import React, { useState } from 'react'
import { Search, ChevronDown, ExternalLink } from 'lucide-react'
import Header from '../components/Header'
import AgentCard from '../components/AgentCard'

const agents = [
  {
    id: 1,
    name: 'HR - Assistance',
    status: 'Active',
    icon: '👤',
    description: 'Handles internal policy queries and employee onboarding workflows for...',
    models: ['LangGraph', 'GPT-4 Turbo']
  },
  {
    id: 2,
    name: 'Claims-Validator',
    status: 'Active',
    icon: '📋',
    description: 'Automated checking of claim submissions against standard medic...',
    models: ['Cortex', 'Llama 3 70B']
  },
  {
    id: 3,
    name: 'Member-Support',
    status: 'Draft',
    icon: '💬',
    description: 'First-line member support for plan coverage and provider search...',
    models: ['LangGraph', 'GPT-4 Turbo']
  },
  {
    id: 4,
    name: 'HR - Assistance',
    status: 'Draft',
    icon: '👤',
    description: 'Handles internal policy queries and employee onboarding workflows for...',
    models: ['LangGraph', 'GPT-4 Turbo']
  },
  {
    id: 5,
    name: 'Claims-Validator',
    status: 'Active',
    icon: '📋',
    description: 'Automated checking of claim submissions against standard medic...',
    models: ['Cortex', 'Llama 3 70B']
  },
  {
    id: 6,
    name: 'Member-Support',
    status: 'Draft',
    icon: '💬',
    description: 'First-line member support for plan coverage and provider search...',
    models: ['LangGraph', 'GPT-4 Turbo']
  },
  {
    id: 7,
    name: 'HR - Assistance',
    status: 'Draft',
    icon: '👤',
    description: 'Handles internal policy queries and employee onboarding workflows for...',
    models: ['LangGraph', 'GPT-4 Turbo']
  },
  {
    id: 8,
    name: 'Claims-Validator',
    status: 'Active',
    icon: '📋',
    description: 'Automated checking of claim submissions against standard medic...',
    models: ['Cortex', 'Llama 3 70B']
  },
  {
    id: 9,
    name: 'Member-Support',
    status: 'Draft',
    icon: '💬',
    description: 'First-line member support for plan coverage and provider search...',
    models: ['LangGraph', 'GPT-4 Turbo']
  }
]

const getStatusColor = (status) => {
  return status === 'Active' ? 'text-badge-active' : 'text-badge-draft'
}

const getStatusBgColor = (status) => {
  return status === 'Active' ? 'bg-emerald-50' : 'bg-yellow-50'
}

export default function DashboardPage() {
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 9

  return (
    <div className="min-h-screen bg-gray-50 font-open-sans">
      {/* Header */}
     <Header />

      {/* Main Content */}
      <main className="px-8 py-8">
        {/* Page Title */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-open-sans text-base font-semibold text-black" style={{ lineHeight: '24px' }}>Key Performance Indicators</h1>
<button style={{
            color: '#0079C2',
            textAlign: 'center',
            fontFamily: 'Open Sans',
            fontSize: '13px',
            fontStyle: 'normal',
            fontWeight: '600',
            lineHeight: '16px',
            border: 'none',
            background: 'none',
            cursor: 'pointer',
            padding: '0',
            margin: '0'
          }}>Register New Agent
          </button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-6 gap-4 mb-12">
          <KPICard label="Total Agents" value="342" change="+5 | 0%" changeType="up" />
          <KPICard label="Total Cortex Agents" value="126" change="-$12 | 1%" changeType="down" />
          <KPICard label="Total LangGraph Agents" value="216" change="+$16 | 0.8%" changeType="up" />
          <KPICard label="Active Agents" value="68" change="+$16 | 0.8%" changeType="up" />
          <KPICard label="Active Cortex Agents" value="30" change="+0.1 | 0.12%" changeType="up" />
          <KPICard label="Active LangGraph Agents" value="38" change="+0.4 | 0.09%" changeType="up" />
        </div>

        {/* Agents Section */}
        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-6">(App Name) Agents</h2>

          {/* Search and Filters */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search Agent:"
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:border-primary-blue"
              />
            </div>
            <div className="relative">
              <select className="px-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:border-primary-blue appearance-none bg-white pr-8">
                <option>Agent Type:</option>
              </select>
              <ChevronDown className="absolute right-2 top-2.5 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>
            <div className="relative">
              <select className="px-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:border-primary-blue appearance-none bg-white pr-8">
                <option>Agent Name:</option>
              </select>
              <ChevronDown className="absolute right-2 top-2.5 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>
          </div>

           {/* Agent Cards Grid */}
          {/* <div className="grid grid-cols-3 gap-6">
            {agents.map((agent) => (
              <div
                key={agent.id}
                style={{
                  width: '411px',
                  height: '243px',
                  borderRadius: '8px',
                  background: '#FFF',
                  boxShadow: '0 13px 19px -13px rgba(17, 17, 17, 0.30)',
                  padding: '16px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px'
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    width: '362.664px',
                    height: '48px',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start'
                  }}
                >
                  <div
                    style={{
                      width: '48px',
                      height: '48px',
                      flexShrink: 0,
                      aspectRatio: '1/1',
                      borderRadius: '8px',
                      background: '#0079C2',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '24px',
                      color: 'white'
                    }}
                  >
                    {agent.icon}
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      padding: '2px 10px',
                      justifyContent: 'center',
                      alignItems: 'center',
                      gap: '8px',
                      borderRadius: '16px',
                      background: agent.status === 'Active' ? '#F1F9F7' : '#FEF3F2',
                      color: agent.status === 'Active' ? '#53B1A3' : '#D90026',
                      fontSize: '11px',
                      fontWeight: '600',
                      fontFamily: 'Open Sans'
                    }}
                  >
                    {agent.status}
                  </div>
                </div>

                <h3
                  style={{
                    color: '#5B6770',
                    fontFamily: 'Open Sans',
                    fontSize: '18px',
                    fontWeight: '600',
                    lineHeight: '27px',
                    margin: '0',
                    marginTop: '4px'
                  }}
                >
                  {agent.name}
                </h3>

                <p
                  style={{
                    width: '338px',
                    color: '#5B6770',
                    fontFamily: 'Open Sans',
                    fontSize: '13px',
                    fontWeight: '300',
                    lineHeight: '18px',
                    margin: '0',
                    marginBottom: '8px'
                  }}
                >
                  {agent.description}
                </p>

                <div
                  style={{
                    display: 'flex',
                    width: '362.664px',
                    height: '36px',
                    alignItems: 'flex-start',
                    gap: '8px',
                    marginTop: 'auto'
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      padding: '9px 11.383px 10px 12px',
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: '8px',
                      border: '1px solid rgba(0, 121, 194, 0.20)',
                      background: 'rgba(0, 121, 194, 0.10)'
                    }}
                  >
                    <span
                      style={{
                        color: '#0079C2',
                        fontFamily: 'Open Sans',
                        fontSize: '11px',
                        fontWeight: '600',
                        lineHeight: '16.5px'
                      }}
                    >
                      {agent.models[0]}
                    </span>
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      padding: '9px 11.156px 10px 12px',
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: '8px',
                      border: '1px solid #E2E8F0',
                      background: '#F1F5F9'
                    }}
                  >
                    <span
                      style={{
                        color: '#5B6770',
                        fontFamily: 'Open Sans',
                        fontSize: '11px',
                        fontWeight: '600',
                        lineHeight: '16.5px'
                      }}
                    >
                      {agent.models[1]}
                    </span>
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      width: '31px',
                      height: '32px',
                      padding: '8.5px 8px 0 8px',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      borderRadius: '16px',
                      marginLeft: 'auto',
                      cursor: 'pointer',
                      hover: { background: '#F5F5F5' }
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none" style={{ height: '15px', flexShrink: 0, alignSelf: 'stretch' }}>
                      <path d="M9.375 1.875H13.125V5.625" stroke="#94A3B8" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M6.25 8.75L13.125 1.875" stroke="#94A3B8" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M11.25 8.125V11.875C11.25 12.2065 11.1183 12.5245 10.8839 12.7589C10.6495 12.9933 10.3315 13.125 10 13.125H3.125C2.79348 13.125 2.47554 12.9933 2.24112 12.7589C2.0067 12.5245 1.875 12.2065 1.875 11.875V5C1.875 4.66848 2.0067 4.35054 2.24112 4.11612C2.47554 3.8817 2.79348 3.75 3.125 3.75H6.875" stroke="#94A3B8" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                </div>
              </div>
            ))}
          </div> */}

           {/* Agent Cards Grid */}
          <div style={{
            display: 'inline-grid',
            rowGap: '24px',
            columnGap: '24px',
            gridTemplateRows: 'repeat(3, fit-content(100%))',
            gridTemplateColumns: 'repeat(3, fit-content(100%))'
          }}>
            {agents.map((agent) => (
              <AgentCard key={agent.id} agent={agent} />
            ))}
          </div>


          {/* Pagination */}
          <div className="flex items-center justify-between mt-8 text-sm text-gray-600">
            <span>1 of 100 of 8,618</span>
            <div className="flex items-center gap-2">
              <button className="p-1 hover:bg-gray-200 rounded">&lt;</button>
              <span>Page 1 of 87</span>
              <button className="p-1 hover:bg-gray-200 rounded">&gt;</button>
              <button className="p-1 hover:bg-gray-200 rounded">&raquo;</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

function KPICard({ label, value, change, changeType }) {
  // Parse change string to separate number and percentage
  const changeMatch = change.match(/([\+\-\$\s\d.]+)\s*\|\s*([\d.]+%)/);
  const changeNumber = changeMatch ? changeMatch[1].trim() : change;
  const changePercent = changeMatch ? changeMatch[2] : '';

  const UpArrow = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="11" viewBox="0 0 9 11" fill="none" style={{ width: '8.901px', height: '10.881px' }}>
      <path fillRule="evenodd" clipRule="evenodd" d="M3.757 0.298058C4.14018 -0.0992929 4.76158 -0.0994126 5.14469 0.298058L8.61344 3.89864C8.99664 4.29635 8.99664 4.94136 8.61344 5.33907C8.23024 5.73675 7.60894 5.73677 7.22575 5.33907L5.45036 3.4963V9.88107C5.45035 10.4334 5.00264 10.8811 4.45036 10.8811C3.89821 10.8809 3.45036 10.4332 3.45036 9.88107V3.4963L1.67496 5.33907C1.29176 5.73677 0.670466 5.73678 0.287269 5.33907C-0.0956676 4.94134 -0.0958451 4.29626 0.287269 3.89864L3.757 0.298058Z" fill="#53B1A3"/>
    </svg>
  );

  const DownArrow = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="11" viewBox="0 0 9 11" fill="none" style={{ width: '8.901px', height: '10.881px' }}>
      <path fillRule="evenodd" clipRule="evenodd" d="M5.14401 10.583C4.76083 10.9804 4.13943 10.9805 3.75632 10.583L0.287567 6.98243C-0.0956354 6.58472 -0.0956354 5.93971 0.287567 5.542C0.670773 5.14432 1.29207 5.1443 1.67526 5.542L3.45065 7.38477L3.45065 1.00001C3.45065 0.447722 3.89837 6.67572e-06 4.45065 6.67572e-06C5.0028 0.000173569 5.45065 0.447825 5.45065 1.00001L5.45065 7.38477L7.22604 5.542C7.60925 5.14431 8.23054 5.14429 8.61374 5.542C8.99668 5.93973 8.99685 6.58481 8.61374 6.98243L5.14401 10.583Z" fill="#D90026"/>
    </svg>
  );

  return (
    <div className="flex flex-col items-start flex-1 p-4 rounded-lg bg-white" style={{ boxShadow: '0 13px 19px -13px rgba(17, 17, 17, 0.30)' }}>
      {/* Label */}
      <p style={{
        color: '#5B6770',
        fontFamily: 'Open Sans',
        fontSize: '14px',
        fontWeight: '400',
        lineHeight: '16px',
        marginBottom: '12px',
        width: '100%'
      }}>
        {label}
      </p>

      {/* Value */}
      <p style={{
        color: '#5B6770',
        fontFamily: 'Open Sans',
        fontSize: '36px',
        fontWeight: '300',
        lineHeight: '48px',
        marginBottom: '8px'
      }}>
        {value}
      </p>

      {/* Change Indicator */}
      <div
        className="flex items-center"
        style={{
          display: 'flex',
          padding: '0 8px',
          alignItems: 'center',
          gap: '5px',
          borderRadius: '8px',
          backgroundColor: changeType === 'up' ? 'rgba(83, 177, 163, 0.10)' : 'rgba(217, 0, 38, 0.10)'
        }}
      >
        {changeType === 'up' ? <UpArrow /> : <DownArrow />}
        <span style={{
          color: '#5B6770',
          fontFamily: 'Open Sans',
          fontSize: '11px',
          fontWeight: '300',
          lineHeight: '16px'
        }}>
          {changeNumber} | {changePercent}
        </span>
      </div>
    </div>
  )
}
