// import React from 'react'
// import { useState } from 'react'
// import { Eye, EyeOff } from 'lucide-react'
// import { useNavigate } from 'react-router-dom'

// export default function LoginPage() {
//   const [showPassword, setShowPassword] = useState(false)
//   const navigate = useNavigate()

//   const handleLogin = (e) => {
//     e.preventDefault()
//     navigate('/dashboard')
//   }

//   return (
//     <div className="flex h-screen font-source-sans">
//       {/* Left Side - Blue Section */}
//       <div style={{
//         display: 'flex',
//         width: '512px',
//         padding: '64px',
//         flexDirection: 'column',
//         justifyContent: 'space-between',
//         alignItems: 'flex-start',
//         background: '#0079C2',
//         color: 'white',
//         height: '100vh',
//         boxSizing: 'border-box'
//       }}>
//         {/* Top Section: Logo and Content */}
//         <div style={{ width: '100%' }}>
//           {/* Logo and Title */}
//           <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px', marginBottom: '40px' }}>
//             {/* Letter E */}
//             <div style={{
//               width: '48px',
//               height: '48px',
//               borderRadius: '6px',
//               background: 'white',
//               boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.10), 0 2px 4px -2px rgba(0, 0, 0, 0.10)',
//               display: 'flex',
//               alignItems: 'center',
//               justifyContent: 'center',
//               color: '#0079C2',
//               fontWeight: 'bold',
//               fontSize: '28px',
//               flexShrink: 0
//             }}>
//               E
//             </div>

//             {/* Elevance and Health Text */}
//             <div>
//               {/* Elevance */}
//               <div style={{
//                 color: '#FFF',
//                 fontFamily: '"Source Sans 3"',
//                 fontSize: '30px',
//                 fontWeight: '700',
//                 lineHeight: '30px',
//                 letterSpacing: '-0.75px',
//                 margin: '0 0 2px 0'
//               }}>
//                 Elevance
//               </div>
//               {/* Health */}
//               <div style={{
//                 color: '#FFF',
//                 fontFamily: '"Source Sans 3"',
//                 fontSize: '24px',
//                 fontWeight: '300',
//                 lineHeight: '30px',
//                 letterSpacing: '0.6px',
//                 margin: 0
//               }}>
//                 Health
//               </div>
//             </div>
//           </div>

//           {/* Enterprise Portal and Agent Studio Container */}
//           <div style={{
//             display: 'flex',
//             flexDirection: 'column',
//             alignItems: 'flex-start',
//             gap: '24px',
//             alignSelf: 'stretch'
//           }}>
//             {/* Enterprise Portal Badge */}
//             <div style={{
//               display: 'flex',
//               padding: '4px 12px',
//               alignItems: 'center',
//               borderRadius: '2px',
//               border: '1px solid rgba(255, 255, 255, 0.20)',
//               background: 'rgba(255, 255, 255, 0.10)'
//             }}>
//               <span style={{
//                 color: 'rgba(255, 255, 255, 0.90)',
//                 fontFamily: '"Source Sans 3"',
//                 fontSize: '12px',
//                 fontWeight: '600',
//                 lineHeight: '16px',
//                 letterSpacing: '1.2px',
//                 textTransform: 'uppercase',
//                 margin: 0
//               }}>
//                 ENTERPRISE PORTAL
//               </span>
//             </div>

//             {/* Agent Studio Title */}
//             <h2 style={{
//               color: '#FFF',
//               fontFamily: '"Source Sans 3"',
//               fontSize: '48px',
//               fontWeight: '700',
//               lineHeight: '60px',
//               margin: 0
//             }}>
//               Agent Studio
//             </h2>

//             {/* Description */}
//             <p style={{
//               color: 'rgba(255, 255, 255, 0.80)',
//               fontFamily: '"Source Sans 3"',
//               fontSize: '20px',
//               fontWeight: '400',
//               lineHeight: '32.5px',
//               margin: 0,
//               maxWidth: '320px'
//             }}>
//               The enterprise-grade no-code and low-code agent builder for professional agent registration and secure management.
//             </p>
//             <div style={{display: 'flex',
// paddingTop: '40px',
// flexDirection: 'column',
// alignItems: 'flex-start',
// alignSelf: 'stretch'}}>
//     <div style={{
//             display: 'flex',
//             alignItems: 'center',
//             gap: '12px',
//             marginBottom: '32px'
//           }}>
//             {/* 1st Line */}
//             <div style={{
//               width: '48px',
//               height: '6px',
//               borderRadius: '9999px',
//               background: '#00AEEF'
//             }}></div>
//             {/* 2nd Line */}
//             <div style={{
//               width: '16px',
//               height: '6px',
//               borderRadius: '9999px',
//               background: 'rgba(255, 255, 255, 0.20)'
//             }}></div>
//             {/* 3rd Line */}
//             <div style={{
//               width: '16px',
//               height: '6px',
//               borderRadius: '9999px',
//               background: 'rgba(255, 255, 255, 0.20)'
//             }}></div>
//           </div>

// </div>
//           </div>
//         </div>

//         {/* Bottom Section: Decorative Lines and Copyright */}
//         <div style={{ width: '100%' }}>
//           {/* Decorative Lines Container */}


//           {/* Copyright Section */}
//           <div style={{
//             color: 'rgba(255, 255, 255, 0.50)',
//             fontFamily: '"Source Sans 3"',
//             fontSize: '14px',
//             fontWeight: '300',
//             lineHeight: '20px'
//           }}>
//             <p style={{ margin: '0 0 4px 0' }}>© 2024 Elevance Health. All rights reserved.</p>
//             <p style={{ margin: 0 }}>Authorized Personnel Only.</p>
//           </div>
//         </div>
//       </div>

//       {/* Right Side - Form Section */}
//       <div style={{ flex: 1, background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '32px' }}>
//         <div style={{ background: 'white', borderRadius: '8px', padding: '48px', width: '100%', maxWidth: '420px', boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)' }}>
//           {/* Form Header */}
//           <h3 className="text-3xl font-bold text-primary-blue text-center mb-2">
//             Welcome Back
//           </h3>
//           <p className="text-center text-gray-700 text-sm mb-8">
//             Please enter your credentials to access<br />Agent Studio.
//           </p>

//           {/* Login Form */}
//           <form onSubmit={handleLogin} className="space-y-6">
//             {/* User ID Field */}
//             <div>
//               <label className="block text-sm font-semibold text-gray-800 mb-2">
//                 User ID
//               </label>
//               <div className="relative">
//                 <span className="absolute left-4 top-4 text-gray-400">
//                   👤
//                 </span>
//                 <input
//                   type="text"
//                   placeholder="Enter your User ID"
//                   className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700"
//                 />
//               </div>
//             </div>

//             {/* Password Field */}
//             <div>
//               <label className="block text-sm font-semibold text-gray-800 mb-2">
//                 Password
//               </label>
//               <div className="relative">
//                 <span className="absolute left-4 top-4 text-gray-400">
//                   🔒
//                 </span>
//                 <input
//                   type={showPassword ? 'text' : 'password'}
//                   placeholder="•••••••"
//                   className="w-full pl-12 pr-12 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700"
//                 />
//                 <button
//                   type="button"
//                   onClick={() => setShowPassword(!showPassword)}
//                   className="absolute right-4 top-3 text-gray-400 hover:text-gray-600"
//                 >
//                   {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
//                 </button>
//               </div>
//             </div>

//             {/* Application Code Field */}
//             <div>
//               <label className="block text-sm font-semibold text-gray-800 mb-2">
//                 Application Code
//               </label>
//               <div className="relative">
//                 <span className="absolute left-4 top-4 text-gray-400">
//                   ☰
//                 </span>
//                 <select className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700 appearance-none bg-white">
//                   <option>Select Application Code</option>
//                 </select>
//                 <span className="absolute right-4 top-4 text-gray-400 pointer-events-none">
//                   ▼
//                 </span>
//               </div>
//             </div>

//             {/* Remember & Forgot */}
//             <div className="flex items-center justify-between text-sm">
//               <label className="flex items-center gap-2 cursor-pointer">
//                 <input type="checkbox" className="w-4 h-4 border border-gray-300 rounded" />
//                 <span className="text-gray-700">Remember me</span>
//               </label>
//               <a href="#" className="text-primary-blue hover:underline font-semibold">
//                 Forgot password?
//               </a>
//             </div>

//             {/* Sign In Button */}
//             <button
//               type="submit"
//               className="w-full bg-primary-blue text-white py-3 rounded-md font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2 mt-8"
//             >
//               Sign in
//               <span>→</span>
//             </button>
//           </form>

//           {/* Sign Up Link */}
//           <p className="text-center text-gray-700 text-sm mt-6">
//             New agent? <a href="#" className="text-primary-blue hover:underline font-semibold">Request access</a>
//           </p>
//         </div>
//       </div>
//     </div>
//   )
// }
import React from 'react'
import { useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const navigate = useNavigate()

  const handleLogin = (e) => {
    e.preventDefault()
    navigate('/dashboard')
  }

  return (
    <div className="flex h-screen font-source-sans">
      {/* Left Side - Blue Section */}
      <div style={{
        display: 'flex',
        width: '512px',
        padding: '64px',
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        background: '#0079C2',
        color: 'white',
        height: '100vh',
        boxSizing: 'border-box'
      }}>
        {/* Logo Section - Stays at Top */}
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px' }}>
          {/* Letter E */}
          <div style={{
            width: '48px',
            height: '48px',
            borderRadius: '6px',
            background: 'white',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.10), 0 2px 4px -2px rgba(0, 0, 0, 0.10)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#0079C2',
            fontWeight: 'bold',
            fontSize: '28px',
            flexShrink: 0
          }}>
            E
          </div>

          {/* Elevance and Health Text */}
          <div>
            {/* Elevance */}
            <div style={{
              color: '#FFF',
              fontFamily: '"Source Sans 3"',
              fontSize: '30px',
              fontWeight: '700',
              lineHeight: '30px',
              letterSpacing: '-0.75px',
              margin: '0 0 2px 0'
            }}>
              Elevance
            </div>
            {/* Health */}
            <div style={{
              color: '#FFF',
              fontFamily: '"Source Sans 3"',
              fontSize: '24px',
              fontWeight: '300',
              lineHeight: '30px',
              letterSpacing: '0.6px',
              margin: 0
            }}>
              Health
            </div>
          </div>
        </div>

        {/* Enterprise Portal and Agent Studio Container - Expands with flex:1 */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          gap: '24px',
          width: '100%',
          flex: 1,
          justifyContent: 'center'
        }}>
          {/* Enterprise Portal Badge */}
          <div style={{
            display: 'flex',
            padding: '4px 12px',
            alignItems: 'center',
            borderRadius: '2px',
            border: '1px solid rgba(255, 255, 255, 0.20)',
            background: 'rgba(255, 255, 255, 0.10)'
          }}>
            <span style={{
              color: 'rgba(255, 255, 255, 0.90)',
              fontFamily: '"Source Sans 3"',
              fontSize: '12px',
              fontWeight: '600',
              lineHeight: '16px',
              letterSpacing: '1.2px',
              textTransform: 'uppercase',
              margin: 0
            }}>
              ENTERPRISE PORTAL
            </span>
          </div>

          {/* Agent Studio Title */}
          <h2 style={{
            color: '#FFF',
            fontFamily: '"Source Sans 3"',
            fontSize: '48px',
            fontWeight: '700',
            lineHeight: '60px',
            margin: 0
          }}>
            Agent Studio
          </h2>

          {/* Description */}
          <p style={{
            color: 'rgba(255, 255, 255, 0.80)',
            fontFamily: '"Source Sans 3"',
            fontSize: '20px',
            fontWeight: '400',
            lineHeight: '32.5px',
            margin: 0,
            maxWidth: '320px'
          }}>
            The enterprise-grade no-code and low-code agent builder for professional agent registration and secure management.
          </p>
          <div style={{
            display: 'flex',
            paddingTop: '40px',
            flexDirection: 'column',
            alignItems: 'flex-start',
            alignSelf: 'stretch'
          }}>
            {/* Decorative Lines Container */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '32px'
            }}>
              {/* 1st Line */}
              <div style={{
                width: '48px',
                height: '6px',
                borderRadius: '9999px',
                background: '#00AEEF'
              }}></div>
              {/* 2nd Line */}
              <div style={{
                width: '16px',
                height: '6px',
                borderRadius: '9999px',
                background: 'rgba(255, 255, 255, 0.20)'
              }}></div>
              {/* 3rd Line */}
              <div style={{
                width: '16px',
                height: '6px',
                borderRadius: '9999px',
                background: 'rgba(255, 255, 255, 0.20)'
              }}></div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Decorative Lines and Copyright */}
        <div style={{ width: '100%' }}>


          {/* Copyright Section */}
          <div style={{
            color: 'rgba(255, 255, 255, 0.50)',
            fontFamily: '"Source Sans 3"',
            fontSize: '14px',
            fontWeight: '300',
            lineHeight: '20px'
          }}>
            <p style={{ margin: '0 0 4px 0' }}>© 2024 Elevance Health. All rights reserved.</p>
            <p style={{ margin: 0 }}>Authorized Personnel Only.</p>
          </div>
        </div>
      </div>

      {/* Right Side - Form Section */}
      <div style={{
        display: 'flex',
        width: '768px',
        padding: 48,
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'stretch'
      }}>
       
        <div style={{
          width: '448px',
          height: 752,
          borderRadius: 8,
          background: 'rgba(255, 255, 255, 0.00)',
          boxShadow: '0 10px 40px -10px rgba(0, 38, 119, 0.15)',
        }}>
          {/* Form Header */}
          <div style={{
            display: 'flex',
            width: 334,
            flexDirection: 'column',
            alignItems: 'flex-start',
            gap: 12
          }}>
          <h3 style={{
width: '190.08px',
height: '36px',
justifyContent: 'center',
marginBottom: '16px',
color: '#0079C2',
textAlign: 'center',
fontFamily: '"Source Sans 3"',
fontSize: '30px',
fontStyle: 'normal',
fontWeight: '700',
lineHeight: '36px'
}}>
            Welcome Back
          </h3>
          <p className="text-center text-gray-700 text-sm mb-8">
            Please enter your credentials to access<br />Agent Studio.
          </p>
                    </div>

          {/* Login Form */}
<div style={{display: 'flex',
width: '334px',
flexDirection: 'column',
alignItems: 'flex-start',
gap: '28px'}}>
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-2">
                User ID
              </label>
              <div className="relative">
                <span className="absolute left-4 top-4 text-gray-400">
                  👤
                </span>
                <input
                  type="text"
                  placeholder="Enter your User ID"
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-2">
                Password
              </label>
              <div className="relative">
                <span className="absolute left-4 top-4 text-gray-400">
                  🔒
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="•••••••"
                  className="w-full pl-12 pr-12 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-3 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            {/* Application Code Field */}
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-2">
                Application Code
              </label>
              <div className="relative">
                <span className="absolute left-4 top-4 text-gray-400">
                  ☰
                </span>
                <select className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700 appearance-none bg-white">
                  <option>Select Application Code</option>
                </select>
                <span className="absolute right-4 top-4 text-gray-400 pointer-events-none">
                  ▼
                </span>
              </div>
            </div>

            {/* Remember & Forgot */}
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 border border-gray-300 rounded" />
                <span className="text-gray-700">Remember me</span>
              </label>
              <a href="#" className="text-primary-blue hover:underline font-semibold">
                Forgot password?
              </a>
            </div>

            {/* Sign In Button */}
            <button
              type="submit"
              className="w-full bg-primary-blue text-white py-3 rounded-md font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2 mt-8"
            >
              Sign in
              <span>→</span>
            </button>
          </div>

          {/* Sign Up Link */}
          <p className="text-center text-gray-700 text-sm mt-6">
            New agent? <a href="#" className="text-primary-blue hover:underline font-semibold">Request access</a>
          </p>

        </div>
        
      </div>
    </div>
  )
}
