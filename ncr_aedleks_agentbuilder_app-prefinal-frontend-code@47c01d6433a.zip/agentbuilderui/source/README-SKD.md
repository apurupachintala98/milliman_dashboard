
# How to Use

## 1 - Install Packages
npm install --force

## 2 - Run App
npm run dev

## 3 - Check on browser
http://localhost:8080/



