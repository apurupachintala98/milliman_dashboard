"use client"

import { Bot, Users, ExternalLink, Snowflake, GitMerge } from "lucide-react"
import { Card, CardContent } from "../ui/card"

const existingAgents = [
  {
    title: "Agent Builder",
    icon: Bot,
    iconBg: "bg-blue-50",
    iconColor: "text-blue-600",
  },
]

const singleAgentOptions = [
  {
    title: "Cortex Single Agent",
    subtitle: "Snowflake Cortex",
    icon: Snowflake,
    iconBg: "bg-sky-50",
    iconColor: "text-sky-500",
    href: "/agent-builder",
    
  },
  {
    title: "Langgraph Agent",
    subtitle: "Langgraph Framework",
    icon: GitMerge,
    iconBg: "bg-emerald-50",
    iconColor: "text-emerald-500",
    href: "/langraph-agent",
  },
]

const buildCards = [
  {
    title: "Multi Agent",
    description: "Multi-agent, flexible & non-deterministic",
    icon: Users,
    iconBg: "bg-red-50",
    iconColor: "text-red-500",
    disabled: true,
  },
]

const prebuiltAgents = [
  {
    title: "Agent A",
    icon: Bot,
    iconBg: "bg-green-50",
    iconColor: "text-green-600",
  },
  {
    title: "Agent B",
    icon: Users,
    iconBg: "bg-yellow-50",
    iconColor: "text-yellow-600",
  },
]

export function DashboardContent() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-6xl mx-auto px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                Welcome back, Apurupa
              </h1>
              <p className="text-muted-foreground">
                Build, refine, and productionize agents effortlessly in minutes.
              </p>
            </div>
            {/* <div className="flex items-center gap-4 text-sm">
              <a href="#" className="flex items-center gap-1 text-foreground hover:text-primary">
                Docs <ExternalLink className="h-3 w-3" />
              </a>
              <a href="#" className="flex items-center gap-1 text-foreground hover:text-primary">
                APIs <ExternalLink className="h-3 w-3" />
              </a>
              <a href="#" className="flex items-center gap-1 text-foreground hover:text-primary">
                Tutorials <ExternalLink className="h-3 w-3" />
              </a>
            </div> */}
          </div>
        </div>

        {/* Build Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Build</h2>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
              View All
            </a>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Single Agent Section */}
            <div className="lg:col-span-2">
              <Card className="border border-border py-0 h-full">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                      <Bot className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Single Agent</h3>
                      <p className="text-sm text-muted-foreground">Standalone agent, easy to get started</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                    {singleAgentOptions.map((option) => (
                       <a
                       key={option.title}
                       href={option.href}
                       className="block"
                     >
                       <div
                        className="flex items-center gap-3 p-4 rounded-lg border border-border bg-background hover:bg-muted/50 hover:border-primary/30 cursor-pointer transition-all"
                      >
                        <div className={`w-9 h-9 rounded-lg ${option.iconBg} flex items-center justify-center shrink-0`}>
                          <option.icon className={`h-4 w-4 ${option.iconColor}`} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-foreground text-sm">{option.title}</p>
                          <p className="text-xs text-muted-foreground truncate">{option.subtitle}</p>
                        </div>
                      </div>
                      </a>
))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Multi Agent Card */}
            {buildCards.map((card) => (
              <Card
                key={card.title}
                className={`border border-border py-0 transition-shadow ${
                  card.disabled 
                    ? "opacity-60 pointer-events-none bg-muted/30" 
                    : "cursor-pointer hover:shadow-md"
                }`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 rounded-lg ${card.disabled ? "bg-muted" : card.iconBg} flex items-center justify-center`}>
                      <card.icon className={`h-5 w-5 ${card.disabled ? "text-muted-foreground" : card.iconColor}`} />
                    </div>
                    {card.disabled && (
                      <span className="px-2 py-1 text-xs font-medium bg-muted text-muted-foreground rounded-md">
                        Coming Soon
                      </span>
                    )}
                  </div>
                  <h3 className={`font-semibold mb-1 ${card.disabled ? "text-muted-foreground" : "text-foreground"}`}>{card.title}</h3>
                  <p className="text-sm text-muted-foreground">{card.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Existing Agents Section - Disabled */}
        <div className="opacity-60">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-semibold text-foreground">Existing Agents</h2>
              <span className="px-2 py-1 text-xs font-medium bg-muted text-muted-foreground rounded-md">
                Coming Soon
              </span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pointer-events-none">
            {existingAgents.map((agent) => (
              <Card
                key={agent.title}
                className="border border-border py-0 bg-muted/30"
              >
                <CardContent className="p-6">
                  <div className={`w-10 h-10 rounded-lg bg-muted flex items-center justify-center mb-4`}>
                    <agent.icon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold text-muted-foreground">{agent.title}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
