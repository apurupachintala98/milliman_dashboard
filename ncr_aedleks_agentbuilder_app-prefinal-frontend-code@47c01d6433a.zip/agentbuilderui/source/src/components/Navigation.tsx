"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLocation } from "react-router-dom"

export const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const location = useLocation()
  const isHomePage = location.pathname === "/"

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setIsMobileMenuOpen(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("agent_uuid")
    localStorage.removeItem("user_id")
    localStorage.removeItem("agent_name")
    localStorage.removeItem("application_name")
    localStorage.removeItem("llms")
    window.location.href = "/"
  }


  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-card/80 backdrop-blur-xl border-b border-border shadow-card" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex items-end justify-between py-5">
          <a href="/" className="flex items-end gap-3 group">
            <img src="/logo.png" alt="Data Intelligence Platform Agent Studio" className="h-10 w-auto object-contain" />
            <span className="text-xl font-bold bg-gradient-primary bg-clip-text text-transparent leading-tight" style={{fontSize: "25px", lineHeight: "1.3"}}>
              Data Intelligence Platform - Agent Studio
            </span>
          </a>
           {isHomePage ? (
            <div className="hidden md:flex items-center gap-4">
            
              <a href="/login">
                <Button className="bg-gradient-primary hover:opacity-90 transition-opacity">Login</Button>
              </a>
            </div>
            ) : (
            <div className="hidden md:flex items-center gap-4">
              <Button
                onClick={handleLogout}
                variant="outline"
                className="bg-gradient-primary hover:opacity-90 transition-opacity"
              >
                Logout
              </Button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

      
      </div>
    </nav>
  )
}
