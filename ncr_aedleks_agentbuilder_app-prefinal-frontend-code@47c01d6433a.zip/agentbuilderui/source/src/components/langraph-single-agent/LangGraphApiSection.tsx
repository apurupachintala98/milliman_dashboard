"use client"

import { useState, useEffect } from "react"
import { Server, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

interface ApiStepProps {
  onNext: (data: any) => void
  initialData?: any
  defaultConfig?: any
  isLoadingConfig?: boolean
}

export function LangGraphApiSection({ onNext, initialData, defaultConfig, isLoadingConfig }: ApiStepProps) {
  const [includeApi, setIncludeApi] = useState(initialData?.includeApi ?? true)
  const [hostname, setHostname] = useState(initialData?.hostname || "")
  const [apiPort, setApiPort] = useState(initialData?.apiPort || "")

  useEffect(() => {
    if (defaultConfig?.backend_config) {
      setHostname(defaultConfig.backend_config.host || "")
      setApiPort(defaultConfig.backend_config.port?.toString() || "")
    }
  }, [defaultConfig])

  const handleNext = () => {
    if (includeApi && (!apiPort || !hostname)) {
      alert("Please enter hostname and port number")
      return
    }
    onNext({ includeApi, hostname, apiPort })
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full mb-4">
          <Server className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Step 4: API Configuration</span>
        </div>
        <h2 className="text-3xl font-bold mb-2">Configure API</h2>
        <p className="text-muted-foreground">Set up your backend endpoint</p>
      </div>

      <div className="space-y-6">
        <div className="flex items-center space-x-3 p-4 bg-background/30">
          <Checkbox
            id="include-api"
            checked={includeApi}
            onCheckedChange={(checked) => setIncludeApi(checked as boolean)}
            disabled
          />
          <Label htmlFor="include-api" className="cursor-pointer">
            Include API Configuration
          </Label>
        </div>

        {includeApi && (
          <div className="space-y-2 p-3 bg-background/30">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="hostname">Hostname *</Label>
                <Input
                  id="hostname"
                  placeholder="localhost"
                  value={hostname}
                  onChange={(e) => setHostname(e.target.value)}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="api-port">Port *</Label>
                <Input
                  id="api-port"
                  placeholder="8000"
                  value={apiPort}
                  onChange={(e) => setApiPort(e.target.value)}
                  className="bg-background/50"
                  disabled
                />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-end pt-6">
        <Button
          onClick={handleNext}
          size="lg"
          className="bg-gradient-to-r from-purple-500 to-pink-600 hover:opacity-90"
        >
          Next Step
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  )
}
