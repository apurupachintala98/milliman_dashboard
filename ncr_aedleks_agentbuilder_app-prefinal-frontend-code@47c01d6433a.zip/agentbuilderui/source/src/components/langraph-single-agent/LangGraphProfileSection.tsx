// "use client"

// import { useState, useEffect } from "react"
// import { User, Edit2, Save, CheckCircle2 } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Textarea } from "@/components/ui/textarea"
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// import { Checkbox } from "@/components/ui/checkbox"
// import { langgraphApi, type LLMModel } from "@/services/langgraph-api"

// interface LangGraphProfileSectionProps {
//   onProfileSaved?: (data: any) => void
//   onSuccess?: (message: string) => void
// }

// export function LangGraphProfileSection({ onProfileSaved, onSuccess }: LangGraphProfileSectionProps) {
//   const [isEditing, setIsEditing] = useState(true)
//   const [isLoading, setIsLoading] = useState(false)
//   const [agentName, setAgentName] = useState("")
//   const [description, setDescription] = useState("")

//   const [snowflakeCortex, setSnowflakeCortex] = useState(false)
//   const [ehap, setEhap] = useState(false)

//   const [pat, setPat] = useState("")
//   const [baseUrl, setBaseUrl] = useState("")

//   const [llmModels, setLlmModels] = useState<LLMModel[]>([])
//   const [isLoadingModels, setIsLoadingModels] = useState(false)
//   const [aiModel, setAiModel] = useState("")
//   const [systemInstructions, setSystemInstructions] = useState("")
//   const [orchestrationInstructions, setOrchestrationInstructions] = useState("")
//   const [responseInstructions, setResponseInstructions] = useState("")

//   useEffect(() => {
//     if (snowflakeCortex) {
//       console.log("[v0] ProfileSection - Snowflake Cortex selected, loading LLMs from localStorage")

//       // Try to load from localStorage first
//       const storedModels = localStorage.getItem("llm_models")
//       const storedProviderId = localStorage.getItem("snowflake_provider_id")

//       if (storedModels) {
//         try {
//           const models = JSON.parse(storedModels)
//           console.log("[v0] ProfileSection - Loaded LLMs from localStorage:", models)
//           setLlmModels(models)
//         } catch (error) {
//           console.error("[v0] ProfileSection - Failed to parse stored LLM models:", error)
//           // Fallback to API call if localStorage data is corrupted
//           fetchLLMModels(storedProviderId)
//         }
//       } else {
//         // If not in localStorage, fetch from API
//         console.log("[v0] ProfileSection - No LLMs in localStorage, fetching from API")
//         fetchLLMModels(storedProviderId)
//       }
//     } else {
//       setLlmModels([])
//       setAiModel("")
//     }
//   }, [snowflakeCortex])

//   const fetchLLMModels = async (providerId: string | null) => {
//     if (!providerId) {
//       console.error("[v0] ProfileSection - No provider_id available")
//       alert("Provider information not found. Please go back to dashboard and try again.")
//       return
//     }

//     setIsLoadingModels(true)
//     try {
//       console.log("[v0] ProfileSection - Fetching LLMs with provider_id:", providerId)
//       const models = await langgraphApi.getLLMs(providerId)
//       console.log("[v0] ProfileSection - Fetched LLM models:", models)
//       setLlmModels(models)
//       localStorage.setItem("llm_models", JSON.stringify(models))
//     } catch (error) {
//       console.error("[v0] ProfileSection - Failed to load LLM models:", error)
//       alert("Failed to load AI models. Please try again.")
//     } finally {
//       setIsLoadingModels(false)
//     }
//   }

//   const handleSave = async () => {
//     if (!agentName.trim()) {
//       alert("Please enter an agent name")
//       return
//     }

//     if (!snowflakeCortex) {
//       alert("Please select Snowflake Cortex as LLM Service Provider")
//       return
//     }

//     if (!pat.trim()) {
//       alert("Please enter PAT")
//       return
//     }

//     if (!baseUrl.trim()) {
//       alert("Please enter Base URL")
//       return
//     }

//     if (!aiModel) {
//       alert("Please select an AI model")
//       return
//     }

//     setIsLoading(true)

//     try {
//       const storedProviderId = localStorage.getItem("snowflake_provider_id")
//       const payload = {
//         agent_name: agentName,
//         agent_description: description,
//         agent_instructions: {
//           system: systemInstructions,
//           orchestration: orchestrationInstructions,
//           response_structure: responseInstructions,
//         },
//         llm_config: {
//           model_id: aiModel,
//           model_name: llmModels.find((m) => m.model_id === aiModel)?.model_name || "",
//           provider_name: storedProviderId,
//           llm_auth: {
//             base_url: baseUrl,
//             pat_token: pat,
//           },
//           llm_model_config: {
//             temperature: 0.1,
//             max_tokens: 1024,
//           },
//         },
//       }

//       console.log("[v0] ProfileSection - Calling createAgent API with payload:", payload)
//       const response = await langgraphApi.createAgent(payload)
//       console.log("[v0] ProfileSection - Create agent response:", response)
//       console.log("[v0] ProfileSection - Agent UUID:", response.agent_uuid)

//       localStorage.setItem("langgraph_agent_uuid", response.agent_uuid)
//       localStorage.setItem("langgraph_profile_saved", "true")
//       console.log("[v0] ProfileSection - Saved to localStorage - UUID:", response.agent_uuid)

//       const profileData = {
//         agentName,
//         description,
//         serviceProvider: {
//           snowflakeCortex,
//           ehap,
//         },
//         credentials: {
//           pat,
//           baseUrl,
//         },
//         aiModel,
//         instructions: {
//           system: systemInstructions,
//           orchestration: orchestrationInstructions,
//           response: responseInstructions,
//         },
//         agentUuid: response.agent_uuid,
//       }

//       if (onProfileSaved) onProfileSaved(profileData)
//       if (onSuccess) onSuccess(response.message || "Agent profile created successfully!")
//       setIsEditing(false)
//     } catch (error) {
//       console.error("Failed to create agent:", error)
//       alert("Failed to create agent. Please check your inputs and try again.")
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   const handleEdit = () => {
//     setIsEditing(true)
//   }

//   return (
//     <section id="profile" className="py-24 relative">
//       <div className="container mx-auto px-6">
//         <div className="max-w-5xl mx-auto">
//           {/* Section Header */}
//           <div className="text-center mb-16 animate-fade-in">
//             <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
//               <User className="w-4 h-4 text-primary" />
//               <span>Step 1</span>
//             </div>
//             <h2 className="text-4xl md:text-5xl font-bold mb-4">
//               Define Your <span className="bg-gradient-primary bg-clip-text text-transparent">Agent Profile</span>
//             </h2>
//             <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//               Configure your agent's basic settings and capabilities
//             </p>
//           </div>

//           {/* Profile Card */}
//           <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-card space-y-6">
//             {/* Agent Name */}
//             <div className="space-y-2">
//               <Label htmlFor="agent-name">Agent Name *</Label>
//               <Input
//                 id="agent-name"
//                 placeholder="Enter agent name"
//                 value={agentName}
//                 onChange={(e) => setAgentName(e.target.value)}
//                 disabled={!isEditing}
//                 className="bg-background"
//               />
//             </div>

//             {/* Description */}
//             <div className="space-y-2">
//               <Label htmlFor="description">Agent Description</Label>
//               <Textarea
//                 id="description"
//                 placeholder="Describe what your agent does"
//                 rows={3}
//                 value={description}
//                 onChange={(e) => setDescription(e.target.value)}
//                 disabled={!isEditing}
//                 className="bg-background resize-none"
//               />
//             </div>

//             {/* LLM Service Provider */}
//             <div className="space-y-4 pt-4 border-t border-border">
//               <Label className="text-base font-semibold">LLM Service Provider</Label>

//               <div className="space-y-4">
//                 <div className="space-y-3">
//                   <div className="flex items-center space-x-2">
//                     <Checkbox
//                       id="snowflake-cortex"
//                       checked={snowflakeCortex}
//                       onCheckedChange={(checked) => {
//                         setSnowflakeCortex(checked as boolean)
//                         if (!checked) {
//                           setPat("")
//                           setBaseUrl("")
//                         }
//                       }}
//                       disabled={!isEditing}
//                     />
//                     <label htmlFor="snowflake-cortex" className="text-sm font-medium leading-none cursor-pointer">
//                       SnowFlake Cortex
//                     </label>
//                   </div>

//                   {snowflakeCortex && (
//                     <div className="ml-8 pl-4 border-l-2 border-border space-y-4">
//                       {/* Base URL */}
//                       <div className="space-y-2">
//                         <Label htmlFor="base-url">Base URL</Label>
//                         <Input
//                           id="base-url"
//                           placeholder="Enter Base URL"
//                           value={baseUrl}
//                           onChange={(e) => setBaseUrl(e.target.value)}
//                           disabled={!isEditing}
//                           className="bg-background"
//                         />
//                       </div>

//                       {/* PAT */}
//                       <div className="space-y-2">
//                         <Label htmlFor="pat">PAT</Label>
//                         <Input
//                           id="pat"
//                           placeholder="Enter PAT"
//                           value={pat}
//                           onChange={(e) => setPat(e.target.value)}
//                           disabled={!isEditing}
//                           className="bg-background"
//                         />
//                       </div>
//                     </div>
//                   )}
//                 </div>

//                 <div className="flex items-center space-x-2">
//                   <Checkbox
//                     id="ehap"
//                     checked={ehap}
//                     onCheckedChange={(checked) => setEhap(checked as boolean)}
//                     disabled={true}
//                   />
//                   <label htmlFor="ehap" className="text-sm font-medium leading-none cursor-not-allowed opacity-50">
//                     EHAP
//                   </label>
//                 </div>
//               </div>
//             </div>

//             {/* AI Model */}
//             <div className="space-y-2">
//               <Label htmlFor="ai-model">AI Model</Label>
//               <Select
//                 value={aiModel}
//                 onValueChange={setAiModel}
//                 disabled={!isEditing || isLoadingModels || !snowflakeCortex}
//               >
//                 <SelectTrigger className="bg-background">
//                   <SelectValue placeholder={isLoadingModels ? "Loading models..." : "Select AI model"} />
//                 </SelectTrigger>
//                 <SelectContent>
//                   {llmModels.map((model) => (
//                     <SelectItem key={model.model_id} value={model.model_id}>
//                       {model.model_name}
//                     </SelectItem>
//                   ))}
//                 </SelectContent>
//               </Select>
//             </div>

//             {/* Agent Instructions */}
//             <div className="space-y-4 pt-4 border-t border-border">
//               <Label className="text-base font-semibold">Agent Instructions</Label>

//               <div className="space-y-2">
//                 <Label htmlFor="system-instructions">System Instructions</Label>
//                 <Textarea
//                   id="system-instructions"
//                   rows={3}
//                   value={systemInstructions}
//                   onChange={(e) => setSystemInstructions(e.target.value)}
//                   disabled={!isEditing}
//                   className="bg-background resize-none"
//                 />
//               </div>

//               <div className="space-y-2">
//                 <Label htmlFor="orchestration-instructions">Orchestration Instructions</Label>
//                 <Textarea
//                   id="orchestration-instructions"
//                   rows={3}
//                   value={orchestrationInstructions}
//                   onChange={(e) => setOrchestrationInstructions(e.target.value)}
//                   disabled={!isEditing}
//                   className="bg-background resize-none"
//                 />
//               </div>

//               <div className="space-y-2">
//                 <Label htmlFor="response-instructions">Response Instructions</Label>
//                 <Textarea
//                   id="response-instructions"
//                   rows={3}
//                   value={responseInstructions}
//                   onChange={(e) => setResponseInstructions(e.target.value)}
//                   disabled={!isEditing}
//                   className="bg-background resize-none"
//                 />
//               </div>
//             </div>

//             {/* Action Buttons */}
//             <div className="flex items-center gap-4 pt-4 justify-center">
//               {isEditing ? (
//                 <Button
//                   onClick={handleSave}
//                   disabled={isLoading}
//                   className="bg-gradient-primary hover:opacity-90 transition-opacity"
//                 >
//                   <Save className="w-4 h-4 mr-2" />
//                   {isLoading ? "Creating Agent..." : "Save Profile"}
//                 </Button>
//               ) : (
//                 <>
//                   <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
//                     <CheckCircle2 className="w-5 h-5" />
//                     <span className="font-medium">Profile saved</span>
//                   </div>
//                   <Button onClick={handleEdit} variant="outline">
//                     <Edit2 className="w-4 h-4 mr-2" />
//                     Edit Profile
//                   </Button>
//                 </>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>
//     </section>
//   )
// }

"use client"

import { useState, useEffect } from "react"
import { Sparkles, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { langgraphApi, type LLMModel } from "@/services/langgraph-api"

interface ProfileStepProps {
  onNext: (data: any) => void
  initialData?: any
  defaultConfig?: any
  isLoadingConfig?: boolean
}

export function LangGraphProfileSection({ onNext, initialData, defaultConfig, isLoadingConfig }: ProfileStepProps) {
  const [agentName, setAgentName] = useState(initialData?.agentName || "")
  const [description, setDescription] = useState(initialData?.description || "")
  const [snowflakeCortex, setSnowflakeCortex] = useState(initialData?.snowflakeCortex || false)
  const [ehap, setEhap] = useState(false)
  const [pat, setPat] = useState(initialData?.pat || "")
  const [baseUrl, setBaseUrl] = useState(initialData?.baseUrl || "")
  const [llmModels, setLlmModels] = useState<LLMModel[]>([])
  const [isLoadingModels, setIsLoadingModels] = useState(false)
  const [aiModel, setAiModel] = useState(initialData?.aiModel || "")
  const [systemInstructions, setSystemInstructions] = useState(initialData?.systemInstructions || "")
  const [orchestrationInstructions, setOrchestrationInstructions] = useState(
    initialData?.orchestrationInstructions || "",
  )
  const [responseInstructions, setResponseInstructions] = useState(initialData?.responseInstructions || "")
  const [agentNameError, setAgentNameError] = useState("")


  useEffect(() => {
    if (defaultConfig?.profile_config) {
      const { agent_instructions, llm_config } = defaultConfig.profile_config
      setSystemInstructions(agent_instructions.system || "")
      setOrchestrationInstructions(agent_instructions.orchestration || "")
      setResponseInstructions(agent_instructions.response_structure || "")
      setBaseUrl(llm_config.llm_auth.base_url || "")
      if (llm_config.provider_name?.toLowerCase() === "cortex") {
        console.log("[v0] ProfileSection - Preselecting Snowflake Cortex from default config")
        setSnowflakeCortex(true)
      }
      if (llm_config.model_id) {
        console.log("[v0] ProfileSection - Presetting AI model from default config:", llm_config.model_id)
        setAiModel(llm_config.model_id)
      }
    }
  }, [defaultConfig])

  useEffect(() => {
    if (snowflakeCortex) {
      console.log("[v0] ProfileSection - Snowflake Cortex selected, loading LLMs from localStorage")

      const storedModels = localStorage.getItem("llm_models")
      const storedProviderId = localStorage.getItem("snowflake_provider_id")

      if (storedModels) {
        try {
          const models = JSON.parse(storedModels)
          console.log("[v0] ProfileSection - Loaded LLMs from localStorage:", models)
          setLlmModels(models)
        } catch (error) {
          console.error("[v0] ProfileSection - Failed to parse stored LLM models:", error)
          fetchLLMModels(storedProviderId)
        }
      } else {
        console.log("[v0] ProfileSection - No LLMs in localStorage, fetching from API")
        fetchLLMModels(storedProviderId)
      }
    } else {
      setLlmModels([])
      setAiModel("")
    }
  }, [snowflakeCortex])

  const fetchLLMModels = async (providerId: string | null) => {
    if (!providerId) {
      console.error("[v0] ProfileSection - No provider_id available")
      alert("Provider information not found. Please go back to dashboard and try again.")
      return
    }

    setIsLoadingModels(true)
    try {
      console.log("[v0] ProfileSection - Fetching LLMs with provider_id:", providerId)
      const models = await langgraphApi.getLLMs(providerId)
      console.log("[v0] ProfileSection - Fetched LLM models:", models)
      setLlmModels(models)
      localStorage.setItem("llm_models", JSON.stringify(models))
    } catch (error) {
      console.error("[v0] ProfileSection - Failed to load LLM models:", error)
      alert("Failed to load AI models. Please try again.")
    } finally {
      setIsLoadingModels(false)
    }
  }

  const handleAgentNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value

    if (value.includes("_") || value.includes(" ")) {
      setAgentNameError("Agent name cannot contain underscores or spaces")
    } else {
      setAgentNameError("")
    }

    setAgentName(value)
  }

  const handleNext = () => {
    if (!agentName.trim()) {
      alert("Please enter an agent name")
      return
    }
    if (agentName.includes("_") || agentName.includes(" ")) {
      alert("Agent name cannot contain underscores or spaces")
      return
    }
    if (!snowflakeCortex) {
      alert("Please select Snowflake Cortex as LLM Service Provider")
      return
    }
    if (!pat.trim()) {
      alert("Please enter PAT")
      return
    }
    if (!baseUrl.trim()) {
      alert("Please enter Base URL")
      return
    }
    if (!aiModel) {
      alert("Please select an AI model")
      return
    }

    const aiModelName = llmModels.find((m) => m.model_id === aiModel)?.model_name || ""

    onNext({
      agentName,
      description,
      snowflakeCortex,
      ehap,
      pat,
      baseUrl,
      aiModel,
      aiModelName,
      systemInstructions,
      orchestrationInstructions,
      responseInstructions,
    })
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full mb-4">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Step 1: Agent Profile</span>
        </div>
        <h2 className="text-3xl font-bold mb-2">Define Your Agent</h2>
        <p className="text-muted-foreground">Configure your agent's basic settings and capabilities</p>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="agent-name">Agent Name *</Label>
          <Input
            id="agent-name"
            placeholder="Enter agent name"
            value={agentName}
            onChange={handleAgentNameChange}
            className="bg-background/50"
          />
                    {agentNameError && <p className="text-sm text-red-500">{agentNameError}</p>}

        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Agent Description</Label>
          <Textarea
            id="description"
            placeholder="Describe what your agent does"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="bg-background/50 resize-none"
          />
        </div>

        <div className="space-y-4 p-4 border border-border rounded-lg bg-background/30">
          <Label className="text-base font-semibold">LLM Service Provider</Label>

          <div className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="snowflake-cortex"
                  checked={snowflakeCortex}
                  onCheckedChange={(checked) => {
                    setSnowflakeCortex(checked as boolean)
                    if (!checked) {
                      setPat("")
                      setBaseUrl("")
                    }
                  }}
                />
                <label htmlFor="snowflake-cortex" className="text-sm font-medium leading-none cursor-pointer">
                  SnowFlake Cortex
                </label>
              </div>

              {snowflakeCortex && (
                <div className="ml-8 pl-4 border-l-2 border-border space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="base-url">Base URL</Label>
                    <Input
                      id="base-url"
                      placeholder="Enter Base URL"
                      value={baseUrl}
                      onChange={(e) => setBaseUrl(e.target.value)}
                      className="bg-background"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="pat">PAT</Label>
                    <Input
                      id="pat"
                      placeholder="Enter PAT"
                      value={pat}
                      onChange={(e) => setPat(e.target.value)}
                      className="bg-background"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="ehap"
                checked={ehap}
                onCheckedChange={(checked) => setEhap(checked as boolean)}
                disabled={true}
              />
              <label htmlFor="ehap" className="text-sm font-medium leading-none cursor-not-allowed opacity-50">
                EHAP
              </label>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="ai-model">AI Model</Label>
          <Select value={aiModel} onValueChange={setAiModel} disabled={isLoadingModels || !snowflakeCortex}>
            <SelectTrigger className="bg-background/50">
              <SelectValue placeholder={isLoadingModels ? "Loading models..." : "Select AI model"} />
            </SelectTrigger>
            <SelectContent>
              {llmModels.map((model) => (
                <SelectItem key={model.model_id} value={model.model_id}>
                  {model.model_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4 p-4 border border-border rounded-lg bg-background/30">
          <Label className="text-base font-semibold">Agent Instructions</Label>

          <div className="space-y-2">
            <Label htmlFor="system-instructions">System Instructions</Label>
            <Textarea
              id="system-instructions"
              rows={3}
              value={systemInstructions}
              onChange={(e) => setSystemInstructions(e.target.value)}
              className="bg-background/50 resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="orchestration-instructions">Orchestration Instructions</Label>
            <Textarea
              id="orchestration-instructions"
              rows={3}
              value={orchestrationInstructions}
              onChange={(e) => setOrchestrationInstructions(e.target.value)}
              className="bg-background/50 resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="response-instructions">Response Instructions</Label>
            <Textarea
              id="response-instructions"
              rows={3}
              value={responseInstructions}
              onChange={(e) => setResponseInstructions(e.target.value)}
              className="bg-background/50 resize-none"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-6">
        <Button
          onClick={handleNext}
          size="lg"
          className="bg-gradient-to-r from-blue-500 to-purple-600 hover:opacity-90"
        >
          Next Step
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  )
}
