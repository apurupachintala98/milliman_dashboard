"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { nanoid } from "nanoid"
import { Play, BarChart3, MessageSquare, CheckCircle, Clock, Send, AlertCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TypingDots } from "../typing-dots"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
}
export type Role = "user" | "assistant"
export type ChatMessage = {
  id: string
  role: Role
  content: string
}

interface LangGraphTestSectionProps {
  deployUrl?: string | null
  agentName?: string
}

interface ApiResponse {
  response: {
    content_type: string
    messages: Array<{
      role: string
      content: string
    }>
  }
  semantic_memory: Array<any>
  episodic_memory: Array<any>
  procedural_memory: Array<any>
}

function generate6DigitId(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  let result = ""
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export function LangGraphTestSection({ deployUrl, agentName }: LangGraphTestSectionProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [detailsOpen, setDetailsOpen] = useState<Record<string, boolean>>({})
  const [apiUrl, setApiUrl] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [loading, setLoading] = useState(false)
  const [errorNotification, setErrorNotification] = useState<string | null>(null)
  const [applicationCode, setApplicationCode] = useState("")
  const [applicationId, setApplicationId] = useState("")
  const [userId, setUserId] = useState("")
  const [sessionId] = useState(() => nanoid(12))

  useEffect(() => {
    if (agentName) {
      const formattedAgentName = agentName.toLowerCase().trim()
      setApiUrl(`https://agentbuilder-demo.edl.dev.awsdns.internal.das/${formattedAgentName}be-service/`)
    }
  }, [agentName])

  useEffect(() => {
    const sharedId = generate6DigitId()

    const agentUuid = `agent_${sharedId}`
    const appUuid = `app_${sharedId}`
    const userUuid = `user_${sharedId}`

    localStorage.setItem("agent_uuid", agentUuid)
    localStorage.setItem("app_uuid", appUuid)
    localStorage.setItem("user_uuid", userUuid)

    setApplicationCode(agentUuid)
    setApplicationId(appUuid)
    setUserId(userUuid)
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    if (errorNotification) {
      const timer = setTimeout(() => setErrorNotification(null), 5000)
      return () => clearTimeout(timer)
    }
  }, [errorNotification])

  async function typeAssistantMessage(full: string) {
    const id = nanoid()
    const base: Message = { id, role: "assistant", content: "" }
    setMessages((prev) => [...prev, base])

    let acc = ""
    const delay = 12
    for (const ch of full) {
      acc += ch
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: acc } : m)))
      await new Promise((r) => setTimeout(r, delay))
    }
    scrollToBottom()
  }

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault()
    }

    const content = inputValue.trim()
    if (!content) return

    if (!applicationCode || !applicationId || !userId) {
      setErrorNotification("Please fill in all required fields (Agent ID, Application ID, User ID)")
      return
    }

    const userMsg: Message = {
      id: nanoid(),
      role: "user",
      content,
    }
    setMessages((prev) => [...prev, userMsg])
    setInputValue("")
    setIsLoading(true)
    setLoading(true)

    setTimeout(() => scrollToBottom(), 100)

    try {
      const baseUrl = apiUrl.trim()
      if (!baseUrl) {
        throw new Error("API URL is required")
      }

      const payload = {
        agent_id: applicationCode,
        application_id: applicationId,
        user_id: userId,
        session_id: sessionId,
        body: {
          content_type: "text",
          messages: [
            {
              role: "user",
              content: content,
            },
          ],
        },
      }

      const endpoint = baseUrl.endsWith("/") ? `${baseUrl}agent/chat` : `${baseUrl}agent/chat`

      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      if (!res.ok) {
        throw new Error(`API error: ${res.status} ${res.statusText}`)
      }

      const data: ApiResponse = await res.json()

      const assistantText = data.response?.messages?.[0]?.content ?? ""

      if (!assistantText) {
        throw new Error("No response content received from API")
      }
      setLoading(false)
      await typeAssistantMessage(assistantText)
    } catch (e) {
      const errorMsg = e instanceof Error ? e.message : "An unknown error occurred"
      setErrorNotification(errorMsg)

      const errorResponse: Message = {
        id: nanoid(),
        role: "assistant",
        content: "Sorry, I ran into an error. Please try again.",
      }
      setMessages((prev) => [...prev, errorResponse])

      console.error("Chat error:", e)
    } finally {
      setIsLoading(false)
      setLoading(false)
    }
  }

  const toggleDetails = (messageId: string) => {
    setDetailsOpen((prev) => ({
      ...prev,
      [messageId]: !prev[messageId],
    }))
  }

  return (
    <section id="testing" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
              <Play className="w-4 h-4 text-primary" />
              <span>Step 7</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Test & <span className="bg-gradient-primary bg-clip-text text-transparent">Monitor</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Test your agent's responses and monitor performance in real-time
            </p>
          </div>

          {errorNotification && (
            <div className="mb-6 max-w-2xl mx-auto bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-500" />
                <p className="text-sm text-red-700">{errorNotification}</p>
              </div>
              <button onClick={() => setErrorNotification(null)} className="text-red-500 hover:text-red-700">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="mb-8 max-w-2xl mx-auto space-y-4">
            <div>
              <label htmlFor="api-url" className="block text-sm font-medium mb-2">
                Test API URL
              </label>
              <Input
                id="api-url"
                type="text"
                className="bg-card/60 backdrop-blur-xl border-border"
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">Auto-populated from API configuration</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="application-code" className="block text-sm font-medium mb-2">
                  Agent ID*
                </label>
                <Input
                  id="application-code"
                  type="text"
                  className="bg-card/60 backdrop-blur-xl border-border"
                  value={applicationCode}
                  onChange={(e) => setApplicationCode(e.target.value)}
                  placeholder="agent_xxxxxx"
                  required
                />
              </div>

              <div>
                <label htmlFor="application-id" className="block text-sm font-medium mb-2">
                  Application ID *
                </label>
                <Input
                  id="application-id"
                  type="text"
                  className="bg-card/60 backdrop-blur-xl border-border"
                  value={applicationId}
                  onChange={(e) => setApplicationId(e.target.value)}
                  placeholder="app_xxxxxx"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="user-id" className="block text-sm font-medium mb-2">
                User ID *
              </label>
              <Input
                id="user-id"
                type="text"
                className="bg-card/60 backdrop-blur-xl border-border"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="user_xxxxxx"
                required
              />
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-6 shadow-card">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center shadow-glow">
                  <MessageSquare className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Test Your Agent</h3>
                </div>
              </div>

              <div className="space-y-4 mb-6 h-96 overflow-y-auto">
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <p className="text-sm">Start a conversation with your agent...</p>
                  </div>
                ) : (
                  <ul className="space-y-3">
                    {messages.map((m) => (
                      <li key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                        <div
                          className={
                            m.role === "user"
                              ? "max-w-[85%] rounded-2xl bg-slate-900 px-4 py-2 text-white shadow-sm transition-all duration-300 data-[show=true]:opacity-100 data-[show=true]:translate-y-0 opacity-0 translate-y-1"
                              : "max-w-[85%] rounded-2xl bg-white px-4 py-2 text-slate-900 shadow-sm ring-1 ring-slate-200 transition-all duration-300 data-[show=true]:opacity-100 data-[show=true]:translate-y-0 opacity-0 translate-y-1"
                          }
                          data-show
                        >
                          <div className="whitespace-pre-wrap text-sm leading-6">{m.content}</div>
                        </div>
                      </li>
                    ))}
                    {loading && (
                      <li className="flex justify-start">
                        <div className="max-w-[85%] rounded-2xl bg-white px-4 py-2 text-slate-900 shadow-sm ring-1 ring-slate-200">
                          <TypingDots />
                        </div>
                      </li>
                    )}
                  </ul>
                )}
                <div ref={messagesEndRef} />
              </div>

              <form onSubmit={handleSubmit} className="flex gap-2">
                <Input
                  placeholder="Type a message to test your agent..."
                  className="bg-secondary/50 border-border"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  disabled={isLoading}
                />
                <Button
                  type="submit"
                  size="icon"
                  className="bg-gradient-primary hover:opacity-90 transition-opacity flex-shrink-0"
                  disabled={isLoading || !inputValue.trim()}
                >
                  {isLoading ? <Clock className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </form>
            </div>

            <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-6 shadow-card">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-accent rounded-lg flex items-center justify-center shadow-glow">
                  <BarChart3 className="w-5 h-5 text-accent-foreground" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Observability</h3>
                  <p className="text-sm text-muted-foreground">Monitor execution</p>
                </div>
              </div>

              <Tabs defaultValue="input" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-secondary/50">
                  <TabsTrigger value="input">Input</TabsTrigger>
                  <TabsTrigger value="output">Output</TabsTrigger>
                  <TabsTrigger value="logs">Logs</TabsTrigger>
                </TabsList>

                <TabsContent value="input" className="space-y-3 mt-4">
                  <div className="bg-secondary/30 border border-border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-mono bg-primary/20 px-2 py-1 rounded text-primary border border-primary/30">
                        T
                      </span>
                      <span className="text-sm font-medium">action</span>
                    </div>
                    <p className="text-sm text-muted-foreground">saveContext</p>
                  </div>
                  <div className="bg-secondary/30 border border-border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-mono bg-primary/20 px-2 py-1 rounded text-primary border border-primary/30">
                        T
                      </span>
                      <span className="text-sm font-medium">input</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {messages.length > 0 && messages[messages.length - 2]?.role === "user"
                        ? messages[messages.length - 2].content
                        : "No input yet"}
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="output" className="space-y-3 mt-4">
                  {messages.length > 0 ? (
                    messages.slice(-2).map((msg) => (
                      <div key={msg.id} className="bg-secondary/30 border border-border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">{msg.role === "user" ? "Human" : "AI"}</span>
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        </div>
                        <p className="text-sm text-muted-foreground">{msg.content}</p>
                      </div>
                    ))
                  ) : (
                    <div className="bg-secondary/30 border border-border rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">No output yet</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="logs" className="space-y-3 mt-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs">
                      <Clock className="w-3 h-3 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        {messages.filter((m) => m.role === "user").length} Messages
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <CheckCircle className="w-3 h-3 text-green-500" />
                      <span className="text-muted-foreground">Agent Active</span>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
