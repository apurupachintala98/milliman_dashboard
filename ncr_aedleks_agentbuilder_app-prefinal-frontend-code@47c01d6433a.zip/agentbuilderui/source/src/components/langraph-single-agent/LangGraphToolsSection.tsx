// "use client"

// import type React from "react"

// import { useState } from "react"
// import { Wrench, Plus, X, ChevronRight, Upload, Code2, Settings } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

// interface Tool {
//   type: string
//   subType?: string
//   name: string
//   description: string
//   url?: string
//   customFile?: File
//   customFileName?: string
//   uploadedFilePath?: string
//   isNormalTool?: boolean
// }

// interface ToolsStepProps {
//   onNext: (data: any) => void
//   initialData?: any
//   defaultConfig?: any
//   isLoadingConfig?: boolean
// }

// export function LangGraphToolsSection({ onNext, initialData, defaultConfig, isLoadingConfig }: ToolsStepProps) {
//   const [savedTools, setSavedTools] = useState<Tool[]>(initialData?.savedTools || [])
//   const [showAddTool, setShowAddTool] = useState(false)
//   const [selectedToolOption, setSelectedToolOption] = useState<"time" | "custom" | null>(null)
//   const [toolType, setToolType] = useState("http")
//   const [toolName, setToolName] = useState("")
//   const [toolDescription, setToolDescription] = useState("")
//   const [toolUrl, setToolUrl] = useState("")
//   const [customFile, setCustomFile] = useState<File | null>(null)
//   const [customFileName, setCustomFileName] = useState("")

//   const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const file = e.target.files?.[0]
//     if (file) {
//       if (!file.name.endsWith(".py")) {
//         alert("Please upload only .py files")
//         e.target.value = ""
//         return
//       }
//       setCustomFileName(file.name)
//       setCustomFile(file)
//     }
//   }

//   const handleAddNormalTool = () => {
//     const transport = defaultConfig?.tool_config?.transport || "stdio"
//     const name = defaultConfig?.tool_config?.name || "default_tool"
//     const description = defaultConfig?.tool_config?.description || "Default tool description"

//     const normalTool: Tool = {
//       type: transport,
//       name: name,
//       description: description,
//       isNormalTool: true,
//       ...(transport === "http" && {
//         url: defaultConfig?.tool_config?.config?.url || "",
//       }),
//       ...(transport === "stdio" && {
//         subType: defaultConfig?.tool_config?.config?.args || "current-time",
//       }),
//     }

//     setSavedTools([...savedTools, normalTool])
//     setShowAddTool(false)
//     setSelectedToolOption(null)
//   }

//   const handleAddCustomTool = () => {
//     if (!toolName || !toolDescription) {
//       alert("Please fill in tool name and description")
//       return
//     }
//     if (toolType === "stdio" && !customFile) {
//       alert("Please upload a .py file for custom tool")
//       return
//     }
//     if (toolType === "http" && !toolUrl.trim()) {
//       alert("Please enter an HTTP URL")
//       return
//     }

//     const newTool: Tool = {
//       type: toolType,
//       name: toolName,
//       description: toolDescription,
//       isNormalTool: false,
//       ...(toolType === "http" && { url: toolUrl }),
//       ...(toolType === "stdio" && {
//         subType: "custom",
//         customFile: customFile!,
//         customFileName: customFileName,
//       }),
//     }

//     setSavedTools([...savedTools, newTool])
//     setToolName("")
//     setToolDescription("")
//     setToolUrl("")
//     setCustomFile(null)
//     setCustomFileName("")
//     setShowAddTool(false)
//     setSelectedToolOption(null)
//   }

//   const handleRemoveTool = (index: number) => {
//     setSavedTools(savedTools.filter((_, i) => i !== index))
//   }

//   const handleCloseAddTool = () => {
//     setShowAddTool(false)
//     setSelectedToolOption(null)
//     setToolName("")
//     setToolDescription("")
//     setToolUrl("")
//     setCustomFile(null)
//     setCustomFileName("")
//   }

//   const handleNext = () => {
//     onNext({ savedTools })
//   }

//   const isCustomToolValid = () => {
//     if (!toolName.trim() || !toolDescription.trim()) {
//       return false
//     }
//     if (toolType === "http" && !toolUrl.trim()) {
//       return false
//     }
//     if (toolType === "stdio" && !customFile) {
//       return false
//     }
//     return true
//   }

//   return (
//     <div className="space-y-8">
//       <div className="text-center">
//         <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500/10 to-amber-500/10 rounded-full mb-4">
//           <Wrench className="w-4 h-4 text-primary" />
//           <span className="text-sm font-medium">Step 3: Agent Tools</span>
//         </div>
//         <h2 className="text-3xl font-bold mb-2">Configure Tools</h2>
//         <p className="text-muted-foreground">Add MCP tools to extend capabilities</p>
//       </div>

//       <div className="space-y-6">
//         {savedTools.length > 0 && (
//           <div className="space-y-3">
//             {savedTools.map((tool, index) => (
//               <div
//                 key={index}
//                 className="flex items-start justify-between p-4 border border-border rounded-lg bg-background/30"
//               >
//                 <div className="flex-1">
//                   <div className="flex items-center gap-2 mb-1">
//                     <Wrench className="w-4 h-4 text-primary" />
//                     <h5 className="font-semibold text-sm">{tool.name}</h5>
//                     <span className="text-xs bg-primary/20 px-2 py-0.5 rounded">
//                       {tool.isNormalTool ? "Default" : tool.type}
//                     </span>
//                   </div>
//                   <p className="text-xs text-muted-foreground">{tool.description}</p>
//                 </div>
//                 <Button
//                   variant="ghost"
//                   size="sm"
//                   onClick={() => handleRemoveTool(index)}
//                   className="text-destructive hover:text-destructive hover:bg-destructive/10"
//                 >
//                   <X className="w-4 h-4" />
//                 </Button>
//               </div>
//             ))}
//           </div>
//         )}

//         {!showAddTool ? (
//           <Button onClick={() => setShowAddTool(true)} variant="outline" className="w-full">
//             <Plus className="w-4 h-4 mr-2" />
//             Add Tool
//           </Button>
//         ) : (
//           <div className="p-6 border-2 border-primary/30 rounded-lg bg-background/50 space-y-4">
//             <div className="flex items-center justify-between">
//               <h3 className="text-lg font-semibold">Add Tool</h3>
//               <Button variant="ghost" size="sm" onClick={handleCloseAddTool}>
//                 <X className="w-4 h-4" />
//               </Button>
//             </div>

//             {!selectedToolOption ? (
//               <div className="grid grid-cols-2 gap-4">
//                 <Button
//                   onClick={handleAddNormalTool}
//                   variant="outline"
//                   className="h-auto p-4 flex flex-col items-start bg-transparent"
//                 >
//                   <Code2 className="w-5 h-5 text-primary mb-2" />
//                   <div className="font-semibold text-sm">Default Time Tool</div>
//                   <p className="text-xs text-muted-foreground text-left">Predefined configuration</p>
//                 </Button>
//                 <Button
//                   onClick={() => setSelectedToolOption("custom")}
//                   variant="outline"
//                   className="h-auto p-4 flex flex-col items-start"
//                 >
//                   <Settings className="w-5 h-5 text-primary mb-2" />
//                   <div className="font-semibold text-sm">Custom Tool</div>
//                   <p className="text-xs text-muted-foreground text-left">Create your own</p>
//                 </Button>
//               </div>
//             ) : (
//               <div className="space-y-4 pt-4 border-t border-border">
//                 <div className="space-y-2">
//                   <Label htmlFor="tool-name" className="text-sm">
//                     Tool Name
//                   </Label>
//                   <Input
//                     id="tool-name"
//                     value={toolName}
//                     onChange={(e) => setToolName(e.target.value)}
//                     className="bg-background/50"
//                   />
//                 </div>
//                 <div className="space-y-2">
//                   <Label htmlFor="tool-description" className="text-sm">
//                     Description
//                   </Label>
//                   <Input
//                     id="tool-description"
//                     value={toolDescription}
//                     onChange={(e) => setToolDescription(e.target.value)}
//                     className="bg-background/50"
//                   />
//                 </div>
//                 <RadioGroup value={toolType} onValueChange={setToolType}>
//                   <div className="space-y-3">
//                     <div className="flex items-center space-x-2">
//                       <RadioGroupItem value="http" id="tool-http" />
//                       <Label htmlFor="tool-http" className="cursor-pointer text-sm">
//                         HTTP
//                       </Label>
//                     </div>
//                     {toolType === "http" && (
//                       <div className="ml-6 space-y-2">
//                         <Input
//                           placeholder="https://..."
//                           value={toolUrl}
//                           onChange={(e) => setToolUrl(e.target.value)}
//                           className="bg-background/50"
//                         />
//                       </div>
//                     )}
//                     <div className="flex items-center space-x-2">
//                       <RadioGroupItem value="stdio" id="tool-stdio" />
//                       <Label htmlFor="tool-stdio" className="cursor-pointer text-sm">
//                         Stdio (.py file)
//                       </Label>
//                     </div>
//                     {toolType === "stdio" && (
//                       <div className="ml-6 space-y-2">
//                         <Input
//                           type="file"
//                           accept=".py"
//                           onChange={handleFileUpload}
//                           className="bg-background/50 cursor-pointer"
//                         />
//                         {customFileName && (
//                           <div className="flex items-center gap-2 text-xs text-muted-foreground">
//                             <Upload className="w-3 h-3 text-primary" />
//                             <span>{customFileName}</span>
//                           </div>
//                         )}
//                       </div>
//                     )}
//                   </div>
//                 </RadioGroup>
//                 <Button
//                   onClick={handleAddCustomTool}
//                   className="bg-gradient-to-r from-orange-500 to-amber-600 hover:opacity-90"
//                   size="sm"
//                   disabled={!isCustomToolValid()}
//                 >
//                   Add Custom Tool
//                 </Button>
//               </div>
//             )}
//           </div>
//         )}
//       </div>

//       <div className="flex justify-end pt-6">
//         <Button
//           onClick={handleNext}
//           size="lg"
//           className="bg-gradient-to-r from-orange-500 to-amber-600 hover:opacity-90"
//           disabled={selectedToolOption !== "custom" && savedTools.length === 0}
//         >
//           Next Step
//           <ChevronRight className="w-4 h-4 ml-2" />
//         </Button>
//       </div>
//     </div>
//   )
// }

"use client"

import type React from "react"

import { useState } from "react"
import { Wrench, Plus, X, ChevronRight, Upload, Code2, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface Tool {
  type: string
  subType?: string
  name: string
  description: string
  url?: string
  customFile?: File
  customFileName?: string
  uploadedFilePath?: string
  isNormalTool?: boolean
}

interface ToolsStepProps {
  onNext: (data: any) => void
  initialData?: any
  defaultConfig?: any
  isLoadingConfig?: boolean
}

export function LangGraphToolsSection({ onNext, initialData, defaultConfig, isLoadingConfig }: ToolsStepProps) {
  const [savedTools, setSavedTools] = useState<Tool[]>(initialData?.savedTools || [])
  const [showAddTool, setShowAddTool] = useState(false)
  const [selectedToolOption, setSelectedToolOption] = useState<"time" | "custom" | null>(null)
  const [toolType, setToolType] = useState("http")
  const [toolName, setToolName] = useState("")
  const [toolDescription, setToolDescription] = useState("")
  const [toolUrl, setToolUrl] = useState("")
  const [customFile, setCustomFile] = useState<File | null>(null)
  const [customFileName, setCustomFileName] = useState("")

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (!file.name.endsWith(".py")) {
        alert("Please upload only .py files")
        e.target.value = ""
        return
      }
      setCustomFileName(file.name)
      setCustomFile(file)
    }
  }

  const handleAddNormalTool = () => {
    const transport = defaultConfig?.tool_config?.transport || "stdio"
    const name = defaultConfig?.tool_config?.name || "default_tool"
    const description = defaultConfig?.tool_config?.description || "Default tool description"

    const normalTool: Tool = {
      type: transport,
      name: name,
      description: description,
      isNormalTool: true,
      ...(transport === "http" && {
        url: defaultConfig?.tool_config?.config?.url || "",
      }),
      ...(transport === "stdio" && {
        subType: defaultConfig?.tool_config?.config?.args || "current-time",
      }),
    }

    setSavedTools([...savedTools, normalTool])
    setShowAddTool(false)
    setSelectedToolOption(null)
  }

  const handleAddCustomTool = () => {
    if (!toolName || !toolDescription) {
      alert("Please fill in tool name and description")
      return
    }
    if (toolType === "stdio" && !customFile) {
      alert("Please upload a .py file for custom tool")
      return
    }
    if (toolType === "http" && !toolUrl.trim()) {
      alert("Please enter an HTTP URL")
      return
    }

    const newTool: Tool = {
      type: toolType,
      name: toolName,
      description: toolDescription,
      isNormalTool: false,
      ...(toolType === "http" && { url: toolUrl }),
      ...(toolType === "stdio" && {
        subType: "custom",
        customFile: customFile!,
        customFileName: customFileName,
      }),
    }

    setSavedTools([...savedTools, newTool])
    setToolName("")
    setToolDescription("")
    setToolUrl("")
    setCustomFile(null)
    setCustomFileName("")
    setShowAddTool(false)
    setSelectedToolOption(null)
  }

  const handleRemoveTool = (index: number) => {
    setSavedTools(savedTools.filter((_, i) => i !== index))
  }

  const handleCloseAddTool = () => {
    setShowAddTool(false)
    setSelectedToolOption(null)
    setToolName("")
    setToolDescription("")
    setToolUrl("")
    setCustomFile(null)
    setCustomFileName("")
  }

  const handleNext = () => {
    onNext({ savedTools })
  }

  const isCustomToolValid = () => {
    if (!toolName.trim() || !toolDescription.trim()) {
      return false
    }
    if (toolType === "http" && !toolUrl.trim()) {
      return false
    }
    if (toolType === "stdio" && !customFile) {
      return false
    }
    return true
  }

  
  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500/10 to-amber-500/10 rounded-full mb-4">
          <Wrench className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Step 3: Agent Tools</span>
        </div>
        <h2 className="text-3xl font-bold mb-2">Configure Tools</h2>
        <p className="text-muted-foreground">Add MCP tools to extend capabilities</p>
      </div>

      <div className="space-y-6">
        {savedTools.length > 0 && (
          <div className="space-y-3">
            {savedTools.map((tool, index) => (
              <div
                key={index}
                className="flex items-start justify-between p-4 border border-border rounded-lg bg-background/30"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Wrench className="w-4 h-4 text-primary" />
                    <h5 className="font-semibold text-sm">{tool.name}</h5>
                    <span className="text-xs bg-primary/20 px-2 py-0.5 rounded">
                      {tool.isNormalTool ? "Default" : tool.type}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{tool.description}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemoveTool(index)}
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {!showAddTool ? (
          <Button onClick={() => setShowAddTool(true)} variant="outline" className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Add Tool
          </Button>
        ) : (
          <div className="p-6 border-2 border-primary/30 rounded-lg bg-background/50 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Add Tool</h3>
              <Button variant="ghost" size="sm" onClick={handleCloseAddTool}>
                <X className="w-4 h-4" />
              </Button>
            </div>

            {!selectedToolOption ? (
              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={handleAddNormalTool}
                  variant="outline"
                  className="h-auto p-4 flex flex-col items-start bg-transparent"
                >
                  <Code2 className="w-5 h-5 text-primary mb-2" />
                  <div className="font-semibold text-sm">Default Time Tool</div>
                  <p className="text-xs text-muted-foreground text-left">Predefined configuration</p>
                </Button>
                <Button
                  onClick={() => setSelectedToolOption("custom")}
                  variant="outline"
                  className="h-auto p-4 flex flex-col items-start"
                >
                  <Settings className="w-5 h-5 text-primary mb-2" />
                  <div className="font-semibold text-sm">Custom Tool</div>
                  <p className="text-xs text-muted-foreground text-left">Create your own</p>
                </Button>
              </div>
            ) : (
              <div className="space-y-4 pt-4 border-t border-border">
                <div className="space-y-2">
                  <Label htmlFor="tool-name" className="text-sm">
                    Tool Name
                  </Label>
                  <Input
                    id="tool-name"
                    value={toolName}
                    onChange={(e) => setToolName(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tool-description" className="text-sm">
                    Description
                  </Label>
                  <Input
                    id="tool-description"
                    value={toolDescription}
                    onChange={(e) => setToolDescription(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <RadioGroup value={toolType} onValueChange={setToolType}>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="http" id="tool-http" />
                      <Label htmlFor="tool-http" className="cursor-pointer text-sm">
                        HTTP
                      </Label>
                    </div>
                    {toolType === "http" && (
                      <div className="ml-6 space-y-2">
                        <Input
                          placeholder="https://..."
                          value={toolUrl}
                          onChange={(e) => setToolUrl(e.target.value)}
                          className="bg-background/50"
                        />
                      </div>
                    )}
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="stdio" id="tool-stdio" />
                      <Label htmlFor="tool-stdio" className="cursor-pointer text-sm">
                        Stdio (.py file)
                      </Label>
                    </div>
                    {toolType === "stdio" && (
                      <div className="ml-6 space-y-2">
                        <Input
                          type="file"
                          accept=".py"
                          onChange={handleFileUpload}
                          className="bg-background/50 cursor-pointer"
                        />
                        {customFileName && (
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Upload className="w-3 h-3 text-primary" />
                            <span>{customFileName}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </RadioGroup>
                <Button
                  onClick={handleAddCustomTool}
                  className="bg-gradient-to-r from-orange-500 to-amber-600 hover:opacity-90"
                  size="sm"
                  disabled={!isCustomToolValid()}
                >
                  Add Custom Tool
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex justify-end pt-6">
        <Button
          onClick={handleNext}
          size="lg"
          className="bg-gradient-to-r from-orange-500 to-amber-600 hover:opacity-90"
          disabled={savedTools.length === 0 || selectedToolOption === "custom"}
        >
          Next Step
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  )
}
