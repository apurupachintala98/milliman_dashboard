"use client"

import { useState, useEffect } from "react"
import { Database, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface DatabaseStepProps {
  onNext: (data: any) => void
  initialData?: any
  defaultConfig?: any
  isLoadingConfig?: boolean
}

export function LangGraphDatabaseSection({ onNext, initialData, defaultConfig, isLoadingConfig }: DatabaseStepProps) {
  const [enableThreadMemory, setEnableThreadMemory] = useState(initialData?.enableThreadMemory || false)
  const [enableLongTermMemory, setEnableLongTermMemory] = useState(initialData?.enableLongTermMemory || false)
  const [userProfile, setUserProfile] = useState(initialData?.userProfile || false)
  const [userExperience, setUserExperience] = useState(initialData?.userExperience || false)
  const [userInstruction, setUserInstruction] = useState(initialData?.userInstruction || false)
  const [customSchema, setCustomSchema] = useState(initialData?.customSchema || false)
  const [databaseType, setDatabaseType] = useState<"default" | "custom">(initialData?.databaseType || "default")
  const [host, setHost] = useState(initialData?.host || "")
  const [port, setPort] = useState(initialData?.port || "")
  const [databaseName, setDatabaseName] = useState(initialData?.databaseName || "")
  const [schemaName, setSchemaName] = useState(initialData?.schemaName || "")
  const [username, setUsername] = useState(initialData?.username || "")
  const [password, setPassword] = useState(initialData?.password || "")

  const [defaultDbValues, setDefaultDbValues] = useState({
    host: "",
    port: "",
    databaseName: "",
    schemaName: "",
    username: "",
  })

  useEffect(() => {
    if (defaultConfig?.memory_config) {
      const { memory_config } = defaultConfig
      setEnableThreadMemory(memory_config.short_term_memory_needed || false)
      setEnableLongTermMemory(memory_config.long_term_memory_needed || false)
      if (memory_config.long_term_memory_config) {
        setUserProfile(memory_config.long_term_memory_config.semantic_user_profile || false)
        setUserExperience(memory_config.long_term_memory_config.episodic_user_experience || false)
        setUserInstruction(memory_config.long_term_memory_config.procedural_user_instructions || false)
        setCustomSchema(memory_config.long_term_memory_config.custom || false)
      }
      const dbDefaults = {
        host: memory_config.db_host || "",
        port: memory_config.db_port?.toString() || "",
        databaseName: memory_config.db_name || "",
        schemaName: memory_config.db_schema || "",
        username: memory_config.db_username || "",
      }
      setDefaultDbValues(dbDefaults)
      if (databaseType === "default") {
        setHost(dbDefaults.host)
        setPort(dbDefaults.port)
        setDatabaseName(dbDefaults.databaseName)
        setSchemaName(dbDefaults.schemaName)
        setUsername(dbDefaults.username)
      }
    }
  }, [defaultConfig, databaseType])

  const handleDatabaseTypeChange = (value: "default" | "custom") => {
    setDatabaseType(value)
    if (value === "default") {
      setHost(defaultDbValues.host)
      setPort(defaultDbValues.port)
      setDatabaseName(defaultDbValues.databaseName)
      setSchemaName(defaultDbValues.schemaName)
      setUsername(defaultDbValues.username)
    } else {
      setHost("")
      setPort("")
      setDatabaseName("")
      setSchemaName("")
      setUsername("")
      setPassword("")
    }
  }

  const handleNext = () => {
    const memoryEnabled = enableThreadMemory || enableLongTermMemory
    if (memoryEnabled) {
      if (databaseType === "custom" && (!host || !databaseName || !schemaName || !username || !password)) {
        alert("Please fill in all required database configuration fields")
        return
      }
    }

    const finalDefaultPassword = databaseType === "default" ? "85FC7ou6d(qB]jKl" : password


    onNext({
      enableThreadMemory,
      enableLongTermMemory,
      userProfile,
      userExperience,
      userInstruction,
      customSchema,
      databaseType,
      host,
      port,
      databaseName,
      schemaName,
      username,
      password: finalDefaultPassword,
    })
  }

  const showDatabaseConfig = enableThreadMemory || enableLongTermMemory

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500/10 to-teal-500/10 rounded-full mb-4">
          <Database className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Step 2: Memory Configuration</span>
        </div>
        <h2 className="text-3xl font-bold mb-2">Configure Memory</h2>
        <p className="text-muted-foreground">Set up memory and database configuration</p>
      </div>

      <div className="space-y-6">
        <div className="space-y-4 p-4 border border-border rounded-lg bg-background/30">
          <Label className="text-base font-semibold">Memory Options</Label>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Checkbox
                id="thread-memory"
                checked={enableThreadMemory}
                onCheckedChange={(checked) => setEnableThreadMemory(checked as boolean)}
              />
              <Label htmlFor="thread-memory" className="cursor-pointer">
                Enable Thread Memory
              </Label>
            </div>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="long-term-memory"
                  checked={enableLongTermMemory}
                  onCheckedChange={(checked) => setEnableLongTermMemory(checked as boolean)}
                />
                <Label htmlFor="long-term-memory" className="cursor-pointer">
                  Enable Long Term Memory
                </Label>
              </div>
              {enableLongTermMemory && (
                <div className="ml-8 pl-4 border-l-2 border-primary/30 space-y-2">
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="user-profile"
                      checked={userProfile}
                      onCheckedChange={(checked) => setUserProfile(checked as boolean)}
                    />
                    <Label htmlFor="user-profile" className="cursor-pointer text-sm">
                      User Profile (Semantic Memory)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="user-experience"
                      checked={userExperience}
                      onCheckedChange={(checked) => setUserExperience(checked as boolean)}
                    />
                    <Label htmlFor="user-experience" className="cursor-pointer text-sm">
                      User Experience (Episodic Memory)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="user-instruction"
                      checked={userInstruction}
                      onCheckedChange={(checked) => setUserInstruction(checked as boolean)}
                    />
                    <Label htmlFor="user-instruction" className="cursor-pointer text-sm">
                      User Instruction (Procedural Memory)
                    </Label>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {showDatabaseConfig && (
          <div className="space-y-4 p-4 border border-border rounded-lg bg-background/30">
            <Label className="text-base font-semibold">Memory Database Configuration (Postgres)</Label>
            <RadioGroup
              value={databaseType}
              onValueChange={(value) => handleDatabaseTypeChange(value as "default" | "custom")}
            >
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="default" id="default-db" />
                <Label htmlFor="default-db" className="cursor-pointer text-sm">
                  Default Database
                </Label>
              </div>
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="custom" id="custom-db" />
                <Label htmlFor="custom-db" className="cursor-pointer text-sm">
                  Custom Database
                </Label>
              </div>
            </RadioGroup>

            {databaseType === "custom" && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="host" className="text-sm">
                    Host *
                  </Label>
                  <Input
                    id="host"
                    placeholder="localhost"
                    value={host}
                    onChange={(e) => setHost(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="port" className="text-sm">
                    Port *
                  </Label>
                  <Input
                    id="port"
                    placeholder="5432"
                    value={port}
                    onChange={(e) => setPort(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="database-name" className="text-sm">
                    Database Name *
                  </Label>
                  <Input
                    id="database-name"
                    placeholder="mydb"
                    value={databaseName}
                    onChange={(e) => setDatabaseName(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="schema-name" className="text-sm">
                    Schema Name *
                  </Label>
                  <Input
                    id="schema-name"
                    placeholder="public"
                    value={schemaName}
                    onChange={(e) => setSchemaName(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-sm">
                    Username *
                  </Label>
                  <Input
                    id="username"
                    placeholder="postgres"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm">
                    Password *
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-background/50"
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex justify-end pt-6">
        <Button onClick={handleNext} size="lg" className="bg-gradient-to-r from-green-500 to-teal-600 hover:opacity-90">
          Next Step
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  )
}