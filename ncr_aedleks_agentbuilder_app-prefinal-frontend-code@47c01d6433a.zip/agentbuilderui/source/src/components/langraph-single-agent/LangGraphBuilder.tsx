"use client"

import { useState, useEffect } from "react"
import { Check, ArrowLeft } from "lucide-react"
import { cn } from "@/lib/utils"
import { LangGraphProfileSection } from "../langraph-single-agent/LangGraphProfileSection"
import { LangGraphDatabaseSection } from "../langraph-single-agent/LangGraphDatabaseSection"
import { LangGraphToolsSection } from "../langraph-single-agent/LangGraphToolsSection"
import { LangGraphApiSection } from "../langraph-single-agent/LangGraphApiSection"
import { LangGraphUiSection } from "../langraph-single-agent/LangGraphUiSection"
import { LangGraphDeploySection } from "../langraph-single-agent/LangGraphDeploySection"
import { LangGraphTestSection } from "../langraph-single-agent/LangGraphTestSection"
import { useNavigate } from "react-router-dom"

import { langgraphApi } from "@/services/langgraph-api"

const STEPS = [
  { id: 1, name: "Profile", description: "Agent basics" },
  { id: 2, name: "Memory", description: "Database config" },
  { id: 3, name: "Tools", description: "Agent capabilities" },
  { id: 4, name: "API", description: "Backend setup" },
  { id: 5, name: "UI", description: "Frontend config" },
  { id: 6, name: "Deploy", description: "Download & test" },
]

function generateUUID(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === "x" ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

export default function LangGraphBuilder() {
  const router = useNavigate()
  const [currentStep, setCurrentStep] = useState(1)
  const [completedSteps, setCompletedSteps] = useState<number[]>([])
  const [wizardData, setWizardData] = useState<any>({})
  const [isSaving, setIsSaving] = useState(false)
  const [allConfigsSaved, setAllConfigsSaved] = useState(false)
  const [deployUrl, setDeployUrl] = useState<string | null>(null)
  const [defaultConfig, setDefaultConfig] = useState<any>(null)
  const [isLoadingConfig, setIsLoadingConfig] = useState(true)
  const [hasLoadedConfig, setHasLoadedConfig] = useState(false)
  const [currentUiData, setCurrentUiData] = useState<any>(null)
  const [apiConfig, setApiConfig] = useState<{ hostname: string; apiPort: string } | null>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    setTimeout(() => {
      window.scrollTo(0, 0)
    }, 0)
  }, [])

  useEffect(() => {
    if (hasLoadedConfig) return

    const loadDefaultConfig = async () => {
      setHasLoadedConfig(true)
      try {
        const config = await langgraphApi.getDefaultConfig()
        setDefaultConfig(config)
      } catch (error) {
        console.error("Failed to load default config:", error)
      } finally {
        setIsLoadingConfig(false)
      }
    }

    loadDefaultConfig()
    window.scrollTo(0, 0)
  }, [hasLoadedConfig])

  const handleNext = (stepData: any) => {
    setWizardData((prev: any) => ({ ...prev, [currentStep]: stepData }))
    if (currentStep === 5) {
      setCurrentUiData(stepData)
    }
    if (currentStep === 4) {
      setApiConfig({ hostname: stepData.hostname, apiPort: stepData.apiPort })
    }
    if (!completedSteps.includes(currentStep)) {
      setCompletedSteps([...completedSteps, currentStep])
    }
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1)
      window.scrollTo({ top: 0, behavior: "instant" })
    }
  }

  const handleStepClick = (stepId: number) => {
    if (stepId === 6 || completedSteps.includes(stepId - 1) || stepId === 1) {
      setCurrentStep(stepId)
      window.scrollTo({ top: 0, behavior: "instant" })
    }
  }

  const handleSaveAndContinue = async (uiData?: any) => {
    console.log("ui data", uiData)
    setIsSaving(true)
    try {
      const profileData = wizardData[1]
      if (!profileData) {
        alert("Please complete the Profile step first")
        setIsSaving(false)
        return
      }

      const storedProviderId = localStorage.getItem("snowflake_provider_id")
      const profilePayload = {
        agent_name: profileData.agentName,
        agent_description: profileData.description,
        agent_instructions: {
          system: profileData.systemInstructions,
          orchestration: profileData.orchestrationInstructions,
          response_structure: profileData.responseInstructions,
        },
        llm_config: {
          model_id: profileData.aiModel,
          model_name: profileData.aiModelName,
          provider_name: storedProviderId,
          llm_auth: {
            base_url: profileData.baseUrl,
            pat_token: profileData.pat,
          },
          llm_model_config: {
            temperature: 0.1,
            max_tokens: 1024,
          },
        },
      }

      const agentResponse = await langgraphApi.createAgent(profilePayload)
      const agentUuid = agentResponse.agent_uuid
      localStorage.setItem("langgraph_agent_uuid", agentUuid)
      localStorage.setItem("langgraph_profile_saved", "true")

      const appUuid = generateUUID()
      const userUuid = generateUUID()
      localStorage.setItem("langgraph_app_uuid", appUuid)
      localStorage.setItem("langgraph_user_uuid", userUuid)

      const memoryData = wizardData[2]
      if (memoryData && (memoryData.enableThreadMemory || memoryData.enableLongTermMemory)) {
        const memoryPayload = {
          short_term_memory_needed: memoryData.enableThreadMemory,
          long_term_memory_needed: memoryData.enableLongTermMemory,
          long_term_memory_config: {
            semantic_user_profile: memoryData.userProfile,
            episodic_user_experience: memoryData.userExperience,
            procedural_user_instructions: memoryData.userInstruction,
            custom: memoryData.customSchema,
          },
          db_type: "postgres",
          db_host: memoryData.host,
          db_port: Number.parseInt(memoryData.port) || 5432,
          db_username: memoryData.username,
          db_password: memoryData.password,
          db_name: memoryData.databaseName,
          db_schema: memoryData.schemaName,
        }
        await langgraphApi.configureMemory(agentUuid, memoryPayload)
      }

      const toolsData = wizardData[3]
      const savedTools = toolsData?.savedTools || []

      let mcpTools: any[] = []

      if (savedTools.length > 0) {
        const toolsWithPaths = await Promise.all(
          savedTools.map(async (tool: any) => {
            if (tool.type === "stdio" && tool.subType === "custom" && tool.customFile) {
              const uploadResponse = await langgraphApi.uploadToolFile(agentUuid, tool.customFile)
              return { ...tool, uploadedFilePath: uploadResponse.destination_path }
            }
            return tool
          }),
        )

        mcpTools = toolsWithPaths.map((tool: any) => {
          if (tool.type === "http" || tool.type === "streamable_http") {
            return {
              transport: "streamable_http",
              name: tool.name,
              description: tool.description,
              config: {
                url: tool.url || "",
                config: "",
              },
            }
          } else {
            if (tool.isNormalTool) {
              return {
                transport: "stdio",
                name: tool.name,
                description: tool.description,
                config: {
                  command: defaultConfig?.tool_config?.config?.command || "python",
                  args: tool.subType || defaultConfig?.tool_config?.config?.args || "current-time",
                },
              }
            } else if (tool.subType === "custom" && tool.uploadedFilePath) {
              return {
                transport: "stdio",
                name: tool.name,
                description: tool.description,
                config: {
                  command: "python",
                  args: tool.uploadedFilePath,
                },
              }
            } else {
              return {
                transport: "stdio",
                name: tool.name,
                description: tool.description,
                config: {
                  command: "python",
                  args: tool.subType || "current-time",
                },
              }
            }
          }
        })
      }

      await langgraphApi.configureTools(agentUuid, { mcp_tools: mcpTools })

      const apiData = wizardData[4]
      if (apiData && apiData.includeApi) {
        const apiPayload = {
          host: apiData.hostname,
          port: Number.parseInt(apiData.apiPort),
        }
        await langgraphApi.configureBackend(agentUuid, apiPayload)
      }

      const finalUiData = uiData || currentUiData || wizardData[5]
      console.log("[v0] Wizard - Checking UI data (passed, state, or wizardData):", finalUiData)
      if (finalUiData && finalUiData.includeUi) {
        console.log("[v0] Wizard - Configuring frontend with port:", finalUiData.uiPort)
        const uiPayload = {
          port: Number.parseInt(finalUiData.uiPort),
        }
        await langgraphApi.configureFrontend(agentUuid, uiPayload)
        console.log("[v0] Wizard - Frontend configured successfully")
      } else {
        console.log("[v0] Wizard - Skipping frontend configuration (includeUi:", finalUiData?.includeUi, ")")
      }

      setAllConfigsSaved(true)
      setCurrentStep(6)
      window.scrollTo({ top: 0, behavior: "instant" })
    } catch (error) {
      console.error("Failed to save configurations:", error)
      alert("Failed to save configurations. Please check your inputs and try again.")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="sticky top-16 z-40 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 py-4">
          <div className="max-w-5xl mx-auto mb-3">
            <button
              onClick={() => router("/dashboard")}
              className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors group"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              Back to Dashboard
            </button>
          </div>
          <div className="flex items-center justify-between max-w-5xl mx-auto gap-1 sm:gap-2">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center flex-1 min-w-0">
                <button
                  onClick={() => handleStepClick(step.id)}
                  disabled={step.id !== 6 && !completedSteps.includes(step.id - 1) && step.id !== 1}
                  className={cn(
                    "group flex flex-col items-center gap-1.5 transition-all min-w-0",
                    step.id === currentStep && "scale-105",
                    (step.id === 6 || (step.id !== 6 && (completedSteps.includes(step.id - 1) || step.id === 1))) &&
                      "cursor-pointer",
                    step.id !== 6 &&
                      !completedSteps.includes(step.id - 1) &&
                      step.id !== 1 &&
                      "cursor-not-allowed opacity-40",
                  )}
                >
                  <div
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center font-semibold text-xs transition-all",
                      step.id === currentStep &&
                        "bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg shadow-primary/50",
                      completedSteps.includes(step.id) && step.id !== currentStep && "bg-green-500 text-white",
                      !completedSteps.includes(step.id) && step.id !== currentStep && "bg-muted text-muted-foreground",
                    )}
                  >
                    {completedSteps.includes(step.id) && step.id !== currentStep ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      step.id
                    )}
                  </div>
                  <div className="text-center hidden sm:block min-w-0">
                    <div className={cn("text-xs font-medium", step.id === currentStep && "text-primary")}>
                      {step.name}
                    </div>
                    <div className="text-xs text-muted-foreground">{step.description}</div>
                  </div>
                </button>
                {index < STEPS.length - 1 && (
                  <div
                    className={cn(
                      "flex-1 h-0.5 mx-2 transition-all min-w-[8px]",
                      completedSteps.includes(step.id) ? "bg-green-500" : "bg-border",
                    )}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 pt-32 pb-12">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card/60 backdrop-blur-xl border border-border rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-8 sm:p-12">
              {currentStep === 1 && (
                <LangGraphProfileSection
                  onNext={handleNext}
                  initialData={wizardData[1]}
                  defaultConfig={defaultConfig}
                  isLoadingConfig={isLoadingConfig}
                />
              )}
              {currentStep === 2 && (
                <LangGraphDatabaseSection
                  onNext={handleNext}
                  initialData={wizardData[2]}
                  defaultConfig={defaultConfig}
                  isLoadingConfig={isLoadingConfig}
                />
              )}
              {currentStep === 3 && (
                <LangGraphToolsSection
                  onNext={handleNext}
                  initialData={wizardData[3]}
                  defaultConfig={defaultConfig}
                  isLoadingConfig={isLoadingConfig}
                />
              )}
              {currentStep === 4 && (
                <LangGraphApiSection
                  onNext={handleNext}
                  initialData={wizardData[4]}
                  defaultConfig={defaultConfig}
                  isLoadingConfig={isLoadingConfig}
                />
              )}
              {currentStep === 5 && (
                <LangGraphUiSection
                  onNext={handleNext}
                  onSaveAll={handleSaveAndContinue}
                  isSaving={isSaving}
                  initialData={wizardData[5]}
                  uiData={currentUiData}
                  defaultConfig={defaultConfig}
                  isLoadingConfig={isLoadingConfig}
                />
              )}
              {currentStep === 6 && (
                <>
                  <LangGraphDeploySection
                    wizardData={wizardData}
                    deployUrl={deployUrl}
                    onDeployed={(url) => setDeployUrl(url)}
                  />
                   <LangGraphTestSection agentName={wizardData[1]?.agentName || ""} />
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
