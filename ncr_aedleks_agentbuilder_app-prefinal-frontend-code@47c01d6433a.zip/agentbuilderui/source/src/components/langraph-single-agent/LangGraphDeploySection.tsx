// "use client"
 
// import type React from "react"
 
// import { useState, useEffect } from "react"
// import { Download, Play, Send } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { langgraphApi } from "@/services/langgraph-api"
 
// interface DeployStepProps {
//   wizardData: any
//   deployUrl?: string | null
//   onDeployed?: (url: string) => void
// }
 
// interface Message {
//   id: string
//   type: "user" | "assistant"
//   content: string
//   thinking?: string
//   isStreaming?: boolean
// }
 
// export function LangGraphDeploySection({ wizardData, deployUrl, onDeployed }: DeployStepProps) {
//   const [isDownloading, setIsDownloading] = useState(false)
//   const [messages, setMessages] = useState<Message[]>([])
//   const [inputValue, setInputValue] = useState("")
//   const [isLoading, setIsLoading] = useState(false)
//   const [detailsOpen, setDetailsOpen] = useState<Record<string, boolean>>({})
//   const [apiUrl, setApiUrl] = useState("")
//   const [bearerToken, setBearerToken] = useState("")
//   const [errorNotification, setErrorNotification] = useState<string | null>(null)
 
//   useEffect(() => {
//     if (deployUrl) {
//       setApiUrl(deployUrl)
//     }
//   }, [deployUrl])
 
//   const handleDownloadCode = async () => {
//     const agentUuid = localStorage.getItem("langgraph_agent_uuid")
//     const configsSaved = localStorage.getItem("langgraph_profile_saved")
 
//     if (!agentUuid || !configsSaved) {
//       alert("Please complete and save all configuration steps before downloading.")
//       return
//     }
 
//     setIsDownloading(true)
//     try {
//       const blob = await langgraphApi.downloadAgent(agentUuid)
//       const url = window.URL.createObjectURL(blob)
//       const a = document.createElement("a")
//       a.href = url
//       a.download = `langgraph-agent-${agentUuid}.zip`
//       document.body.appendChild(a)
//       a.click()
//       window.URL.revokeObjectURL(url)
//       document.body.removeChild(a)
//     } catch (error) {
//       console.error("Failed to download agent:", error)
//       alert("Failed to download agent code. Please try again.")
//     } finally {
//       setIsDownloading(false)
//     }
//   }
 
//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!inputValue.trim() || isLoading) return
 
//     const userMessage: Message = {
//       id: `user-${Date.now()}`,
//       type: "user",
//       content: inputValue.trim(),
//     }
 
//     setMessages((prev) => [...prev, userMessage])
 
//     const assistantMessage: Message = {
//       id: `assistant-${Date.now()}`,
//       type: "assistant",
//       content: "",
//       thinking: "",
//       isStreaming: true,
//     }
 
//     setMessages((prev) => [...prev, assistantMessage])
//     setInputValue("")
//     setIsLoading(true)
 
//     try {
//       await streamResponse(assistantMessage.id, userMessage.content)
//     } catch (error) {
//       console.error("Streaming error:", error)
//       const errorMessage = error instanceof Error ? error.message : "Unknown error occurred"
//       setErrorNotification(errorMessage)
//       setMessages((prev) =>
//         prev.map((msg) =>
//           msg.id === assistantMessage.id
//             ? { ...msg, content: "Error occurred while processing your request.", isStreaming: false }
//             : msg,
//         ),
//       )
//     } finally {
//       setIsLoading(false)
//     }
//   }
 
//   const streamResponse = async (messageId: string, userInput: string) => {
//     const endpoint = apiUrl.trim()
//     const applicationName = localStorage.getItem("application_name") || "langgraph_agent"
//     const userIdentity = localStorage.getItem("user_id") || "user_001"
 
//     const payload = {
//       application_name: applicationName,
//       user_identity: userIdentity,
//       messages: [{ role: "user", content: [{ type: "text", text: userInput }] }],
//     }
 
//     const headers: Record<string, string> = { "Content-Type": "application/json" }
//     if (bearerToken.trim()) {
//       headers["Authorization"] = `Bearer ${bearerToken.trim()}`
//     }
 
//     const response = await fetch(endpoint, {
//       method: "POST",
//       headers,
//       body: JSON.stringify(payload),
//     })
 
//     if (!response.ok) {
//       const errorData = await response.text()
//       throw new Error(`HTTP ${response.status}: ${errorData || response.statusText}`)
//     }
 
//     if (!response.body) throw new Error("No response body")
 
//     const reader = response.body.getReader()
//     const decoder = new TextDecoder()
//     let buffer = ""
//     let streamingText = ""
 
//     while (true) {
//       const { done, value } = await reader.read()
//       if (done) break
 
//       buffer += decoder.decode(value, { stream: true })
//       const lines = buffer.split("\n")
//       buffer = lines.pop() || ""
 
//       for (const line of lines) {
//         const trimmedLine = line.trim()
//         if (!trimmedLine) continue
 
//         if (trimmedLine.startsWith("data:")) {
//           try {
//             const jsonStr = trimmedLine.substring(5).trim()
//             const data = JSON.parse(jsonStr)
//             if (data.text) {
//               streamingText += data.text
//               setMessages((prev) =>
//                 prev.map((msg) => (msg.id === messageId ? { ...msg, content: streamingText } : msg)),
//               )
//             }
//           } catch (e) {
//             // Ignore parse errors
//           }
//         }
//       }
//     }
 
//     setMessages((prev) => prev.map((msg) => (msg.id === messageId ? { ...msg, isStreaming: false } : msg)))
//   }
 
//   const toggleDetails = (messageId: string) => {
//     setDetailsOpen((prev) => ({ ...prev, [messageId]: !prev[messageId] }))
//   }
 
//   return (
//     <div className="space-y-8">
//       <div className="text-center">
//         <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-full mb-4">
//           <Play className="w-4 h-4 text-primary" />
//           <span className="text-sm font-medium">Step 6: Deploy & Test</span>
//         </div>
//         <h2 className="text-3xl font-bold mb-2">Deploy Your Agent</h2>
//         <p className="text-muted-foreground">Download and test your agent</p>
//       </div>
 
//       <div className="space-y-6">
//         {/* Download Section */}
//         <div className="p-6 border border-border rounded-lg bg-gradient-to-br from-primary/5 to-transparent text-center">
//           <h3 className="text-xl font-bold mb-2">Ready to Deploy</h3>
//           <p className="text-sm text-muted-foreground mb-4">
//             Download your agent configuration and deploy it to your infrastructure
//           </p>
//           <Button
//             onClick={handleDownloadCode}
//             disabled={isDownloading}
//             size="lg"
//             className="bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90"
//           >
//             <Download className="w-4 h-4 mr-2" />
//             {isDownloading ? "Downloading..." : "Download Code"}
//           </Button>
//         </div>
//       </div>
//     </div>
//   )
// }
 
"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Download, Play, Rocket } from "lucide-react"
import { Button } from "@/components/ui/button"
import { langgraphApi } from "@/services/langgraph-api"

interface DeployStepProps {
  wizardData: any
  deployUrl?: string | null
  onDeployed?: (url: string) => void
}

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  thinking?: string
  isStreaming?: boolean
}

export function LangGraphDeploySection({ wizardData, deployUrl, onDeployed }: DeployStepProps) {
  const [isDownloading, setIsDownloading] = useState(false)
  const [isDeploying, setIsDeploying] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [detailsOpen, setDetailsOpen] = useState<Record<string, boolean>>({})
  const [apiUrl, setApiUrl] = useState("")
  const [bearerToken, setBearerToken] = useState("")
  const [errorNotification, setErrorNotification] = useState<string | null>(null)

  useEffect(() => {
    if (deployUrl) {
      setApiUrl(deployUrl)
    }
  }, [deployUrl])

  const handleDownloadCode = async () => {
    const agentUuid = localStorage.getItem("langgraph_agent_uuid")
    const configsSaved = localStorage.getItem("langgraph_profile_saved")

    if (!agentUuid || !configsSaved) {
      alert("Please complete and save all configuration steps before downloading.")
      return
    }

    setIsDownloading(true)
    try {
      const blob = await langgraphApi.downloadAgent(agentUuid)
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `langgraph-agent-${agentUuid}.zip`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("Failed to download agent:", error)
      alert("Failed to download agent code. Please try again.")
    } finally {
      setIsDownloading(false)
    }
  }

  const handleDeploy = async () => {
    const agentUuid = localStorage.getItem("langgraph_agent_uuid")
    const configsSaved = localStorage.getItem("langgraph_profile_saved")

    if (!agentUuid || !configsSaved) {
      alert("Please complete and save all configuration steps before deploying.")
      return
    }

    setIsDeploying(true)
    try {
      const response = await langgraphApi.deployAgent(agentUuid)

      // If there's a deployment URL in the response, update it
      if (response.url && onDeployed) {
        onDeployed(response.url)
      }
    } catch (error) {
      console.error("Failed to deploy agent:", error)
      alert("Failed to deploy agent. Please try again.")
    } finally {
      setIsDeploying(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: "user",
      content: inputValue.trim(),
    }

    setMessages((prev) => [...prev, userMessage])

    const assistantMessage: Message = {
      id: `assistant-${Date.now()}`,
      type: "assistant",
      content: "",
      thinking: "",
      isStreaming: true,
    }

    setMessages((prev) => [...prev, assistantMessage])
    setInputValue("")
    setIsLoading(true)

    try {
      await streamResponse(assistantMessage.id, userMessage.content)
    } catch (error) {
      console.error("Streaming error:", error)
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred"
      setErrorNotification(errorMessage)
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMessage.id
            ? { ...msg, content: "Error occurred while processing your request.", isStreaming: false }
            : msg,
        ),
      )
    } finally {
      setIsLoading(false)
    }
  }

  const streamResponse = async (messageId: string, userInput: string) => {
    const endpoint = apiUrl.trim()
    const applicationName = localStorage.getItem("application_name") || "langgraph_agent"
    const userIdentity = localStorage.getItem("user_id") || "user_001"

    const payload = {
      application_name: applicationName,
      user_identity: userIdentity,
      messages: [{ role: "user", content: [{ type: "text", text: userInput }] }],
    }

    const headers: Record<string, string> = { "Content-Type": "application/json" }
    if (bearerToken.trim()) {
      headers["Authorization"] = `Bearer ${bearerToken.trim()}`
    }

    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      const errorData = await response.text()
      throw new Error(`HTTP ${response.status}: ${errorData || response.statusText}`)
    }

    if (!response.body) throw new Error("No response body")

    const reader = response.body.getReader()
    const decoder = new TextDecoder()
    let buffer = ""
    let streamingText = ""

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split("\n")
      buffer = lines.pop() || ""

      for (const line of lines) {
        const trimmedLine = line.trim()
        if (!trimmedLine) continue

        if (trimmedLine.startsWith("data:")) {
          try {
            const jsonStr = trimmedLine.substring(5).trim()
            const data = JSON.parse(jsonStr)
            if (data.text) {
              streamingText += data.text
              setMessages((prev) =>
                prev.map((msg) => (msg.id === messageId ? { ...msg, content: streamingText } : msg)),
              )
            }
          } catch (e) {
            // Ignore parse errors
          }
        }
      }
    }

    setMessages((prev) => prev.map((msg) => (msg.id === messageId ? { ...msg, isStreaming: false } : msg)))
  }

  const toggleDetails = (messageId: string) => {
    setDetailsOpen((prev) => ({ ...prev, [messageId]: !prev[messageId] }))
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-full mb-4">
          <Play className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Step 6: Deploy & Test</span>
        </div>
        <h2 className="text-3xl font-bold mb-2">Deploy Your Agent</h2>
        <p className="text-muted-foreground">Download and test your agent</p>
      </div>

      <div className="space-y-6">
        {/* Download Section */}
        <div className="p-6 border border-border rounded-lg bg-gradient-to-br from-primary/5 to-transparent text-center">
          <h3 className="text-xl font-bold mb-2">Ready to Deploy</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Download your agent configuration and deploy it to your infrastructure
          </p>
          <div className="flex items-center justify-center gap-3">
            <Button
              onClick={handleDeploy}
              disabled={isDeploying}
              size="lg"
              className="bg-gradient-primary hover:opacity-90"
            >
              <Rocket className="w-4 h-4 mr-2" />
              {isDeploying ? "Deploying..." : "Deploy"}
            </Button>
            <Button
              onClick={handleDownloadCode}
              disabled={isDownloading}
              size="lg"
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90"
            >
              <Download className="w-4 h-4 mr-2" />
              {isDownloading ? "Downloading..." : "Download Code"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
