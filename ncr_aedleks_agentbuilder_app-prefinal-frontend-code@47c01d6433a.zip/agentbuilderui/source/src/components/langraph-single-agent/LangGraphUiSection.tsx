"use client"

import { useState, useEffect } from "react"
import { Layout, Loader2, Sparkles, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

interface UiStepProps {
  onNext: (data: any) => void
  onSaveAll: (uiData?: any) => void 
  isSaving: boolean
  initialData?: any
  uiData?: any 
  defaultConfig?: any
  isLoadingConfig?: boolean
}

export function LangGraphUiSection({ onNext, onSaveAll, isSaving, initialData, defaultConfig, uiData, isLoadingConfig }: UiStepProps) {
  const [includeUi, setIncludeUi] = useState(initialData?.includeUi ?? true)
  const [uiPort, setUiPort] = useState(initialData?.uiPort || "")
  const [showSaveButton, setShowSaveButton] = useState(initialData?.showSaveButton || false)
  const [tempData, setTempData] = useState<any>(null)

  useEffect(() => {
    if (defaultConfig?.frontend_config) {
      setUiPort(defaultConfig.frontend_config.port?.toString() || "")
    }
  }, [defaultConfig])

  const handleNext = () => {
    if (includeUi && !uiPort) {
      alert("Please enter UI port")
      return
    }

    const currentUiData = {
      includeUi,
      uiPort,
      showSaveButton: true,
    }

    // Store data temporarily but don't advance to next step
    setTempData(currentUiData)
    onNext(currentUiData)
    setShowSaveButton(true)
  }

  const handleSaveAndContinue = () => {
    onSaveAll(tempData)
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-full mb-4">
          <Layout className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Step 5: UI Configuration</span>
        </div>
        <h2 className="text-3xl font-bold mb-2">Configure UI</h2>
        <p className="text-muted-foreground">Set up your frontend interface</p>
      </div>

      <div className="space-y-6">
        <div className="flex items-center space-x-3 p-4 bg-background/30">
          <Checkbox
            id="include-ui"
            checked={includeUi}
            onCheckedChange={(checked) => setIncludeUi(checked as boolean)}
            disabled
          />
          <Label htmlFor="include-ui" className="cursor-pointer">
            Include UI Configuration
          </Label>
        </div>

        {includeUi && (
          <div className="space-y-2 p-3 bg-background/30">
            <div className="space-y-2">
              <Label htmlFor="ui-port">UI Port Number *</Label>
              <Input
                id="ui-port"
                placeholder="3000"
                value={uiPort}
                onChange={(e) => setUiPort(e.target.value)}
                className="bg-background/50"
                disabled
              />
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-center pt-6">
        {!showSaveButton ? (
          <Button
            onClick={handleNext}
            size="lg"
            className="bg-gradient-to-r from-orange-500 to-amber-500 hover:opacity-90 shadow-lg shadow-primary/30"
          >
            Next Step
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        ) : (
          <Button
            onClick={handleSaveAndContinue}
            disabled={isSaving}
            size="lg"
            className="bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 hover:opacity-90 shadow-lg shadow-primary/30"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Saving All Configurations...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Save & Continue to Deploy
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  )
}
