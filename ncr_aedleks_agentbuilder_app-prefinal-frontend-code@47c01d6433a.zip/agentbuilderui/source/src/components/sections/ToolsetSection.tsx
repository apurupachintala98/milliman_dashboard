"use client"

import { useState, useEffect } from "react"
import { Wrench, Plus, Server, Code2, X, Settings, ArrowRight, CheckCircle2, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Tool {
  type: string
  name: string
  description: string
  input_schema: string
}

interface ToolResource {
  name: string
  semantic_model_file: string
  execution_environment_type: string
  warehouse: string
  query_timeout: number
}

interface ToolsetStepProps {
  agentUuid?: string | null
  onNext: (data: any) => void
  onSaveAll: (data: any) => void
  initialData?: any
  isSaving?: boolean
}

export function ToolsetStep({ agentUuid, onNext, onSaveAll, initialData, isSaving }: ToolsetStepProps) {
  const [showSaveButton, setShowSaveButton] = useState(initialData?.showSaveButton || false)

  const [toolChoiceType, setToolChoiceType] = useState(initialData?.toolChoiceType || "auto")
  const [toolChoiceName, setToolChoiceName] = useState(initialData?.toolChoiceName || "")
  const [activeForm, setActiveForm] = useState<
    "none" | "addToolOptions" | "addToolCustom" | "addResourceOptions" | "addResourceCustom"
  >("none")
  const [tools, setTools] = useState<Tool[]>(initialData?.tools || [])
  const [toolResources, setToolResources] = useState<ToolResource[]>(initialData?.toolResources || [])

  const [newTool, setNewTool] = useState<Tool>({
    type: "cortex_analyst_text_to_sql",
    name: "",
    description: "",
    input_schema: "",
  })

  const [newResource, setNewResource] = useState<ToolResource>({
    name: "",
    semantic_model_file: "",
    execution_environment_type: "warehouse",
    warehouse: "",
    query_timeout: 120,
  })

  useEffect(() => {
    if (initialData?.showSaveButton !== undefined) {
      setShowSaveButton(initialData.showSaveButton)
    }
  }, [initialData?.showSaveButton])

  const handleAddTool1 = () => {
    const tool1 = {
      type: "cortex_analyst_text_to_sql",
      name: "analyst_tool",
      description: "Analyze claims for unknown payment recovery status.",
      input_schema: "InputSchema",
    }
    setTools([...tools, tool1])
    setActiveForm("none")
  }

  const handleAddTool = () => {
    if (newTool.name && newTool.description) {
      setTools([...tools, newTool])
      setNewTool({
        type: "cortex_analyst_text_to_sql",
        name: "",
        description: "",
        input_schema: "",
      })
      setActiveForm("none")
    }
  }

  const handleAddToolResource1 = () => {
    const resource1 = {
      name: "analyst_tool",
      semantic_model_file: "@POC_SPC_SNOWPARK_DB.COC_SCHEMA.COC_STAGE/DNYP_MODEL.yaml",
      execution_environment_type: "warehouse",
      warehouse: "POC_SPC_SNOWPARK_WH",
      query_timeout: 120,
    }
    setToolResources([...toolResources, resource1])
    setActiveForm("none")
  }

  const handleAddResource = () => {
    if (newResource.name && newResource.semantic_model_file && newResource.warehouse) {
      setToolResources([...toolResources, newResource])
      setNewResource({
        name: "",
        semantic_model_file: "",
        execution_environment_type: "warehouse",
        warehouse: "",
        query_timeout: 120,
      })
      setActiveForm("none")
    }
  }

  const handleRemoveTool = (index: number) => {
    setTools(tools.filter((_, i) => i !== index))
  }

  const handleRemoveResource = (index: number) => {
    setToolResources(toolResources.filter((_, i) => i !== index))
  }

  const handleNext = () => {
    const data = {
      toolChoiceType,
      toolChoiceName,
      tools,
      toolResources,
      showSaveButton: true,
    }

    console.log("[v0] ToolsetStep - Next clicked, showing Save button")
    // Don't call onNext here - that would advance to next step
    // Just update local state to show the Save & Continue button
    setShowSaveButton(true)
  }

  const handleSaveAndContinue = () => {
    const data = {
      toolChoiceType,
      toolChoiceName,
      tools,
      toolResources,
      showSaveButton: true,
    }

    console.log("[v0] ToolsetStep - Save & Continue clicked, saving data to wizard first")
    // First save the toolset data to the wizard state
    onNext(data)

    // Then trigger all API calls
    console.log("[v0] ToolsetStep - Now calling all APIs via onSaveAll")
    onSaveAll(data)
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
          <Wrench className="w-4 h-4 text-primary" />
          <span>Step 3: Agent Tools</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Configure{" "}
          <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Tools</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Add tools and integrations to help your agent take action
        </p>
      </div>

      {/* Form Card */}
      <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg space-y-8">
        {/* Tool Choice Configuration */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Settings className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-bold">Tool Choice Configuration</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tool-choice-type">Type</Label>
              <Select value={toolChoiceType} onValueChange={setToolChoiceType}>
                <SelectTrigger id="tool-choice-type" className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto</SelectItem>
                  <SelectItem value="required">Required</SelectItem>
                  <SelectItem value="tool">Tool</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {toolChoiceType === "tool" && (
              <div className="space-y-2">
                <Label htmlFor="tool-choice-name">Name</Label>
                <Input
                  id="tool-choice-name"
                  placeholder="Enter tool name"
                  value={toolChoiceName}
                  onChange={(e) => setToolChoiceName(e.target.value)}
                  className="bg-background"
                />
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-border" />

        {/* Tools List */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold">Tools</h3>
              <p className="text-sm text-muted-foreground">Configure tools for your agent</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setNewTool({
                    type: "cortex_analyst_text_to_sql",
                    name: "",
                    description: "",
                    input_schema: "",
                  })
                  setActiveForm("addToolOptions")
                }}
                className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90"
                disabled={isSaving}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Tool
              </Button>
              <Button
                onClick={() => {
                  setNewResource({
                    name: "",
                    semantic_model_file: "",
                    execution_environment_type: "warehouse",
                    warehouse: "",
                    query_timeout: 120,
                  })
                  setActiveForm("addResourceOptions")
                }}
                variant="outline"
                disabled={isSaving}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Resource
              </Button>
            </div>
          </div>

          {/* Tool Forms - keeping all the existing form logic */}
          {activeForm === "addToolOptions" && (
            <div className="bg-secondary/20 border-2 border-primary/50 rounded-xl p-6 space-y-4 mb-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-lg font-semibold">Select Tool Type</h4>
                  <p className="text-sm text-muted-foreground">Choose a predefined tool or create a custom one</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setActiveForm("none")}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <Button
                  onClick={handleAddTool1}
                  variant="outline"
                  className="h-auto p-6 flex flex-col items-start gap-2 hover:bg-primary/5 bg-transparent"
                >
                  <div className="flex items-center gap-2 font-semibold text-lg">
                    <Code2 className="w-5 h-5 text-primary" />
                    Payment recovery status tool
                  </div>
                  <p className="text-sm text-muted-foreground text-left">Cortex Analyst - Analyze claims</p>
                </Button>
                <Button
                  onClick={() => setActiveForm("addToolCustom")}
                  variant="outline"
                  className="h-auto p-6 flex flex-col items-start gap-2 hover:bg-primary/5"
                >
                  <div className="flex items-center gap-2 font-semibold text-lg">
                    <Settings className="w-5 h-5 text-primary" />
                    Custom Tool
                  </div>
                  <p className="text-sm text-muted-foreground text-left">Create your own custom tool</p>
                </Button>
              </div>
            </div>
          )}

          {activeForm === "addToolCustom" && (
            <div className="bg-secondary/20 border-2 border-primary/50 rounded-xl p-6 space-y-4 mb-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="tool-type">Type</Label>
                  <Select value={newTool.type} onValueChange={(value) => setNewTool({ ...newTool, type: value })}>
                    <SelectTrigger id="tool-type" className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cortex_analyst_text_to_sql">Cortex Analyst Text to SQL</SelectItem>
                      <SelectItem value="generic">Generic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tool-name">Name *</Label>
                  <Input
                    id="tool-name"
                    placeholder="e.g., analyst_tool"
                    value={newTool.name}
                    onChange={(e) => setNewTool({ ...newTool, name: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tool-description">Description *</Label>
                  <Textarea
                    id="tool-description"
                    placeholder="Detailed description of the tool..."
                    value={newTool.description}
                    onChange={(e) => setNewTool({ ...newTool, description: e.target.value })}
                    rows={3}
                    className="bg-background resize-none"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tool-schema">Input Schema</Label>
                  <Input
                    id="tool-schema"
                    placeholder="e.g., InputSchema"
                    value={newTool.input_schema}
                    onChange={(e) => setNewTool({ ...newTool, input_schema: e.target.value })}
                    className="bg-background"
                  />
                </div>
              </div>
              <div className="flex gap-2 justify-end pt-4">
                <Button variant="outline" onClick={() => setActiveForm("addToolOptions")}>
                  Back
                </Button>
                <Button
                  onClick={handleAddTool}
                  disabled={!newTool.name || !newTool.description}
                  className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90"
                >
                  Add Tool
                </Button>
              </div>
            </div>
          )}

          {activeForm === "addResourceOptions" && (
            <div className="bg-secondary/20 border-2 border-primary/50 rounded-xl p-6 space-y-4 mb-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-lg font-semibold">Select Tool Resource Type</h4>
                  <p className="text-sm text-muted-foreground">Choose a predefined resource or create a custom one</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setActiveForm("none")}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <Button
                  onClick={handleAddToolResource1}
                  variant="outline"
                  className="h-auto p-6 flex flex-col items-start gap-2 hover:bg-primary/5 bg-transparent"
                >
                  <div className="flex items-center gap-2 font-semibold text-lg">
                    <Server className="w-5 h-5 text-primary" />
                    EDA DIP Resource
                  </div>
                  <p className="text-sm text-muted-foreground text-left">Analyst Tool</p>
                </Button>
                <Button
                  onClick={() => setActiveForm("addResourceCustom")}
                  variant="outline"
                  className="h-auto p-6 flex flex-col items-start gap-2 hover:bg-primary/5"
                >
                  <div className="flex items-center gap-2 font-semibold text-lg">
                    <Settings className="w-5 h-5 text-primary" />
                    Custom Resource
                  </div>
                  <p className="text-sm text-muted-foreground text-left">Create your own custom tool resource</p>
                </Button>
              </div>
            </div>
          )}

          {activeForm === "addResourceCustom" && (
            <div className="bg-secondary/20 border-2 border-primary/50 rounded-xl p-6 space-y-4 mb-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="resource-name">Tool Resource Name *</Label>
                  <Input
                    id="resource-name"
                    placeholder="e.g., analyst_tool"
                    value={newResource.name}
                    onChange={(e) => setNewResource({ ...newResource, name: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="semantic-model">Semantic Model File *</Label>
                  <Input
                    id="semantic-model"
                    placeholder="@POC_SPC_SNOWPARK_DB.HEDIS_SCHEMA.HEDIS_STAGE_FULL/edadip.yaml"
                    value={newResource.semantic_model_file}
                    onChange={(e) => setNewResource({ ...newResource, semantic_model_file: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="warehouse">Warehouse *</Label>
                  <Input
                    id="warehouse"
                    placeholder="e.g., POC_SPC_SNOWPARK_WH"
                    value={newResource.warehouse}
                    onChange={(e) => setNewResource({ ...newResource, warehouse: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="query-timeout">Query Timeout (seconds)</Label>
                  <Input
                    id="query-timeout"
                    type="number"
                    placeholder="120"
                    value={newResource.query_timeout}
                    onChange={(e) => setNewResource({ ...newResource, query_timeout: Number(e.target.value) })}
                    className="bg-background"
                  />
                </div>
              </div>
              <div className="flex gap-2 justify-end pt-4">
                <Button variant="outline" onClick={() => setActiveForm("addResourceOptions")}>
                  Back
                </Button>
                <Button
                  onClick={handleAddResource}
                  disabled={!newResource.name || !newResource.semantic_model_file || !newResource.warehouse}
                  className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90"
                >
                  Add Resource
                </Button>
              </div>
            </div>
          )}

          {/* Display Added Tools */}
          {tools.length > 0 && (
            <div className="space-y-3 mb-6">
              <h4 className="text-sm font-semibold">Added Tools</h4>
              {tools.map((tool, index) => (
                <div
                  key={index}
                  className="bg-background border border-border rounded-lg p-4 flex items-start justify-between"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Code2 className="w-4 h-4 text-primary" />
                      <span className="font-semibold">{tool.name}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{tool.description}</p>
                    <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Type: {tool.type}</span>
                      {tool.input_schema && <span>Schema: {tool.input_schema}</span>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveTool(index)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    disabled={isSaving}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Display Added Resources */}
          {toolResources.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-semibold">Added Tool Resources</h4>
              {toolResources.map((resource, index) => (
                <div
                  key={index}
                  className="bg-background border border-border rounded-lg p-4 flex items-start justify-between"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Server className="w-5 h-5 text-primary" />
                      <span className="font-semibold">{resource.name}</span>
                    </div>
                    <div className="space-y-1 text-xs text-muted-foreground">
                      <div>File: {resource.semantic_model_file}</div>
                      <div>Warehouse: {resource.warehouse}</div>
                      <div>Timeout: {resource.query_timeout}s</div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveResource(index)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    disabled={isSaving}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="pt-6 flex justify-center gap-4">
          {!showSaveButton ? (
            <Button
              onClick={handleNext}
              className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90 text-white px-8 py-6 text-base font-semibold"
              size="lg"
              disabled={isSaving}
            >
              <span>Next Step</span>
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleSaveAndContinue}
              disabled={isSaving}
              className="bg-gradient-to-r from-orange-600 to-amber-500 hover:opacity-90 text-white px-8 py-6 text-base font-semibold shadow-lg"
              size="lg"
            >
              <CheckCircle2 className="w-5 h-5 mr-2" />
              <span>Save & Continue to Deploy</span>
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
