"use client"

import { useState } from "react"
import { Database, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface ApplicationConfigStepProps {
  agentUuid?: string | null
  onNext: (data: any) => void
  initialData?: any
}

export function ApplicationConfigStep({ agentUuid, onNext, initialData }: ApplicationConfigStepProps) {
  const [db, setDb] = useState(initialData?.db || "")
  const [schema, setSchema] = useState(initialData?.schema || "")
  const [applicationName, setApplicationName] = useState(initialData?.applicationName || "")

  const handleNext = () => {
    if (!db.trim() || !schema.trim() || !applicationName.trim()) {
      alert("Please fill in all required fields")
      return
    }

    const data = {
      db,
      schema,
      applicationName,
    }

    console.log("[v0] ApplicationConfigStep - Passing data to wizard:", data)
    onNext(data)
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
          <Database className="w-4 h-4 text-primary" />
          <span>Step 2: Application Config</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Configure{" "}
          <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Database</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">Set up your database and application configuration</p>
      </div>

      {/* Form Card */}
      <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg">
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="db">Database *</Label>
              <Input
                id="db"
                placeholder="e.g., POC_SPC_SNOWPARK_DB"
                value={db}
                onChange={(e) => setDb(e.target.value)}
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="schema">Schema *</Label>
              <Input
                id="schema"
                placeholder="e.g., DATA_SCHEMA"
                value={schema}
                onChange={(e) => setSchema(e.target.value)}
                className="bg-background"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="application-name">Application Name *</Label>
            <Input
              id="application-name"
              placeholder="e.g., DEFAULT_APPLICATION"
              value={applicationName}
              onChange={(e) => setApplicationName(e.target.value)}
              className="bg-background"
            />
          </div>

          <div className="pt-6 flex justify-center">
            <Button
              onClick={handleNext}
              disabled={!db.trim() || !schema.trim() || !applicationName.trim()}
              className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90 text-white px-8 py-6 text-base font-semibold"
              size="lg"
            >
              <span>Next Step</span>
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
