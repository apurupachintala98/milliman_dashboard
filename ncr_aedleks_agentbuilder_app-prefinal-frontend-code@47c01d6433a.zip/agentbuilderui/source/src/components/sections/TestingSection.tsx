// "use client"

// import type React from "react"

// import { useState, useRef, useEffect } from "react"
// import {
//   Play,
//   BarChart3,
//   MessageSquare,
//   CheckCircle,
//   Clock,
//   Send,
//   ChevronDown,
//   ChevronUp,
//   AlertCircle,
//   X,
// } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// interface Message {
//   id: string
//   type: "user" | "assistant"
//   content: string
//   thinking?: string
//   isStreaming?: boolean
// }

// interface TestingSectionProps {
//   activeSection?: string
//   setActiveSection?: (section: string) => void
//   agentUrl?: string | null
// }

// export const TestingSection = ({ activeSection, setActiveSection, agentUrl }: TestingSectionProps) => {
//   const [messages, setMessages] = useState<Message[]>([])
//   const [inputValue, setInputValue] = useState("")
//   const [isLoading, setIsLoading] = useState(false)
//   const [detailsOpen, setDetailsOpen] = useState<Record<string, boolean>>({})
//   const [apiUrl, setApiUrl] = useState("")
//   const messagesEndRef = useRef<HTMLDivElement>(null)
//   const [bearerToken, setBearerToken] = useState<string>("")
//   const [errorNotification, setErrorNotification] = useState<string | null>(null)

//   const scrollToBottom = () => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
//   }

//   useEffect(() => {
//     if (agentUrl) {
//       setApiUrl(agentUrl)
//     }
//   }, [agentUrl])


//   useEffect(() => {
//     scrollToBottom()
//   }, [messages])

//   useEffect(() => {
//     if (errorNotification) {
//       const timer = setTimeout(() => setErrorNotification(null), 5000)
//       return () => clearTimeout(timer)
//     }
//   }, [errorNotification])

//   const parseStreamEvent = (line: string) => {
//     if (line.startsWith("event:")) {
//       return { event: line.substring(6).trim(), data: null }
//     }
//     if (line.startsWith("data:")) {
//       try {
//         const jsonStr = line.substring(5).trim()
//         return { event: "data", data: JSON.parse(jsonStr) }
//       } catch (e) {
//         return null
//       }
//     }
//     return null
//   }

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!inputValue.trim() || isLoading) return

//     const userMessage: Message = {
//       id: `user-${Date.now()}`,
//       type: "user",
//       content: inputValue.trim(),
//     }

//     setMessages((prev) => [...prev, userMessage])

//     const assistantMessage: Message = {
//       id: `assistant-${Date.now()}`,
//       type: "assistant",
//       content: "",
//       thinking: "",
//       isStreaming: true,
//     }

//     setMessages((prev) => [...prev, assistantMessage])
//     setInputValue("")
//     setIsLoading(true)

//     try {
//       await streamResponse(assistantMessage.id, userMessage.content)
//     } catch (error) {
//       console.error("Streaming error:", error)
//       const errorMessage = error instanceof Error ? error.message : "Unknown error occurred"
//       setErrorNotification(errorMessage)
//       setMessages((prev) =>
//         prev.map((msg) =>
//           msg.id === assistantMessage.id
//             ? {
//               ...msg,
//               content: "Error occurred while processing your request.",
//               isStreaming: false,
//             }
//             : msg,
//         ),
//       )
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   const streamResponse = async (messageId: string, userInput: string) => {
//     const endpoint = apiUrl.trim()

//     const applicationName = endpoint.includes(
//       "deniedyetpaidagent.edagenaipreprod.awsdns.internal.das/run_cao_agent"
//     )
//       ? "cao"
//       : localStorage.getItem("application_name")
//     const userIdentity = localStorage.getItem("user_id") || "user_001"

//     const payload = {
//       application_name: applicationName,
//       user_identity: userIdentity,
//       messages: [
//         {
//           role: "user",
//           content: [
//             {
//               type: "text",
//               text: userInput
//             }
//           ]
//         }
//       ]
//     }

//     const headers: Record<string, string> = {
//       "Content-Type": "application/json",
//     }

//     if (bearerToken.trim()) {
//       headers["Authorization"] = `Bearer ${bearerToken.trim()}`
//     }
//     const response = await fetch(endpoint, {
//       method: "POST",
//       headers,
//       body: JSON.stringify(payload),
//     })

//     if (!response.ok) {
//       const errorData = await response.text()
//       throw new Error(`HTTP ${response.status}: ${errorData || response.statusText}`)
//     }

//     if (!response.body) {
//       throw new Error("No response body")
//     }

//     const reader = response.body.getReader()
//     const decoder = new TextDecoder()
//     let buffer = ""
//     let currentEvent = ""
//     let streamingThinking = ""
//     let streamingText = ""
//     let finalThinking = ""
//     let finalText = ""

//     let isReading = true

//     while (isReading) {
//       const { done, value } = await reader.read()
//       if (done) {
//         isReading = false
//         break
//       }

//       buffer += decoder.decode(value, { stream: true })
//       const lines = buffer.split("\n")
//       buffer = lines.pop() || ""

//       for (const line of lines) {
//         const trimmedLine = line.trim()
//         if (!trimmedLine) continue

//         const parsed = parseStreamEvent(trimmedLine)
//         if (!parsed) continue

//         if (parsed.event !== "data") {
//           currentEvent = parsed.event
//           continue
//         }

//         const data = parsed.data

//         switch (currentEvent) {
//           case "response.thinking.delta":
//             if (data.text) {
//               streamingThinking += data.text
//               setMessages((prev) =>
//                 prev.map((msg) => (msg.id === messageId ? { ...msg, thinking: streamingThinking } : msg)),
//               )
//             }
//             break

//           case "response.thinking":
//             finalThinking = data.text
//             break

//           case "response.text.delta":
//             if (data.text) {
//               streamingText += data.text
//               setMessages((prev) =>
//                 prev.map((msg) => (msg.id === messageId ? { ...msg, content: streamingText } : msg)),
//               )
//             }
//             break

//           case "response.text":
//             if (data.text) {
//               if (finalText.length > 0) {
//                 finalText += "\n"
//               }
//               finalText += data.text
//             }
//             break

//           case "response":
//             if (data.content) {
//               const thinkingContent = data.content.find((item: any) => item.type === "thinking")
//               const textContent = data.content.find((item: any) => item.type === "text")

//               setMessages((prev) =>
//                 prev.map((msg) =>
//                   msg.id === messageId
//                     ? {
//                       ...msg,
//                       thinking: thinkingContent?.thinking?.text || finalThinking,
//                       content: finalText,
//                       isStreaming: false,
//                     }
//                     : msg,
//                 ),
//               )
//             }
//             return

//           case "done":
//             return
//         }

//         await new Promise((resolve) => setTimeout(resolve, 50))
//       }
//     }
//   }

//   const toggleDetails = (messageId: string) => {
//     setDetailsOpen((prev) => ({
//       ...prev,
//       [messageId]: !prev[messageId],
//     }))
//   }

//   return (
//     <section id="testing" className="py-24 relative">
//       <div className="container mx-auto px-6">
//         <div className="max-w-6xl mx-auto">
//           <div className="text-center mb-16 animate-fade-in">
//             <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
//               <Play className="w-4 h-4 text-primary" />
//               <span>Step 5</span>
//             </div>
//             <h2 className="text-4xl md:text-5xl font-bold mb-4">
//               Test & <span className="bg-gradient-primary bg-clip-text text-transparent">Monitor</span>
//             </h2>
//             <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//               Test your agent's responses and monitor performance in real-time
//             </p>
//           </div>

//           {errorNotification && (
//             <div className="mb-6 max-w-2xl mx-auto bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-center justify-between">
//               <div className="flex items-center gap-3">
//                 <AlertCircle className="w-5 h-5 text-red-500" />
//                 <p className="text-sm text-red-700">{errorNotification}</p>
//               </div>
//               <button onClick={() => setErrorNotification(null)} className="text-red-500 hover:text-red-700">
//                 <X className="w-4 h-4" />
//               </button>
//             </div>
//           )}

//           <div className="mb-8 max-w-2xl mx-auto space-y-4">
//             <div>
//               <label htmlFor="api-url" className="block text-sm font-medium mb-2">
//                 Test API URL:
//               </label>
//               <Input
//                 id="api-url"
//                 type="text"
//                 placeholder="Enter your API endpoint URL"
//                 className="bg-card/60 backdrop-blur-xl border-border"
//                 value={apiUrl}
//                 onChange={(e) => setApiUrl(e.target.value)}
//               />
//             </div>
//             <div>
//               <label htmlFor="bearer-token" className="block text-sm font-medium mb-2">
//                 Bearer Token:
//               </label>
//               <Input
//                 id="bearer-token"
//                 type="password"
//                 placeholder="Enter your Bearer token if required"
//                 className="bg-card/60 backdrop-blur-xl border-border"
//                 value={bearerToken}
//                 onChange={(e) => setBearerToken(e.target.value)}
//               />
//             </div>
//           </div>

//           <div className="space-y-6">
//             <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-6 shadow-card">
//               <div className="flex items-center gap-3 mb-6">
//                 <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center shadow-glow">
//                   <MessageSquare className="w-5 h-5 text-primary-foreground" />
//                 </div>
//                 <div>
//                   <h3 className="text-xl font-bold">Test Your Agent</h3>
//                   {/* <p className="text-sm text-muted-foreground">Try your agent</p> */}
//                 </div>
//               </div>

//               <div className="space-y-4 mb-6 h-96 overflow-y-auto">
//                 {messages.length === 0 ? (
//                   <div className="flex items-center justify-center h-full text-muted-foreground">
//                     <p className="text-sm">Start a conversation with your agent...</p>
//                   </div>
//                 ) : (
//                   messages.map((message) => (
//                     <div key={message.id}>
//                       {message.type === "user" ? (
//                         <div className="flex justify-end">
//                           <div className="bg-primary/20 border border-primary/30 rounded-2xl rounded-tr-sm px-4 py-3 max-w-[80%]">
//                             <p className="text-sm">{message.content}</p>
//                           </div>
//                         </div>
//                       ) : (
//                         <div className="flex justify-start">
//                           <div className="bg-secondary/50 border border-border rounded-2xl rounded-tl-sm px-4 py-3 max-w-[90%] space-y-3">
//                             {message.thinking && (
//                               <div className="border rounded-lg p-3 bg-accent/10">
//                                 {message.isStreaming && (
//                                   <div className="flex items-center gap-2 mb-2">
//                                     <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
//                                     <span className="text-xs font-medium text-muted-foreground">Thinking...</span>
//                                   </div>
//                                 )}
//                                 {!message.isStreaming && (
//                                   <button
//                                     onClick={() => toggleDetails(message.id)}
//                                     className="flex items-center gap-2 text-xs text-primary hover:underline mb-2"
//                                   >
//                                     {detailsOpen[message.id] ? (
//                                       <ChevronUp className="w-3 h-3" />
//                                     ) : (
//                                       <ChevronDown className="w-3 h-3" />
//                                     )}
//                                     {detailsOpen[message.id] ? "Hide Details" : "Show Details"}
//                                   </button>
//                                 )}
//                                 {(message.isStreaming || detailsOpen[message.id]) && (
//                                   <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">
//                                     {message.thinking}
//                                   </p>
//                                 )}
//                               </div>
//                             )}

//                             {message.content && (
//                               <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
//                             )}

//                             {message.isStreaming && !message.content && !message.thinking && (
//                               <div className="flex items-center gap-2">
//                                 <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
//                                 <span className="text-xs text-muted-foreground">Loading...</span>
//                               </div>
//                             )}
//                           </div>
//                         </div>
//                       )}
//                     </div>
//                   ))
//                 )}
//                 <div ref={messagesEndRef} />
//               </div>

//               <form onSubmit={handleSubmit} className="flex gap-2">
//                 <Input
//                   placeholder="Type a message to test your agent..."
//                   className="bg-secondary/50 border-border"
//                   value={inputValue}
//                   onChange={(e) => setInputValue(e.target.value)}
//                   disabled={isLoading}
//                 />
//                 <Button
//                   type="submit"
//                   size="icon"
//                   className="bg-gradient-primary hover:opacity-90 transition-opacity flex-shrink-0"
//                   disabled={isLoading}
//                 >
//                   {isLoading ? <Clock className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
//                 </Button>
//               </form>
//             </div>

//             <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-6 shadow-card opacity-50 pointer-events-none">
//               <div className="flex items-center gap-3 mb-6">
//                 <div className="w-10 h-10 bg-gradient-accent rounded-lg flex items-center justify-center shadow-glow">
//                   <BarChart3 className="w-5 h-5 text-accent-foreground" />
//                 </div>
//                 <div>
//                   <h3 className="text-xl font-bold">Observability</h3>
//                   <p className="text-sm text-muted-foreground">Monitor execution</p>
//                 </div>
//               </div>

//               <Tabs defaultValue="input" className="w-full">
//                 <TabsList className="grid w-full grid-cols-3 bg-secondary/50">
//                   <TabsTrigger value="input">Input</TabsTrigger>
//                   <TabsTrigger value="output">Output</TabsTrigger>
//                   <TabsTrigger value="logs">Logs</TabsTrigger>
//                 </TabsList>

//                 <TabsContent value="input" className="space-y-3 mt-4">
//                   <div className="bg-secondary/30 border border-border rounded-lg p-4">
//                     <div className="flex items-center gap-2 mb-2">
//                       <span
//                         className="text-xs font-mono bg-primary/20 px-2 py-1 rounded text-primary"
//                         style={{ border: "1px solid #000" }}
//                       >
//                         T
//                       </span>
//                       <span className="text-sm font-medium">action</span>
//                     </div>
//                     <p className="text-sm text-muted-foreground">saveContext</p>
//                   </div>
//                   <div className="bg-secondary/30 border border-border rounded-lg p-4">
//                     <div className="flex items-center gap-2 mb-2">
//                       <span
//                         className="text-xs font-mono bg-primary/20 px-2 py-1 rounded text-primary"
//                         style={{ border: "1px solid #000" }}
//                       >
//                         T
//                       </span>
//                       <span className="text-sm font-medium">input</span>
//                     </div>
//                     <p className="text-sm text-muted-foreground">
//                       {messages.length > 0 && messages[messages.length - 2]?.type === "user"
//                         ? messages[messages.length - 2].content
//                         : "No input yet"}
//                     </p>
//                   </div>
//                   <div className="bg-secondary/30 border border-border rounded-lg p-4">
//                     <div className="flex items-center gap-2 mb-2">
//                       <span
//                         className="text-xs font-mono bg-primary/20 px-2 py-1 rounded text-primary"
//                         style={{ border: "1px solid #000" }}
//                       >
//                         T
//                       </span>
//                       <span className="text-sm font-medium">system_message</span>
//                     </div>
//                     <p className="text-sm text-muted-foreground">You are a helpful assistant</p>
//                   </div>
//                 </TabsContent>

//                 <TabsContent value="output" className="space-y-3 mt-4">
//                   {messages.length > 0 ? (
//                     messages.slice(-2).map((msg) => (
//                       <div key={msg.id} className="bg-secondary/30 border border-border rounded-lg p-4">
//                         <div className="flex items-center justify-between mb-2">
//                           <span className="text-sm font-medium">{msg.type === "user" ? "Human" : "AI"}</span>
//                           <CheckCircle className="w-4 h-4 text-green-500" />
//                         </div>
//                         <p className="text-sm text-muted-foreground">{msg.content}</p>
//                       </div>
//                     ))
//                   ) : (
//                     <div className="bg-secondary/30 border border-border rounded-lg p-4">
//                       <p className="text-sm text-muted-foreground">No output yet</p>
//                     </div>
//                   )}
//                 </TabsContent>

//                 <TabsContent value="logs" className="space-y-3 mt-4">
//                   <div className="space-y-2">
//                     <div className="flex items-center gap-2 text-xs">
//                       <Clock className="w-3 h-3 text-muted-foreground" />
//                       <span className="text-muted-foreground">
//                         {messages.filter((m) => m.type === "user").length} Messages
//                       </span>
//                     </div>
//                     <div className="flex items-center gap-2 text-xs">
//                       <CheckCircle className="w-3 h-3 text-green-500" />
//                       <span className="text-muted-foreground">Agent Active</span>
//                     </div>
//                     <div className="bg-secondary/30 border border-border rounded-lg p-3">
//                       <p className="text-xs font-mono text-muted-foreground">
//                         [Session: {localStorage.getItem("user_id")?.slice(0, 5) || "xxxxx"}...] Chat session active
//                       </p>
//                     </div>
//                     <div className="bg-secondary/30 border border-border rounded-lg p-3">
//                       <p className="text-xs font-mono text-muted-foreground">AI Agent → Streaming Response</p>
//                     </div>
//                     <div className="bg-secondary/30 border border-border rounded-lg p-3">
//                       <p className="text-xs font-mono text-muted-foreground">Snowflake Cortex</p>
//                     </div>
//                   </div>
//                 </TabsContent>
//               </Tabs>

//               <div className="grid grid-cols-3 gap-3 mt-6">
//                 <div className="bg-secondary/30 border border-border rounded-lg p-3 text-center">
//                   <div className="text-2xl font-bold text-primary">
//                     {messages.length > 0
//                       ? Math.round((messages.filter((m) => m.content).length / messages.length) * 100)
//                       : 0}
//                     %
//                   </div>
//                   <div className="text-xs text-muted-foreground">Success</div>
//                 </div>
//                 <div className="bg-secondary/30 border border-border rounded-lg p-3 text-center">
//                   <div className="text-2xl font-bold text-accent">~2s</div>
//                   <div className="text-xs text-muted-foreground">Avg Time</div>
//                 </div>
//                 <div className="bg-secondary/30 border border-border rounded-lg p-3 text-center">
//                   <div className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
//                     {messages.filter((m) => m.type === "user").length}
//                   </div>
//                   <div className="text-xs text-muted-foreground">Queries</div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </section>
//   )
// }

// export default TestingSection
"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import {
  Play,
  Download,
  Zap,
  Send,
  Clock,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  X,
  MessageSquare,
  Check,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { agentApi } from "@/services/api"

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  thinking?: string
  isStreaming?: boolean
}

interface DeployTestStepProps {
  agentUuid?: string | null
  agentUrl?: string | null
  setAgentUrl: (url: string) => void
}

export function DeployTestStep({ agentUuid, agentUrl, setAgentUrl }: DeployTestStepProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [detailsOpen, setDetailsOpen] = useState<Record<string, boolean>>({})
  const [apiUrl, setApiUrl] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [bearerToken, setBearerToken] = useState<string>("")
  const [errorNotification, setErrorNotification] = useState<string | null>(null)
  const [isDownloading, setIsDownloading] = useState(false)
  const [isCreatingAgent, setIsCreatingAgent] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)

  useEffect(() => {
    if (agentUrl) {
      setApiUrl(agentUrl)
    }
  }, [agentUrl])

  useEffect(() => {
    if (errorNotification) {
      const timer = setTimeout(() => setErrorNotification(null), 5000)
      return () => clearTimeout(timer)
    }
  }, [errorNotification])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const parseStreamEvent = (line: string) => {
    if (line.startsWith("event:")) {
      return { event: line.substring(6).trim(), data: null }
    }
    if (line.startsWith("data:")) {
      try {
        const jsonStr = line.substring(5).trim()
        return { event: "data", data: JSON.parse(jsonStr) }
      } catch (e) {
        return null
      }
    }
    return null
  }

  const streamResponse = async (messageId: string, userInput: string) => {
    const endpoint = apiUrl.trim()
    const applicationName = localStorage.getItem("application_name")
    const userIdentity = localStorage.getItem("user_id") || "user_001"

    const payload = {
      application_name: applicationName,
      user_identity: userIdentity,
      messages: [
        {
          role: "user",
          content: [{ type: "text", text: userInput }],
        },
      ],
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    }

    if (bearerToken.trim()) {
      headers["Authorization"] = `Bearer ${bearerToken.trim()}`
    }

    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      const errorData = await response.text()
      throw new Error(`HTTP ${response.status}: ${errorData || response.statusText}`)
    }

    if (!response.body) {
      throw new Error("No response body")
    }

    const reader = response.body.getReader()
    const decoder = new TextDecoder()
    let buffer = ""
    let currentEvent = ""
    let streamingThinking = ""
    let streamingText = ""
    let finalThinking = ""
    let finalText = ""

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split("\n")
      buffer = lines.pop() || ""

      for (const line of lines) {
        const trimmedLine = line.trim()
        if (!trimmedLine) continue

        const parsed = parseStreamEvent(trimmedLine)
        if (!parsed) continue

        if (parsed.event !== "data") {
          currentEvent = parsed.event
          continue
        }

        const data = parsed.data

        switch (currentEvent) {
          case "response.thinking.delta":
            if (data.text) {
              streamingThinking += data.text
              setMessages((prev) =>
                prev.map((msg) => (msg.id === messageId ? { ...msg, thinking: streamingThinking } : msg)),
              )
            }
            break

          case "response.thinking":
            finalThinking = data.text
            break

          case "response.text.delta":
            if (data.text) {
              streamingText += data.text
              setMessages((prev) =>
                prev.map((msg) => (msg.id === messageId ? { ...msg, content: streamingText } : msg)),
              )
            }
            break

          case "response.text":
            if (data.text) {
              if (finalText.length > 0) finalText += "\n"
              finalText += data.text
            }
            break

          case "response":
            if (data.content) {
              const thinkingContent = data.content.find((item: any) => item.type === "thinking")
              const textContent = data.content.find((item: any) => item.type === "text")

              setMessages((prev) =>
                prev.map((msg) =>
                  msg.id === messageId
                    ? {
                        ...msg,
                        thinking: thinkingContent?.thinking?.text || finalThinking,
                        content: finalText,
                        isStreaming: false,
                      }
                    : msg,
                ),
              )
            }
            return

          case "done":
            return
        }

        await new Promise((resolve) => setTimeout(resolve, 50))
      }
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: "user",
      content: inputValue.trim(),
    }

    setMessages((prev) => [...prev, userMessage])

    const assistantMessage: Message = {
      id: `assistant-${Date.now()}`,
      type: "assistant",
      content: "",
      thinking: "",
      isStreaming: true,
    }

    setMessages((prev) => [...prev, assistantMessage])
    setInputValue("")
    setIsLoading(true)

    try {
      await streamResponse(assistantMessage.id, userMessage.content)
    } catch (error) {
      console.error("Streaming error:", error)
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred"
      setErrorNotification(errorMessage)
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMessage.id
            ? {
                ...msg,
                content: "Error occurred while processing your request.",
                isStreaming: false,
              }
            : msg,
        ),
      )
    } finally {
      setIsLoading(false)
    }
  }

  const toggleDetails = (messageId: string) => {
    setDetailsOpen((prev) => ({
      ...prev,
      [messageId]: !prev[messageId],
    }))
  }

  const handleDownloadCode = async () => {
    if (!agentUuid) {
      setErrorNotification("No agent UUID found. Please save your profile first.")
      return
    }

    setIsDownloading(true)

    try {
      const blob = await agentApi.downloadAgent(agentUuid)

      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `agent-${agentUuid}.zip`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("Failed to download agent:", error)
      setErrorNotification("Failed to download agent code. Please try again.")
    } finally {
      setIsDownloading(false)
    }
  }

  const handleCreateAgent = async () => {
    if (!agentUuid) {
      setErrorNotification("No agent UUID found. Please save your profile first.")
      return
    }

    setIsCreatingAgent(true)

    try {
      const response = await agentApi.generateAgentInSnowflake(agentUuid)
      setAgentUrl(response.agent_url)
      setApiUrl(response.agent_url)
      localStorage.setItem("agent_url", response.agent_url)
      setShowSuccessModal(true)
    } catch (error) {
      console.error("Failed to create agent:", error)
      setErrorNotification(`Failed to create agent: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setIsCreatingAgent(false)
    }
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
          <Play className="w-4 h-4 text-primary" />
          <span>Step 4: Deploy & Test</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Deploy &{" "}
          <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Test</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">Deploy your agent and test its responses in real-time</p>
      </div>

      {/* Error Notification */}
      {errorNotification && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-500" />
            <p className="text-sm text-red-700">{errorNotification}</p>
          </div>
          <button onClick={() => setErrorNotification(null)} className="text-red-500 hover:text-red-700">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Deploy Section */}
      <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg text-center">
        <h3 className="text-xl font-bold mb-4">Ready to Deploy?</h3>
        <p className="text-muted-foreground mb-6">Download your agent configuration or deploy to Snowflake</p>
        <div className="flex gap-4 justify-center flex-wrap">
          <Button
            size="lg"
            onClick={handleCreateAgent}
            disabled={isCreatingAgent}
            className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90 text-white"
          >
            {isCreatingAgent ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 mr-2" />
                Deploy Agent
              </>
            )}
          </Button>
          <Button
            size="lg"
            onClick={handleDownloadCode}
            disabled={isDownloading}
            className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90 text-white"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Downloading...
              </>
            ) : (
              <>
                <Download className="w-5 h-5 mr-2" />
                Download Code
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Test Section */}
      <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg">
        {/* API URL Input */}
        <div className="mb-6 space-y-4">
          <div>
            <label htmlFor="api-url" className="block text-sm font-medium mb-2">
              Test API URL
            </label>
            <Input
              id="api-url"
              type="text"
              placeholder="Enter your API endpoint URL"
              className="bg-background"
              value={apiUrl}
              onChange={(e) => setApiUrl(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="bearer-token" className="block text-sm font-medium mb-2">
              Bearer Token (Optional)
            </label>
            <Input
              id="bearer-token"
              type="password"
              placeholder="Enter your Bearer token if required"
              className="bg-background"
              value={bearerToken}
              onChange={(e) => setBearerToken(e.target.value)}
            />
          </div>
        </div>

        {/* Chat Interface */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-500 rounded-lg flex items-center justify-center">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Test Your Agent</h3>
            <p className="text-sm text-muted-foreground">Try your agent in action</p>
          </div>
        </div>

        <div className="space-y-4 mb-6 h-96 overflow-y-auto border border-border rounded-lg p-4 bg-background/50">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <p className="text-sm">Start a conversation with your agent...</p>
            </div>
          ) : (
            messages.map((message) => (
              <div key={message.id}>
                {message.type === "user" ? (
                  <div className="flex justify-end">
                    <div className="bg-primary/20 border border-primary/30 rounded-2xl rounded-tr-sm px-4 py-3 max-w-[80%]">
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex justify-start">
                    <div className="bg-secondary/50 border border-border rounded-2xl rounded-tl-sm px-4 py-3 max-w-[90%] space-y-3">
                      {message.thinking && (
                        <div className="border rounded-lg p-3 bg-accent/10">
                          {message.isStreaming && (
                            <div className="flex items-center gap-2 mb-2">
                              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                              <span className="text-xs font-medium text-muted-foreground">Thinking...</span>
                            </div>
                          )}
                          {!message.isStreaming && (
                            <button
                              onClick={() => toggleDetails(message.id)}
                              className="flex items-center gap-2 text-xs text-primary hover:underline mb-2"
                            >
                              {detailsOpen[message.id] ? (
                                <ChevronUp className="w-3 h-3" />
                              ) : (
                                <ChevronDown className="w-3 h-3" />
                              )}
                              {detailsOpen[message.id] ? "Hide Details" : "Show Details"}
                            </button>
                          )}
                          {(message.isStreaming || detailsOpen[message.id]) && (
                            <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">
                              {message.thinking}
                            </p>
                          )}
                        </div>
                      )}

                      {message.content && (
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                      )}

                      {message.isStreaming && !message.content && !message.thinking && (
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                          <span className="text-xs text-muted-foreground">Loading...</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            placeholder="Type a message to test your agent..."
            className="bg-background"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isLoading}
          />
          <Button
            type="submit"
            size="icon"
            className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90 flex-shrink-0"
            disabled={isLoading}
          >
            {isLoading ? <Clock className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-card border border-border rounded-2xl p-8 max-w-sm w-full mx-4 shadow-2xl">
            <div className="flex justify-center mb-4">
              <div className="w-12 h-12 bg-green-500/20 border border-green-500/30 rounded-full flex items-center justify-center">
                <Check className="w-6 h-6 text-green-500" />
              </div>
            </div>
            <h2 className="text-xl font-bold text-center mb-2">Success!</h2>
            <p className="text-muted-foreground text-center mb-6">The agent was deployed successfully</p>
            <Button
              onClick={() => setShowSuccessModal(false)}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90"
            >
              OK
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
