"use client"

import { useState, useEffect } from "react"
import { User, Sparkles, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import type { LLMModel } from "@/services/api"

interface ProfileStepProps {
  onNext: (data: any) => void
  initialData?: any
}

export function ProfileStep({ onNext, initialData }: ProfileStepProps) {
  const [agentName, setAgentName] = useState(initialData?.agentName || "")
  const [description, setDescription] = useState(initialData?.description || "")
  const [selectedModel, setSelectedModel] = useState(initialData?.selectedModel || "")
  const [responseInstructions, setResponseInstructions] = useState(initialData?.responseInstructions || "")
  const [orchestrationInstructions, setOrchestrationInstructions] = useState(
    initialData?.orchestrationInstructions || "",
  )
  const [systemInstructions, setSystemInstructions] = useState(initialData?.systemInstructions || "")
  const [budgetSeconds, setBudgetSeconds] = useState(initialData?.budgetSeconds || 60)
  const [budgetTokens, setBudgetTokens] = useState(initialData?.budgetTokens || 1600)
  const [llmModels, setLlmModels] = useState<LLMModel[]>([])

  useEffect(() => {
    const storedModels = localStorage.getItem("llm_models")
    if (storedModels) {
      const models = JSON.parse(storedModels)
      setLlmModels(models)
      if (models.length > 0 && !selectedModel) {
        setSelectedModel(models[0].model_id)
      }
    }
  }, [])

  const handleNext = () => {
    if (!agentName.trim()) {
      alert("Please enter an agent name")
      return
    }

    const data = {
      agentName,
      description,
      selectedModel,
      responseInstructions,
      orchestrationInstructions,
      systemInstructions,
      budgetSeconds,
      budgetTokens,
    }

    console.log("[v0] ProfileStep - Passing data to wizard:", data)
    onNext(data)
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/60 backdrop-blur-xl border border-border rounded-full text-sm mb-4">
          <User className="w-4 h-4 text-primary" />
          <span>Step 1: Agent Profile</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Define Your{" "}
          <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Agent</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Configure your agent's basic information and capabilities
        </p>
      </div>

      {/* Form Card */}
      <div className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Agent Configuration</h3>
            <p className="text-sm text-muted-foreground">Set up your agent's basic information</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Agent Name */}
          <div className="space-y-2">
            <Label htmlFor="agent-name">Agent Name *</Label>
            <Input
              id="agent-name"
              placeholder="Enter agent name"
              value={agentName}
              onChange={(e) => setAgentName(e.target.value)}
              className="bg-background"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="agent-description">Description</Label>
            <Textarea
              id="agent-description"
              placeholder="Describe what your agent does"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-background resize-none"
            />
          </div>

          {/* Thread Memory */}
          <div className="flex items-center gap-6 py-2">
            <div className="flex items-center space-x-2">
              <Checkbox id="thread-memory" checked={true} disabled className="opacity-50 cursor-not-allowed" />
              <label htmlFor="thread-memory" className="text-sm font-medium leading-none opacity-70">
                Enable thread memory
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="long-term-memory" checked={false} disabled className="opacity-50 cursor-not-allowed" />
              <label htmlFor="long-term-memory" className="text-sm font-medium leading-none opacity-50">
                Enable Long Term Memory
              </label>
            </div>
          </div>

          {/* LLM Provider */}
          <div className="space-y-2">
            <Label>LLM Service Provider</Label>
            <Select defaultValue="Cortex">
              <SelectTrigger className="bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Cortex">Snowflake Cortex</SelectItem>
                <SelectItem value="EHAP">EHAP</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* AI Model */}
          <div className="space-y-2">
            <Label htmlFor="model">AI Model *</Label>
            <Select value={selectedModel} onValueChange={setSelectedModel}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select a model" />
              </SelectTrigger>
              <SelectContent>
                {llmModels.map((model) => (
                  <SelectItem key={model.model_id} value={model.model_id}>
                    {model.model_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Agent Instructions */}
          <div className="space-y-4 pt-4 border-t border-border">
            <div>
              <Label className="text-base font-semibold">Agent Instructions</Label>
              <p className="text-sm text-muted-foreground mt-1">Define how your agent should behave</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="system-instructions">System Instructions</Label>
                <Textarea
                  id="system-instructions"
                  placeholder="Core system-level instructions..."
                  rows={3}
                  value={systemInstructions}
                  onChange={(e) => setSystemInstructions(e.target.value)}
                  className="bg-background resize-none"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="orchestration-instructions">Orchestration Instructions</Label>
                <Textarea
                  id="orchestration-instructions"
                  placeholder="How the agent should use tools and coordinate tasks..."
                  rows={3}
                  value={orchestrationInstructions}
                  onChange={(e) => setOrchestrationInstructions(e.target.value)}
                  className="bg-background resize-none"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="response-instructions">Response Instructions</Label>
                <Textarea
                  id="response-instructions"
                  placeholder="How the agent should format and deliver responses..."
                  rows={3}
                  value={responseInstructions}
                  onChange={(e) => setResponseInstructions(e.target.value)}
                  className="bg-background resize-none"
                />
              </div>
            </div>
          </div>

          {/* Budget Config */}
          <div className="space-y-4 pt-4 border-t border-border">
            <div>
              <Label className="text-base font-semibold">Orchestration Configuration</Label>
              <p className="text-sm text-muted-foreground mt-1">Set budget limits for agent execution</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="budget-seconds">Budget (Seconds)</Label>
                <Input
                  id="budget-seconds"
                  type="number"
                  placeholder="60"
                  value={budgetSeconds}
                  onChange={(e) => setBudgetSeconds(Number(e.target.value))}
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="budget-tokens">Budget (Tokens)</Label>
                <Input
                  id="budget-tokens"
                  type="number"
                  placeholder="1600"
                  value={budgetTokens}
                  onChange={(e) => setBudgetTokens(Number(e.target.value))}
                  className="bg-background"
                />
              </div>
            </div>
          </div>

          <div className="pt-6 flex justify-center">
            <Button
              onClick={handleNext}
              disabled={!agentName.trim()}
              className="bg-gradient-to-r from-blue-600 to-blue-500 hover:opacity-90 text-white px-8 py-6 text-base font-semibold"
              size="lg"
            >
              <span>Next Step</span>
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
