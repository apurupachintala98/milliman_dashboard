// src/components/VersionBadge.tsx
import React from "react";
import versionData from "@/config/version.json";

const VersionBadge: React.FC = () => {
  const version = (versionData && versionData.version) || "0.0.0";

  return (
    <div
      aria-hidden="true"
      className="fixed right-4 bottom-3 z-50 pointer-events-none"
      style={{ fontSize: "0.65rem", opacity: 0.8 }}
    >
      <span className="text-gray-400 select-none">V {version}</span>
    </div>
  );
};

export default VersionBadge;
