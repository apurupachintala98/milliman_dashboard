import { BrowserRouter, Routes, Route } from "react-router-dom"
import { Toaster } from "@/components/ui/toaster"
import { Toaster as Sonner } from "@/components/ui/sonner"
import { TooltipProvider } from "@/components/ui/tooltip"
import Home from "../src/pages/Home"
import Login from "./pages/Login"
import Dashboard from "./pages/Dashboard"
import AgentBuilder from "../src/pages/Agent-builder"
import LangraphAgent from "../src/pages/Langgraph-agent-builder"
import NotFound from "./pages/NotFound"
import VersionBadge from "@/components/VersionBadge";

const App = () => (
  <TooltipProvider>
     {/* <Toaster position="top-right" richColors closeButton /> */}
    {/* <Sonner /> */}
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/agent-builder" element={<AgentBuilder />} />
        <Route path="/langraph-agent" element={<LangraphAgent />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <VersionBadge />
    </BrowserRouter>
  </TooltipProvider>
)

export default App
