"""
Setup script to initialize the project structure
Run this once before starting the application
"""
from pathlib import Path


def setup_project():
    """Create necessary directories and template files"""
    
    print("🚀 Setting up Snowflake Agent Manager...")
    print()
    
    # Create directories
    dirs = [
        'template',
        'template/utilities',
        'agents',
        'app',
        'app/models',
        'app/schemas',
        'app/crud',
        'app/api',
        'app/api/endpoints',
        'app/utils'
    ]
    
    for dir_name in dirs:
        Path(dir_name).mkdir(exist_ok=True, parents=True)
        print(f"✓ Created directory: {dir_name}")

    # Create agents/.gitkeep
    # Path('agents/.gitkeep').touch()
    # print("✓ Created: agents/.gitkeep")
    
    print()
    print("✅ Setup complete!")
    print()
    print("Next steps:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Run the application: python run.py")
    print("3. Access the API docs: http://localhost:8000/docs")


if __name__ == "__main__":
    setup_project()