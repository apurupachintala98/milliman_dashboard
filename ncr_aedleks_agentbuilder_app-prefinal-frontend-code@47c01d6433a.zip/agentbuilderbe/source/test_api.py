"""
Test script for Snowflake Agent Manager API
Demonstrates the complete workflow with updated schemas
"""
import requests
import json

BASE_URL = "http://localhost:8000"


def print_response(title, response):
    """Pretty print API response"""
    print(f"\n{'='*60}")
    print(f"{title}")
    print(f"{'='*60}")
    print(f"Status Code: {response.status_code}")
    try:
        print(f"Response: {json.dumps(response.json(), indent=2)}")
    except:
        print(f"Response: {response.text}")
    print(f"{'='*60}\n")


def test_workflow():
    """Test the complete agent creation workflow"""
    

    # Step 1: Health check
    print("\nStep 1: Health Check")
    response = requests.get(f"{BASE_URL}/")
    print_response("Health Check", response)

    if response.status_code != 200:
        print("❌ Failed to check health")
        return
    print(f"✅ Health checked successfully")
    

    # Step 2: Create a new agent
    print("\nStep 2: Create Agent")
    create_data = {"user_id": "test_user_001"}
    response = requests.post(f"{BASE_URL}/api/agent/create", json=create_data)
    print_response("Create Agent", response)
    
    if response.status_code != 200:
        print("❌ Failed to create agent")
        return
    
    agent_uuid = response.json()["agent_uuid"]
    print(f"✅ Agent created with UUID: {agent_uuid}")
    

    # Step 3: Get available LLMs
    print("\nStep 3: Get Available LLMs")
    response = requests.get(f"{BASE_URL}/api/llms")
    print_response("Available LLMs", response)
    
    if response.status_code != 200:
        print("❌ Failed to get LLMs")
        return
    
    llms = response.json()
    print(f"✅ Found {len(llms)} available LLMs")
    

    # Step 4: Configure the agent with new schema
    print("\nStep 4: Configure Agent")
    agent_config = {
        "agent_name": "Customer Support Agent",
        "description": "AI agent for customer inquiries and support tickets",
        "model_config": {
            "orchestration": "claude-4-sonnet"
        },
        "agent_instructions": {
            "response": "Respond concisely and clearly.",
            "orchestration": "Use the search and analyst tools as needed.",
            "system": "You are a helpful customer support agent."
        },
        "orchestration_config": {
            "budget": {
                "seconds": 60,
                "tokens": 1600
            }
        }
    }
    response = requests.post(
        f"{BASE_URL}/api/agent/{agent_uuid}/configure",
        json=agent_config
    )
    print_response("Configure Agent", response)
    
    if response.status_code != 200:
        print("❌ Failed to configure agent")
        return
    
    print("✅ Agent configured successfully")


    # Step 5: Configure Runtime (runtime-configure)
    print("\nStep 5: Configure Runtime")
    runtime_config = {
        "agent_name": "Customer Support Agent",
        "application_name": "Customer Support App",
        "user_identity": "test_user_001",
        # "db": "POC_SPC_SNOWPARK_DB",
        # "schema": "DATA_SCHEMA"
    }

    response = requests.post(
        f"{BASE_URL}/api/agent/{agent_uuid}/runtime-configure",
        json=runtime_config
    )
    print_response("Runtime Configure", response)

    if response.status_code != 200:
        print("❌ Failed to configure runtime")
        return

    print("✅ Runtime configured successfully")
    

    # Step 6: Add tools with new schema
    print("\nStep 6: Add Tools Configuration")
    tool_config = {
        "tool_choice": {
            "type": "auto",        # options: auto, required, tool
            "name": []             # Only needed if type = tool
        },
        "tools": [
            {
                # "tool_spec": {
                "type": "cortex_analyst_text_to_sql",  # options: cortex_analyst_text_to_sql, generic
                "name": "clm_payment_recovery_status", # Must be unique
                "description": "Agent to help with current Payment recovery inclusion/exclusion status for Facets claims."
                # }
            }
        ],
        "tool_resources": {
            "clm_payment_recovery_status": {
                "semantic_model_file": "@D01_COC.COC_DTI.COC_DTI_CORTEX/CAO_DENIEDYETPAID.yaml",
                "execution_environment": {
                    "type": "warehouse",
                    "warehouse": "D01_COC_DTI_APP_WH",
                    "query_timeout": 120
                }
            }
        }
    }
    response = requests.post(
        f"{BASE_URL}/api/agent/{agent_uuid}/tools",
        json=tool_config
    )
    print_response("Add Tools", response)
    
    if response.status_code != 200:
        print("❌ Failed to add tools")
        return
    
    print("✅ Tools added successfully")
    
    # Get agent details
    print("\nRetrieving Agent Details")
    response = requests.get(f"{BASE_URL}/api/agent/{agent_uuid}")
    print_response("Agent Details", response)
    

    # Step 7: Download agent
    print("\nStep 7: Download Agent")
    response = requests.get(f"{BASE_URL}/api/agent/{agent_uuid}/download")
    
    if response.status_code == 200:
        filename = f"agent_{agent_uuid}.zip"
        with open(filename, 'wb') as f:
            f.write(response.content)
        print(f"✅ Agent downloaded successfully: {filename}")
        print(f"   File size: {len(response.content)} bytes")
    else:
        print("❌ Failed to download agent")
        print_response("Download Error", response)

    
     # STEP 8: Generate Agent in Snowflake
    print("\nStep 8: Generate Agent in Snowflake")
    response = requests.post(f"{BASE_URL}/api/agent/{agent_uuid}/generate_agent_in_snowflake")
    print_response("Generate Agent in Snowflake", response)
    
    if response.status_code == 200:
        print("✅ Agent successfully registered in Snowflake (simulated).")
    else:
        print("❌ Snowflake generation failed.")
    

    # # List all agents
    # print("\nListing All Agents")
    # response = requests.get(f"{BASE_URL}/api/agents")
    # print_response("All Agents", response)
    
    # # List agents by user
    # print("\nListing Agents by User")
    # response = requests.get(f"{BASE_URL}/api/agents?user_id=test_user_001")
    # print_response("User's Agents", response)
    
    
    print("\n" + "="*60)
    print("🎉 All tests completed successfully!")
    print("="*60)


def test_error_cases():
    """Test error handling"""
    print("\n" + "="*60)
    print("Testing Error Cases")
    print("="*60)
    
    # Test with non-existent agent
    print("\nTest 1: Non-existent agent")
    response = requests.get(f"{BASE_URL}/api/agent/non-existent-uuid")
    print_response("Non-existent Agent", response)
    
    # Test configure without creating agent first
    print("\nTest 2: Configure non-existent agent")
    agent_config = {
        "model_config": {"orchestration": "claude-4-sonnet"},
        "agent_instructions": {
            "response": "Test",
            "orchestration": "Test",
            "system": "Test"
        },
        "orchestration_config": {
            "budget": {"seconds": 60, "tokens": 1600}
        }
    }
    response = requests.post(
        f"{BASE_URL}/api/agent/fake-uuid/configure",
        json=agent_config
    )
    print_response("Configure Non-existent Agent", response)
    
    print("\n✅ Error handling tests completed")


if __name__ == "__main__":
    print("🚀 Starting Snowflake Agent Manager API Tests\n")
    print("Make sure the API server is running at http://localhost:8000")
    print("Start the server with: python run.py\n")
    
    input("Press Enter to start the tests...")
    
    try:
        test_workflow()
        test_error_cases()
        
    except requests.exceptions.ConnectionError:
        print("\n❌ Error: Could not connect to the API server")
        print("Please make sure the server is running: python run.py")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()