
# Notes:
1. Filenames and APIs naming conventions -> Prefix 'csa' (Cortex Single Agent) and 'lsa' (LangGraph Single Agent).
2. No APIs will end with a '/'.


# Snowflake Single Agent Manager

A FastAPI-based system for managing Snowflake Cortex AI agents with SQLite database backend.

## Features

- Create and manage multiple AI agents
- Configure agents with different Snowflake Cortex LLMs
- Add tools to agents
- Download complete agent configurations as ZIP files
- SQLite database for data persistence

## Required Environment Variables
- env_name
- GENAI_PATH
- SF_PAT_TOKEN

## Installations

### 1. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. Create Template Directory Structure

```bash
mkdir -p template
mkdir -p agents
```

## Database Setup

The database is automatically initialized on first run with these tables:
- `user_agent` - Maps users to their agents
- `agent_details` - Stores agent configurations
- `tool_details` - Stores tool configurations
- `available_snowflake_cortex_llms` - Lists available LLMs

Sample Snowflake Cortex LLMs are pre-populated:
- Llama 3.1 8B, 70B, 405B
- Mistral Large 2
- Mixtral 8x7B
- Snowflake Arctic

## Running the Application

```bash
python main.py
```

Or using uvicorn directly:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at: `http://localhost:8000`

Interactive API docs: `http://localhost:8000/docs`

## API Endpoints

### 1. Health Check
```http
GET /
```

### 2. Create Agent (Step 2)
```http
POST /api/agent/create
Content-Type: application/json

{
  "user_id": "user123"
}

Response:
{
  "agent_uuid": "uuid-here",
  "message": "Agent created successfully"
}
```

### 3. Get Available LLMs (Step 3)
```http
GET /api/llms

Response:
[
  {
    "model_id": "llama3.1-8b",
    "model_name": "Llama 3.1 8B"
  },
  ...
]
```

### 4. Configure Agent (Step 4)
```http
POST /api/agent/{agent_uuid}/configure
Content-Type: application/json

{
  "agent_name": "Customer Service Agent",
  "description": "Handles customer inquiries",
  "model_id": "llama3.1-8b",
  "system_prompt": "You are a helpful customer service agent.",
  "temperature": 0.7,
  "max_tokens": 1000
}
```

### 5. Add Tool to Agent (Step 5)
```http
POST /api/agent/{agent_uuid}/tools
Content-Type: application/json

{
  "tool_name": "search_database",
  "tool_description": "Search the customer database",
  "tool_type": "database",
  "parameters": {
    "query": "string",
    "limit": "integer"
  }
}
```

### 6. Download Agent Code (Step 6)
```http
GET /api/agent/{agent_uuid}/download

Response: ZIP file containing agent configuration
```

### Additional Endpoints

#### Get Agent Details
```http
GET /api/agent/{agent_uuid}
```

#### List All Agents
```http
GET /api/agents?user_id=user123
```

## Usage Flow

1. **Create an agent**
   ```bash
   curl -X POST http://localhost:8000/api/agent/create \
     -H "Content-Type: application/json" \
     -d '{"user_id": "user123"}'
   ```

2. **Get available LLMs**
   ```bash
   curl http://localhost:8000/api/llms
   ```

3. **Configure the agent**
   ```bash
   curl -X POST http://localhost:8000/api/agent/{agent_uuid}/configure \
     -H "Content-Type: application/json" \
     -d '{
       "agent_name": "My Agent",
       "description": "Test agent",
       "model_id": "llama3.1-8b",
       "system_prompt": "You are helpful.",
       "temperature": 0.7,
       "max_tokens": 1000
     }'
   ```

4. **Add tools**
   ```bash
   curl -X POST http://localhost:8000/api/agent/{agent_uuid}/tools \
     -H "Content-Type: application/json" \
     -d '{
       "tool_name": "calculator",
       "tool_description": "Performs calculations",
       "tool_type": "function",
       "parameters": {"expression": "string"}
     }'
   ```

5. **Download the agent**
   ```bash
   curl -O http://localhost:8000/api/agent/{agent_uuid}/download
   ```

## Project Structure

```
.
├── main.py                    # Main FastAPI application
├── requirements.txt           # Python dependencies
├── agent_manager.db          # SQLite database (auto-created)
├── template/                 # Template folder for new agents
│   ├── README.md
│   └── __init__.py
└── agents/                   # Created agent folders
    └── {agent_uuid}/
        ├── agent.yaml       # Agent configuration
        └── tools.yaml       # Tools configuration
```

## Migration to Snowflake (Future)

The current implementation uses SQLite for easy setup. To migrate to Snowflake:

1. Replace `sqlite3` connections with Snowflake connector
2. Update SQL syntax for Snowflake compatibility
3. Modify BLOB storage approach if needed
4. Update connection configuration

## Error Handling

All endpoints return appropriate HTTP status codes:
- `200` - Success
- `404` - Resource not found
- `500` - Internal server error

## Notes

- Agent UUIDs are automatically generated
- Template folder must exist before creating agents
- ZIP files are automatically cleaned up after download
- All timestamps are in UTC

## License

MIT