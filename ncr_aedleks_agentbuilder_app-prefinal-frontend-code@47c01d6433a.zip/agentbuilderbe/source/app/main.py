"""
Main FastAPI application
"""
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import PROJECT_NAME, VERSION, API_V1_PREFIX
from app.database.database import init_db, SessionLocal
from app.database.crud.user import init_user
from app.database.crud.ssa_llm import init_default_llms
from app.database.crud.lsa_crud import init_default_providers, init_default_llms_by_provider
from app.api.endpoints import login, ssa_agent, ssa_llm, ssa_tool, lsa_api


# Create FastAPI app
app = FastAPI(
    title=PROJECT_NAME,
    version=VERSION,
    description="APIs for managing Agent Builder Application",
)

@app.on_event("startup")
def on_startup():
    # init_db()  # Commented out - tables should already exist in production DB
    # Commented out initialization functions for production - data should already exist
    # db = SessionLocal()
    # try:
    #     init_user(db)
    #     init_default_llms(db)
    #     init_default_providers(db)
    #     init_default_llms_by_provider(db)
    # finally:
    #     db.close()
    pass  # No initialization needed in production

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(login.router, prefix=f"{API_V1_PREFIX}/login", tags=["login"])

app.include_router(ssa_agent.router, prefix=f"{API_V1_PREFIX}/agent", tags=["agents"])
app.include_router(ssa_tool.router, prefix=f"{API_V1_PREFIX}/agent", tags=["tools"])
app.include_router(ssa_llm.router, prefix=API_V1_PREFIX, tags=["llms"])

app.include_router(lsa_api.router, prefix=f"{API_V1_PREFIX}/lsa")

@app.get("/")
def root():
    """
    Root endpoint
    """
    return {
        "status": "ok",
        "message": "Agent Builder Root API",
        "version": VERSION
    }


@app.get("/health")
def health_check():
    """
    Health check endpoint
    """
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
