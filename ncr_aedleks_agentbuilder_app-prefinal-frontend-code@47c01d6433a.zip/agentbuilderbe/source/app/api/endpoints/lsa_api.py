"""
LangGraph Agent Management APIs
Handles provider/model retrieval, agent creation, memory setup, MCP tool configuration,
and codebase download for Single LangGraph Agent
"""

import os
import uuid
import logging
import yaml
from typing import List
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.database.crud.lsa_crud import (
    get_all_providers,
    get_llms_by_provider,
    create_agent,
    create_agent_profile,
    create_memory_config,
    create_mcp_tool
)
from app.api.schemas.lsa_api_schemas import (
    Provider,
    LLM,
    AgentProfile,
    AgentProfileResponse,
    MemoryConfig,
    MemoryConfigResponse,
    MCPTool,
    MCPToolResponse,
    BackendConfigSettings,
    FrontendConfigSettings
)
from app.utils.lsa_utils import (
    copy_template_to_agent_folder,
    create_agent_zip,
    cleanup_zip,
    write_agent_yaml,
    write_memory_yaml,
    write_tool_yaml,
    update_frontend_config,
    load_config
)
from deploy.my_service_deploy import deploy
from app.config import LSA_AGENTS_DIR, LSA_SERVERS_PATH, LSA_CONFIG_PATH, LSA_DEFAULT_INPUTS

logger = logging.getLogger(__name__)
router = APIRouter()


# ============================================================
# 1. Get all LLM Providers
# ============================================================

@router.get("/providers", response_model=List[Provider], tags=["LSA LLM Providers"])
def list_all_providers(db: Session = Depends(get_db)):
    """
    Get list of all LLM providers (Snowflake Cortex, OpenAI, Anthropic, etc.)
    """
    try:
        # providers = get_all_providers(db)
        providers = [
            {"provider_id": "cortex", "provider_name": "Snowflake Cortex"},
            {"provider_id": "openai", "provider_name": "OpenAI"},
            {"provider_id": "anthropic", "provider_name": "Anthropic"},
            {"provider_id": "google_gemini", "provider_name": "Google Gemini"},
            {"provider_id": "ehap", "provider_name": "EHAP"}
        ]
        logger.info(f"List of available providers: {providers}")
        return providers
    except Exception as e:
        logger.exception(f"Failed to fetch providers: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 2. Get LLMs by Provider
# ============================================================

@router.get("/providers/{provider_id}/llms", response_model=List[LLM], tags=["LSA LLM Providers"])
def list_llms_by_provider(provider_id: str, db: Session = Depends(get_db)):
    """
    Get all LLMs for a selected provider from local DB
    """
    try:
        # llms = get_llms_by_provider(db, provider_id)
        llms_of_all_providers = {
            "cortex": [
                {"model_id": "openai-gpt-5-chat", "model_name": "OpenAI GPT 5 Chat"},
                {"model_id": "claude-4-sonnet", "model_name": "Claude 4 Sonnet"},
                {"model_id": "mistral-large", "model_name": "Mistral Large"},
                {"model_id": "llama3-70b", "model_name": "Llama 3 70B"},
                {"model_id": "llama3-8b", "model_name": "Llama 3 8B"},
                {"model_id": "mixtral-8x7b", "model_name": "Mixtral 8x7B"},
            ],
            "openai": [
                {"model_id": "gpt-4", "model_name": "GPT-4"},
                {"model_id": "gpt-4-turbo", "model_name": "GPT-4 Turbo"},
                {"model_id": "gpt-3.5-turbo", "model_name": "GPT-3.5 Turbo"},
            ],
            "anthropic": [
                {"model_id": "claude-3-opus", "model_name": "Claude 3 Opus"},
                {"model_id": "claude-3-sonnet", "model_name": "Claude 3 Sonnet"},
                {"model_id": "claude-3-haiku", "model_name": "Claude 3 Haiku"},
            ],
            "google_gemini": [
                {"model_id": "gemini-1.5-pro", "model_name": "Gemini 1.5 Pro"},
                {"model_id": "gemini-1.5-flash", "model_name": "Gemini 1.5 Flash"},
            ],
            "ehap": [
                {"model_id": "ehap-base", "model_name": "EHAP Base Model"},
                {"model_id": "ehap-advanced", "model_name": "EHAP Advanced Model"},
            ],
        }
        llms = llms_of_all_providers[provider_id]
        logger.info(f"List of available LLMs: {llms}")
        return llms
    except Exception as e:
        logger.exception(f"Failed to fetch LLMs for provider {provider_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 3. Create LangGraph Agent
# ============================================================

@router.post("/agent/create", response_model=AgentProfileResponse, tags=["LSA Agent Configuration"])
def create_langgraph_agent(agent: AgentProfile, db: Session = Depends(get_db)):
    """
    Create a new LangGraph Agent:
    - Generate UUID
    - Copy template folder
    - Create agent_config.yaml
    - Save agent details to DB
    """
    try:
        # Generate unique UUID
        agent_uuid = str(uuid.uuid4())
        logger.info(f"Creating LangGraph Agent with UUID {agent_uuid}")

        # Copy template folder for agent
        agent_folder = copy_template_to_agent_folder(agent_uuid, agent.agent_name)

        # Generate agent_config.yaml
        write_agent_yaml(agent_folder, agent)

        # Save agent record to DB
        # db_agent = create_agent(db, agent_uuid=agent_uuid, user_id="default_user")

        # Save agent profile (JSON serialized)
        # agent_json = agent.model_dump_json().encode("utf-8")
        # create_agent_profile(
        #     db,
        #     agent_id=db_agent.agent_uuid,
        #     llm_model_id=None,
        #     agent_json=agent_json
        # )

        return AgentProfileResponse(
            agent_uuid=agent_uuid,
            message=f"LangGraph Agent '{agent.agent_name}' created successfully"
        )

    except Exception as e:
        logger.exception(f"Failed to create LangGraph Agent: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 4. Create / Configure Memory
# ============================================================

@router.post("/agent/{agent_uuid}/memory", response_model=MemoryConfigResponse, tags=["LSA Memory Configuration"])
def configure_agent_memory(agent_uuid: str, memory: MemoryConfig, db: Session = Depends(get_db)):
    """
    Configure memory for the agent:
    - short_term_memory_needed
    - long_term_memory_needed
    - long_term_memory_config
    - DB connection details
    - Generates memory_config.yaml
    """
    try:
        # Verify agent exists
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        # Generate memory YAML
        write_memory_yaml(agent_folder, memory)

        # # Save memory configuration JSON
        # memory_json = memory.model_dump_json().encode("utf-8")
        # create_memory_config(db, agent_id=agent_uuid, memory_config_json=memory_json)

        return MemoryConfigResponse(
            success=True,
            message="Memory configuration created successfully"
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to configure memory for agent {agent_uuid}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 5. Configure MCP Tools
#   a. Upload STDIO Tool File
#   b. Add/Update MCP Tool
# ============================================================

@router.post("/agent/{agent_uuid}/tools/upload", response_model=dict, tags=["LSA MCP Tools"])
def upload_stdio_tool_file(
    agent_uuid: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload a Python file for STDIO-based MCP Tool.
    - Places the uploaded file inside /agents/{agent_uuid}/source/tools/
    - Returns the destination path.
    """
    try:
        # Verify agent folder exists
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        # Ensure tools subfolder exists
        mcp_tools_subfolder = os.path.join(agent_folder, LSA_SERVERS_PATH)
        os.makedirs(mcp_tools_subfolder, exist_ok=True)

        # Validate file type (must be .py)
        filename = file.filename
        if not filename.lower().endswith(".py"):
            raise HTTPException(status_code=400, detail="Only Python (.py) files are allowed")

        # Destination path
        destination_path = os.path.join(mcp_tools_subfolder, filename)

        # Save the uploaded file
        with open(destination_path, "wb") as f:
            f.write(file.file.read())
        logger.info(f"Uploaded STDIO tool file saved at: {destination_path}")

        # Relative path from agent folder
        relative_path_start = os.path.join(agent_folder, "agentic-backend")
        tool_relative_path = os.path.relpath(destination_path, start=relative_path_start)
        logger.info(f"Relative path of STDIO tool file saved in config: {tool_relative_path}")

        # Optional: store metadata in DB if needed
        # e.g., you could record the filename in a new MCPToolFile table later

        return {
            "status": "success",
            "agent_uuid": agent_uuid,
            "file_name": filename,
            "destination_path": tool_relative_path
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to upload STDIO tool file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/agent/{agent_uuid}/tools", response_model=MCPToolResponse, tags=["LSA MCP Tools"])
def configure_mcp_tools(agent_uuid: str, tool: MCPTool, db: Session = Depends(get_db)):
    """
    Configure MCP tools (streamable_http or stdio)
    - Generate tool_config.yaml
    - Save tool details in DB
    """
    try:
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        # Generate tool YAML
        write_tool_yaml(agent_folder, tool)

        # # Save tool JSON to DB
        # tool_json = tool.model_dump_json().encode("utf-8")
        # create_mcp_tool(db, agent_id=agent_uuid, mcp_tool_json=tool_json)

        return MCPToolResponse(
            message=f"Tool '{tool.mcp_tools}' configured successfully",
            agent_uuid=agent_uuid
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to configure MCP tools: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 6. Configure Backend Settings
# ============================================================

@router.post("/agent/{agent_uuid}/backend", tags=["LSA Backend"])
def configure_backend(
    agent_uuid: str,
    settings: BackendConfigSettings,
):
    """
    Configure backend settings inside the agent's config file.
    - Updates or creates config.yaml inside the agent folder.
    """
    try:
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        # Config file path
        backend_config_path = os.path.join(agent_folder, LSA_CONFIG_PATH, "backend_config.yaml")

        # Load existing config if present
        if os.path.exists(backend_config_path):
            with open(backend_config_path, "r") as f:
                current_config = yaml.safe_load(f) or {}
        else:
            current_config = {}

        # Update or set host/port value
        current_config.update({
            "host": settings.host,
            "port": settings.port,
        })

        # Write back to YAML
        with open(backend_config_path, "w") as f:
            yaml.dump(current_config, f, default_flow_style=False, sort_keys=False)

        logger.info(f"Backend config updated for agent {agent_uuid} at {backend_config_path}")

        return {
            "status": "success",
            "agent_uuid": agent_uuid,
            "message": "Backend settings updated successfully",
            "backend_config_file": backend_config_path
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to update backend config for agent {agent_uuid}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    

# ============================================================
# 7. Configure Frontend Settings
# ============================================================

@router.post("/agent/{agent_uuid}/frontend", tags=["LSA Frontend"])
def configure_frontend(
    agent_uuid: str,
    settings: FrontendConfigSettings,
):
    """
    Configure frontend settings inside the agent's config file.
    - Updates or creates config.yaml inside the agent folder.
    """
    try:
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        # Config file path
        frontend_config_path = os.path.join(agent_folder, LSA_CONFIG_PATH, "frontend_config.yaml")

        # Load existing config if present
        if os.path.exists(frontend_config_path):
            with open(frontend_config_path, "r") as f:
                current_config = yaml.safe_load(f) or {}
        else:
            current_config = {}

        # Update or set port values
        current_config.update({
            "port": settings.port,
        })

        # Write back to YAML
        with open(frontend_config_path, "w") as f:
            yaml.dump(current_config, f, default_flow_style=False, sort_keys=False)

        logger.info(f"Frontend config updated for agent {agent_uuid} at {frontend_config_path}")

        update_frontend_config(agent_folder, str(settings.port))
        logger.info(f"Updated frontend port to {str(settings.port)} at package.json")

        return {
            "status": "success",
            "agent_uuid": agent_uuid,
            "message": "Frontend settings updated successfully",
            "frontend_config_file": frontend_config_path
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to update frontend config for agent {agent_uuid}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 8. Download Agent Codebase as ZIP
# ============================================================

@router.get("/agent/{agent_uuid}/download", tags=["LSA ZIP Download"])
def download_agent_codebase(agent_uuid: str):
    """
    Download the complete agent codebase as a ZIP file.
    """
    try:
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        # Create ZIP archive
        zip_path = create_agent_zip(agent_uuid)

        # Return ZIP file
        return FileResponse(
            zip_path,
            media_type="application/zip",
            filename=f"lsa_agent_{agent_uuid}.zip",
            background=lambda: cleanup_zip(zip_path)
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to download agent codebase: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    

# ============================================================
# 9. Get Default Inputs to prepopulate the UI
# ============================================================

@router.get("/default_inputs", tags=["LSA Default Inputs"])
def get_default_inputs():
    """
    Returns default inputs to prepopulate the UI.
    """
    return LSA_DEFAULT_INPUTS


# ============================================================
# 10. Deploy API returns LSA Backend and Frontend path
# ============================================================

@router.get("/agent/{agent_uuid}/deploy", tags=["Deploy LSA Agent"])
def deploy_agent(agent_uuid: str):
    """
    Returns LSA Backend and Frontend path for deployment.
    """
    try:
        # Verify agent exists
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise HTTPException(status_code=404, detail="Agent folder not found")

        agent_config_path = os.path.join(agent_folder, "agentic-backend", "source", "config", "agent_config.yaml")
        agent_config = load_config(agent_config_path)
        agent_name = agent_config.get("agent_name", "dummy_deployed_agent")

        backend_path = os.path.join(agent_folder, "agentic-backend")
        frontend_path = os.path.join(agent_folder, "agentic-frontend")

        # Backend Service Configuration
        BACKEND_SERVICE_CONFIG = {
            'service_name': f"{agent_name.lower()}be",
            'environment': 'dev',
            'container_port': 9000,             # Needs to be dyanamic (from backend_config)
            'cpu_limit': '500m',
            'memory_limit': '1Gi',
            'replicas': 2,
            'image_tag': 'latest',
            'app_source_path': f'/app/temp/lsa_agents/{agent_uuid}/agentic-backend'
        }
        
        # Frontend Service Configuration
        FRONTEND_SERVICE_CONFIG = {
            'service_name': f"{agent_name.lower()}",
            'environment': 'dev',
            'container_port': 4000,             # Needs to be dyanamic (from frontend_config)
            'cpu_limit': '500m',
            'memory_limit': '1Gi',
            'replicas': 2,
            'image_tag': 'latest',
            'app_source_path': f'/app/temp/lsa_agents/{agent_uuid}/agentic-frontend'
        }

        GIT_CREDENTIALS = {
            'username': 'AL14414',
            'token': 'Jan@2026'
        }
        
        # Deploy backend service
        logger.info(f"Deploying backend service for agent {agent_uuid}")
        deploy('AL14414', BACKEND_SERVICE_CONFIG, GIT_CREDENTIALS)
        
        # Deploy frontend service
        # logger.info(f"Deploying frontend service for agent {agent_uuid}")
        # deploy('AL14414', FRONTEND_SERVICE_CONFIG, GIT_CREDENTIALS)

        return {
            "backend_path": backend_path,
            "frontend_path": frontend_path,
            "agent_name": agent_name,
            "agent_uuid": agent_uuid
        }

    except HTTPException:
        raise
    
    except Exception as e:
        logger.exception(f"Failed to deploy agent {agent_uuid}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    