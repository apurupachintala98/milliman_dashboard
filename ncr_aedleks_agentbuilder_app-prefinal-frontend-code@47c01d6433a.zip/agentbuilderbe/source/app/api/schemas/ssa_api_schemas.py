"""
Pydantic schemas for request/response validation (Updated for new YAML structure)
"""
from datetime import datetime
from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field, EmailStr
from typing import Optional


# Login Schemas
class LoginRequest(BaseModel):
    email: EmailStr
    password: Optional[str] = None
    isSso: bool = False

class LoginResponse(BaseModel):
    token: str

class UserBase(BaseModel):
    username: str
    email: EmailStr

    class Config:
        orm_mode = True


# Agent Creation Schemas
class AgentCreate(BaseModel):
    """Schema for creating a new agent"""
    user_id: str = Field(..., description="User ID who owns the agent")

class AgentResponse(BaseModel):
    """Schema for agent creation response"""
    agent_uuid: str
    message: str


# Agent Configuration Schemas
class ModelConfig(BaseModel):
    orchestration: str = Field(..., description="Model orchestration identifier (e.g., claude-4-sonnet)")

class AgentInstructions(BaseModel):
    response: str = Field(default="Respond concisely and clearly.")
    orchestration: str = Field(default="Use the search and analyst tools as needed.")
    system: str = Field(default="You are a helpful assistant.")

class Budget(BaseModel):
    seconds: int = Field(default=60)
    tokens: int = Field(default=1600)

class Features(BaseModel):
    thread_memory: bool = Field(default=True)

class OrchestrationConfig(BaseModel):
    budget: Budget
    features: Optional[Features] = None

class AgentConfig(BaseModel):
    """Schema for agent configuration details (matches YAML structure)"""
    agent_name: Optional[str] = Field(None, description="Name of the agent")
    description: Optional[str] = Field(None, description="Description of the agent")
    llm_config: ModelConfig = Field(..., alias="model_config")
    agent_instructions: AgentInstructions
    orchestration_config: OrchestrationConfig

    model_config = {
        "populate_by_name": True,
        "protected_namespaces": ()  # disables 'model_' prefix warning entirely
    }


# Agent Runtime Configuration Schema
class AgentRuntimeConfig(BaseModel):
    """Schema for configuring runtime parameters when rewriting the agent file"""
    agent_name: str = Field(..., description="Agent name, e.g., customer_support_agent")
    # db: str = Field(default="POC_SPC_SNOWPARK_DB", description="Database name to be used by the agent")
    # schema: str = Field(default="DATA_SCHEMA", description="Schema name associated with the agent")
    application_name: str = Field(default="DEAFULT_APPLICATION", description="Application invoking the agent")
    user_identity: str = Field(..., description="User identity or ID of the invoker")
    db: Optional[str] = Field(..., description="Database name to be used by the agent")
    schema: Optional[str] = Field(..., description="Schema name associated with the agent")

# Generate Snowflake Agent Response Schema
class GenerateSnowflakeAgentResponse(BaseModel):
    """Schema for generate agent in Snowflake response"""
    agent_url: str


# For future use
class AgentDetailsResponse(BaseModel):
    """Schema for agent details response"""
    agent_uuid: str
    agent_details: Dict[str, Any]
    tools: List[Dict[str, Any]]

# For future use
class AgentListItem(BaseModel):
    """Schema for agent list item"""
    agent_uuid: str
    user_id: str
    created_at: datetime

    model_config = {
        "from_attributes": True
    }

# For future use
class AgentListResponse(BaseModel):
    """Schema for agent list response"""
    agents: List[AgentListItem]


# TOOL SCHEMAS
class ToolChoice(BaseModel):
    """Schema for tool choice configuration (top-level tools.yaml key)"""
    type: Literal["auto", "required", "tool"] = "auto"
    name: Optional[List[str]] = Field(default_factory=list, description="Tool names (only if type=tool)")

class ToolSpecDetails(BaseModel):
    """Defines metadata for each tool."""
    type: str = Field(..., description="Tool type (e.g., cortex_analyst_text_to_sql, generic)")
    name: str = Field(..., description="Unique name of the tool")
    description: str = Field(..., description="Detailed description of what the tool does")
    db_name: Optional[str] = Field(default="Default", description="Database name")
    # Input schema reference (pydantic model)
    input_schema: Optional[str] = Field(default="Default", description="Pydantic model name defining tool input schema")

# class ToolSpec(BaseModel):
#     """Wrapper for tool_spec"""
#     tool_spec: ToolSpecDetails

class ExecutionEnvironment(BaseModel):
    """Defines the execution environment for a tool resource."""
    type: str = Field(..., description="Environment type (e.g., warehouse)")
    warehouse: Optional[str] = Field(None, description="Warehouse name")
    query_timeout: Optional[int] = Field(120, description="Query timeout in seconds")

class ToolResource(BaseModel):
    """Defines resources and environment for a specific tool."""
    semantic_model_file: Optional[str] = Field(None, description="Path to semantic model file")
    db_name: Optional[str] = Field(default="Default", description="Database name")
    execution_environment: Optional[ExecutionEnvironment] = Field(None, description="Execution environment details")
    input_schema: Optional[str] = Field(default="Default", description="Pydantic model name defining tool input schema")

class ToolConfig(BaseModel):
    """Top-level schema combining tool choice, tool definitions, and resources."""
    # sesn_id: str = Field(..., description="Session ID")
    tool_choice: Optional[ToolChoice] = Field(None, description="Tool selection configuration") # was = None before
    tools: List[ToolSpecDetails] = Field(default_factory=list, description="List of tools")
    tool_resources: Dict[str, ToolResource]= Field(default_factory=dict, description="Dynamic tool resources keyed by tool name")

class ToolResponse(BaseModel):
    """Schema for tool response"""
    message: str
    agent_uuid: str


# LLM SCHEMAS
class LLMModel(BaseModel):
    """Schema for LLM model"""
    id: str = Field(..., alias="model_id")
    name: str = Field(..., alias="model_name")

    model_config = {
        "from_attributes": True,
        "protected_namespaces": (),
        "populate_by_name": True  # allows passing id/name OR model_id/model_name
    }


class LLMListResponse(BaseModel):
    """Schema for LLM list response"""
    models: List[LLMModel]


# GENERAL RESPONSE
class MessageResponse(BaseModel):
    """Generic message response"""
    message: str
    agent_uuid: Optional[str] = None


# Deploy Agent Schemas
# class DeployAgentConfig(BaseModel):
#     """Schema for deploy agent configuration"""
#     agent_uuid: str

class DeployAgentResponse(BaseModel):
    """Schema for deploy agent response"""
    agent_uuid: str
    deployment_status: str


# New Session and Agent Config Schemas
class SessionCreateRequest(BaseModel):
    """Schema for creating a session"""
    sesn_id: str
    user_id: str
    aplctn_cd: str

class SessionCreateResponse(BaseModel):
    """Schema for session creation response"""
    message: str
    sesn_id: str

class AgentConfigCreateRequest(BaseModel):
    """Schema for creating agent configuration"""
    # sesn_id: str
    agent_name: str
    db: str = Field(default="Default", description="Database name")
    schema: str = Field(default="Default", description="Schema name")
    application_name: Optional[str] = Field(default="default-app", description="Application name")
    description: Optional[str] = None
    llm_config: ModelConfig = Field(alias="model_config")
    agent_instructions: AgentInstructions
    orchestration_config: OrchestrationConfig
    features: Optional[Features] = None
    

class AgentConfigCreateResponse(BaseModel):
    """Schema for agent configuration creation response"""
    message: str
    agnt_id: str
    sesn_id: str

class ToolConfigRequest(BaseModel):
    """Schema for tool configuration request including context"""
    tool_config: ToolConfig
    sesn_id: str
    # db: str


# Session Detail Schemas for AGNT_BLDR_SESN_DTL table
class SessionDetailResponse(BaseModel):
    """Schema for session detail response"""
    sesn_id: str
    user_id: Optional[str] = None
    created_dtm: datetime
    udated_dtm: datetime
    schma_nm: Optional[str] = None

class SessionDetailUpdateRequest(BaseModel):
    """Schema for session detail update request"""
    user_id: Optional[str] = None
    schma_nm: Optional[str] = None

class SessionDetailUpdateResponse(BaseModel):
    """Schema for session detail update response"""
    message: str
    sesn_id: str
    user_id: Optional[str] = None
    schma_nm: Optional[str] = None
    # schema: str
