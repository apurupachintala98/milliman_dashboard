# app/schemas/langgraph_schemas.py

from typing import Optional, Literal, List, Union
from pydantic import BaseModel, Field


# Snowflake Cortex Auth Config Schemas
class SnowflakeCortexAuthConfig(BaseModel):
    """Holds authentication and execution-context details (Snowflake/DB/etc)."""
    base_url: str
    pat_token: str


# EHAP Config Schemas
class EHAPAuthConfig(BaseModel):
    pass


# LLM Schemas for prepopulated list
class Provider(BaseModel):
    provider_id: str
    provider_name: str

class LLM(BaseModel):
    model_id: str
    model_name: str

class LLMModelConfig(BaseModel):
    """Controls for the LLM model itself."""
    temperature: Optional[float] = Field(default=0.1, ge=0, le=1)
    max_tokens: Optional[int] = Field(default=1024, gt=0)
    # top_p: Optional[float] = Field(default=1.0, ge=0, le=1)
    # frequency_penalty: Optional[float] = Field(default=0.0, ge=-2, le=2)
    # presence_penalty: Optional[float] = Field(default=0.0, ge=-2, le=2)
    # stop_sequences: Optional[List[str]] = None
    # streaming: Optional[bool] = False
    # response_format: Optional[str] = Field(default="text", examples=["text", "json"])

class LLMConfig(BaseModel):
    model_id: str = Field(..., description="Model id of the LLM")
    model_name: str = Field(..., examples=["gpt-4.1", "claude-3", "mistral", "llama3"])
    provider_name: str = Field(..., description="Name of the selected LLM provider")
    llm_auth: Union[SnowflakeCortexAuthConfig] = Field(..., description="LLM Provider Authorization Details")
    llm_model_config: Optional[LLMModelConfig] = Field(..., description="LLM Model Configuration Details")
    

# Agent Schemas
class AgentInstructions(BaseModel):
    system: str
    orchestration: str
    response_structure: str

class AgentProfile(BaseModel):
    agent_name: str
    agent_description: str
    agent_instructions: AgentInstructions
    llm_config: LLMConfig

class AgentProfileResponse(BaseModel):
    agent_uuid: str
    message: str


# Memory Schemas
class LongTermMemoryConifg(BaseModel):
    semantic_user_profile: bool = True
    episodic_user_experience: bool = True
    procedural_user_instructions: bool = True
    custom: bool = False

class MemoryConfig(BaseModel):
    short_term_memory_needed: bool = True
    long_term_memory_needed: bool = True
    long_term_memory_config: Optional[LongTermMemoryConifg] = None

    # Postgres Connection Details
    db_type: str = Field(default="postgres", description="Type of Database. Default is Postgres DB.")
    db_host: str 
    db_port: int 
    db_username: str
    db_password: str
    db_name: str
    db_schema: str

class MemoryConfigResponse(BaseModel):
    success: bool
    message: str


# MCP Tool Schemas
class STDIOConfig(BaseModel):
    command: Optional[str] = "python"
    args: Optional[str]

class StreamableHTTPConfig(BaseModel):
    url: Optional[str]
    config: Optional[str]

class MCPToolConfig(BaseModel):
    transport: Literal["streamable_http", "stdio"] = "streamable_http"
    name: str
    description: str
    config: Union[StreamableHTTPConfig, STDIOConfig]

class MCPTool(BaseModel):
    mcp_tools: List[MCPToolConfig]

class MCPToolResponse(BaseModel):
    message: str
    agent_uuid: str


# Backend
class BackendConfigSettings(BaseModel):
    host: str
    port: int


# Frontend
class FrontendConfigSettings(BaseModel):
    port: int
    