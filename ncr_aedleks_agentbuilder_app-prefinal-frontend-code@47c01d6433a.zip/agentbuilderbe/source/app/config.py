"""
Configuration settings for the Agent Builder application.
Loads settings from config.yaml
"""
import os
from pathlib import Path
import yaml

# Base directory
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = BASE_DIR / "app" / "config.yaml"

# Load YAML
with open(CONFIG_FILE, "r") as f:
    _config = yaml.safe_load(f)

# -------------------------------
# Database
# -------------------------------
DATABASE_URL = os.getenv("DATABASE_URL", _config["database"]["url"])
DATABASE_URL = DATABASE_URL.replace("${BASE_DIR}", BASE_DIR.as_posix())

# -------------------------------
# Directories
# -------------------------------
TEMPLATE_DIR = BASE_DIR / _config["directories"]["template_dir"]
SSA_TEMPLATE_DIR = TEMPLATE_DIR / _config["directories"]["ssa_template_dir"]
LSA_TEMPLATE_DIR = TEMPLATE_DIR / _config["directories"]["lsa_template_dir"]

# AGENTS_DIR = Path("/app") / _config["directories"]["agents_dir"]
AGENTS_DIR = BASE_DIR / _config["directories"]["agents_dir"]
SSA_AGENTS_DIR = AGENTS_DIR / _config["directories"]["ssa_agents_dir"]
LSA_AGENTS_DIR = AGENTS_DIR / _config["directories"]["lsa_agents_dir"]

# Create all directories if they don't exist
for path in (AGENTS_DIR, SSA_AGENTS_DIR, LSA_AGENTS_DIR):
    path.mkdir(parents=True, exist_ok=True)

# Intermediate paths (relative)
LSA_CONFIG_PATH = _config["intermediate_path"]["config"]
LSA_SERVERS_PATH = _config["intermediate_path"]["servers"]
LSA_CERTS_PATH = _config["intermediate_path"]["certs"]
LSA_PACKAGE_JSON_PATH = _config["intermediate_path"]["package_json"]
LSA_CONFIG_JSON_PATH = _config["intermediate_path"]["config_json"]

# Certificate path (relative)
LSA_CERT_PATH = _config["cert_path"]

# -------------------------------
# Default Inputs
# -------------------------------
LSA_DEFAULT_INPUTS = _config["ui_default_inputs"]["lsa"]

# -------------------------------
# API Settings
# -------------------------------
API_V1_PREFIX = _config["api"]["prefix"]
PROJECT_NAME = _config["api"]["project_name"]
VERSION = _config["api"]["version"]

# -------------------------------
# Auth / JWT Settings
# -------------------------------
SECRET_KEY = os.getenv("SECRET_KEY", _config["auth"]["secret_key"])
ENCODING_ALGORITHM = os.getenv("ENCODING_ALGORITHM", _config["auth"]["encoding_algorithm"])
TOKEN_EXPIRY_IN_DAYS = int(os.getenv("TOKEN_EXPIRY_IN_DAYS", _config["auth"]["token_expiry_in_days"]))

# -------------------------------
# Credentials
# -------------------------------
USERNAME = os.getenv("APP_USERNAME", _config["credentials"]["username"])
PASSWORD = os.getenv("APP_PASSWORD", _config["credentials"]["password"])
