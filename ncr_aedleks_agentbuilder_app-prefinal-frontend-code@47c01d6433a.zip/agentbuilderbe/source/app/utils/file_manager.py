"""
File management utilities
"""
import os
import shutil
import yaml

from app.config import SSA_TEMPLATE_DIR, SSA_AGENTS_DIR


def copy_template_to_agent_folder(agent_uuid: str, agent_name: str) -> str:
    """
    Copy template folder to agent-specific folder
    Rename 'cao' folder to agent_name and CAO_AGENT.py accordingly
    Flush or create tool.yaml to a blank default state
    Returns the path to the new agent folder
    """
    agent_folder = os.path.join(SSA_AGENTS_DIR, agent_uuid)
    
    # Remove existing folder if it exists
    if os.path.exists(agent_folder):
        shutil.rmtree(agent_folder)
    
    # Copy template to new folder
    shutil.copytree(SSA_TEMPLATE_DIR, agent_folder)

    # Point to agent source folder
    agent_source_folder = os.path.join(agent_folder, "source")

    # Rename cao folder to agent_name
    cao_folder = os.path.join(agent_source_folder, "cao")
    new_folder = os.path.join(agent_source_folder, agent_name)
    
    if os.path.exists(cao_folder):
        os.rename(cao_folder, new_folder)
        
        # Rename CAO_AGENT.py
        old_file = os.path.join(new_folder, "CAO_AGENT.py")
        new_file = os.path.join(new_folder, f"{agent_name.upper()}_AGENT.py")
        if os.path.exists(old_file):
            os.rename(old_file, new_file)

        # Flush or create tool.yaml with clean structure
        tool_yaml_path = os.path.join(new_folder, "tool.yaml")
        blank_tool_config = {
            "tool_choice": {
                "type": "auto",   # options: auto, required, tool
                "name": []        # only needed if type=tool
            },
            "tools": [],          # empty list — no tools added yet
            "tool_resources": {}  # empty dict — no resources
        }
        with open(tool_yaml_path, "w", encoding="utf-8") as f:
            yaml.dump(blank_tool_config, f, default_flow_style=False, sort_keys=False)

        # Optional (for debugging/logging)
        # print(f"tool.yaml reset successfully at: {tool_yaml_path}")
    
    return agent_folder


def create_agent_zip(agent_uuid: str) -> str:
    """
    Create a zip file of the agent folder
    Returns the path to the zip file
    """
    agent_folder = os.path.join(SSA_AGENTS_DIR, agent_uuid)
    zip_path = f"{agent_folder}.zip"
    
    # Remove existing zip if it exists
    if os.path.exists(zip_path):
        os.remove(zip_path)
    
    # Create zip file
    shutil.make_archive(agent_folder, 'zip', agent_folder)
    
    return zip_path


def cleanup_zip(zip_path: str):
    """
    Delete the zip file
    """
    if os.path.exists(zip_path):
        os.remove(zip_path)