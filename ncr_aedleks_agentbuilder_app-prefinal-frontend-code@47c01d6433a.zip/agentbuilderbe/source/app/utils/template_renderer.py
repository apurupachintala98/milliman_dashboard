
import os


def render_agent_template(template_path: str, replacements: dict) -> str:
    """
    Reads a template file and replaces placeholders like {{key}} with given values.

    Args:
        template_path (str): Path to the template file (e.g., CAO_AGENT.py)
        replacements (dict): Dict of key-value pairs to replace in the template

    Returns:
        str: Rendered template content as string
    """
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    for key, value in replacements.items():
        content = content.replace(f"{{{{{key}}}}}", str(value))

    return content


def write_rendered_template(template_dir: str, agent_folder: str, agent_name: str, replacements: dict,
                            template_file: str, output_file: str) -> str:
    """
    Renders a template and writes it to the agent's folder.
    """
    template_path = os.path.join(template_dir, template_file)
    if not os.path.exists(template_path):
        raise FileNotFoundError(f"Template not found at {template_path}")
    
    # Determine target directory based on file type
    if template_file == "Dockerfile":
        # Dockerfile goes in the root agent folder
        agent_name_folder = agent_folder
        os.makedirs(agent_name_folder, exist_ok=True)
    elif agent_name:
        # Other files with agent_name go in <agent_folder>/source/<agent_name>
        agent_name_folder = os.path.join(agent_folder, "source", agent_name)
        os.makedirs(agent_name_folder, exist_ok=True)
    else:
        # Other files without agent_name go in <agent_folder>/source
        agent_name_folder = os.path.join(agent_folder, "source")
        os.makedirs(agent_name_folder, exist_ok=True)

    output_path = os.path.join(agent_name_folder, output_file)

    rendered_content = render_agent_template(template_path, replacements)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(rendered_content)

    return output_path