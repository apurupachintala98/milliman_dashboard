"""
LangGraph Single Agent (LSA) Utility Functions
Handles file operations, YAML generation, and ZIP packaging for LangGraph Agents
"""

import os
import shutil
import yaml
import logging
import json
from pathlib import Path

logger = logging.getLogger(__name__)

from app.api.schemas.lsa_api_schemas import (
    AgentProfile,
    MemoryConfig,
    MCPTool,
)

# Base paths (import from config if defined)
from app.config import LSA_TEMPLATE_DIR, LSA_AGENTS_DIR, LSA_CONFIG_PATH
from app.config import LSA_CERTS_PATH, LSA_CERT_PATH
from app.config import LSA_PACKAGE_JSON_PATH, LSA_CONFIG_JSON_PATH

# ============================================================
# 1. Copy Template Folder
# ============================================================

def copy_template_to_agent_folder(agent_uuid: str, agent_name: str) -> str:
    """
    Copy the base LangGraph agent template folder into the destination agent folder.
    Returns the new agent folder path.
    """
    try:
        destination_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if os.path.exists(destination_folder):
            logger.warning(f"LSA Agent folder already exists: {destination_folder}")
            return destination_folder

        if not os.path.exists(LSA_TEMPLATE_DIR):
            raise FileNotFoundError(f"LSA Template directory not found: {LSA_TEMPLATE_DIR}")

        shutil.copytree(LSA_TEMPLATE_DIR, destination_folder)
        logger.info(f"Copied LSA template to {destination_folder}")

        # Optional: rename folder or update agent name in files if needed
        return destination_folder

    except Exception as e:
        logger.exception(f"Failed to copy LSA template: {e}")
        raise


# ============================================================
# 2. Create Agent ZIP
# ============================================================

def create_agent_zip(agent_uuid: str) -> str:
    """
    Create a ZIP archive of the LSAS agent's folder for download.
    File name format: lsa_agent_{agent_uuid}.zip
    Returns the path of the generated ZIP file.
    """
    try:
        agent_folder = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        if not os.path.exists(agent_folder):
            raise FileNotFoundError(f"LSA Agent folder not found: {agent_folder}")

        zip_base_path = os.path.join(LSA_AGENTS_DIR, agent_uuid)
        zip_path = shutil.make_archive(zip_base_path, "zip", agent_folder)

        logger.info(f"Created LSA ZIP file: {zip_path}")
        return zip_path

    except Exception as e:
        logger.exception(f"Failed to create LSA agent ZIP: {e}")
        raise


# ============================================================
# 3. Cleanup Temporary ZIP
# ============================================================

def cleanup_zip(zip_path: str):
    """
    Delete the ZIP file after download is complete.
    """
    try:
        if os.path.exists(zip_path):
            os.remove(zip_path)
            logger.info(f"Deleted temporary LSA ZIP: {zip_path}")
    except Exception as e:
        logger.warning(f"Failed to delete LSA ZIP file {zip_path}: {e}")


# ============================================================
# 4. Write Agent YAML (create or update)
# ============================================================

def write_agent_yaml(agent_folder: str, details: AgentProfile):
    """
    Create or update agent_config.yaml for LangGraph Agent.
    - Creates if not exists, updates if exists.
    Also copies the certificate file into the agent folder.
    """
    try:
        agent_yaml_path = Path(agent_folder) / LSA_CONFIG_PATH / "agent_config.yaml"
        logger.info(f"Agent yaml path: {agent_yaml_path}\n")

        llm_config = details.llm_config
        llm_auth = llm_config.llm_auth
        llm_model_config = llm_config.llm_model_config
        
        def get_project_root():
            # Find the highest directory that contains your source folder
            current = Path(__file__).resolve()
            for parent in current.parents:
                if (parent / "lsa_utils.py").exists():
                    return parent
            return Path(__file__).resolve().parent  # fallback

        # Source certificate path (where it exists in your backend)
        root_path = get_project_root()
        logger.info(f"Root Path Generated for Cert Path: {root_path}")
        source_cert_path = root_path / Path(LSA_CERT_PATH)
        logger.info(f"Full source cert path: {source_cert_path}\n")
        if not source_cert_path.exists():
            raise FileNotFoundError(f"Certificate not found: {source_cert_path}")

        # Destination folder inside the agent (this is where we’ll copy cert.pem)
        certs_folder_path = Path(agent_folder) / LSA_CERTS_PATH
        logger.info(f"Destination cert folder path to be created: {certs_folder_path}\n")
        certs_folder_path.mkdir(parents=True, exist_ok=True)
        
        # Destination file path
        dest_cert_path = certs_folder_path / source_cert_path.name
        logger.info(f"Destination cert path: {dest_cert_path}\n")

        # Copy certificate file
        shutil.copy2(source_cert_path, dest_cert_path)
        logger.info(f"Certificate copied to: {dest_cert_path}\n")

        # Relative path from agent folder
        relative_path_start = os.path.join(agent_folder, "agentic-backend")
        cert_path = os.path.relpath(dest_cert_path, start=relative_path_start)

        # Build YAML Content
        agent_config = {
            "agent_name": details.agent_name.strip(),
            "agent_description": details.agent_description,
            "llm_config": {
                "model_id": llm_config.model_id,
                "model_name": llm_config.model_name,
                "provider_name": llm_config.provider_name,
                "llm_auth": {
                    "base_url": llm_auth.base_url,
                    "pat_token": llm_auth.pat_token.strip(),
                    "cert_path": cert_path
                },
                "llm_model_config": (
                    llm_model_config.model_dump() if llm_model_config else {}
                ),
            },
            "agent_instructions": {
                "system": details.agent_instructions.system,
                "orchestration": details.agent_instructions.orchestration,
                "response_structure": details.agent_instructions.response_structure,
            },
        }

        with open(agent_yaml_path, "w") as f:
            yaml.dump(agent_config, f, default_flow_style=False, sort_keys=False)

        logger.info(f"agent_config.yaml written at: {agent_yaml_path}")
        logger.info(f"Cert folder path: {dest_cert_path}")
    except Exception as e:
        logger.exception(f"Failed to write agent_config.yaml: {e}")
        raise


# ============================================================
# 5. Write Memory YAML (create or update)
# ============================================================

def write_memory_yaml(agent_folder: str, memory: MemoryConfig):
    """
    Create or update memory_config.yaml for LangGraph Agent.
    - Creates if not exists, updates if exists.
    """
    try:
        memory_yaml_path = os.path.join(agent_folder, LSA_CONFIG_PATH, "memory_config.yaml")

        memory_config = {
            "short_term_memory_needed": memory.short_term_memory_needed,
            "long_term_memory_needed": memory.long_term_memory_needed,
            "long_term_memory_config": (
                memory.long_term_memory_config.model_dump()
                if memory.long_term_memory_config
                else {}
            ),
            "database": {
                "type": memory.db_type,
                "hostname": memory.db_host,
                "port": memory.db_port,
                "username": memory.db_username,
                "password": memory.db_password.strip(),
                "database_name": memory.db_name,
                "database_schema": memory.db_schema,
            },
        }

        with open(memory_yaml_path, "w") as f:
            yaml.dump(memory_config, f, default_flow_style=False, sort_keys=False)

        logger.info(f"memory_config.yaml written at: {memory_yaml_path}")
    except Exception as e:
        logger.exception(f"Failed to write memory_config.yaml: {e}")
        raise


# ============================================================
# 6. Write Tool YAML (create or update, supports multiple tools)
# ============================================================

def write_tool_yaml(agent_folder: str, tools: MCPTool):
    """
    Create or update tool_config.yaml for LangGraph Agent.
    - Creates if not exists.
    - Updates existing tools or adds new ones.
    - Accepts multiple tools via MCPTool schema.
    """
    try:
        tool_yaml_path = os.path.join(agent_folder, LSA_CONFIG_PATH, "tool_config.yaml")

        # Load existing YAML if present
        if os.path.exists(tool_yaml_path):
            with open(tool_yaml_path, "r") as f:
                existing_config = yaml.safe_load(f) or {}
        else:
            existing_config = {"tools": []}

        tools_list = existing_config.get("tools", [])
        existing_tool_names = {t.get("name"): t for t in tools_list if "name" in t}

        added, updated = 0, 0

        for tool in tools.mcp_tools:
            if tool.name in existing_tool_names:
                existing_tool_names[tool.name].update({
                    "transport": tool.transport,
                    "description": tool.description,
                    "config": tool.config.model_dump(),
                })
                updated += 1
            else:
                tools_list.append({
                    "transport": tool.transport,
                    "name": tool.name,
                    "description": tool.description,
                    "config": tool.config.model_dump(),
                })
                added += 1

        # Rebuild final tool list
        existing_config["tools"] = list(existing_tool_names.values()) + [
            t for t in tools_list if t.get("name") not in existing_tool_names
        ]

        with open(tool_yaml_path, "w") as f:
            yaml.dump(existing_config, f, default_flow_style=False, sort_keys=False)

        logger.info(
            f"tool_config.yaml updated at {tool_yaml_path} (Added: {added}, Updated: {updated})"
        )
    except Exception as e:
        logger.exception(f"Failed to write tool_config.yaml: {e}")
        raise


# ============================================================
# 7. Update Frontend Config
# ============================================================

def update_frontend_config(agent_folder, port):
    """
    Update Frontend Configuration to package.json and config.json
    """
    try:
        frontend_package_json_path = Path(agent_folder) / LSA_PACKAGE_JSON_PATH
        with open(frontend_package_json_path, "r") as f:
            package_json = json.load(f)

        package_json["scripts"]["dev"] = f"next dev -p {port}"
        package_json["scripts"]["start"] = f"next start -p {port}"

        with open(frontend_package_json_path, "w") as f:
            json.dump(package_json, f, indent=2)

        # Extract Backend Host and Post from Backend Config YAML File
        backend_config_path = Path(agent_folder) / LSA_CONFIG_PATH / "backend_config.yaml"
        if os.path.exists(backend_config_path):
            with open(backend_config_path, "r") as f:
                backend_config = yaml.safe_load(f) or {}
        backend_host = str(backend_config["host"]).strip()
        backend_port = str(backend_config["port"]).strip()

        frontend_config_json_path = Path(agent_folder) / LSA_CONFIG_JSON_PATH
        with open(frontend_config_json_path, "r") as f:
            config_json = json.load(f)

        config_json["apiUrl"] = f"http://{backend_host}:{backend_port}agent/chat"

        with open(frontend_config_json_path, "w") as f:
            json.dump(config_json, f, indent=2)

        logger.info(f"Updated frontend port to {port} at {frontend_package_json_path}")
        logger.info(f"Updated backend host and port to {backend_host} and {backend_port} at {frontend_config_json_path}")
    except Exception as e:
        logger.exception(f"Failed to modify frontend port at {frontend_package_json_path} and backend host and port at {frontend_config_json_path}: {e}")
        raise


# ============================================================
# 8. Load Config
# ============================================================

def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    # Filter out comment lines (starting with # after optional whitespace)
    filtered_lines = [
        line for line in lines
        if not line.strip().startswith('#')
    ]
    content = ''.join(filtered_lines)
    
    return yaml.safe_load(content)