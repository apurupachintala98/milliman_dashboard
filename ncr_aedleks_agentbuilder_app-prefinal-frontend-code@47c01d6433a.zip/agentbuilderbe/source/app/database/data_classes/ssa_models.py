"""
SQLAlchemy models for database tables
"""
from datetime import datetime
from sqlalchemy import Column, String, LargeBinary, DateTime, Integer, ForeignKey, Text, TIMESTAMP
from sqlalchemy.orm import relationship

from app.database.database import Base

class User(Base):
    """Users table"""
    __tablename__ = "users"

    username = Column(String(50), primary_key=True, index=True)
    email = Column(String(100), unique=True, index=True, nullable=False)
    password = Column(String(100), nullable=True)
    first_name = Column(String(50), nullable=True)
    last_name = Column(String(50), nullable=True)
    user_role = Column(String(50), nullable=True)
    date_created = Column(DateTime, default=datetime.utcnow)
    date_updated = Column(DateTime, nullable=True)
    date_expired = Column(DateTime, nullable=True)
    group_id = Column(Text, nullable=True)
    current_login_date = Column(TIMESTAMP, nullable=True)
    last_login_date = Column(TIMESTAMP, nullable=True)


class UserAgent(Base):
    """User Agent mapping table"""
    __tablename__ = "user_agent"

    agent_uuid = Column(String(36), primary_key=True, index=True)
    user_id = Column(String(50), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    agent_details = relationship("AgentDetails", back_populates="user_agent", uselist=False)
    tools = relationship("ToolDetails", back_populates="user_agent")


class AgentDetails(Base):
    """Agent details table"""
    __tablename__ = "agent_details"

    agent_id = Column(String(36), ForeignKey("user_agent.agent_uuid"), primary_key=True, index=True)
    agent_json = Column(LargeBinary, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user_agent = relationship("UserAgent", back_populates="agent_details")


class ToolDetails(Base):
    """Tool details table"""
    __tablename__ = "tool_details"

    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(String(36), ForeignKey("user_agent.agent_uuid"), nullable=False, index=True)
    tool_json = Column(LargeBinary, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    user_agent = relationship("UserAgent", back_populates="tools")


class SnowflakeCortexLLM(Base):
    """Snowflake Cortex LLMs table"""
    __tablename__ = "snowflake_cortex_llms"

    model_id = Column(String(36), primary_key=True, index=True)
    model_name = Column(String(100), nullable=False)


# --- New models for agent builder session/config tables ---
from sqlalchemy import JSON

class EdlGenaiAgntBldrSesnCnfgrn(Base):
    """Session configuration table"""
    __tablename__ = "edl_genai_agnt_bldr_sesn_cnfgrn"

    sesn_id = Column(String(36), primary_key=True, index=True)
    user_id = Column(String(100), default="Default")
    creat_dtm = Column(DateTime, default=datetime.utcnow)
    last_updt_dtm = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    aplctn_cd = Column(String(100), default="Default")

    # Relationships
    agents = relationship("EdlGenaiCrtxAgntCnfgrn", back_populates="session")
    tools = relationship("EdlGenaiCrtxAgntToolCnfgrn", back_populates="session")
    resources = relationship("EdlGenaiCrtxAgntToolRsrcCnfgrn", back_populates="session")


class EdlGenaiCrtxAgntCnfgrn(Base):
    """Agent configuration table"""
    __tablename__ = "edl_genai_crtx_agnt_cnfgrn"

    agnt_id = Column(String(36), primary_key=True, index=True)
    sesn_id = Column(String(36), ForeignKey("edl_genai_agnt_bldr_sesn_cnfgrn.sesn_id"), nullable=False)
    db_nm = Column(String(100), nullable=False)
    schma_nm = Column(String(100), nullable=False)
    agnt_nm = Column(String(100), nullable=True)
    agnt_desc = Column(Text, nullable=True)
    orch_llm_prvdr = Column(String(100), nullable=True)
    llm_nm = Column(String(100), nullable=True)
    orch_config = Column(JSON, nullable=True)
    creat_dtm = Column(DateTime, default=datetime.utcnow)
    last_updt_dtm = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    session = relationship("EdlGenaiAgntBldrSesnCnfgrn", back_populates="agents")


class EdlGenaiCrtxAgntToolCnfgrn(Base):
    """Agent tool configuration table"""
    __tablename__ = "edl_genai_crtx_agnt_tool_cnfgrn"

    agnt_id = Column(String(36), ForeignKey("edl_genai_crtx_agnt_cnfgrn.agnt_id"), primary_key=True)
    tool_id = Column(String(36), primary_key=True)
    sesn_id = Column(String(36), ForeignKey("edl_genai_agnt_bldr_sesn_cnfgrn.sesn_id"), nullable=False)
    db_nm = Column(String(100), nullable=False)
    schma_nm = Column(String(100), nullable=False)
    tool_nm = Column(String(100), nullable=False)
    tool_desc = Column(Text, nullable=True)
    tool_config = Column(JSON, nullable=True)
    creat_dtm = Column(DateTime, default=datetime.utcnow)
    last_updt_dtm = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    session = relationship("EdlGenaiAgntBldrSesnCnfgrn", back_populates="tools")


class EdlGenaiCrtxAgntToolRsrcCnfgrn(Base):
    """Agent tool resource configuration table"""
    __tablename__ = "edl_genai_crtx_agnt_tool_rsrc_cnfgrn"

    agnt_id = Column(String(36), primary_key=True)
    tool_id = Column(String(36), primary_key=True)
    rsrc_id = Column(String(36), primary_key=True)
    sesn_id = Column(String(36), ForeignKey("edl_genai_agnt_bldr_sesn_cnfgrn.sesn_id"), nullable=False)
    db_nm = Column(String(100), nullable=False)
    schma_nm = Column(String(100), nullable=False)
    rsrc_config = Column(JSON, nullable=True)
    creat_dtm = Column(DateTime, default=datetime.utcnow)
    last_updt_dtm = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    session = relationship("EdlGenaiAgntBldrSesnCnfgrn", back_populates="resources")


# class AgntBldrSesnDtl(Base):
#     """Agent Builder Session Details table"""
#     __tablename__ = "edl_genai_agnt_bldr_sesn_cnfgrn"

#     sesn_id = Column(String(36), primary_key=True, index=True)  # UUID
#     user_id = Column(String(100), default="Default")
#     created_dtm = Column(DateTime, default=datetime.utcnow)
#     udated_dtm = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
#     schma_nm = Column(String(100), default="Default")

