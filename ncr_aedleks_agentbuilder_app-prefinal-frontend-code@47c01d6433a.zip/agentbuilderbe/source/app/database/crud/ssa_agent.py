"""
CRUD operations for agents
"""
import json
import uuid
from typing import Optional, List
from sqlalchemy.orm import Session

from app.database.data_classes.ssa_models import UserAgent, AgentDetails, EdlGenaiCrtxAgntCnfgrn, EdlGenaiAgntBldrSesnCnfgrn
from app.api.schemas.ssa_api_schemas import AgentCreate, AgentConfig


def create_agent(db: Session, agent: AgentCreate) -> UserAgent:
    """
    Create a new agent with UUID
    """
    agent_uuid = str(uuid.uuid4())
    db_agent = UserAgent(
        agent_uuid=agent_uuid,
        user_id=agent.user_id
    )
    db.add(db_agent)
    db.commit()
    db.refresh(db_agent)
    return db_agent


def get_agent(db: Session, agent_uuid: str) -> Optional[UserAgent]:
    """
    Get agent by UUID
    """
    return db.query(EdlGenaiCrtxAgntCnfgrn).filter(EdlGenaiCrtxAgntCnfgrn.agnt_id == agent_uuid).first()


def create_agent_details(db: Session, agent_uuid: str, details: AgentConfig) -> AgentDetails:
    """
    Create or update agent details
    """
    agent_json = json.dumps(details.model_dump(by_alias=True)).encode()
    
    # Check if details already exist
    existing = db.query(AgentDetails).filter(AgentDetails.agent_id == agent_uuid).first()
    
    if existing:
        # Update existing
        existing.agent_json = agent_json
        db.commit()
        db.refresh(existing)
        return existing
    else:
        # Create new
        db_details = AgentDetails(
            agent_id=agent_uuid,
            agent_json=agent_json
        )
        db.add(db_details)
        db.commit()
        db.refresh(db_details)
        return db_details
    

# For future use
def get_agents_by_user(db: Session, user_id: str) -> List[UserAgent]:
    """
    Get all agents for a specific user
    """
    return db.query(UserAgent).filter(UserAgent.user_id == user_id).all()


# For future use
def get_all_agents(db: Session, skip: int = 0, limit: int = 100) -> List[EdlGenaiCrtxAgntCnfgrn]:
    """
    Get all agents with pagination
    """
    return db.query(EdlGenaiCrtxAgntCnfgrn).offset(skip).limit(limit).all()


def get_agent_details(db: Session, agent_uuid: str) -> Optional[dict]:
    """
    Get agent details as dictionary from agent configuration
    """
    config = db.query(EdlGenaiCrtxAgntCnfgrn).filter(EdlGenaiCrtxAgntCnfgrn.agnt_id == agent_uuid).first()
    if config:
        return {
            "agent_name": config.agnt_nm,
            "agent_description": config.agnt_desc,
            "db_name": config.db_nm,
            "schema_name": config.schma_nm,
            "orchestration_llm_provider": config.orch_llm_prvdr,
            "llm_name": config.llm_nm,
            "orchestration_config": config.orch_config
        }
    return None


# For future use
def delete_agent(db: Session, agent_uuid: str) -> bool:
    """
    Delete an agent and all related data
    """
    agent = get_agent(db, agent_uuid)
    if agent:
        db.delete(agent)
        db.commit()
        return True
    return False


# CRUD functions for new session and agent config tables
def create_session(db: Session, sesn_id: str, user_id: str, aplctn_cd: str):
    """
    Create a new session entry in EdlGenaiAgntBldrSesnCnfgrn
    """
    # from app.database.data_classes.ssa_models import EdlGenaiAgntBldrSesnCnfgrn
    
    existing = db.query(EdlGenaiAgntBldrSesnCnfgrn).filter_by(sesn_id=sesn_id).first()
    if existing:
        return None  # Session already exists
    
    session = EdlGenaiAgntBldrSesnCnfgrn(
        sesn_id=sesn_id,
        user_id=user_id,
        aplctn_cd=aplctn_cd
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


def get_session(db: Session, sesn_id: str):
    """
    Get session by session ID
    """
    # from app.database.data_classes.ssa_models import EdlGenaiAgntBldrSesnCnfgrn
    
    return db.query(EdlGenaiAgntBldrSesnCnfgrn).filter_by(sesn_id=sesn_id).first()


def create_agent_config(db: Session, agnt_id: str, sesn_id: str, db_nm: str, schma_nm: str, 
                       agnt_nm: str = None, agnt_desc: str = None, orch_llm_prvdr: str = None,
                       llm_nm: str = None, orch_config: dict = None):
    """
    Create agent configuration in EdlGenaiCrtxAgntCnfgrn
    """
    # from app.database.data_classes.ssa_models import EdlGenaiCrtxAgntCnfgrn
    
    agent_config = EdlGenaiCrtxAgntCnfgrn(
        agnt_id=agnt_id,
        sesn_id=sesn_id,
        db_nm=db_nm,
        schma_nm=schma_nm,
        agnt_nm=agnt_nm,
        agnt_desc=agnt_desc,
        orch_llm_prvdr=orch_llm_prvdr,
        llm_nm=llm_nm,
        orch_config=orch_config
    )
    
    db.add(agent_config)
    db.commit()
    db.refresh(agent_config)
    return agent_config


def get_agent_config(db: Session, agnt_id: str):
    """
    Get agent configuration by agent ID
    """
    # from app.database.data_classes.ssa_models import EdlGenaiCrtxAgntCnfgrn
    
    return db.query(EdlGenaiCrtxAgntCnfgrn).filter_by(agnt_id=agnt_id).first()


# CRUD functions for AgntBldrSesnDtl table
def create_agent_builder_session_detail(db: Session, sesn_id: str, user_id: str = None, schma_nm: str = None):
    """
    Create a new agent builder session detail entry
    """
    session_detail = EdlGenaiAgntBldrSesnCnfgrn(
        sesn_id=sesn_id
    )
    
    db.add(session_detail)
    db.commit()
    db.refresh(session_detail)
    return session_detail


def get_agent_builder_session_detail(db: Session, sesn_id: str):
    """
    Get agent builder session detail by session ID
    """
    return db.query(EdlGenaiAgntBldrSesnCnfgrn).filter_by(sesn_id=sesn_id).first()

def update_agent_builder_session_detail(db: Session, sesn_id: str, user_id: str = None, schma_nm: str = None):
    """
    Update agent builder session detail
    """
    session_detail = db.query(EdlGenaiAgntBldrSesnCnfgrn).filter_by(sesn_id=sesn_id).first()
    if session_detail:
        if user_id is not None:
            session_detail.user_id = user_id
        if schma_nm is not None:
            session_detail.schma_nm = schma_nm
        
        db.commit()
        db.refresh(session_detail)
        return session_detail
    return None


# def delete_agent_builder_session_detail(db: Session, sesn_id: str):
#     """
#     Delete agent builder session detail by session ID
#     """
#     session_detail = db.query(AgntBldrSesnDtl).filter_by(sesn_id=sesn_id).first()
#     if session_detail:
#         db.delete(session_detail)
#         db.commit()
#         return True
#     return False
