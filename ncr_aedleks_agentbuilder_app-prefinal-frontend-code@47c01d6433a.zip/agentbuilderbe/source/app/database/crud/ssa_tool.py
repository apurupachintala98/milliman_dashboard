"""
CRUD operations for tools
"""
import json
from typing import List
import uuid
from sqlalchemy.orm import Session

from app.database.data_classes.ssa_models import (
    ToolDetails, 
    EdlGenaiCrtxAgntToolCnfgrn, 
    EdlGenaiCrtxAgntToolRsrcCnfgrn,
    EdlGenaiCrtxAgntToolCnfgrn
)
from app.api.schemas.ssa_api_schemas import ToolConfig


def create_tool(db: Session, agent_uuid: str, tool: ToolConfig) -> ToolDetails:
    """
    Add a tool to an agent
    """
    tool_json = json.dumps(tool.model_dump()).encode()
    
    db_tool = ToolDetails(
        agent_id=agent_uuid,
        tool_json=tool_json
    )
    db.add(db_tool)
    db.commit()
    db.refresh(db_tool)
    return db_tool


# For future use
def get_tools_by_agent(db: Session, agent_uuid: str) -> List[dict]:
    """
    Get all tools for a specific agent
    """
    tools = db.query(ToolDetails).filter(ToolDetails.agent_id == agent_uuid).all()
    return [json.loads(tool.tool_json.decode()) for tool in tools]


# For future use
def delete_tool(db: Session, tool_id: int) -> bool:
    """
    Delete a specific tool
    """
    tool = db.query(ToolDetails).filter(ToolDetails.id == tool_id).first()
    if tool:
        db.delete(tool)
        db.commit()
        return True
    return False


def delete_all_tools_by_agent(db: Session, agent_uuid: str) -> int:
    """
    Delete all tools for a specific agent
    Returns number of deleted tools
    """
    count = db.query(ToolDetails).filter(ToolDetails.agent_id == agent_uuid).delete()
    db.commit()
    return count


# CRUD functions for new tool configuration tables
def create_tool_config(db: Session, agnt_id: str, sesn_id: str, db_nm: str, 
                      schma_nm: str, tool_nm: str, tool_desc: str = None, tool_config: dict = None):
    """
    Create tool configuration in EdlGenaiCrtxAgntToolCnfgrn
    """
    tool_uuid = str(uuid.uuid4())
    tool_config_obj = EdlGenaiCrtxAgntToolCnfgrn(
        agnt_id=agnt_id,
        tool_id=tool_uuid,
        sesn_id=sesn_id,
        db_nm=db_nm,
        schma_nm=schma_nm,
        tool_nm=tool_nm,
        tool_desc=tool_desc,
        tool_config=tool_config
    )
    
    db.add(tool_config_obj)
    db.commit()
    db.refresh(tool_config_obj)
    return tool_config_obj


def get_tool_config(db: Session, agnt_id: str, tool_id: str):
    """
    Get tool configuration by agent ID and tool ID
    """
    return db.query(EdlGenaiCrtxAgntToolCnfgrn).filter_by(agnt_id=agnt_id, tool_id=tool_id).first()


def get_tools_by_agent_config(db: Session, agnt_id: str) -> List:
    """
    Get all tool configurations for a specific agent
    """
    
    return db.query(EdlGenaiCrtxAgntToolCnfgrn).filter_by(agnt_id=agnt_id).all()


def get_tools_by_session(db: Session, sesn_id: str) -> List:
    """
    Get all tool configurations for a specific session
    """
    
    return db.query(EdlGenaiCrtxAgntToolCnfgrn).filter_by(sesn_id=sesn_id).all()


def update_tool_config(db: Session, agnt_id: str, tool_id: str, tool_nm: str = None, 
                      tool_desc: str = None, tool_config: dict = None):
    """
    Update tool configuration
    """
    
    tool_obj = db.query(EdlGenaiCrtxAgntToolCnfgrn).filter_by(agnt_id=agnt_id, tool_id=tool_id).first()
    if tool_obj:
        if tool_nm is not None:
            tool_obj.tool_nm = tool_nm
        if tool_desc is not None:
            tool_obj.tool_desc = tool_desc
        if tool_config is not None:
            tool_obj.tool_config = tool_config
        
        db.commit()
        db.refresh(tool_obj)
        return tool_obj
    return None


def delete_tool_config(db: Session, agnt_id: str, tool_id: str) -> bool:
    """
    Delete tool configuration
    """    
    tool_obj = db.query(EdlGenaiCrtxAgntToolCnfgrn).filter_by(agnt_id=agnt_id, tool_id=tool_id).first()
    if tool_obj:
        db.delete(tool_obj)
        db.commit()
        return True
    return False


# CRUD functions for tool resource configuration
def create_tool_resource_config(db: Session, agnt_id: str, tool_nm: str, tool_desc: str, tool_config: dict,
                                sesn_id: str, db_nm: str, schma_nm: str, rsrc_config: dict = None):
    """
    Create tool resource configuration in EdlGenaiCrtxAgntToolRsrcCnfgrn
    """
    tool_id = str(uuid.uuid4())
    rsrc_id = str(uuid.uuid4())
    resource_config_obj = EdlGenaiCrtxAgntToolRsrcCnfgrn(
        agnt_id=agnt_id,
        tool_id=tool_id,
        rsrc_id=rsrc_id,
        sesn_id=sesn_id,
        db_nm=db_nm,
        schma_nm=schma_nm,
        rsrc_config=rsrc_config
    )
    
    db.add(resource_config_obj)
    db.commit()
    db.refresh(resource_config_obj)
    return resource_config_obj


def get_tool_resource_config(db: Session, agnt_id: str, tool_id: str, rsrc_id: str):
    """
    Get tool resource configuration by agent ID, tool ID, and resource ID
    """
    from app.database.data_classes.ssa_models import EdlGenaiCrtxAgntToolRsrcCnfgrn
    
    return db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(
        agnt_id=agnt_id, tool_id=tool_id, rsrc_id=rsrc_id
    ).first()


def get_resources_by_tool(db: Session, agnt_id: str, tool_id: str) -> List:
    """
    Get all resource configurations for a specific tool
    """
    from app.database.data_classes.ssa_models import EdlGenaiCrtxAgntToolRsrcCnfgrn
    
    return db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(
        agnt_id=agnt_id, tool_id=tool_id
    ).all()


def get_resources_by_agent(db: Session, agnt_id: str) -> List:
    """
    Get all resource configurations for a specific agent
    """
    from app.database.data_classes.ssa_models import EdlGenaiCrtxAgntToolRsrcCnfgrn
    
    return db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(agnt_id=agnt_id).all()


def get_resources_by_session(db: Session, sesn_id: str) -> List:
    """
    Get all resource configurations for a specific session
    """
    
    return db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(sesn_id=sesn_id).all()


def update_tool_resource_config(db: Session, agnt_id: str, tool_id: str, rsrc_id: str, 
                               rsrc_config: dict = None):
    """
    Update tool resource configuration
    """
    
    resource_obj = db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(
        agnt_id=agnt_id, tool_id=tool_id, rsrc_id=rsrc_id
    ).first()
    
    if resource_obj:
        if rsrc_config is not None:
            resource_obj.rsrc_config = rsrc_config
        
        db.commit()
        db.refresh(resource_obj)
        return resource_obj
    return None


def delete_tool_resource_config(db: Session, agnt_id: str, tool_id: str, rsrc_id: str) -> bool:
    """
    Delete tool resource configuration
    """
    
    resource_obj = db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(
        agnt_id=agnt_id, tool_id=tool_id, rsrc_id=rsrc_id
    ).first()
    
    if resource_obj:
        db.delete(resource_obj)
        db.commit()
        return True
    return False


def delete_all_resources_by_tool(db: Session, agnt_id: str, tool_id: str) -> int:
    """
    Delete all resource configurations for a specific tool
    Returns number of deleted resources
    """
    
    count = db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(
        agnt_id=agnt_id, tool_id=tool_id
    ).delete()
    db.commit()
    return count


def delete_all_resources_by_agent(db: Session, agnt_id: str) -> int:
    """
    Delete all resource configurations for a specific agent
    Returns number of deleted resources
    """
    
    count = db.query(EdlGenaiCrtxAgntToolRsrcCnfgrn).filter_by(agnt_id=agnt_id).delete()
    db.commit()
    return count