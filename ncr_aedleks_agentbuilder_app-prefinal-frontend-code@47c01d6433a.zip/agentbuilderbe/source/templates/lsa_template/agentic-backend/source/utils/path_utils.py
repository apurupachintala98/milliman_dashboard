
# utils/path_utils.py
import os
from pathlib import Path

def get_project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

def get_env_root():
    return str(os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))+"\\.env")
    # return os.path.abspath(os.path.join(os.path.dirname(__file__), "..")) + "\.env"

def get_project_root_for_agent() -> Path:
    """Find project root by looking for marker file."""
    current = Path(__file__).resolve().parent
    
    for parent in [current] + list(current.parents):
        if (parent / 'requirements.txt').exists():
            return parent
    
    # Fallback to current working directory
    return Path.cwd()