"""
Snowflake Cortex OpenAI LLM connector implementation.
This can be used to connect to Snowflake Cortex LLMs via OpenAI API.
"""

import os
from .base_llm import BaseLLM
from langchain_openai import ChatOpenAI
import httpx
import logging
from pathlib import Path
from utils.path_utils import get_project_root_for_agent


class SnowflakeCortexOpenAILLM(BaseLLM):
    def __init__(self, config: dict):
        logging.info(f"Loading Snowflake Cortex LLM config: {config}\n")

        # Resolve cert_path to absolute
        cert_path = Path(config["cert_path"])
        if not cert_path.is_absolute():
            base_dir = get_project_root_for_agent()
            cert_path = (base_dir / cert_path).resolve()
        logging.info(f"Resolved certificate path: {cert_path}\n")

        try:
            if os.getenv("SSL_CERT_FILE"):
                cert_path = os.getenv("SSL_CERT_FILE")
                logging.info(f"SSL_CERT_FILE from EKS Environment: {os.getenv("SSL_CERT_FILE")}")
            logging.info(f"Initializing HTTP Async Client with Cert Path: {cert_path}\n")
            self.http_async_client = httpx.AsyncClient(
                verify=str(cert_path),
                timeout=60.0
            )
            logging.info("HTTP Async Client initialized successfully\n")
        except FileNotFoundError as e:
            logging.error(f"Certificate file not found: {cert_path}\n")
            raise FileNotFoundError(f"Certificate file not found at {cert_path}\n") from e
        except httpx.InvalidURL as e:
            logging.error(f"Invalid URL configuration: {e}\n")
            raise ValueError(f"Invalid URL configuration: {e}\n") from e
        except Exception as e:
            logging.error(f"Failed to initialize HTTP async client: {e}\n")
            raise RuntimeError(f"Failed to initialize HTTP async client: {e}\n") from e
        
        self.api_key = config['pat_token']
        self.base_url = config['base_url']
        self.model = config['model']
        self.temperature = config["params"]['temperature']
        logging.info(f"Loading Snowflake Cortex LLM: {self.model}\n")
        self._llm_params = {
            k: v for k, v in config["params"].items()
        }
        logging.info(f"Loading Snowflake Cortex LLM params: {self._llm_params}\n")

        self.model = ChatOpenAI(
            http_async_client=self.http_async_client,
            model=self.model,  
            base_url=self.base_url,  
            api_key=self.api_key, 
            temperature=self.temperature,
        )

    @property
    def model_name(self) -> str:
        return self.model

    @property
    def llm_params(self) -> dict:
        return self._llm_params

    # async def generate(self, messages, **kwargs):
    #     params = {**self.llm_params, **kwargs}
    #     return await self.model.ainvoke(messages, **params)