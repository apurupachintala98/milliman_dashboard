"""
LangGrapg ReAct Agent
"""
import logging
from langchain_core.runnables import Runnable, RunnableConfig
from langchain_core.messages import SystemMessage
from states.agent_state import AgentState
from memory.user_memory_ops import get_long_term_memories
from .base_agent import BaseAgent


class ReActAgent(BaseAgent):
    def __init__(self, llm, system_prompt, user_prompt, tools, store, memory_config, react_agent_instructions):
        super().__init__(llm, system_prompt, user_prompt, tools, store)
        self.memory_config = memory_config
        self.react_agent_instructions = react_agent_instructions


    def _create_agent_runnable(self) -> Runnable:
        self.llm_with_tools = self.llm.model.bind_tools(self.tools)
        logging.info(f"Model bound with tools: {[t.name for t in self.tools]}")
    
    
    async def _get_long_term_memories(self, memories_to_load, config: RunnableConfig) -> dict:
        # memory_types is now passed in as a list, which is the 'selected_memory' you wanted.
        # user_id = config["configurable"]["user_id"]
        namespace_ids = [
            config["configurable"]["user_id"],
            config["configurable"]["agent_id"],
            config["configurable"]["application_id"]
        ]
        logging.info(f"Fetching Long Term Memories for Namespace ID: {namespace_ids}\n")
        return await get_long_term_memories(
            memory_types=memories_to_load, 
            namespace_ids=namespace_ids, 
            store=self.store
        )
 
 
    async def execute_with_memory(self, state: AgentState, config: RunnableConfig) -> AgentState:
        tool_list = [t.name for t in self.tools]
        user_selected_memories = [key for key, val in self.memory_config["long_term_memory_config"].items() if val]
        
        # memories_to_load = state.get("classified_memories", [])
        # memories_to_load = ["semantic_memory", "episodic_memory", "procedural_memory"]
        memories_to_load = [f"{memory}_memory" for memory in user_selected_memories]
        memories = await self._get_long_term_memories(memories_to_load, config)

        def format_memory_types(memorytypes):
            if isinstance(memorytypes, str):
                memorytypes = [m.strip() for m in memorytypes.split(",")]
 
            bullet_map = {
                "semantic": "use stable facts from USER PROFILE",
                "episodic": "use USER EXPERIENCES (past events)",
                # "procedural": "follow USER INSTRUCTIONS (rules and preferences)",
                "procedural": "use Policy Memory to evaluate hypothesis"
            }
 
            bullets = "\n      ".join(
                f"- **{m}**  {bullet_map.get(m, 'unknown type')}" for m in memorytypes
            )
 
            joined = ", ".join(memorytypes)
            return f"(Current memory type(s): **{joined}**)\n      {bullets}"
 
        memorytype_value = format_memory_types(user_selected_memories)
        system_message = self.system_prompt.format(
            system=self.react_agent_instructions["system"],
            orchestration=self.react_agent_instructions["orchestration"],
            response_structure=self.react_agent_instructions["response_structure"],
            memorytype=memorytype_value,  
            tool_list=str(tool_list),
            user_profile=str(memories["semantic_memory"]),
            user_experiences=str(memories["episodic_memory"]),
            policy_memories=str(memories["procedural_memory"])
        )
        logging.info(f"Final System Prompt: {system_message}\n")
        messages = [SystemMessage(content=system_message)] + state["messages"]
        response = await self.llm_with_tools.ainvoke(messages)
        logging.info(f"ReAct Agent Response: {response}\n")
       
        return AgentState(
            messages=list(state["messages"]) + [response],
            semantic_memory=memories["semantic_memory"],
            episodic_memory=memories["episodic_memory"],
            procedural_memory=memories["procedural_memory"],
        )

    def extract_tool_result(self, response):
        """
        Extract raw tool result from the LLM response.additional_kwargs.
        Supports all tool formats: tool_calls, tool_messages, and message lists.
        """

        additional_kwargs = getattr(response, "additional_kwargs", {})

        # Most common: messages containing tool output
        if "messages" in additional_kwargs:
            for message in additional_kwargs["messages"]:
                if message.get("type") == "tool" or message.get("name") == "get_competitor_policy_rag_data":
                    return message.get("content")

        # Sometimes tool output is in "tool_messages"
        if "tool_messages" in additional_kwargs:
            for m in additional_kwargs["tool_messages"]:
                return m.get("content")

        # Rare: embedded in "tool_calls" output (OpenAI style)
        if "tool_calls" in additional_kwargs:
            for call in additional_kwargs["tool_calls"]:
                if "function" in call and "output" in call["function"]:
                    return call["function"]["output"]

        # If nothing found, return None
        return None