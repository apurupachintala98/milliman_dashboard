
from fastmcp import FastMCP

'''
# Package: 
pip install fastmcp

# To run the MCP server:
python mcp_get_competitor_policy_data.py

# To test the tool via MCP Inspector:
npx @modelcontextprotocol/inspector

    # Transport: Streamable HTTP
    # MCP Base URL: http://localhost:6003/mcp
'''

#mcp = FastMCP("get_competitor_policy_data", port=6003)
mcp = FastMCP(
    "get_competitor_policy_data",
    host="0.0.0.0",
    port=6003
)

def log_tool_call(tool_name, *args, **kwargs):
    print(f"[TOOL CALL] {tool_name} called with args={args}, kwargs={kwargs}")

def log_tool_result(tool_name, result):
    print(f"[TOOL RESULT] {tool_name} returned: {result}")

@mcp.tool()
def get_competitor_policy_rag_data(competitors: list[str]):
    """
    MCP TOOL: Competitor Policy Retrieval (RAG-Oriented)

    PURPOSE
    -------
    Retrieve competitor reimbursement policy documents in markdown format for
    analysis, reasoning, and evidence-based decision making. This tool provides
    full policy text that can be analyzed to validate hypotheses, extract rules,
    or answer questions about competitor reimbursement policies.

    This tool does NOT perform hypothesis evaluation or classification.
    It only retrieves policy documents for agent analysis.

    WHEN TO USE
    -----------
    Use this tool when you need to:
    - Access competitor policy text to validate user hypotheses
    - Extract specific reimbursement or bundling rules from policies
    - Answer questions about what a competitor's policy states
    - Compare policy content against claims or assertions
    - Gather evidence for policy-related decisions

    INPUT
    -----
    competitors : list[str]
        A list of competitor names whose policies you want to retrieve.
        
        Currently available competitors:
        - "CIGNA" → Returns Cigna Reimbursement Policy R30 - Evaluation and 
          Management Services (includes pelvic exam add-on CPT 99459, consultation 
          codes, preventive E/M billing, and multiple encounter rules)

    OUTPUT
    ------
    Returns a JSON object with the following structure:

    {
        "status": "success",
        "retrieval_context": {
            "retrieved_policy_count": int,
            "retrieval_mode": "multi_policy_rag"
        },
        "policies": [
            {
                "policy_metadata": {
                    "policy_id": str,           # e.g., "COM_CIG_00017"
                    "competitor": str,          # e.g., "CIGNA"
                    "policy_name": str,         # Full policy name
                    "retrieval_strategy": str   # e.g., "semantic_chunking"
                },
                "chunks": [
                    {
                        "chunk_id": str,        # Unique chunk identifier
                        "content": str,         # Full markdown-formatted policy text
                        "metadata": {
                            "page_start": str,  # Starting page number
                            "page_end": str     # Ending page number
                        }
                    }
                ]
            }
        ]
    }

    CONTENT FORMAT
    --------------
    The "content" field contains markdown-formatted policy text with:
    - Headers (# Overview, ## Reimbursement Policy, etc.)
    - Bullet points and lists
    - CPT code references (e.g., 99202-99215, 99459, 99381-99397)
    - Detailed reimbursement rules and criteria
    - Policy effective dates and conditions

    AGENT USAGE GUIDANCE
    --------------------
    After calling this tool:
    1. Parse the returned markdown content from chunks[0].content
    2. Search through the policy text for relevant sections using markdown headers
    3. Extract specific rules, CPT codes, or criteria mentioned
    4. Compare the policy content against the user's hypothesis or question
    5. Cite specific policy text as evidence in your response
    6. Look for key sections like "Reimbursement Policy", "Consultation Codes", etc.

    EXAMPLE CALL
    ------------
    get_competitor_policy_rag_data(["CIGNA"])

    EXAMPLE RESPONSE (STRUCTURE)
    ----------------------------
    {
        "status": "success",
        "retrieval_context": {
            "retrieved_policy_count": 1,
            "retrieval_mode": "multi_policy_rag"
        },
        "policies": [
            {
                "policy_metadata": {
                    "policy_id": "COM_CIG_00017",
                    "competitor": "CIGNA",
                    "policy_name": "Reimbursement Policy R30 - Evaluation and Management Services",
                    "retrieval_strategy": "semantic_chunking"
                },
                "chunks": [
                    {
                        "chunk_id": "CIGNA-R30-CH-001",
                        "content": "# Overview\n\nThese Reimbursement policies...",
                        "metadata": {
                            "page_start": "2",
                            "page_end": "5"
                        }
                    }
                ]
            }
        ]
    }


    ERROR HANDLING
    --------------
    If no valid competitor names are provided or if a competitor doesn't exist:
    {
        "status": "error",
        "message": "No valid policy IDs provided"
    }

    IMPORTANT NOTES
    ---------------
    - Policy content is in markdown format of the original document
    - Effective dates and specific rules are embedded in the content text
    - Always read the full content to find relevant information
    - The tool is deterministic and safe for repeated calls
    - Use exact competitor name (case-sensitive): "CIGNA" not "cigna" or "Cigna"

    """

    # --------------------------------------------------------------------------------------------
    # Internal Policy Store
    # --------------------------------------------------------------------------------------------

    policy_text_page_2_to_5 = """

        # Overview

        These Reimbursement policies do not constitute medical advice, clinical protocols, or treatment recommendations and should not influence or replace the independent clinical judgment of healthcare professionals in the care of individual patients.
        Evaluation and Management (E/M) codes are used to represent services provided by a physician or other qualified healthcare professionals. E/M CPT® codes should reflect the appropriate place of service and be supported within the documentation.
        The reimbursement policy applies to all claims submitted on a Center of Medicare and Medicaid Services (CMS) 1500, UB-04 and all electronic equivalent claim forms.

        # Reimbursement Policy

        ## Cigna allows reimbursement for an Evaluation and Management (E/M) services when the following criteria are met:

        -  E/M services provided must meet the criteria as defined in the current year CPT® E/M guidelines
        -  Documentation within the medical record must be specific to the patient and the encounter at the time of service. Cloned or “copy and paste” must not be used within the patient documentation. Cigna considers cloned or “copy and paste” identified when the entry in the medical record is worded exactly alike or similar to the previous entries or when the medical documentation is exactly the same within different patient records

        ## Cigna does not reimburse for:

        -  For outpatient or inpatient consult codes reported by a physician or other qualified healthcare professional on a CMS - 1500
        -  Professional evaluation and management (E/M) codes for professional services when reported by a facility on a UB-04 claim form. Facilities may report Emergency Department Services CPT® codes 99281 - 99285 for facility emergency room services using the appropriate revenue code (045X)
        -  CPT® code 99211 when reported with modifier 25 on a CMS - 1500 claim form
        -  Two E/M service codes submitted for the same date of service on a CMS - 1500 claim form unless the presenting situation is one of the exception scenarios noted below
            1. Prolonged service with direct face-to-face contact (CPT® 99354, 99355)
            2. A preventive medicine office visit (CPT® 99381-99397) with a problem-based office visit (CPT® 99202-99215)
        -  E/M services reported with modifier 25 and joint injection codes reported on the same date of service, with a same or similar diagnosis code, are not separately reimbursable without documentation supporting the use of Modifier 25 on a CMS - 1500 claim form
        -  Prolonged service codes 99358 and 99359 reported on CMS - 1500 claim form as they are considered to be included in the overall care of the customer
        -  When impacted cerumen (CPT® 69209 or 69210) is the sole reason for the visit an E/M service (CPT® 99202-99205 and 99211-99215) is not separately reimbursed on a CMS - 1500 claim form and all electronic equivalents.
        -  Cigna will not separately reimburse E/M services (CPT® codes 99211-99215) reported with a testosterone therapy injection when the injection is the sole reason for the visit


        # General Background

        Evaluation and Management (E/M) are services provided by a physician or other qualified healthcare professionals. The E/M section of the Current Procedural Terminology (CPT®) book is divided into various categories that are further divided into sub-categories which describe the different E/M service classifications. The various classification consists of the following but not limited to, office/outpatient visits, inpatient hospital visits, etc. The E/M service classification represents the nature of the work which varies by type of service, place of service, patient medical status, code criteria, work completed by the provider.

        ## Medical Record Documentation

        The current CPT® evaluation and management section provides documentation guidelines included but not limited to the definitions of new and established visits, initial and subsequent visits, time, and medical decision making. Clinical documentation must be maintained by the provider, which supports the services/procedures and must be made available to Cigna upon request.
        Documentation within the medical record must be unique to the patient and the encounter for that specific date of service in order to support the E/M code reported. Cloned or copying and pasting from previous encounters is not appropriate. CMS states: “Cloning—this practice involves copying and pasting previously recorded information from a prior note into a new note, and it is a problem in health care institutions that is not broadly addressed. The medical record must contain documentation showing the differences and the needs of the patient for each visit or encounter. Simply changing the date on the EHR without reflecting what occurred during the actual visit is not acceptable.”

        ## Evaluation and Management Service Types

        Evaluation and Management codes are identified within the Current Procedural Terminology (CPT®) ranging in various types of services. Some types of service within the section are but not inclusive:
        -  Office visits - both established and new with descriptions
        -  Hospital services - inpatient and observation
        -  Emergency Room
        -  Preventive
        -  Critical Care
        -  Hospital Inpatient/Observation Services
        -  Consultations
        -  Emergency Department Services
        -  Critical Care Services
        -  Nursing Facility Services
        -  Rest Home or Residence Services


        ## New and Established Patients

        Cigna follows American Medical Association (AMA) definitions of what is considered to be a new or established patients.

        ## New Patient

        Cigna agrees with the AMA and CMS definition of a new patient; a new patient is one who has not received professional services by the same physician, or another physician within the same practice (group) within the previous 3 years.

        ## Established Patient

        Cigna agrees with the AMA and CMS definition of an established patient; an established patient has received professional services by the same physician, or another physician within the same practice (group) within the previous 3 years.

        ## Guidelines for Office or Other Outpatient E/M Services Codes 99202 - 99215

        Cigna will follow the guidelines that have been outlined in the E/M guidelines section of the current CPT® code book. Specific requirements for codes are found in the AMA CPT® coding guidelines code book. The guidelines consist of the following areas: History and physical examination, total time, and medical decision making (MDM).
        Total Time - The AMA states, “Total time on the date of the encounter (office or other outpatient services [99202 - 99205 - 99212 - 99215]: For coding purposes, time for these services is the total time on the date of the encounter. It includes both the face-to-face and non-face-to-face time personally spent by the physician and/or other qualified health care professional(s) on the day of the encounter (includes time in activities that require the physician or other qualified health care professional and does not include time in activities normally performed by clinical staff).”
        Note: Time is not a component for the emergency department CPT® codes 99281 - 99285 per the CPT® coding guidelines.
        Medical decision making and interpretation and report: “When the physician or other qualified health care professional is reporting a separate CPT® code that includes interpretation and/or report, the interpretation and/or report should not be counted in the medical decision making when selecting a level of office or other outpatient service. When the physician or other qualified professional is reporting a separate service for discussion of management with a physician or other qualified health care professional, the discussion is not counted in the medical decision making when selecting a level of office or other outpatient service.”
        CPT® code 99211 MDM code levels do not apply.
        Cigna will allow separate reimbursement for E/M CPT® codes 99202 - 99205, 99212 - 99215 and preventive services when reported with CPT code 99459 for pelvic exam.

        ## Consultation Codes

        Effective 10/11/2025, Cigna will no longer deny CPT code 99459 pelvic exam when reported with codes 99202 - 99205, and 99212 - 99215.

        Consultations services are evaluation and management services that are requested by physician/qualified healthcare professional during the care of a patient to obtain advice, or an opinion of care concerning a specific condition or problem.
        Cigna will not reimburse consultation codes office or other outpatient consultation CPT® (99242 - 99245), and 99252 - 99255. Non-consultative Evaluation and Management Codes may be utilized based on the code that best describes the service performed.

        ## Evaluation and Management Codes in the Facility

        Cigna will not reimburse professional evaluation and management (E/M) codes when reported by a facility on a UB-04 claim form, except for Emergency Department Services CPT® codes 99281 - 99285 using the appropriate revenue code 045X. The UB-04 is utilized by institutions/facility for reporting facility resource utilization.

        ## Multiple Patient Encounters on the Same Day

        Cigna does not reimburse two E/M service codes submitted for the same date of service unless the presenting situation is one of the exception scenarios noted below. Generally, the service code with the higher Relative Value Unit (RVU) will be considered for reimbursement.* The CMS Medically Unlikely Edit (MUE) of 2 for codes 99212, 99213 and 99214 is excluded from editing as it conflicts with this reimbursement policy indicating that we only pay 1 E/M service per health care professional per single date of service.

        One exception to reporting multiple patient encounters in one day is that of prolonged services with direct face-to-face patient contact (CPT® 99354, 99355). When appropriate, these codes may be used in conjunction with another E/M code for the same date of service.

        ## Discharge Services

        Cigna will reimburse E/M discharge services reported by the primary provider for both inpatient and observation services.
        Only one hospital discharge management service is reimbursable per hospital inpatient or observation stay.
        Cigna will reimburse specialists or additional providers that use a subsequent E/M code applicable to the type of stay, if providing services on the same day as discharge.

        ## Prolonged Services without Direct Patient Contact

        The CPT® manual states “prolonged service is provided that is neither face-to-face time in the office or outpatient setting, nor additional unit/floor time in the hospital or nursing facility setting during the same session of an evaluation and management service and is beyond the usual physician or other qualified health care professional service time.”
        Cigna will not reimburse prolonged service codes 99358 and 99359 reported on CMS - 1500 claim form as they are considered to be included in the overall care of the customer.

    """

    policy_store = {

        # ============================================================
        # competitor_name: CIGNA (UNCHANGED)
        # ============================================================
        "CIGNA": {
            "retrieval_context": {
                "policy_id": "COM_CIG_00017",
                "competitor": "CIGNA",
                "policy_name": "Reimbursement Policy R30 - Evaluation and Management Services",
                "retrieval_strategy": "semantic_chunking"
            },
            "chunks": [
                {
                    "chunk_id": "CIGNA-R30-CH-001",
                    "content": policy_text_page_2_to_5,
                    "metadata": {
                        "page_start": "2",
                        "page_end": "5",
                    },
                    
                }
            ]
        }
    }

    retrieved_policies = []

    for competitor in competitors:
        if competitor in policy_store:
            retrieved_policies.append({
                "policy_metadata": policy_store[competitor]["retrieval_context"],
                "chunks": policy_store[competitor]["chunks"]
            })

    print(f"\nRetrieved Policies: {retrieved_policies}\n")

    if not retrieved_policies:
        return {
            "status": "error",
            "message": "No valid policy IDs provided"
        }

    return {
        "status": "success",
        "retrieval_context": {
            "retrieved_policy_count": len(retrieved_policies),
            "retrieval_mode": "multi_policy_rag"
        },
        "policies": retrieved_policies
    }

 
if __name__ == "__main__":
    mcp.run(transport="http")