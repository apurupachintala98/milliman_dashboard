# Agentic AI Framework

A modular, configurable agentic AI framework using LangGraph, supporting multi-agent orchestration, MCP tools, and pluggable LLM connectors.

## Features
- Agentic framework using LangGraph
- Multi MCP server support
- MCP tool integration
- Configurable LLM connectors (Ollama, etc.)
- YAML-based config and logging
- Extensible and testable structure

## Quick Start
- Install dependencies: `pip install -r requirements.txt`
- Edit `config/config.yaml` for your LLM and MCP settings

## Run the mcp servers
- cd agentic_framework_with_memory/servers 
- python http_ddg_web_search_server.py
- python sse_youtube_search_server.py

## Run the agentic framework
- cd agentic_framework_with_memory
- streamlit run streamlit_ui.py

## Structure
See the code and comments for details on each module.
