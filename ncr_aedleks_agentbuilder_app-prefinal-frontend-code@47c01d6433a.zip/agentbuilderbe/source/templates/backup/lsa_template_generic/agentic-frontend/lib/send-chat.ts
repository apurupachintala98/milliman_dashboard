import type { ApiResponse, ApiRequest } from "./types"
import { getConfig } from "./config-store"
import staticConfig from "./config.json"

type SendChatParams = {
  content: string
  sessionId: string
}

export async function sendChat(params: SendChatParams): Promise<ApiResponse> {
  const cfg = getConfig()
  const url = (cfg.apiUrl && cfg.apiUrl.trim()) || (process.env.CHATBOT_API_URL as string) || staticConfig.apiUrl

  const payload: ApiRequest = {
    application_code: cfg.appCode || (process.env.CHATBOT_APP_CODE as string) || "",
    application_id: cfg.appId || (process.env.CHATBOT_APP_ID as string) || "",
    user_id: cfg.userId || (process.env.CHATBOT_USER_ID as string) || "",
    session_id: params.sessionId,
    body: {
      content_type: "text",
      messages: [{ role: "user", content: params.content }],
    },
  }

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return (await res.json()) as ApiResponse
}
