import staticConfig from "./config.json"
export type AppConfig = {
  apiUrl: string
  appId: string
  appCode: string
  userId: string
  chatName: string
  avatarUrl: string
  suggestedPrompts: string[]
}

export function getDefaultConfig(): AppConfig {
  const apiUrl = (process.env.CHATBOT_API_URL as string) || staticConfig.apiUrl
  const appId = (process.env.CHATBOT_APP_ID as string) || staticConfig.appId
  const appCode = (process.env.CHATBOT_APP_CODE as string) || staticConfig.appCode
  const userId = (process.env.CHATBOT_USER_ID as string) || staticConfig.userId
  return {
    apiUrl,
    appId,
    appCode,
    userId,
    chatName: staticConfig.chatName,
    avatarUrl: staticConfig.avatarUrl,
    suggestedPrompts: staticConfig.suggestedPrompts,
  }
}
