import type { ChatSession } from "./types"

const KEY = "chat-sessions-v1"

export function loadSessions(): ChatSession[] {
  if (typeof window === "undefined") return []
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as ChatSession[]
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export function persistSessions(sessions: ChatSession[]) {
  if (typeof window === "undefined") return
  localStorage.setItem(KEY, JSON.stringify(sessions))
}
