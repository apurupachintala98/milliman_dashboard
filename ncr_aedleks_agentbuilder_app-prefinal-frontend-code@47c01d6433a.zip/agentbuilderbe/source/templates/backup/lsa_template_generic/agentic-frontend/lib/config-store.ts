"use client"

import { useSyncExternalStore } from "react"
import { type AppConfig, getDefaultConfig } from "./config"

const KEY = "chat-config-v1"
const BUILD_VERSION_KEY = "chat-config-build-version"
const CURRENT_BUILD_VERSION = Date.now().toString()

function clearConfigOnNewBuild() {
  if (typeof window === "undefined") return

  try {
    const savedVersion = localStorage.getItem(BUILD_VERSION_KEY)

    // If no version exists or version has changed, clear config
    if (!savedVersion || savedVersion !== CURRENT_BUILD_VERSION) {
      localStorage.removeItem(KEY)
      localStorage.setItem(BUILD_VERSION_KEY, CURRENT_BUILD_VERSION)
    }
  } catch {
    // Silently fail if localStorage is not available
  }
}

clearConfigOnNewBuild()

let state: AppConfig = load() || getDefaultConfig()
const listeners = new Set<() => void>()

function load(): AppConfig | null {
  if (typeof window === "undefined") return null
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return null
    return JSON.parse(raw) as AppConfig
  } catch {
    return null
  }
}

function persist(next: AppConfig) {
  if (typeof window === "undefined") return
  localStorage.setItem(KEY, JSON.stringify(next))
}

export function getConfig(): AppConfig {
  return state
}

export function setConfig(patch: Partial<AppConfig>) {
  state = { ...state, ...patch }
  persist(state)
  listeners.forEach((l) => l())
}

export function resetConfig() {
  // always reload the original config.json defaults
  const freshDefaults = getDefaultConfig()
  state = freshDefaults
  persist(state)
  listeners.forEach((l) => l())
}

export function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

export function useAppConfig(): [AppConfig, typeof setConfig, typeof resetConfig] {
  const snapshot = useSyncExternalStore(
    subscribe,
    () => state,
    () => state,
  )
  return [snapshot, setConfig, resetConfig]
}
