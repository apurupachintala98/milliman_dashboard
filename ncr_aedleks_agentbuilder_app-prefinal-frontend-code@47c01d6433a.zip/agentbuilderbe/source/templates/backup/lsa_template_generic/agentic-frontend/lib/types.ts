export type Role = "user" | "assistant"

export type ChatMessage = {
  id: string
  role: Role
  content: string
}

export type ChatSession = {
  id: string
  title: string
  createdAt: string
  messages: ChatMessage[]
}

export type ApiRequest = {
  application_code: string
  application_id: string
  user_id: string
  session_id: string
  body: {
    content_type: string
    messages: { role: Role; content: string }[]
  }
}

export type ApiResponse = {
  response: {
    content_type: "text"
    messages: { role: "assistant"; content: string }[]
  }
  long_term_memory?: {
    name?: string
    location?: string
    preferences?: string[]
  }
  semantic_memory?: SemanticMemoryEntry[]
  episodic_memory?: EpisodicMemoryEntry[]
  procedural_memory?: ProceduralMemoryEntry[]
}

export type SemanticMemoryEntry = {
  dob?: string | null
  name?: string
  location?: string
  profession?: string | null
  preferences?: string[]
}

export type EpisodicMemoryEntry = {
  title?: string
  outcome?: string | null
  description?: string
  occurred_at?: string
  related_entities?: string[]
}

export type ProceduralMemoryEntry = {
  content?: string
  category?: string
  priority?: "low" | "medium" | "high"
}
