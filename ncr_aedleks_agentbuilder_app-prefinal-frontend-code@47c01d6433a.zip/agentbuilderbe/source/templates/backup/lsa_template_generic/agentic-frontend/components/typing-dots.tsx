"use client"

export function TypingDots() {
  return (
    <div className="flex items-center gap-1">
      <span className="sr-only">Assistant is typing…</span>
      <Dot delay="0ms" />
      <Dot delay="120ms" />
      <Dot delay="240ms" />
    </div>
  )
}

function Dot({ delay }: { delay: string }) {
  return (
    <span
      className="block h-2 w-2 animate-bounce rounded-full bg-pink-500"
      style={{ animationDelay: delay }}
      aria-hidden="true"
    />
  )
}
