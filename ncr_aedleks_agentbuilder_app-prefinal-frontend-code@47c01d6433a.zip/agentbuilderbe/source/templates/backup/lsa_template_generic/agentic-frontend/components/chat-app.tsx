"use client"

import { useEffect, useMemo, useState } from "react"
import { Sidebar } from "./sidebar"
import { ChatWindow } from "./chat-window"
import { loadSessions, persistSessions } from "@/lib/storage"
import type { ChatMessage, ChatSession } from "@/lib/types"
import { nanoid } from "@/lib/utils/nanoid"
import { useAppConfig } from "@/lib/config-store"
import { useRouter } from "next/navigation"

export default function ChatApp() {
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(true)
  const [search, setSearch] = useState("")
  const [cfg] = useAppConfig()
  const router = useRouter()

  useEffect(() => {
    const initial = loadSessions()

    if (initial.length > 0) {
      setSessions(initial)
      setActiveId(null)
    } else {
      // If no sessions exist, show empty state without creating a session
      setSessions([])
      setActiveId(null)
    }
  }, [])

  // persist on changes
  useEffect(() => {
    if (sessions.length) {
      persistSessions(sessions)
    }
  }, [sessions])

  const activeSession = useMemo(() => sessions.find((s) => s.id === activeId) ?? null, [sessions, activeId])

  function upsertActiveSessionMessages(updater: (prev: ChatMessage[]) => ChatMessage[]) {
    setSessions((prev) => prev.map((s) => (s.id === activeId ? { ...s, messages: updater(s.messages) } : s)))
  }

  function renameActiveSession(newTitle: string) {
    setSessions((prev) => prev.map((s) => (s.id === activeId ? { ...s, title: newTitle } : s)))
  }

  function ensureTitleFromFirstUserMessage(messages: ChatMessage[]): string {
    const firstUser = messages.find((m) => m.role === "user")
    if (!firstUser) return "New Chat"
    const cleaned = firstUser.content.trim().replace(/\s+/g, " ")
    return cleaned.length > 40 ? cleaned.slice(0, 40) + "…" : cleaned
  }

  function startNewChat() {
    const existingEmptyChat = sessions.find((session) => session.title === "New Chat" && session.messages.length === 0)

    // If there's already an empty new chat, just switch to it instead of creating another
    if (existingEmptyChat) {
      setActiveId(existingEmptyChat.id)
      return
    }

    if (
      activeSession &&
      activeSession.messages.length > 0 &&
      (activeSession.title === "New Chat" || activeSession.title.trim() === "")
    ) {
      const derivedTitle = ensureTitleFromFirstUserMessage(activeSession.messages)
      renameActiveSession(derivedTitle)
    }

    const next: ChatSession = {
      id: nanoid(),
      title: "New Chat",
      createdAt: new Date().toISOString(),
      messages: [],
    }
    setSessions((prev) => [next, ...prev])
    setActiveId(next.id)
  }

  function deleteSession(id: string) {
    setSessions((prev) => prev.filter((s) => s.id !== id))
    if (id === activeId) {
      setActiveId((prevActive) => {
        const remaining = sessions.filter((s) => s.id !== id)
        return remaining[0]?.id ?? null
      })
    }
  }

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim()
    if (!q) return sessions
    return sessions.filter(
      (s) => s.title.toLowerCase().includes(q) || s.messages.some((m) => m.content.toLowerCase().includes(q)),
    )
  }, [sessions, search])

  return (
    <div className="h-[100dvh]">
      <div className="flex h-full shadow-md overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          open={sidebarOpen}
          onToggle={() => setSidebarOpen((v) => !v)}
          sessions={filtered}
          activeId={activeId}
          onSelect={setActiveId}
          onNewChat={startNewChat}
          onDelete={deleteSession}
          onRename={(id, title) => setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, title } : s)))}
          search={search}
          onSearch={setSearch}
        />

        {/* Chat Window */}
        <div className="h-full flex-1">
            <ChatWindow
              key={activeSession?.id || "empty"}
              session={activeSession}
              updateMessages={upsertActiveSessionMessages}
              setTitle={(title) => setSessions((prev) => prev.map((s) => (s.id === activeId ? { ...s, title } : s)))}
              onPromptClick={(p) => {
              if (!activeSession) {
                startNewChat()
                // Wait for next tick to ensure session is created
                setTimeout(() => {
                  const event = new CustomEvent("chat-send-from-chip", { detail: p })
                  window.dispatchEvent(event)
                }, 0)
              } else {
                const event = new CustomEvent("chat-send-from-chip", { detail: p })
                window.dispatchEvent(event)
              }
            }}
            suggestions={cfg.suggestedPrompts}
            />
        </div>
      </div>
    </div>
  )
}
