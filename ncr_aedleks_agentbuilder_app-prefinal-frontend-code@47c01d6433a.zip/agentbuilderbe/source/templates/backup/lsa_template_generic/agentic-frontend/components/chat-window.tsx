"use client"

import { useEffect, useRef, useState } from "react"
import type { ChatMessage, ChatSession } from "@/lib/types"
import { TypingDots } from "./typing-dots"
import { sendChat } from "@/lib/send-chat"
import { nanoid } from "@/lib/utils/nanoid"
import Link from "next/link"
import { useAppConfig } from "@/lib/config-store"

type Props = {
  session: ChatSession | null
  updateMessages: (updater: (prev: ChatMessage[]) => ChatMessage[]) => void
  setTitle: (title: string) => void
  onPromptClick: (p: string) => void
  suggestions: string[]
}

export function ChatWindow({ session, updateMessages, setTitle, onPromptClick, suggestions }: Props) {
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [cfg] = useAppConfig()

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail
      if (detail && session) {
        doSend(detail)
      }
    }
    window.addEventListener("chat-send-from-chip", handler as EventListener)
    return () => window.removeEventListener("chat-send-from-chip", handler as EventListener)
  }, [session])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [session?.messages.length, loading])

  function titleFrom(text: string) {
    const t = text.trim().replace(/\s+/g, " ")
    return t.length > 40 ? t.slice(0, 40) + "…" : t
  }

  async function doSend(text?: string) {
    const content = (text ?? input).trim()
    if (!content) return

    const userMsg: ChatMessage = { id: nanoid(), role: "user", content }
    updateMessages((prev) => [...prev, userMsg])
    setInput("")
    if (session?.title === "New Chat") setTitle(titleFrom(content))

    setLoading(true)
    try {
      const res = await sendChat({
        content,
        sessionId: session.id,
      })

      const assistantText = res.response.messages?.[0]?.content ?? ""
      await typeAssistantMessage(assistantText)
    } catch (e) {
      await typeAssistantMessage("Sorry, I ran into an error. Please try again.")
      console.error("Chat error:", e)
    } finally {
      setLoading(false)
    }
  }

  async function typeAssistantMessage(full: string) {
    const id = nanoid()
    const base: ChatMessage = { id, role: "assistant", content: "" }
    updateMessages((prev) => [...prev, base])

    let acc = ""
    const delay = 12
    for (const ch of full) {
      acc += ch
      updateMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: acc } : m)))
      await new Promise((r) => setTimeout(r, delay))
    }
  }

  return (
    <section className="relative mx-auto h-full max-w-3xl">
      <div className="flex h-full flex-col p-4">
        <div ref={scrollRef} className="flex-1 overflow-auto rounded-xl bg-gradient-to-b from-white to-slate-50 p-4">
          {(!session || session.messages.length === 0) && (
            <div className="mx-auto flex max-w-md flex-col items-center gap-3 py-8 text-center">
              <img
                src={
                  cfg.avatarUrl ||
                  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-09-03%20at%203.14.37%E2%80%AFPM%20copy-YkfNpJgDfNpXWe9QQliZEfIVjkeMtb.png"
                }
                alt="Assistant"
                className="h-16 w-16 rounded-full ring-1 ring-slate-200"
              />
              <div className="text-pretty">
                <p className="text-lg font-semibold text-slate-900">Hi there</p>
                <p className="text-lg font-semibold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-pink-500">
                  How can I help you today?
                </p>
              </div>
            </div>
          )}
          {session && (
            <ul className="space-y-3">
              {session.messages.map((m) => (
                <li key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={
                      m.role === "user"
                        ? "max-w-[85%] rounded-2xl bg-slate-900 px-4 py-2 text-white shadow-sm transition-all duration-300 data-[show=true]:opacity-100 data-[show=true]:translate-y-0 opacity-0 translate-y-1"
                        : "max-w-[85%] rounded-2xl bg-white px-4 py-2 text-slate-900 shadow-sm ring-1 ring-slate-200 transition-all duration-300 data-[show=true]:opacity-100 data-[show=true]:translate-y-0 opacity-0 translate-y-1"
                    }
                    data-show
                  >
                    <div className="whitespace-pre-wrap text-sm leading-6">{m.content}</div>
                  </div>
                </li>
              ))}
              {loading && (
                <li className="flex justify-start">
                  <div className="max-w-[85%] rounded-2xl bg-white px-4 py-2 text-slate-900 shadow-sm ring-1 ring-slate-200">
                    <TypingDots />
                  </div>
                </li>
              )}
            </ul>
          )}
        </div>

        {(!session || session.messages.length === 0) && (
          <div className="mt-3">
            <p className="mb-2 text-center text-sm text-slate-600 font-bold">Prompt Suggestions</p>
            <div className="flex flex-wrap justify-center gap-2">
              {suggestions.map((p) => (
                <button
                  key={p}
                  onClick={() => onPromptClick(p)}
                  className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-700 transition-colors hover:border-indigo-300 hover:text-indigo-700"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault()
            doSend()
          }}
          className="mt-4 flex items-center gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me anything…"
            className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition focus:ring-2 focus:ring-indigo-500"
            aria-label="Message"
          />
          <button
            type="submit"
            className="rounded-xl bg-indigo-600 px-4 py-3 text-white shadow-sm transition-colors hover:bg-indigo-700 disabled:opacity-50"
            disabled={!input.trim() || loading || !session}
            aria-label="Send"
          >
            Send
          </button>
        </form>
      </div>
    </section>
  )
}
