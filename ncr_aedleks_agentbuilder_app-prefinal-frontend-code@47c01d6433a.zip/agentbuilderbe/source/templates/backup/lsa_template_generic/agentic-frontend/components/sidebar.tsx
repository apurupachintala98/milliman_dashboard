"use client"

import { useEffect, useRef, useState } from "react"
import type { ChatSession } from "@/lib/types"
import { cn } from "@/lib/utils/cn"
import { useAppConfig } from "@/lib/config-store"
import Link from "next/link"


type Props = {
  open: boolean
  onToggle: () => void
  sessions: ChatSession[]
  activeId: string | null
  onSelect: (id: string) => void
  onNewChat: () => void
  onDelete: (id: string) => void
  onRename: (id: string, newTitle: string) => void
  search: string
  onSearch: (v: string) => void
}

export function Sidebar({
  open,
  onToggle,
  sessions,
  activeId,
  onSelect,
  onNewChat,
  onDelete,
  onRename,
  search,
  onSearch,
}: Props) {
  const [editingId, setEditingId] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [cfg] = useAppConfig()


  useEffect(() => {
    if (editingId) inputRef.current?.focus()
  }, [editingId])

  return (
    <div className="relative h-full">
      <button
        onClick={onToggle}
        aria-label={open ? "Collapse sidebar" : "Expand sidebar"}
        className="fixed left-3 top-2 z-50 rounded-full bg-slate-900 p-2 text-white shadow hover:bg-slate-800"
      >
        {/* simple hamburger icon */}
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M3 6h18v2H3V6zm0 5h18v2H3v-2zm0 5h18v2H3v-2z" />
        </svg>
      </button>

      <aside
        className={cn(
          "relative h-full shrink-0 overflow-hidden transition-[width,transform] duration-300",
          open ? "w-72 translate-x-0" : "w-0 -translate-x-2",
        )}
        aria-label="Chat history sidebar"
      >
        <div className="flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-2 shadow-sm">
          {/* header (compact) */}
          <header className="mb-3 flex items-center justify-end">
            <div className="flex items-center gap-2">
              <Link
                href="/config"
                className="rounded-full bg-gradient-to-r from-indigo-600 to-pink-500 px-2 py-1 text-xs text-white"
              >
                Config
              </Link>
            </div>
          </header>
          <div className="flex items-center justify-between p-3">
            <h1 className="text-balance text-lg font-semibold text-slate-900">{cfg.chatName}</h1>
            <button
              onClick={onNewChat}
              className="inline-flex items-center rounded-md bg-indigo-600 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-indigo-700"
            >
              + New Chat
            </button>
          </div>

          {/* search */}
          <div className="mt-2">
            <input
              value={search}
              onChange={(e) => onSearch(e.target.value)}
              placeholder="Search chats…"
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
              aria-label="Search chats"
            />
          </div>

          {/* list */}
          {/* <div className="mt-2 flex-1 overflow-y-auto pr-1">
            <ul className="space-y-0.5">
              {sessions.map((s) => (
                <li key={s.id}>
                  <div
                    className={cn(
                      "group flex items-center justify-between rounded-md px-2 py-1.5",
                      s.id === activeId ? "bg-indigo-50" : "hover:bg-slate-50",
                    )}
                  >
                    {editingId === s.id ? (
                      <input
                        ref={inputRef}
                        defaultValue={s.title}
                        onBlur={(e) => {
                          onRename(s.id, e.currentTarget.value || "Untitled")
                          setEditingId(null)
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            onRename(s.id, (e.target as HTMLInputElement).value || "Untitled")
                            setEditingId(null)
                          }
                        }}
                        className="mr-2 w-full rounded border border-slate-200 px-2 py-1 text-sm outline-none"
                      />
                    ) : (
                      <button
                        onClick={() => onSelect(s.id)}
                        className="truncate text-left text-sm text-slate-800"
                        title={s.title}
                      >
                        {s.title}
                      </button>
                    )}

                    <div className="ml-2 hidden items-center gap-1 text-xs group-hover:flex">
                      <button
                        className="rounded px-2 py-1 text-slate-600 hover:bg-slate-100"
                        onClick={() => setEditingId(s.id)}
                        aria-label="Rename chat"
                      >
                        Rename
                      </button>
                      <button
                        className="rounded px-2 py-1 text-rose-600 hover:bg-rose-50"
                        onClick={() => onDelete(s.id)}
                        aria-label="Delete chat"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </li>
              ))}
              {sessions.length === 0 && <li className="py-4 text-center text-sm text-slate-500">No chats yet</li>}
            </ul>
          </div> */}
        </div>
      </aside>
    </div>
  )
}
