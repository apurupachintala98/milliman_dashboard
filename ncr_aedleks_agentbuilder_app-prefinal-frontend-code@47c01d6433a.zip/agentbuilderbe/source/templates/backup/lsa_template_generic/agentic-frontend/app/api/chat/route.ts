import type { NextRequest } from "next/server"
import type { ApiRequest, ApiResponse } from "@/lib/types"

export async function POST(req: NextRequest) {
  const { content, sessionId } = (await req.json()) as {
    content: string
    sessionId: string
  }

  const endpoint = process.env.CHATBOT_API_URL // set in Project Settings to call your real backend

  if (endpoint) {
    // Forward to your backend using the required payload format
    const payload: ApiRequest = {
      application_code: process.env.CHATBOT_APP_CODE || "abc",
      application_id: process.env.CHATBOT_APP_ID || "abc_01",
      user_id: process.env.CHATBOT_USER_ID || "User",
      session_id: sessionId,
      body: {
        content_type: "string",
        messages: [{ role: "user", content }],
      },
    }
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })

      if (!res.ok) {
        return new Response("Upstream error", { status: 502 })
      }

      const data = (await res.json()) as ApiResponse
      return Response.json(data)
    } catch (err) {
      return new Response("Error connecting to backend", { status: 500 })
    }
  }
}
