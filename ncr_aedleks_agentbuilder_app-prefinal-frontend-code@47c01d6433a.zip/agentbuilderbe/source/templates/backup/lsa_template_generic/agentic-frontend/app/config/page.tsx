"use client"

import { useEffect, useState } from "react"
import { useAppConfig } from "@/lib/config-store"
import Link from "next/link"

export default function ConfigPage() {
  const [cfg, setCfg, reset] = useAppConfig()
  const [form, setForm] = useState(cfg)
  const [savedMsg, setSavedMsg] = useState<string | null>(null)

  useEffect(() => setForm(cfg), [cfg])

 

  function update<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }))
  }

  function save() {
    // find changed fields
    const changedFields = Object.keys(form).filter(
      (key) => JSON.stringify(form[key as keyof typeof form]) !== JSON.stringify(cfg[key as keyof typeof cfg]),
    )

    if (changedFields.length === 0) {
      setSavedMsg("No changes to save.")
      return
    }

    setCfg(form)

    setSavedMsg(`Changes saved: ${changedFields.join(", ")}`)

    // auto-hide message after 3s
    setTimeout(() => setSavedMsg(null), 3000)
  }

  return (
    <main className="mx-auto h-[100dvh] max-w-3xl px-4 py-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-balance text-2xl font-semibold">Chatbot Configuration</h1>
        <Link href="/" className="text-sm text-indigo-600 hover:underline">
          Back to Chat
        </Link>
      </div>
    {/* success message */}
      {savedMsg && (
        <div className="mb-4 rounded-md border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          {savedMsg}
        </div>
      )}
      <div className="grid grid-cols-1 gap-6">
        <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <h2 className="mb-4 text-sm font-semibold text-slate-700">API</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-600">API URL</span>
              <input
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.apiUrl}
                onChange={(e) => update("apiUrl", e.target.value)}
                placeholder=""
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-600">Application ID</span>
              <input
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.appId}
                onChange={(e) => update("appId", e.target.value)}
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-600">Application Code</span>
              <input
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.appCode}
                onChange={(e) => update("appCode", e.target.value)}
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-600">User ID</span>
              <input
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.userId}
                onChange={(e) => update("userId", e.target.value)}
              />
            </label>
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <h2 className="mb-4 text-sm font-semibold text-slate-700">Branding</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-600">Chat Name</span>
              <input
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.chatName}
                onChange={(e) => update("chatName", e.target.value)}
              />
            </label>
            {/* <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-600">Greeting Name</span>
              <input
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.greetingName}
                onChange={(e) => update("greetingName", e.target.value)}
              />
            </label> */}
            <label className="col-span-1 flex flex-col gap-1 sm:col-span-2">
              <span className="text-xs text-slate-600">Avatar Image URL</span>
              <input
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                value={form.avatarUrl}
                onChange={(e) => update("avatarUrl", e.target.value)}
                placeholder=""
              />
            </label>
            <div className="col-span-1 sm:col-span-2">
              <img
                src={
                  form.avatarUrl
                    ? form.avatarUrl.startsWith("http")
                      ? form.avatarUrl // external URL
                      : `/${form.avatarUrl.replace(/^\/+/, "")}` // local public path
                    : "/default-avatar.png" // fallback (put this in /public)
                }
                alt="Chat avatar preview"
                className="h-16 w-16 rounded-full ring-1 ring-slate-200"
              />

            </div>
          </div>
        </section>

        <section className="p-4 shadow-sm">
          <h2 className="mb-2 text-sm font-semibold text-slate-700">Suggested Prompts</h2>
          <p className="mb-2 text-xs text-slate-500">One per line.</p>
          <textarea
            className="min-h-32 w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            value={form.suggestedPrompts.join("\n")}
            onChange={(e) =>
              update(
                "suggestedPrompts",
                e.target.value
                  .split("\n")
                  .map((s) => s.trim())
                  .filter(Boolean),
              )
            }
          />
        </section>

        <div className="flex items-center justify-end gap-2">
          <button
            onClick={reset}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
          >
            Reset to defaults
          </button>
          <button
            onClick={save}
            className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            Save
          </button>
        </div>
      </div>
    </main>
  )
}
