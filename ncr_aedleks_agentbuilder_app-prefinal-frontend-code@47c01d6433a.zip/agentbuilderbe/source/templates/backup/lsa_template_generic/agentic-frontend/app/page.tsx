import ChatApp from "../components/chat-app"

export default function Page() {
  return (
    <main className="h-[100dvh] bg-gradient-to-b from-white to-slate-50">
      <ChatApp />
    </main>
  )
}
