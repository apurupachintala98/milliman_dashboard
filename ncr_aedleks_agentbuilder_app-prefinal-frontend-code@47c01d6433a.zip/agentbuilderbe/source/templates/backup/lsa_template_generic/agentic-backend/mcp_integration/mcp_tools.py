"""
Utility functions/classes for MCP tools.
"""
from langchain_mcp_adapters.tools import load_mcp_tools
import logging

# Add any MCP tool-related utilities here

async def get_all_mcp_tools(mcp_client):
    all_tools = await mcp_client.get_tools()
    return all_tools

# Work on this later
async def filter_tools_by_config(mcp_client, mcp_cfg):
    return None
