"""
Wrapper for MultiServerMCPClient, handles tool loading and communication.
"""
from langchain_mcp_adapters.client import MultiServerMCPClient
import logging
import asyncio


class MCPClientWrapper:
    def __init__(self, servers: dict):
        logging.info(f"Initializing MCPClientWrapper with servers: {servers}")
        self.client = MultiServerMCPClient(servers)

    async def get_tools(self):
        logging.info("Fetching tools from MCP servers")
        # tools = await self.client.get_tools()
        try:
            tools = await asyncio.wait_for(self.client.get_tools(), timeout=10)
        except asyncio.TimeoutError:
            logging.error("Timeout while fetching tools from MCP servers")
            return []
        except Exception as e:
            logging.exception(f"Error fetching tools from MCP servers: {e}")
            return []
        logging.info(f"Loaded tools: {[t.name for t in tools]}")
        return tools

    def get_session(self, server_name):
        logging.info(f"Getting session for server: {server_name}")
        return self.client.session(server_name)