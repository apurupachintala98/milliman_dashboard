
from .mcp_client import MCPClientWrapper
from .mcp_tools import get_all_mcp_tools


async def setup_mcp_tools(config):
    mcp_cfg = config["mcp"]["servers"]
    mcp_client = MCPClientWrapper(servers=mcp_cfg)
    tools = await get_all_mcp_tools(mcp_client)
    return tools