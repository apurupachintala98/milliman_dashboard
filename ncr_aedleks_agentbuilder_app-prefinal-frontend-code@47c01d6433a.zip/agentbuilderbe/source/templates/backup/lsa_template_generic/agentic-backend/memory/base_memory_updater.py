"""
Base class for all memory updater.
Defines the interface and shared logic for memory operations and message handling.
"""
from abc import ABC, abstractmethod
from langchain_core.runnables import Runnable
from langgraph.store.base import BaseStore

class BaseMemoryUpdater(ABC):
    def __init__(self, llm, system_prompt: str, user_prompt: str, store: BaseStore):
        self.llm = llm
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.store = store
        self.memory_updater_runnable = self._create_memory_updater_runnable()

    @abstractmethod
    async def _create_memory_updater_runnable(self) -> Runnable:
        pass

    @abstractmethod
    async def _retrieve_memory(self, namespace: str, key: str):
        pass

    @abstractmethod
    async def _store_memory(self, namespace: str, key: str, value: dict):
        pass

    def get_runnable(self) -> Runnable:
        return self.memory_updater_runnable