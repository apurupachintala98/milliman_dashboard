"""
Semantic Memory Updater - Checks, stores, retrieves semantic information.
"""
import logging
from langchain_core.runnables import RunnableConfig, Runnable
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.store.base import BaseStore
from states.agent_state import AgentState
from schemas.user_memory_schema import UserProfile
from .base_memory_updater import BaseMemoryUpdater
from .user_memory_ops import merge_semantic_memory

class SemanticMemoryUpdater(BaseMemoryUpdater):
    def __init__(self, llm, system_prompt: str, user_prompt: str, store: BaseStore):
        super().__init__(llm, system_prompt, user_prompt, store)


    def _create_memory_updater_runnable(self) -> Runnable:
        self.model_with_structured_output = self.llm.get_structured_output_model(UserProfile)
        logging.info(f"Model bound with structured (semantic memory) output")
    

    async def _retrieve_memory(self, namespace) -> dict:
        # retrieved_memory = await self.store.asearch(namespace)
        # Get only items from exact namespace
        retrieved_memory = [
            item for item in await self.store.asearch(namespace)
            if item.namespace == namespace
        ]
        logging.info(f"Retrieved semantic memory from namespace={namespace}: {retrieved_memory}\n")
        return retrieved_memory


    async def _store_memory(self, namespace, key, value):
        await self.store.aput(namespace, key, value)
        logging.info(f"Stored semantic memory in namespace={namespace}, key={key}: {value}\n")


    async def _extract_semantic_memory(self, chat_history:str, user_message: str) -> UserProfile:
        response = await self.model_with_structured_output.ainvoke(
            [
                SystemMessage(content=self.system_prompt),
                HumanMessage(content=self.user_prompt.format(chat_history=chat_history, user_message=user_message)),
            ]
        )
        return response


    async def execute_with_memory(self, state: AgentState, config: RunnableConfig) -> AgentState:
        user_message = state["messages"][-1].content if state.get("messages") else ""
        chat_history = "\n".join(message.content for message in state["messages"][:-1])
        extracted_memory = await self._extract_semantic_memory(chat_history, user_message) if user_message else ""
        if extracted_memory:
            logging.info(f"Extracted Semantic Memories from LLM: {str(extracted_memory)}\n")
            # namespace = ("semantic_memory", config["configurable"]["user_id"])
            namespace = (
                "semantic_memory", 
                config["configurable"]["user_id"],
                config["configurable"]["agent_id"],
                config["configurable"]["application_id"]
            )
            existing_memory = await self._retrieve_memory(namespace)
            merged_memory = await merge_semantic_memory(existing_memory, extracted_memory) if existing_memory else extracted_memory.model_dump()
            await self._store_memory(namespace, "profile", merged_memory)
        return state