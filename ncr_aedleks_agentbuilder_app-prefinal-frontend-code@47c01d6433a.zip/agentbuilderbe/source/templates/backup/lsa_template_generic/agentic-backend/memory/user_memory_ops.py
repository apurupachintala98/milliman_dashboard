
from typing import Dict, Any
from schemas.user_memory_schema import UserProfile, UserExperience, UserInstruction, DEFAULT_SCHEMAS
import logging


async def merge_semantic_memory(existing_memory, extracted_memory):
    merged_memories = existing_memory[0].value
    for key, value in extracted_memory.model_dump().items():
        if key == "preferences" and value != None:
            merged_memories[key] = list(set((merged_memories.get(key) or []) + value))
        elif value and value.lower() != "na":
            merged_memories[key] = value
    return merged_memories


async def get_long_term_memory(namespace, store):
    memory_map = {
        "semantic_memory": UserProfile(),
        "episodic_memory": UserExperience(),
        "procedural_memory": UserInstruction()
    }
    # retrieved_memories = await store.asearch(namespace)
    # Get only items from exact namespace
    retrieved_memories = [
        item for item in await store.asearch(namespace)
        if item.namespace == namespace
    ]
    logging.info(f"RAW RETRIEVED MEMORIES for {namespace}: {retrieved_memories}\n")

    if retrieved_memories:
        memory_content = [memory.value for memory in retrieved_memories]
    else:
        memory_content = [memory_map[namespace[0]].model_dump()]        # namespace[0] holds memory name
   
    return memory_content
 
 
async def get_long_term_memories(memory_types, namespace_ids, store) -> Dict[str, Any]:
    logging.info(f"Namespace ID: {namespace_ids}\n")

    memories = {
        "semantic_memory": [UserProfile().model_dump()],
        "episodic_memory": [UserExperience().model_dump()],
        "procedural_memory": [UserInstruction().model_dump()],
    }
    for memory_type in memory_types:
        namespace = tuple([memory_type] + namespace_ids)
        logging.info(f"Namespace: {namespace}\n")

        retrieved = await get_long_term_memory(namespace, store)
        logging.info(f"Retrieved memory for {namespace}: {retrieved}\n")

        memories[memory_type] = retrieved
 
    return memories