"""
Episodic Memory Updater - Checks, stores, retrieves episodic information.
"""
import logging
import uuid
from langchain_core.runnables import RunnableConfig, Runnable
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.store.base import BaseStore
from states.agent_state import AgentState
from .base_memory_updater import BaseMemoryUpdater
from schemas.user_memory_schema import UserExperience


class EpisodicMemoryUpdater(BaseMemoryUpdater):
    def __init__(self, llm, system_prompt: str, user_prompt: str, store: BaseStore):
        super().__init__(llm, system_prompt, user_prompt, store)


    def _create_memory_updater_runnable(self) -> Runnable:
        self.model_with_structured_output = self.llm.get_structured_output_model(UserExperience)
        logging.info(f"Model bound with structured (episodic memory) output")


    async def _retrieve_memory(self, namespace):
        # retrieved_memory = await self.store.asearch(namespace)
        retrieved_memory = [
            item for item in await self.store.asearch(namespace)
            if item.namespace == namespace
        ]
        logging.info(f"Retrieved episodic memory from namespace={namespace}: {retrieved_memory}\n")
        return retrieved_memory


    async def _store_memory(self, namespace, key, value):
        await self.store.aput(namespace, key, value)
        logging.info(f"Stored semantic memory in namespace={namespace}, key={key}: {value}\n")


    async def _extract_episodic_memory(self, chat_history: str, user_message: str) -> UserExperience:
        response = await self.model_with_structured_output.ainvoke(
            [
                SystemMessage(content=self.system_prompt),
                HumanMessage(content=self.user_prompt.format(chat_history=chat_history, user_message=user_message)),
            ]
        )
        return response


    async def execute_with_memory(self, state: AgentState, config: RunnableConfig) -> AgentState:
        user_message = state["messages"][-1].content if state.get("messages") else ""
        chat_history = "\n".join(message.content for message in state["messages"][:-1])
        extracted_episodic_memory = await self._extract_episodic_memory(chat_history, user_message) if user_message else ""
        if extracted_episodic_memory:
            logging.info(f"Extracted Episodic Memories from LLM: {str(extracted_episodic_memory)}\n")
            # namespace = ("episodic_memory", config["configurable"]["user_id"])
            namespace = (
                "episodic_memory", 
                config["configurable"]["user_id"],
                config["configurable"]["agent_id"],
                config["configurable"]["application_id"]
            )
            await self._store_memory(namespace, str(uuid.uuid4()), extracted_episodic_memory.model_dump())
        return state