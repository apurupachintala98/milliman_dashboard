"""
Memory Router -> It is used to decide which memories to update through User Input
This version supports configurable memory types from UI
"""

import logging
from schemas.user_memory_schema import MemoryClassification
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig

class MemoryClassifier:
    def __init__(self, llm, system_prompt: str, user_prompt: str, memory_config: dict):
        self.model_with_structured_output = llm.get_structured_output_model(MemoryClassification)
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.memory_config = memory_config

    async def classify(self, chat_history: str, user_message: str) -> MemoryClassification:
        """
        Classify user message into memory types, respecting enabled types from UI config.
        
        Args:
            user_message: The user's input message
            enabled_memory_types: List of enabled memory types from UI config
                                 e.g., ["semantic", "episodic"] or ["semantic", "procedural"]
        
        Returns:
            MemoryClassification with filtered memory types
        """
        response = await self.model_with_structured_output.ainvoke(
            [
                SystemMessage(content=self.system_prompt),
                HumanMessage(content=self.user_prompt.format(
                    chat_history=chat_history,
                    user_message=user_message
                ))
            ]
        )
        return response


async def memory_classifier_node(state, classifier: MemoryClassifier):
    """
    Node function for memory classification in the graph.
    Extracts memory configuration from config and filters classified memories.
    """
    user_message = state["messages"][-1].content 
    chat_history = "\n".join(message.content for message in state["messages"][:-1])
    
    enabled_memory_types = [
        memory_type for memory_type, is_enabled in classifier.memory_config["long_term_memory_config"].items() 
        if is_enabled
    ]
    
    logging.info(f"Memory config from UI: {classifier.memory_config}")
    logging.info(f"Enabled memory types: {enabled_memory_types}")
    
    # Classify with enabled types
    memories = await classifier.classify(chat_history, user_message)
    
    # Filter classified memories based on enabled types (double-check)
    filtered_memories = []
    for route in memories.classified_memories:
        if route in enabled_memory_types:
            filtered_memories.append(f"{route}_memory")
        else:
            logging.warning(f"LLM classified '{route}' but it's not enabled. Skipping.")
    
    logging.info(f"LLM Classified memories: {str(memories.classified_memories)}")
    logging.info(f"Filtered memories based on config: {filtered_memories}")
    
    return {"classified_memories": filtered_memories}