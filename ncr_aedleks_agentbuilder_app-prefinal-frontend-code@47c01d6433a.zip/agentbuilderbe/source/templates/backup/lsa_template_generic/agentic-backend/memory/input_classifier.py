"""
Input Classifier -> It is used to classify the user input to memory router or react agent.
"""

import logging
from schemas.user_memory_schema import InputClassification
from langchain_core.messages import SystemMessage, HumanMessage

class InputClassifier:
    def __init__(self, llm, system_prompt: str, user_prompt: str):
        self.model_with_structured_output = llm.get_structured_output_model(InputClassification)
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt

    async def classify(self, chat_history: str, user_message: str) -> InputClassification:
        response = await self.model_with_structured_output.ainvoke(
            [
                SystemMessage(content=self.system_prompt),
                HumanMessage(content=self.user_prompt.format(chat_history=chat_history, user_message=user_message))
            ]
        )
        return response

async def input_classifier_node(state, classifier: InputClassifier):
    user_message = state["messages"][-1].content 
    chat_history = "\n".join(message.content for message in state["messages"][:-1])
    result = await classifier.classify(chat_history, user_message)
    logging.info(f"Input Classified as: {result.input_type} | Full: {str(result.model_dump())}")
    return {"classification": result.input_type}