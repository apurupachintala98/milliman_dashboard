
# utils/path_utils.py
import os

def get_project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

def get_env_root():
    return str(os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))+"\\.env")
    # return os.path.abspath(os.path.join(os.path.dirname(__file__), "..")) + "\.env"