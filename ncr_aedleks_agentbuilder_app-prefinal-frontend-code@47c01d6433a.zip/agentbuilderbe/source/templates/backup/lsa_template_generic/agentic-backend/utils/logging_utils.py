"""
Sets up logging from logging.yaml
"""
import logging.config
import yaml
import os

from .path_utils import get_project_root

def setup_logging(config_path: str):
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)

    base_log_dir = get_project_root()
    for handler in config.get("handlers", {}).values():
        if "filename" in handler:
            filename = os.path.basename(handler["filename"])
            new_path = os.path.join(base_log_dir, filename)
            handler["filename"] = new_path

            # Ensure the log directory exists
            os.makedirs(os.path.dirname(new_path), exist_ok=True)

    logging.config.dictConfig(config)