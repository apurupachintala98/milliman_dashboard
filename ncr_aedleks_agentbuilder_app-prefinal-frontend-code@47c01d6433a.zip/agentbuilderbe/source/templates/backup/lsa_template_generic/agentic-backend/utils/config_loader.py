"""
Loads and validates YAML config.
"""
import os
import re
import yaml

# Pattern to match ${VAR_NAME}
env_var_pattern = re.compile(r'\$\{([^}^{]+)\}')

def load_config(path: str) -> dict:
    # with open(path, 'r', encoding='utf-8') as f:
    #     content = f.read()
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    # Filter out comment lines (starting with # after optional whitespace)
    filtered_lines = [
        line for line in lines
        if not line.strip().startswith('#')
    ]
    content = ''.join(filtered_lines)
    # Replace all ${VAR_NAME} with os.getenv(VAR_NAME)
    def replace_env_var(match):
        var_name = match.group(1)
        value = os.getenv(var_name)
        if value is None:
            raise ValueError(f"Environment variable '{var_name}' not set.")
        return value

    substituted_content = env_var_pattern.sub(replace_env_var, content)
    return yaml.safe_load(substituted_content)





# def load_config(path: str) -> dict:
#     with open(path, 'r') as f:
#         return yaml.safe_load(f)