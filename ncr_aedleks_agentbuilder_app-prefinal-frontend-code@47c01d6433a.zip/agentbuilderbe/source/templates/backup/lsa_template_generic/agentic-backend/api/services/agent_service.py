"""
Agent Services used by Chat Router
"""

import logging
import time
from langchain_core.messages import HumanMessage
from api.schemas.agent import Message, MessagePayload, AgentRequest, AgentResponse
from fastapi import Request


async def process_agent_request(request: Request, request_body: AgentRequest) -> AgentResponse:
    role_map = {
        "ai": "assistant",
        "human": "user",
        "system": "system",
        "tool": "tool"
    }
    
    user_prompt = request_body.body.messages[-1].content 

    if not user_prompt or not user_prompt.strip():
        return

    run_config = {
        "configurable": {
            "thread_id": f"{request_body.user_id}:{request_body.session_id}", 
            "user_id": request_body.user_id, 
            # "agent_id": request_body.application_code,
            "agent_id": request_body.agent_id,
            "application_id": request_body.application_id
        }
    }

    user_input = {"messages": [HumanMessage(content=user_prompt)]}
    graph = request.app.state.graph
    start_time = time.time()
    response_state = await graph.ainvoke(user_input, config=run_config)
    time_taken = time.time() - start_time
    time_taken = f"{int(time_taken // 60)} {'minute' if int(time_taken // 60) == 1 else 'minutes'} {time_taken % 60:.2f} seconds" if time_taken > 60 else f"{time_taken:.2f} seconds"
    logging.info(f"Time taken: {time_taken}\n")

    # Extract the assistant’s latest response
    if response_state and "messages" in response_state:
        last_message = response_state["messages"][-1]
        role = role_map.get(last_message.type, "assistant")
        response_payload = MessagePayload(
            content_type="text", 
            messages=[Message(role=role, content=last_message.content)]
        )
    else:
        response_payload = MessagePayload(type=None, messages=[])

    return AgentResponse(
        response=response_payload,
        semantic_memory=response_state["semantic_memory"],
        episodic_memory=response_state["episodic_memory"],
        procedural_memory=response_state["procedural_memory"]
    )