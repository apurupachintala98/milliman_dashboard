"""
Chat API -> This API is used by users to chat with the model through the chat window.
"""

from fastapi import APIRouter, HTTPException, Request
from api.schemas.agent import AgentRequest, AgentResponse
from api.services.agent_service import process_agent_request

router = APIRouter()

@router.post("/chat", response_model=AgentResponse, summary="Chat with Agent")
async def chat(request: Request, request_body: AgentRequest):
    try:
        return await process_agent_request(request, request_body)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))