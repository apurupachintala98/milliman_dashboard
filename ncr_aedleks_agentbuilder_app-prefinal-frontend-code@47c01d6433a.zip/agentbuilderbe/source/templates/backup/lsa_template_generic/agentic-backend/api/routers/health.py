"""
Health Check API -> To check whether APIs are running or not.
"""
from fastapi import APIRouter

router = APIRouter()

@router.get("/", summary="Health Check")
async def health_check():
    return {"status": "ok", "message": "Multi-Agent API is running."}