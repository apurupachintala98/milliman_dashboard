"""
Agent API Schema Structure
"""
from pydantic import BaseModel
from typing import Any, List

class Message(BaseModel):
    role: str
    content: str

class MessagePayload(BaseModel):
    content_type: Any
    messages: List[Message]

class AgentRequest(BaseModel):
    # application_code: str
    agent_id: str
    application_id: str
    user_id: str
    session_id: str
    body: MessagePayload

class AgentResponse(BaseModel):
    response: MessagePayload
    semantic_memory: List
    episodic_memory: List
    procedural_memory: List