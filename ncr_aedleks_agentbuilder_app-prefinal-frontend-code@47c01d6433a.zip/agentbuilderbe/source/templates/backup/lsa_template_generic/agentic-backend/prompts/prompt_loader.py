
def get_prompts(config):
    prompts = {}
    for name, prompt_data in config["prompts"].items():
        prompts[f"{name}_system_prompt"] = prompt_data["system"]
        if "user" in prompt_data.keys():
            prompts[f"{name}_user_prompt"] = prompt_data["user"]
    return prompts