"""
ChatOpenAI LLM connector implementation.
This can be used to connect to OpenAI's API or any compatible local LLM server.
Has been tested with LM Studio.
"""

from .base_llm import BaseLLM
from langchain_openai import ChatOpenAI
import logging

class ChatOpenAI_LLM(BaseLLM):
    def __init__(self, config: dict):
        logging.info(f"Loading OpenAI config: {config}")
        self._model_name = config['model']
        self.host = config['host']
        self.openai_api_key = config['openai_api_key']
        self._model_name = config['model']
        self.temperature = config["params"]['temperature']
        logging.info(f"Loading OpenAI model: {self._model_name}")
        self._llm_params = {
            k: v for k, v in config["params"].items() if k not in ('model', 'host')
        }
        logging.info(f"Loading OpenAI params: {self._llm_params}")

        self.model = ChatOpenAI(
            model=self._model_name,  
            openai_api_base=self.host,  
            openai_api_key=self.openai_api_key, 
            temperature=self.temperature,
        )

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def llm_params(self) -> dict:
        return self._llm_params

    # async def generate(self, messages, **kwargs):
    #     params = {**self.llm_params, **kwargs}
    #     return await self.model.ainvoke(messages, **params)
    
