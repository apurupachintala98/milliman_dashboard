
import os

os.environ['REQUESTS_CA_BUNDLE'] = "C:/Users/AM52297/Documents/langgraph_multi_agent_framework-suvojeet/multi_agent_env/Lib/site-packages/certifi/cacert.pem"
os.environ["SNOWFLAKE_DATABASE"] = "POC_SPC_SNOWPARK_DB"
os.environ["SNOWFLAKE_SCHEMA"] = "DATA_SCHEMA"

import json
from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Literal,
    Optional,
    Sequence,
    Type,
    Union,
)

from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    ChatMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from langchain_core.tools import BaseTool
from langchain_core.utils import (
    convert_to_secret_str,
    get_from_dict_or_env,
    get_pydantic_field_names,
)
from langchain_core.utils.function_calling import convert_to_openai_tool
from langchain_core.utils.utils import _build_model_kwargs
from langchain.tools import StructuredTool
from pydantic import Field, SecretStr, model_validator, BaseModel, create_model
import requests
import re


SUPPORTED_ROLES: List[str] = [
    "system",
    "user",
    "assistant",
]


class ChatSnowflakeCortexError(Exception):
    """Error with Snowpark client."""


def _convert_message_to_dict(message: BaseMessage) -> dict:
    """Convert a LangChain message to a dictionary.

    Args:
        message: The LangChain message.

    Returns:
        The dictionary.
    """
    
    message_dict: Dict[str, Any] = {}

    # Populate role and additional message data
    if isinstance(message, ChatMessage) and message.role in SUPPORTED_ROLES:
        message_dict["role"] = message.role
        message_dict["content"] = message.content
    elif isinstance(message, SystemMessage):
        message_dict["role"] = "system"
        message_dict["content"] = message.content
    elif isinstance(message, HumanMessage):
        message_dict["role"] = "user"
        message_dict["content"] = message.content
    elif isinstance(message, AIMessage):
        message_dict["role"] = "assistant"
        message_dict["content"] = message.content
        for tool in message.tool_calls:
            tool_content = {
                "type": "tool_use",
                "tool_use": {
                    "tool_use_id": tool["id"],
                    "name": tool["name"],
                    "input": tool["args"],
                }
            }
            if "content_list" in message_dict:
                message_dict["content_list"].append(tool_content)
            else:
                message_dict["content_list"] = [tool_content]

    elif isinstance(message, ToolMessage):
        message_dict["role"] = "user"
        
        # Old version of result_content
        # result_content = [
        #     {
        #         "type": "text", 
        #         "text": ",".join([ "{key}: {val}".format(key=key, val=val) for key,val in rslt.items()])
        #     } for rslt in (json.loads(message.content) if isinstance(message.content,str) else message.content)
        # ]
        
        try:
            parsed = json.loads(message.content) if isinstance(message.content, str) else message.content
        except (TypeError, json.JSONDecodeError):
            parsed = [{"result": message.content}]  # fallback wrapper
        
        parsed = [parsed] if isinstance(parsed, dict) else parsed
        parsed = [{"result": parsed}] if not isinstance(parsed, list) else parsed

        result_content = [
            {"type": "text", "text": ",".join(f"{k}: {v}" for k, v in r.items())}
            for r in parsed
        ]

        tool_content = {
            "type": "tool_results",
            "tool_results": {
                "tool_use_id": message.tool_call_id,
                "name": message.name,
                "content": result_content
            }
        }
        if "content_list" in message_dict:
                message_dict["content_list"].append(tool_content)
        else:
                message_dict["content_list"] = [tool_content]

    else:
        raise TypeError(f"Got unknown type {message}")
    return message_dict


def _truncate_at_stop_tokens(
    text: str,
    stop: Optional[List[str]],
) -> str:
    """Truncates text at the earliest stop token found."""
    if stop is None:
        return text

    for stop_token in stop:
        stop_token_idx = text.find(stop_token)
        if stop_token_idx != -1:
            text = text[:stop_token_idx]
    return text


class ChatSnowflakeCortex(BaseChatModel):
    """Snowflake Cortex based Chat model

    To use the chat model, you must have the ``snowflake-snowpark-python`` Python
    package installed and either:

        1. environment variables set with your snowflake credentials or
        2. directly passed in as kwargs to the ChatSnowflakeCortex constructor.

    Example:
        .. code-block:: python

            from langchain_community.chat_models import ChatSnowflakeCortex
            chat = ChatSnowflakeCortex()
    """

    test_tools: Dict[str, Union[Dict[str, Any], Type, Callable, BaseTool]] = Field(
        default_factory=dict
    )

    session: Any = None
    """Snowpark session object."""

    model: str = "mistral-large"
    """Snowflake cortex hosted LLM model name, defaulted to `mistral-large`.
        Refer to docs for more options. Also note, not all models support 
        agentic workflows."""

    cortex_function: str = "complete"
    """Cortex function to use, defaulted to `complete`.
        Refer to docs for more options."""

    temperature: float = 0
    """Model temperature. Value should be >= 0 and <= 1.0"""

    max_tokens: Optional[int] = None
    """The maximum number of output tokens in the response."""

    top_p: Optional[float] = 0
    """top_p adjusts the number of choices for each predicted tokens based on
        cumulative probabilities. Value should be ranging between 0.0 and 1.0. 
    """

    snowflake_username: Optional[str] = Field(default=None, alias="username")
    """Automatically inferred from env var `SNOWFLAKE_USERNAME` if not provided."""
    snowflake_password: Optional[SecretStr] = Field(default=None, alias="password")
    """Automatically inferred from env var `SNOWFLAKE_PASSWORD` if not provided."""
    snowflake_account: Optional[str] = Field(default=None, alias="account")
    """Automatically inferred from env var `SNOWFLAKE_ACCOUNT` if not provided."""
    snowflake_database: Optional[str] = Field(default=None, alias="database")
    """Automatically inferred from env var `SNOWFLAKE_DATABASE` if not provided."""
    snowflake_schema: Optional[str] = Field(default=None, alias="schema")
    """Automatically inferred from env var `SNOWFLAKE_SCHEMA` if not provided."""
    snowflake_warehouse: Optional[str] = Field(default=None, alias="warehouse")
    """Automatically inferred from env var `SNOWFLAKE_WAREHOUSE` if not provided."""
    snowflake_role: Optional[str] = Field(default=None, alias="role")
    """Automatically inferred from env var `SNOWFLAKE_ROLE` if not provided."""


    @classmethod
    def validate_environment(self, values: dict) -> dict:
        """
        Override the model validator to skip credential checks if a session is already provided.
        """
        if values.get("session") is not None:
            return values
        return super().validate_environment(values)


    def convert_pydantic_basemodel_class_to_structured_tool(
        self,
        model_class: Type[BaseModel],
        name: Optional[str] = None,
        description: Optional[str] = None,
        return_direct: bool = False
    ) -> StructuredTool:
        tool_name = name or model_class.__name__
        tool_description = description or model_class.__doc__ or f"Tool for {model_class.__name__}"
        def tool_function(**kwargs) -> Dict[str, Any]:
            try:
                validated_instance = model_class(**kwargs)
                return validated_instance.model_dump()
            except Exception as e:
                return {"error": f"Validation error: {str(e)}"}
        structured_tool = StructuredTool.from_function(
            func=tool_function,
            name=tool_name,
            description=tool_description,
            args_schema=model_class,            # The Pydantic model as the schema
            return_direct=return_direct
        )
        return structured_tool


    def with_structured_output(
        self,
        schema: Type[BaseModel],
        **kwargs
    ) -> Any:
        structured_tool = self.convert_pydantic_basemodel_class_to_structured_tool(
            model_class=schema,
            name=f"{schema.__name__}_output",
            description=f"Generate structured output conforming to {schema.__name__} schema"
        )
        fresh_llm = self.__class__(
            session=self.session,
            model=self.model,
        )
        bound_llm = fresh_llm.bind_tools([structured_tool], **kwargs)

        class StructuredOutputLLM:
            def __init__(self, llm):
                self.llm = llm

            def _extract_tool_calls(self, message: AIMessage) -> Any:
                """Extract structured output from tool_calls"""
                if message.tool_calls:
                    tool_name = message.tool_calls[0].get('name', 'DynamicModel')
                    tool_name = tool_name.split("_output")[0]
                    tool_args = message.tool_calls[0].get('args', {})
                    fields = {
                        key: (type(value), ...)  # The '...' makes the field required.
                        for key, value in tool_args.items()
                    }
                    DynamicModel = create_model(tool_name, **fields)
                    return DynamicModel(**tool_args)
                return message.content
                
            async def ainvoke(self, *args, **kwargs):
                result = await self.llm.ainvoke(*args, **kwargs)
                return self._extract_tool_calls(result)
                
            def invoke(self, *args, **kwargs):
                result = self.llm.invoke(*args, **kwargs)
                return self._extract_tool_calls(result)
    
        return StructuredOutputLLM(bound_llm)
    

    def bind_tools(
        self,
        tools: Sequence[Union[Dict[str, Any], Type, Callable, BaseTool]],
        *,
        tool_choice: Optional[
            Union[dict, str, Literal["auto", "any", "none"], bool]
        ] = "auto",
        **kwargs: Any,
    ) -> "ChatSnowflakeCortex":
        """Bind tool-like objects to this chat model, ensuring they conform to
        expected formats."""
        def convert_to_snowflake_tool(tool) -> Dict[str, Any]:
            """Convert a StructuredTool to a dictionary format."""
            # print(f"\nTool Class: {tool.__class__}")
            # print(f"\nTool Dir: {dir(tool)}")
            # print(f"\nTool: {tool}")
            # print(f"\nTool args_schema: {tool.args_schema}")
            # print(f"\nTool JSON Schmea: {tool.args_schema.model_json_schema()}")
            args_schema = tool.args_schema
            if isinstance(args_schema, type) and issubclass(args_schema, BaseModel):
                tool_schema = args_schema.model_json_schema()
            elif isinstance(args_schema, dict):
                tool_schema = tool.args_schema
            return {
                "type": "json" if tool.func and issubclass(tool.func, BaseModel) else "generic",
                "name": tool.name,
                "description": tool.description,
                "input_schema": {
                    "type": tool_schema.get("type", "object"),
                    "properties": tool_schema.get("properties", {}),
                    "required": tool_schema.get("required", [])
                },
                "func": tool.func if tool.func else tool.coroutine, 
            }

        formatted_tools = [convert_to_snowflake_tool(tool) for tool in tools]
        formatted_tools_dict = {
            tool["name"]: tool for tool in formatted_tools if "name" in tool
        }
        self.test_tools.update(formatted_tools_dict)
        return self


    @model_validator(mode="before")
    @classmethod
    def build_extra(cls, values: Dict[str, Any]) -> Any:
        """Build extra kwargs from additional params that were passed in."""
        all_required_field_names = get_pydantic_field_names(cls)
        values = _build_model_kwargs(values, all_required_field_names)
        return values
    

    def __del__(self) -> None:
        if getattr(self, "session", None) is not None:
            self.session.close()


    @property
    def _llm_type(self) -> str:
        """Get the type of language model used by this chat model."""
        return f"snowflake-cortex-{self.model}"


    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        
        message_dicts = [_convert_message_to_dict(m) for m in messages]

        # Check for tool invocation in the messages and prepare for tool use
        tool_output = None
        for message in messages:
            if (
                isinstance(message.content, dict)
                and isinstance(message, SystemMessage)
                and "invoke_tool" in message.content
            ):
                tool_info = json.loads(message.content.get("invoke_tool"))
                tool_name = tool_info.get("tool_name")
                if tool_name in self.test_tools:
                    tool_args = tool_info.get("args", {})
                    tool_output = self.test_tools[tool_name](**tool_args)
                    break

        # Prepare messages for SQL query
        if tool_output:
            message_dicts.append(
                {"tool_output": str(tool_output)}
            )  # Ensure tool_output is a string

        # JSON dump the message_dicts and options
        message_json = json.dumps(message_dicts)
        message_json = message_json.replace("'", "''")  # ONLY escape single quotes for SQL

        # Need to build a message for rule use & Tool Response build both of them
        response_format_lst =  [tl.get("func") for tl in self.test_tools.values() if tl.get("type") == "json" and tl.get("func")]
        response_format = {"response_format": {"type": "json", "schema": response_format_lst[0].model_json_schema()}} if response_format_lst else {}
        options = {
            "temperature": self.temperature,
            "top_p": self.top_p if self.top_p is not None else 1.0,
            "max_tokens": self.max_tokens if self.max_tokens is not None else 16000,
            **response_format
        }
        request_body = {
            "model": self.model,
            "messages": message_dicts,
            "tools": [{"tool_spec": {k: v for k, v in tl.items() if k != "func"}} for tl in self.test_tools.values() if tl.get("type") == "generic"],
            **options,
        }
        headers = {
                "Authorization": f'Snowflake Token="{self.session.connection.rest.token}"',
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        options_json = json.dumps(options)
        HOST = "carelon-eda-preprod.privatelink.snowflakecomputing.com"
        resp = requests.post(
            url=f"https://{HOST}/api/v2/cortex/inference:complete",
            json=request_body,
            headers=headers
        )

        response_chunks = []
        response_agg = {
            "content": "",
            "usage":{},
            "tool_use": {}
        }
        last_tool_id = None
        if resp.status_code == 200:
            for line in resp.iter_lines():
                if line:
                    # Remove the 'data: ' prefix and parse the JSON
                    line_content = line.decode('utf-8').replace('data: ', '')
                    try:
                        json_line = json.loads(line_content)
                        # Aggrigate the usage
                        response_agg["usage"].update(json_line.get("usage", {}))
                        # Collect the message content 
                        delta_chunk =json_line["choices"][0].get("delta", {})
                        if delta_chunk.get("type") == "text":
                            response_agg["content"] += delta_chunk.get("content", "")
                        # Collecting tool usage 
                        if delta_chunk.get("type") == "tool_use":
                            if "tool_use_id" in delta_chunk: 
                                if delta_chunk.get("tool_use_id") not in response_agg["tool_use"]:
                                    last_tool_id = delta_chunk.get("tool_use_id")
                                    response_agg["tool_use"][delta_chunk.get("tool_use_id")] = {
                                        "name": delta_chunk.get("name"),
                                        "args": "",
                                        "id": delta_chunk.get("tool_use_id")
                                    }
                                
                            response_agg["tool_use"][last_tool_id]["args"] += delta_chunk.get("input", "")
                            
                        response_chunks.append(json_line)
                    except json.JSONDecodeError:
                        print("Error decoding JSON line:", line_content)
        else:
            print("Error:", resp.status_code, resp.text)
        
        ai_message_content = response_agg["content"]
        content = _truncate_at_stop_tokens(ai_message_content, stop)
        tool_calls = [
            {
                "name": tool["name"],
                "id": tool["id"],
                "args": json.loads(tool["args"])
            } 
            for tool in response_agg["tool_use"].values()
        ]

        message = AIMessage(
            content=content,
            response_metadata=response_agg["usage"],
            tool_calls=tool_calls
        )
        generation = ChatGeneration(message=message)
        return ChatResult(generations=[generation])


    def _stream_content(
        self, content: str, stop: Optional[List[str]]
    ) -> Iterator[ChatGenerationChunk]:
        """
        Stream the output of the model in chunks to return ChatGenerationChunk.
        """
        chunk_size = 50  # Define a reasonable chunk size for streaming
        truncated_content = _truncate_at_stop_tokens(content, stop)

        for i in range(0, len(truncated_content), chunk_size):
            chunk_content = truncated_content[i : i + chunk_size]

            # Create and yield a ChatGenerationChunk with partial content
            yield ChatGenerationChunk(message=AIMessageChunk(content=chunk_content))


def _stream(
    self,
    messages: List[BaseMessage],
    stop: Optional[List[str]] = None,
    run_manager: Optional[CallbackManagerForLLMRun] = None,
    **kwargs: Any,
) -> Iterator[ChatGenerationChunk]:
    """Stream the output of the model in chunks to return ChatGenerationChunk."""
    message_dicts = [_convert_message_to_dict(m) for m in messages]

    # JSON dump the message_dicts and options
    message_json = json.dumps(message_dicts)
    message_json = message_json.replace("'", "''")  # ONLY escape single quotes for SQL

    options = {
        "temperature": self.temperature,
        "top_p": self.top_p if self.top_p is not None else 1.0,
        "max_tokens": self.max_tokens if self.max_tokens is not None else 2048,
    }
    options_json = json.dumps(options)

    sql_stmt = f"""
        select snowflake.cortex.{self.cortex_function}(
            '{self.model}',
            parse_json('{message_json}'),
            parse_json('{options_json}')
        ) as llm_stream_response;
    """

    try:
        self.session.sql(
            f"USE WAREHOUSE {self.session.get_current_warehouse()};"
        ).collect()
        result = self.session.sql(sql_stmt).collect()

        for row in result:
            response = json.loads(row["LLM_STREAM_RESPONSE"])
            ai_message_content = response["choices"][0]["messages"]

            for chunk in self._stream_content(ai_message_content, stop):
                yield chunk

    except Exception as e:
        raise ChatSnowflakeCortexError(
            f"Error while making request to Snowflake Cortex stream: {e}"
        )