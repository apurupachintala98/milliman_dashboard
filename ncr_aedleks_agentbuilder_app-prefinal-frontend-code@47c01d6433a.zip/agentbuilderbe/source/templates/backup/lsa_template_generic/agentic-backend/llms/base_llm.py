from abc import ABC, abstractmethod

class BaseLLM(ABC):
    # @abstractmethod
    # async def generate(self, messages, **kwargs):
    #     """
    #     Subclasses must implement this async method.
    #     """
    #     pass

    @property
    @abstractmethod
    def model_name(self):
        """
        Subclasses must define a model_name property.
        """
        pass

    @property
    @abstractmethod
    def llm_params(self):
        """
        Subclasses must define a llm_params property.
        """
        pass

    def get_structured_output_model(self, schema, **kwargs):
        model_name = self.model_name if isinstance(self.model_name, str) else str(self.model_name)
        if "claude" in model_name.lower():
            if "method" not in kwargs:
                kwargs["method"] = "function_calling"
        return self.model.with_structured_output(schema, **kwargs)