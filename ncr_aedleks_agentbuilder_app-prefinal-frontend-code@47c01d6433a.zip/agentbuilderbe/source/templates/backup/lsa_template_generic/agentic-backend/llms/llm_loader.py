
# from .ollama_connector import OllamaLLM
# from .watsonx_connector import WatsonXLLM
# from .chat_openai_connector import ChatOpenAI_LLM
# from .snowflake_cortex_connector import SnowflakeCortexLLM
from .snowflake_cortex_openai_connector import SnowflakeCortexOpenAILLM
import logging


def load_llm(config: dict, provider: str):
    llm_cfg = config["llms"]
    if provider.lower() == "cortex":
        cortex_openai_cfg = llm_cfg["cortex"]["config"]
        logging.info(f"Loading LLM model: {cortex_openai_cfg['model']}")
        llm = SnowflakeCortexOpenAILLM(config=cortex_openai_cfg)
    # elif provider.lower() == "snowflake":
    #     cortex_cfg = llm_cfg["cortex"]["config"]
    #     logging.info(f"Loading LLM model: {cortex_cfg['model_name']}")
    #     llm = SnowflakeCortexLLM(config=cortex_cfg)
    # elif provider.lower() == "ollama":
    #     ollama_cfg = llm_cfg["ollama"]["config"]
    #     logging.info(f"Loading LLM model: {ollama_cfg['model']}")
    #     llm = OllamaLLM(config=ollama_cfg)
    # elif provider.lower() == "ibm":
    #     watsonx_cfg = llm_cfg["watsonx"]["config"]
    #     logging.info(f"Loading LLM model: {watsonx_cfg['model_id']}")
    #     llm = WatsonXLLM(config=watsonx_cfg)
    # elif provider.lower() == "lmstudio":
    #     openai_cfg = llm_cfg["lmstudio"]["config"]
    #     logging.info(f"Loading LLM model: {openai_cfg['model']}")
    #     llm = ChatOpenAI_LLM(config=openai_cfg)
    return llm