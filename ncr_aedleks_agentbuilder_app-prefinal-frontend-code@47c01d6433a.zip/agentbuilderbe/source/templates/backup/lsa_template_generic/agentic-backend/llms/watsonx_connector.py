"""
Watsonx LLM connector implementation.
"""
from .base_llm import BaseLLM
from ibm_watsonx_ai.foundation_models import ModelInference
from ibm_watsonx_ai import Credentials
from langchain_ibm import ChatWatsonx
import logging

class WatsonXLLM(BaseLLM):
    def __init__(self, config: dict):
        logging.info(f"Loading watsonx config: {config}")
        self._apikey = config['apikey']
        self._project_id = config['project_id']
        self._model_id = config['model_id']
        self._api_url = config['api_url']
        logging.info(f"Loading watsonx model: {self._model_id}")
        not_params = ('apikey', 'project_id', 'model_id', 'api_url')
        self._llm_params = {
            k: v for k, v in config["params"].items() if k not in not_params
        }
        logging.info(f"Loading watsonx params: {self._llm_params}")

        self.model_inference = ModelInference(
            model_id= self._model_id,
            params=self._llm_params,
            credentials=Credentials(
                api_key=self._apikey,
                url=self._api_url
            ),
            project_id=self._project_id
        )
     
        self.model = ChatWatsonx(
            watsonx_model=self.model_inference,
            model_id=self._model_id,
            url=self._api_url,
            apikey=self._apikey,
            project_id=self._project_id,
            params=self._llm_params,
        )

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def llm_params(self) -> dict:
        return self._llm_params