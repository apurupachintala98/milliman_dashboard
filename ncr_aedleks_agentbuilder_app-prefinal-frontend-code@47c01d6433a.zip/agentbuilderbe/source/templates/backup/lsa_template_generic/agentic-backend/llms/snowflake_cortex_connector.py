"""
Snowflake Cortex LLM Connector
"""
from snowflake.snowpark import Session
from .snowflake_cortex_wrapper import ChatSnowflakeCortex
from .base_llm import BaseLLM
import logging
import os

os.environ['REQUESTS_CA_BUNDLE'] = "C:/Users/AM52297/Documents/langgraph_multi_agent_framework-suvojeet/multi_agent_env/Lib/site-packages/certifi/cacert.pem"
os.environ["SNOWFLAKE_DATABASE"] = "POC_SPC_SNOWPARK_DB"
os.environ["SNOWFLAKE_SCHEMA"] = "DATA_SCHEMA"


class SnowflakeCortexLLM(BaseLLM):

    def __init__(self, config: dict):
        logging.info(f"Loading snowflake cortex config: {config}")
        self._user = config["user"]
        self._password = config["password"]
        self._account = config["account"]
        self._host = config["host"]
        self._port = config["port"]
        self._warehouse = config["warehouse"]
        self._role = config["role"]
        self._model_name = config["model_name"]
        self._authenticator = config["authenticator"]
        self._connect_snowflake_using_snowpark()

        self.model = ChatSnowflakeCortex(
            session=self.session,
            model=self._model_name
        )


    def _connect_snowflake_using_snowpark(self):
        """Connect to Snowflake and get authentication token"""
        try:
            # Build a Snowflake session
            connection_parameters = {
                "user": self._user,
                "password": self._password,
                "account": self._account,  
                "host": self._host,
                "port": self._port,
                "warehouse": self._warehouse,
                "role": self._role,
                # "authenticator": self._authenticator,
            }
            self.session = Session.builder.configs(connection_parameters).create()
            logging.info("Connected to Snowflake successfully")
        except Exception as e:
            self.session = None
            logging.info(f"Failed to connect to Snowflake: {e}")

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def llm_params(self) -> dict:
        return self._llm_params