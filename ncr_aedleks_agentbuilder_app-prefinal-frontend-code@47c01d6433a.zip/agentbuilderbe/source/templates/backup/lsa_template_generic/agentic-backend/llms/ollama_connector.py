"""
Ollama LLM connector implementation.
"""
from .base_llm import BaseLLM
from langchain_ollama import ChatOllama
import logging


class OllamaLLM(BaseLLM):
    def __init__(self, config: dict):
        logging.info(f"Loading ollama config: {config}")
        self._model_name = config['model']
        logging.info(f"Loading ollama model: {self._model_name}")
        self._llm_params = {
            k: v for k, v in config["params"].items() if k not in ('model', 'host')
        }
        logging.info(f"Loading ollama params: {self._llm_params}")
        self.model = ChatOllama(model=self._model_name)

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def llm_params(self) -> dict:
        return self._llm_params