"""
Snowflake Cortex OpenAI LLM connector implementation.
This can be used to connect to Snowflake Cortex LLMs via OpenAI API.
"""

import os

# os.environ['REQUESTS_CA_BUNDLE'] = "C:/Users/AM52297/Documents/langgraph_multi_agent_framework-a2a_multiagent/a2a_env/Lib/site-packages/certifi/cacert.pem"
# os.environ['REQUESTS_CA_BUNDLE'] = config['cert_path']

# Set SSL certificate path BEFORE any imports
os.environ['REQUESTS_CA_BUNDLE'] = "C:/Users/AM49922/langgraph_multi_agent_framework/agentic_framework_with_memory/llms/cacert.pem"
# os.environ['SSL_CERT_FILE'] = os.environ['REQUESTS_CA_BUNDLE']
# os.environ['CURL_CA_BUNDLE'] = os.environ['REQUESTS_CA_BUNDLE']

from .base_llm import BaseLLM
from langchain_openai import ChatOpenAI
import httpx
import logging
from pathlib import Path

class SnowflakeCortexOpenAILLM(BaseLLM):
    def __init__(self, config: dict):
        logging.info(f"Loading Snowflake Cortex LLM config: {config}")

        # Resolve cert_path to absolute
        cert_path = Path(config["cert_path"])
        if not cert_path.is_absolute():
            # make it absolute relative to the current file or project root
            base_dir = Path(__file__).resolve().parent.parent.parent  # adjust as needed
            cert_path = (base_dir / cert_path).resolve()
        logging.info(f"Resolved certificate path: {cert_path}")

        self.http_async_client = httpx.AsyncClient(
            verify=str(cert_path),
            timeout=60.0
        )
        self.api_key = config['pat_token']
        self.base_url = config['base_url']
        self.model = config['model']
        self.temperature = config["params"]['temperature']
        logging.info(f"Loading Snowflake Cortex LLM: {self.model}")
        self._llm_params = {
            k: v for k, v in config["params"].items()
        }
        logging.info(f"Loading Snowflake Cortex LLM params: {self._llm_params}")

        self.model = ChatOpenAI(
            http_async_client=self.http_async_client,
            model=self.model,  
            base_url=self.base_url,  
            api_key=self.api_key, 
            temperature=self.temperature,
        )

    @property
    def model_name(self) -> str:
        return self.model

    @property
    def llm_params(self) -> dict:
        return self._llm_params

    # async def generate(self, messages, **kwargs):
    #     params = {**self.llm_params, **kwargs}
    #     return await self.model.ainvoke(messages, **params)
    
