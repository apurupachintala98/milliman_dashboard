# langgraph-multi-agent/state/agent_state.py
from typing import Annotated, Sequence, TypedDict, List
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages
from schemas.user_memory_schema import UserProfile, UserExperience, UserInstruction

class AgentState(TypedDict):
    """
    Represents the state of the LangGraph workflow.

    Attributes:
        messages:
            Conversation history as a sequence of messages.
            New messages are appended to this sequence automatically.

        semantic_memory:
            Stable facts, knowledge, or attributes about the movie.
            Example: genres, characters, settings, themes.

        episodic_memory:
            Events, scenes, or contextual experiences within the movie.
            Example: specific story arcs or detailed plot events.

        procedural_memory:
            Instructions, step-by-step logic, or processes that occur in the movie.
            Example: rituals, repeated strategies, battle plans, etc.
    """
    messages: Annotated[Sequence[AnyMessage], add_messages]
    semantic_memory: UserProfile
    episodic_memory: UserExperience
    procedural_memory: UserInstruction
    classified_memories: List[str]