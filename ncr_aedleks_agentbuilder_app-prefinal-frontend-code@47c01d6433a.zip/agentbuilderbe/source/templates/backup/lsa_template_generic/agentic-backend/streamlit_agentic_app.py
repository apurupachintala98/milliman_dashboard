"""
Agentic Framework Core Entry Point
"""

import asyncio
import os
import sys
import time
import logging
from utils.config_loader import load_config
from utils.logging_utils import setup_logging
from llms.llm_loader import load_llm
from prompts.prompt_loader import get_prompts
from mcp_integration.mcp_setup import setup_mcp_tools
from db.setup_db import get_db_url
from graphs.main_graph import MainGraph
from langgraph.store.postgres.aio import AsyncPostgresStore
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langchain_core.messages import HumanMessage
from pathlib import Path

def transform_configs(configs):
    config = {}

    # LLM Config
    llm = configs["agent_config"]["llm_config"]
    provider_name = llm["provider_name"]
    config["llms"] = {
        provider_name: {
            "provider": provider_name,
            "config": {
                "model": llm["model_id"],
                **llm["llm_auth"],
                "params": {
                    **llm["llm_model_config"]
                }
            }
        }
    }

    # Prompt Config
    react_agent_instructions = configs["agent_config"]["agent_instructions"]
    prompts = configs["static_config"]["prompts"]
    config["prompts"] = prompts

    # Memory Config
    long_term_memory_config = {}
    for key, val in configs["memory_config"]["long_term_memory_config"].items():
        if "semantic" in key:
            long_term_memory_config["semantic"] = val
        elif "episodic" in key:
            long_term_memory_config["episodic"] = val
        elif "procedural" in key:
            long_term_memory_config["procedural"] = val

    memory_config = {
        "short_term_memory_needed": configs["memory_config"]["short_term_memory_needed"],
        "long_term_memory_needed": configs["memory_config"]["long_term_memory_needed"],
        "long_term_memory_config": long_term_memory_config
    }

    # Database Config
    config["database"] = configs["memory_config"]["database"]

    # MCP Tool Config
    servers = {}
    for tool in configs["tool_config"]["tools"]:
        if tool["transport"] == "stdio":
            BASE_DIR = Path(__file__).resolve().parent.parent
            args = str(BASE_DIR / tool["config"]["args"])
            servers[tool["name"]] = {
                "command": tool["config"]["command"],
                "args": [args],
                "transport": tool["transport"]
            }
        else:
            servers[tool["name"]] = {
                "url": tool["config"]["url"],
                "transport": tool["transport"]
            }
    config["mcp"] = {"servers": servers}

    # Frontend Config
    config["frontend"] = {
        "port": configs["frontend_config"]["port"]
    }

    return config, memory_config, react_agent_instructions

async def call_agent(user_id, thread_id, user_prompt):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    static_config = load_config(os.path.join(base_dir, "config", "static_config.yaml"))
    
    # Logging setup
    logging_config_path = os.path.join(base_dir, static_config["logging"]["config"])
    setup_logging(logging_config_path)
    logging.info(f"Logging configuration completed. Path: {logging_config_path}")
    
    ## Agent Builder Change ##

    config_files = os.listdir(os.path.join(base_dir, "config"))
    configs = {
        config_file.split(".")[0]: load_config(os.path.join(base_dir, "config", config_file))
        for config_file in config_files 
        if config_file.endswith(".yaml")
    }
    config, memory_config, react_agent_instructions = transform_configs(configs)
    logging.info(f"Config: {config}")
    logging.info(f"Memory Config: {memory_config}")

    ## Agent Builder Change ##

    # Load LLM
    llm = load_llm(config, list(config['llms'].keys())[0])

    # MCP tools setup
    tools = await setup_mcp_tools(config)

    # System prompts
    prompts = get_prompts(config)

    # Graph store and checkpointer
    db_url = get_db_url(config)

    # return config, memory_config, react_agent_instructions, llm, tools, prompts, db_url

    # base_dir = os.path.dirname(os.path.abspath(__file__))
    # config = load_config(os.path.join(base_dir, "config", "config.yaml"))

    # Logging setup
    # logging_config_path = os.path.join(base_dir, config["logging"]["config"])
    # setup_logging(logging_config_path)

    # Load LLM
    # llm = load_llm(config, "snowflake")

    # MCP tools setup
    # tools = await setup_mcp_tools(config)

    # System prompts
    # prompts = get_prompts(config)

    # Graph store and checkpointer
    # db_url = get_db_url(config)

    async with (
        AsyncPostgresStore.from_conn_string(db_url) as store,
        AsyncPostgresSaver.from_conn_string(db_url) as checkpointer,
    ):
        
        # Create LangGraph
        graph_instance = MainGraph(config, memory_config, react_agent_instructions, llm, prompts, tools, store, checkpointer)
        # graph_instance = MainGraph(config, llm, prompts, tools, store, checkpointer)
        graph = graph_instance.get_main_graph()

        if not user_prompt or not user_prompt.strip():
            return
        run_config = {
            "configurable": {
                "thread_id": f"{user_id}:{thread_id}", 
                "user_id": user_id
            }
        }

        user_input = {"messages": [HumanMessage(content=user_prompt)]}
        start_time = time.time()
        response_state = await graph.ainvoke(user_input, config=run_config)
        time_taken = time.time() - start_time
        time_taken = f"{int(time_taken // 60)} {'minute' if int(time_taken // 60) == 1 else 'minutes'} {time_taken % 60:.2f} seconds" if time_taken > 60 else f"{time_taken:.2f} seconds"
        logging.info(f"Time taken: {time_taken}")

        return response_state

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    # For Debugging Purpose
    simulate = True
    while simulate:
        user_id = input("Enter user id: ")
        thread_id = input("Enter thread id: ")
        user_input = input("Enter your query: ")
        response_state = asyncio.run(call_agent(user_id, thread_id, user_input))
        print(f"User Profile: \n{response_state["semantinc_memory"]}")
        print(f"User Experiences: {response_state["episodic_memory"]}")
        print(f"User Instructions: {response_state["procedural_memory"]}")
        for response in response_state["messages"]:
            response.pretty_print()
        if input("Do you want to continue? (Yes/No): ").lower() == "yes":
            simulate = True
        else:
            simulate = False