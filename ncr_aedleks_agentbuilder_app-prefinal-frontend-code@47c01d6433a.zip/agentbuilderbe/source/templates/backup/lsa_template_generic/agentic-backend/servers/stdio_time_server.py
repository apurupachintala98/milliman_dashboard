
from fastmcp import FastMCP
from datetime import datetime
import pytz

mcp = FastMCP("Time")

def log_tool_call(tool_name, *args, **kwargs):
    print(f"[TOOL CALL] {tool_name} called with args={args}, kwargs={kwargs}")

def log_tool_result(tool_name, result):
    print(f"[TOOL RESULT] {tool_name} returned: {result}")

@mcp.tool()
def get_current_date_time(timezone: str = 'Asia/Kolkata'):
    """
    Get the current date and time in a given timezone.

    When to use:
    - Use this tool whenever the user asks for the current date, time, or both.
    - Example requests: "What time is it in New York?", "Give me the current date in Tokyo", 
      "Tell me the time now", "What's the date today in London?".

    Input:
    - timezone (string): A valid pytz timezone name. 
      Examples: "Asia/Kolkata", "America/New_York", "Europe/London", "UTC".
      If no timezone is provided, default is "Asia/Kolkata".

    Output:
    - A string with the current date and time in the format "YYYY-MM-DD HH:MM:SS".

    Rules:
    - Always call this tool if the user asks about the current date or time.
    - If the user does not specify a timezone, use the default ("Asia/Kolkata").
    - If the user provides an invalid timezone, return an error message indicating that.
    """

    log_tool_call("get_current_date_time", timezone=timezone)
    try:
        # Set the timezone
        tz = pytz.timezone(timezone)
        # Get current time in that timezone
        current_time = datetime.now(tz)
        formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
        print(f"Current time in {timezone}: {formatted_time}")
    except pytz.UnknownTimeZoneError:
        formatted_time = f"Unknown timezone: {timezone}. Please provide a valid timezone name."
    log_tool_result("get_current_date_time", formatted_time)
    return formatted_time

if __name__ == "__main__":
    mcp.run(transport="stdio")