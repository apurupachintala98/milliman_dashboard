
from fastmcp import FastMCP
from langchain_community.tools import YouTubeSearchTool

mcp = FastMCP("YouTube", port=6003)

# Initialize the DuckDuckGo search tool
yt_tool = YouTubeSearchTool()

def log_tool_call(tool_name, *args, **kwargs):
    print(f"[TOOL CALL] {tool_name} called with args={args}, kwargs={kwargs}")

def log_tool_result(tool_name, result):
    print(f"[TOOL RESULT] {tool_name} returned: {result}")

@mcp.tool()
def youtube_search(query: str) -> str:
    """
    Search YouTube for videos.

    When to use:
    - Use this tool whenever the user asks for videos, tutorials, songs, reviews, lectures, or any video-based content.
    - Example requests: "Python tutorial videos", "motivational speech by Steve Jobs", "funny cat videos", "official trailer of Dune 2".

    Input:
    - A short search query (string) with keywords or a natural phrase.
      Example: "machine learning basics tutorial"

    Output:
    - A list of YouTube video titles and links matching the search.

    Rules:
    - Always call this tool if the user specifically asks for YouTube content or videos.
    - Do NOT summarize from memory — instead, fetch fresh results from YouTube.
    - Provide the query exactly as the user asked (no rewriting needed).
    """
    log_tool_call("youtube_search", query)
    result = yt_tool.run(query)
    log_tool_result("youtube_search", result)
    return result

 
if __name__ == "__main__":
    mcp.run(transport="http")