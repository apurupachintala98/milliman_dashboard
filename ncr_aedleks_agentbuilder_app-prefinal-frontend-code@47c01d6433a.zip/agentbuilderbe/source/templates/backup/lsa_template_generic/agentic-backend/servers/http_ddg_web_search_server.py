
from fastmcp import FastMCP
from ddgs import DDGS

mcp = FastMCP("DuckDuckGo", port=6001)

def log_tool_call(tool_name, *args, **kwargs):
    print(f"[TOOL CALL] {tool_name} called with args={args}, kwargs={kwargs}")

def log_tool_result(tool_name, result):
    print(f"[TOOL RESULT] {tool_name} returned: {result}")

@mcp.tool()
def duckduckgo_search(query) -> str:
    """
    Search the internet using DuckDuckGo.

    When to use:
    - Use this tool whenever the user asks for information, facts, or resources that require looking up on the web.
    - Example requests: "latest news about AI", "top places to visit in Kolkata", "current weather in Paris", "who won the 2024 cricket world cup".

    Input:
    - A short search query (string) with keywords or a natural language phrase.
      Example: "best programming languages 2025"

    Output:
    - Text results (summaries/snippets) from DuckDuckGo search.

    Rules:
    - Always call this tool if the user asks for online info, recent events, or factual lookups.
    - Do NOT answer from memory if the query is about current data or facts — always call this tool.
    - Provide the query exactly as the user asked (no rewriting needed).
    """
    log_tool_call("duckduckgo_search", query)
    if isinstance(query, str):
        query_text = query
    elif isinstance(query, dict):
        query_text = query["query"]
    result = DDGS().text(query_text, region="in-en", safesearch="off")
    result = "\n".join([res["body"] for res in result])
    log_tool_result("duckduckgo_search", result)
    return result


if __name__ == "__main__":
    mcp.run(transport="sse")