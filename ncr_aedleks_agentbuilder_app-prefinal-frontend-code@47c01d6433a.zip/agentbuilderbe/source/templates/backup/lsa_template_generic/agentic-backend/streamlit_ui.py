"""
Agentic Framework UI (Streamlit) Entry point
"""
from streamlit_agentic_app import call_agent
import streamlit as st
import sys
import asyncio

def set_page_configuration():
    """Configure Streamlit page and initialize session state."""
    st.set_page_config(
        page_title="Multi-Agent Framework",
        page_icon="🤖",
        layout="centered",
    )

    st.markdown(
        """
            <style>
                .block-container {
                    padding-top: 2.5rem; /* reduce Streamlit default padding */
                }
                .title-block {
                    text-align: center;
                    margin-top: 0.5rem;
                }
            </style>

            <div class="title-block">
                <h4>🤖 Multi-Agent Framework with Memory & Tools</h4>
            </div>
        """,
        unsafe_allow_html=True
    )

    # Initialize session state variables if not present
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "state_messages" not in st.session_state:
        st.session_state.state_messages = {}
    if "long_term_memories" not in st.session_state:
        st.session_state.long_term_memories = {}


def render_sidebar():
    """Render sidebar controls and session configuration."""
    with st.sidebar:
        if st.button("Clear Chat"):
            st.session_state.messages = []
            st.session_state.state_messages = {}
            st.session_state.long_term_memories = {}
            st.rerun()

        st.title("Session Config")
        user_input = st.text_input(
            "User ID",
            value=st.session_state.get("user_id", ""),
            key="user_input"
        )
        thread_input = st.text_input(
            "Session ID (Thread)",
            value=st.session_state.get("thread_id", ""),
            key="thread_input"
        )

        submit_disabled = not user_input.strip() or not thread_input.strip()

        if st.button("Submit", disabled=submit_disabled):
            prev_user_id = st.session_state.get("user_id")
            prev_thread_id = st.session_state.get("thread_id")

            if prev_user_id != user_input or prev_thread_id != thread_input:
                st.session_state.messages = []
                st.session_state.state_messages = {}
                st.session_state.long_term_memories = {}

            st.session_state.user_id = user_input
            st.session_state.thread_id = thread_input
            st.success("Session configuration updated.")
            st.rerun()

    # Fallback defaults
    user_id = st.session_state.get("user_id", "1")
    thread_id = st.session_state.get("thread_id", "101")
    return user_id, thread_id


def render_tabs():
    """Render tabs for Chat, Logs, and Memory."""
    tab1, tab2, tab3 = st.tabs(["💬 Chat", "🛠️ State", "🧠 Memory"])

    with tab1:
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

    with tab2:
        st.subheader("Current State")
        st.json(st.session_state.state_messages)

    with tab3:
        st.subheader("Long Term Memory")
        st.json(st.session_state.long_term_memories)


async def render_chat_window(user_id, thread_id):
    """Get input from the chat input box."""
    if not st.session_state.get("user_id") or not st.session_state.get("thread_id"):
        st.info("Please set both User ID and Session ID in the sidebar to start chatting.")
    else:
        if user_prompt := st.chat_input("Ask something..."):
            user_prompt = user_prompt.strip()
            st.session_state.messages.append({"role": "user", "content": user_prompt})
            
            with st.chat_message("user"):
                st.markdown(user_prompt)

            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    response_state = await call_agent(user_id, thread_id, user_prompt)
                    response = response_state["messages"][-1]
                    st.markdown(response.content)
                    st.session_state.messages.append({"role": "assistant", "content": response.content})
                    st.session_state.long_term_memories["Semantic Memory"] = response_state["semantic_memory"]
                    st.session_state.long_term_memories["Episodic Memory"] = response_state["episodic_memory"]
                    st.session_state.long_term_memories["Procedural Memory"] = response_state["procedural_memory"]
                    for res in response_state["messages"]:
                        msg_type = res.type
                        msg_content = res.content
                        if msg_type and msg_content:
                            if msg_type not in st.session_state.state_messages:
                                st.session_state.state_messages[msg_type] = []
                            if msg_content not in st.session_state.state_messages[msg_type]:
                                st.session_state.state_messages[msg_type].append(msg_content)
            st.rerun()

async def render_agentic_app_ui():
    set_page_configuration()
    user_id, thread_id = render_sidebar()
    render_tabs()
    await render_chat_window(user_id, thread_id)

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(render_agentic_app_ui()) 