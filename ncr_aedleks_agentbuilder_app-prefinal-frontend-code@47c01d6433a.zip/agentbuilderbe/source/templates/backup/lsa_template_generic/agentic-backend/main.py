"""
main.py - Entry point to access all APIs
"""
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from langgraph.store.postgres.aio import AsyncPostgresStore
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from utils.config_loader import load_config
from utils.logging_utils import setup_logging
from llms.llm_loader import load_llm
from prompts.prompt_loader import get_prompts
from mcp_integration.mcp_setup import setup_mcp_tools
from db.setup_db import get_db_url
from graphs.main_graph import MainGraph
from api.routers import health, chat
from pathlib import Path
import uvicorn
import logging


def transform_configs(configs):
    config = {}

    # LLM Config
    llm = configs["agent_config"]["llm_config"]
    provider_name = llm["provider_name"]
    config["llms"] = {
        provider_name: {
            "provider": provider_name,
            "config": {
                "model": llm["model_id"],
                **llm["llm_auth"],
                "params": {
                    **llm["llm_model_config"]
                }
            }
        }
    }

    # Prompt Config
    react_agent_instructions = configs["agent_config"]["agent_instructions"]
    prompts = configs["static_config"]["prompts"]
    config["prompts"] = prompts

    # Memory Config
    long_term_memory_config = {}
    for key, val in configs["memory_config"]["long_term_memory_config"].items():
        if "semantic" in key:
            long_term_memory_config["semantic"] = val
        elif "episodic" in key:
            long_term_memory_config["episodic"] = val
        elif "procedural" in key:
            long_term_memory_config["procedural"] = val

    memory_config = {
        "short_term_memory_needed": configs["memory_config"]["short_term_memory_needed"],
        "long_term_memory_needed": configs["memory_config"]["long_term_memory_needed"],
        "long_term_memory_config": long_term_memory_config
    }

    # Database Config
    config["database"] = configs["memory_config"]["database"]

    # MCP Tool Config
    servers = {}
    for tool in configs["tool_config"]["tools"]:
        if tool["transport"] == "stdio":
            BASE_DIR = Path(__file__).resolve().parent.parent
            args = BASE_DIR / tool["config"]["args"]
            servers[tool["name"]] = {
                "command": tool["config"]["command"],
                "args": [str(args.as_posix())],
                "transport": tool["transport"]
            }
        else:
            servers[tool["name"]] = {
                "url": tool["config"]["url"],
                "transport": tool["transport"]
            }
    config["mcp"] = {"servers": servers}

    # Frontend Config
    config["frontend"] = {
        "port": configs["frontend_config"]["port"]
    }

    return config, memory_config, react_agent_instructions


async def initialize_startup_events():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    static_config = load_config(os.path.join(base_dir, "config", "static_config.yaml"))
    
    # Logging setup
    logging_config_path = os.path.join(base_dir, static_config["logging"]["config"])
    setup_logging(logging_config_path)
    logging.info(f"Logging configuration completed. Path: {logging_config_path}\n")
    
    ## Agent Builder Change ##

    config_files = os.listdir(os.path.join(base_dir, "config"))
    configs = {
        config_file.split(".")[0]: load_config(os.path.join(base_dir, "config", config_file))
        for config_file in config_files 
        if config_file.endswith(".yaml")
    }
    config, memory_config, react_agent_instructions = transform_configs(configs)
    logging.info(f"Config: {config}\n")
    logging.info(f"Memory Config: {memory_config}\n")

    ## Agent Builder Change ##

    # Load LLM
    llm = load_llm(config, list(config['llms'].keys())[0])

    # MCP tools setup
    tools = await setup_mcp_tools(config)

    # System prompts
    prompts = get_prompts(config)

    # Graph store and checkpointer
    db_url = get_db_url(config)

    return config, memory_config, react_agent_instructions, llm, tools, prompts, db_url


@asynccontextmanager
async def lifespan(app: FastAPI):
    config, memory_config, react_agent_instructions, llm, tools, prompts, db_url = await initialize_startup_events()
    async with (
        AsyncPostgresStore.from_conn_string(db_url) as store,
        AsyncPostgresSaver.from_conn_string(db_url) as checkpointer,
    ):
        graph_instance = MainGraph(config, memory_config, react_agent_instructions, llm, prompts, tools, store, checkpointer)
        app.state.graph = graph_instance.get_main_graph()
        yield


app = FastAPI(
    title="Multi-Agent Framework API",
    description="API for interacting with the multi-agent framework",
    version="1.0.0",
    root_path="/api",
    lifespan=lifespan
)


# Add CORS middleware
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Register routers
app.include_router(health.router, prefix="/health", tags=["Health"])
app.include_router(chat.router, prefix="/agent", tags=["Agent"])


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # Load the backend config YAML directly
    backend_config_path = os.path.join(base_dir, "config", "backend_config.yaml")
    backend_config = load_config(backend_config_path)
    host = backend_config.get("host", "127.0.0.1")
    port = backend_config.get("port", 8080)
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True
    )