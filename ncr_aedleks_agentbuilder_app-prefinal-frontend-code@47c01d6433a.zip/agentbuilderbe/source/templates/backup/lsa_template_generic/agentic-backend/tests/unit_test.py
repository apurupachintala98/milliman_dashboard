"""
Basic unit tests for core components.
"""
import unittest

class TestBasic(unittest.TestCase):
    def test_imports(self):
        try:
            import agentic_framework.agents.base_agent
            import agentic_framework.llms.base_llm
            import agentic_framework.mcp_integration.mcp_client
        except Exception as e:
            self.fail(f"Import failed: {e}")

if __name__ == "__main__":
    unittest.main()
