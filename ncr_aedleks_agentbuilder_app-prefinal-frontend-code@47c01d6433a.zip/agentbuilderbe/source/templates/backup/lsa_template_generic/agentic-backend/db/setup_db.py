
def get_db_url(config) -> str:
    hostname = config["database"]["hostname"]
    port = config["database"]["port"]
    username = config["database"]["username"]
    password = config["database"]["password"]
    database_name = config["database"]["database_name"]
    return f"postgresql://{username}:{password}@{hostname}:{port}/{database_name}"