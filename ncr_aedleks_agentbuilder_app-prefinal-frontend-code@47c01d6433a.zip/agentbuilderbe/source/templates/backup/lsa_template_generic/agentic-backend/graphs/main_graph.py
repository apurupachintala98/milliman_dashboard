"""
Main Graph -> This class is used to build the graph for the Agentic Framework
"""
from langchain_core.runnables import RunnableConfig
from langgraph.graph import StateGraph, START
from langgraph.prebuilt import ToolNode, tools_condition
import logging
from agents.react_agent import ReActAgent
from memory.semantic_memory_updater import SemanticMemoryUpdater
from memory.episodic_memory_updater import EpisodicMemoryUpdater
from memory.procedural_memory_updater import ProceduralMemoryUpdater
from memory.input_classifier import InputClassifier, input_classifier_node
from memory.memory_classifier import MemoryClassifier, memory_classifier_node
from states.agent_state import AgentState
from functools import partial


class MainGraph:
    def __init__(self, config, memory_config, react_agent_instructions, llm, prompts, tools, store, checkpointer):
        self.config = config
        self.memory_config = memory_config
        self.react_agent_instructions = react_agent_instructions
        self.llm = llm
        self.prompts = prompts
        self.tools = tools
        self.store = store
        self.checkpointer = checkpointer
        self.workflow = StateGraph(AgentState)
        self._initialize_memory_updaters()
        self._initialize_agents()
        self._build_graph()

    def _initialize_memory_updaters(self):
        input_classifier_system_prompt = self.prompts["input_classifier_system_prompt"]
        input_classifier_user_prompt = self.prompts["input_classifier_user_prompt"]
        self.input_classifier = InputClassifier(
            self.llm, 
            input_classifier_system_prompt,
            input_classifier_user_prompt
        )
        logging.info(f"InputClassifier Initialized\n")

        memory_classifier_system_prompt = self.prompts["memory_classifier_system_prompt"]
        memory_classifier_user_prompt = self.prompts["memory_classifier_user_prompt"]
        self.memory_classifier = MemoryClassifier(
            self.llm, 
            memory_classifier_system_prompt,
            memory_classifier_user_prompt,
            self.memory_config
        )
        logging.info(f"MemoryClassifier Initialized\n")

        semantic_memory_updater_system_prompt = self.prompts["semantic_memory_updater_system_prompt"]
        semantic_memory_updater_user_prompt = self.prompts["semantic_memory_updater_user_prompt"]
        self.semantic_memory_updater = SemanticMemoryUpdater(
            self.llm, 
            semantic_memory_updater_system_prompt, 
            semantic_memory_updater_user_prompt, 
            self.store
        )
        logging.info(f"SemanticMemoryUpdater Initialized\n")

        episodic_memory_updater_system_prompt = self.prompts["episodic_memory_updater_system_prompt"]
        episodic_memory_updater_user_prompt = self.prompts["episodic_memory_updater_user_prompt"]
        self.episodic_memory_updater = EpisodicMemoryUpdater(
            self.llm, 
            episodic_memory_updater_system_prompt, 
            episodic_memory_updater_user_prompt, 
            self.store
        )
        logging.info(f"EpisodicMemoryUpdater Initialized\n")

        procedural_memory_updater_system_prompt = self.prompts["procedural_memory_updater_system_prompt"]
        procedural_memory_updater_user_prompt = self.prompts["procedural_memory_updater_user_prompt"]
        self.procedural_memory_updater = ProceduralMemoryUpdater(
            self.llm, 
            procedural_memory_updater_system_prompt, 
            procedural_memory_updater_user_prompt, 
            self.store
        )
        logging.info(f"ProceduralMemoryUpdater Initialized\n")
    
    def _initialize_agents(self):
        react_agent_system_prompt = self.prompts["react_agent_system_prompt"]
        self.react_agent = ReActAgent(self.llm, react_agent_system_prompt, None, self.tools, self.store, self.memory_config, self.react_agent_instructions)
        logging.info(f"ReActAgent Initialized\n")
    
    async def _update_memories(self, state: AgentState, config: RunnableConfig):
        # Get memory configuration from config
        long_term_memory_config = self.memory_config["long_term_memory_config"]
        logging.info(f"Current Agent State after Memory Classification: {state}\n")
        logging.info(f"Long Term Memory Config: {long_term_memory_config}\n")
        
        for memory_type in state["classified_memories"]:
            if memory_type == "semantic_memory" and long_term_memory_config.get("semantic", True):
                state = await self.semantic_memory_updater.execute_with_memory(state, config)
            elif memory_type == "episodic_memory" and long_term_memory_config.get("episodic", True):
                state = await self.episodic_memory_updater.execute_with_memory(state, config)
            elif memory_type == "procedural_memory" and long_term_memory_config.get("procedural", True):
                state = await self.procedural_memory_updater.execute_with_memory(state, config)
            logging.info(f"Agent State during {memory_type} Memory Update: {state}\n")
        
        return state
    
    def _build_graph(self):
        self.workflow.add_node(
            "input_classifier",
            partial(input_classifier_node, classifier=self.input_classifier),
            is_async=True,
        )
        self.workflow.add_node(
            "memory_classifier", 
            partial(memory_classifier_node, classifier=self.memory_classifier),
            is_async=True,
        )
        self.workflow.add_node("update_memories", self._update_memories)
        self.workflow.add_node("react_agent", self.react_agent.execute_with_memory)
        self.workflow.add_node("tools", ToolNode(self.tools))
        self.workflow.add_edge(START, "input_classifier")
        self.workflow.add_conditional_edges(
            "input_classifier",
            lambda state: state["classification"],
            {
                "memory": "memory_classifier",
                "query": "react_agent",
            }
        )
        self.workflow.add_edge("memory_classifier", "update_memories")
        self.workflow.add_edge("update_memories", "react_agent")
        self.workflow.add_conditional_edges("react_agent", tools_condition)
        self.workflow.add_edge("tools", "react_agent")
        logging.info(f"StateGraph initialized\n")

    def get_main_graph(self):
        graph = self.workflow.compile(store=self.store, checkpointer=self.checkpointer)
        # with open("main_graph.png", "wb") as f:
        #     f.write(graph.get_graph().draw_mermaid_png())
        return graph