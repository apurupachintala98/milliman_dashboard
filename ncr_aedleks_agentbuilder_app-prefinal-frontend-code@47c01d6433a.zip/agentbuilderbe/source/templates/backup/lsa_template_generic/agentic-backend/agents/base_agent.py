"""
Base class for all agents.
Defines the interface and shared logic for agent state and message handling.
"""
from abc import ABC, abstractmethod
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool
from langgraph.store.base import BaseStore
from typing import Optional


class BaseAgent(ABC):
    def __init__(self, llm, system_prompt: str, user_prompt: str, tools: list[BaseTool], store: BaseStore):
        self.llm = llm
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.tools = tools
        self.store = store
        self.agent_runnable = self._create_agent_runnable()

    @abstractmethod
    def _create_agent_runnable(self) -> Runnable:
        pass

    def get_runnable(self) -> Runnable:
        return self.agent_runnable