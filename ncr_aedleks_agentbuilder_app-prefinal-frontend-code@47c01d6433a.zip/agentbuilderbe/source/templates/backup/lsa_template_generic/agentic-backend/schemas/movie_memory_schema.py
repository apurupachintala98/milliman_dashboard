"""
Memory Schemas for Agentic Framework (Upgraded with Pydantic Models)

These schemas define the three major memory types:
- SemanticMemory: facts (people, teams, locations)
- EpisodicMemory: events and experiences
- ProceduralMemory: rules, tech, and procedures
"""

from pydantic import BaseModel, Field
from typing import List, Literal, Optional


# -------------------- Input / Routing --------------------

class InputClass(BaseModel):
    input_type: Literal["description", "query"] = Field(
        ..., description="Defines whether the input is a narrative description or a user query."
    )

class MemoryRoute(BaseModel):
    memories: List[Literal["semantic", "episodic", "procedural"]] = Field(
        ..., description="Which memory types to use for handling the input."
    )

class MemorySplit(BaseModel):
    semantic: str = Field("", description="Slice of text relevant to SemanticMemory")
    episodic: str = Field("", description="Slice of text relevant to EpisodicMemory")
    procedural: str = Field("", description="Slice of text relevant to ProceduralMemory")


# -------------------- Semantic Memory --------------------

class Background(BaseModel):
    role: str = Field(..., description="The character's role in the story (e.g., driver, engineer).")
    history: str = Field(..., description="Background history of the character.")
    medical_issues: Optional[str] = Field(None, description="Any known medical issues of the character.")


class CurrentStatus(BaseModel):
    team: str = Field(..., description="The current team affiliation of the character.")
    role: str = Field(..., description="The current role of the character in the team/story.")
    key_events: str = Field(..., description="Recent or ongoing key events involving the character.")
    status: str = Field(..., description="Current state/status (e.g., active, injured, suspended).")


class GoalsAmbitions(BaseModel):
    primary: str = Field(..., description="The primary goal or ambition of the character.")
    secondary: Optional[str] = Field(None, description="Any secondary or less critical ambition.")


class Character(BaseModel):
    name: str = Field(..., description="The full name of the character.")
    actor: str = Field(..., description="The actor portraying this character.")
    background: Background = Field(..., description="Details about the character’s past background.")
    current_status: CurrentStatus = Field(..., description="The character’s current role and situation.")
    goals_ambitions: GoalsAmbitions = Field(..., description="The ambitions and goals of the character.")


class SemanticMemory(BaseModel):
    characters: List[Character] = Field(default_factory=list, description="List of all major characters in the movie.")


# -------------------- Episodic Memory --------------------

class Event(BaseModel):
    event_id: int = Field(..., description="Unique numeric identifier for the event.")
    name: str = Field(..., description="Name of the event (e.g., 'Monaco Grand Prix').")
    location: str = Field(..., description="The location or venue of the event.")
    time: str = Field(..., description="The time or date when the event took place.")
    description: str = Field(..., description="A narrative description of the event.")
    outcome: Optional[str] = Field(None, description="The outcome or result of the event.")
    key_characters: List[str] = Field(default_factory=list, description="Names of characters central to the event.")


class EpisodicMemory(BaseModel):
    events: List[Event] = Field(default_factory=list, description="List of key plot events in the movie.")


# -------------------- Procedural Memory --------------------

class FIAGovernance(BaseModel):
    authority: str = Field(..., description="The governing authority (e.g., FIA).")
    responsibilities: List[str] = Field(default_factory=list, description="Responsibilities handled by the governing authority.")


class Dimensions(BaseModel):
    max_width: str = Field(..., description="Maximum car width allowed by regulations.")
    max_height: str = Field(..., description="Maximum car height allowed by regulations.")
    max_wheelbase: str = Field(..., description="Maximum wheelbase allowed by regulations.")


class Engine(BaseModel):
    type: str = Field(..., description="Type of engine (e.g., V6 turbo hybrid).")
    max_rpm: int = Field(..., description="Maximum revolutions per minute allowed.")
    fuel_limit: str = Field(..., description="Maximum amount of fuel allowed per race.")
    fuel_flow: str = Field(..., description="Fuel flow restriction details.")


class CarSpecifications(BaseModel):
    minimum_weight: str = Field(..., description="Minimum weight requirement of the car.")
    dimensions: Dimensions = Field(..., description="Car dimension limits.")
    engine: Engine = Field(..., description="Engine specifications and restrictions.")
    power_unit_components: List[str] = Field(default_factory=list, description="List of power unit components.")
    component_limits: str = Field(..., description="Limits on number of components used per season.")


class SafetyRequirements(BaseModel):
    chassis: str = Field(..., description="Requirements for chassis design.")
    crash_tests: List[str] = Field(default_factory=list, description="Crash tests mandated by FIA.")
    banned_tech: List[str] = Field(default_factory=list, description="Technologies banned for safety reasons.")


class Tyres(BaseModel):
    supplier: str = Field(..., description="Official tyre supplier.")
    types: List[str] = Field(default_factory=list, description="Types of tyres available (soft, medium, hard, wet).")
    rules: str = Field(..., description="Rules for tyre usage in races.")


class TechnicalRegulations(BaseModel):
    car_specifications: CarSpecifications = Field(..., description="Technical car specification regulations.")
    safety_requirements: SafetyRequirements = Field(..., description="Safety requirements for the car.")
    tyres: Tyres = Field(..., description="Tyre regulations and rules.")


class RaceFormat(BaseModel):
    weekend_structure: List[str] = Field(default_factory=list, description="Structure of the race weekend (practice, qualifying, race).")
    start_procedure: List[str] = Field(default_factory=list, description="Rules for starting procedure (formation lap, grid, etc.).")


class RaceManagement(BaseModel):
    safety_car: str = Field(..., description="Rules and procedures involving safety car deployment.")
    red_flag: str = Field(..., description="Rules when a red flag is issued.")
    wet_weather: str = Field(..., description="Rules for wet weather conditions and tyres.")


class SportingRegulations(BaseModel):
    race_format: RaceFormat = Field(..., description="Structure and rules of race weekends.")
    race_management: RaceManagement = Field(..., description="Rules for managing race interruptions and conditions.")
    parc_ferme: str = Field(..., description="Regulations around parc fermé conditions.")


class PointsSystem(BaseModel):
    top_10: List[int] = Field(default_factory=list, description="Points awarded to the top 10 finishers.")
    fastest_lap: str = Field(..., description="Points awarded for the fastest lap rule.")


class Penalties(BaseModel):
    types: List[str] = Field(default_factory=list, description="Types of penalties (e.g., drive-through, grid drop).")
    examples: List[str] = Field(default_factory=list, description="Examples of situations leading to penalties.")


class SafetyFeatures(BaseModel):
    equipment: List[str] = Field(default_factory=list, description="Safety equipment required (e.g., Halo, fire extinguisher).")


class BudgetCap(BaseModel):
    amount: str = Field(..., description="The maximum allowed budget cap.")
    purpose: str = Field(..., description="The purpose or scope of the budget cap restrictions.")


class ProceduralMemory(BaseModel):
    fia_governance: Optional[FIAGovernance] = Field(None, description="FIA governance authority and responsibilities.")
    technical_regulations: Optional[TechnicalRegulations] = Field(None, description="Technical rules for car design and safety.")
    sporting_regulations: Optional[SportingRegulations] = Field(None, description="Rules governing sporting aspects of races.")
    points_system: Optional[PointsSystem] = Field(None, description="Scoring system for races and seasons.")
    penalties: Optional[Penalties] = Field(None, description="Penalties applicable for infractions.")
    safety_features: Optional[SafetyFeatures] = Field(None, description="Safety features mandated by regulations.")
    budget_cap: Optional[BudgetCap] = Field(None, description="Financial regulations like budget caps.")


# -------------------- Default Schemas --------------------

DEFAULT_SCHEMAS = {
    "semantic_memory": SemanticMemory().model_dump(),
    "episodic_memory": EpisodicMemory().model_dump(),
    "procedural_memory": ProceduralMemory().model_dump(),
}


# ---------------------------------------------------------




# # -------------------- Old version ---------------------- # #
# # -------------------- Semantic Memory ------------------ # #

# class Person(BaseModel):
#     id: str
#     name: str
#     role: Optional[str] = ""
#     team: Optional[str] = ""
#     nationality: Optional[str] = ""
#     status: Optional[str] = ""
#     skills: List[str] = []
#     goals: List[str] = []
#     relationships: List[str] = []


# class Team(BaseModel):
#     id: str
#     name: str
#     tier: Optional[str] = ""
#     principal: Optional[str] = ""
#     drivers: List[str] = []


# class Location(BaseModel):
#     id: str
#     name: str
#     country: Optional[str] = ""


# class SemanticMemory(BaseModel):
#     people: List[Person] = []
#     teams: List[Team] = []
#     locations: List[Location] = []


# # -------------------- Episodic Memory --------------------

# class Result(RootModel[Dict[str, str]]):
#     pass


# class Event(BaseModel):
#     id: str
#     round: int = 0
#     location: str = ""
#     summary: str = ""
#     result: Result = Result({})
#     incident: Optional[str] = ""


# class EpisodicMemory(BaseModel):
#     season: str = ""
#     events: List[Event] = []


# # -------------------- Procedural Memory --------------------

# class Rule(BaseModel):
#     id: str
#     name: str


# class Tech(BaseModel):
#     id: str
#     name: str


# class Procedure(BaseModel):
#     id: str
#     name: str


# class ProceduralMemory(BaseModel):
#     rules: List[Rule] = []
#     tech: List[Tech] = []
#     procedures: List[Procedure] = []


# # -------------------- Default Schemas --------------------

# DEFAULT_SCHEMAS = {
#     "semantic_memory": SemanticMemory().model_dump(),
#     "episodic_memory": EpisodicMemory().model_dump(),
#     "procedural_memory": ProceduralMemory().model_dump()
# }