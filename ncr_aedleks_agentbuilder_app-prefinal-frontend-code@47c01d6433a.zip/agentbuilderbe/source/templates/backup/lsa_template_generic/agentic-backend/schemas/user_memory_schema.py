"""
Schema definitions for user memory types:
- InputClassification (input classified by the LLM)
- MemoryClassification (memories classified by the LLM)
- Semantic (facts)
- Episodic (experiences)
- Procedural (instructions)
"""
from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class InputClassification(BaseModel):
    """
    Classifies whether user input should be stored as memory or treated as a query.
    """
    input_type: Literal["memory", "query"] = Field(
        ...,
        description=(
            "'memory' if the input contains information worth storing "
            "(to be further routed by MemoryRoute into semantic/episodic/procedural), "
            "'query' if the input is only a question or not memory-worthy."
        )
    )


class MemoryClassification(BaseModel):
    """
    Classifies whether a given user input should be stored as memory and, if so,
    which type(s) of memory to update.

    Memory types map directly to the user memory models:
    - "semantic" → UserProfile  
        Stable facts and attributes about the user, such as name, profession, 
        location, or long-term preferences.  
        Example: "My name is John and I live in Berlin."

    - "episodic" → UserExperience  
        Past experiences, interactions, or events that occurred at a specific time, 
        with possible outcomes and related entities.  
        Example: "Last week I attended a data science workshop with my colleague Anna."

    - "procedural" → UserInstruction  
        Rules, instructions, or constraints that guide behavior or preferences, 
        often with a priority level.  
        Example: "Always summarize meeting notes in bullet points."
    """
    classified_memories: List[Literal["semantic", "episodic", "procedural"]] = Field(
        ..., description="Which memory types to update based on the input."
    )


class UserProfile(BaseModel):
    """Semantic Memory: stable facts and attributes about the user."""
    name: str = Field("", description="The full name of the user")
    dob: Optional[str] = Field(None, description="Date of birth of the user (YYYY-MM-DD)")
    profession: Optional[str] = Field(None, description="The profession/occupation of the user")
    location: Optional[str] = Field(None, description="The location of the user")
    preferences: Optional[List[str]] = Field(default_factory=list, description="User's interests or hobbies")


class UserExperience(BaseModel):
    """Episodic Memory: past experiences, interactions, or events."""
    title: str = Field("", description="Short title or label for the experience")
    description: str = Field("", description="Narrative of the experience")
    occurred_at: Optional[str] = Field(None, description="When the experience occurred (date or time reference)")
    outcome: Optional[str] = Field(None, description="Outcome of the experience")
    related_entities: Optional[List[str]] = Field(default_factory=list, description="Other people/tools/contexts involved")


class UserInstruction(BaseModel):
    """Procedural Memory: rules, preferences, or constraints."""
    category: str = Field("", description="Category of the instruction (e.g., communication, safety, work, preferences)")
    content: str = Field("", description="The instruction or rule in natural language")
    priority: Literal["high", "medium", "low"] = Field("low", description="Priority of the instruction")


DEFAULT_SCHEMAS = {
    "semantic_memory": UserProfile().model_dump(),
    "episodic_memory": UserExperience().model_dump(),
    "procedural_memory": UserInstruction().model_dump(),
}