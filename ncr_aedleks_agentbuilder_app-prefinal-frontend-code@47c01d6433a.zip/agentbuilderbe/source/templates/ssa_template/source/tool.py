# ToolResource model and tool_resources mapping
from typing import Mapping
from enum import Enum
from typing import Optional, Dict, Any, List, Type
from pydantic import BaseModel, Field
from models import MODEL_MAP
from models import InputSchema
import os
import yaml

class ResourceType(str, Enum):
	CORTEX_ANALYST_TEXT2SQL = "cortex_analyst_text2sql"
	CORTEX_SEARCH = "cortex_search"
	GENERIC = "generic"

class ToolInputSchema(BaseModel):
	type: str
	description: Optional[str] = None
	properties: Optional[Dict[str, 'ToolInputSchema']] = None
	items: Optional['ToolInputSchema'] = None
	required: Optional[List[str]] = None

	class Config:
		arbitrary_types_allowed = True
		# Allow forward references
		underscore_attrs_are_private = True

def pydantic_model_to_tool_input_schema(model: Type[BaseModel]) -> ToolInputSchema:
	"""Convert a Pydantic model to ToolInputSchema recursively."""
	schema = model.model_json_schema()
	def convert(schema_dict: dict) -> ToolInputSchema:
		t = schema_dict.get('type', 'object')
		desc = schema_dict.get('description')
		props = None
		items = None
		required = schema_dict.get('required')
		if t == 'object' and 'properties' in schema_dict:
			props = {k: convert(v) for k, v in schema_dict['properties'].items()}
		if t == 'array' and 'items' in schema_dict:
			items = convert(schema_dict['items'])
		return ToolInputSchema(
			type=t,
			description=desc,
			properties=props,
			items=items,
			required=required
		)
	return convert(schema)

class ToolSpec(BaseModel):
	class Builder:
		def __init__(self):
			self._type = None
			self._name = None
			self._description = None
			self._input_schema = None

		def type(self, value: str):
			self._type = value
			return self

		def name(self, value: str):
			self._name = value
			return self

		def description(self, value: str):
			self._description = value
			return self

		def input_schema(self, value: 'ToolInputSchema'):
			self._input_schema = value
			return self

		def from_dict(self, spec: dict):
			self._type = spec["type"]
			self._name = spec["name"]
			self._description = spec["description"]
			input_schema_key = spec.get("input_schema")
			self._input_schema = pydantic_model_to_tool_input_schema(MODEL_MAP[input_schema_key]) if input_schema_key is not None else None
			return self

		def build(self):
			if not all([self._type, self._name, self._description]):
				raise ValueError("Type, name, and description must be set for ToolSpec.")
			return ToolSpec(
				type=self._type,
				name=self._name,
				description=self._description,
				input_schema=self._input_schema
			)
	type: str
	name: str
	description: str
	input_schema: Optional[ToolInputSchema] = None

class Tool(BaseModel):
	class Builder:
		def __init__(self):
			self._tool_spec = None

		def tool_spec(self, value: ToolSpec):
			self._tool_spec = value
			return self

		def from_dict(self, spec: dict):
			"""Build Tool from a dictionary spec (as from YAML), using ToolSpec.Builder."""
			self._tool_spec = ToolSpec.Builder().from_dict(spec["tool_spec"]).build()
			return self

		def build(self):
			if not self._tool_spec:
				raise ValueError("tool_spec must be set for Tool.")
			return Tool(tool_spec=self._tool_spec)
	tool_spec: ToolSpec

class Tools(BaseModel):
	tools: List['Tool']

	class Builder:
		def __init__(self):
			self._tools = []


		def add_tool(self, tool: 'Tool'):
			self._tools.append(tool)
			return self

		def tools(self, tools: List['Tool']):
			self._tools = tools
			return self
		
		# def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/tool.yaml"):
		def from_config_file(self): 
			config_path: str = os.path.join(os.environ.get('GENAI_PATH', '').lower(), 'tool.yaml')
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			tool_specs = config.get("tools", [])
			self._tools = [Tool.Builder().from_dict(spec).build() for spec in tool_specs]
			return self

		def build(self):
			if not self._tools:
				raise ValueError("At least one tool must be set for Tools.")
			return Tools(tools=self._tools)
	
class ExecutionEnvironment(BaseModel):
	"""
	Configuration for server-executed tools.
	type: The type of execution environment, currently only 'warehouse' is supported.
	warehouse: The name of the warehouse. Case-sensitive, if it is an unquoted identifier, provide the name in all-caps.
	query_timeout: The query timeout in seconds.
	"""
	type: str
	warehouse: str
	query_timeout: Optional[int] = None


# ToolResource is an interface (base class)
class ToolResource(BaseModel):
	"""
	Interface for tool resource configuration. Do not instantiate directly.
	"""
	pass

class AnalystResource(ToolResource):
	semantic_model_file: str
	semantic_view: Optional[str] = None
	execution_environment: 'ExecutionEnvironment'

class SearchResource(ToolResource):
	search_service: str
	title_column: str
	id_column: str
	filter: Optional[dict] = None

class GenericResource(ToolResource):
	type: str
	execution_environment: 'ExecutionEnvironment'
	identifier: str

class ToolChoiceType(str, Enum):
	AUTO = "auto"
	REQUIRED = "required"
	TOOL = "tool"

class ToolChoice(BaseModel):
	class Builder:
		def __init__(self):
			self._type = None
			self._name = None

		def type(self, value: str):
			# Validate type against ToolChoiceType enum
			if value not in ToolChoiceType.__members__.values() and value not in [e.value for e in ToolChoiceType]:
				raise ValueError(f"Invalid type '{value}' for ToolChoice. Must be one of {[e.value for e in ToolChoiceType]}")
			self._type = value
			return self

		def name(self, value: Optional[List[str]]):
			self._name = value
			return self
		
		# def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/tool.yaml"):
		def from_config_file(self):
			config_path: str = os.path.join(os.environ.get('GENAI_PATH', '').lower(), 'tool.yaml')
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			tool_choice_cfg = config.get("tool_choice", {})
			if not tool_choice_cfg:
				raise ValueError("No tool_choice found in config.")
			self.type(tool_choice_cfg.get("type"))
			self.name(tool_choice_cfg.get("name"))
			return self

		def build(self):
			if not self._type:
				raise ValueError("type must be set for ToolChoice.")
			return ToolChoice(type=self._type, name=self._name)
	type: str  # Should be one of 'auto', 'required', 'tool'
	name: Optional[List[str]] = None
	"""
	type: Determines how tools are selected: - auto - Automatic tool selection (default) - required - Must use at least one tool - tool - Use specific named tools
	name: List of specific tool names to use when type is 'tool'.
	"""

# tool_resources: map of tool name to ToolResource
ToolResources = Mapping[str, ToolResource]
"""
tool_resources: Configuration for each tool referenced in the tools array. Keys must match the name of the respective tool.
"""

# Builder for ToolResources
class ToolResourcesBuilder:
	def __init__(self):
		self._tool_resources = {}

	def add(self, name: str, resource: ToolResource):
		self._tool_resources[name] = resource
		return self

	# def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/tool.yaml"):
	def from_config_file(self):
		config_path: str = os.path.join(os.environ.get('GENAI_PATH', '').lower(), 'tool.yaml')
		if not os.path.exists(config_path):
			raise FileNotFoundError(f"Config file {config_path} not found.")
		with open(config_path) as f:
			config = yaml.safe_load(f)
		# Build tools first
		tool_specs = config.get("tools", [])
		tools = [Tool.Builder().from_dict(spec).build() for spec in tool_specs]
		resources_cfg = config.get("tool_resources", {})
		# Map tool type to resource class
		type_to_resource = {
			"cortex_analyst_text_to_sql": AnalystResource,
			"cortex_search": SearchResource,
			"generic": GenericResource,
		}
		for tool in tools:
			name = tool.tool_spec.name
			tool_type = tool.tool_spec.type
			resource_data = resources_cfg.get(name)
			if not resource_data:
				continue  # No resource config for this tool
			resource_cls = type_to_resource.get(tool_type)
			if not resource_cls:
				continue  # Unknown resource type, skip
			self._tool_resources[name] = resource_cls(**resource_data)
		return self

	def build(self):
		return self._tool_resources
