import os
import requests
import uuid

from snowflake_auth import SnowflakeAuthManager

env = os.getenv('env_name')
if env=="dev" or env=="sit":
	# account = "st69414.us-east-2.privatelink"
	HOST = "carelon-eda-nonprod.privatelink.snowflakecomputing.com"
elif env=="uat" or env=="preprod":
	# account = "jib90126.us-east-1.privatelink"
	HOST = "carelon-eda-preprod.privatelink.snowflakecomputing.com"
else:
	# account = "gcb59607.us-east-1.privatelink"
	HOST = "carelon-eda-prod.privatelink.snowflakecomputing.com"

class ThreadManager:

	def __init__(self, application_name: str, user_identity: str,
							logger: str,
							aplctn_cd: str,
							env: str,
							region_name: str,
							warehouse_size_suffix: str,
							prefix: str
					):
			self.application_name = application_name
			self.logger = logger
			self.user_identity = user_identity
			self.aplctn_cd= aplctn_cd
			self.env = env
			self.region_name = region_name
			self.warehouse_size_suffix = warehouse_size_suffix
			self.prefix = prefix
			self.auth_manager = SnowflakeAuthManager()
			self.conn = self.auth_manager \
								.builder() \
								.build_rrr(logger, aplctn_cd, env, region_name, warehouse_size_suffix, prefix, user_identity)
			print(f'tokenn:{self.conn}')

			
	def _headers(self):
		return {
			"Authorization": f"Snowflake Token=\"{getattr(getattr(self.conn, "rest", None), "token", None)}\"",
			"Content-Type": "application/json",
			"Accept": "application/json"
		}

	def create_thread(self):
		origin_application = f"{self.application_name}-{self.user_identity}"
		url = f"https://{HOST}/api/v2/cortex/threads"
		payload = {
			"origin_application": origin_application
		}
		response = requests.post(url, headers=self._headers(), json=payload)
		if response.status_code == 200:
			data = response.json()
			return data
		else:
			raise Exception(f"Thread creation failed: {response.text}")

	def list_threads(self):
		origin_application = f"{self.application_name}-{self.user_identity}"
		url = f"https://{HOST}/api/v2/cortex/threads"
		payload = {
			"origin_application": origin_application
		}
		response = requests.get(url, headers=self._headers(), params=payload)
		# response = requests.get(url, headers=self._headers(), json=payload)
		if response.status_code == 200:
			return response.json()
		else:
			raise Exception(f"List threads failed: {response.text}")

	def describe_thread(self, thread_id: str):
		origin_application = f"{self.application_name}-{self.user_identity}"
		url = f"https://{HOST}/api/v2/cortex/threads/{thread_id}"
		response = requests.get(url, headers=self._headers())
		if response.status_code == 200:
			return response.json()
		else:
			raise Exception(f"Describe thread failed: {response.text}")

	def update_thread(self, thread_id: str, update_data: dict):
		origin_application = f"{self.application_name}-{self.user_identity}"
		url = f"https://{HOST}/api/v2/cortex/threads/{thread_id}?origin_application={origin_application}"
		response = requests.put(url, headers=self._headers(), json=update_data)
		if response.status_code == 200:
			return response.json()
		else:
			raise Exception(f"Update thread failed: {response.text}")

	def delete_thread(self, thread_id: str):
		origin_application = f"{self.application_name}-{self.user_identity}"
		url = f"https://{HOST}/api/v2/cortex/threads/{thread_id}?origin_application={origin_application}"
		response = requests.delete(url, headers=self._headers())
		if response.status_code == 200:
			return True
		else:
			raise Exception(f"Delete thread failed: {response.text}")

	def get_latest_thread_id(self):
		threads = self.list_threads()
		if threads:
			latest_thread = max(threads, key=lambda t: t.get("created_on", 0))
			return latest_thread.get("thread_id")
		else:
			print("No threads found for user.")
			return self.create_thread().get("thread_id")

	def get_parent_message_id(self, thread_id):
		thread_data = self.describe_thread(thread_id)
		parent_message_id = 0
		assistant_messages = [m for m in thread_data["messages"] if m.get("role") == "assistant"]
		if assistant_messages:
			latest_msg = max(assistant_messages, key=lambda m: m.get("created_on", 0))
			latest_message_id = latest_msg.get("message_id")
			parent_message_id = latest_message_id
		return parent_message_id
