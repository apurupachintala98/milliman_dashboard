from typing import Optional, Dict, Any, List, Type
from pydantic import BaseModel, Field
from enum import Enum

class InputSchema(BaseModel):
	model_name: str


class MessageContent(BaseModel):
    type: str
    text: str

class Message(BaseModel):
    role: str
    content: List[MessageContent]

class AgentRequest(BaseModel):
    application_name: str
    user_identity: str
    messages: List[Message]

class FilterDataRequest(BaseModel):
    user_identity: str
    application_name: str

class EnvName(Enum):
    DEV = "dev"
    TEST = "test"
    UAT = "uat"
    PREPROD = "preprod"
    PROD = "prod"


#Should inlclude model map for all the pydantic models included 
MODEL_MAP = {
	"InputSchema": InputSchema
}

# Map env to host_env for URL
ENV_TO_HOST = {
    "dev": "eda-nonprod",
    "test": "eda-nonprod",
    "uat": "eda-preprod",
    "preprod": "eda-preprod",
    "prod": "edaprod",
}

