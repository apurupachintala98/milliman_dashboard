from fastapi import logger
import requests
import os
import yaml
from typing import Tuple, Dict, Optional
from pydantic import BaseModel
import logging
from models import EnvName
from snowflake_auth import SnowflakeAuthManager
from tool import Tools, ToolResourcesBuilder

# Set up logger
logger = logging.getLogger(__name__)
# from .agent import AgentInstructions, ModelConfig, OrchestrationConfig


# Agent Rest API Client 
class SnowflakeCortexAgentAPI:
    """Client for Snowflake Cortex Agents REST API"""
    def __init__(self, aplctn_cd: str = None, env: str = None, region_name: str = None, 
                 warehouse_size_suffix: str = None, prefix: str = None, user_identity: str = None):
        
        # Get environment and set appropriate HOST
        self.account_url = "https://carelon-eda-nonprod.privatelink.snowflakecomputing.com"
        self.pat_token = os.getenv("SF_PAT_TOKEN")
        env_name = os.getenv('env_name')
        if env_name == "dev" or env_name == "sit":
            HOST = "carelon-eda-nonprod.privatelink.snowflakecomputing.com"
        elif env_name == "uat" or env_name == "preprod":
            HOST = "carelon-eda-preprod.privatelink.snowflakecomputing.com"
        else:
            HOST = "carelon-edaprod.privatelink.snowflakecomputing.com"
        
        self.account_url = f"https://{HOST}"
        self.base_url = f"{self.account_url}/api/v2"
    
        try:            
            # Use SnowflakeAuthManager for authentication (same as agent.py)
            auth_manager = SnowflakeAuthManager()
            conn = auth_manager.builder().build_rrr(
                logger, aplctn_cd, env, region_name, warehouse_size_suffix, prefix, ""
            )
            self.headers = {
                "Authorization": f"Snowflake Token=\"{getattr(getattr(conn, 'rest', None), 'token', None)}\"",
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        except Exception as e:
            logging.info(f"Error initializing SnowflakeCortexAgentAPI: {str(e)}")
            logging.info("Falling back to PAT token for authentication")
            self.headers = {
                'Authorization': f'Bearer {self.pat_token}',
                'Content-Type': 'application/json'
            }

        
    def test_connection(self) -> Tuple[bool, str]:
        """Test the connection to the Snowflake account"""
        try:
            # Try to list databases as a connection test
            url = f"{self.base_url}/databases"
            response = requests.get(url, headers=self.headers, timeout=10)
            response.raise_for_status()
            return True, "Connection successful"
        except requests.exceptions.RequestException as e:
            return False, f"Connection failed: {str(e)}"
    
    def create_agent(self, database: str, schema: str, agent_config: Dict) -> bool:
        """Create a new agent"""
        url = f"{self.base_url}/databases/{database}/schemas/{schema}/agents?createMode=errorIfExists"
        url_to_send = f"{self.base_url}/databases/{database}/schemas/{schema}/agents/{agent_config['name']}:run"
        print(f"\nURL: {url}")
        print(f"\nHeaders: {self.headers}")
        print(f"\nAgent Config: {agent_config}")
        try:
            response = requests.post(url, headers=self.headers, json=agent_config)
            response.raise_for_status()
            return True, url_to_send
        except requests.exceptions.RequestException as e:
            logging.error(f"Error creating agent in {self.account_url}: {str(e)}")
            return False, "No URL Created"

#1. Database and Schema Selection

def get_database_schema_config(agent_name: str) -> Dict[str, str]:
    """
    Get database and schema configuration from app.yaml based on agent name and environment.
    
    Args:
        agent_name: The name of the agent to get config for (e.g., 'CAO_DENIEDYETPAID')
    
    Returns:
        Dictionary containing db, schema, data_schema configuration
        
    Raises:
        ValueError: If environment is invalid or configuration not found
        FileNotFoundError: If app.yaml file is not found
    """
    
    # Get environment from env_name host variable
    env = os.getenv('env_name')
    if not env:
        raise ValueError("env_name environment variable is not set")
    
    # Validate env against EnvName enum from models
    valid_envs = {e.value for e in EnvName}
    if env not in valid_envs:
        raise ValueError(f"Invalid environment '{env}'. Must be one of: {', '.join(valid_envs)}")
    
    # Construct app.yaml file path using GENAI_PATH
    genai_path = os.environ.get("GENAI_PATH")
    if not genai_path:
        raise ValueError("GENAI_PATH environment variable is not set")
    
    config_path = os.path.join(genai_path, "app.yaml")
    
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"app.yaml file not found at: {config_path}")
    
    # Load configuration from app.yaml
    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
    except Exception as e:
        raise ValueError(f"Failed to load app.yaml: {str(e)}")
    
    # Navigate to agent configuration
    agents_config = config.get("Agents", {})
    if not agents_config:
        raise ValueError("No 'Agents' section found in app.yaml")
    
    agent_config = agents_config.get(agent_name, {})
    if not agent_config:
        raise ValueError(f"Agent '{agent_name}' not found in app.yaml")
    
    env_config = agent_config.get(env, {})
    if not env_config:
        raise ValueError(f"Environment '{env}' not found for agent '{agent_name}' in app.yaml")
    
    # Extract database and schema information
    db_config = {
        'db': env_config.get('db'),
        'schema': env_config.get('schema'),
        'data_schema': env_config.get('data_schema'),
        'aplctn_cd': env_config.get('aplctn_cd'),
        'env': env_config.get('env'),
        'region_name': env_config.get('region_name'),
        'warehouse_size_suffix': env_config.get('warehouse_size_suffix'),
        'prefix': env_config.get('prefix')
    }
    
    # Validate required fields
    required_fields = ['db', 'schema']
    missing_fields = [field for field in required_fields if not db_config.get(field)]
    
    if missing_fields:
        raise ValueError(f"Missing required configuration fields for agent '{agent_name}' in environment '{env}': {missing_fields}")
    
    return db_config

#2. Tools information 
  

def create_agent(agent_name: str, user_identity: str = None):
    db_schema_details = get_database_schema_config(agent_name)
    
    # Initialize the client with authentication parameters from db_schema_details
    client = SnowflakeCortexAgentAPI(
        aplctn_cd=db_schema_details.get('aplctn_cd'),
        env=db_schema_details.get('env'),
        region_name=db_schema_details.get('region_name'),
        warehouse_size_suffix=db_schema_details.get('warehouse_size_suffix'),
        prefix=db_schema_details.get('prefix'),
        user_identity=user_identity
    )
    
    tools = Tools.Builder().from_config_file().build().model_dump()
    tool_resources = ToolResourcesBuilder().from_config_file().build()
    tool_resources_dict = {rec: tool_resources[rec].model_dump() for rec in tool_resources}
    
    models = ModelConfig.Builder().from_config_file().build()
    agent_instructions = AgentInstructions.Builder().from_config_file().build()
    
    orchestration = OrchestrationConfig.Builder().from_config_file().build()
    
    agent_config = {
        "name": agent_name,
        "instructions": agent_instructions.model_dump(),
        "models": models.model_dump(),
        "orchestration": orchestration.model_dump(),
        "tools": tools["tools"],
        "tool_resources": tool_resources_dict
    }
    return client.create_agent(db_schema_details["db"], db_schema_details["schema"], agent_config)


class AgentInstructions(BaseModel):
	class Builder:
		def __init__(self):
			self._response = None
			self._orchestration = None
			self._system = None
		def response(self, value: str):
			self._response = value
			return self
		def orchestration(self, value: str):
			self._orchestration = value
			return self
		def system(self, value: str):
			self._system = value
			return self
        # def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
		def from_config_file(self):
			config_path: str = os.path.join(os.environ.get('GENAI_PATH', '').lower(), 'agent.yaml')
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			self._response = config["agent_instructions"].get("response")
			self._orchestration = config["agent_instructions"].get("orchestration")
			self._system = config["agent_instructions"].get("system")
			return self
		def build(self):
			if not (self._response and self._orchestration and self._system):
				raise ValueError("All AgentInstructions fields must be set.")
			return AgentInstructions(
				response=self._response,
				orchestration=self._orchestration,
				system=self._system
			)
	response: str
	orchestration: str
	system: str
	"""
	response: Instructions for response generation.
	orchestration: Custom instructions for tool planning.
	system: System instructions for the agent.
	"""

class ModelConfig(BaseModel):
	class Builder:
		def __init__(self):
			self._orchestration = None
		def orchestration(self, value: str):
			self._orchestration = value
			return self
		# def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
		def from_config_file(self):
			config_path: str = os.path.join(os.environ.get('GENAI_PATH', '').lower(), 'agent.yaml')
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			self._orchestration = config.get("model_config", {}).get("orchestration")
			return self
		def build(self):
			if not self._orchestration:
				raise ValueError("Orchestration must be set for ModelConfig.")
			return ModelConfig(orchestration=self._orchestration)
	orchestration: str
	"""
	orchestration: Model to use for orchestration. If not provided, a model is automatically selected.
	"""

class OrchestrationConfig(BaseModel):
	class Builder:
		def __init__(self):
			self._budget = None
		def budget(self, value: 'BudgetConfig'):
			self._budget = value
			return self
		# def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
		def from_config_file(self):
			config_path: str = os.path.join(os.environ.get('GENAI_PATH', '').lower(), 'agent.yaml')
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			budget_cfg = config.get("orchestration_config", {}).get("budget", {})
			if not budget_cfg:
				raise ValueError("No budget config found in orchestration_config.")
			self._budget = BudgetConfig(**budget_cfg)
			return self
		def build(self):
			if not self._budget:
				raise ValueError("Budget must be set for OrchestrationConfig.")
			return OrchestrationConfig(budget=self._budget)
	budget: 'BudgetConfig'
	"""
	budget: Budget constraints for the agent. If more than one constraint is specified, whichever is first hit will end the request.
	"""

class BudgetConfig(BaseModel):
	seconds: int
	tokens: int
	"""
	seconds: Time budget in seconds.
	tokens: Token budget.
	"""
