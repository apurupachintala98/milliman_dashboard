"""
Snowflake authentication module supporting multiple authentication methods:
- Service ID based authentication (with connection pooling)
- Snowflake JWT authentication
- Snowflake programmatic access token authentication

Each method has its own required parameters. The environment is loaded from llmconfig if available.
"""
import logging
import json
from snowflake.snowpark import Session
from snowflake.connector import SnowflakeConnection
from typing import Optional, Dict, Any, Tuple, Union
from ReduceReuseRecycle.snowflakefunc import snowflake_conn
from ReduceReuseRecycle.snowparkfunc import get_snowpark_sessn
import os
import yaml
import threading
import boto3
from botocore.exceptions import ClientError

session_lock = threading.Lock()
# session = None
logger = logging.getLogger(__name__)

class SnowflakeAuthManager:
    _conn_pool: Dict[Tuple[str,str,str,str],Union[Session, SnowflakeConnection]] = {}
    _pool_lock = threading.Lock()  # Add thread safety for connection pool

    def __init__(self):
        """
        Dependency injection of LLMConfig instance.
        """
        self.llm_config = None


    class Builder:
        def __init__(self, auth_manager):
            self.auth_manager = auth_manager
            self._params = {}
            self._config_file = None
            self.session = None

        def config_file(self, path):
            self._config_file = path
            return self

        def application_code(self, code):
            self._params['application_code'] = code
            return self

        def prefix(self, prefix):
            self._params['prefix'] = prefix
            return self

        def warehouse(self, warehouse):
            self._params['warehouse'] = warehouse
            return self

        def role(self, role):
            self._params['role'] = role
            return self

        def database(self, database):
            self._params['database'] = database
            return self

        def schema(self, schema):
            self._params['schema'] = schema
            return self

        def env(self, env):
            self._params['env'] = env
            return self

        def user(self, user):
            self._params['user'] = user
            return self

        def password(self, password):
            self._params['password'] = password
            return self

        def account(self, account):
            self._params['account'] = account
            return self

        def host(self, host):
            self._params['host'] = host
            return self

        def port(self, port):
            self._params['port'] = port
            return self
        
        def build_rrr(self, logger, aplctn_cd, env, region_name, warehouse_size_suffix, prefix,user):

            key = (aplctn_cd,prefix,user,'conn')
            
            with SnowflakeAuthManager._pool_lock:
                # Check if we have a valid cached connection
                if key in SnowflakeAuthManager._conn_pool:
                    cached_connection = SnowflakeAuthManager._conn_pool[key]
                    # For RRR connections, we store the token string, so we need to check if it's still valid
                    # A simple check is to see if the token is not None and not empty
                    if cached_connection and cached_connection.is_valid():
                        logger.info(f"Reusing cached RRR connection for key: {key}")
                        return cached_connection
                    else:
                        # Remove invalid connection from pool
                        logger.info(f"Removing invalid cached connection for key: {key}")
                        SnowflakeAuthManager._conn_pool.pop(key, None)
                
                # Create new connection
                logger.info(f"Creating new RRR connection for key: {key}")
                new_connection = self.auth_manager._build_rrr_connection(logger, aplctn_cd, env, region_name, warehouse_size_suffix, prefix, **self._params)
                
                # Store in pool only if connection is valid
                if new_connection:
                    SnowflakeAuthManager._conn_pool[key] = new_connection
                
                return new_connection

        def build_patid(self, logger, aplctn_cd, env, region_name, warehouse_size_suffix, prefix, user):
           return self.build_rrr(logger, aplctn_cd, env, region_name, warehouse_size_suffix, prefix, user)

        #def create_fresh_session(self):
        #    """Create a brand new Snowpark session - no caching, no reuse"""
        #    print("[create_fresh_session] Creating completely new session")
        #    # CRITICAL: Clear the snowparkfunc internal cache to force fresh creation
        #    #print(f"[create_fresh_session] Clearing snowparkfunc cache: {list(snowparkfunc._Builder__sf_session_dict.keys())}")
        #    #snowparkfunc._Builder__sf_session_dict.clear()
#
        #    # Check if the attribute exists and is a dictionary
        #    if hasattr(snowparkfunc, "__sf_session_dict"):
        #        session_dict = getattr(snowparkfunc, "__sf_session_dict")
        #        if isinstance(session_dict, dict):
        #            print(f"[create_fresh_session] Current cache keys: {list(session_dict.keys())}")
        #            session_dict.clear()
        #            print("[create_fresh_session] Cache cleared successfully.")
        #        else:
        #            print("[create_fresh_session] __sf_session_dict exists but is not a dictionary.")
        #    else:
        #        print("[create_fresh_session] __sf_session_dict not found in snowparkfunc.")
#
#
        #    #Load config from app.yaml to get additional_config
        #    config_path = os.path.join(os.environ.get("GENAI_PATH", "dev").lower(), "app.yaml")
        #    print(f'additional_config:',config_path)
        #    query_tag={}
        #    with open(config_path, "r") as f:
        #        config = yaml.safe_load(f)
        #    additional_config = config.get("additional_config", {}).get("cao_data", {})
        #    aplctn_cd = additional_config.get("aplctn_cd", "aedl")
        #    warehouse_size_suffix = additional_config.get("warehouse_size_suffix", "")
        #    prefix = additional_config.get("prefix", "")
        #    env = os.getenv('env_name')
        #    region_name = os.getenv('region_name')
        #    logger.info(f"application_code: {aplctn_cd}, env: {env}, region_name: {region_name}, warehouse_size_suffix: {warehouse_size_suffix}, prefix: {prefix}")
#
#
            #try:
            #    new_session = get_snowpark_sessn(
            #        logger,
            #        aplctn_cd=aplctn_cd,
            #        env=env,
            #        region_name=region_name,
            #        warehouse_size_suffix=warehouse_size_suffix,
            #        prefix=""
            #    )
            #    print(f"[create_fresh_session] Success: {new_session}")
            #    return new_session
            #except Exception as e:
            #    print(f"[create_fresh_session] Failed: {e}")
            #    raise

        #def is_session_usable(self,sess):
        #    """Check if session can be used without throwing 1404 or token expiry"""
        #    if sess is None:
        #        return False
#
        #    try:
        #        # Try to get basic session info first (lightweight check)
        #        _ = sess.session_id
        #        # Also try a simple SQL query to catch token expiry
        #        sess.sql("SELECT 1").collect()
        #        return True
        #    except Exception as e:
        #        error_msg = str(e)
        #        print(f"[is_session_usable] Session not usable: {error_msg}")
        #        # Check for known session failure patterns
        #        if any(marker in error_msg for marker in ["390114", "Authentication token has expired", "session has been closed", "1404"]):
        #            print(f"[is_session_usable] Detected recoverable session error: {error_msg}")
        #        return False

        #def build_session(self):
        #    print(f'started get_valid_session')
#
        #    if self.session is None or not self.is_session_usable(self.session):
        #        print("[get_valid_session] No usable session - creating new")
#
        #        if self.session is not None:
        #            try:
        #                self.session.close()
        #            except Exception:
        #                pass
        #            self.session = None
#
        #        self.session = self.create_fresh_session()
#
        #        if not self.is_session_usable(self.session):
        #            raise Exception("Newly created session is not usable")
#
        #        return self.session
#
        #    try:
        #        self.session.sql("SELECT 1").collect()
        #        print("[get_valid_session] Existing session SQL test passed")
        #        return self.session
        #    except Exception as e:
        #        error_msg = str(e)
        #        print(f"[get_valid_session] Existing session SQL failed: {error_msg}")
#
        #        try:
        #            self.session.close()
        #        except Exception as close_err:
        #            print(f"[get_valid_session] Error closing session: {close_err}")
#
        #        self.session = self.create_fresh_session()
        #        return self.session


        def build_session(
                self,
                logger,
                api_name: str,
                user: str = "default"
                ):
                # Load config from app.yaml to get additional_config
                config_path = os.path.join(os.environ.get("GENAI_PATH", "dev").lower(), "app.yaml")
                print(f'additional_config:',config_path)
                
                with open(config_path, "r") as f:
                    config = yaml.safe_load(f)
                additional_config = config.get("additional_config", {}).get(api_name, {})
                aplctn_cd = additional_config.get("aplctn_cd", "aedl")
                warehouse_size_suffix = additional_config.get("warehouse_size_suffix", "")
                prefix = additional_config.get("prefix", "")
                region_name = os.getenv('region_name')
                env = os.getenv('env_name')
                
                # Create pooling key similar to build_rrr
                key = (aplctn_cd, prefix, user, 'session')
                
                with SnowflakeAuthManager._pool_lock:
                    # Check if we have a valid cached session
                    if key in SnowflakeAuthManager._conn_pool:
                        cached_session = SnowflakeAuthManager._conn_pool[key]
                        if self._is_session_valid(cached_session, logger):
                            logger.info(f"Reusing cached Snowpark session for key: {key}")
                            return cached_session
                        else:
                            # Remove invalid session from pool
                            logger.info(f"Removing invalid cached session for key: {key}")
                            SnowflakeAuthManager._conn_pool.pop(key, None)
                    
                    # Create new session
                    logger.info(f"Creating new Snowpark session for key: {key}")
                    logger.info(f"application_code: {aplctn_cd}, env: {env}, region_name: {region_name}, warehouse_size_suffix: {warehouse_size_suffix}, prefix: {prefix}")
                    
                    print(f"application_code: {aplctn_cd}, env: {env}, region_name: {region_name}, warehouse_size_suffix: {warehouse_size_suffix}, prefix: {prefix}")
                    ###
                    secret_name = f"{env}/snowflake/{aplctn_cd}"
                    session = boto3.session.Session()
                    client = session.client(
                        service_name='secretsmanager',
                        region_name=region_name
                    )
                    
                    try:
                        get_secret_value_response = client.get_secret_value(
                            SecretId=secret_name
                        )
                        
                        if 'SecretString' in get_secret_value_response:
                            secret_string = get_secret_value_response['SecretString']
                            secret = json.loads(secret_string)  # Parse JSON string to dict
                        else:
                            logger.error("SecretString not found in AWS Secrets Manager response")
                            raise Exception("Unable to form connection - SecretString not found")
                            
                    except ClientError as error:
                        logger.error(f"Failed to retrieve secret from AWS Secrets Manager: {error}")
                        raise error
                    except json.JSONDecodeError as error:
                        logger.error(f"Failed to parse secret JSON: {error}")
                        raise error
                    
                    sf_url = f"{secret['account']}.snowflakecomputing.com"

                    connection_parameters = {
                        "account": secret['account']
                        ,"user": secret[f'{prefix}_user']
                        ,"password": secret[f'{prefix}_password']
                        ,"database": secret[f'{prefix}_database']
                        ,"warehouse": secret[f'{prefix}_warehouse']
                        ,"role": secret[f'{prefix}_role']
                    }
                    try:
                        session = Session.builder.configs(connection_parameters).create()
                    except Exception as error:
                        logger.critical('*** ERROR: Connection to Snowflake failed! ***')
                        logger.critical(error)
                        raise error
                    ###
                    #session = get_snowpark_sessn(log=logger, aplctn_cd=aplctn_cd, env=env, region_name=region_name, warehouse_size_suffix=warehouse_size_suffix, prefix=prefix)
                    print(f'snowparksession:{session}')
                    
                    # Store in pool only if session is valid
                    if session:
                        SnowflakeAuthManager._conn_pool[key] = session
                    
                    return session

        def _is_session_valid(self, session, logger):
            """Check if a Snowpark session is still valid and usable"""
            if session is None:
                return False
            
            try:
                # Try to get basic session info first (lightweight check)
                _ = session.session_id
                # Also try a simple SQL query to catch token expiry
                session.sql("SELECT 1").collect()
                return True
            except Exception as e:
                error_msg = str(e)
                logger.warning(f"Session validation failed: {error_msg}")
                # Check for known session failure patterns
                if any(marker in error_msg.lower() for marker in ["390114", "authentication token has expired", "session has been closed", "1404"]):
                    logger.info(f"Detected recoverable session error: {error_msg}")
                return False

        # def build_patid(self):
        #     return "eyJraWQiOiIxNTY1ODE3NTMxNjk3MzIxMCIsImFsZyI6IkVTMjU2In0.eyJwIjoiMjM4OTI0ODA4Mzg5OjIzODkyNDc5ODU5NyIsImlzcyI6IlNGOjEwNDMiLCJleHAiOjE3NjE3NTc1NTJ9.qsTy8svp_I_p5p7JClcwhWNBRK8GfYSMYIZf5WB698hKJCo20nrxRiiy0WJHdza8mXYUZG4Wcen4Balp8c_zgw"

    def builder(self):
        return self.Builder(self)
    
    def _build_rrr_connection(
        self,
        logger,
        aplctn_cd: str,
        env: str,
        region_name: str,
        warehouse_size_suffix: str,
        prefix: str
    ) -> str:
        """
        Build a Snowflake connection using ReduceReuseRecycle (RRR) pattern
        by calling snowflake_conn from ReduceReuseRecycleGENAI.snowflake,
        and return the session token.
        """
        # Use the imported snowflake_conn function
        conn = snowflake_conn(
            logger,
            aplctn_cd=aplctn_cd,
            env=env,
            region_name=region_name,
            warehouse_size_suffix=warehouse_size_suffix,
            prefix=prefix
        )
        logger.info(f"Snowflake RRR connection established for application_code={aplctn_cd}, env={env}, prefix={prefix}")
        # Return the session token if available
        return conn
    
    
    def close_all(self):
        with self._pool_lock:
            for key, session in self._conn_pool.items():
                try:
                    # Handle different types of connections stored in pool
                    if isinstance(session, tuple):  # Service ID connections store (session, conn)
                        session[0].close()
                        logger.info(f"Closed service ID session for {key}")
                    elif hasattr(session, 'close') and hasattr(session, 'sql'):  # Snowpark Session objects
                        session.close()
                        logger.info(f"Closed Snowpark session for {key}")
                    elif isinstance(session, str):  # String tokens (RRR connections)
                        logger.info(f"RRR token for {key} marked for cleanup (no explicit close needed)")
                    else:
                        logger.info(f"Unknown session type for {key}: {type(session)}")
                except Exception as e:
                    logger.warning(f"Failed to close session for {key}: {e}")
            self._conn_pool.clear()
            logger.info("Connection pool cleared")
