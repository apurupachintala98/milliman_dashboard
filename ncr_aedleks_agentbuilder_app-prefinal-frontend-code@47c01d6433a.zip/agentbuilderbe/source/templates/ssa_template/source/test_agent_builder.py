#!/usr/bin/env python3
"""
Test script for agent_builder functionality
"""
import os
import sys
from agent_builder import get_database_schema_config

def test_agent_builder():
    """
    Test the agent builder functionality with sample environment variables
    """
    
    # Set test environment variables (these would normally be set by the host)
    os.environ['env_name'] = 'dev'
    os.environ['GENAI_PATH'] = '/Users/AF72092/ncr_aedleks_emcmp_app-1/caobackend/source/cao'
    
    agent_name = 'CAO_DENIEDYETPAID'
    
    try:
        print("=== Testing Agent Builder Functions ===")
        print(f"Agent Name: {agent_name}")
        print(f"Environment: {os.getenv('env_name')}")
        print(f"GENAI_PATH: {os.getenv('GENAI_PATH')}")
        print()
        
        # Test get_database_schema_config
        print("1. Testing get_database_schema_config():")
        config = get_database_schema_config(agent_name)
        print(f"   Full configuration: {config}")
        print()
        
        
        print("✅ All tests passed successfully!")
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)

def test_different_environments():
    """
    Test with different environment values
    """
    print("\n=== Testing Different Environments ===")
    
    agent_name = 'CAO_DENIEDYETPAID'
    os.environ['GENAI_PATH'] = '/Users/AF72092/ncr_aedleks_emcmp_app-1/caobackend/source/cao'
    
    environments = ['dev', 'sit', 'uat', 'preprod', 'prod']
    
    for env in environments:
        os.environ['env_name'] = env
        try:
            config = get_database_schema_config(agent_name)
            print(f"Environment: {env}")
            print(f"  Database: {config['db']}")
            print(f"  Schema: {config['schema']}")
            print(f"  Data Schema: {config['data_schema']}")
            print()
        except Exception as e:
            print(f"Environment: {env} - Error: {str(e)}")
            print()

if __name__ == "__main__":
    test_agent_builder()
    test_different_environments()