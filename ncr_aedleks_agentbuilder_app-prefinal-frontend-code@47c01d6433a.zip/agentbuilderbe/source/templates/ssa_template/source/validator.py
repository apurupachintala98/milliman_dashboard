from models import AgentRequest

def validate_request_type(request):
    if request is None:
        return {"error": "Request body is mandatory and must conform to AgentRequest schema."}
    if not isinstance(request, AgentRequest):
        return {"error": "Request must be of type AgentRequest."}
    return None

def validate_messages(request):
    if not hasattr(request, "messages") or not request.messages:
        return {"error": "'messages' field is required in AgentRequest body."}
    return None

def validate_application_name(request):
    if not getattr(request, "application_name", None):
        return {"error": "'application_name' field is required in AgentRequest body."}
    return None

def validate_user_identity(request):
    if not getattr(request, "user_identity", None):
        return {"error": "'user_identity' field is required in AgentRequest body."}
    return None

def validate_agent_request(request):
    if request is None:
        return {"error": "Request body is mandatory and must conform to AgentRequest schema."}
    # Validate type
    error = validate_request_type(request)
    if error:
        return error
    # Validate messages
    error = validate_messages(request)
    if error:
        return error
    # Validate application_name
    error = validate_application_name(request)
    if error:
        return error
    # Validate user_identity
    error = validate_user_identity(request)
    if error:
        return error
    return None
