from enum import Enum
from logging import config
from typing import Union
from snowflake_auth import SnowflakeAuthManager
from typing import List, Dict, Optional
from tool import *
import os
import json
from pydantic import BaseModel
from pydantic import validator
import os
import yaml
from thread import ThreadManager
import httpx
from fastapi.responses import StreamingResponse
import logging
logger = logging.getLogger(__name__)

class AnnotationType(str, Enum):
	CORTEX_SEARCH_CITATION = "cortex_search_citation"

class Annotation(BaseModel):
	type: AnnotationType
	index: int
	search_result_id: str
	doc_id: str
	doc_title: str
	text: str

	@validator("type")
	def validate_type(cls, v):
		if v != AnnotationType.CORTEX_SEARCH_CITATION:
			raise ValueError("type must be 'cortex_search_citation'")
		return v

	class Builder:
		def __init__(self):
			self._type = AnnotationType.CORTEX_SEARCH_CITATION
			self._index = None
			self._search_result_id = None
			self._doc_id = None
			self._doc_title = None
			self._text = None

		def index(self, value: int):
			self._index = value
			return self
		def search_result_id(self, value: str):
			self._search_result_id = value
			return self
		def doc_id(self, value: str):
			self._doc_id = value
			return self
		def doc_title(self, value: str):
			self._doc_title = value
			return self
		def text(self, value: str):
			self._text = value
			return self
		def from_dict(self, d: dict):
			self._type = AnnotationType(d.get("type", "cortex_search_citation"))
			self._index = d.get("index")
			self._search_result_id = d.get("search_result_id")
			self._doc_id = d.get("doc_id")
			self._doc_title = d.get("doc_title")
			self._text = d.get("text")
			return self
		def build(self):
			if None in [self._index, self._search_result_id, self._doc_id, self._doc_title, self._text]:
				raise ValueError("All fields must be set for Annotation.")
			return Annotation(
				type=self._type,
				index=self._index,
				search_result_id=self._search_result_id,
				doc_id=self._doc_id,
				doc_title=self._doc_title,
				text=self._text
			)


class ChartContent(BaseModel):
	tool_use_id: str
	chart_spec: str  # vega-lite chart specification as string

	class Builder:
		def __init__(self):
			self._tool_use_id = None
			self._chart_spec = None

		def tool_use_id(self, value: str):
			self._tool_use_id = value
			return self

		def chart_spec(self, value: str):
			self._chart_spec = value
			return self

		def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			chart_cfg = config.get("chart_content", {})
			self._tool_use_id = chart_cfg.get("tool_use_id")
			self._chart_spec = chart_cfg.get("chart_spec")
			return self

		def build(self):
			if not self._tool_use_id or not self._chart_spec:
				raise ValueError("Both tool_use_id and chart_spec must be set for ChartContent.")
			return ChartContent(tool_use_id=self._tool_use_id, chart_spec=self._chart_spec)


# --- ResultSet/MetaData/RowType Models ---

class RowType(BaseModel):
	name: str
	type: str
	length: int
	precision: int
	scale: int
	nullable: bool

	class Builder:
		def __init__(self):
			self._name = None
			self._type = None
			self._length = None
			self._precision = None
			self._scale = None
			self._nullable = None

		def name(self, value: str):
			self._name = value
			return self
		def type(self, value: str):
			self._type = value
			return self
		def length(self, value: int):
			self._length = value
			return self
		def precision(self, value: int):
			self._precision = value
			return self
		def scale(self, value: int):
			self._scale = value
			return self
		def nullable(self, value: bool):
			self._nullable = value
			return self
		def from_dict(self, d: dict):
			self._name = d.get("name")
			self._type = d.get("type")
			self._length = d.get("length")
			self._precision = d.get("precision")
			self._scale = d.get("scale")
			self._nullable = d.get("nullable")
			return self
		def build(self):
			if None in [self._name, self._type, self._length, self._precision, self._scale, self._nullable]:
				raise ValueError("All fields must be set for RowType.")
			return RowType(
				name=self._name,
				type=self._type,
				length=self._length,
				precision=self._precision,
				scale=self._scale,
				nullable=self._nullable
			)


class ResultSetMetaData(BaseModel):
	partition: int
	numRows: int
	format: str
	rowType: list[RowType]

	class Builder:
		def __init__(self):
			self._partition = None
			self._numRows = None
			self._format = None
			self._rowType = []

		def partition(self, value: int):
			self._partition = value
			return self
		def numRows(self, value: int):
			self._numRows = value
			return self
		def format(self, value: str):
			self._format = value
			return self
		def rowType(self, value: list):
			self._rowType = value
			return self
		def add_rowType(self, value: RowType):
			self._rowType.append(value)
			return self
		def from_dict(self, d: dict):
			self._partition = d.get("partition")
			self._numRows = d.get("numRows")
			self._format = d.get("format")
			self._rowType = [RowType.Builder().from_dict(rt).build() for rt in d.get("rowType", [])]
			return self

		def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			meta_cfg = config.get("result_set_metadata", {})
			self._partition = meta_cfg.get("partition")
			self._numRows = meta_cfg.get("numRows")
			self._format = meta_cfg.get("format")
			self._rowType = [RowType.Builder().from_dict(rt).build() for rt in meta_cfg.get("rowType", [])]
			return self
		def build(self):
			if None in [self._partition, self._numRows, self._format] or not self._rowType:
				raise ValueError("All fields must be set for ResultSetMetaData.")
			return ResultSetMetaData(
				partition=self._partition,
				numRows=self._numRows,
				format=self._format,
				rowType=self._rowType
			)


class ResultSet(BaseModel):
	statementHandle: str
	resultSetMetaData: ResultSetMetaData
	data: list[list]

	class Builder:
		def __init__(self):
			self._statementHandle = None
			self._resultSetMetaData = None
			self._data = None

		def statementHandle(self, value: str):
			self._statementHandle = value
			return self
		def resultSetMetaData(self, value: ResultSetMetaData):
			self._resultSetMetaData = value
			return self
		def data(self, value: list):
			self._data = value
			return self
		def from_dict(self, d: dict):
			self._statementHandle = d.get("statementHandle")
			self._resultSetMetaData = ResultSetMetaData.Builder().from_dict(d["resultSetMetaData"]).build()
			self._data = d.get("data")
			return self
		def build(self):
			if not (self._statementHandle and self._resultSetMetaData and self._data):
				raise ValueError("All fields must be set for ResultSet.")
			return ResultSet(
				statementHandle=self._statementHandle,
				resultSetMetaData=self._resultSetMetaData,
				data=self._data
			)

# --- TableContent Model ---
class TableContent(BaseModel):
	tool_use_id: str
	query_id: str
	result_set: ResultSet
	title: str

	class Builder:
		def __init__(self):
			self._tool_use_id = None
			self._query_id = None
			self._result_set = None
			self._title = None

		def tool_use_id(self, value: str):
			self._tool_use_id = value
			return self
		def query_id(self, value: str):
			self._query_id = value
			return self
		def result_set(self, value: ResultSet):
			self._result_set = value
			return self
		def title(self, value: str):
			self._title = value
			return self
		def from_dict(self, d: dict):
			self._tool_use_id = d.get("tool_use_id")
			self._query_id = d.get("query_id")
			self._result_set = ResultSet.from_dict(d["result_set"])
			self._title = d.get("title")
			return self
		def build(self):
			if not (self._tool_use_id and self._query_id and self._result_set and self._title):
				raise ValueError("All fields must be set for TableContent.")
			return TableContent(
				tool_use_id=self._tool_use_id,
				query_id=self._query_id,
				result_set=self._result_set,
				title=self._title
			)


class ThinkingContent(BaseModel):
	text: str

	class Builder:
		def __init__(self):
			self._text = None

		def text(self, value: str):
			self._text = value
			return self

		def from_dict(self, d: dict):
			self._text = d.get("text")
			return self

		def build(self):
			if not self._text:
				raise ValueError("text must be set for ThinkingContent.")
			return ThinkingContent(text=self._text)


# --- ToolResultContent Models ---
from abc import ABC

class ToolResultContentType(str, Enum):
	JSON = "json"
	TEXT = "text"

class ToolResultContent(BaseModel, ABC):
	type: ToolResultContentType

	@staticmethod
	def from_dict(d: dict) -> 'ToolResultContent':
		t = d.get("type")
		if t == ToolResultContentType.JSON:
			return JsonToolResultContent.Builder().from_dict(d).build()
		elif t == ToolResultContentType.TEXT:
			return TextToolResultContent.Builder().from_dict(d).build()
		else:
			raise ValueError(f"Invalid ToolResultContent type: {t}")

class JsonToolResultContent(ToolResultContent):
	type: ToolResultContentType = ToolResultContentType.JSON
	json: dict

	class Builder:
		def __init__(self):
			self._json = None
		def json(self, value: dict):
			self._json = value
			return self
		def from_dict(self, d: dict):
			self._json = d.get("json")
			return self
		def build(self):
			if self._json is None:
				raise ValueError("json must be set for JsonToolResultContent.")
			return JsonToolResultContent(json=self._json)

class TextToolResultContent(ToolResultContent):
	type: ToolResultContentType = ToolResultContentType.TEXT
	text: str

	class Builder:
		def __init__(self):
			self._text = None
		def text(self, value: str):
			self._text = value
			return self
		def from_dict(self, d: dict):
			self._text = d.get("text")
			return self
		def build(self):
			if not self._text:
				raise ValueError("text must be set for TextToolResultContent.")
			return TextToolResultContent(text=self._text)

# --- ToolResult Model ---
class ToolResult(BaseModel):
	tool_use_id: str
	type: str
	name: str
	content: list[ToolResultContent]
	status: str

	class Builder:
		def __init__(self):
			self._tool_use_id = None
			self._type = None
			self._name = None
			self._content = []
			self._status = None

		def tool_use_id(self, value: str):
			self._tool_use_id = value
			return self
		def type(self, value: str):
			self._type = value
			return self
		def name(self, value: str):
			self._name = value
			return self
		def content(self, value: list):
			self._content = value
			return self
		def add_content_item(self, value: ToolResultContent):
			self._content.append(value)
			return self
		def status(self, value: str):
			self._status = value
			return self
		def from_dict(self, d: dict):
			self._tool_use_id = d.get("tool_use_id")
			self._type = d.get("type")
			self._name = d.get("name")
			self._content = [ToolResultContent.from_dict(c) for c in d.get("content", [])]
			self._status = d.get("status")
			return self
		def build(self):
			if not (self._tool_use_id and self._type and self._name and self._content is not None and self._status):
				raise ValueError("All fields must be set for ToolResult.")
			return ToolResult(
				tool_use_id=self._tool_use_id,
				type=self._type,
				name=self._name,
				content=self._content,
				status=self._status
			)


class ToolUse(BaseModel):
	tool_use_id: str
	type: str
	name: str
	input: dict
	client_side_execute: bool

	class Builder:
		def __init__(self):
			self._tool_use_id = None
			self._type = None
			self._name = None
			self._input = None
			self._client_side_execute = None

		def tool_use_id(self, value: str):
			self._tool_use_id = value
			return self
		def type(self, value: str):
			self._type = value
			return self
		def name(self, value: str):
			self._name = value
			return self
		def input(self, value: dict):
			self._input = value
			return self
		def client_side_execute(self, value: bool):
			self._client_side_execute = value
			return self
		def from_dict(self, d: dict):
			self._tool_use_id = d.get("tool_use_id")
			self._type = d.get("type")
			self._name = d.get("name")
			self._input = d.get("input")
			self._client_side_execute = d.get("client_side_execute")
			return self
		def build(self):
			if None in [self._tool_use_id, self._type, self._name, self._input, self._client_side_execute]:
				raise ValueError("All fields must be set for ToolUse.")
			return ToolUse(
				tool_use_id=self._tool_use_id,
				type=self._type,
				name=self._name,
				input=self._input,
				client_side_execute=self._client_side_execute
			)

# --- MessageContentItem (Union) ---

# Enum for message content types
class MessageContentType(str, Enum):
	CHART = "chart"
	TABLE = "table"
	TEXT = "text"
	THINKING = "thinking"
	TOOL_RESULT = "tool_result"
	TOOL_USE = "tool_use"

# Interface/base class
class MessageContentItem(BaseModel):
	type: MessageContentType

	@staticmethod
	def from_dict(d: dict) -> 'MessageContentItem':
		t = d.get("type")
		if t not in MessageContentType._value2member_map_:
			raise ValueError(f"Invalid message content type: {t}")
		t_enum = MessageContentType(t)
		if t_enum == MessageContentType.CHART:
			return ChartMessageContentItem.Builder().from_dict(d).build()
		elif t_enum == MessageContentType.TABLE:
			return TableMessageContentItem.Builder().from_dict(d).build()
		elif t_enum == MessageContentType.TEXT:
			return TextMessageContentItem.Builder().from_dict(d).build()
		elif t_enum == MessageContentType.THINKING:
			return ThinkingMessageContentItem.Builder().from_dict(d).build()
		elif t_enum == MessageContentType.TOOL_RESULT:
			return ToolResultMessageContentItem.Builder().from_dict(d).build()
		elif t_enum == MessageContentType.TOOL_USE:
			return ToolUseMessageContentItem.Builder().from_dict(d).build()
		else:
			raise ValueError(f"Unhandled message content type: {t}")

# Concrete implementations for each type
class ChartMessageContentItem(MessageContentItem):
	chart: ChartContent
	type: MessageContentType = MessageContentType.CHART

	class Builder:
		def __init__(self):
			self._chart = None
		def chart(self, value: ChartContent):
			self._chart = value
			return self
		def from_dict(self, d: dict):
			self._chart = ChartContent(**d["chart"])
			return self
		def build(self):
			return ChartMessageContentItem(chart=self._chart)

class TableMessageContentItem(MessageContentItem):
	table: TableContent
	type: MessageContentType = MessageContentType.TABLE

	class Builder:
		def __init__(self):
			self._table = None
		def table(self, value: TableContent):
			self._table = value
			return self
		def from_dict(self, d: dict):
			self._table = TableContent(**d["table"])
			return self
		def build(self):
			return TableMessageContentItem(table=self._table)

class TextMessageContentItem(MessageContentItem):
	text: str
	annotations: Optional[list[Annotation]] = None
	is_elicitation: Optional[bool] = None
	type: MessageContentType = MessageContentType.TEXT

	class Builder:
		def __init__(self):
			self._text = None
			self._annotations = None
			self._is_elicitation = None
		def text(self, value: str):
			self._text = value
			return self
		def annotations(self, value: list):
			self._annotations = value
			return self
		def is_elicitation(self, value: bool):
			self._is_elicitation = value
			return self
		def from_dict(self, d: dict):
			self._text = d.get("text")
			self._annotations = [Annotation(**a) for a in d.get("annotations", [])] if d.get("annotations") else None
			self._is_elicitation = d.get("is_elicitation")
			return self
		def build(self):
			return TextMessageContentItem(text=self._text, annotations=self._annotations, is_elicitation=self._is_elicitation)

class ThinkingMessageContentItem(MessageContentItem):
	thinking: ThinkingContent
	type: MessageContentType = MessageContentType.THINKING

	class Builder:
		def __init__(self):
			self._thinking = None
		def thinking(self, value: ThinkingContent):
			self._thinking = value
			return self
		def from_dict(self, d: dict):
			self._thinking = ThinkingContent(**d["thinking"])
			return self
		def build(self):
			return ThinkingMessageContentItem(thinking=self._thinking)

class ToolResultMessageContentItem(MessageContentItem):
	tool_result: ToolResult
	type: MessageContentType = MessageContentType.TOOL_RESULT

	class Builder:
		def __init__(self):
			self._tool_result = None
		def tool_result(self, value: ToolResult):
			self._tool_result = value
			return self
		def from_dict(self, d: dict):
			self._tool_result = ToolResult(**d["tool_result"])
			return self
		def build(self):
			return ToolResultMessageContentItem(tool_result=self._tool_result)

class ToolUseMessageContentItem(MessageContentItem):
	tool_use: ToolUse
	type: MessageContentType = MessageContentType.TOOL_USE

	class Builder:
		def __init__(self):
			self._tool_use = None
		def tool_use(self, value: ToolUse):
			self._tool_use = value
			return self
		def from_dict(self, d: dict):
			self._tool_use = ToolUse(**d["tool_use"])
			return self
		def build(self):
			return ToolUseMessageContentItem(tool_use=self._tool_use)

# --- Message Model ---
class Message(BaseModel):
	role: str  # 'user' or 'assistant'
	content: list[MessageContentItem]

	class Builder:
		def __init__(self):
			self._role = None
			self._content = []
		def role(self, value: str):
			self._role = value
			return self
		def content(self, value: list):
			self._content = value
			return self
		def add_content_item(self, item: MessageContentItem):
			self._content.append(item)
			return self
		def from_dict(self, d: dict):
			self._role = d["role"]
			self._content = [MessageContentItem.from_dict(c) for c in d["content"]]
			return self
		def build(self):
			return Message(role=self._role, content=self._content)

class AgentInstructions(BaseModel):
	class Builder:
		def __init__(self):
			self._response = None
			self._orchestration = None
			self._system = None
		def response(self, value: str):
			self._response = value
			return self
		def orchestration(self, value: str):
			self._orchestration = value
			return self
		def system(self, value: str):
			self._system = value
			return self
		def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			self._response = config["agent_instructions"].get("response")
			self._orchestration = config["agent_instructions"].get("orchestration")
			self._system = config["agent_instructions"].get("system")
			return self
		def build(self):
			if not (self._response and self._orchestration and self._system):
				raise ValueError("All AgentInstructions fields must be set.")
			return AgentInstructions(
				response=self._response,
				orchestration=self._orchestration,
				system=self._system
			)
	response: str
	orchestration: str
	system: str
	"""
	response: Instructions for response generation.
	orchestration: Custom instructions for tool planning.
	system: System instructions for the agent.
	"""

class BudgetConfig(BaseModel):
	seconds: int
	tokens: int
	"""
	seconds: Time budget in seconds.
	tokens: Token budget.
	"""

class OrchestrationConfig(BaseModel):
	class Builder:
		def __init__(self):
			self._budget = None
		def budget(self, value: 'BudgetConfig'):
			self._budget = value
			return self
		def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			budget_cfg = config.get("orchestration_config", {}).get("budget", {})
			if not budget_cfg:
				raise ValueError("No budget config found in orchestration_config.")
			self._budget = BudgetConfig(**budget_cfg)
			return self
		def build(self):
			if not self._budget:
				raise ValueError("Budget must be set for OrchestrationConfig.")
			return OrchestrationConfig(budget=self._budget)
	budget: 'BudgetConfig'
	"""
	budget: Budget constraints for the agent. If more than one constraint is specified, whichever is first hit will end the request.
	"""

class ModelConfig(BaseModel):
	class Builder:
		def __init__(self):
			self._orchestration = None
		def orchestration(self, value: str):
			self._orchestration = value
			return self
		def from_config_file(self, config_path: str = f"{os.environ.get('GENAI_PATH', '').lower()}/agent.yaml"):
			if not os.path.exists(config_path):
				raise FileNotFoundError(f"Config file {config_path} not found.")
			with open(config_path) as f:
				config = yaml.safe_load(f)
			self._orchestration = config.get("model_config", {}).get("orchestration")
			return self
		def build(self):
			if not self._orchestration:
				raise ValueError("Orchestration must be set for ModelConfig.")
			return ModelConfig(orchestration=self._orchestration)
	orchestration: str
	"""
	orchestration: Model to use for orchestration. If not provided, a model is automatically selected.
	"""

#Define Messages
# AgentRun model for agent execution requests
class AgentRun(BaseModel):
	async def run(self):
		request_body = {
			"thread_id": self.thread_id,
			"parent_message_id": self.parent_message_id,
			"messages": self.messages,
			"tool_choice": self.tool_choice
		}
		print(request_body)
		print(self.headers)
		print(self.url)
		async def agent_v2_data_streamer():
			try:
				async with httpx.AsyncClient(timeout=None, verify=False) as client:
					async with client.stream("POST", url=self.url, headers=self.headers, json=request_body) as response:
						response.raise_for_status()
						if 200 <= response.status_code < 300:
							async for result_chunk in response.aiter_bytes():
								print(result_chunk)
								if result_chunk:
									yield result_chunk
						else:
							yield json.dumps({
								"error": "Request failed",
								"code": response.status_code,
								"reason": getattr(response, 'reason_phrase', None),
								"details": "Non-successful status code received."
							})
			except Exception as e:
				import sys
				exc_type, exc_value, exc_traceback = sys.exc_info()
				yield json.dumps({
					"error": "Exception occurred",
					"code": getattr(e, 'response', None) and getattr(e.response, 'status_code', None),
					"reason": str(e),
					"details": str(e)
				})
		return StreamingResponse(agent_v2_data_streamer(), media_type='text/event-stream')

	class Builder:
		def __init__(self):
			self._application_name = None
			self._user_identity = None
			self._thread_id = None
			self._parent_message_id = None
			self._messages = None
			self._tool_choice = None
			self._models = None
			self._instructions = None
			self._orchestration = None
			self._tools = None
			self._tool_resources = None
			self._agent_db = None
			self._agent_schema = None
			self._agent_name = None
			self._aplctn_cd = None
			self._env = None
			self._region_name = None
			self._warehouse_size_suffix = None
			self._prefix = None

		def application_name(self, value: str):
			self._application_name = value
			return self
		def user_identity(self, value: str):
			self._user_identity = value
			return self

		def _resolve_refs(self,schema: dict) -> dict:
			defs = schema.get("$defs", {})
			def _resolve(obj):
				if isinstance(obj, dict):
					if "$ref" in obj:
						ref_path = obj["$ref"]
                        # Only support local refs like "#/$defs/SomeType"
						if ref_path.startswith("#/$defs/"):
							def_key = ref_path.split("/")[-1]
							return _resolve(defs[def_key])
						else:
							raise ValueError(f"Unsupported $ref path: {ref_path}")
					else:
						return {k: _resolve(v) for k, v in obj.items()}
				elif isinstance(obj, list):
					return [_resolve(item) for item in obj]
				else:
					return obj
            # Remove $defs from the top-level after resolving
			resolved = _resolve(schema)
			if "$defs" in resolved:
				del resolved["$defs"]
			return resolved

		def aplctn_cd(self, value: str):
			self._aplctn_cd = value
			return self

		def env(self, value: str):
			self._env = value
			return self

		def region_name(self, value: str):
			self._region_name = value
			return self

		def warehouse_size_suffix(self, value: str):
			self._warehouse_size_suffix = value
			return self

		def prefix(self, value: str):
			self._prefix = value
			return self

		def agent_db(self, value: str):
			self._agent_db = value
			return self

		def agent_schema(self, value: str):
			self._agent_schema = value
			return self

		def agent_name(self, value: str):
			self._agent_name = value
			return self

		def thread_id(self, value: int):
			self._thread_id = value
			return self

		def parent_message_id(self, value: int = 0):
			self._parent_message_id = value
			return self

		def messages(self, value: list):
			if value is None:
				raise ValueError("messages is a required field and cannot be None.")
			print(value)
			self._messages = value
			print(self._messages)
			return self

		def tool_choice(self, value: 'ToolChoice' = None):
			if value == None:
				self._tool_choice = ToolChoice \
									 .Builder() \
									.from_config_file().build().model_dump()

			else:
				self._tool_choice = value
			return self

		def models(self, value: 'ModelConfig' = None):
			if value == None:
				self._models = ModelConfig \
				                    .Builder() \
				                    .from_config_file().build().model_dump()

			else:
				self._models = value
			return self

		def instructions(self, value: 'AgentInstructions'=None):
			if value == None:
				self._instructions = AgentInstructions \
					.Builder() \
					.from_config_file().build().model_dump()

			else:
				self._instructions = value
			return self

		def orchestration(self, value: 'OrchestrationConfig'= None):
			if value == None:
				self._orchestration = OrchestrationConfig \
					.Builder() \
					.from_config_file().build().model_dump()
			else:
				self._orchestration = value
			return self

		def tools(self, value: Tools = None):
			if value == None:
				self._tools = Tools \
					.Builder() \
					.from_config_file().build().model_dump()

			else:
				self._tools = value
			return self

		def tool_resources(self, value: ToolResources = None):
			if value == None:
				self._tool_resources = ToolResourcesBuilder \
					.from_config_file().build().model_dump()

			else:
				self._tool_resources = value
			return self


		def build(self):
			if self._messages is None:
				raise ValueError("messages must be set for AgentRun.")
			env = os.getenv('env_name')
			if env=="dev" or env=="sit":
				account = "st69414.us-east-2.privatelink"
				HOST = "carelon-eda-nonprod.privatelink.snowflakecomputing.com"
			elif env=="uat" or env=="preprod":
				account = "jib90126.us-east-1.privatelink"
				HOST = "carelon-eda-preprod.privatelink.snowflakecomputing.com"
			else:
				account = "gcb59607.us-east-1.privatelink"
				HOST = "carelon-edaprod.privatelink.snowflakecomputing.com"
			url = f"https://{HOST}/api/v2/databases/{self._agent_db}/schemas/{self._agent_schema}/agents/{self._agent_name}:run"
			auth_manager = SnowflakeAuthManager()
			conn = auth_manager.builder().build_rrr(logger,self._aplctn_cd, self._env, self._region_name, self._warehouse_size_suffix, self._prefix,self._user_identity)
			headers = {
				"Authorization": f"Snowflake Token=\"{getattr(getattr(conn, "rest", None), "token", None)}\"",
				"Content-Type": "application/json",
				"Accept": "application/json"
			}
			# ThreadManager logic
			thread_id = self._thread_id
			parent_message_id = self._parent_message_id
			if self._application_name and self._user_identity:
				tm = ThreadManager(
							self._application_name,
							self._user_identity,
							logger=logger,
							aplctn_cd=self._aplctn_cd,
							env=self._env,
							region_name=self._region_name,
							warehouse_size_suffix=self._warehouse_size_suffix,
							prefix=self._prefix
							)
				if thread_id is None:
					thread_id = tm.get_latest_thread_id()
				if parent_message_id is None:
					parent_message_id = tm.get_parent_message_id(thread_id)
			return AgentRun(
				url=url,
				headers=headers,
				thread_id=thread_id,
				parent_message_id=parent_message_id,
				messages=self._messages,
				tool_choice=self._tool_choice,
				models=self._models,
				instructions=self._instructions,
				orchestration=self._orchestration,
				tools=self._tools,
				tool_resources=self._tool_resources
			)
	url: str = None
	headers: Dict[str, str] = {}
	thread_id: Optional[int] = None
	parent_message_id: Optional[int] = None
	messages: list
	tool_choice: Optional[dict] = None
	models: Optional[dict] = None
	instructions: Optional[dict] = None
	orchestration: Optional[dict] = None
	tools: Optional[list] = None
	tool_resources: Optional[dict] = None
	"""
	thread_id: The thread ID for the conversation. If thread_id is used, then parent_message_id must be passed as well.
	parent_message_id: The ID of the parent message in the thread. If this is the first message, parent_message_id should be 0.
	messages: List of Message objects (user and assistant messages in order).
	tool_choice: Configures how the agent should select and use tools during the interaction.
	models: Model configuration for the agent (orchestration model).
	instructions: Instructions for the agent’s behavior.
	orchestration: Orchestration configuration, including budget constraints.
	tools: List of tools available for the agent to use.
	tool_resources: Configuration for each tool referenced in the tools array. Keys must match the name of the respective tool.
	"""
