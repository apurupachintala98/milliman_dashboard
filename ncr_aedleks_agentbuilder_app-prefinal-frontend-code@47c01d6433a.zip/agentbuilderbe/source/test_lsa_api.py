"""
Test script for LangGraph Single Agent (LSA) APIs
Demonstrates complete workflow of provider/model retrieval,
agent creation, memory configuration, MCP tool setup, backend/frontend config, and download.
"""

import requests
import json
import os

BASE_URL = "http://localhost:8000/api/lsa"


def print_response(title, response):
    """Pretty print API response"""
    print(f"\n{'='*60}")
    print(f"{title}")
    print(f"{'='*60}")
    print(f"Status Code: {response.status_code}")
    try:
        print(json.dumps(response.json(), indent=2))
    except Exception:
        print(response.text)
    print(f"{'='*60}\n")


def test_lsa_workflow():
    """Run through all LSA APIs in sequence"""

    # Step 1: Health check (root)
    print("\nStep 1 - Health Check")
    response = requests.get("http://localhost:8000/")
    print_response("Health Check", response)
    if response.status_code != 200:
        print("❌ Server not healthy")
        return


    # Step 2: Get providers
    print("\nStep 2 - Get LLM Providers")
    response = requests.get(f"{BASE_URL}/providers")
    print_response("Providers", response)
    if response.status_code != 200:
        print("❌ Failed to fetch providers")
        return

    providers = response.json()
    print(f"✅ Found {len(providers)} providers")
    provider_id = providers[0]["provider_id"] if providers else "openai"
    provider_id = "cortex"


    # Step 3: Get LLMs for provider
    print("\nStep 3 - Get LLMs for Provider")
    response = requests.get(f"{BASE_URL}/providers/{provider_id}/llms")
    print_response("LLMs by Provider", response)
    if response.status_code != 200:
        print("❌ Failed to fetch LLMs")
        return

    llms = response.json()
    llm_model_id = llms[0]["model_id"] if llms else "gpt-4"
    llm_model_id = "openai-gpt-5-chat"
    llm_model_name = llms[0]["model_name"] if llms else "GPT 4"
    llm_model_name = "GPT 5 Chat"
    llm_model_id = "claude-4-sonnet"
    llm_model_name = "Claude 4 Sonnet"


    # Step 4: Create agent
    print("\nStep 4 - Create LangGraph Agent")
    agent_payload = {
        "agent_name": "customer_support_agent",
        "agent_description": "Handles customer queries and support tickets",
        "agent_instructions": {
            "system": "You are a helpful assistant.",
            "orchestration": "Route queries based on intent.",
            "response_structure": "Provide clear, concise answers."
        },
        "llm_config": {
            "model_id": llm_model_id,
            "model_name": llm_model_name,
            "provider_name": provider_id,
            "llm_auth": {
                "base_url": "https://carelon-eda-preprod.privatelink.snowflakecomputing.com/api/v2/cortex/v1",
                "pat_token": "",
            },
            "llm_model_config": {
                "temperature": 0.7,
                "max_tokens": 1024
            }
        }
    }

    response = requests.post(f"{BASE_URL}/agent/create", json=agent_payload)
    print_response("Create Agent", response)
    if response.status_code != 200:
        print("❌ Failed to create agent")
        return
    agent_uuid = response.json()["agent_uuid"]
    print(f"✅ Agent created with UUID: {agent_uuid}")


    # Step 5: Configure memory
    print("\nStep 5 - Configure Memory")
    memory_payload = {
        "short_term_memory_needed": True,
        "long_term_memory_needed": True,
        "long_term_memory_config": {
            "semantic_user_profile": True,
            "episodic_user_experience": True,
            "procedural_user_instructions": True,
            "custom": False
        },
        "db_type": "postgres",
        "db_host": "aapsql-apm1010241-devcl01.cluster-c1orsd8u0hmn.us-east-2.rds.amazonaws.com",
        "db_port": 5432,
        "db_username": "src_aedl_dml",
        "db_password": "85FC7ou6d(qB]jKl",
        "db_name": "audt_cntrl",
        "db_schema": "dummy_memory_schema"
    }

    response = requests.post(f"{BASE_URL}/agent/{agent_uuid}/memory", json=memory_payload)
    print_response("Configure Memory", response)
    if response.status_code != 200:
        print("❌ Failed to configure memory")
        return
    print("✅ Memory configured successfully")


    # Step 6: Upload STDIO tool file
    print("\nStep 6 - Upload STDIO Tool File")
    test_file_path = "./stdio_time_server.py"
    # with open(test_file_path, "w") as f:
    #     f.write("print('Hello from STDIO tool')")

    with open(test_file_path, "rb") as f:
        files = {"file": (os.path.basename(test_file_path), f, "text/x-python")}
        response = requests.post(f"{BASE_URL}/agent/{agent_uuid}/tools/upload", files=files)
    print_response("Upload Tool File", response)
    if response.status_code != 200:
        print("❌ Failed to upload tool file")
        return
    destination_path = response.json()["destination_path"]


    # Step 7: Configure tools
    print("\nStep 7 - Configure MCP Tools")
    tools_payload = {
        "mcp_tools": [
            {
                "transport": "stdio",
                "name": "time_server",
                "description": "Returns current date and time in a given timezone.",
                "config": {
                    "command": "python",
                    "args": destination_path
                }
            }
            # {
            #     "transport": "streamable_http",
            #     "name": "time_server",
            #     "description": "Returns current date and time in a given timezone.",
            #     "config": {
            #         "url": "http://localhost:6002/mcp",
            #         "config": "Optional"
            #     }
            # }
        ]
    }

    response = requests.post(f"{BASE_URL}/agent/{agent_uuid}/tools", json=tools_payload)
    print_response("Configure Tools", response)
    if response.status_code != 200:
        print("❌ Failed to configure tools")
        return
    print("✅ Tools configured successfully")


    # Step 8: Backend config
    print("\nStep 8 - Configure Backend")
    backend_payload = {"port": 9000}
    response = requests.post(f"{BASE_URL}/agent/{agent_uuid}/backend", json=backend_payload)
    print_response("Configure Backend", response)
    if response.status_code != 200:
        print("❌ Backend config failed")
        return


    # Step 9: Frontend config
    print("\nStep 9 - Configure Frontend")
    frontend_payload = {"host": "127.0.0.1", "port": 4000}
    response = requests.post(f"{BASE_URL}/agent/{agent_uuid}/frontend", json=frontend_payload)
    print_response("Configure Frontend", response)
    if response.status_code != 200:
        print("❌ Frontend config failed")
        return


    # Step 10: Download agent ZIP
    print("\nStep 10 - Download Agent ZIP")
    response = requests.get(f"{BASE_URL}/agent/{agent_uuid}/download")
    if response.status_code == 200:
        filename = f"lsa_agent_{agent_uuid}.zip"
        with open(filename, "wb") as f:
            f.write(response.content)
        print(f"✅ Agent ZIP downloaded: {filename} ({len(response.content)} bytes)")
    else:
        print("❌ Failed to download agent ZIP")
        print_response("Download Error", response)


    print("\n" + "="*60)
    print("🎉 LSA workflow completed successfully 🎉")
    print("="*60)


if __name__ == "__main__":
    print("🚀 Starting LangGraph Single Agent (LSA) API tests\n")
    print("Make sure the API server is running at http://localhost:8000")
    input("Press Enter to start tests...")

    try:
        test_lsa_workflow()
    except requests.exceptions.ConnectionError:
        print("\n❌ Connection error - start API server first")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()