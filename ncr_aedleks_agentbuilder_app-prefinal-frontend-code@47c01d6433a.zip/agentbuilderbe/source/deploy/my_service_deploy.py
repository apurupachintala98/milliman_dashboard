"""
EKS Service Deployment Example
==============================

Simple example to deploy a service to EKS with complete automation.
Update the configuration below and run: python3 example_deployment.py

What it does:
1.  Generates Helm charts and Tekton configs
2.  Clones/reuses Git repository  
3.  Creates feature branch from develop
4.  Commits and pushes service files
5.  Merges feature branch to develop
6.  Cleans up local files

Usage: python3 example_deployment.py
"""

import os
from deploy.invoke import complete_dual_repo_workflow

# =============================================================================
# 🔧 CONFIGURATION - UPDATE FOR YOUR SERVICE
# =============================================================================

# Service Configuration
SERVICE_CONFIG = {
    'service_name': 'sample',          #  CHANGE THIS - your service name
    'environment': 'dev',                          # Environment: dev/uat/prod
    'container_port': 8080,                        #  CHANGE THIS - your app port
    'cpu_limit': '500m',                           # CPU limit
    'memory_limit': '1Gi',                         # Memory limit  
    'replicas': 2,                                 # Number of pods
    'image_tag': 'latest',                         # Docker image tag
    'app_source_path': '/new_caoagent/test_agbuilder/',    #  OPTIONAL: Directory containing servicename.zip
}

# Repository Configuration - DUAL REPO SUPPORT
REPO_CONFIG = {
    # Deploy Repository (Kubernetes YAML files, Helm charts)
    'deploy_repo': {
        'repo_url': 'https://bitbucket.elevancehealth.com/scm/aedlk8s/ncr_aedleks_agentbuilderpoc_deploy.git',
        'repo_path_in_repo': '',                   # Leave empty for root directory
    },
    # App Repository (Application source code, Python files)
    'app_repo': {  
        'repo_url': 'https://bitbucket.elevancehealth.com/scm/aedlk8s/ncr_aedleks_agentbuilderpoc_app.git',  # App repository
        'repo_path_in_repo': '',                   # Leave empty for root directory
    }
}

# Git Credentials -  UPDATE WITH YOUR CREDENTIALS
GIT_CREDENTIALS = {
    'username': 'AL14414',             #  Your Bitbucket username               
    'token': 'Nov@2025'             #  Your Bitbucket App Password           
}

# Workflow Options - Simplified for dual repository deployment
WORKFLOW_OPTIONS = {
    'auto_merge_pr': True,                     # Auto-merge the created PR
}

# =============================================================================
# 🚀 DEPLOYMENT EXECUTION
# =============================================================================

def deploy_example_service(service_config: dict,
                           git_credentials: dict
                           ) -> bool:
    """Deploy the example service using dual repository workflow"""
    # print(" EKS Service Deployment Example")
    # print("=" * 50)
    # print(f" Service: {SERVICE_CONFIG['service_name']}")
    # print(f" Environment: {SERVICE_CONFIG['environment']}")
    # print(f" Port: {SERVICE_CONFIG['container_port']}")
    # print(f" Resources: {SERVICE_CONFIG['cpu_limit']}/{SERVICE_CONFIG['memory_limit']}")
    # print(f" Replicas: {SERVICE_CONFIG['replicas']}")
    # print(" Workflow: Dual Repository (Deploy + App)")
    # print("=" * 50)
    
    # Extract service config to avoid parameter conflicts
    # config = SERVICE_CONFIG.copy()
    config = service_config.copy()
    service_name = config.pop('service_name')
    
    # Use the directory path directly (already unzipped content)
    app_source_dir = config.get('app_source_path', '.')
    
    # Validate directory exists and contains files
    if not os.path.exists(app_source_dir):
        print(f"\n Warning: Application source directory not found at: {app_source_dir}")
        print(" Cannot proceed without application source directory")
        return False
    
    if not os.path.isdir(app_source_dir):
        print(f"\n Warning: Path is not a directory: {app_source_dir}")
        print(" Expected a directory containing application files")
        return False
    
    # Check if directory has content
    dir_contents = os.listdir(app_source_dir)
    if not dir_contents:
        print(f"\n Warning: Application source directory is empty: {app_source_dir}")
        print(" Cannot proceed with empty directory")
        return False
    
    print(f" Found application source directory: {app_source_dir}")
    print(f" Directory contains {len(dir_contents)} items: {dir_contents[:5]}{'...' if len(dir_contents) > 5 else ''}")
    print(" Using DUAL REPOSITORY workflow (Deploy repo + App repo)")
    
    # Create a copy of config without app_source_path to avoid conflicts
    config_without_app_path = {k: v for k, v in config.items() if k != 'app_source_path'}
    
    success = complete_dual_repo_workflow(
        service_name=service_name,
        deploy_repo_config=REPO_CONFIG['deploy_repo'],
        app_repo_config=REPO_CONFIG['app_repo'],
        git_credentials=git_credentials,
        workflow_type='pr_api',
        auto_merge=WORKFLOW_OPTIONS['auto_merge_pr'],
        app_source_path=app_source_dir,
        **config_without_app_path
    )
    
    return success

def deploy(username: str, 
           service_config: dict,
           git_credentials: dict) -> bool:
    """Main execution"""
    try:
        # # Validate configuration
        # if GIT_CREDENTIALS['username'] == username:     
        #     print("💡 TIP: Update GIT_CREDENTIALS with your actual Bitbucket credentials")
        
        # Deploy service
        success = deploy_example_service(service_config, git_credentials)
        
        if success:
            print("\n🎉 DEPLOYMENT SUCCESS!")
            print("✅ Service deployed to both repositories")
            print("✅ Pull requests created and merged") 
            print("🚀 Ready for production use!")
        else:
            print("\n❌ DEPLOYMENT FAILED!")
            print("💡 Check error messages above for details")
            return False
            
    except KeyboardInterrupt:
        print("\n🛑 Deployment cancelled by user")
        return False
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return False
    
    return True

# if __name__ == "__main__":
#     deploy()
