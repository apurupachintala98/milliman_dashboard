#!/usr/bin/env python3
"""
Simple EKS Service Generator
"""

import os
import shutil
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def generate_service(service_name, environment='dev', **kwargs):
    """
    Simple method to generate service deployment files
    
    Args:
        service_name: Name of the service
        environment: Target environment (default: 'dev')
        **kwargs: Additional configuration
    
    Returns:
        bool: True if successful, False otherwise
    
    Example:
        generate_service('my-api')
        generate_service('my-api', environment='prod', container_port=9000)
    """
    
    logger.info(f" Generating service: {service_name}")
    logger.info(f" Environment: {environment}")
    
    # Get sourcefiles path
    script_dir = Path(__file__).parent
    sourcefiles_path = script_dir / "sourcefiles"
    
    if not sourcefiles_path.exists():
        logger.error(" sourcefiles directory not found!")
        return False
    
    # Setup service configuration
    service_config = {
        'service_name': service_name,
        'target_namespace': "bmbpoc-srv-devops",
        'container_port': kwargs.get('container_port', 8000),
        'cpu_limit': kwargs.get('cpu_limit', '1'),
        'memory_limit': kwargs.get('memory_limit', '2Gi'),
        'image_registry': kwargs.get('image_registry', 'quay-nonprod.elevancehealth.com'),
        'image_org': kwargs.get('image_org', 'sprk-wrklds-tekton'),
        'tag': kwargs.get('image_tag', 'latest')
    }
    
    # Create service directory
    service_dir = f"./{service_name}"
    os.makedirs(service_dir, exist_ok=True)
    os.makedirs(f"{service_dir}/templates", exist_ok=True)
    
    logger.info(f" Created directory: {service_dir}")
    
    try:
        # Copy Chart.yaml
        copy_and_update_chart(sourcefiles_path, service_dir, service_config)
        
        # Copy templates
        copy_templates(sourcefiles_path, service_dir)
        
        # Copy and update values file
        copy_and_update_values(sourcefiles_path, service_dir, service_config, environment)
        
        # Copy and update tekton values
        copy_and_update_tekton_values(sourcefiles_path, service_dir, service_config, environment)
        
        logger.info(f" Successfully generated service: {service_name}")
        logger.info(f" Files available in: {service_dir}")
        
        # List generated files
        list_generated_files(service_dir)
        
        return True
        
    except Exception as e:
        logger.error(f" Failed to generate service: {e}")
        return False


def copy_and_update_chart(sourcefiles_path, service_dir, service_config):
    """Copy and update Chart.yaml"""
    source_chart = sourcefiles_path / "Chart.yaml"
    target_chart = f"{service_dir}/Chart.yaml"
    
    if source_chart.exists():
        shutil.copy2(source_chart, target_chart)
        
        # Update Chart.yaml content
        with open(target_chart, 'r') as f:
            content = f.read()
        
        # Replace service name
        content = content.replace('name: tokenizer', f'name: {service_config["service_name"]}')
        content = content.replace('name: demoservice', f'name: {service_config["service_name"]}')
        content = content.replace('name: demo', f'name: {service_config["service_name"]}')
        content = content.replace(
            'description: A Helm chart for Kubernetes',
            f'description: A Helm chart for {service_config["service_name"]} Kubernetes deployment'
        )
        
        with open(target_chart, 'w') as f:
            f.write(content)
        
        logger.info(" Chart.yaml copied and updated")


def copy_templates(sourcefiles_path, service_dir):
    """Copy template files"""
    source_templates = sourcefiles_path / "templates"
    target_templates = f"{service_dir}/templates"
    
    if source_templates.exists():
        for template_file in source_templates.glob("*.yaml"):
            shutil.copy2(template_file, target_templates)
            logger.info(f"✅ Copied template: {template_file.name}")


def copy_and_update_values(sourcefiles_path, service_dir, service_config, environment):
    """Copy and update values file"""
    source_values = sourcefiles_path / f"values-{environment}.yaml"
    
    # If specific env file doesn't exist, use values-dev.yaml
    if not source_values.exists():
        source_values = sourcefiles_path / "values-dev.yaml"
    
    target_values = f"{service_dir}/values-{environment}.yaml"
    
    if source_values.exists():
        shutil.copy2(source_values, target_values)
        
        # Update values content
        with open(target_values, 'r') as f:
            content = f.read()
        
        service_name = service_config['service_name']
        namespace = service_config['target_namespace']
        
        # Update all the values to match your new template structure
        content = content.replace('namespace: bmbpoc-srv-devops', f'namespace: {namespace}')
        content = content.replace('label: sample-app', f'label: {service_name}')
        content = content.replace('imagePullSecrets: sprk-wrklds-tekton-tektontest-pull-secret', f'imagePullSecrets: sprk-wrklds-tekton-tektontest-pull-secret')
        
        # Update config section
        content = content.replace('name: sample-app', f'name: {service_name}')
        content = content.replace('environment: dev', f'environment: {environment}')
        
        # Update deployment section
        content = content.replace('deployment:\n  name: sample-app', f'deployment:\n  name: {service_name}')
        
        # Update container section
        content = content.replace('container:\n  name: sample-app', f'container:\n  name: {service_name}')
        content = content.replace('containerPort: 5000', f'containerPort: {service_config["container_port"]}')
        content = content.replace('    port: 5000', f'    port: {service_config["container_port"]}')  # For http section
        
        # Update service section  
        content = content.replace('name: sample-service', f'name: {service_name}-service')
        content = content.replace('targetPort: 5000', f'targetPort: {service_config["container_port"]}')
        
        # Add missing resource limits section if not present
        if 'resources:' not in content:
            # Insert resources section after container section
            container_section = content.find('container:')
            if container_section != -1:
                # Find the end of container section and insert resources
                lines = content.split('\n')
                new_lines = []
                in_container_section = False
                resources_added = False
                
                for line in lines:
                    new_lines.append(line)
                    if line.strip().startswith('container:'):
                        in_container_section = True
                    elif in_container_section and line.startswith('service:') and not resources_added:
                        # Add resources section before service section
                        new_lines.insert(-1, '')
                        new_lines.insert(-1, '# Resource Configuration')
                        new_lines.insert(-1, 'resources:')
                        new_lines.insert(-1, '  limits:')
                        new_lines.insert(-1, f'    cpu: "{service_config["cpu_limit"]}"')
                        new_lines.insert(-1, f'    memory: "{service_config["memory_limit"]}"')
                        new_lines.insert(-1, '  requests:')
                        new_lines.insert(-1, f'    cpu: "250m"')
                        new_lines.insert(-1, f'    memory: "512Mi"')
                        new_lines.insert(-1, '')
                        new_lines.insert(-1, '# Environment Configuration')
                        new_lines.insert(-1, 'env:')
                        region_value = content.split("region: ")[1].split("\n")[0] if "region: " in content else "us-east-1"
                        new_lines.insert(-1, f'  region: {region_value}')
                        new_lines.insert(-1, f'  Environment: {environment}')
                        new_lines.insert(-1, '')
                        new_lines.insert(-1, '# Service Account')
                        new_lines.insert(-1, f'serviceAccountName: bmbpoc-custom-sa')
                        resources_added = True
                        in_container_section = False
                
                content = '\n'.join(new_lines)
        else:
            # Update existing resource values
            content = content.replace('cpu: "1"', f'cpu: "{service_config["cpu_limit"]}"')
            content = content.replace('memory: "2Gi"', f'memory: "{service_config["memory_limit"]}"')
        
        with open(target_values, 'w') as f:
            f.write(content)
        
        logger.info(f" values-{environment}.yaml copied and updated")


def copy_and_update_tekton_values(sourcefiles_path, service_dir, service_config, environment):
    """Copy and update tekton values file"""
    target_tekton = f"{service_dir}/tekton-values-{environment}.yaml"
    
    # Generate tekton values content
    image_url = f"{service_config['image_registry']}/{service_config['image_org']}/{service_config['service_name']}:{service_config['tag']}"
    tekton_content = f"""container:
  image: {image_url}
"""
    
    with open(target_tekton, 'w') as f:
        f.write(tekton_content)
    
    logger.info(f"✅ tekton-values-{environment}.yaml created")


def list_generated_files(service_dir):
    """List all generated files"""
    logger.info("\n📁 Generated files:")
    for root, dirs, files in os.walk(service_dir):
        level = root.replace(service_dir, '').count(os.sep)
        indent = ' ' * 2 * level
        logger.info(f"{indent}{os.path.basename(root)}/")
        subindent = ' ' * 2 * (level + 1)
        for file in files:
            logger.info(f"{subindent}{file}")


if __name__ == "__main__":
    # Example usage
    print("Example: Basic service generation")
    generate_service('example-api')
