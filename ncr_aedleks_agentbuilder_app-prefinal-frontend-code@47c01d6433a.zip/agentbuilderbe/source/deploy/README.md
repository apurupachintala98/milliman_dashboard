# EKS Service Deployment Automation

## 🚀 Overview
Complete automation system for deploying services to EKS using dual repository strategy:
- **Deploy Repository**: Kubernetes YAML files, Helm charts, Tekton configs
- **App Repository**: Application source code, Python files

## 📁 Files Included
```
agent-builder/
├── my_service_deploy.py       # Main configuration & deployment script
├── invoke.py                  # Core workflow automation functions
├── deploy_app.py              # Template processing & file generation
└── sourcefiles/               # Kubernetes & Helm templates
    ├── Chart.yaml
    ├── values-dev.yaml
    ├── tekton-values-dev.yaml
    └── templates/
        ├── deployment.yaml
        ├── service.yaml
        ├── alb.yaml
        └── config.yaml
```

## 🔧 Setup Instructions

### 1. Update Configuration
Edit `my_service_deploy.py`:

```python
# Service Configuration
SERVICE_CONFIG = {
    'service_name': 'your-service-name',       # Your actual service name
    'environment': 'dev',                      # Target environment
    'container_port': 8080,                    # Your application port
    'app_source_path': './your-zip-directory', # Directory containing servicename.zip
}

# Repository URLs - Update with your repositories
REPO_CONFIG = {
    'deploy_repo': {
        'repo_url': 'https://your-bitbucket.com/scm/project/deploy-repo.git',
    },
    'app_repo': {
        'repo_url': 'https://your-bitbucket.com/scm/project/app-repo.git',
    }
}

# Your Bitbucket Credentials
GIT_CREDENTIALS = {
    'username': 'your-username',               # Your Bitbucket username
    'token': 'your-app-password'               # Your Bitbucket App Password
}
```

### 2. Prepare Application Code
Create a zip file with your application code:
```bash
# Your zip file should be named: {service-name}.zip
# Example: if service_name = 'user-api', create user-api.zip
zip -r your-service-name.zip your-application-files/
```

Place this zip file in the directory specified by `app_source_path`.

### 3. Run Deployment
```bash
python3 my_service_deploy.py
```

## 🔄 What It Does

### Phase 1: Deploy Repository (Kubernetes YAML)
1. ✅ Generates Helm charts and Tekton configs from templates
2. ✅ Clones/reuses deploy repository
3. ✅ Creates feature branch from develop
4. ✅ Commits and pushes service files
5. ✅ Creates Pull Request via Bitbucket API
6. ✅ Auto-merges PR to develop branch

### Phase 2: App Repository (Source Code)
1. ✅ Extracts application zip file
2. ✅ Deploys files directly to service directory (flattened structure)
3. ✅ Creates feature branch in app repository
4. ✅ Commits and pushes application code
5. ✅ Creates Pull Request via Bitbucket API
6. ✅ Auto-merges PR to develop branch

## 📋 Features

- **🎯 Dual Repository Support**: Separates infrastructure (YAML) and application code
- **📦 Automatic Zip Handling**: Extracts servicename.zip with flattened directory structure
- **🔄 Complete PR Workflow**: Creates and merges pull requests automatically
- **🛡️ SSL Support**: Handles corporate SSL certificates
- **📝 Template-Based**: Generates all Kubernetes manifests from templates
- **🧹 Cleanup**: Automatic cleanup of temporary files

## 🔧 Customization

### Templates
All Kubernetes templates are in `sourcefiles/templates/`:
- Modify templates to match your infrastructure requirements
- Update values files for different environments
- Add new templates as needed

### Workflow Options
```python
WORKFLOW_OPTIONS = {
    'auto_merge_pr': True,  # Set to False for manual PR merge
}
```

## ⚠️ Requirements

- Python 3.7+
- Git installed and configured
- Bitbucket access with App Password
- Network access to your Bitbucket instance

## 🆘 Troubleshooting

### Common Issues

1. **Zip file not found**
   - Ensure zip file is named `{service-name}.zip`
   - Check `app_source_path` directory exists
   - Verify file permissions

2. **Authentication errors**
   - Verify Bitbucket username and app password
   - Check repository access permissions
   - Ensure repositories exist

3. **SSL certificate issues**
   - Code handles SSL verification bypass for corporate environments
   - Check network connectivity to Bitbucket

### Debug Output
The script provides detailed output for each step:
- ✅ Success indicators
- ❌ Error messages with details
- 📋 Summary information
- 🔗 PR links when created

## 📞 Support
For issues or questions, check the error output messages which provide detailed troubleshooting information.