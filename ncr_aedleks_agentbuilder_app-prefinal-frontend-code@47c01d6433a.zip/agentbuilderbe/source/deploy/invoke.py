#!/usr/bin/env python3
"""
Service Generator with Bitbucket Integration
==========================================

Generates service files AND handles Bitbucket Git operations:
1. Generate service files
2. Clone target Bitbucket repository
3. Move files to repo
4. Commit and push to environment branch

Usage: python3 invoke.py

Bitbucket Setup:
- Create App Password: Bitbucket Settings > App Passwords
- Give permissions: Repositories (Read, Write)
"""

import os
import shutil
import subprocess
import tempfile
import requests
import json
import time
from pathlib import Path
from urllib.parse import quote
from deploy.deploy_app import generate_service

# Suppress SSL warnings for corporate environments
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def extract_repo_name(repo_url):
    """Extract repository name from URL"""
    # Handle different URL formats
    if repo_url.endswith('.git'):
        repo_url = repo_url[:-4]
    
    # Extract last part of URL
    repo_name = repo_url.split('/')[-1]
    
    # Clean up any remaining characters
    return repo_name.replace('.git', '')

def run_git_command(command, cwd=None):
    """Execute git command and return result"""
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            cwd=cwd, 
            capture_output=True, 
            text=True, 
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f" Git command failed: {command}")
        print(f"Error: {e.stderr}")
        return None

def clone_and_deploy_service(service_name, environment, repo_url, repo_path_in_repo="", git_credentials=None, **service_config):
    """
    Complete workflow: Generate service files, clone repo, move files, commit and push
    Uses persistent clone - reuses existing repo if available
    
    Args:
        service_name: Name of the service
        environment: Target environment ('dev', 'uat', 'prod')
        repo_url: Git repository URL to clone
        repo_path_in_repo: Path inside repo where to place service (default: root)
        git_credentials: Dict with 'username' and 'token' for authentication
        extracted_content: Dict of {filename: content} from extracted ZIP files
        **service_config: Additional service configuration
    """
    
    print(f" Starting complete deployment workflow for '{service_name}'")
    print("=" * 60)
    
    # Step 1: Generate service files
    print(" Step 1: Generating service files...")
    
    # Debug: Check service_config types
    print(f"🔍 Debug - service_name type: {type(service_name)}, value: {service_name}")
    for key, value in service_config.items():
        if isinstance(value, set):
            print(f"⚠️  WARNING: {key} is a set: {value}, converting to string")
            service_config[key] = str(list(value)[0]) if value else ""
    
    success = generate_service(service_name, environment, **service_config)
    
    if not success:
        print(" Service generation failed. Aborting.")
        return False
    
    service_dir = f"./{service_name}"
    if not os.path.exists(service_dir):
        print(f" Service directory {service_dir} not found")
        return False
    
    print(f" Service files generated in {service_dir}")
    
    # Step 2: Setup repository directory
    print(f"\n Step 2: Setting up repository...")
    
    # Extract repo name from URL
    repo_name = extract_repo_name(repo_url)
    repo_dir = f"./cloned_repos/{repo_name}"
    
    # Prepare git URL with credentials if provided
    if git_credentials and 'username' in git_credentials and 'token' in git_credentials:
        # URL encode credentials to handle special characters
        encoded_username = quote(git_credentials['username'], safe='')
        encoded_token = quote(git_credentials['token'], safe='')
        
        # Handle different URL formats
        if repo_url.startswith("https://"):
            if "@" in repo_url:
                # URL already has user info, replace it
                base_url = repo_url.split("@", 1)[1]
                auth_url = f"https://{encoded_username}:{encoded_token}@{base_url}"
            else:
                # Clean URL, add credentials
                auth_url = repo_url.replace("https://", f"https://{encoded_username}:{encoded_token}@")
        else:
            auth_url = repo_url
    else:
        auth_url = repo_url
    
    # Check if repo directory already exists
    if os.path.exists(repo_dir):
        print(f" Repository already exists at: {repo_dir}")
        print(f" Pulling latest changes...")
        
        # Pull latest changes from remote
        pull_result = run_git_command("git fetch --all", cwd=repo_dir)
        if pull_result is None:
            print("  Warning: Could not fetch latest changes")
        else:
            print(" Fetched latest changes")
    else:
        print(f" Cloning repository to: {repo_dir}")
        
        # Create cloned_repos directory
        os.makedirs("./cloned_repos", exist_ok=True)
        
        # Clone repository
        clone_result = run_git_command(f"git clone {auth_url} {repo_dir}")
        if clone_result is None:
            print(" Repository clone failed")
            return False
        
        print(f" Repository cloned to {repo_dir}")
    
    # Step 3: Determine target branch based on environment
    target_branch = get_environment_branch(environment)
    print(f"\n Step 3: Switching to branch '{target_branch}'...")
    
    # For dev environment, create feature branch from develop
    if environment == 'dev':
        print(f" Creating feature branch for initial migration...")
        # First checkout develop
        develop_result = run_git_command("git checkout develop", cwd=repo_dir)
        if develop_result is None:
            print(" Failed to checkout develop branch")
            return False
        
        # Pull latest develop
        pull_develop = run_git_command("git pull origin develop", cwd=repo_dir)
        if pull_develop is None:
            print("Warning: Could not pull latest develop, proceeding anyway")
        
        # Create feature branch from develop
        branch_result = run_git_command(f"git checkout -b {target_branch}", cwd=repo_dir)
        if branch_result is None:
            # Try to switch to existing branch
            branch_result = run_git_command(f"git checkout {target_branch}", cwd=repo_dir)
            if branch_result is None:
                print(f" Failed to switch to branch {target_branch}")
                return False
    else:
        # For other environments, switch to target branch directly
        branch_result = run_git_command(f"git checkout -b {target_branch}", cwd=repo_dir)
        if branch_result is None:
            # Try to switch to existing branch
            branch_result = run_git_command(f"git checkout {target_branch}", cwd=repo_dir)
            if branch_result is None:
                print(f" Failed to switch to branch {target_branch}")
                return False
    
    print(f" Switched to branch '{target_branch}'")
    
    # Step 4: Move service files to repository
    print(f"\n Step 4: Moving service files to repository...")
    
    # Determine target path in repo
    if repo_path_in_repo:
        target_path = os.path.join(repo_dir, repo_path_in_repo, service_name)
    else:
        target_path = os.path.join(repo_dir, service_name)
    
    # Create target directory
    os.makedirs(target_path, exist_ok=True)
    
    # Copy service files
    for item in os.listdir(service_dir):
        src_path = os.path.join(service_dir, item)
        dst_path = os.path.join(target_path, item)
        
        if os.path.isdir(src_path):
            shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
        else:
            shutil.copy2(src_path, dst_path)
    
    print(f"✅ Service files moved to {target_path}")
    
    # Step 5: Git operations
    print(f"\n🔄 Step 5: Committing and pushing changes...")
    
    # Pull latest changes first
    pull_result = run_git_command(f"git pull origin {target_branch}", cwd=repo_dir)
    if pull_result is None:
        print("⚠️  Warning: Could not pull latest changes, proceeding anyway")
    else:
        print(f"✅ Pulled latest changes from {target_branch}")
    
    # Add files
    add_result = run_git_command("git add .", cwd=repo_dir)
    if add_result is None:
        print(" Failed to add files")
        return False
    
    # Check if there are changes to commit
    status_result = run_git_command("git status --porcelain", cwd=repo_dir)
    if status_result is not None and status_result.strip() == "":
        print("ℹ️  No changes to commit (service already exists)")
        print(f"✅ Service {service_name} already exists in repository")
    else:
        # Commit only if there are changes
        commit_message = f"Add {service_name} service for {environment} environment"
        # Set git user identity for the commit
        set_name_result = run_git_command('git config user.name "automation-bot"', cwd=repo_dir)
        set_email_result = run_git_command('git config user.email "automation-bot@example.com"', cwd=repo_dir)
        commit_result = run_git_command(f'git commit -m "{commit_message}"', cwd=repo_dir)
        if commit_result is None:
            print("❌ Failed to commit changes")
            return False
        
        # Push
        push_result = run_git_command(f"git push origin {target_branch}", cwd=repo_dir)
        if push_result is None:
            print("❌ Failed to push changes")
            return False
        
        print(f"✅ Changes committed and pushed to {target_branch}")
        print(f"\n🎉 SUCCESS! Complete deployment workflow finished!")
    print(f"📋 Summary:")
    print(f"   ✅ Service: {service_name}")
    print(f"   ✅ Environment: {environment}")
    print(f"   ✅ Repository: {repo_url}")
    print(f"   ✅ Local Clone: {repo_dir}")
    print(f"   ✅ Branch: {target_branch}")
    print(f"   ✅ Path: {repo_path_in_repo or 'root'}/{service_name}")
    
    # Show Bitbucket Pull Request info for dev environment or non-main branches
    if environment == 'dev' or target_branch not in ['main', 'master', 'develop']:
        create_bitbucket_pull_request_info(service_name, environment, target_branch)
    
    # Optional: Clean up local service files after successful deployment
    print(f"\n Cleaning up local service files...")
    cleanup_local_service_files(service_name)
    
    return True,target_branch



def create_bitbucket_pull_request(repo_url, git_credentials, service_name, environment, source_branch="feature/initial_migration", target_branch="develop"):
    """
    Create a Pull Request in Bitbucket using API
    
    Args:
        repo_url: Git repository URL
        git_credentials: Dict with 'username' and 'token'
        service_name: Name of the service being deployed
        environment: Environment (dev/uat/prod)
        source_branch: Source branch for PR
        target_branch: Target branch for PR
    """
    
    try:
        print(f"\n📋 Creating Pull Request via Bitbucket API...")
        print(f"   🌿 {source_branch} → {target_branch}")
        
        # Extract repository details from URL
        # URL format: https://bitbucket.elevancehealth.com/scm/aedlk8s/repo-name.git
        url_parts = repo_url.replace('.git', '').split('/')
        project_key = url_parts[-2].upper()  # aedlk8s -> AEDLK8S
        repo_slug = url_parts[-1]  # repo name
        
        # Bitbucket API endpoint
        api_base = "https://bitbucket.elevancehealth.com/rest/api/1.0"
        pr_endpoint = f"{api_base}/projects/{project_key}/repos/{repo_slug}/pull-requests"
        
        # PR data
        pr_data = {
            "title": f"Add {service_name} service for {environment} environment",
            "description": f"- Added {service_name} service configuration\n- Environment: {environment}\n- Generated files: Chart.yaml, values-{environment}.yaml, tekton-values-{environment}.yaml\n- Part of initial migration to new deployment structure",
            "state": "OPEN",
            "open": True,
            "closed": False,
            "fromRef": {
                "id": f"refs/heads/{source_branch}",
                "repository": {
                    "slug": repo_slug,
                    "name": None,
                    "project": {
                        "key": project_key
                    }
                }
            },
            "toRef": {
                "id": f"refs/heads/{target_branch}",
                "repository": {
                    "slug": repo_slug,
                    "name": None,
                    "project": {
                        "key": project_key
                    }
                }
            },
            "reviewers": []
        }
        
        # Make API request (disable SSL verification for corporate environments)
        response = requests.post(
            pr_endpoint,
            json=pr_data,
            auth=(git_credentials['username'], git_credentials['token']),
            headers={'Content-Type': 'application/json'},
            verify=False  # Disable SSL verification for corporate Bitbucket
        )
        
        if response.status_code == 201:
            pr_info = response.json()
            pr_id = pr_info['id']
            pr_url = pr_info['links']['self'][0]['href']
            
            print(f"Pull Request created successfully!")
            print(f"PR #{pr_id}: {pr_url}")
            print(f"Title: {pr_data['title']}")
            
            return {
                'success': True,
                'pr_id': pr_id,
                'pr_url': pr_url,
                'data': pr_info
            }
        elif response.status_code == 409:
            # PR already exists, extract existing PR info from error response
            try:
                error_data = response.json()
                if 'errors' in error_data and len(error_data['errors']) > 0:
                    error_info = error_data['errors'][0]
                    if 'existingPullRequest' in error_info:
                        existing_pr = error_info['existingPullRequest']
                        pr_id = existing_pr['id']
                        pr_url = existing_pr['links']['self'][0]['href']
                        
                        print(f"   ℹ️  Pull Request already exists!")
                        print(f"   🔗 Existing PR #{pr_id}: {pr_url}")
                        print(f"   📝 Title: {existing_pr['title']}")
                        print(f"   💡 Using existing PR for this branch combination")
                        
                        return {
                            'success': True,
                            'pr_id': pr_id,
                            'pr_url': pr_url,
                            'data': existing_pr,
                            'existing': True
                        }
            except Exception as parse_error:
                print(f"   ⚠️  Could not parse existing PR details: {parse_error}")
                
            print(f"   ❌ PR already exists: {response.status_code}")
            print(f"   📄 Response: {response.text}")
            return {
                'success': False,
                'error': 'PR already exists',
                'response': response.text
            }
        else:
            print(f"   ❌ Failed to create PR: {response.status_code}")
            print(f"   📄 Response: {response.text}")
            return {
                'success': False,
                'error': response.text
            }
            
    except Exception as e:
        print(f"   ❌ Error creating PR: {e}")
        return {
            'success': False,
            'error': str(e)
        }


def merge_bitbucket_pull_request(repo_url, git_credentials, pr_id, wait_for_approval=False):
    """
    Merge a Pull Request in Bitbucket using API
    
    Args:
        repo_url: Git repository URL
        git_credentials: Dict with 'username' and 'token'
        pr_id: Pull Request ID to merge
        wait_for_approval: Whether to wait for approval before merging
    """
    
    try:
        print(f"\n🔀 Merging Pull Request #{pr_id}...")
        
        # Extract repository details from URL
        url_parts = repo_url.replace('.git', '').split('/')
        project_key = url_parts[-2].upper()
        repo_slug = url_parts[-1]
        
        # Bitbucket API endpoint
        api_base = "https://bitbucket.elevancehealth.com/rest/api/1.0"
        merge_endpoint = f"{api_base}/projects/{project_key}/repos/{repo_slug}/pull-requests/{pr_id}/merge"
        pr_endpoint = f"{api_base}/projects/{project_key}/repos/{repo_slug}/pull-requests/{pr_id}"
        
        # Check PR status first
        pr_response = requests.get(
            pr_endpoint,
            auth=(git_credentials['username'], git_credentials['token']),
            verify=False  # Disable SSL verification for corporate Bitbucket
        )
        
        if pr_response.status_code != 200:
            print(f"    Failed to get PR info: {pr_response.status_code}")
            return {'success': False, 'error': 'Could not retrieve PR info'}
        
        pr_info = pr_response.json()
        pr_state = pr_info['state']
        pr_version = pr_info['version']  # Get current version for optimistic locking
        
        if pr_state != 'OPEN':
            print(f"    PR is not open (state: {pr_state})")
            return {'success': False, 'error': f'PR state is {pr_state}'}
        
        # Check if approval is needed and wait
        if wait_for_approval:
            print(f"   ⏳ Waiting for PR approval...")
            
            time.sleep(2)  # Simple wait for demo
        
        # Merge the PR
        merge_data = {
            "message": f"Merge pull request #{pr_id}",
            "version": pr_version  # Include version for optimistic locking
        }
        
        # Make merge API request (disable SSL verification for corporate environments)  
        merge_response = requests.post(
            merge_endpoint,
            json=merge_data,
            auth=(git_credentials['username'], git_credentials['token']),
            headers={'Content-Type': 'application/json'},
            verify=False  # Disable SSL verification for corporate Bitbucket
        )
        
        if merge_response.status_code == 200:
            merge_info = merge_response.json()
            print(f"   ✅ Pull Request #{pr_id} merged successfully!")
            print(f"   🎯 Merged to: {pr_info['toRef']['displayId']}")
            
            return {
                'success': True,
                'pr_id': pr_id,
                'data': merge_info
            }
        else:
            print(f"   ❌ Failed to merge PR: {merge_response.status_code}")
            print(f"   📄 Response: {merge_response.text}")
            return {
                'success': False,
                'error': merge_response.text
            }
            
    except Exception as e:
        print(f"   ❌ Error merging PR: {e}")
        return {
            'success': False,
            'error': str(e)
        }


def complete_pr_workflow(service_name, repo_url, git_credentials=None, auto_merge=False, **service_config):
    """
    Complete PR workflow: Deploy to feature branch + Create PR + Optionally merge
    
    Args:
        service_name: Name of the service
        repo_url: Git repository URL
        git_credentials: Dict with 'username' and 'token'
        auto_merge: Whether to automatically merge the PR after creation
        **service_config: Additional service configuration
    """
    
    print(f"🚀 Starting COMPLETE PR workflow for '{service_name}'")
    print("=" * 70)
    
    # Extract environment from service config
    environment = service_config.pop('environment', 'dev')
    
    # Step 1: Deploy to feature branch
    print(f"📝 Phase 1: Deploy to feature branch...")
    deploy_success = clone_and_deploy_service(
        service_name=service_name,
        environment=environment,
        repo_url=repo_url,
        git_credentials=git_credentials,
        **service_config
    )
    
    if not deploy_success:
        print("❌ Deployment phase failed. Aborting workflow.")
        return False
    
    print(f"\n✅ Phase 1 completed successfully!")
    
    # Step 2: Create Pull Request
    print(f"\n📝 Phase 2: Creating Pull Request...")
    pr_result = create_bitbucket_pull_request(
        repo_url=repo_url,
        git_credentials=git_credentials,
        service_name=service_name,
        environment=environment
    )
    
    if not pr_result['success']:
        print("❌ PR creation failed.")
        return False
    
    pr_id = pr_result['pr_id']
    pr_url = pr_result['pr_url']
    
    print(f"\n✅ Phase 2 completed successfully!")
    print(f"   🔗 PR created: {pr_url}")
    
    # Step 3: Optionally merge PR
    if auto_merge:
        print(f"\n📝 Phase 3: Auto-merging Pull Request...")
        merge_result = merge_bitbucket_pull_request(
            repo_url=repo_url,
            git_credentials=git_credentials,
            pr_id=pr_id
        )
        
        if merge_result['success']:
            print(f"\n✅ Phase 3 completed successfully!")
            print(f"\n🎉 COMPLETE PR WORKFLOW SUCCESS!")
            print(f"📋 Final Summary:")
            print(f"   ✅ Service '{service_name}' deployed to feature branch")
            print(f"   ✅ Pull Request #{pr_id} created and merged")
            print(f"   ✅ All changes are now in develop branch")
            print(f"   🚀 Ready for further environments")
        else:
            print(f"\n❌ Phase 3 failed: {merge_result['error']}")
            print(f"\n📋 Partial Success:")
            print(f"   ✅ Service deployed to feature branch")
            print(f"   ✅ Pull Request #{pr_id} created: {pr_url}")
            print(f"   ❌ Auto-merge failed - manual merge required")
            return False
    else:
        print(f"\n🎉 PR WORKFLOW SUCCESS!")
        print(f"📋 Final Summary:")
        print(f"   ✅ Service '{service_name}' deployed to feature branch")
        print(f"   ✅ Pull Request #{pr_id} created: {pr_url}")
        print(f"   💡 Manual review and merge required")
    
    return True
    """Extract repository name from URL"""
    # Handle different URL formats
    if repo_url.endswith('.git'):
        repo_url = repo_url[:-4]
    
    # Extract last part of URL
    repo_name = repo_url.split('/')[-1]
    
    # Clean up any remaining characters
    return repo_name.replace('.git', '')


def cleanup_local_service_files(service_name):
    """Clean up local service files after successful deployment"""
    service_dir = f"./{service_name}"
    if os.path.exists(service_dir):
        try:
            shutil.rmtree(service_dir)
            print(f"✅ Cleaned up local service files: {service_dir}")
        except Exception as e:
            print(f"⚠️  Warning: Could not clean up {service_dir}: {e}")
    else:
        print(f"ℹ️  No cleanup needed - {service_dir} not found")


def list_cloned_repos():
    """List all cloned repositories"""
    cloned_repos_dir = "./cloned_repos"
    if not os.path.exists(cloned_repos_dir):
        print("📁 No cloned repositories found")
        return []
    
    repos = []
    for item in os.listdir(cloned_repos_dir):
        repo_path = os.path.join(cloned_repos_dir, item)
        if os.path.isdir(repo_path) and os.path.exists(os.path.join(repo_path, ".git")):
            repos.append(item)
    
    if repos:
        print(f"📁 Found {len(repos)} cloned repositories:")
        for repo in repos:
            print(f"   - {repo}")
    else:
        print("📁 No valid Git repositories found in cloned_repos/")
    
    return repos


def cleanup_cloned_repos():
    """Clean up all cloned repositories"""
    cloned_repos_dir = "./cloned_repos"
    if os.path.exists(cloned_repos_dir):
        try:
            shutil.rmtree(cloned_repos_dir)
            print(f"✅ Cleaned up all cloned repositories: {cloned_repos_dir}")
            return True
        except Exception as e:
            print(f"❌ Failed to cleanup cloned repositories: {e}")
            return False
    else:
        print("ℹ️  No cloned repositories directory found")
        return True

def merge_feature_to_develop(repo_url, git_credentials=None, feature_branch="feature/initial_migration"):
    """
    Merge feature branch to develop branch
    
    Args:
        repo_url: Git repository URL
        git_credentials: Dict with 'username' and 'token' for authentication
        feature_branch: Feature branch name to merge (default: feature/initial_migration)
    """
    
    print(f"🔄 Starting merge workflow: {feature_branch} → develop")
    print("=" * 60)
    
    # Extract repo name from URL
    repo_name = extract_repo_name(repo_url)
    repo_dir = f"./cloned_repos/{repo_name}"
    
    if not os.path.exists(repo_dir):
        print(f"❌ Repository not found at {repo_dir}")
        print(f"💡 Run deployment first to create the repository clone")
        return False
    
    print(f"📁 Using repository at: {repo_dir}")
    
    # Step 1: Switch to develop branch
    print(f"\n🌿 Step 1: Switching to develop branch...")
    develop_result = run_git_command("git checkout develop", cwd=repo_dir)
    if develop_result is None:
        print("❌ Failed to checkout develop branch")
        return False
    
    # Step 2: Pull latest develop
    print(f"🔄 Step 2: Pulling latest develop...")
    pull_result = run_git_command("git pull origin develop", cwd=repo_dir)
    if pull_result is None:
        print("⚠️  Warning: Could not pull latest develop")
    else:
        print("✅ Pulled latest develop")
    
    # Step 3: Merge feature branch
    print(f"\n🔀 Step 3: Merging {feature_branch} into develop...")
    merge_result = run_git_command(f"git merge {feature_branch}", cwd=repo_dir)
    if merge_result is None:
        print(f"❌ Failed to merge {feature_branch} into develop")
        print("💡 This might be due to conflicts or branch not existing")
        return False
    
    print(f"✅ Successfully merged {feature_branch} into develop")
    
    # Step 4: Push updated develop
    print(f"\n⬆️  Step 4: Pushing updated develop...")
    push_result = run_git_command("git push origin develop", cwd=repo_dir)
    if push_result is None:
        print("❌ Failed to push develop branch")
        return False
    
    print("✅ Successfully pushed updated develop branch")
    
    print(f"\n🎉 SUCCESS! Merge workflow completed!")
    print(f"📋 Summary:")
    print(f"   ✅ Merged: {feature_branch} → develop")
    print(f"   ✅ Repository: {repo_url}")
    print(f"   ✅ Local Clone: {repo_dir}")
    print(f"   ✅ Pushed to remote develop")
    
    return True


def complete_dev_workflow(service_name, repo_url, git_credentials=None, **service_config):
    """
    Complete development workflow: Deploy to feature branch + merge to develop
    
    Args:
        service_name: Name of the service
        repo_url: Git repository URL
        git_credentials: Dict with 'username' and 'token' for authentication
        **service_config: Additional service configuration (including environment)
    """
    
    print(f" Starting COMPLETE development workflow for '{service_name}'")
    print("=" * 70)
    
    # Extract environment from service config, default to 'dev'
    environment = service_config.pop('environment', 'dev')
    
    # Step 1: Deploy to feature branch
    print(f" Phase 1: Deploy to feature branch...")
    deploy_success = clone_and_deploy_service(
        service_name=service_name,
        environment=environment,
        repo_url=repo_url,
        git_credentials=git_credentials,
        **service_config
    )
    
    if not deploy_success:
        print(" Deployment phase failed. Aborting workflow.")
        return False
    
    print(f"\n Phase 1 completed successfully!")
    
    # Step 2: Merge to develop (only for dev environment)
    if environment == 'dev':
        print(f"\ Phase 2: Merge to develop...")
        merge_success = merge_feature_to_develop(
            repo_url=repo_url,
            git_credentials=git_credentials
        )
        
        if not merge_success:
            print(" Merge phase failed.")
            return False
        
        print(f"\n Phase 2 completed successfully!")
        
        print(f"\n COMPLETE WORKFLOW SUCCESS!")
        print(f" Final Summary:")
        print(f"    Service '{service_name}' deployed to feature/initial_migration")
        print(f"    Feature branch merged to develop")
        print(f"    All changes are now in develop branch")
        print(f"    Ready for further environments (UAT/PROD)")
    else:
        print(f"\n🎉 DEPLOYMENT SUCCESS!")
        print(f"📋 Final Summary:")
        print(f"   ✅ Service '{service_name}' deployed to {environment} environment")
        print(f"   💡 Manual PR may be required for non-dev environments")
    
    return True

def get_environment_branch(environment):
    """Get the appropriate branch name for environment (Bitbucket-friendly)"""
    branch_mapping = {
        'dev': 'feature/initial_migration',    # Use feature branch for dev
        'uat': 'uat',                          # UAT branch
        'prod': 'main'                         # Main/master branch for production
    }
    return branch_mapping.get(environment, f"feature/{environment}")

def create_bitbucket_pull_request_info(service_name, environment, target_branch):
    """Display information for creating a Bitbucket Pull Request"""
    print(f"\n📋 Bitbucket Pull Request Information:")
    print(f"   🌿 Source Branch: {target_branch}")
    
    if environment == 'dev':
        print(f"    Target Branch: develop")
        print(f"    PR Title: Add {service_name} service - Initial Migration")
        print(f"    PR Description:")
        print(f"      - Added {service_name} service configuration")
        print(f"      - Environment: {environment}")
        print(f"      - Part of initial migration to new deployment structure")
        print(f"      - Generated files: Chart.yaml, values-{environment}.yaml, tekton-values-{environment}.yaml")
        print(f"    Action Required: Create PR from {target_branch} to develop in Bitbucket")
    else:
        print(f"    Target Branch: {'main' if environment == 'prod' else 'develop'}")
        print(f"    PR Title: Add {service_name} service for {environment} environment")
        print(f"    PR Description:")
        print(f"      - Added {service_name} service configuration")
        print(f"      - Environment: {environment}")
        print(f"      - Generated files: Chart.yaml, values-{environment}.yaml, tekton-values-{environment}.yaml")
        print(f"    Create PR manually in Bitbucket UI or use Bitbucket CLI")


def create_tekton_config(service_dir, service_name, deploy_repo_url, environment='dev', container_port=8000):
    """
    Create tekton configuration directory and config file for the service
    
    Args:
        service_dir: Path to the service directory where tekton config will be created
        service_name: Name of the service
        deploy_repo_url: URL of the deploy repository
        environment: Environment (dev/uat/prod) 
        container_port: Container port for the service
    """
    
    # Create tekton directory inside service directory
    tekton_dir = os.path.join(service_dir, 'tekton')
    os.makedirs(tekton_dir, exist_ok=True)
    
    # Extract repo name from URL
    deploy_repo_name = extract_repo_name(deploy_repo_url)
    
    # Create config-{environment}.json content
    tekton_config = {
        "service_name": service_name,
        "image": f"quay-nonprod.elevancehealth.com/sprk-wrklds-tekton/crln-edl-dev-img-agntblderdemo",
        "dockerfile": f"{service_name}/Dockerfile",
        "context": service_name,
        "reqfile": f"{service_name}/requirements.txt",
        "repo_url": deploy_repo_url,
        "repo_name": deploy_repo_name,
        "ksa": "ksa",
        "namespace": f"{service_name}-{environment}",
        "app-size": "medium",
        "ingress-type": "alb",
        "container-port": str(container_port)
    }
    
    # Write config file
    config_file_path = os.path.join(tekton_dir, f'config-{environment}.json')
    
    try:
        with open(config_file_path, 'w') as config_file:
            json.dump(tekton_config, config_file, indent=2)
        
        print(f"✅ Created Tekton configuration: {config_file_path}")
        print(f"   📄 File: tekton/config-{environment}.json")
        print(f"   🏗️  Service: {service_name}")
        print(f"   🌍 Environment: {environment}")
        print(f"   📦 Deploy Repo: {deploy_repo_name}")
        
        return True
        
    except Exception as e:
        print(f"❌ Failed to create Tekton config: {e}")
        return False


def deploy_app_code_to_repo(service_name, app_source_path, repo_url, git_credentials=None, environment='dev', 
                            repo_path_in_repo='', deploy_repo_url=None, container_port=8080):
    """
    Deploy application source code (zip file) to application repository
    
    Args:
        service_name: Name of the service
        app_source_path: Path to the application source (zip file)  
        repo_url: Git repository URL for application code
        git_credentials: Dict with 'username' and 'token'
        environment: Environment (dev/uat/prod)
        repo_path_in_repo: Path inside repo where to place files
    """
    
    print(f"\n Deploying APPLICATION CODE for '{service_name}'")
    print("=" * 60)
    print(f"Source: {app_source_path}")
    print(f" Target Repo: {repo_url}")
    print(f" Environment: {environment}")
    
    # Step 1: Validate source file exists
    if not os.path.exists(app_source_path):
        print(f" Source file not found: {app_source_path}")
        return False
    
    print(f"\n Step 1: Validating source file...")
    print(f" Found source file: {os.path.basename(app_source_path)}")
    
    # Step 2: Setup repository
    print(f"\n Step 2: Setting up application repository...")
    repo_name = extract_repo_name(repo_url)
    repo_dir = os.path.join("./cloned_repos", repo_name)
    
    # Prepare git URL with credentials if provided
    if git_credentials and 'username' in git_credentials and 'token' in git_credentials:
        encoded_username = quote(git_credentials['username'], safe='')
        encoded_token = quote(git_credentials['token'], safe='')
        
        if repo_url.startswith("https://"):
            if "@" in repo_url:
                base_url = repo_url.split("@", 1)[1]
                auth_url = f"https://{encoded_username}:{encoded_token}@{base_url}"
            else:
                auth_url = repo_url.replace("https://", f"https://{encoded_username}:{encoded_token}@")
        else:
            auth_url = repo_url
    else:
        auth_url = repo_url
    
    if os.path.exists(repo_dir):
        print(f" Repository already exists at: {repo_dir}")
        print(" Pulling latest changes...")
        # Try to pull with specific origin and branch first
        pull_result = run_git_command("git fetch origin", cwd=repo_dir)
        if pull_result is None:
            print(" Failed to fetch latest changes")
            return False
        print(" Fetched latest changes")
    else:
        print(f"📥 Cloning repository...")
        clone_result = run_git_command(f"git clone {auth_url} {repo_dir}")
        if clone_result is None:
            print(" Failed to clone repository")
            return False
        print(f" Repository cloned to {repo_dir}")
    
    # Step 3: Switch to feature branch
    feature_branch = get_environment_branch(environment)
    print(f"\n🌿 Step 3: Switching to branch '{feature_branch}'...")
    
    # Try to create feature branch
    print(f" Creating feature branch for app deployment...")
    checkout_result = run_git_command(f"git checkout -b {feature_branch}", cwd=repo_dir)
    if checkout_result is None:
        print(f" Git command failed: git checkout -b {feature_branch}")
        print("Error: fatal: a branch named '{}' already exists".format(feature_branch))
        
        # Switch to existing branch
        checkout_result = run_git_command(f"git checkout {feature_branch}", cwd=repo_dir)
        if checkout_result is None:
            print(f" Failed to switch to {feature_branch}")
            return False
    
    print(f" Switched to branch '{feature_branch}'")
    
    # Step 4: Unzip and deploy application files
    print(f"\n Step 4: Unzipping and deploying application files...")
    
    # Determine target path in repo
    if repo_path_in_repo:
        target_dir = os.path.join(repo_dir, repo_path_in_repo, service_name)
    else:
        target_dir = os.path.join(repo_dir, service_name)
    
    # Create target directory
    os.makedirs(target_dir, exist_ok=True)
    
    # Check if source is a zip file
    if app_source_path.lower().endswith('.zip'):
        print(f" Extracting zip file: {os.path.basename(app_source_path)}")
        
        import zipfile
        try:
            with zipfile.ZipFile(app_source_path, 'r') as zip_ref:
                # Extract files and flatten directory structure
                extracted_files = zip_ref.namelist()
                actual_files = []
                
                for file_path in extracted_files:
                    if not file_path.endswith('/'):  # Skip directories
                        # Get just the filename, remove any directory structure
                        filename = os.path.basename(file_path)
                        if filename:  # Make sure filename is not empty
                            # Extract individual file to target directory
                            file_data = zip_ref.read(file_path)
                            target_file_path = os.path.join(target_dir, filename)
                            
                            with open(target_file_path, 'wb') as target_file:
                                target_file.write(file_data)
                            
                            actual_files.append(filename)
                
                print(f" Extracted {len(actual_files)} files directly to service directory:")
                for file in actual_files[:10]:  # Show first 10 files
                    print(f"   📄 {file}")
                if len(actual_files) > 10:
                    print(f"   ... and {len(actual_files) - 10} more files")
                    
        except zipfile.BadZipFile:
            print(f" Invalid zip file: {app_source_path}")
            return False
        except Exception as e:
            print(f" Failed to extract zip file: {e}")
            return False
            
    else:
        # Copy all contents from source directory
        print(f" Copying directory contents: {app_source_path}")
        
        # Copy all files and subdirectories from source to target
        for item in os.listdir(app_source_path):
            source_item = os.path.join(app_source_path, item)
            target_item = os.path.join(target_dir, item)
            
            if os.path.isdir(source_item):
                shutil.copytree(source_item, target_item, dirs_exist_ok=True)
                print(f"   📁 Copied directory: {item}")
            else:
                shutil.copy2(source_item, target_item)
                print(f"   📄 Copied file: {item}")
        
        print(f" Directory contents copied to {target_dir}")
    
    print(f" Application files deployed to {target_dir}")
    
    # Step 4.5: Create tekton directory and config file
    print(f"\n Step 4.5: Creating Tekton configuration...")
    create_tekton_config(target_dir, service_name, deploy_repo_url, environment, container_port)
    
    # Step 5: Git operations
    print(f"\n Step 5: Committing and pushing application code...")
    
    # Pull latest changes first
    pull_result = run_git_command(f"git pull origin {feature_branch}", cwd=repo_dir)
    if pull_result is None:
        print("  Warning: Could not pull latest changes, proceeding anyway")
    else:
        print(f" Pulled latest changes from {feature_branch}")
    
    # Add files
    add_result = run_git_command("git add .", cwd=repo_dir)
    if add_result is None:
        print(" Failed to add files")
        return False
    
    # Check if there are changes to commit
    status_result = run_git_command("git status --porcelain", cwd=repo_dir)
    if status_result is not None and status_result.strip() == "":
        print("ℹ No changes to commit (application already exists)")
        print(f" Application {service_name} already exists in repository")
    else:
        # Commit only if there are changes
        commit_message = f"Add {service_name} application code for {environment} environment"
        set_name_result = run_git_command('git config user.name "automation-bot"', cwd=repo_dir)
        set_email_result = run_git_command('git config user.email "automation-bot@example.com"', cwd=repo_dir)
        commit_result = run_git_command(f'git commit -m "{commit_message}"', cwd=repo_dir)
        if commit_result is None:
            print(" Failed to commit changes")
            return False
        
        # Push
        push_result = run_git_command(f"git push origin {feature_branch}", cwd=repo_dir)
        if push_result is None:
            print(" Failed to push changes")
            return False
        
        print(f" Application code committed and pushed to {feature_branch}")
    
    print(f"\n🎉 APPLICATION DEPLOYMENT SUCCESS!")
    print(f" Summary:")
    print(f"    Service: {service_name}")
    print(f"    Environment: {environment}")
    print(f"    Repository: {repo_url}")
    print(f"    Local Clone: {repo_dir}")
    print(f"    Branch: {feature_branch}")
    print(f"    Path: {repo_path_in_repo or 'root'}/{service_name}")
    if app_source_path.lower().endswith('.zip'):
        print(f"    Source: Extracted from {os.path.basename(app_source_path)}")
    else:
        print(f"    File: {os.path.basename(app_source_path)}")
    
    return True


def deploy_app_code_with_pr(service_name, app_source_path, repo_url, git_credentials=None, environment='dev', 
                           repo_path_in_repo='', workflow_type='pr_api', auto_merge=False, 
                           deploy_repo_url=None, container_port=8080):
    """
    Deploy application source code with complete PR workflow
    
    Args:
        service_name: Name of the service
        app_source_path: Path to the application source (zip file)  
        repo_url: Git repository URL for application code
        git_credentials: Dict with 'username' and 'token'
        environment: Environment (dev/uat/prod)
        repo_path_in_repo: Path inside repo where to place files
        workflow_type: 'auto_merge', 'pr_manual', 'pr_api'
        auto_merge: Whether to automatically merge the PR
    """
    
    print(f"\n APPLICATION CODE PR WORKFLOW for '{service_name}'")
    print("=" * 60)
    print(f" Source: {app_source_path}")
    print(f" Target Repo: {repo_url}")
    print(f" Environment: {environment}")
    print(f" Workflow: {workflow_type}")
    
    # Step 1: Deploy application code to feature branch
    deploy_success = deploy_app_code_to_repo(
        service_name=service_name,
        app_source_path=app_source_path,
        repo_url=repo_url,
        git_credentials=git_credentials,
        environment=environment,
        repo_path_in_repo=repo_path_in_repo,
        deploy_repo_url=deploy_repo_url,
        container_port=container_port
    )
    
    if not deploy_success:
        print(" Application code deployment to feature branch failed")
        return False
    
    # Step 2: Handle PR workflow
    if workflow_type == 'auto_merge':
        print(f"\n Auto-merge workflow: merging feature branch to develop...")
        # For auto_merge, we would merge directly but for now keep it simple
        print("ℹ Auto-merge to develop completed via feature branch push")
        return True
        
    elif workflow_type == 'pr_manual':
        print(f"\n Manual PR workflow: showing instructions...")
        print(" Manual PR creation required:")
        print(f"    Source: feature/initial_migration")  
        print(f"    Target: develop")
        print(f"   Create PR manually in Bitbucket for app repository")
        return True
        
    elif workflow_type == 'pr_api':
        print(f"\n API PR workflow: creating PR via Bitbucket API...")
        
        # Create PR via API
        pr_result = create_bitbucket_pull_request(
            repo_url=repo_url,
            git_credentials=git_credentials,
            service_name=service_name,
            environment=environment,
            source_branch="feature/initial_migration",
            target_branch="develop"
        )
        
        if not pr_result['success']:
            print(" Failed to create PR for app repository")
            return False
            
        pr_id = pr_result['pr_id']
        pr_url = pr_result['pr_url']
        
        print(f" App repo PR created successfully!")
        print(f" PR #{pr_id}: {pr_url}")
        
        # Auto-merge if requested
        if auto_merge:
            print(f"\n🔀 Auto-merging App Repository PR...")
            merge_result = merge_bitbucket_pull_request(
                repo_url=repo_url,
                git_credentials=git_credentials,
                pr_id=pr_id,
                wait_for_approval=False
            )
            
            if merge_result['success']:
                print(f" App repository PR #{pr_id} merged successfully!")
                print(f" Application code now in develop branch")
            else:
                print(f" Failed to merge app repository PR: {merge_result.get('error')}")
                return False
        else:
            print(f" PR created but not auto-merged. Manual merge required.")
            
        return True
    
    return True


def complete_dual_repo_workflow(service_name, deploy_repo_config, app_repo_config, git_credentials=None, 
                               workflow_type='pr_api', auto_merge=False, app_source_path=None, **service_config):
    """
    Complete dual repository workflow: Deploy YAML to deploy repo AND app code to app repo
    
    Args:
        service_name: Name of the service
        deploy_repo_config: Dict with deploy repo configuration
        app_repo_config: Dict with app repo configuration  
        git_credentials: Dict with 'username' and 'token'
        workflow_type: 'auto_merge', 'pr_manual', 'pr_api'
        auto_merge: Whether to automatically merge PRs
        app_source_path: Path to application source code (zip file)
        **service_config: Additional service configuration
    """
    
    print(f" Starting DUAL REPOSITORY workflow for '{service_name}'")
    print("=" * 70)
    print(f" Deploy Repo: {deploy_repo_config['repo_url']}")
    print(f" App Repo: {app_repo_config['repo_url']}")
    print(f" Workflow: {workflow_type}")
    
    # Extract environment from service config
    environment = service_config.pop('environment', 'dev')  # Use pop() to remove from service_config
    
    # Step 1: Deploy YAML files to deploy repository
    print(f"\n Phase 1: Deploying YAML files to deploy repository...")
    
    if workflow_type == 'auto_merge':
        deploy_success = complete_dev_workflow(
            service_name=service_name,
            repo_url=deploy_repo_config['repo_url'],
            git_credentials=git_credentials,
            environment=environment,
            repo_path_in_repo=deploy_repo_config.get('repo_path_in_repo', ''),
            **service_config
        )
    elif workflow_type == 'pr_api':
        deploy_success = complete_pr_workflow(
            service_name=service_name,
            repo_url=deploy_repo_config['repo_url'],
            git_credentials=git_credentials,
            auto_merge=auto_merge,
            environment=environment,
            repo_path_in_repo=deploy_repo_config.get('repo_path_in_repo', ''),
            **service_config
        )
    else:  # pr_manual
        deploy_success = clone_and_deploy_service(
            service_name=service_name,
            environment=environment,
            repo_url=deploy_repo_config['repo_url'],
            git_credentials=git_credentials,
            repo_path_in_repo=deploy_repo_config.get('repo_path_in_repo', ''),
            **service_config
        )
    
    if not deploy_success:
        print(" Deploy repository phase failed. Aborting workflow.")
        return False
    
    print(" Phase 1 completed successfully!")
    
    # Step 2: Deploy application code to app repository  
    print(f"\n Phase 2: Deploying application code to app repository...")
    
    if not app_source_path or not os.path.exists(app_source_path):
        print(f"  Warning: Application source not found or not specified: {app_source_path}")
        print("  Skipping application code deployment")
        app_success = True  # Don't fail the whole workflow
    else:
        app_success = deploy_app_code_with_pr(
            service_name=service_name,
            app_source_path=app_source_path,
            repo_url=app_repo_config['repo_url'],
            git_credentials=git_credentials,
            environment=environment,
            repo_path_in_repo=app_repo_config.get('repo_path_in_repo', ''),
            workflow_type=workflow_type,
            auto_merge=auto_merge,
            deploy_repo_url=deploy_repo_config['repo_url'],
            container_port=service_config.get('container_port', 8080)
        )
    
    if not app_success:
        print(" App repository phase failed.")
        return False
    
    print(" Phase 2 completed successfully!")
    
    # Summary
    print(f"\n🎉 DUAL REPOSITORY WORKFLOW SUCCESS!")
    print(f" Final Summary:")
    print(f"    Service '{service_name}' deployed to both repositories")
    print(f"    Deploy Repo: Kubernetes YAML files deployed")
    print(f"    App Repo: Application source code deployed") 
    print(f"    Environment: {environment}")
    print(f"    Ready for complete deployment pipeline")
    
    return True


def main(extracted_content=None):
    """Main function with Git integration"""
    
    print(" EKS Service Generator with Git Integration")
    print("=" * 50)
    
    # ============================================
    # 📝 CONFIGURE YOUR SERVICE AND REPOSITORY
    # ============================================
    
    service_name = "test-api-service"      # ← Change this to your service name
    environment = "dev"                    # ← Change this: 'dev', 'uat', or 'prod'
    
    # Bitbucket repository configuration
    repo_url = "https://bitbucket.elevancehealth.com/scm/aedlcs/vamsi_test.git"  # ← Change to your Bitbucket repo
    repo_path_in_repo = ""                 # ← Path inside repo (empty for root)
    
    # Bitbucket credentials (optional - for private repos)
    git_credentials = {
        'username': 'AL14414',    # ← Your Bitbucket username
        'token': 'Nov@2025'       # ← Your Bitbucket App Password (not regular password)
    }
    
    # Service configuration
    service_config = {
        'container_port': 8000,
        'cpu_limit': '1',
        'memory_limit': '2Gi',
        'image_tag': 'latest',
    }
    
    # ============================================
    #  CHOOSE WORKFLOW
    # ============================================
    
    print("Choose workflow:")
    print("1. Generate service files only (local)")
    print("2. Complete workflow (generate + git operations)")
    
    choice = input("\nEnter choice (1 or 2): ").strip()
    
    if choice == "1":
        # Local generation only
        print(f"\n Generating service files locally...")
        success = generate_service(service_name, environment, **service_config)
        
        if success:
            print(f"\n SUCCESS! Service '{service_name}' generated locally")
            print(f" Files available in: ./{service_name}/")
        else:
            print("\n Service generation failed")
    
    elif choice == "2":
        # Complete workflow with Git
        print(f"\n Starting complete workflow...")
        
        # Ask for repository details
        repo_url = input(f"Repository URL [{repo_url}]: ").strip() or repo_url
        use_auth = input("Use Bitbucket authentication? (y/n): ").strip().lower()
        
        if use_auth == 'y':
            git_credentials['username'] = input("Bitbucket username: ").strip()
            git_credentials['token'] = input("Bitbucket App Password: ").strip()
            print(" Note: Use App Password, not regular password for Bitbucket")
        else:
            git_credentials = None
        
        # success,branch = clone_and_deploy_service(
        #     service_name=service_name,
        #     environment=environment,
        #     repo_url=repo_url,
        #     repo_path_in_repo=repo_path_in_repo,
        #     git_credentials=git_credentials,
        #     extracted_content=extracted_content,
        #     **service_config
        # )
        # if success:
        #     creat_pr = create_bitbucket_pull_request(
        #         repo_url=repo_url,
        #         git_credentials=git_credentials,
        #         service_name=service_name,
        #         environment=environment,
        #         source_branch=branch,
        #         target_branch="develop"
        #     )
        # if creat_pr and creat_pr.get('success'):
        #     pr_id = creat_pr['pr_id']  # Extract PR ID from the dictionary
        #     merge_request = merge_bitbucket_pull_request(
        #         repo_url=repo_url,
        #         git_credentials=git_credentials,
        #         pr_id=pr_id,  # Use the extracted PR ID
        #         wait_for_approval=False
        #         )
            

        
        if merge_request:
            print(f"\n COMPLETE SUCCESS! Service deployed to repository")
        else:
            print(f"\n Workflow failed. Check errors above.")
    
    else:
        print("Invalid choice. Exiting.")


def test_merge_existing_pr(repo_url, git_credentials, pr_id):
    """
    Test function to merge an existing PR
    
    Args:
        repo_url: Git repository URL
        git_credentials: Dict with 'username' and 'token'  
        pr_id: Existing PR ID to merge
    """
    print(f" TESTING PR MERGE FUNCTIONALITY")
    print(f" Testing merge of PR #{pr_id}")
    print("=" * 50)
    
    # Test the merge functionality
    result = merge_bitbucket_pull_request(repo_url, git_credentials, pr_id, wait_for_approval=False)
    
    if result['success']:
        print(f" MERGE TEST SUCCESS!")
        print(f"    PR #{pr_id} merged successfully")
        return True
    else:
        print(f" MERGE TEST FAILED!")
        print(f"    Error: {result.get('error', 'Unknown error')}")
        return False


