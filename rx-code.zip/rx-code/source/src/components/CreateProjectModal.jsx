import { useState } from 'react';
import { X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';

const CI_TYPES = ['Clinical Criteria', 'Designated Network', 'Preventive Rx'];
const MARKETS = ['National', 'Northeast', 'Southeast', 'Midwest', 'Southwest', 'West'];

export default function CreateProjectModal({ onClose }) {
  const { addProject } = useApp();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    lob: 'Commercial',
    market: 'National',
    ciType: 'Clinical Criteria',
    comments: ''
  });

  function handle(e) {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }));
  }

  function submit(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    const id = addProject(form);
    onClose();
    navigate('/projects');
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg mx-4 overflow-hidden">
        {/* Header */}
        <div className="bg-brand-navy text-white px-6 py-4 flex items-center justify-between">
          <h2 className="font-bold text-base">Create New Project</h2>
          <button onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={submit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Project Name *</label>
              <input name="name" value={form.name} onChange={handle} required className="input" placeholder="Enter project name" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">LOB</label>
              <input name="lob" value={form.lob} onChange={handle} className="input" readOnly />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Market</label>
              <select name="market" value={form.market} onChange={handle} className="select">
                {MARKETS.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">CI Type *</label>
              <select name="ciType" value={form.ciType} onChange={handle} className="select">
                {CI_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Comments</label>
              <textarea name="comments" value={form.comments} onChange={handle} className="input" rows={3} placeholder="Optional notes..." />
            </div>
          </div>
          <div className="bg-brand-light rounded-lg p-3 text-xs text-brand-navy">
            <strong>Note:</strong> LOB is restricted to Commercial only. Projects cannot be deleted after creation.
          </div>
          <div className="flex gap-3 justify-end pt-2">
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
            <button type="submit" className="btn-primary">Create Project</button>
          </div>
        </form>
      </div>
    </div>
  );
}
