import { useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  ChevronDown, Bell, User, Settings, LogOut, Menu, X, ShieldCheck, Home,
  Network, Pill, FileSearch, MapPin, Clock
} from 'lucide-react';
import { useApp, can } from '../context/AppContext';

const SNAPSHOTS_BY_ROUTE = {
  '/workflow/designated-network': [
    { id: 'jul-2026', label: 'Jul 2026', date: 'Jul 1, 2026',  competitor: 'UHC' },
    { id: 'jun-2026', label: 'Jun 2026', date: 'Jun 1, 2026',  competitor: 'UHC' },
    { id: 'may-2026', label: 'May 2026', date: 'May 1, 2026',  competitor: 'Cigna' },
    { id: 'apr-2026', label: 'Apr 2026', date: 'Apr 1, 2026',  competitor: 'Cigna' },
    { id: 'mar-2026', label: 'Mar 2026', date: 'Mar 1, 2026',  competitor: 'UHC' },
    { id: 'feb-2026', label: 'Feb 2026', date: 'Feb 1, 2026',  competitor: 'UHC' },
  ],
  '/workflow/preventive-rx': [
    { id: 'jul-2026', label: 'Jul 2026', date: 'Jul 1, 2026',  competitor: 'ESI' },
    { id: 'jun-2026', label: 'Jun 2026', date: 'Jun 1, 2026',  competitor: 'CVS' },
    { id: 'may-2026', label: 'May 2026', date: 'May 1, 2026',  competitor: 'Optum RX' },
    { id: 'apr-2026', label: 'Apr 2026', date: 'Apr 1, 2026',  competitor: 'ESI' },
    { id: 'mar-2026', label: 'Mar 2026', date: 'Mar 1, 2026',  competitor: 'CVS' },
    { id: 'feb-2026', label: 'Feb 2026', date: 'Feb 1, 2026',  competitor: 'Optum RX' },
  ],
};


function SnapshotPanel({ route }) {
  const snapshots = SNAPSHOTS_BY_ROUTE[route];
  const navigate  = useNavigate();
  const location  = useLocation();
  const activeId  = new URLSearchParams(location.search).get('snapshot');
  const [open, setOpen] = useState(false);
  if (!snapshots) return null;
  const isByDrugActive = location.pathname === route && !activeId;
  return (
    <div className="ml-12 mr-3 mt-2 mb-1" style={{ borderLeft: '1px solid rgba(255,255,255,0.12)', paddingLeft: 10 }}>
      {route === '/workflow/clinical-criteria' && (
        <NavLink
          to={route}
          onClick={e => { e.preventDefault(); navigate({ pathname: route, search: '' }); }}
          className="flex items-center gap-2 py-1.5 px-2 rounded cursor-pointer transition-colors hover:bg-white/10 mb-0.5"
          style={{
            backgroundColor: isByDrugActive ? 'rgba(68,184,243,0.15)' : undefined,
            borderLeft: isByDrugActive ? '2px solid #44B8F3' : '2px solid transparent',
            marginLeft: -2,
            textDecoration: 'none',
          }}
        >
          <FileSearch size={10} style={{ color: isByDrugActive ? '#44B8F3' : 'rgba(255,255,255,0.6)' }} />
          <span style={{ fontSize: 11, fontWeight: 600, color: isByDrugActive ? '#44B8F3' : 'rgba(255,255,255,0.75)' }}>By Drugs</span>
        </NavLink>
      )}
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1 py-1 w-full group"
      >
        <Clock size={9} style={{ color: '#44B8F3' }} className="shrink-0" />
        <span style={{ color: '#44B8F3', fontSize: 9, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }} className="flex-1 text-left">
          Historical Snapshots
        </span>
        <ChevronDown
          size={10}
          style={{ color: '#44B8F3' }}
          className={`shrink-0 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
        />
      </button>
      {open && snapshots.map((s, idx) => {
        const isActive = activeId === s.id;
        const isCurrent = idx === 0;
        return (
          <div
            key={s.id}
            onClick={() => navigate(`${route}?snapshot=${s.id}`)}
            className="flex items-start gap-2 py-2 px-2 rounded cursor-pointer transition-colors hover:bg-white/10"
            style={{
              backgroundColor: isActive ? 'rgba(68,184,243,0.15)' : undefined,
              borderLeft: isActive ? '2px solid #44B8F3' : '2px solid transparent',
              marginLeft: -2,
            }}
          >
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span style={{ color: isActive ? '#44B8F3' : 'rgba(255,255,255,0.75)', fontSize: 11, fontWeight: isActive ? 700 : 600 }}>
                  {s.date}
                </span>
                {isCurrent && (
                  <span style={{ fontSize: 8, fontWeight: 700, letterSpacing: '0.06em', color: '#44B8F3', backgroundColor: 'rgba(68,184,243,0.18)', padding: '1px 5px', borderRadius: 3, textTransform: 'uppercase' }}>
                    Current
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}


const NAV_ITEMS = [
  {
    label: 'Home', icon: Home, to: '/', children: [
      { label: 'Designated Network',  icon: Network,     to: '/workflow/designated-network',  color: '#00BBBA' },
      { label: 'Preventive Rx',       icon: Pill,        to: '/workflow/preventive-rx',        color: '#E3725F' },
      { label: 'Clinical Criteria',    icon: FileSearch,  to: '/workflow/clinical-criteria',    color: '#2861BB' },
      { label: 'Site of Care',        icon: MapPin,      to: '/workflow/site-of-care',         color: '#7C3AED' },
    ]
  },
  { label: 'Administration', icon: ShieldCheck, to: '/admin', adminOnly: true },
];




function NavItem({ item, collapsed, currentUser }) {
  const location = useLocation();
  const isChildActive = item.children?.some(c => location.pathname.startsWith(c.to));
  const [open, setOpen] = useState(isChildActive);
  if (item.adminOnly && !can(currentUser, 'admin')) return null;

  if (item.children) {
    return (
      <div>
        <div className="flex items-center">
          <NavLink
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `flex-1 flex items-center gap-3 px-4 py-2.5 text-sm font-semibold rounded-lg transition-colors ${
                isActive || isChildActive ? 'bg-white/10 text-white' : 'text-brand-light hover:bg-white/10'
              }`
            }
          >
            <item.icon size={18} className="shrink-0" />
            {!collapsed && <span className="flex-1 text-left">{item.label}</span>}
          </NavLink>
          {!collapsed && (
            <button
              onClick={() => setOpen(o => !o)}
              className="px-2 py-2.5 text-brand-light/60 hover:text-white transition-colors"
            >
              <ChevronDown size={14} className={`transition-transform ${open || isChildActive ? 'rotate-180' : ''}`} />
            </button>
          )}
        </div>
        {!collapsed && (open || isChildActive) && (
          <div className="mt-1 space-y-0.5">
            {item.children.map(child => (
              <div key={child.to}>
                <NavLink
                  to={child.to}
                  className={({ isActive }) =>
                    `flex items-center gap-2.5 pl-10 pr-3 py-2 text-xs font-semibold rounded-lg transition-colors ${
                      isActive ? 'bg-white text-brand-navy' : 'text-brand-light/80 hover:bg-white/10 hover:text-white'
                    }`
                  }
                >
                  {child.label}
                </NavLink>
                {location.pathname.startsWith(child.to) && (
                  <SnapshotPanel route={child.to} />
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <NavLink
      to={item.to}
      end={item.to === '/'}
      className={({ isActive }) =>
        `flex items-center gap-3 px-4 py-2.5 text-sm font-semibold rounded-lg transition-colors ${
          isActive ? 'bg-white text-brand-navy' : 'text-brand-light hover:bg-white/10'
        }`
      }
    >
      <item.icon size={18} className="shrink-0" />
      {!collapsed && item.label}
    </NavLink>
  );
}

export default function Layout({ children, onSignOut }) {
  const [collapsed, setCollapsed] = useState(false);
  const { currentUser } = useApp();
  const navigate = useNavigate();

  return (
    <div className="flex w-full h-screen overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`flex flex-col bg-brand-navy transition-all duration-300 shrink-0 h-screen sticky top-0 ${
          collapsed ? 'w-16' : 'w-60'
        }`}
      >
        {/* Logo / App Name */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-white/10">
          <div className="w-8 h-8 rounded bg-brand-blue flex items-center justify-center shrink-0">
            <span className="text-brand-navy font-bold text-xs">Rx</span>
          </div>
          {!collapsed && (
            <div>
              <p className="text-brand-blue text-xs">Comp Intelligence</p>
            </div>
          )}
          <button
            onClick={() => setCollapsed(c => !c)}
            className="ml-auto text-white/60 hover:text-white"
          >
            {collapsed ? <Menu size={16} /> : <X size={16} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map(item => (
            <NavItem key={item.label} item={item} collapsed={collapsed} currentUser={currentUser} />
          ))}
        </nav>

        {/* User */}
        <div className="border-t border-white/10 px-4 py-3 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-brand-teal flex items-center justify-center shrink-0">
            <User size={14} className="text-white" />
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-semibold truncate">{currentUser.name}</p>
              <p className="text-brand-blue text-xs capitalize">{currentUser.role}</p>
            </div>
          )}
          <button
            onClick={onSignOut}
            title="Sign out"
            className="text-white/40 hover:text-white transition-colors shrink-0"
          >
            <LogOut size={15} />
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shrink-0">
          <div>
            <p className="text-xs text-gray-500">RX Competitive Intelligence</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative text-gray-500 hover:text-brand-navy">
              <Bell size={18} />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-brand-coral rounded-full text-white text-xs flex items-center justify-center">3</span>
            </button>
            {can(currentUser, 'admin') && (
              <button onClick={() => navigate('/admin')} className="text-gray-500 hover:text-brand-navy" title="Administration">
                <Settings size={18} />
              </button>
            )}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
