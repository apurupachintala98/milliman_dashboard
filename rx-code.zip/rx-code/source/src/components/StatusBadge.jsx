export default function StatusBadge({ status }) {
  const map = {
    'Open':        'badge-open',
    'In-Progress': 'badge-in-progress',
    'Review':    'badge-review',
    'Approved':    'badge-approved',
    'Cancelled':   'badge-cancelled',
    'Deferred':    'badge-deferred',
  };
  return <span className={map[status] || 'badge-open'}>{status}</span>;
}
