import { Globe, Database } from 'lucide-react';

export default function SourceBadge({ source }) {
  if (source === 'web') {
    return (
      <span className="inline-flex items-center gap-1 bg-yellow-100 text-yellow-800 text-xs px-2 py-0.5 rounded-full font-semibold">
        <Globe size={10} /> Web Search
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 bg-brand-tealPale text-teal-800 text-xs px-2 py-0.5 rounded-full font-semibold">
      <Database size={10} /> iDiscovery
    </span>
  );
}
