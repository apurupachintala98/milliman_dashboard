import { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Layout from './components/Layout';
import ToastContainer from './components/ToastContainer';
import SignIn from './pages/SignIn';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import ProjectDetail from './pages/ProjectDetail';
import CreateProject from './pages/CreateProject';
import Processing from './pages/Processing';
import GridReview from './pages/GridReview';
import Admin from './pages/Admin';
import ClinicalCriteriaWorkflow from './pages/ClinicalCriteriaWorkflow';
import DesignatedNetworkWorkflow from './pages/DesignatedNetworkWorkflow';
import PreventiveRxWorkflow from './pages/PreventiveRxWorkflow';
import SiteOfCareWorkflow from './pages/SiteOfCareWorkflow';

function App() {
  const [user, setUser] = useState(null);

  if (!user) {
    return <SignIn onSignIn={setUser} />;
  }

  return (
    <BrowserRouter>
      <AppProvider currentUser={user}>
        <Layout onSignOut={() => setUser(null)}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/projects/create" element={<CreateProject />} />
            <Route path="/projects/:id" element={<ProjectDetail />} />
            <Route path="/projects/:id/processing" element={<Processing />} />
            <Route path="/projects/:id/review" element={<GridReview />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/workflow/clinical-criteria" element={<ClinicalCriteriaWorkflow />} />
            <Route path="/workflow/designated-network" element={<DesignatedNetworkWorkflow />} />
            <Route path="/workflow/preventive-rx" element={<PreventiveRxWorkflow />} />
            <Route path="/workflow/site-of-care" element={<SiteOfCareWorkflow />} />
          </Routes>
        </Layout>
        <ToastContainer />
      </AppProvider>
    </BrowserRouter>
  );
}

export default App;
