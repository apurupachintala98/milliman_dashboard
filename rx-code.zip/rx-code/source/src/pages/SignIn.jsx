import { useState } from 'react';

const USERS = [
  { id: 'AH40101', name: 'Alana Coleman', role: 'editor' },
  { id: 'AH40102', name: 'Sara Colburn', role: 'read-only' },
  { id: 'AH40103', name: 'Tracy Thompson', role: 'editor' },
];

const FEATURES = [
  { icon: '⚡', label: 'AI-powered competitive intelligence' },
  { icon: '✓', label: 'Audit compliance & traceability' },
  { icon: '🔒', label: 'Role-based access control' },
];

export default function SignIn({ onSignIn }) {
  const [empId, setEmpId] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    setTimeout(() => {
      const user = USERS.find(u => u.id.toLowerCase() === empId.trim().toLowerCase());
      if (user) {
        onSignIn(user);
      } else {
        setError('Employee ID not found. Try AH40130, AH40131, or AH40132.');
        setLoading(false);
      }
    }, 900);
  }

  return (
    <div className="min-h-screen w-full flex flex-col" style={{ background: '#f0f2f5' }}>

      {/* Top nav bar */}
      <header className="w-full bg-brand-navy flex items-center px-8 py-3 gap-3 shrink-0">
        <div className="flex items-center gap-3">
          {/* Elevance Health chevron logo */}
          <svg width="28" height="20" viewBox="0 0 28 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 14L14 4L24 14" stroke="#44B8F3" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-white font-semibold tracking-wide" style={{ fontSize: 13.5 }}>Elevance Health</span>
        </div>
        <span className="text-white/30 text-xs">|</span>
        <span className="text-white/70 text-xs">RX Competitive Intelligence</span>
      </header>

      {/* Body */}
      <div className="flex-1 flex items-center justify-center px-8 py-16">
        <div className="w-full max-w-4xl flex items-center gap-20">

          {/* Left — branding & description */}
          <div className="flex-1 min-w-0">
            {/* Logo lockup */}
            <div className="flex items-center gap-2 mb-5">
              <svg width="30" height="22" viewBox="0 0 28 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 14L14 4L24 14" stroke="#44B8F3" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-brand-coral text-xs font-bold tracking-widest uppercase">Elevance Health</span>
            </div>

            {/* Headline */}
            <h1 className="text-brand-navy leading-tight mb-1" style={{ fontSize: 34, fontWeight: 300 }}>
              RX Competitive
            </h1>
            <h2 className="text-brand-navy font-bold mb-5" style={{ fontSize: 34 }}>
              Intelligence Platform
            </h2>

            {/* Description */}
            <p className="text-gray-500 text-sm leading-relaxed max-w-xs mb-7">
              AI-powered competitive analysis for Clinical Criteria, Designated Networks, and Preventive Rx — built for Carelon's Commercial business.
            </p>

            {/* Feature list */}
            <ul className="space-y-2.5 mb-10">
              {FEATURES.map(f => (
                <li key={f.label} className="flex items-center gap-2.5 text-sm text-gray-600">
                  <span className="text-base leading-none">{f.icon}</span>
                  {f.label}
                </li>
              ))}
            </ul>

            {/* Decorative chevrons */}
            <div className="flex items-center gap-1 opacity-20">
              {[...Array(5)].map((_, i) => (
                <svg key={i} width="20" height="28" viewBox="0 0 20 28" fill="none">
                  <path d="M4 2 L16 14 L4 26" stroke="#1A3673" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              ))}
            </div>
          </div>

          {/* Right — sign-in card */}
          <div className="w-80 shrink-0">
            <div className="bg-white rounded-xl shadow-lg px-8 py-8">
              <h3 className="text-brand-navy font-bold text-lg mb-1">Sign in</h3>
              <p className="text-gray-400 text-xs mb-6">Enter your Elevance Health Employee ID</p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1.5">Employee ID</label>
                  <input
                    className="input"
                    placeholder="E.G. AH40101"
                    value={empId}
                    onChange={e => { setEmpId(e.target.value); setError(''); }}
                    required
                    autoComplete="off"
                    autoFocus
                    style={{ borderColor: empId ? '#1A3673' : undefined }}
                  />
                </div>

                {error && (
                  <p className="text-xs text-brand-coral font-semibold">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded text-sm font-semibold text-white transition-colors flex items-center justify-center gap-2"
                  style={{ background: loading ? '#6A97DF' : '#2861BB' }}
                >
                  {loading && (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  )}
                  {loading ? 'Signing in...' : 'Sign in with SSO'}
                </button>
              </form>

              <div className="mt-6 text-center space-y-1">
                <p className="text-xs text-gray-400">Elevance Health SSO</p>
                <p className="text-xs text-gray-300">Protected by enterprise SSO. Contact IT for access issues.</p>
              </div>

              {/* Demo hint */}
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-400 mb-1.5 text-center">Demo IDs</p>
                <div className="flex gap-1 justify-center">
                  {USERS.map(u => (
                    <button
                      key={u.id}
                      onClick={() => { setEmpId(u.id); setError(''); }}
                      className="text-xs px-2 py-0.5 rounded border border-gray-200 text-gray-500 hover:border-brand-navy hover:text-brand-navy transition-colors"
                    >
                      {u.id} <span className="text-gray-300">·</span> <span className="text-gray-400">{u.id === 'AH40103' ? 'Admin' : u.role === 'editor' ? 'Editor' : 'Read Only'}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
