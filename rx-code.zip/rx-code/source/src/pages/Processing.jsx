import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CheckCircle, Loader2, Clock, XCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

const STEPS_BY_TYPE = {
  'Clinical Criteria': [
    { label: 'Sourcing Carelon clinical criteria policy', sub: 'Querying iDiscovery for internal policy document' },
    { label: 'Sourcing competitor policies', sub: 'Querying iDiscovery for UHC, Cigna, Aetna, Caremark — falling back to web search if needed' },
    { label: 'Normalizing drug terminology', sub: 'Aligning drug names, brand/generic variants, J-codes via NDC crosswalk' },
    { label: 'Extracting comparison criteria', sub: 'PA triggers, step therapy, duration limits, quantity limits, coverage eligibility' },
    { label: 'Classifying criteria', sub: 'Marking each cell as stricter (red), looser (green), or same vs Carelon' },
    { label: 'Generating AI recommendations', sub: 'Advisory strategy suggestions based on market patterns — clearly marked as AI-generated' },
    { label: 'Finalizing comparison grid', sub: 'Assembling structured artifact with source citations' },
  ],
  'Designated Network': [
    { label: 'Sourcing Carelon designated network drug list', sub: 'Querying iDiscovery for selected program' },
    { label: 'Sourcing competitor drug lists', sub: 'Querying iDiscovery — falling back to web search if unavailable' },
    { label: 'Normalizing drug codes', sub: 'Aligning HCPCS/J-codes, brand/generic names, biosimilar variants' },
    { label: 'Identifying coverage flags', sub: 'Common drugs, Carelon-only, competitor-only, outliers' },
    { label: 'Classifying mandatory vs voluntary', sub: 'Segmenting competitor programs by program type' },
    { label: 'Calculating market consensus', sub: 'Ranking outliers and identifying market gaps' },
    { label: 'Finalizing comparison grid', sub: 'Assembling structured artifact with source citations' },
  ],
  'Preventive Rx': [
    { label: 'Sourcing Carelon preventive drug list', sub: 'Querying iDiscovery for selected baseline list' },
    { label: 'Sourcing competitor preventive lists', sub: 'Querying iDiscovery across 7 competitors — web search fallback' },
    { label: 'Classifying list types', sub: 'Identifying HDHP/IRS vs ACA vs combined to prevent invalid comparisons' },
    { label: 'Normalizing disease state terminology', sub: 'Aligning condition names and drug category variations across competitors' },
    { label: 'Normalizing drug names', sub: 'Handling salt forms, strengths, formulations — flagging low-confidence matches' },
    { label: 'Generating comparison grid', sub: 'Organized by disease state → drug category → individual drugs' },
    { label: 'Finalizing with confidence scoring', sub: 'Flagging low-confidence matches for human review' },
  ],
};

export default function Processing() {
  const { id } = useParams();
  const { projects, updateProject, addToast } = useApp();
  const navigate = useNavigate();
  const project = projects.find(p => p.id === id);

  const steps = STEPS_BY_TYPE[project?.ciType] || STEPS_BY_TYPE['Clinical Criteria'];
  const [currentStep, setCurrentStep] = useState(0);
  const [done, setDone] = useState(false);
  const [cancelled, setCancelled] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (done || cancelled) return;
    const timer = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(timer);
  }, [done, cancelled]);

  useEffect(() => {
    if (cancelled || done) return;
    if (currentStep >= steps.length) {
      setDone(true);
      updateProject(id, {
        status: 'Review',
        _auditNote: `AI intelligence generated from iDiscovery/web search. Status changed to Review.`,
      });
      addToast('Intelligence generation complete. Project is ready for review.', 'success');
      setTimeout(() => navigate(`/projects/${id}/review`), 1500);
      return;
    }
    const delay = 700 + Math.random() * 600;
    const t = setTimeout(() => setCurrentStep(s => s + 1), delay);
    return () => clearTimeout(t);
  }, [currentStep, cancelled, done]);

  function handleCancel() {
    setCancelled(true);
    updateProject(id, { status: 'In-Progress', _auditNote: 'AI generation cancelled by user. Returned to In-Progress.' });
    addToast('Generation cancelled.', 'warning');
    navigate(`/projects/${id}`);
  }

  const progress = Math.round((currentStep / steps.length) * 100);
  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;

  if (!project) return <div className="text-center py-20 text-gray-400">Project not found.</div>;

  return (
    <div className="max-w-xl mx-auto py-8">
      <div className="card">
        {/* Header */}
        <div className="text-center mb-6">
          {done ? (
            <CheckCircle size={48} className="text-brand-teal mx-auto mb-3" />
          ) : cancelled ? (
            <XCircle size={48} className="text-brand-coral mx-auto mb-3" />
          ) : (
            <div className="w-12 h-12 border-4 border-brand-blue border-t-brand-navy rounded-full animate-spin mx-auto mb-3" />
          )}
          <h1 className="text-lg font-bold text-brand-navy">
            {done ? 'Analysis Complete!' : cancelled ? 'Generation Cancelled' : 'Generating Intelligence...'}
          </h1>
          <p className="text-sm text-gray-500 mt-1">{project.name}</p>
          {!done && !cancelled && (
            <p className="text-xs text-gray-400 mt-0.5">
              Elapsed: {mins > 0 ? `${mins}m ` : ''}{secs}s &nbsp;·&nbsp; Est. 3–5 minutes
            </p>
          )}
        </div>

        {/* Progress bar */}
        {!cancelled && (
          <div className="mb-6">
            <div className="flex justify-between text-xs text-gray-400 mb-1">
              <span>{done ? 'Done' : `Step ${Math.min(currentStep + 1, steps.length)} of ${steps.length}`}</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2">
              <div
                className="h-2 rounded-full transition-all duration-500"
                style={{ width: `${progress}%`, background: done ? '#00BBBA' : '#2861BB' }}
              />
            </div>
          </div>
        )}

        {/* Step list */}
        <div className="space-y-3">
          {steps.map((s, i) => {
            const state = i < currentStep ? 'done' : i === currentStep && !done ? 'active' : 'pending';
            return (
              <div key={i} className={`flex items-start gap-3 p-2.5 rounded-lg transition-all ${state === 'active' ? 'bg-brand-iceBlue' : ''}`}>
                <div className="shrink-0 mt-0.5">
                  {state === 'done'   && <CheckCircle size={16} className="text-brand-teal" />}
                  {state === 'active' && <Loader2 size={16} className="text-brand-blue animate-spin" />}
                  {state === 'pending'&& <Clock size={16} className="text-gray-300" />}
                </div>
                <div>
                  <p className={`text-sm font-semibold ${state === 'done' ? 'text-brand-teal' : state === 'active' ? 'text-brand-navy' : 'text-gray-400'}`}>
                    {s.label}
                  </p>
                  {state !== 'pending' && <p className="text-xs text-gray-400 mt-0.5">{s.sub}</p>}
                </div>
              </div>
            );
          })}
        </div>

        {/* Source info */}
        {!done && !cancelled && (
          <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
            <p className="text-xs text-gray-400">
              Primary: <span className="font-semibold text-brand-teal">iDiscovery</span> · Fallback: <span className="font-semibold text-yellow-600">Web Search</span>
            </p>
            <button onClick={handleCancel} className="text-xs text-gray-400 hover:text-brand-coral font-semibold transition-colors">
              Cancel
            </button>
          </div>
        )}

        {done && (
          <div className="mt-5 pt-4 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-400 mb-3">Redirecting to review screen...</p>
            <button onClick={() => navigate(`/projects/${id}/review`)} className="btn-primary text-sm">
              Open Review Grid →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
