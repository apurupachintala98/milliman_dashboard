import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search, Plus, Filter } from 'lucide-react';
import { useApp, can } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';

const STATUS_OPTS = ['All', 'Open', 'In-Progress', 'Review', 'Approved', 'Cancelled', 'Deferred'];
const CI_OPTS = ['All', 'Clinical Criteria', 'Designated Network', 'Preventive Rx'];

export default function Projects() {
  const { projects, currentUser } = useApp();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState(searchParams.get('status') || 'All');
  const [ciFilter, setCiFilter] = useState('All');

  const filtered = projects.filter(p => {
    const q = search.toLowerCase();
    const matchSearch = !q || [p.id, p.name, p.lob, p.market, p.createdBy].some(f =>
      f?.toLowerCase().includes(q)
    );
    const matchStatus = statusFilter === 'All' || p.status === statusFilter;
    const matchCi = ciFilter === 'All' || p.ciType === ciFilter;
    return matchSearch && matchStatus && matchCi;
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-brand-navy">Projects</h1>
          <p className="text-sm text-gray-500">{filtered.length} of {projects.length} projects</p>
        </div>
        {can(currentUser, 'create') && (
          <button onClick={() => navigate('/projects/create')} className="btn-primary flex items-center gap-2">
            <Plus size={16} /> New Project
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="card flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-48">
          <label className="block text-xs font-semibold text-gray-500 mb-1">Search</label>
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              className="input pl-8"
              placeholder="Search by ID, name, market, creator..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-500 mb-1">Status</label>
          <select className="select w-36" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            {STATUS_OPTS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-500 mb-1">CI Type</label>
          <select className="select w-44" value={ciFilter} onChange={e => setCiFilter(e.target.value)}>
            {CI_OPTS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr>
              {['Project ID', 'Name', 'CI Type', 'LOB', 'Market', 'Status', 'Created By', 'Updated', ''].map(h => (
                <th key={h} className="table-header">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={10} className="text-center py-12 text-gray-400 text-sm">
                  No projects match your filters.
                </td>
              </tr>
            ) : filtered.map(p => (
              <tr
                key={p.id}
                className="hover:bg-brand-light cursor-pointer transition-colors"
                onClick={() => navigate(`/projects/${p.id}`)}
              >
                <td className="table-cell font-mono text-xs text-brand-mid font-semibold">{p.id}</td>
                <td className="table-cell font-semibold text-brand-navy max-w-xs truncate">{p.name}</td>
                <td className="table-cell">
                  <span className="bg-brand-iceBlue text-brand-navy text-xs px-2 py-0.5 rounded font-semibold whitespace-nowrap">{p.ciType}</span>
                </td>
                <td className="table-cell text-xs">{p.lob}</td>
                <td className="table-cell text-xs">{p.market}</td>
                <td className="table-cell"><StatusBadge status={p.status} /></td>
                <td className="table-cell text-xs">{p.createdBy}</td>
                <td className="table-cell text-xs text-gray-400">{p.updatedDate}</td>
                <td className="table-cell">
                  <button
                    className="text-xs text-brand-mid font-semibold hover:underline"
                    onClick={e => { e.stopPropagation(); navigate(`/projects/${p.id}`); }}
                  >
                    Open
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
