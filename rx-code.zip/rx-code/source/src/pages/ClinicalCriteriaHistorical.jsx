import { useState, useMemo, useRef } from 'react';
import { Search, Download, ChevronUp, ChevronDown, CheckCircle, TrendingUp, TrendingDown, Minus, Info, Zap, Upload, FileText, X, FileSpreadsheet, Calendar, BarChart2 } from 'lucide-react';

const SNAPSHOTS = [
  { id: 'jun-2026', label: 'Jun 2026', date: 'Jun 1, 2026',  drug: 'Skyrizi', current: true  },
  { id: 'mar-2026', label: 'Mar 2026', date: 'Mar 1, 2026',  drug: 'Skyrizi', current: false },
  { id: 'dec-2025', label: 'Dec 2025', date: 'Dec 1, 2025',  drug: 'Skyrizi', current: false },
  { id: 'sep-2025', label: 'Sep 2025', date: 'Sep 1, 2025',  drug: 'Skyrizi', current: false },
];

const CATEGORIES = ['Coverage Eligibility','Step Therapy','Clinical Documentation','Provider Requirements','Continuation / Reauthorization','Dosing & Quantity Limits'];
const COMPETITORS = ['Excellus BCBS','CDPHP','UHC','Caremark'];
const VARIANCE = {
  stricter:      { label: 'Stricter',       bg: '#FFF0E8', border: '#FDBA74', text: '#C2410C' },
  lenient:       { label: 'More Lenient',   bg: '#FEFCE8', border: '#FDE047', text: '#A16207' },
  same:          { label: 'Same',           bg: '#F0FDF4', border: '#86EFAC', text: '#166534' },
  notComparable: { label: 'Not Comparable', bg: '#F9FAFB', border: '#E5E7EB', text: '#6B7280' },
};

const CRITERIA_HISTORY = [
  {
    criterion: 'Minimum Age Requirement', category: 'Coverage Eligibility', conditions: ['CD','PsA','Ps','UC'],
    snapshots: {
      'jun-2026': { elevance: '18+ for all indications', 'Excellus BCBS':{variance:'same',value:'18+'}, 'CDPHP':{variance:'lenient',value:'No age req.'}, 'UHC':{variance:'lenient',value:'No age req.'}, 'Caremark':{variance:'same',value:'18+'} },
      'mar-2026': { elevance: '18+ for all indications', 'Excellus BCBS':{variance:'same',value:'18+'}, 'CDPHP':{variance:'same',value:'18+'}, 'UHC':{variance:'lenient',value:'No age req.'}, 'Caremark':{variance:'same',value:'18+'} },
      'dec-2025': { elevance: '18+ for all indications', 'Excellus BCBS':{variance:'same',value:'18+'}, 'CDPHP':{variance:'same',value:'18+'}, 'UHC':{variance:'same',value:'18+'}, 'Caremark':{variance:'same',value:'18+'} },
      'sep-2025': { elevance: '18+ for all indications', 'Excellus BCBS':{variance:'same',value:'18+'}, 'CDPHP':{variance:'same',value:'18+'}, 'UHC':{variance:'same',value:'18+'}, 'Caremark':{variance:'same',value:'18+'} },
    },
  },
  {
    criterion: 'Disease Severity Definition', category: 'Coverage Eligibility', conditions: ['CD','PsA','Ps','UC'],
    snapshots: {
      'jun-2026': { elevance: 'Mod-severe; Ps ≥3% BSA or sensitive areas', 'Excellus BCBS':{variance:'stricter',value:'>10% BSA or <10% sensitive'}, 'CDPHP':{variance:'lenient',value:'"Active" PsA'}, 'UHC':{variance:'stricter',value:'≥10% BSA'}, 'Caremark':{variance:'lenient',value:'Just dx of CD'} },
      'mar-2026': { elevance: 'Mod-severe; Ps ≥3% BSA or sensitive areas', 'Excellus BCBS':{variance:'same',value:'Mod-severe'}, 'CDPHP':{variance:'same',value:'Mod-severe'}, 'UHC':{variance:'stricter',value:'≥10% BSA'}, 'Caremark':{variance:'same',value:'Mod-severe'} },
      'dec-2025': { elevance: 'Mod-severe; Ps ≥3% BSA or sensitive areas', 'Excellus BCBS':{variance:'same',value:'Mod-severe'}, 'CDPHP':{variance:'same',value:'Mod-severe'}, 'UHC':{variance:'same',value:'Mod-severe'}, 'Caremark':{variance:'same',value:'Mod-severe'} },
      'sep-2025': { elevance: 'Mod-severe; Ps ≥3% BSA or sensitive areas', 'Excellus BCBS':{variance:'same',value:'Mod-severe'}, 'CDPHP':{variance:'same',value:'Mod-severe'}, 'UHC':{variance:'same',value:'Mod-severe'}, 'Caremark':{variance:'same',value:'Mod-severe'} },
    },
  },
  {
    criterion: 'Required Prior Drug Trials', category: 'Step Therapy', conditions: ['CD','PsA','Ps','UC'],
    snapshots: {
      'jun-2026': { elevance: 'CD: T/F azathioprine/6-MP/MTX. PsA: T/F DMARDs. Ps: T/F phototherapy or systemic', 'Excellus BCBS':{variance:'same',value:'T/F phototherapy x3mo'}, 'CDPHP':{variance:'lenient',value:'Prev TIM or Skyrizi hx'}, 'UHC':{variance:'lenient',value:'No drug T/F req.'}, 'Caremark':{variance:'stricter',value:'T/F TWO systemic tx x3mo'} },
      'mar-2026': { elevance: 'CD: T/F azathioprine/6-MP/MTX. PsA: T/F DMARDs. Ps: T/F phototherapy or systemic', 'Excellus BCBS':{variance:'same',value:'T/F phototherapy x3mo'}, 'CDPHP':{variance:'same',value:'T/F MTX x3mo'}, 'UHC':{variance:'same',value:'T/F phototherapy x3mo'}, 'Caremark':{variance:'same',value:'T/F ONE systemic x3mo'} },
      'dec-2025': { elevance: 'CD: T/F azathioprine/6-MP/MTX', 'Excellus BCBS':{variance:'same',value:'T/F phototherapy x3mo'}, 'CDPHP':{variance:'same',value:'T/F MTX x3mo'}, 'UHC':{variance:'same',value:'T/F phototherapy x3mo'}, 'Caremark':{variance:'same',value:'T/F ONE systemic x3mo'} },
      'sep-2025': { elevance: 'CD: T/F azathioprine/6-MP/MTX', 'Excellus BCBS':{variance:'same',value:'T/F phototherapy x3mo'}, 'CDPHP':{variance:'lenient',value:'Not required'}, 'UHC':{variance:'lenient',value:'Not required'}, 'Caremark':{variance:'same',value:'T/F ONE systemic x3mo'} },
    },
  },
  {
    criterion: 'Required Prescriber Specialty', category: 'Provider Requirements', conditions: ['CD','PsA','Ps','UC'],
    snapshots: {
      'jun-2026': { elevance: 'Not required', 'Excellus BCBS':{variance:'stricter',value:'GI (CD/UC); Derm/Rheum (Ps/PsA)'}, 'CDPHP':{variance:'stricter',value:'GI (CD/UC); Derm (Ps/PsA)'}, 'UHC':{variance:'stricter',value:'GI (CD/UC); Derm (Ps/PsA)'}, 'Caremark':{variance:'same',value:'Not required'} },
      'mar-2026': { elevance: 'Not required', 'Excellus BCBS':{variance:'stricter',value:'GI (CD/UC); Derm/Rheum (Ps/PsA)'}, 'CDPHP':{variance:'stricter',value:'GI (CD/UC)'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'same',value:'Not required'} },
      'dec-2025': { elevance: 'Not required', 'Excellus BCBS':{variance:'stricter',value:'GI (CD/UC)'}, 'CDPHP':{variance:'same',value:'Not required'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'same',value:'Not required'} },
      'sep-2025': { elevance: 'Not required', 'Excellus BCBS':{variance:'same',value:'Not required'}, 'CDPHP':{variance:'same',value:'Not required'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'same',value:'Not required'} },
    },
  },
  {
    criterion: 'Initial Authorization Duration', category: 'Dosing & Quantity Limits', conditions: ['CD','PsA','Ps','UC'],
    snapshots: {
      'jun-2026': { elevance: '12 months', 'Excellus BCBS':{variance:'notComparable',value:'N/A'}, 'CDPHP':{variance:'same',value:'12 months'}, 'UHC':{variance:'same',value:'12 months'}, 'Caremark':{variance:'stricter',value:'6 months'} },
      'mar-2026': { elevance: '12 months', 'Excellus BCBS':{variance:'notComparable',value:'N/A'}, 'CDPHP':{variance:'same',value:'12 months'}, 'UHC':{variance:'same',value:'12 months'}, 'Caremark':{variance:'same',value:'12 months'} },
      'dec-2025': { elevance: '12 months', 'Excellus BCBS':{variance:'notComparable',value:'N/A'}, 'CDPHP':{variance:'same',value:'12 months'}, 'UHC':{variance:'same',value:'12 months'}, 'Caremark':{variance:'same',value:'12 months'} },
      'sep-2025': { elevance: '12 months', 'Excellus BCBS':{variance:'notComparable',value:'N/A'}, 'CDPHP':{variance:'same',value:'12 months'}, 'UHC':{variance:'same',value:'12 months'}, 'Caremark':{variance:'same',value:'12 months'} },
    },
  },
  {
    criterion: 'Adherence Verification at Renewal', category: 'Continuation / Reauthorization', conditions: ['CD','PsA','Ps','UC'],
    snapshots: {
      'jun-2026': { elevance: 'Not required', 'Excellus BCBS':{variance:'same',value:'Not required'}, 'CDPHP':{variance:'same',value:'Not required'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'stricter',value:'≥85% adherence verified'} },
      'mar-2026': { elevance: 'Not required', 'Excellus BCBS':{variance:'same',value:'Not required'}, 'CDPHP':{variance:'same',value:'Not required'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'same',value:'Not required'} },
      'dec-2025': { elevance: 'Not required', 'Excellus BCBS':{variance:'same',value:'Not required'}, 'CDPHP':{variance:'same',value:'Not required'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'same',value:'Not required'} },
      'sep-2025': { elevance: 'Not required', 'Excellus BCBS':{variance:'same',value:'Not required'}, 'CDPHP':{variance:'same',value:'Not required'}, 'UHC':{variance:'same',value:'Not required'}, 'Caremark':{variance:'same',value:'Not required'} },
    },
  },
];

function VChip({ variance }) {
  const v = VARIANCE[variance] || VARIANCE.notComparable;
  return (
    <span className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap"
      style={{ backgroundColor: v.bg, color: v.text }}>
      {variance === 'stricter'      && <TrendingUp size={8}/>}
      {variance === 'lenient'       && <TrendingDown size={8}/>}
      {variance === 'same'          && <Minus size={8}/>}
      {variance === 'notComparable' && <Info size={8}/>}
      {v.label}
    </span>
  );
}

export default function ClinicalCriteriaHistorical() {
  const [activeSnap, setActiveSnap]     = useState('jun-2026');
  const [compareSnap, setCompareSnap]   = useState('mar-2026');
  const [showCompare, setShowCompare]   = useState(false);
  const [search, setSearch]             = useState('');
  const [catFilter, setCatFilter]       = useState('all');
  const [varFilter, setVarFilter]       = useState('all');
  const [sortCol, setSortCol]           = useState('criterion');
  const [sortDir, setSortDir]           = useState('asc');
  const [generating, setGenerating]     = useState(false);
  const [generated, setGenerated]       = useState(true);
  const [reportStatus, setReportStatus] = useState('in-progress');
  const [uploadedFile, setUploadedFile] = useState(null);
  const [exportOpen, setExportOpen]     = useState(false);
  const fileInputRef = useRef(null);
  const exportRef    = useRef(null);

  function handleGenerate() {
    setGenerating(true); setGenerated(false); setReportStatus('in-progress');
    setTimeout(() => { setGenerating(false); setGenerated(true); setReportStatus('in-review'); }, 2500);
  }
  function handleFileUpload(e) {
    const f = e.target.files[0];
    if (f) setUploadedFile(f);
    e.target.value = '';
  }
  function toggleSort(col) {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  }

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let rows = CRITERIA_HISTORY.filter(r => {
      if (catFilter !== 'all' && r.category !== catFilter) return false;
      if (q && !r.criterion.toLowerCase().includes(q) && !r.category.toLowerCase().includes(q)) return false;
      if (varFilter !== 'all') {
        const snap = r.snapshots[activeSnap];
        if (!COMPETITORS.some(c => snap?.[c]?.variance === varFilter)) return false;
      }
      return true;
    });
    return [...rows].sort((a, b) => {
      const av = a[sortCol] || ''; const bv = b[sortCol] || '';
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  }, [search, catFilter, varFilter, activeSnap, sortCol, sortDir]);

  const changedRows = useMemo(() => {
    if (!showCompare) return [];
    return CRITERIA_HISTORY.filter(row => {
      return COMPETITORS.some(c => {
        const a = row.snapshots[activeSnap]?.[c];
        const b = row.snapshots[compareSnap]?.[c];
        return a && b && a.variance !== b.variance;
      });
    });
  }, [showCompare, activeSnap, compareSnap]);

  const kpis = useMemo(() => {
    const snap = activeSnap;
    let stricter = 0, lenient = 0, same = 0, nc = 0;
    CRITERIA_HISTORY.forEach(row => {
      COMPETITORS.forEach(c => {
        const v = row.snapshots[snap]?.[c]?.variance;
        if (v === 'stricter') stricter++;
        else if (v === 'lenient') lenient++;
        else if (v === 'same') same++;
        else nc++;
      });
    });
    return [
      { label: 'Criteria Tracked', value: CRITERIA_HISTORY.length, color: 'text-brand-navy',  bg: 'bg-brand-light' },
      { label: 'Stricter',         value: stricter,                 color: 'text-orange-700',  bg: 'bg-orange-50' },
      { label: 'More Lenient',     value: lenient,                  color: 'text-yellow-700',  bg: 'bg-yellow-50' },
      { label: 'Same',             value: same,                     color: 'text-emerald-700', bg: 'bg-emerald-50' },
      { label: 'Changes Detected', value: changedRows.length,       color: 'text-purple-700',  bg: 'bg-purple-50' },
    ];
  }, [activeSnap, changedRows]);

  return (
    <div className="space-y-5">

      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Clinical Criteria</p>
          <h1 className="text-2xl font-bold text-brand-navy">Historical Data</h1>
          <p className="text-xs text-gray-400 mt-1">Track criteria changes across snapshot periods · Skyrizi (risankizumab) · Elevance as baseline</p>
        </div>
        <div className="relative" ref={exportRef}>
          <button
            onClick={() => reportStatus === 'approved' && setExportOpen(o => !o)}
            disabled={reportStatus !== 'approved'}
            className={`btn-secondary flex items-center gap-2 text-xs transition-all ${reportStatus !== 'approved' ? 'opacity-40 cursor-not-allowed' : ''}`}>
            <Download size={14}/> Export <ChevronDown size={12} className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`}/>
          </button>
          {exportOpen && (
            <div className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
              {[
                { label: 'PowerPoint (.pptx)', icon: <FileText size={13} className="text-orange-500"/> },
                { label: 'PDF (.pdf)',          icon: <FileText size={13} className="text-red-500"/> },
                { label: 'Excel (.xlsx)',       icon: <FileSpreadsheet size={13} className="text-emerald-600"/> },
              ].map(opt => (
                <button key={opt.label} onClick={() => setExportOpen(false)}
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                  {opt.icon} {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Action bar */}
      <div className="card py-3 px-4">
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={handleGenerate} disabled={generating}
            className={`btn-primary flex items-center gap-2 px-5 py-2 text-sm font-semibold ${generating ? 'opacity-70 cursor-not-allowed' : ''}`}>
            <Zap size={15}/> {generating ? 'Generating…' : 'Generate Intelligence'}
          </button>
          <div className="h-6 w-px bg-gray-200"/>
          <input ref={fileInputRef} type="file" accept=".pdf,.xlsx,.xls,.csv,.docx" className="hidden" onChange={handleFileUpload}/>
          {uploadedFile ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
              <CheckCircle size={13} className="text-emerald-600 shrink-0"/>
              <span className="font-semibold text-emerald-800 max-w-[180px] truncate">{uploadedFile.name}</span>
              <button onClick={() => setUploadedFile(null)} className="ml-1 text-gray-400 hover:text-red-500"><X size={12}/></button>
            </div>
          ) : (
            <button onClick={() => fileInputRef.current?.click()} className="btn-secondary flex items-center gap-1.5 text-xs">
              <Upload size={13}/> Upload Criteria File
            </button>
          )}
          <div className="h-6 w-px bg-gray-200"/>
          {/* Status pipeline */}
          <div className="flex items-center gap-1.5">
            {[
              { key:'in-progress', label:'In Progress', activeColor:'#D97706', activeBg:'#FEF3C7', activeBorder:'#FCD34D', dot:'bg-amber-500' },
              { key:'in-review',   label:'In Review',   activeColor:'#1D4ED8', activeBg:'#EFF6FF', activeBorder:'#93C5FD', dot:'bg-blue-500'  },
              { key:'approved',    label:'Approved',    activeColor:'#059669', activeBg:'#ECFDF5', activeBorder:'#6EE7B7', dot:'bg-emerald-500'},
            ].map((step, idx) => {
              const steps = ['in-progress','in-review','approved'];
              const currentIdx = steps.indexOf(reportStatus);
              const stepIdx    = steps.indexOf(step.key);
              const isActive   = reportStatus === step.key;
              const isDone     = stepIdx < currentIdx;
              return (
                <div key={step.key} className="flex items-center gap-1.5">
                  {idx > 0 && <div className={`w-5 h-px ${isDone || isActive ? 'bg-gray-400' : 'bg-gray-200'}`}/>}
                  <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                    isActive ? 'border-current' : isDone ? 'bg-gray-50 text-gray-400 border-gray-200' : 'bg-white text-gray-300 border-gray-100'
                  }`} style={isActive ? { backgroundColor:step.activeBg, color:step.activeColor, borderColor:step.activeBorder } : {}}>
                    {isActive && step.key !== 'approved' && <span className={`w-1.5 h-1.5 rounded-full ${step.dot} ${step.key === 'in-progress' ? 'animate-pulse' : ''}`}/>}
                    {((isActive && step.key === 'approved') || isDone) ? <CheckCircle size={10} className={isDone ? 'text-gray-400' : 'text-emerald-500'}/> : null}
                    {step.label}
                  </span>
                </div>
              );
            })}
            {reportStatus === 'in-review' && (
              <button onClick={() => setReportStatus('approved')}
                className="ml-1 flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 transition-colors">
                <CheckCircle size={11}/> Approve
              </button>
            )}
            {reportStatus === 'approved' && (
              <button onClick={() => setReportStatus('in-review')} className="ml-1 text-[10px] text-gray-400 hover:text-red-400 underline">Revoke</button>
            )}
          </div>
        </div>
      </div>

      {/* Generating spinner */}
      {generating && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0"/>
          <div className="flex-1">
            <p className="text-brand-navy text-sm font-semibold">Generating historical intelligence…</p>
            <div className="flex gap-4 mt-1.5 text-xs text-blue-600">
              {['Loading snapshots','Comparing periods','Detecting changes','Generating insights'].map((s,i) => (
                <span key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay:`${i*200}ms`}}/>{s}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {!generated && !generating ? (
        <div className="card flex flex-col items-center justify-center py-16 gap-4 border-2 border-dashed border-gray-200 bg-gray-50">
          <Zap size={36} className="text-gray-300"/>
          <div className="text-center">
            <p className="text-sm font-semibold text-gray-500">Results will appear here</p>
            <p className="text-xs text-gray-400 mt-1">Click <strong>Generate Intelligence</strong> to begin</p>
          </div>
        </div>
      ) : generated && (
        <div className="space-y-5">

          {/* KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {kpis.map(k => (
              <div key={k.label} className={`rounded-xl p-4 ${k.bg}`}>
                <p className={`text-2xl font-bold ${k.color}`}>{k.value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{k.label}</p>
              </div>
            ))}
          </div>

          {/* Snapshot selector + compare toggle */}
          <div className="card py-3 px-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Calendar size={13} className="text-brand-navy"/>
                <span className="text-xs font-semibold text-gray-600">Active Snapshot:</span>
                <div className="flex gap-1">
                  {SNAPSHOTS.map(s => (
                    <button key={s.id} onClick={() => setActiveSnap(s.id)}
                      className={`text-xs font-bold px-3 py-1 rounded-full border transition-all ${
                        activeSnap === s.id ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-navy'
                      }`}>
                      {s.label}{s.current ? ' ●' : ''}
                    </button>
                  ))}
                </div>
              </div>
              <div className="h-5 w-px bg-gray-200"/>
              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-gray-600">
                <input type="checkbox" checked={showCompare} onChange={e => setShowCompare(e.target.checked)} className="accent-brand-navy"/>
                Compare with:
              </label>
              {showCompare && (
                <div className="flex gap-1">
                  {SNAPSHOTS.filter(s => s.id !== activeSnap).map(s => (
                    <button key={s.id} onClick={() => setCompareSnap(s.id)}
                      className={`text-xs font-bold px-3 py-1 rounded-full border transition-all ${
                        compareSnap === s.id ? 'bg-purple-600 text-white border-purple-600' : 'bg-white text-gray-600 border-gray-200 hover:border-purple-400'
                      }`}>
                      {s.label}
                    </button>
                  ))}
                </div>
              )}
              {showCompare && (
                <span className="ml-auto text-xs font-bold px-2.5 py-1 rounded-full"
                  style={{ backgroundColor: changedRows.length > 0 ? '#FFF0E8' : '#F0FDF4', color: changedRows.length > 0 ? '#C2410C' : '#166534' }}>
                  {changedRows.length} change{changedRows.length !== 1 ? 's' : ''} detected
                </span>
              )}
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="text-gray-400 font-semibold">Category:</span>
            {['all', ...CATEGORIES].map(c => (
              <button key={c} onClick={() => setCatFilter(c)}
                className={`px-3 py-1 rounded-full font-semibold border transition-all ${
                  catFilter === c ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-500 border-gray-200 hover:border-gray-400'
                }`}>{c === 'all' ? 'All Categories' : c}</button>
            ))}
            <div className="h-5 w-px bg-gray-200 ml-1"/>
            <span className="text-gray-400 font-semibold">Variance:</span>
            {[{id:'all',label:'All'},{id:'stricter',label:'Stricter'},{id:'lenient',label:'Lenient'},{id:'same',label:'Same'}].map(f => (
              <button key={f.id} onClick={() => setVarFilter(f.id)}
                className={`px-3 py-1 rounded-full font-semibold border transition-all ${
                  varFilter === f.id ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-500 border-gray-200 hover:border-gray-400'
                }`}>{f.label}</button>
            ))}
            <div className="ml-auto relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"/>
              <input className="input pl-8 text-xs py-1.5 w-44" placeholder="Search criteria…"
                value={search} onChange={e => setSearch(e.target.value)}/>
            </div>
            {search && <button onClick={() => setSearch('')} className="text-gray-400 hover:text-red-500"><X size={12}/></button>}
          </div>

          {/* Main table */}
          <div className="card p-0 overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-100 bg-gray-50 flex items-center justify-between flex-wrap gap-2">
              <div>
                <h2 className="font-bold text-brand-navy text-sm">Criteria Comparison — {SNAPSHOTS.find(s=>s.id===activeSnap)?.label}</h2>
                {showCompare && <p className="text-[10px] text-gray-400 mt-0.5">Purple highlights = changed vs {SNAPSHOTS.find(s=>s.id===compareSnap)?.label}</p>}
              </div>
              <span className="text-xs text-gray-400">{filtered.length} criteria</span>
            </div>
            <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 520 }}>
              <table className="text-left" style={{ borderCollapse:'separate', borderSpacing:0, minWidth:860, width:'100%' }}>
                <thead className="sticky top-0 z-20">
                  <tr>
                    <th className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide bg-gray-50 border-b border-gray-200 sticky left-0 z-30 cursor-pointer select-none"
                      style={{ minWidth:220 }} onClick={() => toggleSort('criterion')}>
                      <div className="flex items-center gap-1">Criterion
                        {sortCol==='criterion' ? (sortDir==='asc' ? <ChevronUp size={12} className="text-brand-navy"/> : <ChevronDown size={12} className="text-brand-navy"/>) : <ChevronUp size={12} className="text-gray-300"/>}
                      </div>
                    </th>
                    <th className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide bg-gray-50 border-b border-gray-200 cursor-pointer select-none"
                      style={{ minWidth:160 }} onClick={() => toggleSort('category')}>
                      <div className="flex items-center gap-1">Category
                        {sortCol==='category' ? (sortDir==='asc' ? <ChevronUp size={12} className="text-brand-navy"/> : <ChevronDown size={12} className="text-brand-navy"/>) : <ChevronUp size={12} className="text-gray-300"/>}
                      </div>
                    </th>
                    <th className="px-4 py-3 text-xs font-bold uppercase tracking-wide border-b border-gray-200 text-center"
                      style={{ minWidth:180, backgroundColor:'#E8F0FF', color:'#1A3673' }}>
                      <div className="flex items-center justify-center gap-1.5">
                        Elevance <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-brand-navy text-white">BASELINE</span>
                      </div>
                    </th>
                    {COMPETITORS.map(c => (
                      <th key={c} className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide bg-gray-50 border-b border-gray-200 text-center" style={{ minWidth:160 }}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((row, ri) => {
                    const snap    = row.snapshots[activeSnap];
                    const snapB   = showCompare ? row.snapshots[compareSnap] : null;
                    const hasChange = showCompare && COMPETITORS.some(c => snap?.[c]?.variance !== snapB?.[c]?.variance);
                    return (
                      <tr key={ri} className={`border-b border-gray-100 transition-colors ${hasChange ? 'bg-purple-50/40' : 'hover:bg-gray-50/50'}`}>
                        <td className="px-4 py-3 align-top sticky left-0 bg-white z-10 border-b border-gray-100" style={{ minWidth:220 }}>
                          <p className="text-xs font-bold text-gray-800 leading-snug">{row.criterion}</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {row.conditions.map(c => (
                              <span key={c} className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gray-100 text-gray-500">{c}</span>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3 align-top border-b border-gray-100">
                          <span className="text-[10px] font-semibold text-gray-500">{row.category}</span>
                        </td>
                        <td className="px-3 py-3 align-top border-b border-gray-100 text-center" style={{ backgroundColor:'#F0F6FF' }}>
                          <p className="text-xs font-semibold text-brand-navy leading-snug">{snap?.elevance || '—'}</p>
                        </td>
                        {COMPETITORS.map(comp => {
                          const cell  = snap?.[comp];
                          const cellB = snapB?.[comp];
                          const changed = showCompare && cell?.variance !== cellB?.variance;
                          const v = VARIANCE[cell?.variance] || VARIANCE.notComparable;
                          return (
                            <td key={comp} className="px-3 py-3 align-top border-b border-gray-100">
                              {cell ? (
                                <div>
                                  <div className="rounded-lg px-2 py-1.5 text-xs leading-snug" style={{ backgroundColor: v.bg, borderLeft:`3px solid ${v.border}` }}>
                                    <VChip variance={cell.variance}/>
                                    <p className="text-[10px] text-gray-700 mt-1">{cell.value}</p>
                                  </div>
                                  {changed && cellB && (
                                    <div className="mt-1 flex items-center gap-1 text-[9px] text-purple-600 font-semibold">
                                      <span className="text-gray-400">was:</span>
                                      <VChip variance={cellB.variance}/>
                                    </div>
                                  )}
                                </div>
                              ) : <span className="text-gray-300 text-xs">—</span>}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                  {filtered.length === 0 && (
                    <tr><td colSpan={3 + COMPETITORS.length} className="py-12 text-center text-gray-400 text-sm">No criteria match current filters.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Timeline strip */}
          <div className="card py-3 px-5">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-3">Snapshot Timeline</p>
            <div className="flex items-center">
              {SNAPSHOTS.slice().reverse().map((s, i, arr) => (
                <div key={s.id} className="flex items-center flex-1">
                  <button onClick={() => setActiveSnap(s.id)} className="flex flex-col items-center group">
                    <div className={`w-3 h-3 rounded-full border-2 transition-all ${activeSnap === s.id ? 'border-brand-navy bg-brand-navy scale-125' : 'border-gray-300 bg-white group-hover:border-brand-navy'}`}/>
                    <p className={`text-[10px] font-bold mt-1 transition-colors ${activeSnap === s.id ? 'text-brand-navy' : 'text-gray-400 group-hover:text-brand-navy'}`}>{s.label}</p>
                    {s.current && <span className="text-[8px] text-brand-navy font-bold">Current</span>}
                  </button>
                  {i < arr.length - 1 && <div className="flex-1 h-px bg-gray-200 mx-1"/>}
                </div>
              ))}
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
