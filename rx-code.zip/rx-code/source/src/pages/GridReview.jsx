import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, CheckCircle, Edit2, Save, X, FileText, ExternalLink, AlertTriangle, Minus, ChevronRight, Info } from 'lucide-react';
import { useApp, can } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';
import SourceBadge from '../components/SourceBadge';

// ── Mock grid data per CI type ──────────────────────────────────────
const MOCK_CC_GRID = [
  { criterion: 'Prior Authorization Required', carelon: 'Yes — all biologics', cells: { 'United Healthcare': { val: 'Yes', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC Medical Policy MP-04.01.07: Prior authorization is required for all biologic agents.' }, Cigna: { val: 'Yes', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna Coverage Policy 0301: PA required for biologic therapies.' }, Aetna: { val: 'Yes', tag: 'neutral', source: 'iDiscovery', evidence: 'Aetna Clinical Policy Bulletin: PA required.' }, Caremark: { val: 'Yes', tag: 'neutral', source: 'web', evidence: 'Caremark formulary guidance states PA required for specialty biologics.' } } },
  { criterion: 'Step Therapy — DMARD Trial (MTX)', carelon: '≥ 6 months MTX trial required', cells: { 'United Healthcare': { val: '≥ 3 months MTX', tag: 'lenient', source: 'iDiscovery', evidence: 'UHC Step Therapy Requirement: Adequate trial of methotrexate for ≥ 3 months at a therapeutic dose.' }, Cigna: { val: '≥ 6 months MTX', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna requires 6 months of conventional DMARD therapy including MTX.' }, Aetna: { val: '≥ 3 months MTX', tag: 'lenient', source: 'web', evidence: 'Aetna policy requires at least 3 months of MTX before approving biologic.' }, Caremark: { val: '≥ 6 months MTX', tag: 'neutral', source: 'iDiscovery', evidence: 'Caremark PA criteria: 6-month MTX trial at adequate dose.' } } },
  { criterion: 'Diagnosis Requirement', carelon: 'Moderate-to-severe RA confirmed by rheumatologist', cells: { 'United Healthcare': { val: 'Moderate-to-severe RA', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC requires documented diagnosis of moderate-to-severe RA per ACR criteria.' }, Cigna: { val: 'Moderate-to-severe RA', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna: Diagnosis of moderate-to-severe active rheumatoid arthritis per ACR criteria.' }, Aetna: { val: 'Moderate-to-severe RA', tag: 'neutral', source: 'iDiscovery', evidence: 'Aetna: Documented moderate-to-severe RA.' }, Caremark: { val: 'Mild-to-severe RA', tag: 'lenient', source: 'web', evidence: 'Caremark policy covers mild-to-severe RA with physician documentation.' } } },
  { criterion: 'Biosimilar Requirement', carelon: 'Biosimilar preferred when available', cells: { 'United Healthcare': { val: 'Mandatory biosimilar first', tag: 'stricter', source: 'iDiscovery', evidence: 'UHC requires dispensing of a biosimilar when one is available unless clinical exception documented.' }, Cigna: { val: 'Preferred biosimilar', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna: Biosimilar preferred but originator permitted with clinical documentation.' }, Aetna: { val: 'Mandatory biosimilar first', tag: 'stricter', source: 'web', evidence: 'Aetna Step Therapy requires biosimilar trial before originator biologic.' }, Caremark: { val: 'Preferred biosimilar', tag: 'neutral', source: 'iDiscovery', evidence: 'Caremark: Prefer biosimilar; originator covered with prior auth.' } } },
  { criterion: 'Quantity Limit', carelon: 'Per FDA labeling', cells: { 'United Healthcare': { val: 'Per FDA labeling', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC quantity limits align with FDA-approved dosing.' }, Cigna: { val: 'Per FDA labeling', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna quantity limits per FDA label.' }, Aetna: { val: '10% below FDA labeling', tag: 'stricter', source: 'iDiscovery', evidence: 'Aetna applies additional utilization management reducing approved quantity by 10%.' }, Caremark: { val: 'Per FDA labeling', tag: 'neutral', source: 'iDiscovery', evidence: 'Caremark aligns with FDA labeling for quantity limits.' } } },
  { criterion: 'Effective Date', carelon: 'Jan 1, 2026', cells: { 'United Healthcare': { val: 'Jan 1, 2026', tag: 'neutral', source: 'iDiscovery', evidence: 'Policy effective date: January 1, 2026.' }, Cigna: { val: 'Feb 1, 2026', tag: 'neutral', source: 'iDiscovery', evidence: 'Coverage policy effective February 1, 2026.' }, Aetna: { val: 'Jan 1, 2026', tag: 'neutral', source: 'web', evidence: 'Clinical policy bulletin updated January 2026.' }, Caremark: { val: 'Apr 1, 2026', tag: 'neutral', source: 'web', evidence: 'Caremark PA criteria effective April 2026.' } } },
];

const MOCK_DN_GRID = [
  { criterion: 'Humira (adalimumab)', carelon: 'Included — Mandatory', cells: { 'United Healthcare': { val: 'Included — Mandatory', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC Designated Network includes adalimumab as a mandatory specialty drug.' }, }, flag: 'Common', hcpcs: 'J0135' },
  { criterion: 'Enbrel (etanercept)', carelon: 'Included — Mandatory', cells: { 'United Healthcare': { val: 'Not included', tag: 'stricter', source: 'iDiscovery', evidence: 'UHC does not include etanercept in current designated network list.' } }, flag: 'Carelon Only', hcpcs: 'J1438' },
  { criterion: 'Stelara (ustekinumab)', carelon: 'Not included', cells: { 'United Healthcare': { val: 'Included — Voluntary', tag: 'lenient', source: 'web', evidence: 'UHC designated network includes ustekinumab on voluntary basis per Q2 2026 update.' } }, flag: 'Competitor Only', hcpcs: 'J3357' },
];

const MOCK_PREV_GRID = [
  { criterion: 'Lisinopril (Hypertension)', carelon: 'ACA + HDHP', cells: { CVS: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'CVS preventive list includes lisinopril under ACA preventive guidelines.' }, Optum: { val: 'ACA + HDHP', tag: 'neutral', source: 'iDiscovery', evidence: 'Optum includes lisinopril under both ACA and HDHP safe harbor.' }, UnitedHealthcare: { val: 'ACA', tag: 'neutral', source: 'web', evidence: 'UHC preventive Rx list includes lisinopril ACA category.' }, Humana: { val: 'Not covered', tag: 'stricter', source: 'web', evidence: 'Humana does not include lisinopril in their preventive drug list.' }, ESI: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'ESI preventive list includes lisinopril.' }, 'Blue Shield CA': { val: 'ACA + HDHP', tag: 'neutral', source: 'iDiscovery', evidence: 'Blue Shield CA covers lisinopril under both ACA and HDHP programs.' }, 'Kaiser Permanente': { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'Kaiser preventive list includes lisinopril under ACA framework.' } } },
  { criterion: 'Statins (Cholesterol)', carelon: 'ACA only', cells: { CVS: { val: 'ACA + HDHP', tag: 'lenient', source: 'web', evidence: 'CVS includes statins under both ACA and HDHP safe harbor.' }, Optum: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'Optum covers generic statins under ACA preventive.' }, UnitedHealthcare: { val: 'HDHP', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC includes statins under HDHP safe harbor program.' }, Humana: { val: 'ACA', tag: 'neutral', source: 'web', evidence: 'Humana preventive list includes generic statins.' }, ESI: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'ESI covers statins under ACA.' }, 'Blue Shield CA': { val: 'ACA + HDHP', tag: 'lenient', source: 'iDiscovery', evidence: 'Blue Shield CA includes statins under both frameworks.' }, 'Kaiser Permanente': { val: 'Not covered', tag: 'stricter', source: 'web', evidence: 'Kaiser does not include statins on preventive Rx list.' } } },
];

const GRID_BY_TYPE = {
  'Clinical Criteria': MOCK_CC_GRID,
  'Designated Network': MOCK_DN_GRID,
  'Preventive Rx': MOCK_PREV_GRID,
};

const TAG_STYLE = {
  stricter: 'bg-brand-peach text-brand-coral border border-brand-coral/30',
  lenient:  'bg-brand-tealPale text-teal-800 border border-brand-teal/20',
  neutral:  'bg-gray-50 text-gray-600 border border-gray-200',
};
const TAG_ICON = { stricter: <AlertTriangle size={10} />, lenient: <CheckCircle size={10} />, neutral: <Minus size={10} /> };

export default function GridReview() {
  const { id } = useParams();
  const { projects, updateProject, currentUser, addToast } = useApp();
  const navigate = useNavigate();
  const project = projects.find(p => p.id === id);

  const baseGrid = GRID_BY_TYPE[project?.ciType] || MOCK_CC_GRID;
  const competitors = project?.competitors || [];

  const [grid, setGrid] = useState(baseGrid);
  const [editingCell, setEditingCell] = useState(null); // {row, comp}
  const [editBuf, setEditBuf] = useState('');
  const [userEdited, setUserEdited] = useState({}); // {row-comp: true}
  const [evidencePanel, setEvidencePanel] = useState(null); // {row, comp, cell}
  const [summary, setSummary] = useState(
    project?.ciType === 'Clinical Criteria'
      ? `Key Findings:\n• UHC and Aetna apply stricter biosimilar-first requirements — consider aligning Carelon policy.\n• Aetna imposes a 10% quantity limit reduction below FDA labeling — notable outlier.\n• Caremark is lenient on diagnosis (mild RA included) — Carelon is more restrictive.\n• UHC and Aetna require only 3-month MTX step therapy vs Carelon's 6 months.\n\nRecommendations (AI-generated — advisory only):\n1. Evaluate biosimilar preference language to align with UHC/Aetna mandatory requirements.\n2. Review step therapy duration — 3-month MTX may be more aligned with market consensus.\n3. Monitor Caremark's lenient diagnosis criteria for downstream utilization impact.`
      : project?.ciType === 'Designated Network'
      ? `Key Findings:\n• Enbrel (etanercept) is Carelon-only — UHC does not include it. Review strategic value.\n• Stelara (ustekinumab) is UHC-only — candidate for potential inclusion in Carelon program.\n• Humira is common to both — market consensus confirmed.\n\nRecommendations (AI-generated — advisory only):\n1. Review Enbrel positioning given UHC exclusion from designated network.\n2. Evaluate adding Stelara based on UHC voluntary program inclusion.`
      : `Key Findings:\n• Statins: Carelon covers ACA only; CVS and Blue Shield CA cover ACA+HDHP — opportunity to expand.\n• Humana does not include Lisinopril — Carelon competitive advantage; maintain.\n• Kaiser does not include Statins — Carelon ahead; highlight in strategy communications.\n\nRecommendations (AI-generated — advisory only):\n1. Evaluate expanding statin coverage to HDHP safe harbor to align with CVS and Blue Shield CA.\n2. Document Carelon advantages on Lisinopril and Statins for strategic positioning.`
  );

  if (!project) return <div className="text-center py-20 text-gray-400">Project not found.</div>;

  const isApproved = project.status === 'Approved';
  const canEdit = can(currentUser, 'edit') && !isApproved;
  const canApprove = can(currentUser, 'approve') && project.status === 'Review';

  function startEditCell(rowIdx, comp, currentVal) {
    if (!canEdit) return;
    setEditingCell({ rowIdx, comp });
    setEditBuf(currentVal);
  }

  function saveCell(rowIdx, comp) {
    const newGrid = grid.map((row, i) => {
      if (i !== rowIdx) return row;
      return { ...row, cells: { ...row.cells, [comp]: { ...row.cells[comp], val: editBuf, userEdited: true } } };
    });
    setGrid(newGrid);
    setUserEdited(u => ({ ...u, [`${rowIdx}-${comp}`]: true }));
    updateProject(id, { analysisGrid: newGrid, _auditNote: `Cell edited: "${grid[rowIdx].criterion}" / ${comp} — updated to "${editBuf}"` });
    addToast(`Cell updated for ${comp}.`, 'success');
    setEditingCell(null);
  }

  function changeTag(rowIdx, comp, tag) {
    const newGrid = grid.map((row, i) => {
      if (i !== rowIdx) return row;
      return { ...row, cells: { ...row.cells, [comp]: { ...row.cells[comp], tag, userEdited: true } } };
    });
    setGrid(newGrid);
    setUserEdited(u => ({ ...u, [`${rowIdx}-${comp}`]: true }));
    updateProject(id, { analysisGrid: newGrid, _auditNote: `Classification changed: "${grid[rowIdx].criterion}" / ${comp} → ${tag}` });
  }

  function approve() {
    updateProject(id, { status: 'Approved', _auditNote: 'Project approved by analyst (Human-in-the-Loop). Export unlocked.' });
    addToast('Project approved successfully. Export is now available.', 'success');
  }

  function exportStub(type) {
    if (!isApproved) { addToast('Project must be Approved before exporting.', 'warning'); return; }
    addToast(`${type} export initiated — document will download shortly.`, 'success');
  }

  const relevantCompetitors = competitors.filter(c => grid.some(row => row.cells[c]));

  return (
    <div className="flex gap-0 h-full relative">
      {/* Main content */}
      <div className={`flex-1 min-w-0 space-y-4 transition-all ${evidencePanel ? 'mr-80' : ''}`}>
        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <button onClick={() => navigate(`/projects/${id}`)} className="flex items-center gap-1 text-xs text-gray-400 hover:text-brand-navy mb-1">
              <ArrowLeft size={13} /> Back to Project
            </button>
            <h1 className="text-xl font-bold text-brand-navy">{project.name}</h1>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <StatusBadge status={project.status} />
              <span className="bg-brand-iceBlue text-brand-navy text-xs px-2 py-0.5 rounded font-semibold">{project.ciType}</span>
              <span className="text-xs text-gray-400">{project.id} · {project.market}</span>
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {canApprove && (
              <button onClick={approve} className="btn-primary flex items-center gap-1.5 text-xs">
                <CheckCircle size={14} /> Approve
              </button>
            )}
            <button onClick={() => exportStub('Excel')} className={`btn-secondary text-xs flex items-center gap-1.5 ${!isApproved ? 'opacity-50' : ''}`}>
              <Download size={13} /> Excel
            </button>
            <button onClick={() => exportStub('PowerPoint')} className={`btn-secondary text-xs flex items-center gap-1.5 ${!isApproved ? 'opacity-50' : ''}`}>
              <Download size={13} /> PPT
            </button>
            <button onClick={() => exportStub('PDF')} className={`btn-secondary text-xs flex items-center gap-1.5 ${!isApproved ? 'opacity-50' : ''}`}>
              <Download size={13} /> PDF
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="card py-2 flex items-center gap-4 flex-wrap">
          <span className="text-xs font-semibold text-gray-500">Legend:</span>
          {Object.entries(TAG_STYLE).map(([tag, cls]) => (
            <span key={tag} className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold ${cls}`}>
              {TAG_ICON[tag]} {tag.charAt(0).toUpperCase() + tag.slice(1)} vs Carelon
            </span>
          ))}
          <span className="text-xs text-gray-400 ml-auto italic">Click any cell to view evidence · Click <Edit2 size={10} className="inline" /> to edit</span>
        </div>

        {!canEdit && !isApproved && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-4 py-2 text-xs text-yellow-800 flex items-center gap-2">
            <AlertTriangle size={13} /> Read-only view — you do not have edit permissions.
          </div>
        )}

        {/* Grid */}
        <div className="card p-0 overflow-x-auto">
          <table className="w-full text-left min-w-max">
            <thead>
              <tr>
                <th className="table-header w-48 sticky left-0 z-10">Criterion / Drug</th>
                <th className="table-header bg-brand-mid sticky left-48 z-10">Carelon</th>
                {relevantCompetitors.map(c => <th key={c} className="table-header">{c}</th>)}
              </tr>
            </thead>
            <tbody>
              {grid.map((row, rowIdx) => (
                <tr key={rowIdx} className="hover:bg-gray-50/50 group">
                  <td className="table-cell font-semibold text-brand-navy text-xs sticky left-0 bg-white z-10">
                    {row.criterion}
                    {row.hcpcs && <span className="block font-mono text-gray-400 font-normal text-xs mt-0.5">{row.hcpcs}</span>}
                    {row.flag && (
                      <span className={`mt-1 inline-block text-xs px-1.5 py-0.5 rounded font-semibold ${
                        row.flag === 'Common' ? 'bg-brand-tealPale text-teal-800'
                        : row.flag === 'Carelon Only' ? 'bg-brand-light text-brand-navy'
                        : 'bg-brand-peach text-brand-coral'}`}>
                        {row.flag}
                      </span>
                    )}
                  </td>
                  <td className="table-cell bg-brand-light/30 text-xs font-semibold sticky left-48 z-10">{row.carelon}</td>
                  {relevantCompetitors.map(comp => {
                    const cell = row.cells[comp];
                    if (!cell) return <td key={comp} className="table-cell text-gray-200 text-xs text-center">—</td>;
                    const isEditing = editingCell?.rowIdx === rowIdx && editingCell?.comp === comp;
                    const wasEdited = userEdited[`${rowIdx}-${comp}`];
                    return (
                      <td
                        key={comp}
                        className={`table-cell text-xs cursor-pointer transition-colors hover:bg-brand-light/20 ${TAG_STYLE[cell.tag]?.includes('bg') ? '' : ''}`}
                        onClick={() => !isEditing && setEvidencePanel({ rowIdx, comp, cell, criterion: row.criterion })}
                      >
                        {isEditing ? (
                          <div onClick={e => e.stopPropagation()} className="space-y-1">
                            <textarea className="input text-xs" rows={2} value={editBuf} onChange={e => setEditBuf(e.target.value)} autoFocus />
                            <div className="flex gap-1">
                              {['stricter','neutral','lenient'].map(t => (
                                <button key={t} onClick={() => changeTag(rowIdx, comp, t)}
                                  className={`text-xs px-1.5 py-0.5 rounded border font-semibold ${cell.tag === t ? 'bg-brand-navy text-white border-brand-navy' : 'border-gray-200 text-gray-500'}`}>
                                  {t}
                                </button>
                              ))}
                              <button onClick={() => saveCell(rowIdx, comp)} className="ml-auto text-brand-teal"><Save size={13} /></button>
                              <button onClick={() => setEditingCell(null)} className="text-gray-400"><X size={13} /></button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-start gap-1.5">
                            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${TAG_STYLE[cell.tag]}`}>
                              {TAG_ICON[cell.tag]} {cell.val}
                            </span>
                            <div className="ml-auto flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                              {wasEdited && <span title="User edited" className="text-brand-mid"><Info size={11} /></span>}
                              <SourceBadge source={cell.source} />
                              {canEdit && (
                                <button onClick={e => { e.stopPropagation(); startEditCell(rowIdx, comp, cell.val); }}
                                  className="text-brand-mid hover:text-brand-navy"><Edit2 size={12} /></button>
                              )}
                            </div>
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* AI Summary */}
        <div className="card border-l-4 border-brand-teal">
          <div className="flex items-center gap-2 mb-3">
            <FileText size={15} className="text-brand-teal" />
            <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>AI Summary & Recommendations</h2>
            <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-semibold ml-auto">Advisory — AI Generated</span>
          </div>
          <textarea
            className="input text-sm font-sans leading-relaxed"
            rows={8}
            value={summary}
            onChange={e => setSummary(e.target.value)}
            disabled={isApproved}
          />
          <p className="text-xs text-gray-400 mt-2 italic">AI recommendations are advisory only. Human review and approval required before export.</p>
        </div>

        {!isApproved && canApprove && (
          <div className="card bg-brand-iceBlue border border-brand-blue flex items-center justify-between gap-4">
            <p className="text-sm text-brand-navy font-semibold">Review complete? Approve the project to unlock document export.</p>
            <button onClick={approve} className="btn-primary flex items-center gap-1.5 text-xs shrink-0">
              <CheckCircle size={14} /> Approve Project
            </button>
          </div>
        )}
      </div>

      {/* Evidence Panel (slide-in) */}
      {evidencePanel && (
        <div className="fixed right-0 top-0 h-full w-80 bg-white border-l border-gray-200 shadow-xl z-40 flex flex-col">
          <div className="bg-brand-navy text-white px-4 py-3 flex items-center justify-between shrink-0">
            <div>
              <p className="text-xs text-white/60">Evidence</p>
              <p className="font-semibold text-sm">{evidencePanel.comp}</p>
            </div>
            <button onClick={() => setEvidencePanel(null)} className="text-white/60 hover:text-white"><X size={16} /></button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-1">Criterion</p>
              <p className="text-sm text-brand-navy font-semibold">{evidencePanel.criterion}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-1">Classification</p>
              <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold ${TAG_STYLE[evidencePanel.cell.tag]}`}>
                {TAG_ICON[evidencePanel.cell.tag]} {evidencePanel.cell.tag.charAt(0).toUpperCase() + evidencePanel.cell.tag.slice(1)}
              </span>
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-1">Value</p>
              <p className="text-sm text-gray-700">{evidencePanel.cell.val}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-1">Extracted Evidence</p>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 text-xs text-gray-700 leading-relaxed italic">
                "{evidencePanel.cell.evidence}"
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-1">Source</p>
              <div className="flex items-center gap-2">
                <SourceBadge source={evidencePanel.cell.source} />
                <button className="text-xs text-brand-mid hover:underline flex items-center gap-1">
                  <ExternalLink size={11} /> View Source Document
                </button>
              </div>
            </div>
            {userEdited[`${evidencePanel.rowIdx}-${evidencePanel.comp}`] && (
              <div className="bg-brand-iceBlue rounded-lg p-2 text-xs text-brand-navy flex items-center gap-1.5">
                <Info size={12} /> This cell was edited by a user.
              </div>
            )}
          </div>
          {can(currentUser, 'edit') && !isApproved && (
            <div className="p-4 border-t border-gray-100 shrink-0">
              <button
                onClick={() => { startEditCell(evidencePanel.rowIdx, evidencePanel.comp, evidencePanel.cell.val); setEvidencePanel(null); }}
                className="btn-secondary w-full text-xs flex items-center justify-center gap-1.5"
              >
                <Edit2 size={13} /> Edit This Cell
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
