import { useState, useMemo, useRef, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Download, ChevronUp, ChevronDown, CheckCircle, AlertTriangle, XCircle, Info, Zap, BarChart2, Upload, FileText, X, FileSpreadsheet, TrendingUp, TrendingDown, Clock, RefreshCw, ArrowRight, Target, Lightbulb, ShieldAlert, Activity } from 'lucide-react';

const MARKETS      = ['National', 'California', 'Texas', 'New York', 'Florida', 'Illinois'];
const COMPETITORS  = ['United Healthcare (UHC)', 'Cigna', 'Aetna', 'CVS/Caremark', 'Humana', 'Blue Shield CA', 'Anthem', 'Centene', 'Molina', 'Kaiser', 'BCBS', 'Magellan', 'Prime Therapeutics'];
const SNAPSHOTS = [
  { id: 'jul-2026', label: 'Jul 2026', date: 'Jul 1, 2026', competitor: 'UHC',   market: 'National',    drugs: 18, status: 'Completed' },
  { id: 'jun-2026', label: 'Jun 2026', date: 'Jun 1, 2026', competitor: 'UHC',   market: 'National',    drugs: 17, status: 'Completed' },
  { id: 'may-2026', label: 'May 2026', date: 'May 1, 2026', competitor: 'Cigna', market: 'National',    drugs: 15, status: 'Completed' },
  { id: 'apr-2026', label: 'Apr 2026', date: 'Apr 1, 2026', competitor: 'Cigna', market: 'National',    drugs: 15, status: 'Completed' },
  { id: 'mar-2026', label: 'Mar 2026', date: 'Mar 1, 2026', competitor: 'UHC',   market: 'National',    drugs: 14, status: 'Completed' },
  { id: 'feb-2026', label: 'Feb 2026', date: 'Feb 1, 2026', competitor: 'UHC',   market: 'National',    drugs: 13, status: 'Completed' },
];

const PROGRAM_STATUS = [
  { label: 'Mandatory',         count: 9,  color: '#1A3673' },
  { label: 'Voluntary',         count: 11, color: '#44B8F3' },
  { label: 'Mixed/Conditional', count: 1,  color: '#00BBBA' },
  { label: 'Other/Unclear',     count: 1,  color: '#6A97DF' },
];

const AI_RECS = [
  { type: 'add',    drug: 'Adakveo (crizanlizumab)',    drugClass: 'Biologic — P-selectin',   confidence: 97, impact: 'High',   reason: 'Covered by all 5 tracked competitors as mandatory program. Carelon currently absent — highest market signal gap.', competitors: ['UHC', 'Cigna', 'Aetna', 'CVS', 'Humana'] },
  { type: 'add',    drug: 'Adzynma (concizumab)',        drugClass: 'Enzyme Replacement',      confidence: 91, impact: 'High',   reason: 'Covered by UHC and Aetna as mandatory. Emerging standard of care for rare coagulation disorders.', competitors: ['UHC', 'Aetna'] },
  { type: 'add',    drug: 'Alyglo (immune globulin)',    drugClass: 'IVIG',                    confidence: 88, impact: 'High',   reason: 'Voluntary coverage at UHC, Cigna, CVS, Humana. Strong biosimilar competition incoming — inclusion now advantageous.', competitors: ['UHC', 'Cigna', 'CVS', 'Humana'] },
  { type: 'add',    drug: 'Amvuttra (vutrisiran)',       drugClass: 'RNAi — TTR',              confidence: 82, impact: 'Medium', reason: 'UHC, Cigna, Aetna, Humana include as voluntary program. RNAi therapy adoption accelerating in market.', competitors: ['UHC', 'Cigna', 'Aetna', 'Humana'] },
  { type: 'add',    drug: 'Beovu (brolucizumab)',        drugClass: 'Anti-VEGF',               confidence: 74, impact: 'Medium', reason: 'Covered voluntarily by UHC, Aetna, CVS. Ophthalmology biologic gap — may affect member satisfaction.', competitors: ['UHC', 'Aetna', 'CVS'] },
  { type: 'remove', drug: 'ADYNOVATE (antihemophilic)', drugClass: 'Factor VIII — PEGylated', confidence: 78, impact: 'Medium', reason: 'No competitor covers this Factor VIII variant in DN programs. Carelon-only inclusion may not represent market consensus.', competitors: [] },
  { type: 'remove', drug: 'BENEFIX (nonacog alfa)',      drugClass: 'Factor IX',               confidence: 65, impact: 'Low',    reason: 'Only Humana includes. Utilization data suggests low DN program relevance — evaluate for formulary-only placement.', competitors: ['Humana'] },
  { type: 'remove', drug: 'ADVATE (antihemophilic)',     drugClass: 'Factor VIII',             confidence: 60, impact: 'Low',    reason: 'Market consensus leaning toward newer PEGylated variants. Cigna and Humana retain; UHC/Aetna/CVS do not.', competitors: ['Cigna', 'Humana'] },
];

const OPPORTUNITIES = [
  { title: 'GLP-1 / SGLT-2 Expansion',   impact: 'High',   value: '$2.4M',  desc: 'Competitors covering Ozempic and Jardiance in DN programs for cardiometabolic risk reduction. Carelon gap may impact commercial RFP competitiveness.', carriers: ['UHC', 'Cigna', 'Aetna'] },
  { title: 'Biosimilar Transition',        impact: 'High',   value: '$1.8M',  desc: 'Market shifting Humira biosimilars (Hadlima, Cyltezo) into mandatory DN. Early adoption reduces costs while maintaining coverage parity.', carriers: ['CVS', 'Humana'] },
  { title: 'Ophthalmology Biologic Gap',   impact: 'Medium', value: '$900K',  desc: 'Anti-VEGF drugs (Beovu, Eylea HD) voluntary across UHC and Aetna. Member access gap in ophthalmology specialty benefit segment.', carriers: ['UHC', 'Aetna'] },
  { title: 'Factor Therapy Differentiation', impact: 'Low', value: '$400K',  desc: 'Carelon Factor VIII/IX portfolio is broader than any single competitor — document as competitive advantage in member-facing materials.', carriers: [] },
];

const C = (v) => v === 'Y';
const DRUGS = [
  { drug: 'ACTEMRA',    drugClass: 'Biologic — IL-6',        hcpcs: 'J0129', programType: 'Mandatory', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'N', Humana: 'Y', Anthem: 'Y', Centene: 'Y', BCBS: 'Y', Molina: 'N', Kaiser: 'Y', Prime: 'Y', Magellan: 'N', Oscar: 'Y' },
  { drug: 'ALDURAZYME', drugClass: 'Enzyme Replacement',     hcpcs: 'J1931', programType: 'Mandatory', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'Y', Humana: 'Y', Anthem: 'Y', Centene: 'N', BCBS: 'Y', Molina: 'Y', Kaiser: 'Y', Prime: 'N', Magellan: 'Y', Oscar: 'N' },
  { drug: 'ASCENIV',   drugClass: 'IVIG',                    hcpcs: 'J1554', programType: 'Mandatory', carelon: 'Y', UHC: 'Y', Cigna: 'N', Aetna: 'Y', CVS: 'Y', Humana: 'N', Anthem: 'Y', Centene: 'N', BCBS: 'N', Molina: 'N', Kaiser: 'Y', Prime: 'Y', Magellan: 'N', Oscar: 'N' },
  { drug: 'AVSOLA',    drugClass: 'Biologic — TNF',          hcpcs: 'J0129', programType: 'Voluntary', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'N', CVS: 'Y', Humana: 'Y', Anthem: 'N', Centene: 'Y', BCBS: 'Y', Molina: 'Y', Kaiser: 'N', Prime: 'Y', Magellan: 'Y', Oscar: 'N' },
  { drug: 'BENLYSTA',  drugClass: 'Biologic — BLyS',         hcpcs: 'J0490', programType: 'Voluntary', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'Y', Humana: 'Y', Anthem: 'Y', Centene: 'Y', BCBS: 'Y', Molina: 'Y', Kaiser: 'Y', Prime: 'Y', Magellan: 'Y', Oscar: 'Y' },
  { drug: 'BIVIGAM',   drugClass: 'IVIG',                    hcpcs: 'J1557', programType: 'Mandatory', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'N', Humana: 'N', Anthem: 'Y', Centene: 'N', BCBS: 'Y', Molina: 'N', Kaiser: 'Y', Prime: 'N', Magellan: 'Y', Oscar: 'N' },
  { drug: 'CINQAIR',   drugClass: 'Biologic — IL-5',         hcpcs: 'J2786', programType: 'Mandatory', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'Y', Humana: 'Y', Anthem: 'Y', Centene: 'Y', BCBS: 'Y', Molina: 'Y', Kaiser: 'Y', Prime: 'Y', Magellan: 'N', Oscar: 'Y' },
  { drug: 'ELAPRASE',  drugClass: 'Enzyme Repl.',             hcpcs: 'J1743', programType: 'Mandatory', carelon: 'Y', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'Y', Humana: 'Y', Anthem: 'Y', Centene: 'Y', BCBS: 'Y', Molina: 'Y', Kaiser: 'Y', Prime: 'Y', Magellan: 'Y', Oscar: 'Y' },
  { drug: 'ADVATE',    drugClass: 'Factor VIII',              hcpcs: 'J7192', programType: 'Mandatory', carelon: 'Y', UHC: 'N', Cigna: 'Y', Aetna: 'N', CVS: 'N', Humana: 'Y', Anthem: 'N', Centene: 'N', BCBS: 'Y', Molina: 'N', Kaiser: 'N', Prime: 'Y', Magellan: 'N', Oscar: 'N' },
  { drug: 'ADYNOVATE', drugClass: 'Factor VIII — PEGylated', hcpcs: 'J7207', programType: 'Mandatory', carelon: 'Y', UHC: 'N', Cigna: 'N', Aetna: 'Y', CVS: 'N', Humana: 'N', Anthem: 'N', Centene: 'Y', BCBS: 'N', Molina: 'N', Kaiser: 'N', Prime: 'N', Magellan: 'Y', Oscar: 'N' },
  { drug: 'AFSTYLA',   drugClass: 'Factor VIII — rVIII',     hcpcs: 'J7200', programType: 'Mandatory', carelon: 'Y', UHC: 'N', Cigna: 'Y', Aetna: 'N', CVS: 'Y', Humana: 'N', Anthem: 'Y', Centene: 'N', BCBS: 'N', Molina: 'Y', Kaiser: 'N', Prime: 'Y', Magellan: 'N', Oscar: 'N' },
  { drug: 'BENEFIX',   drugClass: 'Factor IX',               hcpcs: 'J7193', programType: 'Mandatory', carelon: 'Y', UHC: 'N', Cigna: 'N', Aetna: 'N', CVS: 'N', Humana: 'Y', Anthem: 'N', Centene: 'N', BCBS: 'Y', Molina: 'N', Kaiser: 'N', Prime: 'N', Magellan: 'N', Oscar: 'Y' },
  { drug: 'Adakveo',   drugClass: 'Biologic — P-selectin',   hcpcs: 'J0791', programType: 'Mandatory', carelon: 'N', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'Y', Humana: 'Y', Anthem: 'Y', Centene: 'Y', BCBS: 'Y', Molina: 'Y', Kaiser: 'Y', Prime: 'Y', Magellan: 'Y', Oscar: 'Y' },
  { drug: 'Adzynma',   drugClass: 'Enzyme Replacement',      hcpcs: 'J0222', programType: 'Mandatory', carelon: 'N', UHC: 'Y', Cigna: 'N', Aetna: 'Y', CVS: 'Y', Humana: 'N', Anthem: 'Y', Centene: 'N', BCBS: 'Y', Molina: 'N', Kaiser: 'Y', Prime: 'Y', Magellan: 'N', Oscar: 'N' },
  { drug: 'Alyglo',    drugClass: 'IVIG',                    hcpcs: 'J1555', programType: 'Voluntary', carelon: 'N', UHC: 'Y', Cigna: 'Y', Aetna: 'N', CVS: 'Y', Humana: 'Y', Anthem: 'N', Centene: 'Y', BCBS: 'N', Molina: 'Y', Kaiser: 'N', Prime: 'Y', Magellan: 'N', Oscar: 'Y' },
  { drug: 'Amvuttra',  drugClass: 'RNAi — TTR',              hcpcs: 'J0222', programType: 'Voluntary', carelon: 'N', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'N', Humana: 'Y', Anthem: 'Y', Centene: 'N', BCBS: 'Y', Molina: 'N', Kaiser: 'Y', Prime: 'N', Magellan: 'Y', Oscar: 'Y' },
  { drug: 'Beovu',     drugClass: 'Anti-VEGF',               hcpcs: 'J0179', programType: 'Voluntary', carelon: 'N', UHC: 'Y', Cigna: 'N', Aetna: 'Y', CVS: 'Y', Humana: 'N', Anthem: 'Y', Centene: 'Y', BCBS: 'N', Molina: 'Y', Kaiser: 'N', Prime: 'Y', Magellan: 'N', Oscar: 'N' },
  { drug: 'Bkemv',    drugClass: 'Biosimilar',               hcpcs: 'Q5126', programType: 'Voluntary', carelon: 'N', UHC: 'Y', Cigna: 'Y', Aetna: 'Y', CVS: 'Y', Humana: 'Y', Anthem: 'Y', Centene: 'Y', BCBS: 'Y', Molina: 'Y', Kaiser: 'Y', Prime: 'Y', Magellan: 'N', Oscar: 'Y' },
];
const COMP_KEYS = ['UHC', 'Cigna', 'Aetna', 'CVS', 'Humana', 'Anthem', 'Centene', 'BCBS', 'Molina', 'Kaiser', 'Prime', 'Magellan', 'Oscar'];

const DRUG_CLASSES = [
  { cls: 'Biologics — Immunology',  internalCount: 18, competitorCount: 24, coveragePct: 75, opportunityPct: 25 },
  { cls: 'Enzyme Replacement',      internalCount: 12, competitorCount: 14, coveragePct: 86, opportunityPct: 14 },
  { cls: 'IVIG / Immunoglobulins',  internalCount: 10, competitorCount: 12, coveragePct: 83, opportunityPct: 17 },
  { cls: 'Factor Therapies',        internalCount: 22, competitorCount: 9,  coveragePct: 40, opportunityPct: 60 },
  { cls: 'Ophthalmology Biologics', internalCount: 5,  competitorCount: 10, coveragePct: 50, opportunityPct: 50 },
  { cls: 'Gene / RNAi Therapies',   internalCount: 3,  competitorCount: 8,  coveragePct: 38, opportunityPct: 62 },
];

const COMP_OVERLAP = {
  'UHC': {
    compTotal: 140, carOnly: 75, compOnly: 109, common: 31,
    commonDrugs:    ['ACTEMRA','ALDURAZYME','ASCENIV','AVSOLA','BENLYSTA','BIVIGAM','CINQAIR','ELAPRASE'],
    carOnlyDrugs:   ['ADVATE','ADYNOVATE','AFSTYLA','ALPHANATE','ALPHANINE SD','ALPROLIX','BENEFIX','COAGADEX'],
    compOnlyDrugs:  ['Adakveo','Adzynma','Alyglo','Amondys-45','Amvuttra','Aralast NP','Beovu','Bkemv'],
  },
  'Cigna': {
    compTotal: 118, carOnly: 82, compOnly: 88, common: 24,
    commonDrugs:    ['ACTEMRA','ALDURAZYME','BENLYSTA','BIVIGAM','CINQAIR','ELAPRASE','AVSOLA','ASCENIV'],
    carOnlyDrugs:   ['ADVATE','ADYNOVATE','AFSTYLA','BENEFIX','ALPROLIX','COAGADEX','ALPHANATE','ALPHANINE SD'],
    compOnlyDrugs:  ['Adakveo','Amvuttra','Beovu','Bkemv','Dupixent','Fasenra','Ilaris','Kesimpta'],
  },
  'Aetna': {
    compTotal: 132, carOnly: 68, compOnly: 96, common: 38,
    commonDrugs:    ['ACTEMRA','ALDURAZYME','ASCENIV','BENLYSTA','BIVIGAM','CINQAIR','ELAPRASE','AVSOLA'],
    carOnlyDrugs:   ['ADVATE','ADYNOVATE','ALPHANATE','ALPROLIX','BENEFIX','COAGADEX','AFSTYLA','ALPHANINE SD'],
    compOnlyDrugs:  ['Adakveo','Alyglo','Amvuttra','Beovu','Bkemv','Dupixent','Enspryng','Fasenra'],
  },
  'CVS': {
    compTotal: 98,  carOnly: 91, compOnly: 62, common: 15,
    commonDrugs:    ['ACTEMRA','ALDURAZYME','BENLYSTA','CINQAIR','ELAPRASE','BIVIGAM','ASCENIV','AVSOLA'],
    carOnlyDrugs:   ['ADVATE','ADYNOVATE','AFSTYLA','BENEFIX','ALPHANATE','ALPROLIX','COAGADEX','ALPHANINE SD'],
    compOnlyDrugs:  ['Adakveo','Alyglo','Amvuttra','Beovu','Bkemv','Dupixent','Fasenra','Ilaris'],
  },
  'Humana': {
    compTotal: 110, carOnly: 79, compOnly: 73, common: 27,
    commonDrugs:    ['ACTEMRA','ALDURAZYME','ASCENIV','BENLYSTA','BIVIGAM','CINQAIR','ELAPRASE','AVSOLA'],
    carOnlyDrugs:   ['ADVATE','AFSTYLA','ALPHANATE','ALPHANINE SD','ALPROLIX','BENEFIX','COAGADEX','ADYNOVATE'],
    compOnlyDrugs:  ['Adakveo','Alyglo','Amvuttra','Aralast NP','Beovu','Bkemv','Dupixent','Fasenra'],
  },
};

const RECS = [
  { type: 'gap',     title: '109-Drug Gap Review',      body: 'Prioritize mandatory UHC-only drugs (Adakveo, Adzynma, Alyglo) for DN program inclusion evaluation.' },
  { type: 'missing', title: 'Factor Therapy Advantage', body: 'Carelon Factor VIII/IX/X portfolio appears Carelon-only. Confirm UHC exclusion rationale and document advantage.' },
  { type: 'match',   title: 'Mandatory Alignment',      body: 'Focus primary comparison against 9 mandatory programs — highest market signal fidelity.' },
];

const STATUS_CONFIG = {
  match:   { label: 'Common (Both)',   bg: 'bg-emerald-100 text-emerald-800', icon: <CheckCircle size={13} className="text-emerald-600" /> },
  missing: { label: 'Carelon Only',    bg: 'bg-amber-100 text-amber-800',     icon: <AlertTriangle size={13} className="text-amber-500" /> },
  gap:     { label: 'Competitor Only', bg: 'bg-red-100 text-red-700',         icon: <XCircle size={13} className="text-red-500" /> },
  tier:    { label: 'Tier Diff',       bg: 'bg-blue-100 text-blue-800',       icon: <Info size={13} className="text-blue-500" /> },
};

function SortIcon({ col, sortCol, sortDir }) {
  if (sortCol !== col) return <ChevronUp size={12} className="text-gray-300 ml-1" />;
  return sortDir === 'asc' ? <ChevronUp size={12} className="text-brand-navy ml-1" /> : <ChevronDown size={12} className="text-brand-navy ml-1" />;
}

export default function DesignatedNetworkWorkflow() {
  const [searchParams] = useSearchParams();
  const [market,     setMarket]     = useState(MARKETS[0]);
  const [competitor, setCompetitor] = useState(COMPETITORS[0]);
  const urlSnapshot = searchParams.get('snapshot');
  const [snapshot,   setSnapshot]   = useState(urlSnapshot || SNAPSHOTS[0].id);

  useEffect(() => {
    if (urlSnapshot && SNAPSHOTS.some(s => s.id === urlSnapshot)) {
      setSnapshot(urlSnapshot);
    }
  }, [urlSnapshot]);
  const [search,     setSearch]     = useState('');
  const [tableSearch, setTableSearch] = useState('');
  const [view,       setView]       = useState('drug');
  const [statusFilter, setStatusFilter] = useState('all');
  const [recFilter,    setRecFilter]    = useState('all');
  const [sortCol,  setSortCol]  = useState('drug');
  const [sortDir,  setSortDir]  = useState('asc');
  const [aiTopN,   setAiTopN]   = useState(5);
  const [uploadedFile,  setUploadedFile]  = useState(null);
  const [uploadSource,  setUploadSource]  = useState('carelon');
  const [generating, setGenerating] = useState(false);
  const [generated,  setGenerated]  = useState(true);
  const [exportOpen, setExportOpen] = useState(false);
  const [reportStatus, setReportStatus] = useState('in-progress'); // 'in-progress' | 'in-review' | 'approved'
  const [overlapComp, setOverlapComp] = useState('UHC');
  const [overlapSearch, setOverlapSearch] = useState('');
  const [coverageOpen, setCoverageOpen] = useState(true);
  const [overlapDropOpen, setOverlapDropOpen] = useState(false);
  const [portfolioExpanded, setPortfolioExpanded] = useState(null);
  const [cellOverrides, setCellOverrides] = useState({});
  const [cellNote, setCellNote] = useState(null);
  const [confirmModal, setConfirmModal] = useState(null); // { cellKey, row, comp, action: 'add'|'remove' }
  const [tooltip, setTooltip] = useState(null); // { x, y, content }
  const [selectedComps, setSelectedComps] = useState(new Set(COMP_KEYS.slice(0, 5)));
  const compPickerRef = useRef(null);
  const visibleComps = COMP_KEYS.filter(c => selectedComps.has(c));
  const toggleComp = (c) => setSelectedComps(prev => {
    const next = new Set(prev);
    if (next.has(c)) { if (next.size > 1) next.delete(c); }
    else next.add(c);
    return next;
  });
  const overlapRef = useRef(null);
  const fileInputRef = useRef(null);
  const exportRef    = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (overlapRef.current && !overlapRef.current.contains(e.target)) setOverlapDropOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleFileUpload(e) {
    const file = e.target.files?.[0];
    if (file) setUploadedFile(file);
    e.target.value = '';
  }

  function handleGenerate() {
    setGenerating(true);
    setGenerated(false);
    setReportStatus('in-progress');
    setTimeout(() => { setGenerating(false); setGenerated(true); setReportStatus('in-review'); }, 2500);
  }

  function toggleSort(col) {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  }

  const filtered = useMemo(() => {
    const q = tableSearch.toLowerCase();
    let rows = DRUGS.filter(r =>
      (statusFilter === 'all' || (() => {
        const allCovered = COMP_KEYS.every(k => r[k] === r.carelon);
        if (statusFilter === 'match') return r.carelon === 'Y' && COMP_KEYS.some(k => r[k] === 'Y');
        if (statusFilter === 'missing') return r.carelon === 'Y' && COMP_KEYS.some(k => r[k] === 'N');
        if (statusFilter === 'gap') return r.carelon === 'N' && COMP_KEYS.some(k => r[k] === 'Y');
        return true;
      })()) &&
      (!q || r.drug.toLowerCase().includes(q) || r.drugClass.toLowerCase().includes(q))
    );
    rows = [...rows].sort((a, b) => {
      const av = a[sortCol] || ''; const bv = b[sortCol] || '';
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return rows;
  }, [tableSearch, statusFilter, sortCol, sortDir]);


  const kpis = [
    { label: 'Carelon DN Drugs',   value: 106,                                              color: 'text-brand-navy',  bg: 'bg-brand-light',  sub: 'Full drug list' },
    { label: 'UHC DN Drugs',       value: 140,                                              color: 'text-blue-700',    bg: 'bg-blue-50',      sub: 'Competitor list' },
    { label: 'Common (Both)',       value: 31,                                               color: 'text-emerald-700', bg: 'bg-emerald-50',   sub: 'Overlap' },
    { label: 'Carelon Only',        value: DRUGS.filter(d => d.status === 'missing').length, color: 'text-amber-700',   bg: 'bg-amber-50',     sub: 'Sample shown' },
    { label: 'Competitor Only',     value: 109,                                              color: 'text-red-700',     bg: 'bg-red-50',       sub: 'UHC-only drugs' },
  ];


  return (
    <div className="space-y-5">

      {/* ── Page Header ── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Designated Network</p>
          <h1 className="text-2xl font-bold text-brand-navy">Competitor Drug Comparison</h1>
          <p className="text-xs text-gray-400 mt-1">Compare Carelon's white bagging drug list against competitor DN programs · Identify gaps and opportunities</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative" ref={exportRef}>
            <button
              onClick={() => reportStatus === 'approved' && setExportOpen(o => !o)}
              disabled={reportStatus !== 'approved'}
              title={reportStatus !== 'approved' ? 'Approve the report to enable export' : 'Export report'}
              className={`btn-secondary flex items-center gap-2 text-xs transition-all ${reportStatus !== 'approved' ? 'opacity-40 cursor-not-allowed' : ''}`}>
              <Download size={14} /> Export <ChevronDown size={12} className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`} />
            </button>
            {exportOpen && (
              <div className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
                {[
                  { label: 'PowerPoint (.pptx)', icon: <FileText size={13} className="text-orange-500" /> },
                  { label: 'PDF (.pdf)',          icon: <FileText size={13} className="text-red-500" /> },
                  { label: 'Excel (.xlsx)',       icon: <FileSpreadsheet size={13} className="text-emerald-600" /> },
                ].map(opt => (
                  <button key={opt.label} onClick={() => setExportOpen(false)}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                    {opt.icon} {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>


      {/* ── Action Bar ── */}
      <div className="card py-3 px-4">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleGenerate}
            disabled={generating}
            className={`btn-primary flex items-center gap-2 px-5 py-2 text-sm font-semibold ${generating ? 'opacity-70 cursor-not-allowed' : ''}`}>
            <Zap size={15} /> {generating ? 'Generating...' : 'Generate Intelligence'}
          </button>
          <div className="h-6 w-px bg-gray-200" />
          <input ref={fileInputRef} type="file" accept=".pdf,.xlsx,.xls,.csv,.docx" className="hidden" onChange={handleFileUpload} />
          {uploadedFile ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
              <CheckCircle size={13} className="text-emerald-600 shrink-0" />
              <span className="font-semibold text-emerald-800 max-w-[180px] truncate">{uploadedFile.name}</span>
              <button onClick={() => setUploadedFile(null)} className="ml-1 text-gray-400 hover:text-red-500"><X size={12} /></button>
            </div>
          ) : (
            <button onClick={() => fileInputRef.current?.click()} className="btn-secondary flex items-center gap-1.5 text-xs">
              <Upload size={13} /> Upload Drug List
            </button>
          )}

          {/* ── Status pipeline ── */}
          <div className="h-6 w-px bg-gray-200" />
          <div className="flex items-center gap-1.5">
            {[
              { key: 'in-progress', label: 'In Progress', activeColor: '#D97706', activeBg: '#FEF3C7', activeBorder: '#FCD34D', dot: 'bg-amber-500' },
              { key: 'in-review',   label: 'In Review',   activeColor: '#1D4ED8', activeBg: '#EFF6FF', activeBorder: '#93C5FD', dot: 'bg-blue-500' },
              { key: 'approved',    label: 'Approved',    activeColor: '#059669', activeBg: '#ECFDF5', activeBorder: '#6EE7B7', dot: 'bg-emerald-500' },
            ].map((step, idx) => {
              const steps = ['in-progress', 'in-review', 'approved'];
              const currentIdx = steps.indexOf(reportStatus);
              const stepIdx = steps.indexOf(step.key);
              const isActive = reportStatus === step.key;
              const isDone = stepIdx < currentIdx;
              return (
                <div key={step.key} className="flex items-center gap-1.5">
                  {idx > 0 && <div className={`w-5 h-px ${isDone || isActive ? 'bg-gray-400' : 'bg-gray-200'}`} />}
                  <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                    isActive
                      ? 'border-current'
                      : isDone ? 'bg-gray-50 text-gray-400 border-gray-200' : 'bg-white text-gray-300 border-gray-100'
                  }`} style={isActive ? { backgroundColor: step.activeBg, color: step.activeColor, borderColor: step.activeBorder } : {}}>
                    {isActive && step.key !== 'approved' && <span className={`w-1.5 h-1.5 rounded-full ${step.dot} ${step.key === 'in-progress' ? 'animate-pulse' : ''}`} />}
                    {(isActive && step.key === 'approved') || isDone ? <CheckCircle size={10} className={isDone ? 'text-gray-400' : 'text-emerald-500'} /> : null}
                    {step.label}
                  </span>
                </div>
              );
            })}
            {/* Approve button — only in-review */}
            {reportStatus === 'in-review' && (
              <button
                onClick={() => setReportStatus('approved')}
                className="ml-1 flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
              >
                <CheckCircle size={11} /> Approve
              </button>
            )}
            {reportStatus === 'approved' && (
              <button onClick={() => setReportStatus('in-review')} className="ml-1 text-[10px] text-gray-400 hover:text-red-400 underline">Revoke</button>
            )}
          </div>
        </div>
      </div>

      {/* Generating spinner */}
      {generating && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
          <div className="flex-1">
            <p className="text-brand-navy text-sm font-semibold">Generating intelligence…</p>
            <div className="flex gap-4 mt-1.5 text-xs text-blue-600">
              {['Ingesting drug lists','Normalizing HCPCS codes','Matching overlap','Analyzing gaps'].map((s,i) => (
                <span key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay: `${i*200}ms` }} />{s}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {!generated && !generating ? (
        <div className="card flex flex-col items-center justify-center py-14 gap-4 border-2 border-dashed border-gray-200 bg-gray-50">
          <div className="w-12 h-12 rounded-full bg-brand-light flex items-center justify-center">
            <Zap size={22} className="text-brand-navy" />
          </div>
          <div className="text-center">
            <p className="text-sm font-semibold text-gray-700">Ready to generate insights</p>
            <p className="text-xs text-gray-400 mt-1 max-w-xs">Select a market and competitor above, upload your drug list, then click <strong>Generate Intelligence</strong></p>
          </div>
          <div className="flex items-center gap-6 mt-2">
            {['Ingest','Extract','Normalize','Compare','Report'].map((step, i, arr) => (
              <div key={step} className="flex items-center gap-2">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-400">{i+1}</div>
                  <span className="text-xs text-gray-400">{step}</span>
                </div>
                {i < arr.length - 1 && <ArrowRight size={12} className="text-gray-300 mb-3" />}
              </div>
            ))}
          </div>
        </div>
      ) : generated ? (
        <div className="space-y-6">

          {/* ══════════════════════════════════════════════
              SECTION 2 — Combined Priority Intelligence Table
          ══════════════════════════════════════════════ */}
          <div className="card p-0 overflow-hidden" style={{ border: '2px solid #E1EDFF' }}>
            {/* Table header */}
            <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-3 flex-wrap" style={{ backgroundColor: '#F8FAFF' }}>
              <div className="flex items-center gap-2">
                <Target size={15} className="text-brand-navy shrink-0" />
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold leading-none mb-0.5">Priority Intelligence Table</p>
                  <div className="flex items-center gap-2">
                    <h2 className="font-bold text-brand-navy" style={{ fontSize: 14 }}>Drug-Level Comparison</h2>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{ backgroundColor: '#1A3673', color: '#fff', letterSpacing: '0.04em' }}>
                      ● Current · {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>
                </div>
              </div>
              <div className="ml-auto flex items-center gap-2 flex-wrap">
                {/* Competitor pills */}
                <div className="flex items-center gap-1 flex-wrap">
                  {COMP_KEYS.map(c => (
                    <button key={c} onClick={() => toggleComp(c)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border transition-all ${
                        selectedComps.has(c) ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-400 border-gray-200 hover:border-brand-navy hover:text-brand-navy'
                      }`}>{c}</button>
                  ))}
                </div>
                <div className="w-px h-5 bg-gray-200"/>
                <div className="relative">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input className="input pl-8 text-xs py-1.5 w-44" placeholder="Search drug or class…"
                    value={tableSearch} onChange={e => setTableSearch(e.target.value)} />
                </div>
                {tableSearch && <button onClick={() => setTableSearch('')} className="text-xs text-gray-400 hover:text-red-500"><X size={12}/></button>}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 520 }}>
              <table className="text-left" style={{ borderCollapse: 'separate', borderSpacing: 0, width: '100%', tableLayout: 'fixed' }}>
                <thead className="sticky top-0 z-20">
                  <tr>
                    {/* ── Sticky fixed columns ── */}
                    {[
                      { col: 'drug',        label: 'Drug Name',         width: 180 },
                      { col: 'drugClass',   label: 'Therapeutic Class', width: 160 },
                      { col: 'hcpcs',       label: 'HCPCS',            width: 90  },
                    ].reduce((acc, h, i) => {
                      const left = acc.left;
                      acc.els.push(
                        <th key={h.col} onClick={() => toggleSort(h.col)}
                          className="px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer select-none whitespace-nowrap bg-gray-50 border-b border-gray-200"
                          style={{ position: 'sticky', left: left, zIndex: 20, minWidth: h.width, boxShadow: i === 3 ? 'none' : undefined }}>
                          <div className="flex items-center gap-1">{h.label}<SortIcon col={h.col} sortCol={sortCol} sortDir={sortDir} /></div>
                        </th>
                      );
                      acc.left += h.width;
                      return acc;
                    }, { els: [], left: 0 }).els}
                    {/* Carelon — sticky */}
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-center whitespace-nowrap text-brand-navy border-b border-gray-200"
                      style={{ position: 'sticky', left: 430, zIndex: 20, minWidth: 80, backgroundColor: '#EBF3FF', boxShadow: '2px 0 4px rgba(0,0,0,0.06)' }}>
                      Carelon
                    </th>
                    {/* ── Competitor columns: selected only ── */}
                    {visibleComps.map(c => (
                      <th key={c} className="px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide text-center whitespace-nowrap bg-gray-50 border-b border-gray-200">{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filtered
                    .filter(r => statusFilter === 'all' || r.programType === statusFilter)
                    .sort((a, b) => {
                      if (sortCol !== 'programType') return 0;
                      const order = { Mandatory: 0, Voluntary: 1 };
                      return sortDir === 'asc'
                        ? (order[a.programType] ?? 2) - (order[b.programType] ?? 2)
                        : (order[b.programType] ?? 2) - (order[a.programType] ?? 2);
                    })
                    .map((row, i) => {
                      const isMandatory = row.programType === 'Mandatory';
                      const rec = AI_RECS.find(r => r.drug.toLowerCase().includes(row.drug.toLowerCase()));
                      const rowBg = isMandatory ? '#EEF4FF' : '#fff';
                      const rowBgCarelon = isMandatory ? '#ddeaff' : '#EBF3FF';
                      return (
                        <tr key={i} className="transition-colors" style={{ backgroundColor: rowBg }}>
                          {/* Drug Name — sticky col 1 */}
                          <td className="px-4 py-2.5 whitespace-nowrap border-b border-gray-100"
                            style={{ position: 'sticky', left: 0, zIndex: 10, backgroundColor: rowBg, minWidth: 180, isolation: 'isolate' }}>
                            <div className="flex items-center gap-1.5">
                              {isMandatory && <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: '#1A3673' }} />}
                              <span className={`text-sm font-semibold ${isMandatory ? 'text-brand-navy' : 'text-gray-700'}`}>{row.drug}</span>
                            </div>
                          </td>
                          {/* Therapeutic Class — sticky col 2 */}
                          <td className="px-4 py-2.5 text-xs text-gray-500 whitespace-nowrap border-b border-gray-100"
                            style={{ position: 'sticky', left: 180, zIndex: 10, backgroundColor: rowBg, minWidth: 160, isolation: 'isolate' }}>{row.drugClass}</td>
                          {/* HCPCS — sticky col 3 */}
                          <td className="px-4 py-2.5 text-xs font-mono text-gray-400 whitespace-nowrap border-b border-gray-100"
                            style={{ position: 'sticky', left: 340, zIndex: 10, backgroundColor: rowBg, minWidth: 90, isolation: 'isolate' }}>{row.hcpcs}</td>
                          {/* Carelon — sticky col 4 */}
                          <td className="px-4 py-2.5 text-center border-b border-gray-100"
                            style={{ position: 'sticky', left: 430, zIndex: 10, backgroundColor: rowBgCarelon, minWidth: 80, boxShadow: '2px 0 4px rgba(0,0,0,0.06)', isolation: 'isolate' }}>
                            {row.carelon === 'Y'
                              ? <CheckCircle size={14} className="text-emerald-500 mx-auto" />
                              : <span className="text-xs font-bold text-red-500">Gap</span>}
                          </td>
                          {/* Competitor columns */}
                          {visibleComps.map(c => {
                            const cellKey = `${i}-${c}`;
                            const override = cellOverrides[cellKey]; // { covered: bool, note: string } | undefined
                            const isOriginalY = row[c] === 'Y';
                            const isManuallyAdded = override !== undefined;
                            const isChecked = override !== undefined ? override.covered : isOriginalY;
                            return (
                              <td key={c} className="px-4 py-2.5 text-center border-b border-gray-100 relative">
                                {(() => {
                                  const sameHcpcs = DRUGS.filter(d => d.hcpcs === row.hcpcs && d.drug !== row.drug);
                                  const compsCovering = COMP_KEYS.filter(k => {
                                    const ov = cellOverrides[`${DRUGS.indexOf(row)}-${k}`];
                                    return ov !== undefined ? ov.covered : row[k] === 'Y';
                                  });
                                  const tooltipContent = (
                                    <div className="bg-gray-900 text-white rounded-lg shadow-2xl p-2 text-left" style={{ width: 190 }}>
                                      <div className="mb-1.5">
                                        <p className="font-bold text-[10px] text-white leading-tight">{row.drug}</p>
                                      </div>
                                      <div className="flex items-center gap-1">
                                        <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">HCPCS</span>
                                        <span className="text-[9px] font-mono font-bold text-amber-400 bg-amber-400/10 px-1 py-px rounded">{row.hcpcs}</span>
                                        {isManuallyAdded && <span className="text-[8px] font-bold px-1 py-px rounded bg-orange-500 text-white">Manual</span>}
                                      </div>
                                    </div>
                                  );
                                  const handleMouseEnter = (e) => {
                                    const rect = e.currentTarget.getBoundingClientRect();
                                    setTooltip({ x: rect.left + rect.width / 2, y: rect.top, content: tooltipContent });
                                  };
                                  const handleMouseLeave = () => setTooltip(null);
                                  const openModal = () => setConfirmModal({
                                    cellKey, row, comp: c, compKey: c,
                                    localCovered: isChecked,
                                    localNote: override?.note ?? '',
                                  });
                                  if (isChecked) {
                                    return (
                                      <div className="mx-auto inline-block" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
                                        <button onClick={openModal} className="block">
                                          {isManuallyAdded
                                            ? <CheckCircle size={16} className="text-orange-500 mx-auto" />
                                            : <span className="text-base font-bold hover:opacity-70 transition-opacity" style={{ color: '#10b981' }}>✓</span>}
                                        </button>
                                      </div>
                                    );
                                  }
                                  return (
                                    <div className="mx-auto inline-block" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
                                      <button onClick={openModal} className="text-gray-300 text-sm hover:text-emerald-400 transition-colors">
                                        {isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : '—'}
                                      </button>
                                    </div>
                                  );
                                })()}
                              </td>
                            );
                          })}
                          {/* spacer cell for More button column */}
                          <td className="border-b border-gray-100" />
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
            <div className="px-5 py-2.5 border-t border-gray-100 flex items-center gap-3 text-xs text-gray-400 flex-wrap">
              <div className="flex items-center gap-4 flex-wrap">
                <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full inline-block" style={{backgroundColor:'#1A3673'}}/> Mandatory row</span>
                <span className="flex items-center gap-1 font-bold" style={{color:'#10b981'}}>✓</span><span>= Covered (source data)</span>
                <span className="flex items-center gap-1"><CheckCircle size={11} className="text-orange-500"/></span><span>= Manually added · click for Brand/Generic</span>
                <span className="flex items-center gap-1 text-gray-300">—</span><span>= Not covered · click to mark</span>
                <span className="text-red-500 font-bold">Gap</span><span>= Not on Carelon list</span>
              </div>
              <span className="ml-auto shrink-0">Scroll to view all · Sort any column header</span>
            </div>
          </div>

          {/* ══════════════════════════════════════════════
              SECTION 3 — Coverage Difference Analysis
          ══════════════════════════════════════════════ */}
          {(function CoverageSection() {
            const ov = COMP_OVERLAP[overlapComp] || COMP_OVERLAP['UHC'];
            return (
              <div className="card p-0 overflow-hidden">
                {/* Collapsible header */}
                <button
                  onClick={() => setCoverageOpen(o => !o)}
                  className="w-full flex items-center justify-between gap-3 px-5 py-4 hover:bg-gray-50 transition-colors text-left"
                >
                  <div>
                    <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Coverage Difference Analysis</p>
                    <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>Carelon vs. {overlapComp} — Side-by-Side Comparison</h2>
                    <p className="text-xs text-gray-400 mt-0.5">Normalized brand-name comparison · {ov.common + ov.carOnly + ov.compOnly} total unique drugs</p>
                  </div>
                  <ChevronDown size={15} className={`text-gray-400 transition-transform duration-200 shrink-0 ${coverageOpen ? 'rotate-180' : ''}`} />
                </button>

                {coverageOpen && (
                  <div className="px-5 pb-5 pt-1">
                    {/* Competitor switcher */}
                    <div className="flex items-center gap-2 mb-5" ref={overlapRef}>
                      <span className="text-xs text-gray-400 font-semibold">Compare vs:</span>
                      <div className="relative">
                        <button onClick={() => { setOverlapSearch(''); setOverlapDropOpen(o => !o); }}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-xs font-semibold text-brand-navy hover:border-brand-navy transition-colors min-w-[140px] justify-between">
                          <span>{overlapComp}</span>
                          <ChevronDown size={12} className={`text-gray-400 transition-transform ${overlapDropOpen ? 'rotate-180' : ''}`} />
                        </button>
                        {overlapDropOpen && (
                          <div className="absolute right-0 mt-1 w-52 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
                            <div className="p-2 border-b border-gray-100">
                              <div className="relative">
                                <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                                <input autoFocus className="w-full pl-7 pr-3 py-1.5 text-xs rounded-lg border border-gray-200 focus:outline-none focus:border-brand-navy"
                                  placeholder="Search competitor…" value={overlapSearch} onChange={e => setOverlapSearch(e.target.value)} />
                              </div>
                            </div>
                            <div className="max-h-48 overflow-y-auto py-1">
                              {COMPETITORS.filter(c => c.toLowerCase().includes(overlapSearch.toLowerCase())).map(c => (
                                <button key={c} onClick={() => { setOverlapComp(c); setOverlapDropOpen(false); }}
                                  className={`w-full text-left px-4 py-2 text-xs transition-colors ${overlapComp === c ? 'bg-brand-light text-brand-navy font-semibold' : 'text-gray-700 hover:bg-gray-50'}`}>{c}</button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    {/* Status summary bar */}
                    <div className="grid grid-cols-3 gap-3 mb-5">
                      {[
                        { label: 'Match (Both)',        value: ov.common,   bg: '#D9F5F5', color: '#00BBBA', icon: <CheckCircle size={14}/>,   sub: 'Present on both lists' },
                        { label: 'Carelon Only',         value: ov.carOnly,  bg: '#E1EDFF', color: '#1A3673', icon: <AlertTriangle size={14}/>, sub: 'Competitive advantage' },
                        { label: `${overlapComp} Only`,  value: ov.compOnly, bg: '#FBEAE7', color: '#E3725F', icon: <XCircle size={14}/>,       sub: 'Coverage gaps to review' },
                      ].map(m => (
                        <div key={m.label} className="rounded-xl p-4 flex items-center gap-3" style={{ backgroundColor: m.bg }}>
                          <div style={{ color: m.color }}>{m.icon}</div>
                          <div>
                            <p className="text-xl font-bold leading-none" style={{ color: m.color }}>{m.value}</p>
                            <p className="text-xs font-semibold text-gray-700 leading-tight mt-0.5">{m.label}</p>
                            <p className="text-xs text-gray-400">{m.sub}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    {/* Drug chip lists */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[
                        { label: 'Match',         sub: `${ov.common} drugs`,            dot: 'bg-emerald-500', bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-800', chip: 'bg-white border border-emerald-200 text-emerald-700', drugs: ov.commonDrugs },
                        { label: 'Carelon Only',   sub: `${ov.carOnly} drugs · advantage`, dot: 'bg-brand-navy',  bg: 'bg-blue-50',    border: 'border-blue-200',    text: 'text-brand-navy',  chip: 'bg-white border border-blue-200 text-brand-navy',   drugs: ov.carOnlyDrugs },
                        { label: 'Missing (Gap)',  sub: `${ov.compOnly} drugs · review`,   dot: 'bg-red-400',     bg: 'bg-red-50',     border: 'border-red-200',     text: 'text-red-700',     chip: 'bg-white border border-red-200 text-red-700',       drugs: ov.compOnlyDrugs },
                      ].map(cat => (
                        <div key={cat.label} className={`rounded-xl border p-4 ${cat.bg} ${cat.border}`}>
                          <div className="flex items-center gap-2 mb-1">
                            <div className={`w-2 h-2 rounded-full shrink-0 ${cat.dot}`} />
                            <p className={`text-xs font-bold uppercase tracking-wide ${cat.text}`}>{cat.label}</p>
                          </div>
                          <p className={`text-xs mb-3 pl-4 ${cat.text} opacity-60`}>{cat.sub}</p>
                          <div className="flex flex-wrap gap-1.5">
                            {cat.drugs.map(d => <span key={d} className={`px-2 py-0.5 rounded text-xs font-semibold ${cat.chip}`}>{d}</span>)}
                            <span className="px-2 py-0.5 rounded text-xs text-gray-400 border border-dashed border-gray-200">+ more…</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })()}

          {/* ══════════════════════════════════════════════
              SECTION 3b — Competitor Source Portfolio
          ══════════════════════════════════════════════ */}
          {(() => {
            const mandatoryDrugs = DRUGS.filter(d => d.programType === 'Mandatory');
            const voluntaryDrugs = DRUGS.filter(d => d.programType === 'Voluntary');
            const compMandatoryCoverage = COMP_KEYS.map(c => ({ name: c, count: mandatoryDrugs.filter(d => d[c] === 'Y').length })).sort((a,b) => b.count - a.count);
            const compVoluntaryCoverage = COMP_KEYS.map(c => ({ name: c, count: voluntaryDrugs.filter(d => d[c] === 'Y').length })).sort((a,b) => b.count - a.count);
            const compBothCoverage    = COMP_KEYS.map(c => ({ name: c, count: DRUGS.filter(d => d[c] === 'Y').length })).sort((a,b) => b.count - a.count);
            const compGapCoverage     = COMP_KEYS.map(c => ({ name: c, count: DRUGS.filter(d => d.carelon === 'N' && d[c] === 'Y').length })).sort((a,b) => b.count - a.count);
            const totalDrugs = DRUGS.length;
            const mandatoryTotal = mandatoryDrugs.length;
            const voluntaryTotal = voluntaryDrugs.length;
            const gapTotal = DRUGS.filter(d => d.carelon === 'N').length;
            const PORTFOLIO = [
              { label: 'Mandatory',      count: mandatoryTotal,  color: '#2861BB', bg: '#E1EDFF', competitors: compMandatoryCoverage.filter(c=>c.count>0) },
              { label: 'Voluntary',      count: voluntaryTotal,  color: '#00BBBA', bg: '#D9F5F5', competitors: compVoluntaryCoverage.filter(c=>c.count>0) },
              { label: 'Full Portfolio', count: totalDrugs,      color: '#7C3AED', bg: '#EDE9FE', competitors: compBothCoverage.filter(c=>c.count>0) },
              { label: 'Carelon Gaps',   count: gapTotal,        color: '#E3725F', bg: '#FDECEA', competitors: compGapCoverage.filter(c=>c.count>0) },
            ];
            const maxCount = Math.max(...PORTFOLIO.map(p => p.count));
            return (
              <div className="card p-0 overflow-hidden">
                <div className="px-5 py-4 border-b border-gray-100" style={{ backgroundColor: '#F8FAFF' }}>
                  <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Competitor Source Portfolio</p>
                  <h2 className="font-bold text-brand-navy" style={{ fontSize: 14 }}>Program status distribution from the uploaded workbook</h2>
                </div>
                <div className="px-5 py-5 space-y-4">
                  {PORTFOLIO.map(p => (
                    <div key={p.label}>
                      <button
                        className="w-full flex items-center gap-4 group text-left"
                        onClick={() => setPortfolioExpanded(portfolioExpanded === p.label ? null : p.label)}
                      >
                        {/* Label */}
                        <span className="text-sm font-bold text-brand-navy w-36 shrink-0">{p.label}</span>
                        {/* Bar */}
                        <div className="flex-1 h-8 rounded-md overflow-hidden bg-gray-100">
                          <div
                            className="h-full rounded-md transition-all duration-500"
                            style={{ width: `${(p.count / maxCount) * 100}%`, backgroundColor: p.color }}
                          />
                        </div>
                        {/* Count */}
                        <span className="text-sm font-bold text-brand-navy w-6 text-right shrink-0">{p.count}</span>
                        {/* Expand chevron */}
                        <ChevronDown size={13} className={`text-gray-400 shrink-0 transition-transform duration-200 ${portfolioExpanded === p.label ? 'rotate-180' : ''}`} />
                      </button>
                      {/* Expandable competitor list */}
                      {portfolioExpanded === p.label && (
                        <div className="mt-2 ml-40 flex flex-wrap gap-1.5">
                          {p.competitors.map(c => (
                            <span key={c.name} className="text-xs font-semibold px-2.5 py-0.5 rounded-full border flex items-center gap-1" style={{ backgroundColor: p.bg, color: p.color, borderColor: p.color + '44' }}>
                              {c.name}
                              <span className="text-[10px] font-bold opacity-70">·{c.count}</span>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {/* ══════════════════════════════════════════════
              SECTION 4 — AI Recommendations (focal point)
          ══════════════════════════════════════════════ */}
          <div className="card" style={{ border: '2px solid #E1EDFF' }}>
            {/* Header */}
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <div className="flex items-center justify-center w-7 h-7 rounded-lg shrink-0" style={{ backgroundColor: '#1A3673' }}>
                <Zap size={14} className="text-white" />
              </div>
              <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>AI Recommendations</h2>
              <span className="text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-full px-2.5 py-0.5 font-semibold">Human review required</span>
              {/* Filter tabs */}
              <div className="ml-auto flex items-center gap-1 text-xs">
                {['all', 'add', 'remove'].map(f => (
                  <button key={f} onClick={() => setRecFilter(f)}
                    className={`px-3 py-1 rounded-lg font-semibold border capitalize transition-all ${
                      recFilter === f
                        ? 'bg-brand-navy text-white border-brand-navy'
                        : 'bg-white text-gray-500 border-gray-200 hover:border-brand-navy'
                    }`}>{f === 'all' ? 'All' : f === 'add' ? '+ Additions' : '− Removals'}</button>
                ))}
                <div className="w-px h-4 bg-gray-200 mx-1" />
                {[5, 10].map(n => (
                  <button key={n} onClick={() => setAiTopN(n)}
                    className={`px-3 py-1 rounded-lg font-semibold border transition-all ${
                      aiTopN === n ? 'bg-brand-light text-brand-navy border-brand-navy' : 'bg-white text-gray-400 border-gray-200'
                    }`}>Top {n}</button>
                ))}
              </div>
            </div>
            <p className="text-xs text-gray-400 mb-5">AI-generated drug addition and removal recommendations based on competitor coverage patterns and market analysis.</p>

            {/* Recommendation cards */}
            <div className="space-y-3">
              {AI_RECS
                .filter(r => recFilter === 'all' || r.type === recFilter)
                .slice(0, aiTopN)
                .map((r, i) => {
                  const isAdd = r.type === 'add';
                  return (
                    <div key={i} className={`rounded-xl p-4 flex gap-4 border ${isAdd ? 'border-emerald-100 bg-emerald-50/40' : 'border-red-100 bg-red-50/30'}`}>
                      {/* Accent bar */}
                      <div className={`w-1 rounded-full shrink-0 self-stretch ${isAdd ? 'bg-emerald-400' : 'bg-red-400'}`} />
                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-3 flex-wrap mb-1.5">
                          <div>
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${isAdd ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                {isAdd ? '+ Add Drug' : '− Remove Drug'}
                              </span>
                              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                                r.impact === 'High' ? 'bg-red-50 text-red-600' : r.impact === 'Medium' ? 'bg-amber-50 text-amber-600' : 'bg-gray-100 text-gray-500'
                              }`}>{r.impact} Impact</span>
                            </div>
                            <p className="text-sm font-bold text-gray-800">{r.drug}</p>
                            <p className="text-xs text-gray-400">{r.drugClass}</p>
                          </div>
                          {/* Confidence score */}
                          <div className="shrink-0 text-right">
                            <p className="text-xs text-gray-400 font-semibold">AI Confidence</p>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <div className="w-20 bg-gray-100 rounded-full h-1.5">
                                <div className="h-1.5 rounded-full" style={{ width: `${r.confidence}%`, backgroundColor: r.confidence >= 85 ? '#10b981' : r.confidence >= 70 ? '#f59e0b' : '#ef4444' }} />
                              </div>
                              <span className="text-xs font-bold text-gray-700">{r.confidence}%</span>
                            </div>
                          </div>
                        </div>
                        <p className="text-xs text-gray-600 leading-relaxed">{r.reason}</p>
                        {r.competitors.length > 0 && (
                          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                            <span className="text-xs text-gray-400">{isAdd ? 'Covered by:' : 'Still covered by:'}</span>
                            {r.competitors.map(c => (
                              <span key={c} className={`text-xs font-semibold px-1.5 py-0.5 rounded ${isAdd ? 'bg-blue-50 text-blue-700' : 'bg-gray-100 text-gray-600'}`}>{c}</span>
                            ))}
                          </div>
                        )}
                      </div>
                      <button className="self-start text-xs font-semibold text-brand-navy flex items-center gap-1 hover:underline shrink-0 mt-1 whitespace-nowrap">
                        Review <ArrowRight size={11} />
                      </button>
                    </div>
                  );
              })}
            </div>
          </div>

        </div>
      ) : null}

      {/* ── Cell Edit Modal ── */}
      {confirmModal && (() => {
        const existingOverride = cellOverrides[confirmModal.cellKey];
        const hasOverride = existingOverride !== undefined;
        const setLocalCovered = (v) => setConfirmModal(m => ({ ...m, localCovered: v }));
        const setLocalNote = (v) => setConfirmModal(m => ({ ...m, localNote: v }));
        return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}
            onClick={() => setConfirmModal(null)}>
            <div className="bg-white rounded-xl shadow-xl mx-4 p-4" style={{ width: 280 }} onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-bold text-gray-900 text-xs">{confirmModal.row.drug}</p>
                </div>
                <button onClick={() => setConfirmModal(null)} className="text-gray-400 hover:text-gray-600 ml-2 shrink-0"><X size={14}/></button>
              </div>
              <div className="flex gap-2 mb-3">
                <button onClick={() => setLocalCovered(true)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${
                    confirmModal.localCovered ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-gray-200 bg-white text-gray-400'
                  }`}>
                  <CheckCircle size={12}/> Covered
                </button>
                <button onClick={() => setLocalCovered(false)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${
                    !confirmModal.localCovered ? 'border-red-400 bg-red-50 text-red-600' : 'border-gray-200 bg-white text-gray-400'
                  }`}>
                  <X size={12}/> Not Covered
                </button>
              </div>
              <input
                className="input text-xs py-1.5 w-full mb-3"
                placeholder="Add a note (optional)…"
                value={confirmModal.localNote}
                onChange={e => setLocalNote(e.target.value)}
              />
              <div className="flex gap-1.5">
                <button onClick={() => setConfirmModal(null)}
                  className="flex-1 py-1.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-500 hover:bg-gray-50">
                  Cancel
                </button>
                {hasOverride && (
                  <button
                    onClick={() => { setCellOverrides(prev => { const n = { ...prev }; delete n[confirmModal.cellKey]; return n; }); setConfirmModal(null); }}
                    className="px-2.5 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-xs font-semibold text-amber-700 hover:bg-amber-100 flex items-center gap-1">
                    <RefreshCw size={10}/> Revert
                  </button>
                )}
                <button
                  onClick={() => { setCellOverrides(prev => ({ ...prev, [confirmModal.cellKey]: { covered: confirmModal.localCovered, note: confirmModal.localNote } })); setConfirmModal(null); }}
                  className="flex-1 py-1.5 rounded-lg text-xs font-bold text-white"
                  style={{ backgroundColor: '#1A3673' }}>
                  Save
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Fixed-position tooltip portal — renders above all scroll containers */}
      {tooltip && (
        <div
          className="pointer-events-none"
          style={{
            position: 'fixed',
            left: tooltip.x,
            top: tooltip.y - 8,
            transform: 'translate(-50%, -100%)',
            zIndex: 99999,
          }}
        >
          {tooltip.content}
          <div className="w-2 h-2 bg-gray-900 rotate-45 mx-auto -mt-1" />
        </div>
      )}
    </div>
  );
}
