import { useNavigate } from 'react-router-dom';
import { FileSearch, Network, Pill, ArrowRight, MapPin } from 'lucide-react';

const MODULES = [
  {
    id: 'network',
    to: '/workflow/designated-network',
    icon: Network,
    color: '#00BBBA',
    bg: '#D9F5F5',
    label: 'Designated Network',
    sub: 'Compare Carelon white-bagging drug lists against competitor DN programs. Identify mandatory vs voluntary coverage gaps and opportunities.',
  },
  {
    id: 'preventive',
    to: '/workflow/preventive-rx',
    icon: Pill,
    color: '#E3725F',
    bg: '#FBEAE7',
    label: 'Preventive Rx',
    sub: 'Benchmark Carelon preventive drug lists across competitor payers. Single unified preventive list comparison.',
  },
  {
    id: 'clinical',
    to: '/workflow/clinical-criteria',
    icon: FileSearch,
    color: '#7C3AED',
    bg: '#EDE9FE',
    label: 'Clinical Criteria',
    sub: 'AI-powered competitor policy comparison for drug coverage criteria across UHC, Cigna, Aetna, and Caremark.',
  },
  {
    id: 'siteofcare',
    to: '/workflow/site-of-care',
    icon: MapPin,
    color: '#2861BB',
    bg: '#E3F4FD',
    label: 'Site of Care',
    sub: 'Analyze site-of-care policies and cost-sharing incentives across competitor plans.',
  },
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-full flex flex-col gap-6">

      {/* Hero banner */}
      <div className="bg-brand-navy rounded-2xl px-8 py-10 relative overflow-hidden">
        <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-2 opacity-10 pointer-events-none select-none">
          {[...Array(6)].map((_, i) => (
            <svg key={i} width="28" height="44" viewBox="0 0 28 44" fill="none">
              <path d="M4 4L24 22L4 40" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ))}
        </div>
        <div className="relative z-10 max-w-2xl">
          <p className="text-brand-blue text-xs font-bold tracking-widest uppercase mb-2">Carelon · Cost of Care</p>
          <h1 className="text-white font-bold mb-3" style={{ fontSize: 26 }}>RX Competitive Intelligence Platform</h1>
          <p className="text-white/60 text-sm leading-relaxed">
            AI-driven competitive analysis for Clinical Criteria, Designated Networks, and Preventive Rx — purpose-built for Carelon's Commercial business.
          </p>
        </div>
      </div>

      {/* Module tiles — 4 large cards in a 2×2 grid */}
      <div>
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Competitive Intelligence Modules</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {MODULES.map(m => {
            const Icon = m.icon;
            return (
              <button
                key={m.id}
                onClick={() => navigate(m.to)}
                className="group text-left rounded-2xl border border-gray-100 bg-white hover:shadow-lg transition-all duration-200 hover:-translate-y-1 cursor-pointer overflow-hidden flex flex-col"
              >
                {/* Top colored band with icon */}
                <div className="px-6 pt-7 pb-5 flex items-center gap-4" style={{ backgroundColor: m.bg }}>
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                    style={{ backgroundColor: m.color + '22', border: `1.5px solid ${m.color}44` }}
                  >
                    <Icon size={24} style={{ color: m.color }} />
                  </div>
                  <h3 className="font-bold text-brand-navy text-base leading-snug">{m.label}</h3>
                </div>

                {/* Body */}
                <div className="flex-1 px-6 py-5 flex flex-col gap-4">
                  <p className="text-sm text-gray-500 leading-relaxed flex-1">{m.sub}</p>
                  <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                    <span
                      className="text-xs font-bold uppercase tracking-wide"
                      style={{ color: m.color }}
                    >
                      Open Module
                    </span>
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center transition-transform group-hover:translate-x-1"
                      style={{ backgroundColor: m.bg }}
                    >
                      <ArrowRight size={14} style={{ color: m.color }} />
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <p className="text-center text-xs text-gray-300 pb-2">
        Carelon · RX Competitive Intelligence · LOB: Commercial · v1.0
      </p>
    </div>
  );
}
