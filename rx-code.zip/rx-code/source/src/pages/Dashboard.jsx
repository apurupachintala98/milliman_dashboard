import { useNavigate } from 'react-router-dom';
import { Plus, FolderKanban, CheckCircle, Clock, Eye, TrendingUp, Zap } from 'lucide-react';
import { useApp, can } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';

function StatCard({ label, value, icon: Icon, color }) {
  return (
    <div className="card flex items-center gap-4">
      <div className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
        <Icon size={22} className="text-white" />
      </div>
      <div>
        <p className="text-2xl font-bold text-brand-navy">{value}</p>
        <p className="text-xs text-gray-500 font-semibold">{label}</p>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { projects, currentUser } = useApp();
  const navigate = useNavigate();

  const stats = {
    total: projects.length,
    open: projects.filter(p => p.status === 'Open').length,
    review: projects.filter(p => p.status === 'Review').length,
    approved: projects.filter(p => p.status === 'Approved').length,
  };

  const recent = [...projects].sort((a, b) => b.updatedDate.localeCompare(a.updatedDate)).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-brand-navy">Dashboard</h1>
          <p className="text-sm text-gray-500">RX Competitive Intelligence · LOB: Commercial</p>
        </div>
        {can(currentUser, 'create') && (
          <button onClick={() => navigate('/projects/create')} className="btn-primary flex items-center gap-2">
            <Plus size={16} /> New Project
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Projects" value={stats.total} icon={FolderKanban} color="bg-brand-navy" />
        <StatCard label="Open" value={stats.open} icon={Clock} color="bg-brand-midLight" />
        <StatCard label="Pending Review" value={stats.review} icon={Eye} color="bg-brand-blue" />
        <StatCard label="Approved" value={stats.approved} icon={CheckCircle} color="bg-brand-teal" />
      </div>

      {/* Recent projects */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-brand-navy" style={{ fontSize: 16 }}>Recent Projects</h2>
          <button onClick={() => navigate('/projects')} className="text-xs text-brand-mid font-semibold hover:underline">
            View All
          </button>
        </div>
        <table className="w-full text-left">
          <thead>
            <tr>
              {['Project ID', 'Name', 'CI Type', 'Market', 'Status', 'Updated'].map(h => (
                <th key={h} className="table-header first:rounded-tl-md last:rounded-tr-md">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recent.map(p => (
              <tr
                key={p.id}
                className="hover:bg-brand-light cursor-pointer transition-colors"
                onClick={() => navigate(`/projects/${p.id}`)}
              >
                <td className="table-cell font-mono text-xs text-brand-mid">{p.id}</td>
                <td className="table-cell font-semibold">{p.name}</td>
                <td className="table-cell">
                  <span className="bg-brand-iceBlue text-brand-navy text-xs px-2 py-0.5 rounded font-semibold">{p.ciType}</span>
                </td>
                <td className="table-cell">{p.market}</td>
                <td className="table-cell"><StatusBadge status={p.status} /></td>
                <td className="table-cell text-xs text-gray-400">{p.updatedDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action needed: Review projects awaiting approval */}
      {projects.filter(p => p.status === 'Review').length > 0 && (
        <div className="card border-l-4 border-brand-blue bg-brand-iceBlue">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye size={16} className="text-brand-mid" />
              <p className="text-sm font-semibold text-brand-navy">
                {projects.filter(p => p.status === 'Review').length} project(s) awaiting analyst review
              </p>
            </div>
            <button onClick={() => navigate('/projects?status=Review')} className="btn-secondary text-xs">View →</button>
          </div>
          <div className="mt-2 space-y-1">
            {projects.filter(p => p.status === 'Review').slice(0, 3).map(p => (
              <button key={p.id} onClick={() => navigate(`/projects/${p.id}/review`)}
                className="flex items-center gap-2 text-xs text-brand-mid hover:text-brand-navy transition-colors w-full text-left">
                <Zap size={11} /> {p.name} — <span className="text-gray-400">{p.ciType}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Workflow Guide */}
      <div className="card bg-brand-navy text-white">
        <div className="flex items-center gap-3 mb-4">
          <TrendingUp size={20} />
          <h2 className="font-bold text-base">Project Workflow</h2>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {['In-Progress', 'Review', 'Approved'].map((s, i, arr) => (
            <div key={s} className="flex items-center gap-2">
              <span className={`text-xs px-3 py-1 rounded-full font-semibold ${
                s === 'In-Progress' ? 'bg-yellow-100 text-yellow-800'
                : s === 'Review' ? 'bg-brand-skyLight text-brand-navy'
                : 'bg-brand-tealPale text-teal-800'
              }`}>{s}</span>
              {i < arr.length - 1 && <span className="text-white/40">→</span>}
            </div>
          ))}
          <span className="text-white/40">|</span>
          {['Cancelled', 'Deferred'].map(s => (
            <span key={s} className="text-xs px-3 py-1 rounded-full font-semibold bg-white/10 text-white/70">{s}</span>
          ))}
        </div>
        <p className="text-xs text-white/60 mt-3">
          AI-generated intelligence moves to <strong className="text-white">Review</strong> status. Human-in-the-Loop review and approval required before export.
        </p>
      </div>
    </div>
  );
}
