import { useState, useMemo, useRef, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Download, ChevronUp, ChevronDown, CheckCircle, XCircle, BarChart2, Zap, Upload, FileText, X, Clock, RefreshCw, ArrowRight, FileSpreadsheet } from 'lucide-react';

const MARKETS = ['National', 'California', 'Texas', 'New York', 'Florida'];
const COMPETITORS = ['ESI', 'Optum RX', 'CVS', 'Humana', 'Kaiser', 'Aetna', 'UHC Expanded', 'Cigna All Preventives'];
const SNAPSHOTS = [
  { id: 'jul-2026', label: 'Jul 2026', date: 'Jul 1, 2026', competitor: 'ESI',      market: 'National', drugs: 22, status: 'Completed' },
  { id: 'jun-2026', label: 'Jun 2026', date: 'Jun 1, 2026', competitor: 'CVS',      market: 'National', drugs: 21, status: 'Completed' },
  { id: 'may-2026', label: 'May 2026', date: 'May 1, 2026', competitor: 'Optum RX', market: 'National', drugs: 20, status: 'Completed' },
  { id: 'apr-2026', label: 'Apr 2026', date: 'Apr 1, 2026', competitor: 'ESI',      market: 'National', drugs: 20, status: 'Completed' },
  { id: 'mar-2026', label: 'Mar 2026', date: 'Mar 1, 2026', competitor: 'CVS',      market: 'National', drugs: 19, status: 'Completed' },
  { id: 'feb-2026', label: 'Feb 2026', date: 'Feb 1, 2026', competitor: 'Optum RX', market: 'National', drugs: 18, status: 'Completed' },
];
const LIST_TYPES = ['ACA', 'HDHP', 'General', 'HAS', 'IRS', 'Pre-deductible', 'Preventive Rx'];

const CARELON_KEYS = [
  { key: 'carelonEnhanced', label: 'Enhanced (ASO)' },
  { key: 'carelonPlus',     label: 'Plus (FI)' },
  { key: 'carelonPlus2016', label: 'Plus 2016' },
];
const PBM_KEYS = [
  { key: 'esi',   label: 'ESI' },
  { key: 'optum', label: 'Optum RX' },
  { key: 'cvs',   label: 'CVS' },
];
const PLAN_KEYS = [
  { key: 'humana',       label: 'Humana' },
  { key: 'kaiser',       label: 'Kaiser' },
  { key: 'aetna',        label: 'Aetna' },
  { key: 'uhcExpanded',  label: 'UHC Expanded' },
  { key: 'uhcFederal',   label: 'UHC Federal' },
  { key: 'uhcUniversal', label: 'UHC Universal' },
  { key: 'cignaGeneric', label: 'Cigna Generic' },
  { key: 'cignaAll',     label: 'Cigna All Preventives' },
  { key: 'caBlueShield', label: 'CA Blue Shield' },
];
const COMP_KEYS = [...PBM_KEYS, ...PLAN_KEYS];

const DRUG_DATA = [
  { drug: 'Accolate', drugClass: 'Asthma', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'Y', cvs:'N', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Advair Diskus', drugClass: 'Asthma', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'N', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Alvesco', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Arnuity', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Asmanex', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Atrovent HFA', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Breo Ellipta', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Dulera', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Flovent Diskus', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Flovent HFA', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'fluticasone/salmeterol', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'N', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Incruse Ellipta', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'ipratropium bromide', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'levalbuterol HCl', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'montelukast', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Perforomist', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'ProAir HFA', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Proventil HFA', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Pulmicort Flexhaler', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Qvar', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Serevent Diskus', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Spiriva Respimat', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Stiolto Respimat', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Symbicort', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'tiotropium', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Trelegy Ellipta', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Tudorza Pressair', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Utibron Neohaler', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Ventolin HFA', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Wixela Inhub', drugClass: 'Asthma', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'aspirin', drugClass: 'Blood Clots and Stroke', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'clopidogrel', drugClass: 'Blood Clots and Stroke', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Eliquis', drugClass: 'Blood Clots and Stroke', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'warfarin', drugClass: 'Blood Clots and Stroke', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Xarelto', drugClass: 'Blood Clots and Stroke', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'atorvastatin', drugClass: 'Cholesterol', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'ezetimibe', drugClass: 'Cholesterol', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'lovastatin', drugClass: 'Cholesterol', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'pravastatin', drugClass: 'Cholesterol', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'rosuvastatin', drugClass: 'Cholesterol', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'simvastatin', drugClass: 'Cholesterol', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'glipizide', drugClass: 'Diabetes', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'glipizide ER', drugClass: 'Diabetes', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'insulin glargine', drugClass: 'Diabetes', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Jardiance', drugClass: 'Diabetes', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'metformin', drugClass: 'Diabetes', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Ozempic', drugClass: 'Diabetes', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Wegovy', drugClass: 'Diabetes', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'amlodipine', drugClass: 'Hypertension', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'chlorthalidone', drugClass: 'Hypertension', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'hydrochlorothiazide', drugClass: 'Hypertension', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'lisinopril', drugClass: 'Hypertension', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'losartan', drugClass: 'Hypertension', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'metoprolol', drugClass: 'Hypertension', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'folic acid', drugClass: 'Prenatal', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'prenatal vitamins', drugClass: 'Prenatal', carelonEnhanced:'Y', carelonPlus:'Y', carelonPlus2016:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { drug: 'Aimovig', drugClass: 'Migraine Prevention', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Ajovy', drugClass: 'Migraine Prevention', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Emgality 120 mg', drugClass: 'Migraine Prevention', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Qulipta', drugClass: 'Migraine Prevention', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Apretude', drugClass: 'Non-HIV Antivirals', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Beyfrotus', drugClass: 'Non-HIV Antivirals', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Prevymis', drugClass: 'Non-HIV Antivirals', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Synagis', drugClass: 'Non-HIV Antivirals', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'bupropion sr 150 tablets', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Chantix', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Nicoderm CQ', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Nicorette', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'nicotine gum and lozenges', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'nicotine patches', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Nicotrol NS', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'varenicline', drugClass: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Adipex-P', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Contrave', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Imcivree', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'N', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Orlistat', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'phentermine', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Qsymia', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Saxenda', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'Zepbound', drugClass: 'Weight Management', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { drug: 'buprenorphine sublingual', drugClass: 'Analgesics - Narcotic', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'N', humana:'N', kaiser:'N', aetna:'Y', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Zubsolv', drugClass: 'Analgesics - Narcotic', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'N', humana:'N', kaiser:'N', aetna:'Y', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'naltrexone', drugClass: 'Antidotes', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'N', cvs:'N', humana:'N', kaiser:'N', aetna:'Y', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'compro', drugClass: 'Antiemetics', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'Y', cvs:'N', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { drug: 'Equetro', drugClass: 'Bipolar Agents', carelonEnhanced:'N', carelonPlus:'N', carelonPlus2016:'N', esi:'N', optum:'Y', cvs:'N', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
];

const CLASS_DATA = [
  { cls: 'Asthma',                  carelonEnhanced:'Y', carelonPlus:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { cls: 'Blood Clots and Stroke',  carelonEnhanced:'Y', carelonPlus:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'N' },
  { cls: 'Cholesterol',             carelonEnhanced:'Y', carelonPlus:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { cls: 'Diabetes',                carelonEnhanced:'Y', carelonPlus:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { cls: 'Hypertension',            carelonEnhanced:'Y', carelonPlus:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { cls: 'Prenatal',                carelonEnhanced:'Y', carelonPlus:'Y', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'Y', aetna:'Y', uhcExpanded:'Y', uhcFederal:'Y', uhcUniversal:'Y', cignaGeneric:'Y', cignaAll:'Y', caBlueShield:'Y' },
  { cls: 'Migraine Prevention',     carelonEnhanced:'N', carelonPlus:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { cls: 'Non-HIV Antivirals',      carelonEnhanced:'N', carelonPlus:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'Y', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { cls: 'PPACA Smoking Cessation', carelonEnhanced:'N', carelonPlus:'N', esi:'Y', optum:'Y', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { cls: 'Weight Management',       carelonEnhanced:'N', carelonPlus:'N', esi:'Y', optum:'N', cvs:'Y', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'Y', caBlueShield:'N' },
  { cls: 'Analgesics - Narcotic',   carelonEnhanced:'N', carelonPlus:'N', esi:'N', optum:'N', cvs:'N', humana:'N', kaiser:'N', aetna:'Y', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { cls: 'Antidotes',               carelonEnhanced:'N', carelonPlus:'N', esi:'N', optum:'N', cvs:'N', humana:'N', kaiser:'N', aetna:'Y', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { cls: 'Antiemetics',             carelonEnhanced:'N', carelonPlus:'N', esi:'N', optum:'Y', cvs:'N', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
  { cls: 'Bipolar Agents',          carelonEnhanced:'N', carelonPlus:'N', esi:'N', optum:'Y', cvs:'N', humana:'N', kaiser:'N', aetna:'N', uhcExpanded:'N', uhcFederal:'N', uhcUniversal:'N', cignaGeneric:'N', cignaAll:'N', caBlueShield:'N' },
];

const STATUS_MAP = {
  'None':               { bg: 'bg-emerald-100 text-emerald-800', icon: <CheckCircle size={12} className="text-emerald-600" /> },
  'Coverage Gap':       { bg: 'bg-red-100 text-red-700',         icon: <XCircle size={12} className="text-red-500" /> },
  'Coverage Advantage': { bg: 'bg-blue-100 text-blue-700',       icon: <CheckCircle size={12} className="text-blue-600" /> },
};

const PRX_INTEL_RESULTS = {
  coverage: [
    { label: 'ESI Coverage Findings', items: ['Covers metformin, glipizide, aspirin, folic acid — fully aligned with Carelon', 'Covers Eliquis (apixaban) and Xarelto (rivaroxaban) on preventive list — Carelon gap', 'Covers Farxiga (dapagliflozin) for T2DM + CV risk — Carelon does not', 'Covers Jardiance (empagliflozin) under General preventive — Carelon gap', 'Does NOT cover fluticasone/salmeterol combo — Carelon advantage'] },
    { label: 'CVS / Optum Coverage Findings', items: ['CVS and Optum both cover Ozempic (semaglutide) under General preventive list', 'Mounjaro (tirzepatide) included by CVS — emerging trend for metabolic disease', 'Both cover prenatal vitamins and folic acid at parity with Carelon', 'CVS covers Advair Diskus brand where Optum prefers generic fluticasone/salmeterol', 'Neither covers warfarin on preventive list — Carelon advantage'] },
    { label: 'UHC Expanded / Cigna Findings', items: ['UHC Expanded covers Eliquis, Xarelto, Jardiance, Farxiga — broadest NOAC and SGLT-2 coverage', 'Cigna All Preventives covers Mounjaro and Ozempic — fullest GLP-1 coverage in market', 'Cigna covers Xarelto for stroke/DVT prevention under ACA preventive category', 'UHC Expanded does not cover warfarin on preventive list', 'Cigna covers Advair Diskus brand in addition to generic — most inclusive asthma list'] },
  ],
  gaps: [
    { label: 'Critical Coverage Gaps (Carelon)', items: ['Eliquis (apixaban): covered by UHC Expanded, Cigna — stroke/DVT prevention; ACA eligible', 'Xarelto (rivaroxaban): covered by ESI, UHC Expanded, Cigna — stroke/DVT prevention; ACA eligible', 'Ozempic (semaglutide): covered by CVS, UHC Expanded — T2DM prevention; General list', 'Jardiance (empagliflozin): covered by CVS, Optum, UHC — T2DM + CV risk; ACA/General', 'Mounjaro (tirzepatide): covered by CVS, Cigna — metabolic disease; emerging coverage trend', 'Farxiga (dapagliflozin): covered by ESI, CVS — T2DM + heart failure prevention; ACA'] },
    { label: 'Carelon Competitive Advantages', items: ['fluticasone/salmeterol (generic Advair): covered by Carelon; ESI and Humana do NOT cover', 'warfarin (Coumadin): covered by Carelon; Kaiser and Cigna do NOT cover on preventive list', 'Breo Ellipta: aligned with all major PBMs — no coverage gap identified', 'albuterol sulfate HFA, budesonide, montelukast: universal alignment — maintained strength', 'prenatal vitamins + folic acid: ACA-mandated — 100% parity across all competitors'] },
    { label: 'List Type Alignment Notes', items: ['ACA list: highest parity across competitors — focus expansion efforts here first', 'HDHP/HSA pre-deductible: fewer drugs eligible; confirm IRS eligibility before adding GLP-1s', 'General preventive: broadest competitor coverage — most GLP-1/SGLT-2 drugs added here', 'Cigna "All Preventives" list covers IRS + ACA + employer additions — broadest scope', 'UHC Expanded: adds beyond ACA baseline — second broadest scope in this comparison'] },
  ],
  recs: [
    { title: 'Priority 1: GLP-1 & SGLT-2 Evaluation', body: 'Ozempic, Jardiance, Mounjaro, and Farxiga are covered by 3–4 competitors. Evaluate adding to General preventive list under T2DM + CV risk reduction indication. Confirm IRS/HDHP eligibility before HDHP list inclusion.', color: '#f59e0b' },
    { title: 'Priority 2: NOAC Coverage for Stroke Prevention', body: 'Eliquis and Xarelto are covered by ESI, UHC Expanded, and Cigna for stroke/DVT prevention. These are ACA-eligible. Prioritize formulary committee review before Q1 2027 annual list update.', color: '#ef4444' },
    { title: 'Maintain Carelon Advantages', body: 'Carelon uniquely covers fluticasone/salmeterol (generic Advair) and warfarin where competitors do not. Document these as member access differentiators in next market communication.', color: '#10b981' },
  ],
};

const RECS = [
  { title: 'Diabetes Gap — GLP-1s & SGLT-2s',        body: 'Ozempic, Jardiance, Mounjaro, and Farxiga are covered by CVS, UHC Expanded, ESI, and Optum on preventive lists. Carelon does not cover these. With GLP-1 market momentum, evaluate ACA/General preventive coverage for T2DM + CV risk reduction indications.',              color: '#f59e0b' },
  { title: 'Blood Clots Gap — NOACs',                body: 'Eliquis (apixaban) and Xarelto (rivaroxaban) are on preventive lists at UHC Expanded and ESI for stroke/DVT prevention. Carelon does not cover. These are high-cost, high-utilization drugs — prioritize coverage review before next annual list cycle.',                color: '#ef4444' },
  { title: 'Carelon Strength — Generic Alignment',   body: 'Carelon covers fluticasone/salmeterol (generic Advair) and warfarin where Optum, Humana, Kaiser do not on preventive lists. These are meaningful access differentiators. Maintain and document these advantages in member-facing communications.',  color: '#10b981' },
];

export default function PreventiveRxWorkflow() {
  const [searchParams] = useSearchParams();
  const [market, setMarket]       = useState(MARKETS[0]);
  const [competitor, setCompetitor] = useState(COMPETITORS[0]);
  const urlSnapshot = searchParams.get('snapshot');
  const [snapshot, setSnapshot]   = useState(urlSnapshot || SNAPSHOTS[0].id);

  useEffect(() => {
    if (urlSnapshot && SNAPSHOTS.some(s => s.id === urlSnapshot)) {
      setSnapshot(urlSnapshot);
    }
  }, [urlSnapshot]);
  const [setupOpen, setSetupOpen] = useState(true);
  const [exportOpen, setExportOpen] = useState(false);
  const [cellOverrides, setCellOverrides] = useState({});
  const [cellNote, setCellNote] = useState(null);
  const [confirmModal, setConfirmModal] = useState(null);
  const [tooltip, setTooltip] = useState(null); // { x, y, content }
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadSource, setUploadSource] = useState('carelon');
  const [tableSearch, setTableSearch] = useState('');
  const fileInputRef = useRef(null);
  const exportRef = useRef(null);

  function handleFileUpload(e) {
    const file = e.target.files?.[0];
    if (file) setUploadedFile(file);
    e.target.value = '';
  }
  const [search, setSearch]       = useState('');
  const [view, setView]           = useState('drug');
  const [diffFilter, setDiffFilter] = useState('all');
  const [sortCol, setSortCol]     = useState('drug');
  const [sortDir, setSortDir]     = useState('asc');
  const [aiTopN, setAiTopN]       = useState(5);
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated]   = useState(true);
  const [reportStatus, setReportStatus] = useState('in-progress');

  function handleGenerate() {
    setGenerating(true);
    setGenerated(false);
    setReportStatus('in-progress');
    setTimeout(() => { setGenerating(false); setGenerated(true); setReportStatus('in-review'); }, 2500);
  }

  function toggleSort(col) {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  }

  const allCarelonKeys = CARELON_KEYS.map(c => c.key);
  const allCompKeys    = COMP_KEYS.map(c => c.key);

  const filtered = useMemo(() => {
    const q = (search || tableSearch).toLowerCase();
    let rows = DRUG_DATA.filter(r => {
      if (q && !r.drug.toLowerCase().includes(q) && !r.drugClass.toLowerCase().includes(q)) return false;
      if (diffFilter === 'carelonOnly') return allCarelonKeys.some(k => r[k] === 'Y') && allCompKeys.every(k => r[k] === 'N');
      if (diffFilter === 'compOnly')   return allCarelonKeys.every(k => r[k] === 'N') && allCompKeys.some(k => r[k] === 'Y');
      if (diffFilter === 'common')     return allCarelonKeys.some(k => r[k] === 'Y') && allCompKeys.some(k => r[k] === 'Y');
      return true;
    });
    return [...rows].sort((a, b) => {
      const av = a[sortCol] || ''; const bv = b[sortCol] || '';
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  }, [search, tableSearch, diffFilter, sortCol, sortDir]);


  const carelonCoveredCount = DRUG_DATA.filter(d => allCarelonKeys.some(k => d[k] === 'Y')).length;
  const compOnlyCount       = DRUG_DATA.filter(d => allCarelonKeys.every(k => d[k] === 'N') && allCompKeys.some(k => d[k] === 'Y')).length;
  const carelonOnlyCount    = DRUG_DATA.filter(d => allCarelonKeys.some(k => d[k] === 'Y') && allCompKeys.every(k => d[k] === 'N')).length;
  const commonCount         = DRUG_DATA.filter(d => allCarelonKeys.some(k => d[k] === 'Y') && allCompKeys.some(k => d[k] === 'Y')).length;

  const kpis = [
    { label: 'Total Drugs',        value: DRUG_DATA.length,      color: 'text-brand-navy',  bg: 'bg-brand-light' },
    { label: 'Carelon Covered',    value: carelonCoveredCount,   color: 'text-emerald-700', bg: 'bg-emerald-50' },
    { label: 'Common (Both)',      value: commonCount,           color: 'text-teal-700',    bg: 'bg-teal-50' },
    { label: 'Carelon Only',       value: carelonOnlyCount,      color: 'text-blue-700',    bg: 'bg-blue-50' },
    { label: 'Competitor Only',    value: compOnlyCount,         color: 'text-amber-700',   bg: 'bg-amber-50' },
  ];

  return (
    <div className="space-y-5">

      {/* ── Page Header ── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Preventive Rx</p>
          <h1 className="text-2xl font-bold text-brand-navy">Preventive Drug List Comparison</h1>
          <p className="text-xs text-gray-400 mt-1">Compare Carelon's preventive drug list against competitor PBMs · Identify coverage gaps and advantages</p>
        </div>
        <div className="flex items-center gap-2" ref={exportRef}>
          <button
            onClick={() => reportStatus === 'approved' && setExportOpen(o => !o)}
            disabled={reportStatus !== 'approved'}
            title={reportStatus !== 'approved' ? 'Approve the report to enable export' : 'Export report'}
            className={`btn-secondary flex items-center gap-2 text-xs transition-all ${reportStatus !== 'approved' ? 'opacity-40 cursor-not-allowed' : ''}`}>
            <Download size={14} /> Export <ChevronDown size={12} className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`} />
          </button>
          {exportOpen && (
            <div className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
              {[
                { label: 'PowerPoint (.pptx)', icon: <FileText size={13} className="text-orange-500" /> },
                { label: 'PDF (.pdf)',          icon: <FileText size={13} className="text-red-500" /> },
                { label: 'Excel (.xlsx)',       icon: <FileSpreadsheet size={13} className="text-emerald-600" /> },
              ].map(opt => (
                <button key={opt.label} onClick={() => setExportOpen(false)}
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                  {opt.icon} {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>


      {/* ── Action Bar ── */}
      <div className="card py-3 px-4">
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={handleGenerate} disabled={generating}
            className={`btn-primary flex items-center gap-2 px-5 py-2 text-sm font-semibold ${generating ? 'opacity-70 cursor-not-allowed' : ''}`}>
            <Zap size={15} /> {generating ? 'Generating...' : 'Generate Intelligence'}
          </button>
          <div className="h-6 w-px bg-gray-200" />
          <input ref={fileInputRef} type="file" accept=".pdf,.xlsx,.xls,.csv,.docx" className="hidden" onChange={handleFileUpload} />
          {uploadedFile ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
              <CheckCircle size={13} className="text-emerald-600 shrink-0" />
              <span className="font-semibold text-emerald-800 max-w-[180px] truncate">{uploadedFile.name}</span>
              <button onClick={() => setUploadedFile(null)} className="ml-1 text-gray-400 hover:text-red-500"><X size={12} /></button>
            </div>
          ) : (
            <button onClick={() => fileInputRef.current?.click()} className="btn-secondary flex items-center gap-1.5 text-xs">
              <Upload size={13} /> Upload Drug List
            </button>
          )}

          {/* ── Status pipeline ── */}
          <div className="h-6 w-px bg-gray-200" />
          <div className="flex items-center gap-1.5">
            {[
              { key: 'in-progress', label: 'In Progress', activeColor: '#D97706', activeBg: '#FEF3C7', activeBorder: '#FCD34D', dot: 'bg-amber-500' },
              { key: 'in-review',   label: 'In Review',   activeColor: '#1D4ED8', activeBg: '#EFF6FF', activeBorder: '#93C5FD', dot: 'bg-blue-500' },
              { key: 'approved',    label: 'Approved',    activeColor: '#059669', activeBg: '#ECFDF5', activeBorder: '#6EE7B7', dot: 'bg-emerald-500' },
            ].map((step, idx) => {
              const steps = ['in-progress', 'in-review', 'approved'];
              const currentIdx = steps.indexOf(reportStatus);
              const stepIdx = steps.indexOf(step.key);
              const isActive = reportStatus === step.key;
              const isDone = stepIdx < currentIdx;
              return (
                <div key={step.key} className="flex items-center gap-1.5">
                  {idx > 0 && <div className={`w-5 h-px ${isDone || isActive ? 'bg-gray-400' : 'bg-gray-200'}`} />}
                  <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                    isActive ? 'border-current' : isDone ? 'bg-gray-50 text-gray-400 border-gray-200' : 'bg-white text-gray-300 border-gray-100'
                  }`} style={isActive ? { backgroundColor: step.activeBg, color: step.activeColor, borderColor: step.activeBorder } : {}}>
                    {isActive && step.key !== 'approved' && <span className={`w-1.5 h-1.5 rounded-full ${step.dot} ${step.key === 'in-progress' ? 'animate-pulse' : ''}`} />}
                    {((isActive && step.key === 'approved') || isDone) ? <CheckCircle size={10} className={isDone ? 'text-gray-400' : 'text-emerald-500'} /> : null}
                    {step.label}
                  </span>
                </div>
              );
            })}
            {reportStatus === 'in-review' && (
              <button onClick={() => setReportStatus('approved')}
                className="ml-1 flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 transition-colors">
                <CheckCircle size={11} /> Approve
              </button>
            )}
            {reportStatus === 'approved' && (
              <button onClick={() => setReportStatus('in-review')} className="ml-1 text-[10px] text-gray-400 hover:text-red-400 underline">Revoke</button>
            )}
          </div>
        </div>
      </div>

      {/* Generating spinner */}
      {generating && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
          <div className="flex-1">
            <p className="text-brand-navy text-sm font-semibold">Generating intelligence…</p>
            <div className="flex gap-4 mt-1.5 text-xs text-blue-600">
              {['Analyzing coverage','Mapping list types','Identifying gaps','Generating recommendations'].map((s,i) => (
                <span key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay: `${i*200}ms` }} />{s}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {!generated && !generating ? (
        <div className="card flex flex-col items-center justify-center py-16 gap-4 border-2 border-dashed border-gray-200 bg-gray-50">
          <Zap size={36} className="text-gray-300" />
          <div className="text-center">
            <p className="text-sm font-semibold text-gray-500">Results will appear here</p>
            <p className="text-xs text-gray-400 mt-1">Select your parameters and click <strong>Generate Intelligence</strong> to begin</p>
          </div>
        </div>
      ) : generated ? (
        <div className="space-y-5">

      {/* Filter + View toggle — single row */}
      <div className="flex flex-wrap items-center gap-3 text-xs">
        <span className="text-gray-400 font-semibold">Filter:</span>
        {[
          { id: 'common',      label: 'Common (Both)',    bg: 'bg-emerald-100 text-emerald-800' },
          { id: 'carelonOnly', label: 'Carelon Only',     bg: 'bg-blue-100 text-blue-800' },
          { id: 'compOnly',    label: 'Competitor Only',  bg: 'bg-amber-100 text-amber-800' },
        ].map(f => (
          <button key={f.id} onClick={() => setDiffFilter(diffFilter === f.id ? 'all' : f.id)}
            className={`px-3 py-1 rounded-full font-semibold border transition-all ${
              diffFilter === f.id ? f.bg + ' border-current' : 'bg-white border-gray-200 text-gray-500 hover:border-gray-400'
            }`}>{f.label}
          </button>
        ))}
        {diffFilter !== 'all' && <button onClick={() => setDiffFilter('all')} className="text-brand-mid underline">Clear</button>}
        <div className="ml-auto flex items-center gap-2">
          <span className="text-gray-400 font-semibold">View:</span>
          {[{ id: 'drug', label: 'By Drug' }, { id: 'class', label: 'By Drug Class' }].map(v => (
            <button key={v.id} onClick={() => setView(v.id)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold border transition-all ${view === v.id ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-navy'}`}>
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* Drug table */}
      {view === 'drug' ? (
        <div className="card p-0 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input className="input pl-9 text-sm py-1.5 w-full" placeholder="Search by drug name or disease state…"
                value={tableSearch} onChange={e => setTableSearch(e.target.value)} />
            </div>
            {tableSearch && (
              <button onClick={() => setTableSearch('')} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1"><X size={12} /> Clear</button>
            )}
            <span className="ml-auto text-xs text-gray-400">{filtered.length} drugs</span>
          </div>
          <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 460 }}>
            {/* Disease State=140, Drug=160 → left offsets: 0, 140 → Carelon starts at 300, each carelon col=110 → 3 cols=330 → shadow at 630 */}
            <table className="text-left" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
              <thead className="sticky top-0 z-20">
                {/* Row 1 — group labels */}
                <tr>
                  {/* Sticky: Disease State + Drug placeholder */}
                  <th colSpan={2} className="px-4 py-2 bg-white border-b border-gray-100"
                    style={{ position: 'sticky', left: 0, zIndex: 22 }} />
                  {/* Sticky: CarelonRx group */}
                  <th colSpan={CARELON_KEYS.length}
                    className="px-3 py-2 text-xs font-bold text-blue-800 text-center bg-blue-100 border-b border-blue-200 whitespace-nowrap tracking-wide uppercase"
                    style={{ position: 'sticky', left: 300, zIndex: 22 }}>
                    CarelonRx
                  </th>
                  {/* Scrollable group headers */}
                  <th colSpan={PBM_KEYS.length} className="px-3 py-2 text-xs font-bold text-orange-800 text-center bg-orange-50 border-b border-orange-200 whitespace-nowrap tracking-wide uppercase">Pharmacy Benefit Managers (PBMs)</th>
                  <th colSpan={PLAN_KEYS.length} className="px-3 py-2 text-xs font-bold text-purple-800 text-center bg-purple-50 border-b border-purple-200 whitespace-nowrap tracking-wide uppercase">Health Plans / Insurers</th>
                </tr>
                {/* Row 2 — column labels */}
                <tr>
                  {/* Disease State sticky */}
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer select-none whitespace-nowrap bg-gray-50 border-b border-gray-200"
                    style={{ position: 'sticky', left: 0, zIndex: 21, minWidth: 140 }}
                    onClick={() => toggleSort('drugClass')}>
                    <div className="flex items-center gap-1">Disease State
                      {sortCol==='drugClass' ? (sortDir==='asc' ? <ChevronUp size={12} className="text-brand-navy" /> : <ChevronDown size={12} className="text-brand-navy" />) : <ChevronUp size={12} className="text-gray-300" />}
                    </div>
                  </th>
                  {/* Drug sticky */}
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer select-none whitespace-nowrap bg-gray-50 border-b border-gray-200"
                    style={{ position: 'sticky', left: 140, zIndex: 21, minWidth: 160 }}
                    onClick={() => toggleSort('drug')}>
                    <div className="flex items-center gap-1">Drug
                      {sortCol==='drug' ? (sortDir==='asc' ? <ChevronUp size={12} className="text-brand-navy" /> : <ChevronDown size={12} className="text-brand-navy" />) : <ChevronUp size={12} className="text-gray-300" />}
                    </div>
                  </th>
                  {/* CarelonRx cols sticky */}
                  {CARELON_KEYS.map((c, ci) => (
                    <th key={c.key}
                      className="px-3 py-2 text-xs font-semibold text-blue-800 text-center whitespace-nowrap bg-blue-50 border-b border-gray-200"
                      style={{
                        position: 'sticky', left: 300 + ci * 110, zIndex: 21, minWidth: 110,
                        boxShadow: ci === CARELON_KEYS.length - 1 ? '2px 0 4px rgba(0,0,0,0.06)' : undefined,
                      }}>
                      {c.label}
                    </th>
                  ))}
                  {/* Scrollable PBM cols */}
                  {PBM_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-orange-700 text-center whitespace-nowrap bg-orange-50 border-b border-gray-200" style={{ minWidth: 90 }}>{c.label}</th>
                  ))}
                  {/* Scrollable Health Plan cols */}
                  {PLAN_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-purple-700 text-center whitespace-nowrap bg-purple-50 border-b border-gray-200" style={{ minWidth: 110 }}>{c.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(() => {
                  const makeTooltipContent = (drugRow, manuallyAdded, sameClsList, coveringComps) => (
                    <div className="bg-gray-900 text-white rounded-lg shadow-2xl p-2 text-left" style={{ width: 190 }}>
                      <div className="flex items-start justify-between gap-1.5 mb-1.5">
                        <div>
                          <p className="font-bold text-[10px] text-white leading-tight">{drugRow.drug}</p>
                          <p className="text-[9px] text-gray-300 mt-px">{drugRow.drugClass}</p>
                        </div>
                        {manuallyAdded && <span className="text-[8px] font-bold px-1 py-px rounded bg-orange-500 text-white shrink-0">Manual</span>}
                      </div>
                      <p className="text-[8px] text-gray-400 uppercase tracking-wider font-bold mb-1">Competitors Covering</p>
                      <div className="flex flex-wrap gap-0.5 mb-1.5 pb-1.5 border-b border-white/10">
                        {coveringComps.length > 0
                          ? coveringComps.map(ck => <span key={ck.key} className="text-[8px] font-semibold px-1 py-px rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">{ck.label}</span>)
                          : <span className="text-[9px] text-gray-500">None</span>}
                      </div>
                      {sameClsList.length > 0 && (
                        <>
                          <p className="text-[8px] text-gray-400 uppercase tracking-wider font-bold mb-1">{drugRow.drugClass} — Others</p>
                          <div className="space-y-1 max-h-24 overflow-y-auto">
                            {sameClsList.map(d => {
                              const dComps = COMP_KEYS.filter(ck => d[ck.key] === 'Y');
                              return (
                                <div key={d.drug} className="rounded bg-white/5 px-1.5 py-0.5">
                                  <p className="text-[9px] font-bold text-white leading-tight">{d.drug}</p>
                                  <div className="flex flex-wrap gap-0.5 mt-0.5">
                                    {dComps.length > 0
                                      ? dComps.map(ck => <span key={ck.key} className="text-[8px] px-1 py-px rounded bg-blue-500/20 text-blue-300">{ck.label}</span>)
                                      : <span className="text-[8px] text-gray-500">No coverage</span>}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </>
                      )}
                    </div>
                  );
                  return filtered.map((row, i) => (
                  <tr key={i} className="hover:bg-blue-50/10 transition-colors">
                    {/* Disease State — sticky */}
                    <td className="px-4 py-2.5 text-xs text-gray-500 whitespace-nowrap border-b border-gray-100"
                      style={{ position: 'sticky', left: 0, zIndex: 10, backgroundColor: '#fff', minWidth: 140 }}>{row.drugClass}</td>
                    {/* Drug — sticky */}
                    <td className="px-4 py-2.5 text-sm font-semibold text-brand-navy whitespace-nowrap border-b border-gray-100"
                      style={{ position: 'sticky', left: 140, zIndex: 10, backgroundColor: '#fff', minWidth: 160 }}>{row.drug}</td>
                    {/* CarelonRx cols — sticky */}
                    {CARELON_KEYS.map((c, ci) => {
                      const cellKey = `${i}-${c.key}`;
                      const override = cellOverrides[cellKey]; // { covered, note } | undefined
                      const isOriginalY = row[c.key] === 'Y';
                      const isManuallyAdded = override !== undefined;
                      const isChecked = override !== undefined ? override.covered : isOriginalY;
                      const sameCls = DRUG_DATA.filter(d => d.drugClass === row.drugClass && d.drug !== row.drug);
                      const compsCovering = COMP_KEYS.filter(ck => row[ck.key] === 'Y');
                      const prxContent = makeTooltipContent(row, isManuallyAdded, sameCls, compsCovering);
                      const handleME = (e) => { const r = e.currentTarget.getBoundingClientRect(); setTooltip({ x: r.left + r.width / 2, y: r.top, content: prxContent }); };
                      const handleML = () => setTooltip(null);
                      const openModal = () => setConfirmModal({ cellKey, row, comp: c.label, compKey: c.key, localCovered: isChecked, localNote: override?.note ?? '' });
                      return (
                        <td key={c.key} className="px-3 py-2.5 text-center border-b border-gray-100 relative"
                          style={{
                            position: 'sticky', left: 300 + ci * 110, zIndex: 10,
                            backgroundColor: '#EFF6FF', minWidth: 110,
                            boxShadow: ci === CARELON_KEYS.length - 1 ? '2px 0 4px rgba(0,0,0,0.06)' : undefined,
                          }}>
                          <div className="mx-auto inline-block" onMouseEnter={handleME} onMouseLeave={handleML}>
                            <button onClick={openModal} className="mx-auto block">
                              {isChecked
                                ? (isManuallyAdded ? <CheckCircle size={16} className="text-orange-500 mx-auto" /> : <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>)
                                : (isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : <span className="text-gray-200 text-sm hover:text-emerald-400 transition-colors">—</span>)
                              }
                            </button>
                          </div>
                        </td>
                      );
                    })}
                    {/* PBM cols — scrollable */}
                    {PBM_KEYS.map(c => {
                      const cellKey = `${i}-${c.key}`;
                      const override = cellOverrides[cellKey]; // { covered, note } | undefined
                      const isOriginalY = row[c.key] === 'Y';
                      const isManuallyAdded = override !== undefined;
                      const isChecked = override !== undefined ? override.covered : isOriginalY;
                      const sameCls2 = DRUG_DATA.filter(d => d.drugClass === row.drugClass && d.drug !== row.drug);
                      const compsCovering2 = COMP_KEYS.filter(ck => row[ck.key] === 'Y');
                      const pbmContent = makeTooltipContent(row, isManuallyAdded, sameCls2, compsCovering2);
                      const handleME2 = (e) => { const r = e.currentTarget.getBoundingClientRect(); setTooltip({ x: r.left + r.width / 2, y: r.top, content: pbmContent }); };
                      const handleML2 = () => setTooltip(null);
                      const openModal2 = () => setConfirmModal({ cellKey, row, comp: c.label, compKey: c.key, localCovered: isChecked, localNote: override?.note ?? '' });
                      return (
                        <td key={c.key} className="px-3 py-2.5 text-center border-b border-gray-100 relative" style={{ backgroundColor: 'rgba(255,237,213,0.3)', minWidth: 90 }}>
                          <div className="mx-auto inline-block" onMouseEnter={handleME2} onMouseLeave={handleML2}>
                            <button onClick={openModal2} className="mx-auto block">
                              {isChecked
                                ? (isManuallyAdded ? <CheckCircle size={16} className="text-orange-500 mx-auto" /> : <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>)
                                : (isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : <span className="text-gray-200 text-sm hover:text-emerald-400 transition-colors">—</span>)
                              }
                            </button>
                          </div>
                        </td>
                      );
                    })}
                    {/* Health Plan cols — scrollable */}
                    {PLAN_KEYS.map(c => {
                      const cellKey = `${i}-${c.key}`;
                      const override = cellOverrides[cellKey]; // { covered, note } | undefined
                      const isOriginalY = row[c.key] === 'Y';
                      const isManuallyAdded = override !== undefined;
                      const isChecked = override !== undefined ? override.covered : isOriginalY;
                      const sameCls3 = DRUG_DATA.filter(d => d.drugClass === row.drugClass && d.drug !== row.drug);
                      const compsCovering3 = COMP_KEYS.filter(ck => row[ck.key] === 'Y');
                      const planContent = makeTooltipContent(row, isManuallyAdded, sameCls3, compsCovering3);
                      const handleME3 = (e) => { const r = e.currentTarget.getBoundingClientRect(); setTooltip({ x: r.left + r.width / 2, y: r.top, content: planContent }); };
                      const handleML3 = () => setTooltip(null);
                      const openModal3 = () => setConfirmModal({ cellKey, row, comp: c.label, compKey: c.key, localCovered: isChecked, localNote: override?.note ?? '' });
                      return (
                        <td key={c.key} className="px-3 py-2.5 text-center border-b border-gray-100 relative" style={{ backgroundColor: 'rgba(245,243,255,0.4)', minWidth: 110 }}>
                          <div className="mx-auto inline-block" onMouseEnter={handleME3} onMouseLeave={handleML3}>
                            <button onClick={openModal3} className="mx-auto block">
                              {isChecked
                                ? (isManuallyAdded ? <CheckCircle size={16} className="text-orange-500 mx-auto" /> : <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>)
                                : (isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : <span className="text-gray-200 text-sm hover:text-emerald-400 transition-colors">—</span>)
                              }
                            </button>
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ));
                })()}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-2.5 border-t border-gray-100 flex items-center gap-4 text-xs text-gray-400 flex-wrap">
            <span className="flex items-center gap-1 font-bold" style={{ color: '#10b981' }}>✓</span><span>= Covered (source data)</span>
            <span className="flex items-center gap-1"><CheckCircle size={11} className="text-orange-500" /></span><span>= Manually added · click for Brand/Generic</span>
            <span className="flex items-center gap-1 text-gray-300">—</span><span>= Not covered · click to mark</span>
            <span className="ml-auto shrink-0">{filtered.length} drugs · scroll horizontally for all competitors</span>
          </div>
        </div>
      ) : (
        <div className="card p-0 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input className="input pl-9 text-sm py-1.5 w-full" placeholder="Search by drug class…"
                value={tableSearch} onChange={e => setTableSearch(e.target.value)} />
            </div>
            {tableSearch && (
              <button onClick={() => setTableSearch('')} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1"><X size={12} /> Clear</button>
            )}
            <span className="ml-auto text-xs text-gray-400">
              {CLASS_DATA.filter(r => !tableSearch || r.cls.toLowerCase().includes(tableSearch.toLowerCase())).length} classes
            </span>
          </div>
          <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 460 }}>
            <table className="w-full text-left min-w-max">
              <thead className="sticky top-0 z-10 border-b border-gray-200">
                <tr>
                  <th className="px-4 py-2 bg-white border-b border-gray-100" />
                  <th colSpan={CARELON_KEYS.length} className="px-3 py-2 text-xs font-bold text-blue-800 text-center bg-blue-100 border-b border-blue-200 uppercase tracking-wide">CarelonRx</th>
                  <th colSpan={PBM_KEYS.length} className="px-3 py-2 text-xs font-bold text-orange-800 text-center bg-orange-50 border-b border-orange-200 uppercase tracking-wide">Pharmacy Benefit Managers (PBMs)</th>
                  <th colSpan={PLAN_KEYS.length} className="px-3 py-2 text-xs font-bold text-purple-800 text-center bg-purple-50 border-b border-purple-200 uppercase tracking-wide">Health Plans / Insurers</th>
                </tr>
                <tr className="bg-gray-50">
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Drug Class</th>
                  {CARELON_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-blue-800 text-center whitespace-nowrap bg-blue-50">{c.label}</th>
                  ))}
                  {PBM_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-orange-700 text-center whitespace-nowrap bg-orange-50">{c.label}</th>
                  ))}
                  {PLAN_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-purple-700 text-center whitespace-nowrap bg-purple-50">{c.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {CLASS_DATA
                  .filter(r => !tableSearch || r.cls.toLowerCase().includes(tableSearch.toLowerCase()))
                  .map((row, i) => (
                    <tr key={i} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-2 text-sm font-semibold text-brand-navy whitespace-nowrap">{row.cls}</td>
                      {CARELON_KEYS.map(c => (
                        <td key={c.key} className="px-3 py-2 text-center bg-blue-50/60">
                          {row[c.key]==='Y' ? <span className="text-blue-700 font-bold">X</span> : <span className="text-gray-200">—</span>}
                        </td>
                      ))}
                      {PBM_KEYS.map(c => (
                        <td key={c.key} className="px-3 py-2 text-center bg-orange-50/60">
                          {row[c.key]==='Y' ? <span className="text-orange-600 font-bold">X</span> : <span className="text-gray-200">—</span>}
                        </td>
                      ))}
                      {PLAN_KEYS.map(c => (
                        <td key={c.key} className="px-3 py-2 text-center bg-purple-50/60">
                          {row[c.key]==='Y' ? <span className="text-purple-700 font-bold">X</span> : <span className="text-gray-200">—</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── AI Recommendations ── */}
      <div className="card">
        <div className="flex items-center gap-2 mb-1">
          <BarChart2 size={16} className="text-brand-navy" />
          <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>AI Recommendations</h2>
          <span className="ml-2 text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-full px-2.5 py-0.5 font-semibold">Human review required</span>
          <div className="ml-auto flex items-center gap-1 text-xs">
            <span className="text-gray-400 font-semibold">Show:</span>
            {[5, 10].map(n => (
              <button key={n} onClick={() => setAiTopN(n)}
                className={`px-3 py-1 rounded-lg font-semibold border transition-all ${
                  aiTopN === n ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-500 border-gray-200 hover:border-brand-navy'
                }`}>Top {n}</button>
            ))}
          </div>
        </div>
        <p className="text-xs text-gray-400 mb-4">AI-generated drug coverage recommendations based on competitor preventive list analysis across all payers.</p>

        {/* Add recommendations */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide">Drug Addition Recommendations</p>
          </div>
          <div className="space-y-2">
            {[
              { drug: 'Ozempic / Semaglutide (GLP-1)', drugClass: 'Diabetes', priority: 'High', reason: 'Covered on preventive lists by CVS, UHC Expanded, ESI, and Optum. Carelon absent. Strong GLP-1 market momentum — ACA/General preventive coverage warranted for T2DM + CV risk reduction.', competitors: ['CVS', 'UHC Expanded', 'ESI', 'Optum RX'] },
              { drug: 'Jardiance / Empagliflozin (SGLT-2)', drugClass: 'Diabetes', priority: 'High', reason: 'Covered preventively by CVS, Optum, and UHC Expanded for cardiorenal benefit. Carelon not covered. FDA preventive indication supports inclusion.', competitors: ['CVS', 'Optum RX', 'UHC Expanded'] },
              { drug: 'Eliquis / Apixaban (NOAC)', drugClass: 'Blood Clots', priority: 'High', reason: 'On preventive lists at UHC Expanded and ESI for stroke/DVT prevention. High-cost, high-utilization drug — prioritize coverage review before next annual list cycle.', competitors: ['UHC Expanded', 'ESI'] },
              { drug: 'Xarelto / Rivaroxaban (NOAC)', drugClass: 'Blood Clots', priority: 'Medium', reason: 'Preventively covered by ESI for anticoagulation. Market adoption increasing post EINSTEIN trial data.', competitors: ['ESI'] },
              { drug: 'Chantix / Varenicline', drugClass: 'Smoking Cessation', priority: 'Medium', reason: 'Generic now available. ESI, CVS, and Humana cover preventively. Cost-effective smoking cessation with strong ACA preventive mandate.', competitors: ['ESI', 'CVS', 'Humana'] },
            ].slice(0, aiTopN).map((r, i) => (
              <div key={i} className="rounded-xl border border-emerald-100 bg-emerald-50/40 p-3.5 flex gap-4">
                <div className="w-1 rounded-full shrink-0 self-stretch bg-emerald-400" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <p className="text-sm font-bold text-gray-800">{r.drug}</p>
                      <p className="text-xs text-gray-400">{r.drugClass}</p>
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 shrink-0">+ Add</span>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed mt-1.5">{r.reason}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="text-xs text-gray-400">Covered by:</span>
                    {r.competitors.map(c => <span key={c} className="text-xs font-semibold px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded">{c}</span>)}
                  </div>
                </div>
                <button className="self-start text-xs font-semibold text-brand-navy flex items-center gap-1 hover:underline shrink-0 mt-0.5">
                  Review <ArrowRight size={11} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Remove / Maintain recommendations */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-red-400" />
            <p className="text-xs font-bold text-red-600 uppercase tracking-wide">Drug Removal Recommendations</p>
          </div>
          <div className="space-y-2">
            {[
              { drug: 'AirDuo RespiClick', drugClass: 'Asthma', priority: 'Medium', reason: 'Only Carelon covers this combination inhaler on preventive list. No competitor carries it preventively. Review formulary placement — may be better suited as a standard formulary drug.', coveragePeers: [] },
              { drug: 'Brovana / Arformoterol', drugClass: 'Asthma', priority: 'Low', reason: 'Carelon-only preventive coverage. No competitor preventive coverage detected. Market suggests LABA preference shifted to combination products.', coveragePeers: [] },
              { drug: 'Daliresp / Roflumilast', drugClass: 'Asthma', priority: 'Low', reason: 'Carelon covers preventively but no competitors do. COPD-specific drug — limited ACA preventive mandate basis. Re-evaluate preventive vs. standard placement.', coveragePeers: [] },
            ].slice(0, aiTopN).map((r, i) => (
              <div key={i} className="rounded-xl border border-red-100 bg-red-50/30 p-3.5 flex gap-4">
                <div className="w-1 rounded-full shrink-0 self-stretch bg-red-400" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <p className="text-sm font-bold text-gray-800">{r.drug}</p>
                      <p className="text-xs text-gray-400">{r.drugClass}</p>
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700 shrink-0">− Remove</span>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed mt-1.5">{r.reason}</p>
                </div>
                <button className="self-start text-xs font-semibold text-brand-navy flex items-center gap-1 hover:underline shrink-0 mt-0.5">
                  Review <ArrowRight size={11} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

        </div>
      ) : null}

      {/* ── Cell Edit Modal ── */}
      {confirmModal && (() => {
        const existingOverride = cellOverrides[confirmModal.cellKey];
        const hasOverride = existingOverride !== undefined;
        const setLocalCovered = (v) => setConfirmModal(m => ({ ...m, localCovered: v }));
        const setLocalNote = (v) => setConfirmModal(m => ({ ...m, localNote: v }));
        return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}
            onClick={() => setConfirmModal(null)}>
            <div className="bg-white rounded-xl shadow-xl mx-4 p-4" style={{ width: 280 }} onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-bold text-gray-900 text-xs">{confirmModal.row.drug}</p>
                </div>
                <button onClick={() => setConfirmModal(null)} className="text-gray-400 hover:text-gray-600 ml-2 shrink-0"><X size={14}/></button>
              </div>
              <div className="flex gap-2 mb-3">
                <button onClick={() => setLocalCovered(true)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${
                    confirmModal.localCovered ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-gray-200 bg-white text-gray-400'
                  }`}>
                  <CheckCircle size={12}/> Covered
                </button>
                <button onClick={() => setLocalCovered(false)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${
                    !confirmModal.localCovered ? 'border-red-400 bg-red-50 text-red-600' : 'border-gray-200 bg-white text-gray-400'
                  }`}>
                  <X size={12}/> Not Covered
                </button>
              </div>
              <input
                className="input text-xs py-1.5 w-full mb-3"
                placeholder="Add a note (optional)…"
                value={confirmModal.localNote}
                onChange={e => setLocalNote(e.target.value)}
              />
              <div className="flex gap-1.5">
                <button onClick={() => setConfirmModal(null)}
                  className="flex-1 py-1.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-500 hover:bg-gray-50">
                  Cancel
                </button>
                {hasOverride && (
                  <button
                    onClick={() => { setCellOverrides(prev => { const n = { ...prev }; delete n[confirmModal.cellKey]; return n; }); setConfirmModal(null); }}
                    className="px-2.5 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-xs font-semibold text-amber-700 hover:bg-amber-100 flex items-center gap-1">
                    <RefreshCw size={10}/> Revert
                  </button>
                )}
                <button
                  onClick={() => { setCellOverrides(prev => ({ ...prev, [confirmModal.cellKey]: { covered: confirmModal.localCovered, note: confirmModal.localNote } })); setConfirmModal(null); }}
                  className="flex-1 py-1.5 rounded-lg text-xs font-bold text-white"
                  style={{ backgroundColor: '#1A3673' }}>
                  Save
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Fixed-position tooltip portal — renders above all scroll/sticky containers */}
      {tooltip && (
        <div
          className="pointer-events-none"
          style={{
            position: 'fixed',
            left: tooltip.x,
            top: tooltip.y - 8,
            transform: 'translate(-50%, -100%)',
            zIndex: 99999,
          }}
        >
          {tooltip.content}
          <div className="w-2 h-2 bg-gray-900 rotate-45 mx-auto -mt-1" />
        </div>
      )}
    </div>
  );
}
