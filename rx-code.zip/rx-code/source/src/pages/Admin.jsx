import { useState } from 'react';
import { Plus, Trash2, RefreshCw, CheckCircle, AlertTriangle, Users, Database, Settings, FolderKanban, X } from 'lucide-react';
import { useApp, can } from '../context/AppContext';

const TABS = [
  { id: 'programs', label: 'Program Management', icon: FolderKanban },
  { id: 'users', label: 'User Management', icon: Users },
  { id: 'datasources', label: 'Data Sources', icon: Database },
  { id: 'settings', label: 'Settings', icon: Settings },
];

const INIT_PROGRAMS = {
  'Designated Network': ['Specialty Care Network - National', 'Specialty Care Network - Midwest', 'Oncology Select', 'Rheumatology Network'],
  'Preventive Rx': ['ACA Preventive Drug List 2026', 'HDHP Safe Harbor List 2026', 'IRS Preventive Drug List 2026', 'General Preventive List 2026'],
};

const INIT_USERS = [
  { id: 'AH40130', name: 'Tracy Thompson', role: 'admin', email: 'tracy.thompson@carelon.com', status: 'Active' },
  { id: 'AH40131', name: 'Alana Coleman', role: 'editor', email: 'alana.coleman@carelon.com', status: 'Active' },
  { id: 'AH40132', name: 'Sara Colburn', role: 'read-only', email: 'sara.colburn@carelon.com', status: 'Active' },
  { id: 'AH40133', name: 'Kristen Keller', role: 'editor', email: 'kristen.keller@carelon.com', status: 'Active' },
  { id: 'AH40134', name: 'Jeremy Landsheft', role: 'read-only', email: 'jeremy.landsheft@carelon.com', status: 'Active' },
  { id: 'AH40135', name: 'Niraj Sharma', role: 'editor', email: 'niraj.sharma@carelon.com', status: 'Active' },
];

const INIT_SOURCES = [
  { name: 'iDiscovery', type: 'Primary', status: 'Connected', lastSync: '2026-08-05 09:00', coverage: '82%' },
  { name: 'Web Search Fallback', type: 'Fallback', status: 'Active', lastSync: '2026-08-05 09:00', coverage: 'On-demand' },
  { name: 'SharePoint (NDC Crosswalk)', type: 'Reference', status: 'Connected', lastSync: '2026-08-04 06:00', coverage: 'Weekly refresh' },
  { name: 'SharePoint (Drug List Crosswalk)', type: 'Reference', status: 'Stale', lastSync: '2026-07-28 06:00', coverage: 'Weekly — OVERDUE' },
];

export default function Admin() {
  const { currentUser, addToast } = useApp();
  const [tab, setTab] = useState('programs');
  const [programs, setPrograms] = useState(INIT_PROGRAMS);
  const [newProgramType, setNewProgramType] = useState('Designated Network');
  const [newProgramName, setNewProgramName] = useState('');
  const [users, setUsers] = useState(INIT_USERS);
  const [sources, setSources] = useState(INIT_SOURCES);

  if (!can(currentUser, 'admin')) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3">
        <AlertTriangle size={32} className="text-yellow-400" />
        <p className="text-gray-500 text-sm font-semibold">Admin access required.</p>
        <p className="text-gray-400 text-xs">Contact your system administrator for access.</p>
      </div>
    );
  }

  function addProgram() {
    if (!newProgramName.trim()) return;
    setPrograms(p => ({ ...p, [newProgramType]: [...(p[newProgramType] || []), newProgramName.trim()] }));
    addToast(`Program "${newProgramName}" added to ${newProgramType}.`, 'success');
    setNewProgramName('');
  }

  function removeProgram(type, name) {
    setPrograms(p => ({ ...p, [type]: p[type].filter(x => x !== name) }));
    addToast(`Program "${name}" removed.`, 'warning');
  }

  function changeRole(userId, role) {
    setUsers(u => u.map(x => x.id === userId ? { ...x, role } : x));
    addToast('User role updated.', 'success');
  }

  function syncSource(name) {
    setSources(s => s.map(x => x.name === name ? { ...x, status: 'Connected', lastSync: new Date().toLocaleString() } : x));
    addToast(`${name} sync triggered.`, 'success');
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-brand-navy">Administration</h1>
        <p className="text-sm text-gray-500">Manage programs, users, and data sources.</p>
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 border-b border-gray-200">
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-all -mb-px ${
              tab === t.id ? 'border-brand-navy text-brand-navy' : 'border-transparent text-gray-400 hover:text-brand-navy'
            }`}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {/* ── Program Management ── */}
      {tab === 'programs' && (
        <div className="space-y-5">
          {Object.entries(programs).map(([type, list]) => (
            <div key={type} className="card">
              <h3 className="font-bold text-brand-navy mb-3" style={{ fontSize: 14 }}>{type} Programs</h3>
              <div className="space-y-2 mb-4">
                {list.map(name => (
                  <div key={name} className="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-700">{name}</span>
                    <button onClick={() => removeProgram(type, name)} className="text-gray-300 hover:text-brand-coral"><Trash2 size={14} /></button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input className="input flex-1 text-xs" placeholder="New program name..." value={newProgramName} onChange={e => setNewProgramName(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addProgram()} />
                <button onClick={() => { setNewProgramType(type); addProgram(); }} className="btn-secondary text-xs flex items-center gap-1"><Plus size={13} /> Add</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── User Management ── */}
      {tab === 'users' && (
        <div className="card p-0">
          <table className="w-full text-left">
            <thead>
              <tr>
                {['Employee ID', 'Name', 'Email', 'Role', 'Status'].map(h => (
                  <th key={h} className="table-header">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="hover:bg-gray-50">
                  <td className="table-cell font-mono text-xs text-gray-500">{u.id}</td>
                  <td className="table-cell text-sm font-semibold text-brand-navy">{u.name}</td>
                  <td className="table-cell text-xs text-gray-500">{u.email}</td>
                  <td className="table-cell">
                    <select
                      value={u.role}
                      onChange={e => changeRole(u.id, e.target.value)}
                      className="select text-xs w-36"
                    >
                      <option value="read-only">Read Only</option>
                      <option value="editor">Editor</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td className="table-cell">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${u.status === 'Active' ? 'bg-brand-tealPale text-teal-800' : 'bg-gray-100 text-gray-500'}`}>
                      {u.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── Data Sources ── */}
      {tab === 'datasources' && (
        <div className="space-y-3">
          {sources.map(s => (
            <div key={s.name} className={`card flex items-center justify-between gap-4 ${s.status === 'Stale' ? 'border-yellow-300 bg-yellow-50/30' : ''}`}>
              <div className="flex items-center gap-3">
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${s.status === 'Connected' ? 'bg-brand-teal' : s.status === 'Active' ? 'bg-brand-blue' : 'bg-yellow-400'}`} />
                <div>
                  <p className="font-semibold text-brand-navy text-sm">{s.name}</p>
                  <p className="text-xs text-gray-400">Last sync: {s.lastSync} · Coverage: {s.coverage}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${s.status === 'Connected' ? 'bg-brand-tealPale text-teal-800' : s.status === 'Active' ? 'bg-brand-iceBlue text-brand-navy' : 'bg-yellow-100 text-yellow-800'}`}>
                  {s.status}
                </span>
                <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded font-semibold">{s.type}</span>
                <button onClick={() => syncSource(s.name)} className="btn-secondary text-xs flex items-center gap-1"><RefreshCw size={12} /> Sync Now</button>
              </div>
            </div>
          ))}
          {sources.some(s => s.status === 'Stale') && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex items-center gap-2 text-xs text-yellow-800">
              <AlertTriangle size={14} /> One or more data sources are stale. Trigger a manual sync or check the automated schedule.
            </div>
          )}
        </div>
      )}

      {/* ── Settings ── */}
      {tab === 'settings' && (
        <div className="card max-w-lg space-y-5">
          <h3 className="font-bold text-brand-navy" style={{ fontSize: 14 }}>System Settings</h3>
          <div className="space-y-4">
            {[
              { label: 'LOB Scope', value: 'Commercial (v1.0)', note: 'Medicare & Medicaid deferred to v2.0' },
              { label: 'Session Timeout', value: '30 minutes of inactivity', note: 'SSO session policy' },
              { label: 'Audit Log Retention', value: '7 years (Approved) · 3 years (Cancelled/Deferred)', note: 'Per corporate retention policy' },
              { label: 'SharePoint Refresh Cadence', value: 'Weekly (automated)', note: 'NDC crosswalk & drug list crosswalk' },
              { label: 'AI Grid Generation Target', value: '< 5 minutes', note: '1 drug, 4-5 competitors typical' },
            ].map(s => (
              <div key={s.label} className="flex items-start justify-between gap-4 py-2 border-b border-gray-100 last:border-0">
                <div>
                  <p className="text-sm font-semibold text-brand-navy">{s.label}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{s.note}</p>
                </div>
                <span className="text-xs font-semibold text-gray-600 text-right shrink-0">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
