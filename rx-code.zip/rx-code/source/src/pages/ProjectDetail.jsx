import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Clock, CheckCircle, XCircle, PauseCircle, History,
  ChevronRight, Zap, Eye, Download, AlertTriangle, Edit2, Save,
  X, Plus, Upload, FileText, Minus, Info, ExternalLink, CheckCircle2
} from 'lucide-react';
import { useApp, STATUS_TRANSITIONS, can } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';
import SourceBadge from '../components/SourceBadge';

// ── Inline workflow grids (same mock data as GridReview) ───────────
const MOCK_CC_GRID = [
  { criterion: 'Prior Authorization Required', carelon: 'Yes — all biologics', cells: { 'United Healthcare': { val: 'Yes', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC Medical Policy MP-04.01.07: Prior authorization is required for all biologic agents.' }, Cigna: { val: 'Yes', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna Coverage Policy 0301: PA required for biologic therapies.' }, Aetna: { val: 'Yes', tag: 'neutral', source: 'iDiscovery', evidence: 'Aetna Clinical Policy Bulletin: PA required.' }, Caremark: { val: 'Yes', tag: 'neutral', source: 'web', evidence: 'Caremark formulary guidance states PA required for specialty biologics.' } } },
  { criterion: 'Step Therapy — DMARD Trial (MTX)', carelon: '≥ 6 months MTX trial required', cells: { 'United Healthcare': { val: '≥ 3 months MTX', tag: 'lenient', source: 'iDiscovery', evidence: 'UHC Step Therapy: adequate trial of MTX for ≥ 3 months.' }, Cigna: { val: '≥ 6 months MTX', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna requires 6 months conventional DMARD including MTX.' }, Aetna: { val: '≥ 3 months MTX', tag: 'lenient', source: 'web', evidence: 'Aetna policy requires at least 3 months MTX before biologic.' }, Caremark: { val: '≥ 6 months MTX', tag: 'neutral', source: 'iDiscovery', evidence: 'Caremark PA: 6-month MTX trial at adequate dose.' } } },
  { criterion: 'Biosimilar Requirement', carelon: 'Biosimilar preferred when available', cells: { 'United Healthcare': { val: 'Mandatory biosimilar first', tag: 'stricter', source: 'iDiscovery', evidence: 'UHC requires dispensing of a biosimilar when available unless clinical exception documented.' }, Cigna: { val: 'Preferred biosimilar', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna: Biosimilar preferred but originator permitted with clinical documentation.' }, Aetna: { val: 'Mandatory biosimilar first', tag: 'stricter', source: 'web', evidence: 'Aetna Step Therapy requires biosimilar trial before originator biologic.' }, Caremark: { val: 'Preferred biosimilar', tag: 'neutral', source: 'iDiscovery', evidence: 'Caremark: Prefer biosimilar; originator covered with prior auth.' } } },
  { criterion: 'Quantity Limit', carelon: 'Per FDA labeling', cells: { 'United Healthcare': { val: 'Per FDA labeling', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC quantity limits align with FDA-approved dosing.' }, Cigna: { val: 'Per FDA labeling', tag: 'neutral', source: 'iDiscovery', evidence: 'Cigna quantity limits per FDA label.' }, Aetna: { val: '10% below FDA labeling', tag: 'stricter', source: 'iDiscovery', evidence: 'Aetna applies additional UM reducing approved quantity by 10%.' }, Caremark: { val: 'Per FDA labeling', tag: 'neutral', source: 'iDiscovery', evidence: 'Caremark aligns with FDA labeling.' } } },
];
const MOCK_DN_GRID = [
  { criterion: 'Humira (adalimumab)', carelon: 'Included — Mandatory', cells: { 'United Healthcare': { val: 'Included — Mandatory', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC Designated Network includes adalimumab as mandatory.' } }, flag: 'Common', hcpcs: 'J0135' },
  { criterion: 'Enbrel (etanercept)', carelon: 'Included — Mandatory', cells: { 'United Healthcare': { val: 'Not included', tag: 'stricter', source: 'iDiscovery', evidence: 'UHC does not include etanercept in current designated network list.' } }, flag: 'Carelon Only', hcpcs: 'J1438' },
  { criterion: 'Stelara (ustekinumab)', carelon: 'Not included', cells: { 'United Healthcare': { val: 'Included — Voluntary', tag: 'lenient', source: 'web', evidence: 'UHC designated network includes ustekinumab on voluntary basis.' } }, flag: 'Competitor Only', hcpcs: 'J3357' },
];
const MOCK_PREV_GRID = [
  { criterion: 'Lisinopril (Hypertension)', carelon: 'ACA + HDHP', cells: { CVS: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'CVS preventive list includes lisinopril under ACA guidelines.' }, Optum: { val: 'ACA + HDHP', tag: 'neutral', source: 'iDiscovery', evidence: 'Optum includes lisinopril under both ACA and HDHP.' }, UnitedHealthcare: { val: 'ACA', tag: 'neutral', source: 'web', evidence: 'UHC preventive list includes lisinopril ACA category.' }, Humana: { val: 'Not covered', tag: 'stricter', source: 'web', evidence: 'Humana does not include lisinopril.' }, ESI: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'ESI preventive list includes lisinopril.' }, 'Blue Shield CA': { val: 'ACA + HDHP', tag: 'neutral', source: 'iDiscovery', evidence: 'Blue Shield CA covers lisinopril under both programs.' }, 'Kaiser Permanente': { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'Kaiser includes lisinopril under ACA framework.' } } },
  { criterion: 'Statins (Cholesterol)', carelon: 'ACA only', cells: { CVS: { val: 'ACA + HDHP', tag: 'lenient', source: 'web', evidence: 'CVS includes statins under both ACA and HDHP.' }, Optum: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'Optum covers generic statins under ACA.' }, UnitedHealthcare: { val: 'HDHP', tag: 'neutral', source: 'iDiscovery', evidence: 'UHC includes statins under HDHP safe harbor.' }, Humana: { val: 'ACA', tag: 'neutral', source: 'web', evidence: 'Humana preventive list includes generic statins.' }, ESI: { val: 'ACA', tag: 'neutral', source: 'iDiscovery', evidence: 'ESI covers statins under ACA.' }, 'Blue Shield CA': { val: 'ACA + HDHP', tag: 'lenient', source: 'iDiscovery', evidence: 'Blue Shield CA includes statins under both frameworks.' }, 'Kaiser Permanente': { val: 'Not covered', tag: 'stricter', source: 'web', evidence: 'Kaiser does not include statins on preventive list.' } } },
];
const GRID_BY_TYPE = { 'Clinical Criteria': MOCK_CC_GRID, 'Designated Network': MOCK_DN_GRID, 'Preventive Rx': MOCK_PREV_GRID };

const TAG_STYLE = {
  stricter: 'bg-brand-peach text-brand-coral border border-brand-coral/30',
  lenient:  'bg-brand-tealPale text-teal-800 border border-brand-teal/20',
  neutral:  'bg-gray-50 text-gray-600 border border-gray-200',
};
const TAG_ICON = { stricter: <AlertTriangle size={10} />, lenient: <CheckCircle2 size={10} />, neutral: <Minus size={10} /> };

const TABS = [
  { id: 'overview',   label: 'Overview' },
  { id: 'workflow',   label: 'Workflow' },
  { id: 'grid',       label: 'Review Grid' },
  { id: 'audit',      label: 'Audit Trail' },
];

export default function ProjectDetail() {
  const { id } = useParams();
  const { projects, updateProject, currentUser, addToast } = useApp();
  const navigate = useNavigate();
  const project = projects.find(p => p.id === id);

  const [tab, setTab] = useState('overview');
  const [editComments, setEditComments] = useState(false);
  const [comments, setComments] = useState(project?.comments || '');
  const [competitorsOpen, setCompetitorsOpen] = useState(false);

  // Workflow tab state
  const [drugInput, setDrugInput] = useState('');
  const [drugs, setDrugs] = useState(project?.drugs || []);

  // Grid tab state
  const baseGrid = GRID_BY_TYPE[project?.ciType] || MOCK_CC_GRID;
  const [grid, setGrid] = useState(baseGrid);
  const [editingCell, setEditingCell] = useState(null);
  const [editBuf, setEditBuf] = useState('');
  const [userEdited, setUserEdited] = useState({});
  const [evidencePanel, setEvidencePanel] = useState(null);

  if (!project) {
    return (
      <div className="text-center py-20 text-gray-400">
        <p>Project not found.</p>
        <button onClick={() => navigate('/projects')} className="btn-primary mt-4">Back to Projects</button>
      </div>
    );
  }

  const transitions = STATUS_TRANSITIONS[project.status] || [];
  const canEdit = can(currentUser, 'edit');
  const canApprove = can(currentUser, 'approve');
  const isApproved = project.status === 'Approved';
  const hasGrid = project.status === 'Review' || project.status === 'Approved';
  const competitors = project.competitors || [];

  function changeStatus(newStatus) {
    const noteMap = {
      'In-Progress': 'Status changed to In-Progress',
      'Review':      'Intelligence generated. Status changed to Review',
      'Approved':    'Project approved by analyst (Human-in-the-Loop). Export unlocked.',
      'Cancelled':   'Project cancelled',
      'Deferred':    'Project deferred',
      'Open':        'Project re-opened from Deferred',
    };
    updateProject(id, { status: newStatus, _auditNote: noteMap[newStatus] || `Status changed to ${newStatus}` });
    addToast(`Status updated to ${newStatus}.`, 'success');
  }

  function saveComments() {
    updateProject(id, { comments, _auditNote: 'Comments updated' });
    setEditComments(false);
    addToast('Comments saved.', 'success');
  }

  function generateIntelligence() {
    updateProject(id, { status: 'In-Progress', _auditNote: 'Intelligence generation started. Status changed to In-Progress.' });
    navigate(`/projects/${id}/processing`);
  }

  function addDrug() {
    if (!drugInput.trim() || drugs.includes(drugInput.trim())) return;
    const updated = [...drugs, drugInput.trim()];
    setDrugs(updated);
    setDrugInput('');
    updateProject(id, { drugs: updated, _auditNote: `Drug added: ${drugInput.trim()}` });
  }

  function removeDrug(d) {
    const updated = drugs.filter(x => x !== d);
    setDrugs(updated);
    updateProject(id, { drugs: updated, _auditNote: `Drug removed: ${d}` });
  }

  function saveCell(rowIdx, comp) {
    const newGrid = grid.map((row, i) => {
      if (i !== rowIdx) return row;
      return { ...row, cells: { ...row.cells, [comp]: { ...row.cells[comp], val: editBuf, userEdited: true } } };
    });
    setGrid(newGrid);
    setUserEdited(u => ({ ...u, [`${rowIdx}-${comp}`]: true }));
    updateProject(id, { analysisGrid: newGrid, _auditNote: `Cell edited: "${grid[rowIdx].criterion}" / ${comp}` });
    addToast(`Cell updated.`, 'success');
    setEditingCell(null);
  }

  function approve() {
    updateProject(id, { status: 'Approved', _auditNote: 'Project approved by analyst (Human-in-the-Loop). Export unlocked.' });
    addToast('Project approved. Export is now available.', 'success');
  }

  function exportStub(type) {
    if (!isApproved) { addToast('Project must be Approved before exporting.', 'warning'); return; }
    addToast(`${type} export initiated.`, 'success');
  }

  const relevantCompetitors = competitors.filter(c => grid.some(row => row.cells?.[c]));

  return (
    <div className="space-y-0">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
        <button onClick={() => navigate('/projects')} className="hover:text-brand-navy flex items-center gap-1">
          <ArrowLeft size={14} /> Projects
        </button>
        <ChevronRight size={12} />
        <span className="text-brand-navy font-semibold">{project.id}</span>
      </div>

      {/* Header card */}
      <div className="card mb-0 rounded-b-none border-b-0">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <span className="font-mono text-xs text-brand-mid font-bold">{project.id}</span>
              <StatusBadge status={project.status} />
              <span className="bg-brand-iceBlue text-brand-navy text-xs px-2 py-0.5 rounded font-semibold">{project.ciType}</span>
            </div>
            <h1 className="text-xl font-bold text-brand-navy">{project.name}</h1>
            <p className="text-sm text-gray-500 mt-1">LOB: {project.lob} · Market: {project.market}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {canEdit && transitions.includes('In-Progress') && project.status === 'Open' && (
              <button onClick={generateIntelligence} className="btn-primary flex items-center gap-1.5 text-xs">
                <Zap size={14} /> Generate Intelligence
              </button>
            )}
            {canEdit && transitions.includes('In-Progress') && project.status !== 'Open' && (
              <button onClick={() => changeStatus('In-Progress')} className="btn-secondary flex items-center gap-1.5 text-xs">
                <Clock size={14} /> Back to In-Progress
              </button>
            )}
            {canApprove && transitions.includes('Approved') && (
              <button onClick={approve} className="btn-primary flex items-center gap-1.5 text-xs">
                <CheckCircle size={14} /> Approve
              </button>
            )}
            {isApproved && (
              <>
                <button onClick={() => exportStub('Excel')} className="btn-secondary text-xs flex items-center gap-1.5"><Download size={13} /> Excel</button>
                <button onClick={() => exportStub('PowerPoint')} className="btn-secondary text-xs flex items-center gap-1.5"><Download size={13} /> PPT</button>
                <button onClick={() => exportStub('PDF')} className="btn-secondary text-xs flex items-center gap-1.5"><Download size={13} /> PDF</button>
              </>
            )}
            {canEdit && transitions.includes('Cancelled') && (
              <button onClick={() => changeStatus('Cancelled')} className="btn-danger flex items-center gap-1.5 text-xs">
                <XCircle size={14} /> Cancel
              </button>
            )}
            {canEdit && transitions.includes('Deferred') && (
              <button onClick={() => changeStatus('Deferred')}
                className="bg-brand-salmon text-brand-coral border border-brand-coral px-4 py-2 rounded text-xs font-semibold hover:opacity-90 flex items-center gap-1.5">
                <PauseCircle size={14} /> Defer
              </button>
            )}
            {canEdit && transitions.includes('Open') && (
              <button onClick={() => changeStatus('Open')} className="btn-secondary flex items-center gap-1.5 text-xs">Re-open</button>
            )}
          </div>
        </div>

        {/* Status flow */}
        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center gap-2 text-xs text-gray-400">
          {['Open','In-Progress','Review','Approved'].map((s, i, arr) => (
            <span key={s} className="flex items-center gap-1">
              <span className={`font-semibold ${project.status === s ? 'text-brand-navy' : 'text-gray-300'}`}>{s}</span>
              {i < arr.length - 1 && <ChevronRight size={10} className="text-gray-300" />}
            </span>
          ))}
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex border-b border-gray-200 bg-white px-6 -mt-px shadow-sm">
        {TABS.map(t => {
          const locked = (t.id === 'grid') && !hasGrid;
          return (
            <button
              key={t.id}
              onClick={() => !locked && setTab(t.id)}
              className={`px-4 py-3 text-xs font-semibold border-b-2 transition-all -mb-px ${
                tab === t.id
                  ? 'border-brand-navy text-brand-navy'
                  : locked
                  ? 'border-transparent text-gray-300 cursor-not-allowed'
                  : 'border-transparent text-gray-400 hover:text-brand-navy'
              }`}
            >
              {t.label}
              {t.id === 'grid' && hasGrid && project.status === 'Review' && (
                <span className="ml-1.5 w-1.5 h-1.5 bg-brand-blue rounded-full inline-block align-middle" />
              )}
            </button>
          );
        })}
      </div>

      {/* ── Tab: Overview ── */}
      {tab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
          <div className="card space-y-3">
            <h2 className="font-bold text-brand-navy" style={{ fontSize: 16 }}>Project Details</h2>
            <dl className="space-y-2 text-sm">
              {[
                ['Created By', project.createdBy],
                ['Updated By', project.updatedBy],
                ['Created Date', project.createdDate],
                ['Updated Date', project.updatedDate],
                ['Indication', project.indication || '—'],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-2">
                  <dt className="text-gray-400 w-36 shrink-0">{k}</dt>
                  <dd className="text-gray-700 font-semibold">{v}</dd>
                </div>
              ))}
              {/* Competitors accordion */}
              <div className="pt-1">
                <button
                  onClick={() => setCompetitorsOpen(o => !o)}
                  className="flex items-center gap-2 w-full text-left group"
                >
                  <span className="text-gray-400 w-36 shrink-0 text-sm">Competitors</span>
                  <span className="text-gray-700 font-semibold text-sm flex items-center gap-1.5">
                    {competitors.length} selected
                    <ChevronRight size={13} className={`text-gray-400 transition-transform ${competitorsOpen ? 'rotate-90' : ''}`} />
                  </span>
                </button>
                {competitorsOpen && (
                  <div className="mt-2 ml-36 flex flex-wrap gap-1.5">
                    {competitors.map(c => (
                      <span key={c} className="text-xs px-2.5 py-1 rounded-full bg-brand-navy text-white font-semibold">{c}</span>
                    ))}
                  </div>
                )}
              </div>
            </dl>
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-brand-navy" style={{ fontSize: 16 }}>Comments</h2>
              {!editComments && canEdit && (
                <button onClick={() => setEditComments(true)} className="text-xs text-brand-mid font-semibold hover:underline">Edit</button>
              )}
            </div>
            {editComments ? (
              <div className="space-y-2">
                <textarea className="input" rows={4} value={comments} onChange={e => setComments(e.target.value)} />
                <div className="flex gap-2 justify-end">
                  <button onClick={() => setEditComments(false)} className="btn-secondary text-xs">Cancel</button>
                  <button onClick={saveComments} className="btn-primary text-xs">Save</button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-600">{project.comments || <span className="text-gray-300 italic">No comments.</span>}</p>
            )}
          </div>
        </div>
      )}

      {/* ── Tab: Workflow ── */}
      {tab === 'workflow' && (
        <div className="space-y-5 pt-6">
          <div className="card">
            <h2 className="font-bold text-brand-navy mb-1" style={{ fontSize: 16 }}>{project.ciType} Workflow</h2>
            <p className="text-xs text-gray-400 mb-4">Configure inputs, then generate AI intelligence.</p>

            {project.ciType === 'Clinical Criteria' && (
              <>
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Drug(s) / Drug Family</label>
                  <div className="flex gap-2 mb-2">
                    <input className="input flex-1 text-xs" placeholder="Add drug name..." value={drugInput}
                      onChange={e => setDrugInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && addDrug()} />
                    <button onClick={addDrug} className="btn-secondary text-xs flex items-center gap-1"><Plus size={13} /> Add</button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {drugs.map(d => (
                      <span key={d} className="bg-brand-light text-brand-navy text-xs px-3 py-1 rounded-full font-semibold flex items-center gap-1.5">
                        {d} {canEdit && <button onClick={() => removeDrug(d)}><X size={11} /></button>}
                      </span>
                    ))}
                    {!drugs.length && <p className="text-xs text-gray-400 italic">No drugs added yet.</p>}
                  </div>
                </div>
                <div className="mb-4">
                  <button
                    onClick={() => setCompetitorsOpen(o => !o)}
                    className="flex items-center gap-2 w-full text-left mb-1"
                  >
                    <span className="text-xs font-semibold text-gray-600">Competitors</span>
                    <span className="text-xs text-gray-400 font-medium">({competitors.length})</span>
                    <ChevronRight size={12} className={`text-gray-400 transition-transform ${competitorsOpen ? 'rotate-90' : ''}`} />
                  </button>
                  {competitorsOpen && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {competitors.map(c => (
                        <span key={c} className="text-xs px-3 py-1 rounded-full bg-brand-navy text-white font-semibold">{c}</span>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}

            {project.ciType === 'Designated Network' && (
              <div className="mb-4">
                <label className="block text-xs font-semibold text-gray-600 mb-1">Program</label>
                <p className="text-sm font-semibold text-brand-navy">{project.dnProgram || 'Not set — edit project to configure'}</p>
              </div>
            )}

            {project.ciType === 'Preventive Rx' && (
              <div className="mb-4">
                <label className="block text-xs font-semibold text-gray-600 mb-1">Baseline List</label>
                <p className="text-sm font-semibold text-brand-navy">{project.prevRxList || project.drugs?.[0] || 'Not set'}</p>
              </div>
            )}

            <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
              <label className="btn-secondary text-xs cursor-pointer flex items-center gap-1.5">
                <Upload size={13} /> Upload Document
                <input type="file" className="hidden" accept=".pdf,.docx,.xlsx,.csv" />
              </label>
              {canEdit && (project.status === 'Open' || project.status === 'In-Progress') && (
                <button onClick={generateIntelligence} className="btn-primary flex items-center gap-2 text-xs">
                  <Zap size={14} /> Generate Intelligence
                </button>
              )}
              {project.status === 'In-Progress' && (
                <span className="text-xs text-brand-mid font-semibold animate-pulse">Processing…</span>
              )}
              {hasGrid && (
                <button onClick={() => setTab('grid')} className="btn-secondary text-xs flex items-center gap-1.5">
                  <Eye size={13} /> View Review Grid
                </button>
              )}
            </div>
          </div>

          {project.status === 'Open' && (
            <div className="bg-brand-iceBlue border border-brand-blue rounded-lg p-4 text-xs text-brand-navy space-y-1">
              <p><strong>Next step:</strong> Click <strong>Generate Intelligence</strong> above to start AI analysis.</p>
              <p>System will source documents from <strong>iDiscovery</strong> (fallback: web search) and build the comparison grid.</p>
            </div>
          )}
        </div>
      )}

      {/* ── Tab: Review Grid ── */}
      {tab === 'grid' && (
        <div className="space-y-4 pt-6 relative">
          {!hasGrid ? (
            <div className="card text-center py-12 text-gray-400">
              <Zap size={32} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm font-semibold">No grid yet — generate intelligence first.</p>
              <button onClick={() => setTab('workflow')} className="btn-primary text-xs mt-3">Go to Workflow →</button>
            </div>
          ) : (
            <>
              {/* Legend */}
              <div className="card py-2 flex items-center gap-4 flex-wrap">
                <span className="text-xs font-semibold text-gray-500">Legend:</span>
                {Object.entries(TAG_STYLE).map(([tag, cls]) => (
                  <span key={tag} className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold ${cls}`}>
                    {TAG_ICON[tag]} {tag.charAt(0).toUpperCase() + tag.slice(1)} vs Carelon
                  </span>
                ))}
                <span className="text-xs text-gray-400 ml-auto italic">Click cell for evidence · <Edit2 size={10} className="inline" /> to edit</span>
              </div>

              {/* Grid table */}
              <div className={`card p-0 overflow-x-auto transition-all ${evidencePanel ? 'mr-80' : ''}`}>
                <table className="w-full text-left min-w-max">
                  <thead>
                    <tr>
                      <th className="table-header w-48 sticky left-0 z-10">Criterion</th>
                      <th className="table-header bg-brand-mid sticky left-48 z-10">Carelon</th>
                      {relevantCompetitors.map(c => <th key={c} className="table-header">{c}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {grid.map((row, rowIdx) => (
                      <tr key={rowIdx} className="hover:bg-gray-50/50 group">
                        <td className="table-cell font-semibold text-brand-navy text-xs sticky left-0 bg-white z-10">
                          {row.criterion}
                          {row.hcpcs && <span className="block font-mono text-gray-400 font-normal text-xs mt-0.5">{row.hcpcs}</span>}
                          {row.flag && (
                            <span className={`mt-1 inline-block text-xs px-1.5 py-0.5 rounded font-semibold ${
                              row.flag === 'Common' ? 'bg-brand-tealPale text-teal-800'
                              : row.flag === 'Carelon Only' ? 'bg-brand-light text-brand-navy'
                              : 'bg-brand-peach text-brand-coral'}`}>{row.flag}</span>
                          )}
                        </td>
                        <td className="table-cell bg-brand-light/30 text-xs font-semibold sticky left-48 z-10">{row.carelon}</td>
                        {relevantCompetitors.map(comp => {
                          const cell = row.cells?.[comp];
                          if (!cell) return <td key={comp} className="table-cell text-gray-200 text-xs text-center">—</td>;
                          const isEditing = editingCell?.rowIdx === rowIdx && editingCell?.comp === comp;
                          return (
                            <td key={comp} className="table-cell text-xs cursor-pointer hover:bg-brand-light/20 transition-colors"
                              onClick={() => !isEditing && setEvidencePanel({ rowIdx, comp, cell, criterion: row.criterion })}>
                              {isEditing ? (
                                <div onClick={e => e.stopPropagation()} className="space-y-1">
                                  <textarea className="input text-xs" rows={2} value={editBuf}
                                    onChange={e => setEditBuf(e.target.value)} autoFocus />
                                  <div className="flex gap-1">
                                    <button onClick={() => saveCell(rowIdx, comp)} className="text-brand-teal"><Save size={13} /></button>
                                    <button onClick={() => setEditingCell(null)} className="text-gray-400"><X size={13} /></button>
                                  </div>
                                </div>
                              ) : (
                                <div className="flex items-start gap-1.5">
                                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${TAG_STYLE[cell.tag]}`}>
                                    {TAG_ICON[cell.tag]} {cell.val}
                                  </span>
                                  <div className="ml-auto flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                                    {userEdited[`${rowIdx}-${comp}`] && <Info size={11} className="text-brand-mid" />}
                                    <SourceBadge source={cell.source} />
                                    {canEdit && !isApproved && (
                                      <button onClick={e => { e.stopPropagation(); setEditingCell({ rowIdx, comp }); setEditBuf(cell.val); }}
                                        className="text-brand-mid hover:text-brand-navy"><Edit2 size={12} /></button>
                                    )}
                                  </div>
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Approve bar */}
              {!isApproved && canApprove && (
                <div className="card bg-brand-iceBlue border border-brand-blue flex items-center justify-between gap-4">
                  <p className="text-sm text-brand-navy font-semibold">Review complete? Approve to unlock export.</p>
                  <button onClick={approve} className="btn-primary flex items-center gap-1.5 text-xs shrink-0">
                    <CheckCircle size={14} /> Approve Project
                  </button>
                </div>
              )}

              {/* Evidence panel */}
              {evidencePanel && (
                <div className="fixed right-0 top-0 h-full w-80 bg-white border-l border-gray-200 shadow-xl z-40 flex flex-col">
                  <div className="bg-brand-navy text-white px-4 py-3 flex items-center justify-between shrink-0">
                    <div>
                      <p className="text-xs text-white/60">Evidence</p>
                      <p className="font-semibold text-sm">{evidencePanel.comp}</p>
                    </div>
                    <button onClick={() => setEvidencePanel(null)} className="text-white/60 hover:text-white"><X size={16} /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1">Criterion</p>
                      <p className="text-sm text-brand-navy font-semibold">{evidencePanel.criterion}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1">Classification</p>
                      <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold ${TAG_STYLE[evidencePanel.cell.tag]}`}>
                        {TAG_ICON[evidencePanel.cell.tag]} {evidencePanel.cell.tag}
                      </span>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1">Value</p>
                      <p className="text-sm text-gray-700">{evidencePanel.cell.val}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1">Extracted Evidence</p>
                      <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 text-xs text-gray-700 leading-relaxed italic">
                        "{evidencePanel.cell.evidence}"
                      </div>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1">Source</p>
                      <div className="flex items-center gap-2">
                        <SourceBadge source={evidencePanel.cell.source} />
                        <button className="text-xs text-brand-mid hover:underline flex items-center gap-1">
                          <ExternalLink size={11} /> View Source Document
                        </button>
                      </div>
                    </div>
                  </div>
                  {canEdit && !isApproved && (
                    <div className="p-4 border-t border-gray-100 shrink-0">
                      <button onClick={() => { setEditingCell({ rowIdx: evidencePanel.rowIdx, comp: evidencePanel.comp }); setEditBuf(evidencePanel.cell.val); setEvidencePanel(null); }}
                        className="btn-secondary w-full text-xs flex items-center justify-center gap-1.5">
                        <Edit2 size={13} /> Edit This Cell
                      </button>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ── Tab: Audit Trail ── */}
      {tab === 'audit' && (
        <div className="card mt-6">
          <div className="flex items-center gap-2 mb-4">
            <History size={16} className="text-brand-navy" />
            <h2 className="font-bold text-brand-navy" style={{ fontSize: 16 }}>Audit Trail</h2>
            <span className="ml-auto text-xs text-gray-400">{project.auditTrail.length} entries</span>
          </div>
          <div className="space-y-3">
            {[...project.auditTrail].reverse().map((entry, i) => (
              <div key={i} className="flex gap-4 text-sm border-b border-gray-50 pb-3 last:border-0 last:pb-0">
                <div className="w-40 shrink-0 text-xs text-gray-400">{entry.time}</div>
                <div className="flex-1">
                  <span className="font-semibold text-brand-navy">{entry.user}</span>
                  <span className="text-gray-500"> — {entry.change}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
