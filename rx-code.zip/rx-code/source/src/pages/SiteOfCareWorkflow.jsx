export default function SiteOfCareWorkflow() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Site of Care</p>
        <h1 className="text-2xl font-bold text-brand-navy">Site of Care Analysis</h1>
        <p className="text-sm text-gray-500 mt-0.5">Competitor site-of-care policies and cost-sharing analysis — coming soon.</p>
      </div>
      <div className="card py-16 text-center border-dashed border-2 border-gray-200">
        <p className="text-gray-400 text-sm font-semibold">Site of Care module is under development.</p>
        <p className="text-gray-300 text-xs mt-1">Architecture is ready for drug ranking, outlier detection, and historical trend analysis.</p>
      </div>
    </div>
  );
}
