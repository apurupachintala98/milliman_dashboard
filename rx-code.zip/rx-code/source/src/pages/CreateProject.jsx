import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, ChevronRight, Upload, X, Plus, Search, ChevronDown } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CI_TYPES, MARKETS, COMPETITORS_BY_TYPE, can } from '../context/AppContext';

const DRUG_SUGGESTIONS = [
  'Humira (adalimumab)', 'Dupixent (dupilumab)', 'Stelara (ustekinumab)',
  'Keytruda (pembrolizumab)', 'Tremfya (guselkumab)', 'Skyrizi (risankizumab)',
  'Enbrel (etanercept)', 'Cosentyx (secukinumab)', 'Taltz (ixekizumab)',
  'Otezla (apremilast)', 'Rituxan (rituximab)', 'Herceptin (trastuzumab)',
  'Avastin (bevacizumab)', 'Opdivo (nivolumab)', 'Yervoy (ipilimumab)',
];

const INDICATIONS = [
  'Rheumatoid Arthritis', 'Plaque Psoriasis', 'Crohn\'s Disease', 'Ulcerative Colitis',
  'Non-Small Cell Lung Cancer', 'Melanoma', 'Asthma', 'Atopic Dermatitis',
  'Ankylosing Spondylitis', 'Type 2 Diabetes',
];

const DN_PROGRAMS = [
  'Specialty Care Network - National', 'Specialty Care Network - Midwest',
  'Oncology Select', 'Rheumatology Network',
];

const PREV_RX_LISTS = [
  'ACA Preventive Drug List 2026', 'HDHP Safe Harbor List 2026',
  'IRS Preventive Drug List 2026', 'General Preventive List 2026',
];

const STEPS = ['Project Info', 'Workflow Config', 'Review & Generate'];

export default function CreateProject() {
  const { addProject, currentUser, addToast } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [drugInput, setDrugInput] = useState('');
  const [marketSearch, setMarketSearch] = useState('');
  const [marketOpen, setMarketOpen] = useState(false);
  const marketRef = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (marketRef.current && !marketRef.current.contains(e.target)) setMarketOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);
  const [form, setForm] = useState({
    name: '', lob: 'Commercial', market: 'National', comments: '',
    ciType: 'Clinical Criteria',
    // Clinical Criteria
    drugs: [], indication: '', policyType: 'Pharmacy', competitors: [...COMPETITORS_BY_TYPE['Clinical Criteria']],
    // Designated Network
    dnProgram: '', dnCompetitors: [...COMPETITORS_BY_TYPE['Designated Network']],
    // Preventive Rx
    prevRxList: '', prevCompetitors: [...COMPETITORS_BY_TYPE['Preventive Rx']],
  });

  if (!can(currentUser, 'create')) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400 text-sm">
        You do not have permission to create projects.
      </div>
    );
  }

  function handle(e) {
    const { name, value } = e.target;
    setForm(f => {
      const updated = { ...f, [name]: value };
      if (name === 'ciType') {
        updated.competitors = [...COMPETITORS_BY_TYPE[value]];
        updated.dnCompetitors = [...COMPETITORS_BY_TYPE['Designated Network']];
        updated.prevCompetitors = [...COMPETITORS_BY_TYPE['Preventive Rx']];
      }
      return updated;
    });
  }

  function addDrug() {
    if (!drugInput.trim() || form.drugs.includes(drugInput.trim())) return;
    setForm(f => ({ ...f, drugs: [...f.drugs, drugInput.trim()] }));
    setDrugInput('');
  }

  function removeDrug(d) { setForm(f => ({ ...f, drugs: f.drugs.filter(x => x !== d) })); }

  function toggleCompetitor(list, comp) {
    setForm(f => {
      const current = f[list];
      return { ...f, [list]: current.includes(comp) ? current.filter(c => c !== comp) : [...current, comp] };
    });
  }

  function validate() {
    if (step === 0) return form.name.trim().length > 0;
    if (step === 1) {
      if (form.ciType === 'Clinical Criteria') return form.drugs.length > 0;
      if (form.ciType === 'Designated Network') return !!form.dnProgram;
      if (form.ciType === 'Preventive Rx') return !!form.prevRxList;
    }
    return true;
  }

  function next() { if (validate()) setStep(s => s + 1); }
  function back() { setStep(s => s - 1); }

  function submit() {
    const projectData = {
      name: form.name, lob: form.lob, market: form.market,
      comments: form.comments, ciType: form.ciType,
      drugs: form.ciType === 'Clinical Criteria' ? form.drugs : form.ciType === 'Preventive Rx' ? [form.prevRxList] : [],
      indication: form.indication,
      competitors: form.ciType === 'Clinical Criteria' ? form.competitors
        : form.ciType === 'Designated Network' ? form.dnCompetitors
        : form.prevCompetitors,
      dnProgram: form.dnProgram,
      prevRxList: form.prevRxList,
    };
    const id = addProject(projectData);
    addToast(`Project "${form.name}" created successfully.`, 'success');
    navigate(`/projects/${id}`);
  }

  const activeCompetitors = form.ciType === 'Clinical Criteria' ? form.competitors
    : form.ciType === 'Designated Network' ? form.dnCompetitors
    : form.prevCompetitors;
  const allCompetitors = COMPETITORS_BY_TYPE[form.ciType];
  const compKey = form.ciType === 'Clinical Criteria' ? 'competitors'
    : form.ciType === 'Designated Network' ? 'dnCompetitors' : 'prevCompetitors';

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-bold text-brand-navy">New Competitive Intelligence Project</h1>
        <p className="text-sm text-gray-500 mt-0.5">LOB: Commercial Only</p>
      </div>

      {/* Step progress */}
      <div className="flex items-center gap-2 mb-8">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-2 flex-1 last:flex-none">
            <div className={`flex items-center gap-2 ${i <= step ? 'text-brand-navy' : 'text-gray-400'}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all ${
                i < step ? 'bg-brand-teal border-brand-teal text-white'
                : i === step ? 'bg-brand-navy border-brand-navy text-white'
                : 'border-gray-300 text-gray-400'
              }`}>
                {i < step ? <CheckCircle size={14} /> : i + 1}
              </div>
              <span className={`text-xs font-semibold hidden sm:block ${i === step ? 'text-brand-navy' : 'text-gray-400'}`}>{s}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`flex-1 h-0.5 mx-2 ${i < step ? 'bg-brand-teal' : 'bg-gray-200'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Step card */}
      <div className="card space-y-5">

        {/* ── Step 0: Project Info ── */}
        {step === 0 && (
          <>
            <h2 className="font-bold text-brand-navy" style={{ fontSize: 16 }}>Project Information</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 mb-1">Project Name *</label>
                <input name="name" value={form.name} onChange={handle} className="input" placeholder="e.g. Humira - UM Criteria Q3 2026" required />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">LOB</label>
                <input value="Commercial" className="input bg-gray-50 text-gray-400 cursor-not-allowed" readOnly />
                <p className="text-xs text-gray-400 mt-0.5">Commercial only for v1.0</p>
              </div>
              <div ref={marketRef} className="relative">
                <label className="block text-xs font-semibold text-gray-600 mb-1">Market / State Scope</label>
                <button
                  type="button"
                  onClick={() => { setMarketOpen(o => !o); setMarketSearch(''); }}
                  className="select w-full flex items-center justify-between text-left"
                >
                  <span>{form.market}</span>
                  <ChevronDown size={14} className={`text-gray-400 transition-transform ${marketOpen ? 'rotate-180' : ''}`} />
                </button>
                {marketOpen && (
                  <div className="absolute z-50 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg">
                    <div className="p-2 border-b border-gray-100">
                      <div className="relative">
                        <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input
                          autoFocus
                          className="input pl-8 py-1.5 text-xs"
                          placeholder="Search state..."
                          value={marketSearch}
                          onChange={e => setMarketSearch(e.target.value)}
                        />
                      </div>
                    </div>
                    <ul className="max-h-48 overflow-y-auto py-1">
                      {MARKETS.filter(m => m.toLowerCase().includes(marketSearch.toLowerCase())).map(m => (
                        <li key={m}>
                          <button
                            type="button"
                            onClick={() => { setForm(f => ({ ...f, market: m })); setMarketOpen(false); }}
                            className={`w-full text-left px-3 py-1.5 text-xs hover:bg-brand-light transition-colors ${
                              form.market === m ? 'font-semibold text-brand-navy bg-brand-iceBlue' : 'text-gray-700'
                            }`}
                          >
                            {m}
                          </button>
                        </li>
                      ))}
                      {MARKETS.filter(m => m.toLowerCase().includes(marketSearch.toLowerCase())).length === 0 && (
                        <li className="px-3 py-2 text-xs text-gray-400">No results</li>
                      )}
                    </ul>
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Workflow Type *</label>
                <select name="ciType" value={form.ciType} onChange={handle} className="select">
                  {CI_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 mb-1">Comments / Notes</label>
                <textarea name="comments" value={form.comments} onChange={handle} className="input" rows={2} placeholder="Optional context or background..." />
              </div>
            </div>
          </>
        )}

        {/* ── Step 1: Workflow Config ── */}
        {step === 1 && (
          <>
            <h2 className="font-bold text-brand-navy" style={{ fontSize: 16 }}>
              Workflow Configuration — {form.ciType}
            </h2>

            {/* Clinical Criteria */}
            {form.ciType === 'Clinical Criteria' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Drug Name(s) * <span className="text-gray-400 font-normal">(typeahead — NDC crosswalk)</span></label>
                  <div className="flex gap-2">
                    <input
                      className="input flex-1"
                      placeholder="Start typing drug name..."
                      value={drugInput}
                      onChange={e => setDrugInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && addDrug()}
                      list="drug-list"
                    />
                    <datalist id="drug-list">{DRUG_SUGGESTIONS.map(d => <option key={d} value={d} />)}</datalist>
                    <button onClick={addDrug} className="btn-secondary text-xs flex items-center gap-1"><Plus size={13} /> Add</button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {form.drugs.map(d => (
                      <span key={d} className="bg-brand-light text-brand-navy text-xs px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold">
                        {d} <button onClick={() => removeDrug(d)}><X size={11} /></button>
                      </span>
                    ))}
                    {!form.drugs.length && <p className="text-xs text-gray-400 italic">No drugs added yet.</p>}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">Indication <span className="text-gray-400 font-normal">(optional)</span></label>
                    <input name="indication" value={form.indication} onChange={handle} className="input" list="indication-list" placeholder="e.g. Rheumatoid Arthritis" />
                    <datalist id="indication-list">{INDICATIONS.map(i => <option key={i} value={i} />)}</datalist>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">Policy Type</label>
                    <select name="policyType" value={form.policyType} onChange={handle} className="select">
                      <option>Pharmacy</option>
                      <option>Medical</option>
                      <option>Both</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-2">Competitor Set</label>
                  <div className="flex flex-wrap gap-2">
                    {allCompetitors.map(c => (
                      <button key={c} type="button" onClick={() => toggleCompetitor(compKey, c)}
                        className={`text-xs px-3 py-1.5 rounded-full border font-semibold transition-all ${activeCompetitors.includes(c) ? 'bg-brand-navy text-white border-brand-navy' : 'border-gray-300 text-gray-500 hover:border-brand-navy'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
                <label className="btn-secondary text-xs cursor-pointer flex items-center gap-1.5 w-fit">
                  <Upload size={13} /> Upload Internal Carelon Policy (optional)
                  <input type="file" className="hidden" accept=".pdf,.docx" />
                </label>
              </div>
            )}

            {/* Designated Network */}
            {form.ciType === 'Designated Network' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Designated Network Program *</label>
                  <select name="dnProgram" value={form.dnProgram} onChange={handle} className="select">
                    <option value="">Select a program...</option>
                    {DN_PROGRAMS.map(p => <option key={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-2">Competitor Set</label>
                  <div className="flex flex-wrap gap-2">
                    {COMPETITORS_BY_TYPE['Designated Network'].map(c => (
                      <button key={c} type="button" onClick={() => toggleCompetitor(compKey, c)}
                        className={`text-xs px-3 py-1.5 rounded-full border font-semibold transition-all ${activeCompetitors.includes(c) ? 'bg-brand-navy text-white border-brand-navy' : 'border-gray-300 text-gray-500 hover:border-brand-navy'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-gray-400 mt-1">Additional competitors TBD — contact Ray Lew.</p>
                </div>
                <label className="btn-secondary text-xs cursor-pointer flex items-center gap-1.5 w-fit">
                  <Upload size={13} /> Upload Internal Drug List (optional)
                  <input type="file" className="hidden" accept=".pdf,.csv,.xlsx" />
                </label>
              </div>
            )}

            {/* Preventive Rx */}
            {form.ciType === 'Preventive Rx' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Carelon PreventiveRx Baseline List *</label>
                  <select name="prevRxList" value={form.prevRxList} onChange={handle} className="select">
                    <option value="">Select a list...</option>
                    {PREV_RX_LISTS.map(l => <option key={l}>{l}</option>)}
                  </select>
                  <p className="text-xs text-gray-400 mt-1">Lists sourced from iDiscovery (cannot be publicly available).</p>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-2">Competitor Set</label>
                  <div className="flex flex-wrap gap-2">
                    {COMPETITORS_BY_TYPE['Preventive Rx'].map(c => (
                      <button key={c} type="button" onClick={() => toggleCompetitor(compKey, c)}
                        className={`text-xs px-3 py-1.5 rounded-full border font-semibold transition-all ${activeCompetitors.includes(c) ? 'bg-brand-navy text-white border-brand-navy' : 'border-gray-300 text-gray-500 hover:border-brand-navy'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
                <label className="btn-secondary text-xs cursor-pointer flex items-center gap-1.5 w-fit">
                  <Upload size={13} /> Upload Carelon Baseline List (if not in iDiscovery)
                  <input type="file" className="hidden" accept=".pdf,.xlsx,.csv" />
                </label>
              </div>
            )}
          </>
        )}

        {/* ── Step 2: Review & Generate ── */}
        {step === 2 && (
          <>
            <h2 className="font-bold text-brand-navy" style={{ fontSize: 16 }}>Review & Generate</h2>
            <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
              {[
                ['Project Name', form.name],
                ['LOB', form.lob],
                ['Market', form.market],
                ['Workflow Type', form.ciType],
                form.ciType === 'Clinical Criteria' && ['Drug(s)', form.drugs.join(', ')],
                form.ciType === 'Clinical Criteria' && form.indication && ['Indication', form.indication],
                form.ciType === 'Clinical Criteria' && ['Policy Type', form.policyType],
                form.ciType === 'Designated Network' && ['Program', form.dnProgram],
                form.ciType === 'Preventive Rx' && ['Baseline List', form.prevRxList],
                ['Competitors', activeCompetitors.join(', ')],
                form.comments && ['Comments', form.comments],
              ].filter(Boolean).map(([k, v]) => (
                <div key={k} className="flex gap-3">
                  <span className="text-gray-400 w-32 shrink-0 text-xs">{k}</span>
                  <span className="text-gray-700 font-semibold text-xs">{v}</span>
                </div>
              ))}
            </div>
            <div className="bg-brand-iceBlue rounded-lg p-3 text-xs text-brand-navy space-y-1">
              <p><strong>What happens next:</strong></p>
              <p>1. Project is created with status <strong>Open</strong></p>
              <p>2. Navigate to the project and click <strong>Generate Intelligence</strong> to trigger AI analysis</p>
              <p>3. System sources documents from iDiscovery (fallback: web search) and generates comparison grid</p>
              <p>4. Review, edit, and approve the AI-generated output before exporting</p>
            </div>
          </>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <button
            onClick={() => step === 0 ? navigate('/projects') : back()}
            className="btn-secondary text-xs"
          >
            {step === 0 ? 'Cancel' : '← Back'}
          </button>
          {step < 2 ? (
            <button onClick={next} disabled={!validate()} className="btn-primary flex items-center gap-1.5 text-xs disabled:opacity-50">
              Next <ChevronRight size={14} />
            </button>
          ) : (
            <button onClick={submit} className="btn-primary flex items-center gap-1.5 text-xs">
              <CheckCircle size={14} /> Create Project
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
