import { useState, useMemo, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ChevronDown, ChevronUp, CheckCircle, AlertTriangle, TrendingUp, TrendingDown, Minus, BarChart2, FileText, ExternalLink, Info, Download, Filter, Search, X, Zap, Upload, FileSpreadsheet, Clock } from 'lucide-react';

const VARIANCE = {
  stricter:      { label: 'Stricter',      bg: '#FFF0E8', border: '#FDBA74', text: '#C2410C' },
  lenient:       { label: 'More Lenient',  bg: '#FEFCE8', border: '#FDE047', text: '#A16207' },
  same:          { label: 'Equivalent',    bg: '#F0FDF4', border: '#86EFAC', text: '#166534' },
  notComparable: { label: 'Not Comparable',bg: '#F9FAFB', border: '#E5E7EB', text: '#6B7280' },
};

const COMPETITORS = ['Excellus BCBS', 'UHC', 'Caremark', 'Molina'];

const SRC = { policy: 'Skyrizi Competitor Analysis', effectiveDate: '2026-02-19', url: '#' };

const CRITERIA_DATA = [
  /* ── General ── */
  {
    category: 'General', subCategory: 'Formulary Status', criterion: 'Preferred Drug Tier',
    conditions: ['CD','PsA','Ps','UC'],
    elevance: { value: 'Tier 3', note: 'Last updated Feb 19 2026' },
    competitors: {
      'Excellus BCBS': { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'UHC':           { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'Caremark':      { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'Molina':        { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
    }, source: SRC,
  },
  /* ── Initial PA — CD ── */
  {
    category: 'Initial PA Criteria', subCategory: 'CD — Age', criterion: 'Minimum Age (CD)',
    conditions: ['CD'],
    elevance: { value: '18+', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'18+',variance:'same'} },
      'UHC':           { CD:{value:'No age requirement',variance:'lenient'} },
      'Caremark':      { CD:{value:'No age requirement',variance:'lenient'} },
      'Molina':        { CD:{value:'18+',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'CD — Diagnosis', criterion: 'Disease Severity (CD)',
    conditions: ['CD'],
    elevance: { value: 'Mod-severe CD', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'Mod-severe CD',variance:'same'} },
      'UHC':           { CD:{value:'Mod-severe CD',variance:'same'} },
      'Caremark':      { CD:{value:'Just dx of CD (no severity req.)',variance:'lenient'} },
      'Molina':        { CD:{value:'Mod-severe CD',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'CD — Other', criterion: 'Other CD Criteria',
    conditions: ['CD'],
    elevance: { value: 'n/a', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'Prescribed/consult by Gastroenterologist AND doc of T/F or CI of azathioprine, 6-MP, or MTX. Biologic 1st-line case-by-case via LMN.',variance:'stricter'} },
      'UHC':           { CD:{value:'Prescribed/consult by Gastroenterologist',variance:'stricter'} },
      'Caremark':      { CD:{value:'≥1 high risk feature AND t/f immunomodulator at max dose x3mo (or justification). Baseline disease activity doc required.',variance:'stricter'} },
      'Molina':        { CD:{value:'Initial dosing: 600 mg IV at Wk 0, 4, 8. Maintenance: 360 mg SC q8wk.',variance:'notComparable'} },
    }, source: SRC,
  },
  /* ── Initial PA — PsA ── */
  {
    category: 'Initial PA Criteria', subCategory: 'PsA — Age', criterion: 'Minimum Age (PsA)',
    conditions: ['PsA'],
    elevance: { value: '18+', note: '' },
    competitors: {
      'Excellus BCBS': { PsA:{value:'18+',variance:'same'} },
      'UHC':           { PsA:{value:'No age requirement',variance:'lenient'} },
      'Caremark':      { PsA:{value:'18+',variance:'same'} },
      'Molina':        { PsA:{value:'18+',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'PsA — Diagnosis', criterion: 'Disease Severity (PsA)',
    conditions: ['PsA'],
    elevance: { value: 'Mod-to-severe PsA', note: '' },
    competitors: {
      'Excellus BCBS': { PsA:{value:'"Active" PsA',variance:'lenient'} },
      'UHC':           { PsA:{value:'Severe: no criteria below; Mild-mod AND criteria below',variance:'notComparable'} },
      'Caremark':      { PsA:{value:'"Active"; if severe (doc required) no other criteria',variance:'lenient'} },
      'Molina':        { PsA:{value:'"Active" PsA',variance:'lenient'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'PsA — Step Therapy', criterion: 'T/F DMARDs (PsA)',
    conditions: ['PsA'],
    elevance: { value: 'T/F DMARDs (MTX, sulfasalazine, cyclosporine, or leflunomide)', note: '' },
    competitors: {
      'Excellus BCBS': { PsA:{value:'No DMARD requirement',variance:'lenient'} },
      'UHC':           { PsA:{value:'T/F MTX x3mo OR prev TIM OR claim hx of current Skyrizi',variance:'same'} },
      'Caremark':      { PsA:{value:'T/F DMARDs',variance:'same'} },
      'Molina':        { PsA:{value:'T/F DMARDs x3mo',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'PsA — Step Therapy', criterion: 'CI to DMARDs (PsA)',
    conditions: ['PsA'],
    elevance: { value: 'CI to DMARDs accepted', note: '' },
    competitors: {
      'Excellus BCBS': { PsA:{value:'No DMARD req. — CI not applicable',variance:'lenient'} },
      'UHC':           { PsA:{value:'CI accepted',variance:'same'} },
      'Caremark':      { PsA:{value:'CI accepted',variance:'same'} },
      'Molina':        { PsA:{value:'CI accepted',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'PsA — Other', criterion: 'Other PsA Criteria',
    conditions: ['PsA'],
    elevance: { value: 'n/a', note: '' },
    competitors: {
      'Excellus BCBS': { PsA:{value:'Prescribed/consult by Dermatologist or Rheumatologist',variance:'stricter'} },
      'UHC':           { PsA:{value:'Prescribed/consult by Derm or Rheum AND not in combo with other TIMs',variance:'stricter'} },
      'Caremark':      { PsA:{value:'Prescribed/consult by Derm or Rheum',variance:'stricter'} },
      'Molina':        { PsA:{value:'Baseline disease activity evaluation and treatment goals required',variance:'stricter'} },
    }, source: SRC,
  },
  /* ── Initial PA — Ps ── */
  {
    category: 'Initial PA Criteria', subCategory: 'Ps — Age', criterion: 'Minimum Age (Ps)',
    conditions: ['Ps'],
    elevance: { value: '18+', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'18+',variance:'same'} },
      'UHC':           { Ps:{value:'No age requirement',variance:'lenient'} },
      'Caremark':      { Ps:{value:'No age requirement',variance:'lenient'} },
      'Molina':        { Ps:{value:'18+',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'Ps — Diagnosis', criterion: 'Disease Severity (Ps)',
    conditions: ['Ps'],
    elevance: { value: 'Chronic mod-severe Ps: >3% BSA OR <3% BSA in sensitive areas (palms, soles, head/neck, genitalia)', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'>10% BSA OR <10% in sensitive areas',variance:'stricter'} },
      'UHC':           { Ps:{value:'Ps ≥3% BSA in sensitive areas only',variance:'stricter'} },
      'Caremark':      { Ps:{value:'Doc required: ≥10% BSA OR ≥3% BSA AND t/f phototherapy/pharmacologic tx',variance:'stricter'} },
      'Molina':        { Ps:{value:'Chronic mod-severe Ps',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'Ps — Step Therapy', criterion: 'T/F Phototherapy or Systemic (Ps)',
    conditions: ['Ps'],
    elevance: { value: 'T/F phototherapy or systemic therapy', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'T/F phototherapy x3mo',variance:'same'} },
      'UHC':           { Ps:{value:'T/F topicals + MTX x3mo OR prev TIM OR Skyrizi claim hx',variance:'notComparable'} },
      'Caremark':      { Ps:{value:'T/F phototherapy only if ≥3% BSA',variance:'lenient'} },
      'Molina':        { Ps:{value:'T/F TWO systemic tx or phototherapy x3mo',variance:'stricter'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'Ps — Step Therapy', criterion: 'CI to Phototherapy/Acitretin/Cyclosporine/MTX (Ps)',
    conditions: ['Ps'],
    elevance: { value: 'CI accepted', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'CI accepted',variance:'same'} },
      'UHC':           { Ps:{value:'No CI exception noted',variance:'stricter'} },
      'Caremark':      { Ps:{value:'Only with ≥3% BSA',variance:'stricter'} },
      'Molina':        { Ps:{value:'CI accepted',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'Ps — Other', criterion: 'Other Ps Criteria',
    conditions: ['Ps'],
    elevance: { value: 'n/a', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'Prescribed/consult by Dermatologist or Rheumatologist',variance:'stricter'} },
      'UHC':           { Ps:{value:'Prescribed/consult by Dermatologist AND not in combo w other TIM',variance:'stricter'} },
      'Caremark':      { Ps:{value:'Prescribed/consult by Dermatologist',variance:'stricter'} },
      'Molina':        { Ps:{value:'Baseline disease activity doc + treatment goals required at renewal',variance:'stricter'} },
    }, source: SRC,
  },
  /* ── Initial PA — UC ── */
  {
    category: 'Initial PA Criteria', subCategory: 'UC — Age', criterion: 'Minimum Age (UC)',
    conditions: ['UC'],
    elevance: { value: '18+', note: '' },
    competitors: {
      'Excellus BCBS': { UC:{value:'18+',variance:'same'} },
      'UHC':           { UC:{value:'No age requirement',variance:'lenient'} },
      'Caremark':      { UC:{value:'No age requirement',variance:'lenient'} },
      'Molina':        { UC:{value:'18+',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'UC — Diagnosis', criterion: 'Disease Severity (UC)',
    conditions: ['UC'],
    elevance: { value: 'Mod-severe UC', note: '' },
    competitors: {
      'Excellus BCBS': { UC:{value:'Mod-severe UC',variance:'same'} },
      'UHC':           { UC:{value:'Mod-severe UC',variance:'same'} },
      'Caremark':      { UC:{value:'Mod-severe UC',variance:'same'} },
      'Molina':        { UC:{value:'Mod-severe UC; doc required; if severe = baseline only',variance:'same'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'UC — Other', criterion: 'Other UC Criteria',
    conditions: ['UC'],
    elevance: { value: 'n/a', note: '' },
    competitors: {
      'Excellus BCBS': { UC:{value:'Prescribed/consult by Gastroenterologist AND T/F ≥1 conventional tx x3mo OR pouchitis antibiotic',variance:'stricter'} },
      'UHC':           { UC:{value:'Prescribed/consult by Gastroenterologist AND approved for LD under medical OR currently on Skyrizi AND not in combo w TIMs',variance:'stricter'} },
      'Caremark':      { UC:{value:'Prescribed/consult by Gastroenterologist',variance:'stricter'} },
      'Molina':        { UC:{value:'Doc T/F/CI of one systemic x2mo AND doc pouchitis with antibiotic trial',variance:'stricter'} },
    }, source: SRC,
  },
  {
    category: 'Initial PA Criteria', subCategory: 'Overall', criterion: 'Other Overall Criteria',
    conditions: ['CD','PsA','Ps','UC'],
    elevance: { value: 'n/a', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'UHC':           { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'Caremark':      { CD:{value:'Negative TB test w/in 12mo; no combo w biologic/targeted synthetic drugs for same indication',variance:'stricter'}, PsA:{value:'Same',variance:'stricter'}, Ps:{value:'Same',variance:'stricter'}, UC:{value:'Same',variance:'stricter'} },
      'Molina':        { CD:{value:'No active/latent untreated infection; not in COMBO w TNF-inhibitor/biologic DMARD/JKI/PDE4i; if non-preferred, doc T/F of majority of preferred formulary',variance:'stricter'}, PsA:{value:'Same',variance:'stricter'}, Ps:{value:'Same',variance:'stricter'}, UC:{value:'Same',variance:'stricter'} },
    }, source: SRC,
  },
  /* ── Continuation PA ── */
  {
    category: "Continuation / Reauthorization", subCategory: "Stable Dose", criterion: 'Stable Dose Documentation',
    conditions: ['CD','PsA','Ps','UC'],
    elevance: { value: 'Yes — member received and maintained on stable dose', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'n/a',variance:'lenient'}, PsA:{value:'n/a',variance:'lenient'}, Ps:{value:'n/a',variance:'lenient'}, UC:{value:'n/a',variance:'lenient'} },
      'UHC':           { CD:{value:'No',variance:'lenient'}, PsA:{value:'No',variance:'lenient'}, Ps:{value:'No',variance:'lenient'}, UC:{value:'No',variance:'lenient'} },
      'Caremark':      { CD:{value:'Yes',variance:'same'}, PsA:{value:'Yes',variance:'same'}, Ps:{value:'Yes',variance:'same'}, UC:{value:'Yes',variance:'same'} },
      'Molina':        { CD:{value:'n/a',variance:'lenient'}, PsA:{value:'n/a',variance:'lenient'}, Ps:{value:'n/a',variance:'lenient'}, UC:{value:'n/a',variance:'lenient'} },
    }, source: SRC,
  },
  {
    category: "Continuation / Reauthorization", subCategory: "No Manufacturer Samples", criterion: 'Meds Not via Manufacturer PAP/Samples',
    conditions: ['CD','PsA','Ps','UC'],
    elevance: { value: 'Yes — meds not through manufacturer sponsored/supplied or PAP', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'n/a',variance:'lenient'}, PsA:{value:'n/a',variance:'lenient'}, Ps:{value:'n/a',variance:'lenient'}, UC:{value:'n/a',variance:'lenient'} },
      'UHC':           { CD:{value:'Yes',variance:'same'}, PsA:{value:'Yes',variance:'same'}, Ps:{value:'Yes',variance:'same'}, UC:{value:'Yes',variance:'same'} },
      'Caremark':      { CD:{value:'Yes',variance:'same'}, PsA:{value:'Yes',variance:'same'}, Ps:{value:'Yes',variance:'same'}, UC:{value:'Yes',variance:'same'} },
      'Molina':        { CD:{value:'n/a',variance:'lenient'}, PsA:{value:'n/a',variance:'lenient'}, Ps:{value:'n/a',variance:'lenient'}, UC:{value:'n/a',variance:'lenient'} },
    }, source: SRC,
  },
  {
    category: "Continuation / Reauthorization", subCategory: "Clinical Response", criterion: 'Clinically Significant Improvement / Stabilization',
    conditions: ['CD','PsA','Ps','UC'],
    elevance: { value: 'Yes — clinically significant improvement/stabilization in s/sx required', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'n/a',variance:'lenient'}, PsA:{value:'n/a',variance:'lenient'}, Ps:{value:'n/a',variance:'lenient'}, UC:{value:'n/a',variance:'lenient'} },
      'UHC':           { CD:{value:'Yes; doc required',variance:'same'}, PsA:{value:'Yes; doc required',variance:'same'}, Ps:{value:'Yes; doc required',variance:'same'}, UC:{value:'Yes; doc required',variance:'same'} },
      'Caremark':      { CD:{value:'Yes; doc required: positive clinical response',variance:'same'}, PsA:{value:'Yes; positive clinical response (specific evidence)',variance:'same'}, Ps:{value:'Yes; dec in BSA &/or improvement in s/sx',variance:'same'}, UC:{value:'Yes; positive clinical response (specific evidence)',variance:'same'} },
      'Molina':        { CD:{value:'Yes; doc required',variance:'same'}, PsA:{value:'Yes; doc required',variance:'same'}, Ps:{value:'Yes; doc required',variance:'same'}, UC:{value:'Yes; doc required',variance:'same'} },
    }, source: SRC,
  },
  {
    category: "Continuation / Reauthorization", subCategory: "Other Con't Criteria", criterion: "Other Criteria for Continuation",
    conditions: ['CD','PsA','Ps','UC'],
    elevance: { value: 'n/a', note: '' },
    competitors: {
      'Excellus BCBS': { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'UHC':           { CD:{value:'Not in combo w other TIMs',variance:'stricter'}, PsA:{value:'Not in combo w other TIMs',variance:'stricter'}, Ps:{value:'Not in combo w other TIMs',variance:'stricter'}, UC:{value:'Not in combo w other TIMs',variance:'stricter'} },
      'Caremark':      { CD:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'}, Ps:{value:'n/a',variance:'notComparable'}, UC:{value:'n/a',variance:'notComparable'} },
      'Molina':        { CD:{value:'Adherence ≥85% verified AND provider attests no intolerable AEs; ongoing infection monitoring',variance:'stricter'}, PsA:{value:'Same',variance:'stricter'}, Ps:{value:'Same',variance:'stricter'}, UC:{value:'Same',variance:'stricter'} },
    }, source: SRC,
  },
  /* ── Other Comments ── */
  {
    category: 'Other Comments', subCategory: 'Non-Approvalables', criterion: 'Includes Non-Approvable Conditions',
    conditions: ['Ps','PsA'],
    elevance: { value: 'I. Combo w phototherapy; II. Combo w JAK-i/apremilast/deucravacitinib/etrasimod/ozanimod or biologic immunomodulators (TNF, IL-23, IL-17, vedolizumab, ustekinumab, abatacept, IL-1, IL-6, rituximab, natalizumab); III. Active TB/serious infection/recurrent infection hx; IV. No TST/IGRA if initiating (unless switching TIM w no new risk factors); V. Criteria not met / other indications', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
      'UHC':           { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
      'Caremark':      { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
      'Molina':        { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
    }, source: SRC,
  },
  {
    category: 'Other Comments', subCategory: 'Extra Doses', criterion: 'Extra Dose Criteria',
    conditions: ['Ps','PsA'],
    elevance: { value: 'Up to 4 × 90mg/mL pens OR up to 2 × 180mg/1.2mL syringes per 56 days if clinical necessity of prefilled pen documented and unable to use 360mg on-body injector', note: '' },
    competitors: {
      'Excellus BCBS': { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
      'UHC':           { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
      'Caremark':      { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
      'Molina':        { Ps:{value:'n/a',variance:'notComparable'}, PsA:{value:'n/a',variance:'notComparable'} },
    }, source: SRC,
  },
];

const CATEGORIES = [
  { name: 'General',                        color: '#1A3673', bg: '#E8F0FF' },
  { name: 'Initial PA Criteria',            color: '#7C3AED', bg: '#F0EEFF' },
  { name: 'Continuation / Reauthorization', color: '#059669', bg: '#EDFFF8' },
  { name: 'Other Comments',                 color: '#B45309', bg: '#FFF8E8' },
];

const NAV_TABS = [
  { id: 'criteria', label: 'Clinical Criteria',  enabled: true },
];

function VCell({ value, variance }) {
  const v = VARIANCE[variance] || VARIANCE.notComparable;
  return (
    <div className="rounded-lg px-2 py-1.5 text-xs leading-snug" style={{ backgroundColor: v.bg, borderLeft: `3px solid ${v.border}` }}>
      <div className="flex items-center gap-1 mb-0.5">
        {variance === 'stricter'      && <TrendingUp   size={9} style={{ color: v.text }}/>}
        {variance === 'lenient'       && <TrendingDown size={9} style={{ color: v.text }}/>}
        {variance === 'same'          && <Minus        size={9} style={{ color: v.text }}/>}
        {variance === 'notComparable' && <Info         size={9} style={{ color: v.text }}/>}
        <span className="font-bold" style={{ color: v.text, fontSize: 9 }}>{v.label}</span>
      </div>
      <p className="text-gray-700" style={{ fontSize: 10 }}>{value === 'n/a' ? 'N/A' : value}</p>
    </div>
  );
}

function SrcBadge({ source, open, onToggle }) {
  return (
    <div className="relative inline-block">
      <button onClick={onToggle} className="flex items-center gap-1 text-[10px] text-gray-400 hover:text-brand-navy transition-colors">
        <FileText size={10}/> Source
      </button>
      {open && (
        <div className="absolute left-0 top-full mt-1 z-30 bg-white border border-gray-200 rounded-xl shadow-xl p-3 w-60 text-xs">
          <p className="font-bold text-gray-700 mb-1">{source.policy}</p>
          <p className="text-gray-400 mb-1">Effective: {source.effectiveDate}</p>
          <a href={source.url} className="flex items-center gap-1 text-brand-navy font-semibold hover:underline">
            <ExternalLink size={10}/> View Policy
          </a>
        </div>
      )}
    </div>
  );
}

const SNAPSHOT_META = {
  'jun-2026': { label: 'Jun 2026', date: 'Jun 1, 2026'  },
  'mar-2026': { label: 'Mar 2026', date: 'Mar 1, 2026'  },
  'dec-2025': { label: 'Dec 2025', date: 'Dec 1, 2025'  },
  'sep-2025': { label: 'Sep 2025', date: 'Sep 1, 2025'  },
};

export default function ClinicalCriteriaWorkflow() {
  const [searchParams] = useSearchParams();
  const activeSnapshot = searchParams.get('snapshot');
  const [activeTab, setActiveTab]     = useState('criteria');
  const [activeCond, setActiveCond]   = useState('all');
  const [collapsed, setCollapsed]     = useState({});
  const [sourceOpen, setSourceOpen]   = useState(null);
  const [selectedDrug, setSelectedDrug] = useState('');
  const [searchQ, setSearchQ]           = useState('');
  const [drugQuery, setDrugQuery]       = useState('');
  const [drugListOpen, setDrugListOpen] = useState(false);
  const [drugOptions, setDrugOptions]   = useState(['Skyrizi (risankizumab)', 'Humira (adalimumab)', 'Stelara (ustekinumab)', 'Rinvoq (upadacitinib)', 'Tremfya (guselkumab)']);
  const drugInputRef = useRef(null);
  const drugDropRef  = useRef(null);
  const [generating, setGenerating]   = useState(false);
  const [generated, setGenerated]     = useState(false);
  const [reportStatus, setReportStatus] = useState('in-progress');
  const [uploadedFile, setUploadedFile] = useState(null);
  const [exportOpen, setExportOpen]   = useState(false);
  const [snapshotOpen, setSnapshotOpen] = useState(false);
  const fileInputRef  = useRef(null);
  const exportRef    = useRef(null);
  const snapshotRef  = useRef(null);
  const navigate     = useNavigate();

  function selectDrug(name) {
    setSelectedDrug(name);
    setDrugQuery(name);
    setDrugListOpen(false);
    setGenerated(false);
    setSearchQ('');
  }
  function addNewDrug() {
    const trimmed = drugQuery.trim();
    if (!trimmed) return;
    if (!drugOptions.includes(trimmed)) setDrugOptions(prev => [...prev, trimmed]);
    selectDrug(trimmed);
  }

  function handleGenerate() {
    if (!selectedDrug) return;
    setGenerating(true); setGenerated(false); setReportStatus('in-progress');
    setTimeout(() => { setGenerating(false); setGenerated(true); setReportStatus('in-review'); }, 2500);
  }
  function handleFileUpload(e) {
    const f = e.target.files[0];
    if (f) setUploadedFile(f);
    e.target.value = '';
  }

  const CONDITIONS = useMemo(() => {
    const conds = new Set();
    CRITERIA_DATA.forEach(row => row.conditions.forEach(c => conds.add(c)));
    return ['all', ...Array.from(conds).sort()];
  }, []);

  const filteredCriteria = useMemo(() => {
    return CRITERIA_DATA.filter(row => {
      const matchCond = activeCond === 'all' || row.conditions.includes(activeCond);
      const q = searchQ.toLowerCase();
      const matchSearch = !q || row.criterion.toLowerCase().includes(q) || row.category.toLowerCase().includes(q) || row.subCategory.toLowerCase().includes(q);
      return matchCond && matchSearch;
    });
  }, [activeCond, searchQ]);

  const summary = useMemo(() => {
    let stricter = 0, lenient = 0, same = 0, notComp = 0;
    filteredCriteria.forEach(row => {
      COMPETITORS.forEach(comp => {
        const keys = activeCond === 'all' ? row.conditions : [activeCond];
        keys.forEach(cond => {
          const cell = row.competitors[comp]?.[cond];
          if (!cell) return;
          if (cell.variance === 'stricter') stricter++;
          else if (cell.variance === 'lenient') lenient++;
          else if (cell.variance === 'same') same++;
          else notComp++;
        });
      });
    });
    return { stricter, lenient, same, notComp };
  }, [filteredCriteria, activeCond]);

  const topOpportunities = useMemo(() => {
    return CRITERIA_DATA.map(row => {
      let n = 0;
      COMPETITORS.forEach(comp => row.conditions.forEach(cond => {
        if (row.competitors[comp]?.[cond]?.variance === 'stricter') n++;
      }));
      return { label: row.criterion, count: n };
    }).filter(r => r.count > 0).sort((a,b) => b.count - a.count).slice(0, 3);
  }, []);

  const grouped = useMemo(() => {
    const m = {};
    filteredCriteria.forEach(row => { (m[row.category] = m[row.category] || []).push(row); });
    return m;
  }, [filteredCriteria]);

  return (
    <div className="space-y-5">

      {/* ── HEADER ── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Clinical Criteria</p>
          <h1 className="text-2xl font-bold text-brand-navy">Competitive Intelligence</h1>
          <p className="text-xs text-gray-400 mt-1">Elevance as baseline · Color-coded variance · 4 competitors · Source-traced</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Historical Snapshot badge */}
          {activeSnapshot && SNAPSHOT_META[activeSnapshot] && (
            <span className="inline-flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1.5 rounded-full"
              style={{ backgroundColor: 'rgba(68,184,243,0.12)', color: '#44B8F3', border: '1px solid rgba(68,184,243,0.35)' }}>
              <Clock size={9}/> Historical · {SNAPSHOT_META[activeSnapshot].date}
            </span>
          )}
          {/* Export */}
          <div className="relative" ref={exportRef}>
            <button
              onClick={() => reportStatus === 'approved' && setExportOpen(o => !o)}
              disabled={reportStatus !== 'approved'}
              className={`btn-secondary flex items-center gap-2 text-xs transition-all ${reportStatus !== 'approved' ? 'opacity-40 cursor-not-allowed' : ''}`}>
              <Download size={14}/> Export <ChevronDown size={12} className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`}/>
            </button>
            {exportOpen && (
              <div className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
                {[
                  { label: 'PowerPoint (.pptx)', icon: <FileText size={13} className="text-orange-500"/> },
                  { label: 'PDF (.pdf)',          icon: <FileText size={13} className="text-red-500"/> },
                  { label: 'Excel (.xlsx)',       icon: <FileSpreadsheet size={13} className="text-emerald-600"/> },
                ].map(opt => (
                  <button key={opt.label} onClick={() => setExportOpen(false)}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                    {opt.icon} {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── SECTION 1: SELECT DRUG ── */}
      <div className="card py-4 px-5">
        <div className="flex items-center justify-between mb-3">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Select Drug</p>
          {selectedDrug && (
            <button onClick={() => { setSelectedDrug(''); setDrugQuery(''); setGenerated(false); }}
              className="text-[10px] text-gray-400 hover:text-red-500 font-semibold flex items-center gap-1">
              <X size={10}/> Clear
            </button>
          )}
        </div>

        <div className="relative" ref={drugDropRef} style={{ maxWidth: 520 }}>
          {/* Search input */}
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
            <input
              ref={drugInputRef}
              className={`input pl-9 pr-9 text-sm py-2.5 w-full font-medium transition-all ${selectedDrug ? 'border-brand-navy ring-1 ring-brand-navy/20' : ''}`}
              placeholder="Type drug name or generic (e.g. 'skyrizi', 'adalimumab')…"
              value={drugQuery}
              onChange={e => { setDrugQuery(e.target.value); setDrugListOpen(true); if (!e.target.value) { setSelectedDrug(''); setGenerated(false); } }}
              onFocus={() => setDrugListOpen(true)}
              onBlur={() => setTimeout(() => setDrugListOpen(false), 180)}
            />
            {selectedDrug && !drugListOpen && (
              <CheckCircle size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-navy pointer-events-none"/>
            )}
            {drugQuery && drugListOpen && (
              <button onMouseDown={() => { setDrugQuery(''); setSelectedDrug(''); setGenerated(false); drugInputRef.current?.focus(); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500">
                <X size={13}/>
              </button>
            )}
          </div>

          {/* Selected drug badge */}
          {selectedDrug && !drugListOpen && (
            <div className="flex items-center gap-2 mt-2.5">
              <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">Selected:</span>
              <span className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-full"
                style={{ backgroundColor: '#E8F0FF', color: '#1A3673', border: '1px solid #B8CEFF' }}>
                {selectedDrug}
              </span>
            </div>
          )}

          {/* Dropdown */}
          {drugListOpen && (() => {
            const q = drugQuery.toLowerCase().trim();
            const matched = drugOptions.filter(d => !q || d.toLowerCase().includes(q));
            const exactMatch = drugOptions.some(d => d.toLowerCase() === q);
            const noResults = q && matched.length === 0;
            return (
              <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-2xl z-50 overflow-hidden">
                {/* Matched results */}
                {matched.length > 0 && (
                  <div style={{ maxHeight: 220, overflowY: 'auto' }}>
                    {!q && <p className="px-4 pt-3 pb-1 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Available Drugs</p>}
                    {matched.map(d => {
                      const idx = q ? d.toLowerCase().indexOf(q) : -1;
                      return (
                        <button key={d} onMouseDown={() => selectDrug(d)}
                          className={`w-full text-left px-4 py-2.5 text-sm flex items-center gap-2 transition-colors ${
                            selectedDrug === d ? 'bg-[#E8F0FF] text-brand-navy font-bold' : 'text-gray-800 hover:bg-gray-50'
                          }`}>
                          <span className="flex-1">
                            {idx !== -1 ? (
                              <>
                                {d.slice(0, idx)}
                                <strong className="text-brand-navy bg-yellow-100 px-0.5 rounded">{d.slice(idx, idx + q.length)}</strong>
                                {d.slice(idx + q.length)}
                              </>
                            ) : d}
                          </span>
                          {selectedDrug === d && <CheckCircle size={13} className="text-brand-navy shrink-0"/>}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* No results + Add new */}
                {noResults && (
                  <div className="px-4 py-4">
                    <p className="text-sm text-gray-500 mb-3">
                      No match for <strong className="text-gray-800">"{drugQuery}"</strong>
                    </p>
                    <button onMouseDown={addNewDrug}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-bold text-white transition-colors"
                      style={{ backgroundColor: '#1A3673' }}>
                      <span className="text-lg leading-none">+</span>
                      Add "{drugQuery.trim()}" to drug list
                    </button>
                    <p className="text-[10px] text-gray-400 text-center mt-2">This will add it as a custom drug for analysis</p>
                  </div>
                )}

                {/* Add option alongside results */}
                {q && !exactMatch && matched.length > 0 && (
                  <div className="border-t border-gray-100 px-4 py-2.5 flex items-center justify-between">
                    <span className="text-xs text-gray-400">Not finding what you need?</span>
                    <button onMouseDown={addNewDrug}
                      className="text-xs font-bold px-3 py-1.5 rounded-lg border border-emerald-300 text-emerald-700 hover:bg-emerald-50 transition-colors flex items-center gap-1">
                      <span>+</span> Add "{drugQuery.trim()}"
                    </button>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      </div>

      {/* ── SECTION 2: GENERATE & UPLOAD ── */}
      <div className="card py-4 px-5">
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
          Generate Intelligence
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={handleGenerate} disabled={generating || !selectedDrug}
            className={`btn-primary flex items-center gap-2 px-5 py-2 text-sm font-semibold ${(generating || !selectedDrug) ? 'opacity-50 cursor-not-allowed' : ''}`}>
            <Zap size={15}/> {generating ? 'Generating…' : 'Generate Intelligence'}
          </button>
          <div className="h-6 w-px bg-gray-200"/>
          <input ref={fileInputRef} type="file" accept=".pdf,.xlsx,.xls,.csv,.docx" className="hidden" onChange={handleFileUpload}/>
          {uploadedFile ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
              <CheckCircle size={13} className="text-emerald-600 shrink-0"/>
              <span className="font-semibold text-emerald-800 max-w-[180px] truncate">{uploadedFile.name}</span>
              <button onClick={() => setUploadedFile(null)} className="ml-1 text-gray-400 hover:text-red-500"><X size={12}/></button>
            </div>
          ) : (
            <button onClick={() => fileInputRef.current?.click()} className="btn-secondary flex items-center gap-1.5 text-xs">
              <Upload size={13}/> Upload Criteria File
            </button>
          )}
          <div className="h-6 w-px bg-gray-200"/>
          {/* Status pipeline */}
          <div className="flex items-center gap-1.5">
            {[
              { key:'in-progress', label:'In Progress', activeColor:'#D97706', activeBg:'#FEF3C7', activeBorder:'#FCD34D', dot:'bg-amber-500' },
              { key:'in-review',   label:'In Review',   activeColor:'#1D4ED8', activeBg:'#EFF6FF', activeBorder:'#93C5FD', dot:'bg-blue-500'  },
              { key:'approved',    label:'Approved',    activeColor:'#059669', activeBg:'#ECFDF5', activeBorder:'#6EE7B7', dot:'bg-emerald-500'},
            ].map((step, idx) => {
              const steps = ['in-progress','in-review','approved'];
              const currentIdx = steps.indexOf(reportStatus);
              const stepIdx    = steps.indexOf(step.key);
              const isActive   = reportStatus === step.key;
              const isDone     = stepIdx < currentIdx;
              return (
                <div key={step.key} className="flex items-center gap-1.5">
                  {idx > 0 && <div className={`w-5 h-px ${isDone || isActive ? 'bg-gray-400' : 'bg-gray-200'}`}/>}
                  <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                    isActive ? 'border-current' : isDone ? 'bg-gray-50 text-gray-400 border-gray-200' : 'bg-white text-gray-300 border-gray-100'
                  }`} style={isActive ? { backgroundColor:step.activeBg, color:step.activeColor, borderColor:step.activeBorder } : {}}>
                    {isActive && step.key !== 'approved' && <span className={`w-1.5 h-1.5 rounded-full ${step.dot} ${step.key === 'in-progress' ? 'animate-pulse' : ''}`}/>}
                    {((isActive && step.key === 'approved') || isDone) ? <CheckCircle size={10} className={isDone ? 'text-gray-400' : 'text-emerald-500'}/> : null}
                    {step.label}
                  </span>
                </div>
              );
            })}
            {reportStatus === 'in-review' && (
              <button onClick={() => setReportStatus('approved')}
                className="ml-1 flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 transition-colors">
                <CheckCircle size={11}/> Approve
              </button>
            )}
            {reportStatus === 'approved' && (
              <button onClick={() => setReportStatus('in-review')} className="ml-1 text-[10px] text-gray-400 hover:text-red-400 underline">Revoke</button>
            )}
          </div>
        </div>
      </div>

      {/* Generating spinner */}
      {generating && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0"/>
          <div className="flex-1">
            <p className="text-brand-navy text-sm font-semibold">Generating competitive intelligence…</p>
            <div className="flex gap-4 mt-1.5 text-xs text-blue-600">
              {['Analyzing criteria','Comparing competitors','Detecting variance','Generating insights'].map((s,i) => (
                <span key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay:`${i*200}ms`}}/>{s}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── SECTION 3: TABLE ── */}
      {activeTab === 'criteria' && selectedDrug && generated && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              Competitive Criteria Matrix
            </p>
            {/* Historical Snapshots dropdown */}
            <div className="relative" ref={snapshotRef}>
              <button
                onClick={() => setSnapshotOpen(o => !o)}
                className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border transition-all ${
                  activeSnapshot ? 'border-[#44B8F3] text-[#44B8F3] bg-[rgba(68,184,243,0.08)]' : 'border-gray-200 text-gray-500 hover:border-brand-navy hover:text-brand-navy bg-white'
                }`}>
                <Clock size={12}/>
                {activeSnapshot && SNAPSHOT_META[activeSnapshot] ? `Snapshot · ${SNAPSHOT_META[activeSnapshot].date}` : 'Historical Snapshots'}
                <ChevronDown size={11} className={`transition-transform ${snapshotOpen ? 'rotate-180' : ''}`}/>
              </button>
              {snapshotOpen && (
                <div className="absolute right-0 mt-1 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
                  {activeSnapshot && (
                    <button
                      onClick={() => { navigate('/workflow/clinical-criteria'); setSnapshotOpen(false); }}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-xs text-red-500 hover:bg-red-50 border-b border-gray-100 font-semibold">
                      <X size={11}/> Clear snapshot
                    </button>
                  )}
                  {Object.entries(SNAPSHOT_META).map(([id, meta], idx) => (
                    <button key={id}
                      onClick={() => { navigate(`/workflow/clinical-criteria?snapshot=${id}`); setSnapshotOpen(false); }}
                      className={`w-full flex items-center justify-between px-4 py-2.5 text-xs hover:bg-gray-50 transition-colors ${
                        activeSnapshot === id ? 'text-[#44B8F3] font-bold' : 'text-gray-700 font-semibold'
                      }`}>
                      <span>{meta.date}</span>
                      <div className="flex items-center gap-1">
                        {idx === 0 && <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 uppercase tracking-wide">Current</span>}
                        {activeSnapshot === id && <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-[rgba(68,184,243,0.15)] text-[#44B8F3] uppercase tracking-wide">Active</span>}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-3 text-xs card py-2 px-4">
            <span className="font-bold text-gray-600 text-[10px] uppercase tracking-wider">Legend:</span>
            {Object.entries(VARIANCE).map(([k, v]) => (
              <span key={k} className="flex items-center gap-1 font-semibold px-2 py-0.5 rounded text-[10px]"
                style={{ backgroundColor: v.bg, color: v.text }}>
                {k === 'stricter' && <TrendingUp size={9}/>}
                {k === 'lenient'  && <TrendingDown size={9}/>}
                {k === 'same'     && <Minus size={9}/>}
                {k === 'notComparable' && <Info size={9}/>}
                {v.label}
              </span>
            ))}
            <span className="ml-auto text-[10px] text-gray-400">All comparisons relative to <strong className="text-brand-navy">Elevance</strong> baseline</span>
          </div>

          {/* Matrix */}
          <div className="card p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="text-left" style={{ borderCollapse:'separate', borderSpacing:0, minWidth: 860, width:'100%' }}>
                <thead className="sticky top-0 z-20">
                  <tr>
                    <th className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide bg-gray-50 border-b border-gray-200 sticky left-0 z-30" style={{ minWidth:260 }}>
                      Criterion
                    </th>
                    <th className="px-4 py-3 text-xs font-bold uppercase tracking-wide border-b border-gray-200 text-center" style={{ minWidth:190, backgroundColor:'#E8F0FF', color:'#1A3673' }}>
                      <div className="flex items-center justify-center gap-1.5">
                        Elevance <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-brand-navy text-white">BASELINE</span>
                      </div>
                    </th>
                    {COMPETITORS.map(c => (
                      <th key={c} className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide bg-gray-50 border-b border-gray-200 text-center" style={{ minWidth:180 }}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {CATEGORIES.map(cat => {
                    const rows = grouped[cat.name];
                    if (!rows?.length) return null;
                    const isOpen = !collapsed[cat.name];
                    return (
                      <> 
                        <tr key={`hdr-${cat.name}`}>
                          <td colSpan={2 + COMPETITORS.length} className="px-4 py-2 cursor-pointer select-none"
                            style={{ backgroundColor: cat.bg }} onClick={() => setCollapsed(p => ({ ...p, [cat.name]: !p[cat.name] }))}>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold uppercase tracking-wider" style={{ color: cat.color }}>{cat.name}</span>
                              <span className="text-[10px] text-gray-400">{rows.length} criteria</span>
                              <span className="ml-auto" style={{ color: cat.color }}>{isOpen ? <ChevronUp size={13}/> : <ChevronDown size={13}/>}</span>
                            </div>
                          </td>
                        </tr>
                        {isOpen && rows.map((row, ri) => {
                          const condKeys = activeCond === 'all' ? row.conditions : [activeCond];
                          const srcKey = `${cat.name}-${ri}`;
                          return (
                            <tr key={srcKey} className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors">
                              <td className="px-4 py-3 align-top border-b border-gray-100 sticky left-0 bg-white z-10" style={{ minWidth:260 }}>
                                <p className="text-xs font-bold text-gray-800 leading-snug">{row.criterion}</p>
                                <p className="text-[10px] text-gray-400 mt-0.5">{row.subCategory}</p>
                                <div className="flex flex-wrap gap-1 mt-1.5">
                                  {row.conditions.map(c => (
                                    <span key={c} className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${activeCond === c ? 'bg-brand-navy text-white' : 'bg-gray-100 text-gray-500'}`}>{c}</span>
                                  ))}
                                </div>
                                <div className="mt-1.5">
                                  <SrcBadge source={row.source} open={sourceOpen === srcKey} onToggle={() => setSourceOpen(s => s === srcKey ? null : srcKey)}/>
                                </div>
                              </td>
                              <td className="px-3 py-3 align-top border-b border-gray-100 text-center" style={{ backgroundColor:'#F0F6FF' }}>
                                <div className="text-xs font-semibold text-brand-navy leading-snug">{row.elevance.value}</div>
                                {row.elevance.note && <p className="text-[10px] text-gray-400 mt-0.5 italic">{row.elevance.note}</p>}
                              </td>
                              {COMPETITORS.map(comp => (
                                <td key={comp} className="px-3 py-3 align-top border-b border-gray-100">
                                  <div className="space-y-1.5">
                                    {condKeys.map(cond => {
                                      const cell = row.competitors[comp]?.[cond];
                                      if (!cell) return (
                                        <div key={cond} className="rounded px-2 py-1 text-[10px] text-gray-300 bg-gray-50 border-l-2 border-gray-100">
                                          {activeCond === 'all' ? `${cond}: ` : ''}—
                                        </div>
                                      );
                                      return (
                                        <div key={cond}>
                                          {activeCond === 'all' && <p className="text-[9px] font-bold text-gray-400 mb-0.5">{cond}</p>}
                                          <VCell value={cell.value} variance={cell.variance}/>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </td>
                              ))}
                            </tr>
                          );
                        })}
                      </>
                    );
                  })}
                </tbody>
              </table>
              {filteredCriteria.length === 0 && (
                <div className="py-12 text-center text-gray-400">
                  <Info size={24} className="mx-auto mb-2 opacity-30"/>
                  <p className="text-sm">No criteria match current filters.</p>
                </div>
              )}
            </div>
          </div>
          {/* AI Recommendations */}
          <div className="card">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E8F0FF' }}>
                <BarChart2 size={14} style={{ color: '#1A3673' }}/>
              </div>
              <div>
                <h2 className="font-bold text-brand-navy text-sm">AI Recommendations</h2>
                <p className="text-[10px] text-gray-400">Based on variance analysis vs. Elevance baseline · Human review required before action</p>
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-3">
              {[
                { title: 'Add Specialist Consult Requirement', cat: 'Competitive Opportunity', color: '#1A3673', bg: '#E8F0FF', trend: 'stricter',
                  body: '3 of 4 competitors (Excellus, CDPHP, UHC) require Gastroenterologist for CD/UC and Derm/Rheum for Ps/PsA. Elevance has no prescriber specialty requirement. Adding specialist attestation would align with market majority and improve clinical appropriateness.' },
                { title: 'Evaluate Shorter Auth Duration for CD/UC', cat: 'Market Trend', color: '#7C3AED', bg: '#F0EEFF', trend: 'lenient',
                  body: 'Caremark uses 6-month initial auth vs. Elevance\'s 12 months. Shorter cycles increase renewal touchpoints and documentation of response. Consider piloting 6-month initial PA for CD/UC where clinical evidence supports more frequent reassessment.' },
                { title: 'Adopt Baseline Disease Activity Evaluation', cat: 'Potential UM Lever', color: '#059669', bg: '#EDFFF8', trend: 'stricter',
                  body: 'Caremark uniquely requires a baseline evaluation + treatment goals at initiation — enabling objective benchmarking at renewal. Elevance does not require this. Implementing baseline documentation would strengthen renewal criteria and reduce subjective approvals.' },
                { title: 'Tighten BSA Threshold for Plaque Psoriasis', cat: 'Competitive Opportunity', color: '#B45309', bg: '#FFF8E8', trend: 'stricter',
                  body: 'Elevance allows Ps ≥3% BSA or sensitive areas — the most permissive threshold. Excellus and UHC require ≥10% BSA. Aligning to a higher BSA threshold could reduce low-acuity utilization while remaining clinically defensible for sensitive-area cases.' },
                { title: 'Implement Adherence Verification at Renewal', cat: 'Potential UM Lever', color: '#0891B2', bg: '#E0F6FF', trend: 'stricter',
                  body: 'Only Caremark requires ≥85% adherence verification + provider attestation at continuation. No other competitor — including Elevance — uses this lever. Adding a pharmacy fill-rate check at reauthorization could identify non-compliant members and reduce waste.' },
                { title: 'Step Therapy Consistency for Ps', cat: 'Market Trend', color: '#DC2626', bg: '#FFF2F2', trend: 'stricter',
                  body: 'Caremark requires TWO systemic therapies or phototherapy x3 months for Ps — the strictest in market. Elevance requires one. Monitor whether this becomes the new market standard and evaluate if a dual step-therapy requirement reduces biologic leakage for lower-acuity Ps.' },
              ].map((r, i) => (
                <div key={i} className="rounded-xl p-3.5 border" style={{ borderLeftWidth: 3, borderLeftColor: r.color, borderColor: `${r.color}25`, backgroundColor: r.bg }}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full text-white" style={{ backgroundColor: r.color }}>{r.cat}</span>
                    {r.trend === 'stricter' && <TrendingUp size={10} style={{ color: r.color }}/>}
                    {r.trend === 'lenient'  && <TrendingDown size={10} style={{ color: r.color }}/>}
                  </div>
                  <p className="text-xs font-bold mb-1" style={{ color: r.color }}>{r.title}</p>
                  <p className="text-[11px] text-gray-600 leading-relaxed">{r.body}</p>
                </div>
              ))}
            </div>
            <p className="text-[10px] text-gray-400 mt-3 italic flex items-center gap-1">
              <AlertTriangle size={10} className="text-amber-400"/> AI-generated insights based on competitor data. Validate with clinical and compliance teams before policy changes.
            </p>
          </div>
        </div>
      )}



    </div>
  );
}
