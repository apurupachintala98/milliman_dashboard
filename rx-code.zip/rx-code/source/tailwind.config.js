/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Open Sans"', 'sans-serif'],
      },
      colors: {
        brand: {
          navy: '#1A3673',
          blue: '#44B8F3',
          dark: '#231E33',
          white: '#FFFFFF',
          mid: '#2861BB',
          midLight: '#6A97DF',
          light: '#E1EDFF',
          iceBlue: '#E3F4FD',
          skyLight: '#8FD4F8',
          skyPale: '#C7EAFB',
          teal: '#00BBBA',
          tealLight: '#66D6D6',
          tealPale: '#B2EBEA',
          salmon: '#F7D5CF',
          mint: '#D9F5F5',
          peach: '#FBEAE7',
          coral: '#E3725F',
          coralLight: '#EEAA9F',
        },
      },
    },
  },
  plugins: [],
}

