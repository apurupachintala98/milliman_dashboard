import React, { useState } from 'react'
import { Search } from 'lucide-react'
import Header from '../components/Header'

export default function ReferencePage() {
  const [searchQuery, setSearchQuery] = useState('')

  const referenceCards = [
    {
      id: 1,
      title: 'Platform Architecture',
      description: 'Overview of the AI platform\'s technical architecture, components, and system design principles.'
    },
    {
      id: 2,
      title: 'Getting Started Guide',
      description: 'Step-by-step guide to begin developing applications with the EHAP platform and accessing developer resources.'
    },
    {
      id: 3,
      title: 'Frequently Asked Questions',
      description: 'Common questions and answers about the EHAP platform, development process, and troubleshooting.'
    },
    {
      id: 4,
      title: 'Estimating Cost',
      description: 'Tools and methods for estimating the costs associated with using the EHAP platform and services.'
    },
    {
      id: 5,
      title: 'Tokens',
      description: 'Overview of how token-based usage works across the AI platform\'s endpoints and workflows.'
    },
    {
      id: 6,
      title: 'Rate Limits & Prod Credentials',
      description: 'Overview of the AI platform\'s rate limiting strategies and production credentials.'
    }
  ]

  return (
    <div style={{ minHeight: '100vh', background: '#F5F5F5', fontFamily: '"Open Sans"' }}>
      <Header />

      {/* Main Content */}
      <main style={{ padding: '40px 32px' }}>
        <div style={{ display: 'flex',
width: '1264px',
height: '717px',
flexDirection: 'column',
alignItems: 'flex-start',
gap: '48px' }}>
  <div style={{height: '199px',
flexShrink: 0,
alignSelf: 'stretch'}}>
          {/* Title Section */}
          <div style={{ textAlign: 'center', marginBottom: '48px' }}>
            <h1 style={{
              fontSize: '48px',
              fontWeight: '700',
              color: '#1A1A1A',
              lineHeight: '56px',
              margin: '0 0 16px 0'
            }}>
              References
            </h1>
            <p style={{
              fontSize: '16px',
              fontWeight: '400',
              color: '#5B6770',
              lineHeight: '24px',
              maxWidth: '600px',
              margin: '0 auto'
            }}>
              Explore a variety of resources to help you develop and integrate with the Elevance Health AI Platform.
            </p>
          </div>

          {/* Search Bar */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: '48px'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              width: '100%',
              maxWidth: '500px',
              background: '#FFF',
              borderRadius: '8px',
              padding: '12px 16px',
              border: '1px solid #E2E8F0',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.06)'
            }}>
              <input
                type="text"
                placeholder="Search references..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  border: 'none',
                  outline: 'none',
                  fontSize: '14px',
                  fontFamily: '"Open Sans"',
                  color: '#5B6770'
                }}
              />
              <Search size={20} color="#94A3B8" style={{ marginLeft: '8px' }} />
            </div>
          </div>
</div>
<div style={{height: '406px',
flexShrink: 0,
alignSelf: 'stretch'}}>
          {/* Overview Section */}
          <div style={{ marginBottom: '32px' }}>
            <h2 style={{
              fontSize: '18px',
              fontWeight: '600',
              color: '#1A1A1A',
              lineHeight: '27px',
              margin: '0 0 16px 0'
            }}>
              Overview
            </h2>
            <p style={{
              fontSize: '14px',
              fontWeight: '400',
              color: '#5B6770',
              lineHeight: '20px',
              margin: 0
            }}>
              Get a high-level understanding of the Elevance Health AI Platform and its capabilities.
            </p>
          </div>

          {/* Reference Cards Grid */}
          <div style={{
            display: 'inline-grid',
            rowGap: '24px',
            columnGap: '24px',
            gridTemplateRows: 'repeat(2, fit-content(100%))',
            gridTemplateColumns: 'repeat(3, fit-content(100%))'
          }}>
            {referenceCards.map((card) => (
              <div
                key={card.id}
                style={{
                  width: '340px',
                  padding: '24px',
                  borderRadius: '8px',
                  background: '#FFF',
                  boxShadow: '0 13px 19px -13px rgba(17, 17, 17, 0.30)',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.15)'
                  e.currentTarget.style.transform = 'translateY(-2px)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = '0 13px 19px -13px rgba(17, 17, 17, 0.30)'
                  e.currentTarget.style.transform = 'translateY(0)'
                }}
              >
                {/* Card Title */}
                <h3 style={{
                  fontSize: '16px',
                  fontWeight: '600',
                  color: '#1A1A1A',
                  lineHeight: '24px',
                  margin: 0
                }}>
                  {card.title}
                </h3>

                {/* Card Description */}
                <p style={{
                  fontSize: '14px',
                  fontWeight: '400',
                  color: '#5B6770',
                  lineHeight: '20px',
                  margin: 0
                }}>
                  {card.description}
                </p>
              </div>
            ))}
          </div>
          </div>
        </div>
      </main>
    </div>
  )
}
