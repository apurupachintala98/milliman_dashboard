// import React from 'react'
// import { useState } from 'react'
// import { Eye, EyeOff } from 'lucide-react'
// import { useNavigate } from 'react-router-dom'

// export default function LoginPage() {
//   const [showPassword, setShowPassword] = useState(false)
//   const navigate = useNavigate()

//   const handleLogin = (e) => {
//     e.preventDefault()
//     navigate('/dashboard')
//   }

//   return (
//     <div className="flex h-screen font-source-sans">
//       {/* Left Side - Blue Section */}
//       <div style={{
//         display: 'flex',
//         width: '512px',
//         padding: '64px',
//         flexDirection: 'column',
//         justifyContent: 'space-between',
//         alignItems: 'flex-start',
//         background: '#0079C2',
//         color: 'white',
//         height: '100vh',
//         boxSizing: 'border-box'
//       }}>
//         {/* Top Section: Logo and Content */}
//         <div style={{ width: '100%' }}>
//           {/* Logo and Title */}
//           <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px', marginBottom: '40px' }}>
//             {/* Letter E */}
//             <div style={{
//               width: '48px',
//               height: '48px',
//               borderRadius: '6px',
//               background: 'white',
//               boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.10), 0 2px 4px -2px rgba(0, 0, 0, 0.10)',
//               display: 'flex',
//               alignItems: 'center',
//               justifyContent: 'center',
//               color: '#0079C2',
//               fontWeight: 'bold',
//               fontSize: '28px',
//               flexShrink: 0
//             }}>
//               E
//             </div>

//             {/* Elevance and Health Text */}
//             <div>
//               {/* Elevance */}
//               <div style={{
//                 color: '#FFF',
//                 fontFamily: '"Source Sans 3"',
//                 fontSize: '30px',
//                 fontWeight: '700',
//                 lineHeight: '30px',
//                 letterSpacing: '-0.75px',
//                 margin: '0 0 2px 0'
//               }}>
//                 Elevance
//               </div>
//               {/* Health */}
//               <div style={{
//                 color: '#FFF',
//                 fontFamily: '"Source Sans 3"',
//                 fontSize: '24px',
//                 fontWeight: '300',
//                 lineHeight: '30px',
//                 letterSpacing: '0.6px',
//                 margin: 0
//               }}>
//                 Health
//               </div>
//             </div>
//           </div>

//           {/* Enterprise Portal and Agent Studio Container */}
//           <div style={{
//             display: 'flex',
//             flexDirection: 'column',
//             alignItems: 'flex-start',
//             gap: '24px',
//             alignSelf: 'stretch'
//           }}>
//             {/* Enterprise Portal Badge */}
//             <div style={{
//               display: 'flex',
//               padding: '4px 12px',
//               alignItems: 'center',
//               borderRadius: '2px',
//               border: '1px solid rgba(255, 255, 255, 0.20)',
//               background: 'rgba(255, 255, 255, 0.10)'
//             }}>
//               <span style={{
//                 color: 'rgba(255, 255, 255, 0.90)',
//                 fontFamily: '"Source Sans 3"',
//                 fontSize: '12px',
//                 fontWeight: '600',
//                 lineHeight: '16px',
//                 letterSpacing: '1.2px',
//                 textTransform: 'uppercase',
//                 margin: 0
//               }}>
//                 ENTERPRISE PORTAL
//               </span>
//             </div>

//             {/* Agent Studio Title */}
//             <h2 style={{
//               color: '#FFF',
//               fontFamily: '"Source Sans 3"',
//               fontSize: '48px',
//               fontWeight: '700',
//               lineHeight: '60px',
//               margin: 0
//             }}>
//               Agent Studio
//             </h2>

//             {/* Description */}
//             <p style={{
//               color: 'rgba(255, 255, 255, 0.80)',
//               fontFamily: '"Source Sans 3"',
//               fontSize: '20px',
//               fontWeight: '400',
//               lineHeight: '32.5px',
//               margin: 0,
//               maxWidth: '320px'
//             }}>
//               The enterprise-grade no-code and low-code agent builder for professional agent registration and secure management.
//             </p>
//             <div style={{display: 'flex',
// paddingTop: '40px',
// flexDirection: 'column',
// alignItems: 'flex-start',
// alignSelf: 'stretch'}}>
//     <div style={{
//             display: 'flex',
//             alignItems: 'center',
//             gap: '12px',
//             marginBottom: '32px'
//           }}>
//             {/* 1st Line */}
//             <div style={{
//               width: '48px',
//               height: '6px',
//               borderRadius: '9999px',
//               background: '#00AEEF'
//             }}></div>
//             {/* 2nd Line */}
//             <div style={{
//               width: '16px',
//               height: '6px',
//               borderRadius: '9999px',
//               background: 'rgba(255, 255, 255, 0.20)'
//             }}></div>
//             {/* 3rd Line */}
//             <div style={{
//               width: '16px',
//               height: '6px',
//               borderRadius: '9999px',
//               background: 'rgba(255, 255, 255, 0.20)'
//             }}></div>
//           </div>

// </div>
//           </div>
//         </div>

//         {/* Bottom Section: Decorative Lines and Copyright */}
//         <div style={{ width: '100%' }}>
//           {/* Decorative Lines Container */}


//           {/* Copyright Section */}
//           <div style={{
//             color: 'rgba(255, 255, 255, 0.50)',
//             fontFamily: '"Source Sans 3"',
//             fontSize: '14px',
//             fontWeight: '300',
//             lineHeight: '20px'
//           }}>
//             <p style={{ margin: '0 0 4px 0' }}>© 2024 Elevance Health. All rights reserved.</p>
//             <p style={{ margin: 0 }}>Authorized Personnel Only.</p>
//           </div>
//         </div>
//       </div>

//       {/* Right Side - Form Section */}
//       <div style={{ flex: 1, background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '32px' }}>
//         <div style={{ background: 'white', borderRadius: '8px', padding: '48px', width: '100%', maxWidth: '420px', boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)' }}>
//           {/* Form Header */}
//           <h3 className="text-3xl font-bold text-primary-blue text-center mb-2">
//             Welcome Back
//           </h3>
//           <p className="text-center text-gray-700 text-sm mb-8">
//             Please enter your credentials to access<br />Agent Studio.
//           </p>

//           {/* Login Form */}
//           <form onSubmit={handleLogin} className="space-y-6">
//             {/* User ID Field */}
//             <div>
//               <label className="block text-sm font-semibold text-gray-800 mb-2">
//                 User ID
//               </label>
//               <div className="relative">
//                 <span className="absolute left-4 top-4 text-gray-400">
//                   👤
//                 </span>
//                 <input
//                   type="text"
//                   placeholder="Enter your User ID"
//                   className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700"
//                 />
//               </div>
//             </div>

//             {/* Password Field */}
//             <div>
//               <label className="block text-sm font-semibold text-gray-800 mb-2">
//                 Password
//               </label>
//               <div className="relative">
//                 <span className="absolute left-4 top-4 text-gray-400">
//                   🔒
//                 </span>
//                 <input
//                   type={showPassword ? 'text' : 'password'}
//                   placeholder="•••••••"
//                   className="w-full pl-12 pr-12 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700"
//                 />
//                 <button
//                   type="button"
//                   onClick={() => setShowPassword(!showPassword)}
//                   className="absolute right-4 top-3 text-gray-400 hover:text-gray-600"
//                 >
//                   {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
//                 </button>
//               </div>
//             </div>

//             {/* Application Code Field */}
//             <div>
//               <label className="block text-sm font-semibold text-gray-800 mb-2">
//                 Application Code
//               </label>
//               <div className="relative">
//                 <span className="absolute left-4 top-4 text-gray-400">
//                   ☰
//                 </span>
//                 <select className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:border-primary-blue focus:ring-1 focus:ring-primary-blue text-gray-700 appearance-none bg-white">
//                   <option>Select Application Code</option>
//                 </select>
//                 <span className="absolute right-4 top-4 text-gray-400 pointer-events-none">
//                   ▼
//                 </span>
//               </div>
//             </div>

//             {/* Remember & Forgot */}
//             <div className="flex items-center justify-between text-sm">
//               <label className="flex items-center gap-2 cursor-pointer">
//                 <input type="checkbox" className="w-4 h-4 border border-gray-300 rounded" />
//                 <span className="text-gray-700">Remember me</span>
//               </label>
//               <a href="#" className="text-primary-blue hover:underline font-semibold">
//                 Forgot password?
//               </a>
//             </div>

//             {/* Sign In Button */}
//             <button
//               type="submit"
//               className="w-full bg-primary-blue text-white py-3 rounded-md font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2 mt-8"
//             >
//               Sign in
//               <span>→</span>
//             </button>
//           </form>

//           {/* Sign Up Link */}
//           <p className="text-center text-gray-700 text-sm mt-6">
//             New agent? <a href="#" className="text-primary-blue hover:underline font-semibold">Request access</a>
//           </p>
//         </div>
//       </div>
//     </div>
//   )
// }
import React from 'react'
import { useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

export default function LoginPage() {
  // const [showPassword, setShowPassword] = useState(false)
  const navigate = useNavigate()
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [appCode, setAppCode] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const appCodes = ["Agent Studio Pro", "HR Assistant", "Policy Manager", "Benefits Portal"];
  const handleLogin = (e) => {
    e.preventDefault()
    navigate('/dashboard')
  }

  return (
    <div className="flex h-screen font-source-sans">
      {/* Left Side - Blue Section */}
      <div style={{
        display: 'flex',
        width: '512px',
        padding: '64px',
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        background: '#0079C2',
        color: 'white',
        height: '100vh',
        boxSizing: 'border-box'
      }}>
        {/* Logo Section - Stays at Top */}
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px' }}>
          {/* Letter E */}
          <div style={{
            width: '48px',
            height: '48px',
            borderRadius: '6px',
            background: 'white',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.10), 0 2px 4px -2px rgba(0, 0, 0, 0.10)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#0079C2',
            fontWeight: 'bold',
            fontSize: '28px',
            flexShrink: 0
          }}>
            E
          </div>

          {/* Elevance and Health Text */}
          <div>
            {/* Elevance */}
            <div style={{
              color: '#FFF',
              fontFamily: '"Source Sans 3"',
              fontSize: '30px',
              fontWeight: '700',
              lineHeight: '30px',
              letterSpacing: '-0.75px',
              margin: '0 0 2px 0'
            }}>
              Elevance
            </div>
            {/* Health */}
            <div style={{
              color: '#FFF',
              fontFamily: '"Source Sans 3"',
              fontSize: '24px',
              fontWeight: '300',
              lineHeight: '30px',
              letterSpacing: '0.6px',
              margin: 0
            }}>
              Health
            </div>
          </div>
        </div>

        {/* Enterprise Portal and Agent Studio Container - Expands with flex:1 */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          gap: '24px',
          width: '100%',
          flex: 1,
          justifyContent: 'center'
        }}>
          {/* Enterprise Portal Badge */}
          <div style={{
            display: 'flex',
            padding: '4px 12px',
            alignItems: 'center',
            borderRadius: '2px',
            border: '1px solid rgba(255, 255, 255, 0.20)',
            background: 'rgba(255, 255, 255, 0.10)'
          }}>
            <span style={{
              color: 'rgba(255, 255, 255, 0.90)',
              fontFamily: '"Source Sans 3"',
              fontSize: '12px',
              fontWeight: '600',
              lineHeight: '16px',
              letterSpacing: '1.2px',
              textTransform: 'uppercase',
              margin: 0
            }}>
              ENTERPRISE PORTAL
            </span>
          </div>

          {/* Agent Studio Title */}
          <h2 style={{
            color: '#FFF',
            fontFamily: '"Source Sans 3"',
            fontSize: '48px',
            fontWeight: '700',
            lineHeight: '60px',
            margin: 0
          }}>
            Agent Studio
          </h2>

          {/* Description */}
          <p style={{
            color: 'rgba(255, 255, 255, 0.80)',
            fontFamily: '"Source Sans 3"',
            fontSize: '20px',
            fontWeight: '400',
            lineHeight: '32.5px',
            margin: 0,
            maxWidth: '320px'
          }}>
            The enterprise-grade no-code and low-code agent builder for professional agent registration and secure management.
          </p>
          <div style={{
            display: 'flex',
            paddingTop: '40px',
            flexDirection: 'column',
            alignItems: 'flex-start',
            alignSelf: 'stretch'
          }}>
            {/* Decorative Lines Container */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '32px'
            }}>
              {/* 1st Line */}
              <div style={{
                width: '48px',
                height: '6px',
                borderRadius: '9999px',
                background: '#00AEEF'
              }}></div>
              {/* 2nd Line */}
              <div style={{
                width: '16px',
                height: '6px',
                borderRadius: '9999px',
                background: 'rgba(255, 255, 255, 0.20)'
              }}></div>
              {/* 3rd Line */}
              <div style={{
                width: '16px',
                height: '6px',
                borderRadius: '9999px',
                background: 'rgba(255, 255, 255, 0.20)'
              }}></div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Decorative Lines and Copyright */}
        <div style={{ width: '100%' }}>


          {/* Copyright Section */}
          <div style={{
            color: 'rgba(255, 255, 255, 0.50)',
            fontFamily: '"Source Sans 3"',
            fontSize: '14px',
            fontWeight: '300',
            lineHeight: '20px'
          }}>
            <p style={{ margin: '0 0 4px 0' }}>© 2024 Elevance Health. All rights reserved.</p>
            <p style={{ margin: 0 }}>Authorized Personnel Only.</p>
          </div>
        </div>
      </div>

      {/* Right Side - Form Section */}
      <div className='flex w-full items-center justify-center p-6' style={{
        background: '#F8F9FA',
      }}>

        <div
          className="bg-white rounded-2xl shadow-lg py-10 px-10"
          style={{ width: "500px" }}
        >
          {/* Title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-blue-600 mb-3">Welcome Back</h1>
            <p className="text-gray-500 text-sm leading-relaxed">
              Please enter your credentials to access<br />Agent Studio.
            </p>
          </div>

          {/* User ID */}
          <div className="mb-5">
            <label className="block text-sm font-semibold text-gray-700 mb-2">User ID</label>
            <div className="flex items-center border border-gray-300 rounded-xl px-4 py-3 bg-white focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-50 transition-all">
              <svg className="w-4 h-4 text-gray-400 mr-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              <input
                type="text"
                value={userId}
                onChange={e => setUserId(e.target.value)}
                placeholder="Enter your User ID"
                className="flex-1 outline-none text-sm text-gray-700 placeholder-gray-400 bg-transparent"
              />
            </div>
          </div>

          {/* Password */}
          <div className="mb-5">
            <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
            <div className="flex items-center border border-gray-300 rounded-xl px-4 py-3 bg-white focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-50 transition-all">
              <svg className="w-4 h-4 text-gray-400 mr-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="flex-1 outline-none text-sm text-gray-700 placeholder-gray-400 bg-transparent"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-gray-400 hover:text-gray-600 transition-colors ml-2 flex-shrink-0"
              >
                {showPassword ? (
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                ) : (
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                    <line x1="1" y1="1" x2="23" y2="23" />
                  </svg>
                )}
              </button>
            </div>
          </div>

          {/* Application Code */}
          <div className="mb-6 relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">Application Code</label>
            <div
              className="flex items-center border border-gray-300 rounded-xl px-4 py-3 bg-white cursor-pointer hover:border-gray-400 transition-all select-none"
              onClick={() => setDropdownOpen(!dropdownOpen)}
            >
              {/* Grid dots icon */}
              <svg className="w-4 h-4 text-gray-400 mr-3 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
                <circle cx="5" cy="5" r="1.5" /><circle cx="12" cy="5" r="1.5" /><circle cx="19" cy="5" r="1.5" />
                <circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" />
                <circle cx="5" cy="19" r="1.5" /><circle cx="12" cy="19" r="1.5" /><circle cx="19" cy="19" r="1.5" />
              </svg>
              <span className={`flex-1 text-sm ${appCode ? "text-gray-700" : "text-gray-400"}`}>
                {appCode || "Select Application Code"}
              </span>
              <svg
                className={`w-4 h-4 text-gray-400 transition-transform ${dropdownOpen ? "rotate-180" : ""}`}
                viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
              >
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {/* Dropdown */}
            {dropdownOpen && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-10 overflow-hidden">
                {appCodes.map(code => (
                  <div
                    key={code}
                    className={`px-4 py-2.5 text-sm cursor-pointer hover:bg-blue-50 hover:text-blue-600 transition-colors ${appCode === code ? "bg-blue-50 text-blue-600 font-medium" : "text-gray-700"}`}
                    onClick={() => { setAppCode(code); setDropdownOpen(false); }}
                  >
                    {code}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Remember me + Forgot password */}
          <div className="flex items-center justify-between mb-6">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <div
                onClick={() => setRememberMe(!rememberMe)}
                className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${rememberMe ? "bg-blue-500 border-blue-500" : "border-gray-300 bg-white"
                  }`}
              >
                {rememberMe && (
                  <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                )}
              </div>
              <span className="text-sm text-gray-600">Remember me</span>
            </label>
            <button className="text-sm text-blue-500 hover:text-blue-700 font-medium transition-colors">
              Forgot password?
            </button>
          </div>

          {/* Sign In Button */}
          <button className="w-full bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white font-semibold text-base py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-sm">
            Sign In
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="5" y1="12" x2="19" y2="12" />
              <polyline points="12 5 19 12 12 19" />
            </svg>
          </button>

          {/* Request access */}
          <p className="text-center text-sm text-gray-500 mt-6">
            New agent?{" "}
            <button className="text-blue-500 hover:text-blue-700 font-medium transition-colors">
              Request access
            </button>
          </p>
        </div>
      </div>
    </div >
  )
}
