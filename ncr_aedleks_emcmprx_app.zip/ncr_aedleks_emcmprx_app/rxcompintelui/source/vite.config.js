import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const allowedHosts = [
  'rxcompintel.dev.elevancehealth.com',
  'rxcompintel.preprod.elevancehealth.com',
  'rxcompintel.elevancehealth.com',
]

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    strictPort: true,
    allowedHosts,
  },
  preview: {
    host: true,
    port: 5173,
    strictPort: true,
    allowedHosts,
  },
})
