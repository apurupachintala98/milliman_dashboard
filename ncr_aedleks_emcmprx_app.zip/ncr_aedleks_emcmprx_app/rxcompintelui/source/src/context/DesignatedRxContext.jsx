import { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import { fetchJobRuns, fetchSnapshot, defaultResultType } from '../services/designatedRx';
const DesignatedRxContext = createContext(null);

export function DesignatedRxProvider({ children }) {
  const [jobRuns, setJobRuns]               = useState([]);
  const [jobRunsStatus, setJobRunsStatus]   = useState('idle'); // idle | loading | ready | error
  const [jobRunsError, setJobRunsError]     = useState(null);
  const [selectedJobRunId, setSelectedJobRunId] = useState(null);
  const [selectedRunKey, setSelectedRunKey]     = useState(null);
  const [selectedResultType, setSelectedResultType] = useState(null); // scheduled runs: one of availableFiles; adhoc: null
  const [snapshot, setSnapshot]             = useState(null);   // { drugs, compKeys, jobRunId }
  const [snapshotKey, setSnapshotKey]       = useState(null);   // selectionKey the current `snapshot` belongs to
  const [snapshotStatus, setSnapshotStatus] = useState('idle');
  const [snapshotError, setSnapshotError]   = useState(null);

  const cacheRef = useRef(new Map());       // selectionKey → model
  const jobRunsRequested = useRef(false);
  // Latest selection/job runs, readable from async callbacks without stale closures
  const latestRef = useRef({});
  latestRef.current = { jobRuns, selectedJobRunId, selectedRunKey, selectedResultType };

  const loadJobRuns = useCallback(async ({ force = false } = {}) => {
    if (jobRunsRequested.current && !force) return;
    jobRunsRequested.current = true;
    setJobRunsStatus('loading');
    setJobRunsError(null);
    try {
      const runs = await fetchJobRuns();
      setJobRuns(runs);
      setJobRunsStatus('ready');
      // Default to the run flagged current: true (fallback: newest)
      const defaultRun = runs.find(r => r.current) || runs[0];
      const prev = latestRef.current;
      const keepId = prev.selectedJobRunId && runs.some(r => r.jobRunId === prev.selectedJobRunId);
      const keptRun = prev.selectedRunKey ? runs.find(r => r.key === prev.selectedRunKey) : null;
      const run = keptRun || defaultRun;
      setSelectedJobRunId(keepId ? prev.selectedJobRunId : defaultRun?.jobRunId ?? null);
      setSelectedRunKey(run?.key ?? null);
      // Keep the chosen result type while the run still offers it, otherwise fall back to the run's default
      setSelectedResultType(keptRun && keptRun.availableFiles.includes(prev.selectedResultType)
        ? prev.selectedResultType : defaultResultType(run));
    } catch (e) {
      jobRunsRequested.current = false;
      setJobRunsError(e);
      setJobRunsStatus('error');
    }
  }, []);

  const [reloadTick, setReloadTick] = useState(0);
  const silentReloadRef = useRef(false);
  // silent: refresh in the background — the page keeps showing the current data
  // (no full-page loading state) and swaps it in when the new response arrives.
  // run (job_run_id|run_type) + result_type — identifies one loaded snapshot file
  const selectionKey = selectedRunKey ? `${selectedRunKey}|${selectedResultType ?? ''}` : null;

  const reloadSnapshot = useCallback(({ silent = false } = {}) => {
    if (selectionKey) cacheRef.current.delete(selectionKey);
    silentReloadRef.current = silent;
    setReloadTick(t => t + 1);
  }, [selectionKey]);

  // Fetch data whenever the selected snapshot (or its result type) changes
  useEffect(() => {
    if (!selectedJobRunId || !selectionKey) return;
    const cached = cacheRef.current.get(selectionKey);
    if (cached) {
      setSnapshot(cached);
      setSnapshotKey(selectionKey);
      setSnapshotStatus('ready');
      setSnapshotError(null);
      return;
    }
    const controller = new AbortController();
    const silent = silentReloadRef.current;
    silentReloadRef.current = false;
    if (!silent) {
      setSnapshotStatus('loading');
      setSnapshotError(null);
    }
    const run = jobRuns.find(r => r.key === selectedRunKey);
    // A just-uploaded adhoc run may not be in jobRuns yet — its key (`id|adhoc`) still carries the run type
    const runType = run?.runType ?? selectedRunKey.slice(selectedRunKey.lastIndexOf('|') + 1);
    fetchSnapshot(selectedJobRunId, {
      runType,
      resultType: selectedResultType,
      availableFiles: run?.availableFiles,
      label: run?.label,
      signal: controller.signal,
    })
      .then(model => {
        cacheRef.current.set(selectionKey, model);
        setSnapshot(model);
        setSnapshotKey(selectionKey);
        setSnapshotStatus('ready');
      })
      .catch(e => {
        if (e.name === 'AbortError') return; // user picked another snapshot
        if (silent) {
          // Background refresh failed — keep showing the data we already have
          console.warn('Background snapshot refresh failed:', e);
          return;
        }
        setSnapshotError(e);
        setSnapshotStatus('error');
      });
    return () => controller.abort();
  }, [selectedJobRunId, selectionKey, reloadTick]);

  // resultType: one of the run's availableFiles; omitted → the run's default ('all' when offered)
  const selectJobRun = useCallback((jobRunId, key = null, resultType) => {
    const runs = latestRef.current.jobRuns;
    const run = runs.find(r => r.key === key) || runs.find(r => r.jobRunId === jobRunId);
    setSelectedJobRunId(jobRunId);
    setSelectedRunKey(key);
    setSelectedResultType(resultType !== undefined ? resultType : defaultResultType(run));
  }, []);

  const selectedRun = jobRuns.find(r => r.key === selectedRunKey && r.jobRunId === selectedJobRunId)
  || jobRuns.find(r => r.jobRunId === selectedJobRunId) || null;
const isCurrent = !!selectedRun?.current;

  return (
    <DesignatedRxContext.Provider value={{
      jobRuns, jobRunsStatus, jobRunsError, loadJobRuns,
      selectedJobRunId, selectedRun, isCurrent, selectJobRun,
      selectedResultType, selectionKey,
      snapshot, snapshotKey, snapshotStatus, snapshotError, reloadSnapshot,
    }}>
      {children}
    </DesignatedRxContext.Provider>
  );
}

export function useDesignatedRx() {
  const ctx = useContext(DesignatedRxContext);
  if (!ctx) throw new Error('useDesignatedRx must be used inside DesignatedRxProvider');
  return ctx;
}