import { createContext, useContext, useState, useCallback, useRef } from 'react';

const AppContext = createContext(null);

export const STATUS_TRANSITIONS = {
  'Open':        ['In-Progress', 'Cancelled', 'Deferred'],
  'In-Progress': ['Review', 'Cancelled', 'Deferred'],
  'Review':      ['Approved', 'In-Progress', 'Cancelled', 'Deferred'],
  'Approved':    [],
  'Cancelled':   [],
  'Deferred':    ['Open'],
};

export const CI_TYPES = ['Clinical Criteria', 'Designated Network', 'Preventive Rx'];
export const MARKETS = [
  'National',
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
  'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho',
  'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
  'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
  'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada',
  'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
  'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon',
  'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
  'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington',
  'Washington D.C.', 'West Virginia', 'Wisconsin', 'Wyoming',
];
export const COMPETITORS_BY_TYPE = {
  'Clinical Criteria': ['United Healthcare', 'Cigna', 'Aetna', 'Caremark'],
  'Designated Network': ['United Healthcare'],
  'Preventive Rx': ['CVS', 'Optum', 'UnitedHealthcare', 'Humana', 'ESI', 'Blue Shield CA', 'Kaiser Permanente'],
};

// RBAC
// Actions: view · export · create · edit · generate · upload · approve · admin
export const PERMISSIONS = {
  'super-user': ['view', 'export', 'create', 'edit', 'generate', 'upload', 'approve', 'admin'],
  'user':       ['view', 'export'],
  // legacy roles (used only when the login response has no user_roles)
  'read-only': ['view', 'export'],
  'editor':    ['view', 'export', 'create', 'edit', 'generate', 'upload', 'approve'],
  'admin':     ['view', 'export', 'create', 'edit', 'generate', 'upload', 'approve', 'admin'],
};
export const ROLE_LABELS = { 'super-user': 'Super User', user: 'User', 'read-only': 'Read Only', editor: 'Editor', admin: 'Admin' };
export const NO_PERMISSION_MSG = "You don't have permission for this action. Contact your administrator for access.";

// Login `user_roles` → app role (super-user | user | null = no access) lives in services/access.js

export function can(user, action) {
  return PERMISSIONS[user?.role]?.includes(action) ?? false;
}

/** Reusable permission check for components: `const can = useCan(); can('edit')`. */
export function useCan() {
  const { currentUser } = useContext(AppContext) || {};
  return useCallback(action => can(currentUser, action), [currentUser]);
}

const INITIAL_PROJECTS = [
  {
    id: 'PRJ-001',
    name: 'Humira - UM Clinical Criteria Q3 2026',
    lob: 'Commercial',
    market: 'National',
    createdBy: 'Tracy Thompson',
    updatedBy: 'Tracy Thompson',
    createdDate: '2026-06-15',
    updatedDate: '2026-07-01',
    ciType: 'Clinical Criteria',
    status: 'Review',
    comments: 'AI analysis complete — ready for analyst review.',
    drugs: ['Humira (adalimumab)', 'Dupixent (dupilumab)'],
    indication: 'Rheumatoid Arthritis',
    competitors: ['United Healthcare', 'Cigna', 'Aetna', 'Caremark'],
    analysisGrid: null,
    auditTrail: [
      { user: 'Tracy Thompson', time: '2026-06-15 09:00', change: 'Project created' },
      { user: 'Tracy Thompson', time: '2026-06-15 09:05', change: 'Status changed to In-Progress' },
      { user: 'System (AI)', time: '2026-07-01 14:30', change: 'Intelligence generated from iDiscovery. Status changed to Review.' },
    ],
  },
  {
    id: 'PRJ-002',
    name: 'Designated Network - Specialty Drugs 2026',
    lob: 'Commercial',
    market: 'Midwest',
    createdBy: 'Alana Coleman',
    updatedBy: 'Alana Coleman',
    createdDate: '2026-07-10',
    updatedDate: '2026-07-10',
    ciType: 'Designated Network',
    status: 'Open',
    comments: '',
    drugs: [],
    indication: '',
    competitors: ['United Healthcare'],
    analysisGrid: null,
    auditTrail: [{ user: 'Alana Coleman', time: '2026-07-10 10:00', change: 'Project created' }],
  },
  {
    id: 'PRJ-003',
    name: 'Preventive Rx ACA Comparison 2026',
    lob: 'Commercial',
    market: 'National',
    createdBy: 'Sara Colburn',
    updatedBy: 'Sara Colburn',
    createdDate: '2026-07-20',
    updatedDate: '2026-07-25',
    ciType: 'Preventive Rx',
    status: 'Approved',
    comments: 'Approved by stakeholders',
    drugs: ['Aspirin', 'Statins', 'Folic Acid'],
    indication: '',
    competitors: ['CVS', 'Optum', 'UnitedHealthcare', 'Humana'],
    analysisGrid: null,
    auditTrail: [
      { user: 'Sara Colburn', time: '2026-07-20 08:00', change: 'Project created' },
      { user: 'Sara Colburn', time: '2026-07-25 16:00', change: 'Project approved. Status changed to Approved.' },
    ],
  },
  {
    id: 'PRJ-004',
    name: 'Keytruda - UM Criteria Oncology 2026',
    lob: 'Commercial',
    market: 'National',
    createdBy: 'Tracy Thompson',
    updatedBy: 'Tracy Thompson',
    createdDate: '2026-08-01',
    updatedDate: '2026-08-01',
    ciType: 'Clinical Criteria',
    status: 'In-Progress',
    comments: 'Sourcing competitor documents from iDiscovery.',
    drugs: ['Keytruda (pembrolizumab)'],
    indication: 'Non-Small Cell Lung Cancer',
    competitors: ['United Healthcare', 'Cigna', 'Aetna', 'Caremark'],
    analysisGrid: null,
    auditTrail: [
      { user: 'Tracy Thompson', time: '2026-08-01 09:00', change: 'Project created' },
      { user: 'Tracy Thompson', time: '2026-08-01 09:02', change: 'Status changed to In-Progress' },
    ],
  },
];

export function AppProvider({ children, currentUser }) {
  const [projects, setProjects] = useState(INITIAL_PROJECTS);
  const [toasts, setToasts] = useState([]);

  const toastSeq = useRef(0);
  // options.position: 'bottom' (default, bottom-right) | 'top' (top-center)
  // options.key: toasts with the same key are shown once while visible (default: type + message)
  const addToast = useCallback((message, type = 'success', { position = 'bottom', duration = 4000, key = `${type}|${message}` } = {}) => {
    const id = `${Date.now()}-${toastSeq.current++}`;
    setToasts(t => (t.some(x => x.key === key) ? t : [...t, { id, key, message, type, position }]));
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), duration);
  }, []);

  const dismissToast = useCallback((id) => {
    setToasts(t => t.filter(x => x.id !== id));
  }, []);

  function addProject(project) {
    const newProject = {
      ...project,
      id: `PRJ-${String(projects.length + 1).padStart(3, '0')}`,
      createdBy: currentUser?.name || 'Unknown',
      updatedBy: currentUser?.name || 'Unknown',
      createdDate: new Date().toISOString().slice(0, 10),
      updatedDate: new Date().toISOString().slice(0, 10),
      status: 'Open',
      drugs: project.drugs || [],
      indication: project.indication || '',
      competitors: project.competitors || COMPETITORS_BY_TYPE[project.ciType] || [],
      analysisGrid: null,
      auditTrail: [{ user: currentUser?.name || 'Unknown', time: new Date().toLocaleString(), change: 'Project created' }],
    };
    setProjects(prev => [...prev, newProject]);
    return newProject.id;
  }

  function updateProject(id, updates) {
    setProjects(prev =>
      prev.map(p => {
        if (p.id !== id) return p;
        const auditEntry = {
          user: currentUser?.name || 'Unknown',
          time: new Date().toLocaleString(),
          change: updates._auditNote || `Fields updated: ${Object.keys(updates).filter(k => k !== '_auditNote').join(', ')}`,
        };
        const { _auditNote, ...cleanUpdates } = updates;
        return {
          ...p,
          ...cleanUpdates,
          updatedBy: currentUser?.name || 'Unknown',
          updatedDate: new Date().toISOString().slice(0, 10),
          auditTrail: [...p.auditTrail, auditEntry],
        };
      })
    );
  }

  return (
    <AppContext.Provider value={{ projects, currentUser, addProject, updateProject, toasts, addToast, dismissToast }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}