import { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import { fetchPrxJobRuns, fetchPrxSnapshot } from '../services/preventiveRx';
import { formatSnapshotDate } from '../services/designatedRx';

/** Preventive Rx runs (ad-hoc only) + the selected run's page data — shared by the sidebar and the page. */
const PreventiveRxContext = createContext(null);

const LAST_RUN_KEY = 'rxci_prx_run';

/** List entry for a run id (YYYY-MM-DD) that /job-runs didn't return. */
function runEntry(jobRunId) {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(jobRunId) ? new Date(`${jobRunId}T00:00:00`) : null;
  return { jobRunId, key: `${jobRunId}|adhoc`, runType: 'adhoc', date: d, label: d ? formatSnapshotDate(d) : jobRunId, current: false, availableFiles: [] };
}

export function PreventiveRxProvider({ children }) {
  const [jobRuns, setJobRuns]             = useState([]);
  const [jobRunsStatus, setJobRunsStatus] = useState('idle'); // idle | loading | ready | error
  const [jobRunsError, setJobRunsError]   = useState(null);
  const [selectedJobRunId, setSelectedJobRunId] = useState(null);
  const [snapshot, setSnapshot]             = useState(null);
  const [snapshotKey, setSnapshotKey]       = useState(null);   // jobRunId the current `snapshot` belongs to
  const [snapshotStatus, setSnapshotStatus] = useState('idle');
  const [snapshotError, setSnapshotError]   = useState(null);
  const [reloadTick, setReloadTick] = useState(0);

  const cacheRef = useRef(new Map());   // jobRunId → model
  const jobRunsRequested = useRef(false);
  const silentReloadRef = useRef(false);
  // Latest runs / selection for async callbacks (updated after each render, before the effects below)
  const latestRef = useRef({});
  useEffect(() => { latestRef.current = { jobRuns, selectedJobRunId }; });

  const loadJobRuns = useCallback(async ({ force = false } = {}) => {
    if (jobRunsRequested.current && !force) return;
    jobRunsRequested.current = true;
    setJobRunsStatus('loading');
    setJobRunsError(null);
    try {
      const runs = await fetchPrxJobRuns();
      setJobRuns(runs);
      setJobRunsStatus('ready');
      // Keep the selected run (even if /job-runs doesn't list it, e.g. a just-uploaded run),
      // else the run flagged current (fallback: newest), else the last run opened in this session
      const prev = latestRef.current.selectedJobRunId;
      const next = prev || (runs.find(r => r.current) || runs[0])?.jobRunId || sessionStorage.getItem(LAST_RUN_KEY) || null;
      console.log('[prx] ctx job runs loaded:', runs.length, '| previous selection:', prev, '→ selected:', next); // DEBUG [prx]
      setSelectedJobRunId(next);
    } catch (e) {
      console.error('[prx] ctx job runs failed:', e); // DEBUG [prx]
      jobRunsRequested.current = false;
      setJobRunsError(e);
      setJobRunsStatus('error');
    }
  }, []);

  // silent: refresh in the background — the page keeps showing the current data until the new response arrives
  const reloadSnapshot = useCallback(({ silent = false } = {}) => {
    const id = latestRef.current.selectedJobRunId;
    if (id) cacheRef.current.delete(id);
    silentReloadRef.current = silent;
    setReloadTick(t => t + 1);
  }, []);

  useEffect(() => {
    if (!selectedJobRunId) { console.log('[prx] ctx snapshot: no run selected'); return undefined; } // DEBUG [prx]
    const cached = cacheRef.current.get(selectedJobRunId);
    console.log('[prx] ctx snapshot effect:', { selectedJobRunId, reloadTick, cached: !!cached, silent: silentReloadRef.current }); // DEBUG [prx]
    if (cached) {
      setSnapshot(cached);
      setSnapshotKey(selectedJobRunId);
      setSnapshotStatus('ready');
      setSnapshotError(null);
      return undefined;
    }
    const controller = new AbortController();
    const silent = silentReloadRef.current;
    silentReloadRef.current = false;
    if (!silent) {
      setSnapshotStatus('loading');
      setSnapshotError(null);
    }
    const label = latestRef.current.jobRuns.find(r => r.jobRunId === selectedJobRunId)?.label;
    fetchPrxSnapshot(selectedJobRunId, { label, signal: controller.signal })
      .then(model => {
        // Only cache finished results — a run fetched while Queued / Inprogress has no drug_data yet
        if (model.drugs.length) cacheRef.current.set(selectedJobRunId, model);
        console.log('[prx] ctx snapshot ready:', selectedJobRunId, '| drugs:', model.drugs.length, '| silent:', silent); // DEBUG [prx]
        setSnapshot(model);
        setSnapshotKey(selectedJobRunId);
        setSnapshotStatus('ready');
      })
      .catch(e => {
        if (e.name === 'AbortError') { console.log('[prx] ctx snapshot request aborted (superseded):', selectedJobRunId); return; } // DEBUG [prx]
        console.error('[prx] ctx snapshot failed:', selectedJobRunId, '| silent:', silent, e); // DEBUG [prx]
        // A background refresh that fails must not leave the page stuck on "Loading…"
        if (silent) { setSnapshotStatus(s => (s === 'loading' ? 'error' : s)); setSnapshotError(e); return; }
        setSnapshotError(e);
        setSnapshotStatus('error');
      });
    return () => controller.abort();
  }, [selectedJobRunId, reloadTick]);

  const selectJobRun = useCallback((jobRunId) => setSelectedJobRunId(jobRunId), []);
  // Remember the open run so a page reload reopens it even when /job-runs doesn't list it
  useEffect(() => { if (selectedJobRunId) sessionStorage.setItem(LAST_RUN_KEY, selectedJobRunId); }, [selectedJobRunId]);

  // The selected run is always part of the list (sidebar + page), even when /job-runs doesn't return it
  const listedRuns = selectedJobRunId && !jobRuns.some(r => r.jobRunId === selectedJobRunId)
    ? [runEntry(selectedJobRunId), ...jobRuns]
    : jobRuns;
  const selectedRun = listedRuns.find(r => r.jobRunId === selectedJobRunId) || null;

  return (
    <PreventiveRxContext.Provider value={{
      jobRuns: listedRuns, jobRunsStatus, jobRunsError, loadJobRuns,
      selectedJobRunId, selectedRun, selectJobRun,
      snapshot, snapshotKey, snapshotStatus, snapshotError, reloadSnapshot,
    }}>
      {children}
    </PreventiveRxContext.Provider>
  );
}

export function usePreventiveRx() {
  const ctx = useContext(PreventiveRxContext);
  if (!ctx) throw new Error('usePreventiveRx must be used inside PreventiveRxProvider');
  return ctx;
}
