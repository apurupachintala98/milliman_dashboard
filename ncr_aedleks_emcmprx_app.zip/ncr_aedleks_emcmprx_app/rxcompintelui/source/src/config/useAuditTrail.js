import { useState, useEffect, useCallback } from 'react';

function storageKey(pageId) {
  return `audit_trail_${pageId}`;
}

function ago(minutes) {
  return new Date(Date.now() - minutes * 60000).toISOString();
}

const MOCK_ENTRIES = {
  'designated-network': [
    { id: 1, timestamp: ago(5),   action: 'approve',  details: 'Report approved — Designated Network',                         user: 'Alana Coleman' },
    { id: 2, timestamp: ago(12),  action: 'filter',   details: 'Switched coverage comparison to: Cigna',                        user: 'Alana Coleman' },
    { id: 3, timestamp: ago(18),  action: 'filter',   details: 'Switched coverage comparison to: UHC',                          user: 'Sara Colburn'  },
    { id: 4, timestamp: ago(35),  action: 'generate', details: 'Generated Designated Network competitive intelligence report',   user: 'Alana Coleman' },
    { id: 5, timestamp: ago(62),  action: 'upload',   details: 'Uploaded file: DN_Competitor_List_July2026.xlsx',               user: 'Tracy Thompson'},
    { id: 6, timestamp: ago(90),  action: 'filter',   details: 'Switched coverage comparison to: Aetna',                        user: 'Sara Colburn'  },
    { id: 7, timestamp: ago(130), action: 'generate', details: 'Generated Designated Network competitive intelligence report',   user: 'Tracy Thompson'},
    { id: 8, timestamp: ago(200), action: 'status',   details: 'Approval revoked — moved back to In Review',                   user: 'Alana Coleman' },
    { id: 9, timestamp: ago(260), action: 'approve',  details: 'Report approved — Designated Network',                         user: 'Tracy Thompson'},
  ],
  'preventive-rx': [
    { id: 1, timestamp: ago(8),   action: 'approve',  details: 'Report approved — Preventive Rx',                              user: 'Alana Coleman' },
    { id: 2, timestamp: ago(22),  action: 'edit',     details: 'Edited cell: Aspirin · Cigna → Covered (OTC formulary confirmed)', user: 'Alana Coleman' },
    { id: 3, timestamp: ago(31),  action: 'edit',     details: 'Edited cell: Atorvastatin · Aetna → Not Covered (pending review)', user: 'Sara Colburn'  },
    { id: 4, timestamp: ago(45),  action: 'generate', details: 'Generated Preventive Rx competitive intelligence report',        user: 'Alana Coleman' },
    { id: 5, timestamp: ago(78),  action: 'upload',   details: 'Uploaded file: PreventiveRx_Q3_2026.xlsx',                     user: 'Tracy Thompson'},
    { id: 6, timestamp: ago(110), action: 'edit',     details: 'Edited cell: Metformin · CVS/Caremark → Covered (confirmed)',   user: 'Sara Colburn'  },
    { id: 7, timestamp: ago(155), action: 'status',   details: 'Approval revoked — moved back to In Review',                   user: 'Alana Coleman' },
    { id: 8, timestamp: ago(190), action: 'generate', details: 'Generated Preventive Rx competitive intelligence report',        user: 'Tracy Thompson'},
    { id: 9, timestamp: ago(240), action: 'approve',  details: 'Report approved — Preventive Rx',                              user: 'Sara Colburn'  },
  ],
  'clinical-criteria': [
    { id: 1, timestamp: ago(3),   action: 'approve',  details: 'Report approved — Clinical Criteria (Skyrizi (risankizumab))', user: 'Alana Coleman' },
    { id: 2, timestamp: ago(14),  action: 'generate', details: 'Generated Clinical Criteria intelligence for: Skyrizi (risankizumab)', user: 'Alana Coleman' },
    { id: 3, timestamp: ago(28),  action: 'generate', details: 'Generated Clinical Criteria intelligence for: Stelara (ustekinumab)', user: 'Sara Colburn'  },
    { id: 4, timestamp: ago(50),  action: 'status',   details: 'Approval revoked — moved back to In Review',                   user: 'Alana Coleman' },
    { id: 5, timestamp: ago(72),  action: 'approve',  details: 'Report approved — Clinical Criteria (Stelara (ustekinumab))', user: 'Tracy Thompson'},
    { id: 6, timestamp: ago(95),  action: 'generate', details: 'Generated Clinical Criteria intelligence for: Humira (adalimumab)', user: 'Tracy Thompson'},
    { id: 7, timestamp: ago(140), action: 'generate', details: 'Generated Clinical Criteria intelligence for: Rinvoq (upadacitinib)', user: 'Sara Colburn'},
    { id: 8, timestamp: ago(200), action: 'approve',  details: 'Report approved — Clinical Criteria (Humira (adalimumab))',   user: 'Sara Colburn'  },
    { id: 9, timestamp: ago(280), action: 'generate', details: 'Generated Clinical Criteria intelligence for: Tremfya (guselkumab)', user: 'Alana Coleman'},
  ],
};

export function useAuditTrail(pageId) {
  const [entries, setEntries] = useState(() => {
    try {
      const raw = localStorage.getItem(storageKey(pageId));
      if (raw) return JSON.parse(raw);
      const mock = MOCK_ENTRIES[pageId] || [];
      localStorage.setItem(storageKey(pageId), JSON.stringify(mock));
      return mock;
    } catch (e) {
      return MOCK_ENTRIES[pageId] || [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(storageKey(pageId), JSON.stringify(entries));
    } catch (e) {}
  }, [entries, pageId]);

  const addEntry = useCallback((action, details, user = 'You') => {
    setEntries(prev => [
      {
        id: Date.now() + Math.random(),
        timestamp: new Date().toISOString(),
        action,
        details,
        user,
      },
      ...prev,
    ]);
  }, []);

  const clearAll = useCallback(() => {
    setEntries([]);
  }, []);

  return { entries, addEntry, clearAll };
}
