import { API_BASE_URL, LOGIN_BASE_URL } from './apiBaseUrl';

const BASE_URL = API_BASE_URL.replace(/\/+$/, '');

const enc = encodeURIComponent;

export const API_CONFIG = {
  auth: {
    // LDAP validation goes to the login environment's API (localhost → DEV); the request's `env` is LOGIN_ENV (DEV | UAT | PROD)
    login: `${LOGIN_BASE_URL.replace(/\/+$/, '')}/ldap/validate`,
    me:    `${BASE_URL}/auth/me`,
    refresh: `${BASE_URL}/auth/refresh`,
  },
  designatedRx: {
    jobRuns:  `${BASE_URL}/designated-rx/job-runs`,
    snapshot: (jobRunId) => `${BASE_URL}/designated-rx/${enc(jobRunId)}`,
    status:   (jobRunId) => `${BASE_URL}/designated-rx/${enc(jobRunId)}/status`,
    edits:    (jobRunId) => `${BASE_URL}/designated-rx/${enc(jobRunId)}/edits`,
    export:   (jobRunId) => `${BASE_URL}/designated-rx/v2/${enc(jobRunId)}/export`,
  },
  rxDrugs: {
    upload: `${BASE_URL}/rx-drugs/upload-s3-rx-drug-files`,
  },
};
