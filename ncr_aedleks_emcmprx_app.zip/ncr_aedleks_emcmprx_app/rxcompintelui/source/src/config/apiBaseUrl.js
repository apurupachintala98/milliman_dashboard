export const API_URLS = {
    dev:     'https://rxcompintel.edagenaidev.awsdns.internal.das',
    preprod: 'https://rxcompintel.edagenaipreprod.awsdns.internal.das',
    prod:    'https://rxcompintel.edagenaiprod.awsdns.internal.das',
  };

  // UI hostname → API environment:
  //   localhost / 127.0.0.1                  → dev (local development)
  //   rxcompintel.preprod.elevancehealth.com → preprod
  //   rxcompintel.dev.elevancehealth.com     → dev
  //   rxcompintel.elevancehealth.com         → prod
  export function detectEnv(hostname = typeof window !== 'undefined' ? window.location.hostname : '') {
    const host = String(hostname || '').toLowerCase();
    if (host === 'localhost' || host === '127.0.0.1') return 'dev';
    if (host.includes('preprod')) return 'preprod';   // checked before 'prod' ("preprod" contains "prod")
    if (host.includes('dev')) return 'dev';
    if (host === 'rxcompintel.elevancehealth.com' || host.includes('prod')) return 'prod';
    console.warn(`[config] Unrecognised host "${host}" — defaulting to the DEV API`);
    return 'dev';
  }
   
  export const APP_ENV = detectEnv();
  export const API_BASE_URL = API_URLS[APP_ENV];

  // `env` sent to the login API (/ldap/validate), per environment
  export const LOGIN_ENVS = {
    dev:     'DEV',
    preprod: 'UAT',
    prod:    'PROD',
  };
  // Login environment: same as APP_ENV; localhost logs in against DEV (same as its other APIs)
  const isLocalhost = typeof window !== 'undefined' && ['localhost', '127.0.0.1'].includes(window.location.hostname.toLowerCase());
  export const LOGIN_APP_ENV = isLocalhost ? 'dev' : APP_ENV;
  export const LOGIN_ENV = LOGIN_ENVS[LOGIN_APP_ENV];
  export const LOGIN_BASE_URL = API_URLS[LOGIN_APP_ENV];
   