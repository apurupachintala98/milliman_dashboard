const MINUTE = 60 * 1000;

export const SESSION_CONFIG = {
  IDLE_WARNING_AFTER_MS: 20 * MINUTE,        // no activity → show "Stay signed in?" warning
  IDLE_LOGOUT_AFTER_WARNING_MS: 10 * MINUTE, // warning ignored → sign out
  REFRESH_BEFORE_EXPIRY_MS: 2 * MINUTE,      // renew the token this long before it expires (failure → sign out)
};

const idleMinutes = (SESSION_CONFIG.IDLE_WARNING_AFTER_MS + SESSION_CONFIG.IDLE_LOGOUT_AFTER_WARNING_MS) / MINUTE;

// Shown on the Sign-in page, keyed by the sign-out reason
export const SIGN_OUT_MESSAGES = {
  idle: `You were signed out after ${idleMinutes} minutes of inactivity. Please sign in again.`,
  expired: 'Your session has expired. Please sign in again.',
};
