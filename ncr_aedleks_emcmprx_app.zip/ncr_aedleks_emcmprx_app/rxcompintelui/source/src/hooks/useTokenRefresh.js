import { useEffect, useRef } from 'react';
import { getTokenExpiry, refreshToken } from '../services/authService';

const MAX_TIMEOUT_MS = 2 ** 31 - 1; // setTimeout limit
const delayUntil = (time) => Math.min(Math.max(0, time - Date.now()), MAX_TIMEOUT_MS);

/**
 * Keeps the session's token fresh while signed in.
 * - Shortly before the token expires, calls POST /auth/refresh and reschedules with the new token.
 * - If the refresh fails, calls `onExpired` (sign out).
 * Inactive users are signed out earlier by the idle timer, so only active sessions get renewed.
 */
export function useTokenRefresh({ enabled, refreshBeforeMs, onExpired }) {
  const onExpiredRef = useRef(onExpired);
  useEffect(() => { onExpiredRef.current = onExpired; });

  useEffect(() => {
    if (!enabled) return undefined;
    let timer;
    let cancelled = false;
    const expiry = () => getTokenExpiry() ?? Date.now() + 60 * 60 * 1000; // unknown expiry → assume 1 hour

    const scheduleRefresh = () => {
      timer = setTimeout(async () => {
        try {
          await refreshToken();
          if (cancelled) return;
          // New token too short-lived to refresh again before it expires → sign out when it expires
          if (expiry() - refreshBeforeMs > Date.now()) scheduleRefresh();
          else timer = setTimeout(() => onExpiredRef.current(), delayUntil(expiry()));
        } catch (e) {
          console.warn('[auth] token refresh failed — signing out', e);
          if (!cancelled) onExpiredRef.current();
        }
      }, delayUntil(expiry() - refreshBeforeMs));
    };

    scheduleRefresh();
    return () => { cancelled = true; clearTimeout(timer); };
  }, [enabled, refreshBeforeMs]);
}
