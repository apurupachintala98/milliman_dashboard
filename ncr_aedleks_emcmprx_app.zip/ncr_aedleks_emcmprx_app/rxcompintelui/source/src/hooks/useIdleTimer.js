import { useState, useEffect, useRef, useCallback } from 'react';

const ACTIVITY_EVENTS = ['mousemove', 'mousedown', 'keydown', 'wheel', 'scroll', 'touchstart'];
const ACTIVITY_THROTTLE_MS = 1000;

/**
 * Tracks user inactivity.
 * - No activity for `idleMs` → returns `warningDeadline` (ms epoch) so the UI can ask "stay signed in?".
 * - Still no response within `warningMs` → calls `onTimeout`.
 * While the warning is shown, passive activity is ignored — the user must call `stayActive()` (or sign out).
 */
export function useIdleTimer({ enabled, idleMs, warningMs, onTimeout }) {
  const [warningDeadline, setWarningDeadline] = useState(null);
  const timerRef = useRef(null);
  const warningRef = useRef(false);
  const onTimeoutRef = useRef(onTimeout);
  useEffect(() => { onTimeoutRef.current = onTimeout; });

  // (Re)starts the idle countdown: idle → warning → timeout
  const startTimer = useCallback(() => {
    clearTimeout(timerRef.current);
    warningRef.current = false;
    timerRef.current = setTimeout(() => {
      warningRef.current = true;
      setWarningDeadline(Date.now() + warningMs);
      timerRef.current = setTimeout(() => onTimeoutRef.current(), warningMs);
    }, idleMs);
  }, [idleMs, warningMs]);

  const stayActive = useCallback(() => {
    setWarningDeadline(null);
    startTimer();
  }, [startTimer]);

  useEffect(() => {
    if (!enabled) return undefined;
    startTimer();
    let lastActivity = 0;
    const onActivity = () => {
      const now = Date.now();
      if (warningRef.current || now - lastActivity < ACTIVITY_THROTTLE_MS) return;
      lastActivity = now;
      startTimer();
    };
    ACTIVITY_EVENTS.forEach(e => window.addEventListener(e, onActivity, { passive: true }));
    return () => {
      clearTimeout(timerRef.current);
      ACTIVITY_EVENTS.forEach(e => window.removeEventListener(e, onActivity));
      warningRef.current = false;
      setWarningDeadline(null);
    };
  }, [enabled, startTimer]);

  return { warningDeadline, stayActive };
}
