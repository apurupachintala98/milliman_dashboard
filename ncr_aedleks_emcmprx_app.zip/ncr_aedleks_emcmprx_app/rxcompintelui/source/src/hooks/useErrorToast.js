import { useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { toUserMessage } from '../services/errors';

/**
 * Shows any failure as an error toast in plain language (never the raw API error).
 * Usage: const notifyError = useErrorToast(); … notifyError(err, 'save your change');
 * `action` completes the generic message "We couldn't …".
 */
export function useErrorToast() {
  const { addToast } = useApp();
  return useCallback(
    (err, action) => addToast(toUserMessage(err, { action }), 'error', { position: 'top', duration: 6000 }),
    [addToast]);
}
