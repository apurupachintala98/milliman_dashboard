import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { getToken, getUser, clearSession, getTokenExpiry } from './services/authService';
import { onUnauthorized } from './services/client';
import { SESSION_CONFIG, SIGN_OUT_MESSAGES } from './config/sessionConfig';
import { useIdleTimer } from './hooks/useIdleTimer';
import { useTokenRefresh } from './hooks/useTokenRefresh';
import IdleWarningModal from './components/IdleWarningModal';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { isRouteEnabled } from './featureAccess';
import { AppProvider } from './context/AppContext';
import { roleFromUserRoles } from './services/access';
import { DesignatedRxProvider } from './context/DesignatedRxContext';
import { PreventiveRxProvider } from './context/PreventiveRxContext';
import Layout from './components/Layout';
import ToastContainer from './components/ToastContainer';
import SignIn from './pages/SignIn';

// Route pages are loaded on demand (code-split) so the initial bundle stays small
const Home = lazy(() => import('./pages/Home'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Projects = lazy(() => import('./pages/Projects'));
const ProjectDetail = lazy(() => import('./pages/ProjectDetail'));
const CreateProject = lazy(() => import('./pages/CreateProject'));
const Processing = lazy(() => import('./pages/Processing'));
const GridReview = lazy(() => import('./pages/GridReview'));
const Admin = lazy(() => import('./pages/Admin'));
const ClinicalCriteriaWorkflow = lazy(() => import('./pages/ClinicalCriteriaWorkflow'));
const DesignatedNetworkWorkflow = lazy(() => import('./pages/DesignatedNetworkWorkflow'));
const PreventiveRxWorkflow = lazy(() => import('./pages/PreventiveRxWorkflow'));

function PageLoading() {
  return (
    <div className="flex items-center justify-center py-24">
      <div className="w-6 h-6 border-2 border-brand-navy border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

function displayName(name, fallback) {
  const n = String(name || '').trim();
  const m = /^([^,]+),\s*(.+)$/.exec(n);
  return m ? `${m[2]} ${m[1]}` : (n || fallback);
}

// Login `user_roles` decide access: MCM_*_RXCOMPINTL_SUPER_USER → super-user, MCM_*_RXCOMPINTL_USER → user.
// Neither (or no user_roles) → no access: returns null, so the user stays on / goes back to Sign-in.
function toAppUser(me) {
  if (!me) return null;
  const role = roleFromUserRoles(me.user_roles);
  if (!role) return null;
  return {
    userRoles: me.user_roles || [],
    id: me.user_id,
    name: displayName(me.display_name, me.user_id),
    displayName: me.display_name || '',
    email: me.email || '',
    roles: me.roles || [],
    permissions: me.permissions || [],
    role,
  };
}

function restoreUser() {
  const token = getToken();
  const me = getUser();
  const exp = getTokenExpiry(token);
  // Valid token and a profile with an RX Comp Intel role → stay signed in; anything else → clear and sign in again
  const user = token?.access_token && me && (!exp || exp > Date.now() + 5000) ? toAppUser(me) : null;
  if (!user) clearSession();
  return user;
}

function App() {
  const [user, setUser] = useState(restoreUser);
  const [signOutNotice, setSignOutNotice] = useState('');

  function handleSignIn(me) {
    window.history.replaceState(null, '', '/');
    setSignOutNotice('');
    setUser(toAppUser(me));
  }

  // reason: 'idle' | 'expired' → explained on the Sign-in page; none = user clicked Sign out
  const handleSignOut = useCallback((reason) => {
    clearSession();
    window.history.replaceState(null, '', '/');
    setSignOutNotice(SIGN_OUT_MESSAGES[reason] ?? '');
    setUser(null);
  }, []);

  const signedIn = !!user;
  const { warningDeadline, stayActive } = useIdleTimer({
    enabled: signedIn,
    idleMs: SESSION_CONFIG.IDLE_WARNING_AFTER_MS,
    warningMs: SESSION_CONFIG.IDLE_LOGOUT_AFTER_WARNING_MS,
    onTimeout: () => handleSignOut('idle'),
  });
  useTokenRefresh({
    enabled: signedIn,
    refreshBeforeMs: SESSION_CONFIG.REFRESH_BEFORE_EXPIRY_MS,
    onExpired: () => handleSignOut('expired'),
  });

  // An API call returned 401 and /auth/me confirmed the token is no longer valid
  useEffect(() => {
    if (!signedIn) return undefined;
    return onUnauthorized(() => handleSignOut('expired')); // returns the unsubscribe function
  }, [signedIn, handleSignOut]);

  if (!user) {
    // Same toast setup as the signed-in app, so sign-in failures show as toasts too
    return (
      <AppProvider currentUser={null}>
        <SignIn onSignIn={handleSignIn} notice={signOutNotice} />
        <ToastContainer />
      </AppProvider>
    );
  }

  return (
    <BrowserRouter>
      <AppProvider currentUser={user}>
        <DesignatedRxProvider>
        <PreventiveRxProvider>
        <Layout onSignOut={() => handleSignOut()}>
          <Suspense fallback={<PageLoading />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dashboard" element={isRouteEnabled('/dashboard') ? <Dashboard /> : <Navigate to="/" replace />} />
            <Route path="/projects" element={isRouteEnabled('/projects') ? <Projects /> : <Navigate to="/" replace />} />
            <Route path="/projects/create" element={isRouteEnabled('/projects/create') ? <CreateProject /> : <Navigate to="/" replace />} />
            <Route path="/projects/:id" element={isRouteEnabled('/projects/:id') ? <ProjectDetail /> : <Navigate to="/" replace />} />
            <Route path="/projects/:id/processing" element={isRouteEnabled('/projects/:id/processing') ? <Processing /> : <Navigate to="/" replace />} />
            <Route path="/projects/:id/review" element={isRouteEnabled('/projects/:id/review') ? <GridReview /> : <Navigate to="/" replace />} />
            <Route path="/admin" element={isRouteEnabled('/admin') ? <Admin /> : <Navigate to="/" replace />} />
            <Route path="/workflow/clinical-criteria" element={isRouteEnabled('/workflow/clinical-criteria') ? <ClinicalCriteriaWorkflow /> : <Navigate to="/" replace />} />
            <Route path="/workflow/designated-network" element={isRouteEnabled('/workflow/designated-network') ? <DesignatedNetworkWorkflow /> : <Navigate to="/" replace />} />
            <Route path="/workflow/preventive-rx" element={isRouteEnabled('/workflow/preventive-rx') ? <PreventiveRxWorkflow /> : <Navigate to="/" replace />} />
          </Routes>
          </Suspense>
        </Layout>
        <ToastContainer />
        {warningDeadline && (
          <IdleWarningModal deadline={warningDeadline} onStay={stayActive} onSignOut={() => handleSignOut()} />
        )}
        </PreventiveRxProvider>
        </DesignatedRxProvider>
      </AppProvider>
    </BrowserRouter>
  );
}

export default App;