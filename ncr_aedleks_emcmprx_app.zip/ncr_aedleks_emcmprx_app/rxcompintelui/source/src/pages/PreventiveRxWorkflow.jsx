import { useState, useMemo, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { useCan, NO_PERMISSION_MSG, useApp } from '../context/AppContext';
import { usePreventiveRx } from '../context/PreventiveRxContext';
import { useErrorToast } from '../hooks/useErrorToast';
import { saveDownload } from '../services/client';
import { toUserMessage } from '../services/errors';
import { fetchPrxStatus, updatePrxStatus, savePrxEdits, buildPrxCellUpdate, submitPrxDrugListFile, PRX_UPLOAD_EXTENSIONS } from '../services/preventiveRx';
import { Search, Download, ChevronUp, ChevronDown, CheckCircle, XCircle, BarChart2, Zap, Upload, FileText, X, Clock, RefreshCw, ArrowRight, FileSpreadsheet } from 'lucide-react';
import AuditTrail from '../components/AuditTrail';
import { useAuditTrail } from '../config/useAuditTrail';

const MARKETS = ['National', 'California', 'Texas', 'New York', 'Florida'];
const COMPETITORS = ['ESI', 'Optum RX', 'CVS', 'Humana', 'Kaiser', 'Aetna', 'UHC Expanded', 'Cigna All Preventives'];
const LIST_TYPES = ['ACA', 'HDHP', 'General', 'HAS', 'IRS', 'Pre-deductible', 'Preventive Rx'];

const EMPTY = [];
const EMPTY_OBJ = {};
const STATUS_POLL_MS = 5000;   // status re-check interval while Queued / Inprogress
const STATUS_MAX_POLLS = 120;  // ≈10 minutes
const STILL_PROCESSING_MSG = 'This run is still being processed. Please check back in a few minutes or reload the page.';
const JOB_FAILED_MSG = 'Processing failed for this run. Please upload the drug list again, or contact support if it keeps happening.';
const DATA_LOAD_ACTION = 'load the Preventive Rx data';

const STATUS_MAP = {
  'None':               { bg: 'bg-emerald-100 text-emerald-800', icon: <CheckCircle size={12} className="text-emerald-600" /> },
  'Coverage Gap':       { bg: 'bg-red-100 text-red-700',         icon: <XCircle size={12} className="text-red-500" /> },
  'Coverage Advantage': { bg: 'bg-blue-100 text-blue-700',       icon: <CheckCircle size={12} className="text-blue-600" /> },
};

const PRX_INTEL_RESULTS = {
  coverage: [
    { label: 'ESI Coverage Findings', items: ['Covers metformin, glipizide, aspirin, folic acid — fully aligned with Carelon', 'Covers Eliquis (apixaban) and Xarelto (rivaroxaban) on preventive list — Carelon gap', 'Covers Farxiga (dapagliflozin) for T2DM + CV risk — Carelon does not', 'Covers Jardiance (empagliflozin) under General preventive — Carelon gap', 'Does NOT cover fluticasone/salmeterol combo — Carelon advantage'] },
    { label: 'CVS / Optum Coverage Findings', items: ['CVS and Optum both cover Ozempic (semaglutide) under General preventive list', 'Mounjaro (tirzepatide) included by CVS — emerging trend for metabolic disease', 'Both cover prenatal vitamins and folic acid at parity with Carelon', 'CVS covers Advair Diskus brand where Optum prefers generic fluticasone/salmeterol', 'Neither covers warfarin on preventive list — Carelon advantage'] },
    { label: 'UHC Expanded / Cigna Findings', items: ['UHC Expanded covers Eliquis, Xarelto, Jardiance, Farxiga — broadest NOAC and SGLT-2 coverage', 'Cigna All Preventives covers Mounjaro and Ozempic — fullest GLP-1 coverage in market', 'Cigna covers Xarelto for stroke/DVT prevention under ACA preventive category', 'UHC Expanded does not cover warfarin on preventive list', 'Cigna covers Advair Diskus brand in addition to generic — most inclusive asthma list'] },
  ],
  gaps: [
    { label: 'Critical Coverage Gaps (Carelon)', items: ['Eliquis (apixaban): covered by UHC Expanded, Cigna — stroke/DVT prevention; ACA eligible', 'Xarelto (rivaroxaban): covered by ESI, UHC Expanded, Cigna — stroke/DVT prevention; ACA eligible', 'Ozempic (semaglutide): covered by CVS, UHC Expanded — T2DM prevention; General list', 'Jardiance (empagliflozin): covered by CVS, Optum, UHC — T2DM + CV risk; ACA/General', 'Mounjaro (tirzepatide): covered by CVS, Cigna — metabolic disease; emerging coverage trend', 'Farxiga (dapagliflozin): covered by ESI, CVS — T2DM + heart failure prevention; ACA'] },
    { label: 'Carelon Competitive Advantages', items: ['fluticasone/salmeterol (generic Advair): covered by Carelon; ESI and Humana do NOT cover', 'warfarin (Coumadin): covered by Carelon; Kaiser and Cigna do NOT cover on preventive list', 'Breo Ellipta: aligned with all major PBMs — no coverage gap identified', 'albuterol sulfate HFA, budesonide, montelukast: universal alignment — maintained strength', 'prenatal vitamins + folic acid: ACA-mandated — 100% parity across all competitors'] },
    { label: 'List Type Alignment Notes', items: ['ACA list: highest parity across competitors — focus expansion efforts here first', 'HDHP/HSA pre-deductible: fewer drugs eligible; confirm IRS eligibility before adding GLP-1s', 'General preventive: broadest competitor coverage — most GLP-1/SGLT-2 drugs added here', 'Cigna "All Preventives" list covers IRS + ACA + employer additions — broadest scope', 'UHC Expanded: adds beyond ACA baseline — second broadest scope in this comparison'] },
  ],
  recs: [
    { title: 'Priority 1: GLP-1 & SGLT-2 Evaluation', body: 'Ozempic, Jardiance, Mounjaro, and Farxiga are covered by 3–4 competitors. Evaluate adding to General preventive list under T2DM + CV risk reduction indication. Confirm IRS/HDHP eligibility before HDHP list inclusion.', color: '#f59e0b' },
    { title: 'Priority 2: NOAC Coverage for Stroke Prevention', body: 'Eliquis and Xarelto are covered by ESI, UHC Expanded, and Cigna for stroke/DVT prevention. These are ACA-eligible. Prioritize formulary committee review before Q1 2027 annual list update.', color: '#ef4444' },
    { title: 'Maintain Carelon Advantages', body: 'Carelon uniquely covers fluticasone/salmeterol (generic Advair) and warfarin where competitors do not. Document these as member access differentiators in next market communication.', color: '#10b981' },
  ],
};

const RECS = [
  { title: 'Diabetes Gap — GLP-1s & SGLT-2s',        body: 'Ozempic, Jardiance, Mounjaro, and Farxiga are covered by CVS, UHC Expanded, ESI, and Optum on preventive lists. Carelon does not cover these. With GLP-1 market momentum, evaluate ACA/General preventive coverage for T2DM + CV risk reduction indications.',              color: '#f59e0b' },
  { title: 'Blood Clots Gap — NOACs',                body: 'Eliquis (apixaban) and Xarelto (rivaroxaban) are on preventive lists at UHC Expanded and ESI for stroke/DVT prevention. Carelon does not cover. These are high-cost, high-utilization drugs — prioritize coverage review before next annual list cycle.',                color: '#ef4444' },
  { title: 'Carelon Strength — Generic Alignment',   body: 'Carelon covers fluticasone/salmeterol (generic Advair) and warfarin where Optum, Humana, Kaiser do not on preventive lists. These are meaningful access differentiators. Maintain and document these advantages in member-facing communications.',  color: '#10b981' },
];

export default function PreventiveRxWorkflow() {
  const [market, setMarket]       = useState(MARKETS[0]);
  const [competitor, setCompetitor] = useState(COMPETITORS[0]);

  // ── API data (PreventiveRxContext: ad-hoc runs + selected run's page data) ──
  const prx = usePreventiveRx();
  const { loadJobRuns } = prx;
  useEffect(() => { loadJobRuns(); }, [loadJobRuns]);
  const model = prx.snapshot;
  const CARELON_KEYS = model?.carelonColumns ?? EMPTY;   // [{ key, label, payor, plan, url }] — one column per plan
  const PBM_KEYS     = model?.pbmColumns ?? EMPTY;
  const PLAN_KEYS    = model?.planColumns ?? EMPTY;
  const COMP_KEYS    = useMemo(() => [...PBM_KEYS, ...PLAN_KEYS], [PBM_KEYS, PLAN_KEYS]);
  const DRUG_DATA    = model?.drugs ?? EMPTY;            // { drug, drugClass, matchNames, [columnKey]: 'Y' | 'N' }
  const CLASS_DATA   = model?.classes ?? EMPTY;          // { cls, [columnKey]: 'Y' | 'N' }
  const AI_RECS      = model?.recommendations ?? EMPTY;
  const dataStatus = prx.jobRunsStatus === 'error' ? 'error'
    : prx.jobRunsStatus === 'ready' && prx.jobRuns.length === 0 ? 'empty'
      : prx.snapshotStatus === 'error' ? 'error'
        : prx.snapshotStatus === 'ready' ? 'ready'
          : 'loading';
  const dataError = prx.jobRunsError || prx.snapshotError;
  // Runs / run data failed to load → toast (the page also keeps its Retry card)
  const notifyLoadError = useErrorToast();
  useEffect(() => { if (dataError) notifyLoadError(dataError, DATA_LOAD_ACTION); }, [dataError, notifyLoadError]);

  const [setupOpen, setSetupOpen] = useState(true);
  const [exportOpen, setExportOpen] = useState(false);
  // Manual cell changes: { "drug|columnKey": { covered, note, original } } — starts from the run's saved edits;
  // local changes belong to the run they were made on, so switching runs shows that run's saved edits again
  const [localEdits, setLocalEdits] = useState({ runKey: null, overrides: {} });
  const savedOverrides = prx.snapshot?.manualOverrides ?? EMPTY_OBJ;
  const cellOverrides = localEdits.runKey === prx.snapshotKey ? localEdits.overrides : savedOverrides;
  const setCellOverrides = (update) => setLocalEdits(prev => {
    const base = prev.runKey === prx.snapshotKey ? prev.overrides : savedOverrides;
    return { runKey: prx.snapshotKey, overrides: typeof update === 'function' ? update(base) : update };
  });
  const [cellNote, setCellNote] = useState(null);
  const [confirmModal, setConfirmModal] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadSource, setUploadSource] = useState('carelon');
  const [tableSearch, setTableSearch] = useState('');
  const fileInputRef = useRef(null);
  const exportRef = useRef(null);
  const { entries: auditEntries, addEntry: auditAdd, clearAll: auditClear } = useAuditTrail('preventive-rx');

  // Close the export dropdown on any click outside it
  useEffect(() => {
    if (!exportOpen) return;
    function handleClickOutside(e) {
      if (exportRef.current && !exportRef.current.contains(e.target)) setExportOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [exportOpen]);

  const [search, setSearch]       = useState('');
  const [view, setView]           = useState('drug');
  const [diffFilter, setDiffFilter] = useState('all');
  const [sortCol, setSortCol]     = useState('drug');
  const [sortDir, setSortDir]     = useState('asc');
  const [aiTopN, setAiTopN]       = useState(5);
  const [generating, setGenerating] = useState(false);
  const generated = true;
  const [reportStatus, setReportStatus] = useState('in-progress');
  // Role-based access (login user_roles): normal users can only view and export
  const allowed = useCan();
  const canGenerate = allowed('generate'), canUpload = allowed('upload'), canApprove = allowed('approve');
  const noPermission = (ok) => (ok ? undefined : NO_PERMISSION_MSG);
  const { addToast, currentUser } = useApp();
  const notifyError = useErrorToast();
  const userId = currentUser?.id || currentUser?.name || '';
  const runLabel = prx.selectedRun?.label || prx.selectedJobRunId || '';

  // ── Status: GET /{id}/status — polls every 5s while Queued / Inprogress, then sets the pipeline step ──
  const [statusTick, setStatusTick] = useState(0);   // bump to re-check (e.g. after an upload)
  const statusFromApiRef = useRef(false);
  useEffect(() => { statusFromApiRef.current = false; }, [prx.selectedJobRunId]);
  useEffect(() => {
    if (!statusFromApiRef.current && prx.snapshot?.reportStatus) setReportStatus(prx.snapshot.reportStatus);
  }, [prx.snapshot]);
  const reloadPrxSnapshot = prx.reloadSnapshot;
  const fromUploadRef = useRef(null); // jobRunId just submitted via Upload (first status check after it)
  // Latest loaded data for the status check below (does the loaded run already have its drug rows?)
  const loadedDrugCountRef = useRef(0);
  const loadedSnapshotRef = useRef(null); // jobRunId whose data has finished loading
  useEffect(() => {
    loadedDrugCountRef.current = prx.snapshot?.drugs?.length ?? 0;
    loadedSnapshotRef.current = prx.snapshotStatus === 'ready' ? prx.snapshotKey : null;
  }, [prx.snapshot, prx.snapshotStatus, prx.snapshotKey]);
  useEffect(() => {
    const jobRunId = prx.selectedJobRunId;
    if (!jobRunId) return undefined;
    const controller = new AbortController();
    let timer, polls = 0, wasProcessing = false;
    const check = async () => {
      polls += 1;
      try {
        const res = await fetchPrxStatus(jobRunId, { label: runLabel, signal: controller.signal });
        if (controller.signal.aborted) return;
        if (res.stage === 'processing') {
          wasProcessing = true;
          statusFromApiRef.current = true;
          setReportStatus('in-progress');
          setGenerating(true);
          if (polls < STATUS_MAX_POLLS) { timer = setTimeout(check, STATUS_POLL_MS); return; }
          setGenerating(false);
          addToast(STILL_PROCESSING_MSG, 'warning', { position: 'top', duration: 6000 });
          return;
        }
        setGenerating(false);
        if (res.stage === 'failed') {
          console.warn('[status] Preventive Rx run failed:', res.status, res.message);
          addToast(JOB_FAILED_MSG, 'error', { position: 'top', duration: 8000 });
        } else if (res.stage) {
          statusFromApiRef.current = true;
          setReportStatus(res.stage);
          if (wasProcessing && res.message) addToast(res.message, 'success');
          // Finished, but the data on screen was loaded before it finished (loaded, with no drug rows) → load the results.
          // While the first load is still in flight it's left alone.
          const staleEmpty = loadedSnapshotRef.current === jobRunId && loadedDrugCountRef.current === 0;
          console.log('[prx] status check done:', { jobRunId, stage: res.stage, wasProcessing, loadedFor: loadedSnapshotRef.current, loadedDrugs: loadedDrugCountRef.current, reload: wasProcessing || staleEmpty }); // DEBUG [prx]
          if (wasProcessing || staleEmpty) reloadPrxSnapshot({ silent: true });
          else if (fromUploadRef.current === jobRunId) {
            // Just uploaded but the status never showed processing (as in Designated Network):
            // reload once more shortly so the new results are picked up when they land
            console.log('[prx] after upload: status already finished — reloading again in 35s'); // DEBUG [prx]
            timer = setTimeout(() => reloadPrxSnapshot({ silent: true }), 35_000);
          }
          if (fromUploadRef.current === jobRunId) fromUploadRef.current = null;
        } else {
          console.warn('[status] unrecognised Preventive Rx status:', res.status, res.message);
        }
      } catch (e) {
        if (e.name === 'AbortError') return;
        setGenerating(false);
        notifyError(e, 'check the run status');
      }
    };
    check();
    return () => { controller.abort(); clearTimeout(timer); setGenerating(false); };
  }, [prx.selectedJobRunId, statusTick, runLabel, addToast, notifyError, reloadPrxSnapshot]);

  // ── Approve / Revoke: PUT /{id}/status ──
  const [approving, setApproving] = useState(false);
  async function changeReportStatus(next) {
    const jobRunId = prx.selectedJobRunId;
    if (!jobRunId || approving || !canApprove) return;
    setApproving(true);
    try {
      const res = await updatePrxStatus(jobRunId, { snapshotStatus: next === 'approved' ? 'Approved' : 'In Review', updatedBy: userId });
      statusFromApiRef.current = true;
      setReportStatus(next);
      addToast(res?.message || (next === 'approved' ? 'Run approved.' : 'Approval revoked. The run is back In Review.'), 'success', { position: 'top' });
    } catch (err) {
      notifyError(err, next === 'approved' ? 'approve this run' : 'revoke the approval');
    } finally {
      setApproving(false);
    }
  }

  // ── Upload: .json drug list → POST /process-drug-list (202) → select the run and poll its status ──
  const [uploading, setUploading] = useState(false);
  async function handleFileUpload(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !allowed('upload') || uploading) return;
    setUploading(true);
    try {
      const res = await submitPrxDrugListFile(file);
      setUploadedFile(file);
      addToast(res.message, 'success', { position: 'top' });
      console.log('[prx] upload accepted:', res.body, '| selected before:', prx.selectedJobRunId); // DEBUG [prx]
      if (res.jobRunId) {
        fromUploadRef.current = res.jobRunId;
        // Refresh the list first, then select the new run (so the list can't switch the selection back)
        await prx.loadJobRuns({ force: true });
        if (res.jobRunId !== prx.selectedJobRunId) prx.selectJobRun(res.jobRunId);
        // Same run (one result per day — re-upload overwrites it): reload its data and restart status polling
        else { prx.reloadSnapshot({ silent: true }); setStatusTick(t => t + 1); }
      }
    } catch (err) {
      notifyError(err, 'submit the drug list');
    } finally {
      setUploading(false);
    }
  }

  // Generate Intelligence: re-fetch the selected run's data and status (processing starts from the upload)
  function handleGenerate() {
    if (!canGenerate || !prx.selectedJobRunId) return;
    prx.reloadSnapshot();
    setStatusTick(t => t + 1);
  }

  function toggleSort(col) {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  }

  const allCarelonKeys = useMemo(() => CARELON_KEYS.map(c => c.key), [CARELON_KEYS]);
  const allCompKeys    = useMemo(() => COMP_KEYS.map(c => c.key), [COMP_KEYS]);

  const filtered = useMemo(() => {
    const q = (search || tableSearch).toLowerCase();
    let rows = DRUG_DATA.filter(r => {
      if (q && !r.drug.toLowerCase().includes(q) && !r.drugClass.toLowerCase().includes(q)) return false;
      if (diffFilter === 'carelonOnly') return allCarelonKeys.some(k => r[k] === 'Y') && allCompKeys.every(k => r[k] === 'N');
      if (diffFilter === 'compOnly')   return allCarelonKeys.every(k => r[k] === 'N') && allCompKeys.some(k => r[k] === 'Y');
      if (diffFilter === 'common')     return allCarelonKeys.some(k => r[k] === 'Y') && allCompKeys.some(k => r[k] === 'Y');
      return true;
    });
    return [...rows].sort((a, b) => {
      const av = a[sortCol] || ''; const bv = b[sortCol] || '';
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  }, [DRUG_DATA, allCarelonKeys, allCompKeys, search, tableSearch, diffFilter, sortCol, sortDir]);


  // DEBUG [prx]: what the grid is rendering from
  useEffect(() => {
    console.log('[prx] page render state:', {
      dataStatus, generated, generating, view, diffFilter, search: search || tableSearch,
      jobRunsStatus: prx.jobRunsStatus, jobRuns: prx.jobRuns.length, selectedJobRunId: prx.selectedJobRunId,
      snapshotStatus: prx.snapshotStatus, snapshotKey: prx.snapshotKey, snapshotError: prx.snapshotError?.message,
      DRUG_DATA: DRUG_DATA.length, CLASS_DATA: CLASS_DATA.length, filteredRows: filtered.length,
      CARELON_KEYS: CARELON_KEYS.length, COMP_KEYS: COMP_KEYS.length, reportStatus,
      gridVisible: generated && dataStatus === 'ready',
    });
  }, [dataStatus, generating, view, diffFilter, search, tableSearch, prx.jobRunsStatus, prx.jobRuns.length, prx.selectedJobRunId,
    prx.snapshotStatus, prx.snapshotKey, prx.snapshotError, DRUG_DATA, CLASS_DATA, filtered, CARELON_KEYS, COMP_KEYS, reportStatus, generated]);

  const carelonCoveredCount = DRUG_DATA.filter(d => allCarelonKeys.some(k => d[k] === 'Y')).length;
  const compOnlyCount       = DRUG_DATA.filter(d => allCarelonKeys.every(k => d[k] === 'N') && allCompKeys.some(k => d[k] === 'Y')).length;
  const carelonOnlyCount    = DRUG_DATA.filter(d => allCarelonKeys.some(k => d[k] === 'Y') && allCompKeys.every(k => d[k] === 'N')).length;
  const commonCount         = DRUG_DATA.filter(d => allCarelonKeys.some(k => d[k] === 'Y') && allCompKeys.some(k => d[k] === 'Y')).length;

  // Hover tooltip lookups — computed once per data load instead of per cell on every render
  const coveringByDrug = useMemo(() => new Map(DRUG_DATA.map(d => [d.drug, COMP_KEYS.filter(ck => d[ck.key] === 'Y')])), [DRUG_DATA, COMP_KEYS]);
  const drugsByClass = useMemo(() => {
    const m = new Map();
    for (const d of DRUG_DATA) { if (!m.has(d.drugClass)) m.set(d.drugClass, []); m.get(d.drugClass).push(d); }
    return m;
  }, [DRUG_DATA]);
  const coveringOf = (row) => coveringByDrug.get(row.drug) ?? EMPTY;
  const sameClassOf = (row) => (drugsByClass.get(row.drugClass) ?? EMPTY).filter(d => d.drug !== row.drug);
  // Tooltip state lives in HoverTooltip, so hovering a cell doesn't re-render the whole grid
  const tooltipRef = useRef(null);
  const showTooltip = (e, content) => {
    const r = e.currentTarget.getBoundingClientRect();
    tooltipRef.current?.show({ x: r.left + r.width / 2, y: r.top, content });
  };
  const hideTooltip = () => tooltipRef.current?.hide();

  // Column header: payor + plan name (Carelon columns show just the plan); linked when the plan has a web URL
  const colHeader = (c) => {
    const text = c.payor && c.plan && c.label !== c.plan
      ? <><span className="block">{c.payor}</span><span className="block text-[10px] font-normal normal-case opacity-80">{c.plan}</span></>
      : c.label;
    return c.url
      ? <a href={c.url} target="_blank" rel="noopener noreferrer" title={c.url} className="underline underline-offset-2 hover:opacity-80">{text}</a>
      : <span title={c.key}>{text}</span>;
  };

  // ── Cell edits: PUT /{id}/edits (one update per change; Revert sends the cell back to its original value) ──
  const cellKeyOf = (row, columnKey) => `${row.drug}|${columnKey}`;
  async function saveCellEdit({ revert = false } = {}) {
    const m = confirmModal;
    const jobRunId = prx.selectedJobRunId;
    if (!m || !jobRunId || m.saving) return;
    const existing = cellOverrides[m.cellKey];
    const originalCovered = existing?.original ?? (m.row[m.compKey] === 'Y');
    const currentCovered = existing?.covered ?? originalCovered;
    const covered = revert ? originalCovered : m.localCovered;
    const note = revert ? '' : (m.localNote || '').trim();
    const moved = currentCovered !== covered;
    if (!moved && !revert && (!note || note === (existing?.note ?? ''))) {
      setConfirmModal(null);
      addToast(`${m.row.drug} · ${m.comp}: no change — nothing was saved.`, 'warning', { position: 'top' });
      return;
    }
    setConfirmModal(prev => prev && { ...prev, saving: true });
    try {
      await savePrxEdits(jobRunId, {
        updatedBy: userId,
        reportStatus,
        label: runLabel,
        updates: [buildPrxCellUpdate({ row: m.row, column: m.column, oldCovered: currentCovered, newCovered: covered, note, user: userId })],
      });
      setCellOverrides(prev => {
        const next = { ...prev };
        if (revert) delete next[m.cellKey];
        else next[m.cellKey] = { covered, note, original: originalCovered };
        return next;
      });
      setConfirmModal(null);
      addToast(`${m.row.drug} · ${m.comp}: ${revert ? 'reverted' : !moved ? 'note saved' : covered ? 'marked covered' : 'marked not covered'}`, 'success', { position: 'top' });
    } catch (err) {
      setConfirmModal(prev => prev && { ...prev, saving: false }); // keep the dialog open so the user can retry
      notifyError(err, 'save your change');
    }
  }

  // ── Export: Excel of the table as currently filtered/sorted, including manual cell changes ──
  const [exporting, setExporting] = useState(false);
  async function handleExport(format) {
    setExportOpen(false);
    if (format !== 'xlsx' || exporting) return; // PowerPoint / PDF not available yet
    setExporting(true);
    try {
      const { buildPreventiveRxXlsx } = await import('../export/prxExcelExport');
      const listKeys = [...CARELON_KEYS, ...COMP_KEYS].map(c => c.key);
      const blob = await buildPreventiveRxXlsx({
        carelonColumns: CARELON_KEYS,
        compColumns: COMP_KEYS,
        rows: filtered.map(r => ({
          drug: r.drug, drugClass: r.drugClass,
          cells: Object.fromEntries(listKeys.map(k => {
            const ov = cellOverrides[cellKeyOf(r, k)]; // same key the table uses
            return [k, { covered: ov ? ov.covered : r[k] === 'Y', manual: !!ov }];
          })),
        })),
      });
      const filename = `Preventive_Rx_${String(runLabel || 'export').replace(/[^A-Za-z0-9]+/g, '_')}.xlsx`;
      saveDownload({ blob, filename });
      addToast(`Export downloaded: ${filename}`, 'success', { position: 'top' });
    } catch (err) {
      console.error('[export]', err);
      notifyError(err, 'create the Excel export');
    } finally {
      setExporting(false);
    }
  }


  const kpis = [
    { label: 'Total Drugs',        value: DRUG_DATA.length,      color: 'text-brand-navy',  bg: 'bg-brand-light' },
    { label: 'Carelon Covered',    value: carelonCoveredCount,   color: 'text-emerald-700', bg: 'bg-emerald-50' },
    { label: 'Common (Both)',      value: commonCount,           color: 'text-teal-700',    bg: 'bg-teal-50' },
    { label: 'Carelon Only',       value: carelonOnlyCount,      color: 'text-blue-700',    bg: 'bg-blue-50' },
    { label: 'Competitor Only',    value: compOnlyCount,         color: 'text-amber-700',   bg: 'bg-amber-50' },
  ];

  return (
    <div className="space-y-5">

      {/* ── Page Header ── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Preventive Rx</p>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-bold text-brand-navy">Preventive Drug List Comparison</h1>
            {runLabel && (
              <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{ backgroundColor: '#1A3673', color: '#fff', letterSpacing: '0.04em' }}>
                ● Current · {runLabel}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-400 mt-1">Compare Carelon's preventive drug list against competitor PBMs · Identify coverage gaps and advantages</p>
        </div>
        <div className="relative flex items-center gap-2" ref={exportRef}>
          <button
            onClick={() => reportStatus === 'approved' && setExportOpen(o => !o)}
            disabled={reportStatus !== 'approved'}
            title={reportStatus !== 'approved' ? 'Approve the report to enable export' : 'Export report'}
            className={`btn-secondary flex items-center gap-2 text-xs transition-all ${reportStatus !== 'approved' ? 'opacity-40 cursor-not-allowed' : ''}`}>
            <Download size={14} /> Export <ChevronDown size={12} className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`} />
          </button>
          {exportOpen && (
            <div className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
              {[
                { format: 'pptx', label: 'PowerPoint (.pptx)', icon: <FileText size={13} className="text-orange-500" /> },
                { format: 'pdf',  label: 'PDF (.pdf)',          icon: <FileText size={13} className="text-red-500" /> },
                { format: 'xlsx', label: 'Excel (.xlsx)',       icon: <FileSpreadsheet size={13} className="text-emerald-600" /> },
              ].map(opt => (
                <button key={opt.label} onClick={() => handleExport(opt.format)}
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                  {opt.icon} {opt.label}
                </button>
              ))}
            </div>
          )}
                    <AuditTrail pageId="preventive-rx" entries={auditEntries} onClear={auditClear} />
        </div>
      </div>


      {/* ── Action Bar ── */}
      <div className="card py-3 px-4">
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={handleGenerate} disabled={generating || !canGenerate} title={noPermission(canGenerate)}
            className={`btn-primary flex items-center gap-2 px-5 py-2 text-sm font-semibold ${generating || !canGenerate ? 'opacity-50 cursor-not-allowed' : ''}`}>
            <Zap size={15} /> {generating ? 'Generating...' : 'Generate Intelligence'}
          </button>
          <div className="h-6 w-px bg-gray-200" />
          <input ref={fileInputRef} type="file" accept={PRX_UPLOAD_EXTENSIONS.join(',')} className="hidden" onChange={handleFileUpload} />
          {uploadedFile ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
              <CheckCircle size={13} className="text-emerald-600 shrink-0" />
              <span className="font-semibold text-emerald-800 max-w-[180px] truncate">{uploadedFile.name}</span>
              <button onClick={() => setUploadedFile(null)} className="ml-1 text-gray-400 hover:text-red-500"><X size={12} /></button>
            </div>
          ) : (
            <button onClick={() => fileInputRef.current?.click()} disabled={!canUpload || uploading}
              title={noPermission(canUpload) || 'Upload the Preventive Rx drug list workbook (.xlsx)'}
              className={`btn-secondary flex items-center gap-1.5 text-xs ${!canUpload || uploading ? 'opacity-50 cursor-not-allowed' : ''}`}>
              <Upload size={13} /> {uploading ? 'Submitting…' : 'Upload Drug List'}
            </button>
          )}

          {/* ── Status pipeline ── */}
          <div className="h-6 w-px bg-gray-200" />
          <div className="flex items-center gap-1.5">
            {[
              { key: 'in-progress', label: 'In Progress', activeColor: '#D97706', activeBg: '#FEF3C7', activeBorder: '#FCD34D', dot: 'bg-amber-500' },
              { key: 'in-review',   label: 'In Review',   activeColor: '#1D4ED8', activeBg: '#EFF6FF', activeBorder: '#93C5FD', dot: 'bg-blue-500' },
              { key: 'approved',    label: 'Approved',    activeColor: '#059669', activeBg: '#ECFDF5', activeBorder: '#6EE7B7', dot: 'bg-emerald-500' },
            ].map((step, idx) => {
              const steps = ['in-progress', 'in-review', 'approved'];
              const currentIdx = steps.indexOf(reportStatus);
              const stepIdx = steps.indexOf(step.key);
              const isActive = reportStatus === step.key;
              const isDone = stepIdx < currentIdx;
              return (
                <div key={step.key} className="flex items-center gap-1.5">
                  {idx > 0 && <div className={`w-5 h-px ${isDone || isActive ? 'bg-gray-400' : 'bg-gray-200'}`} />}
                  <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                    isActive ? 'border-current' : isDone ? 'bg-gray-50 text-gray-400 border-gray-200' : 'bg-white text-gray-300 border-gray-100'
                  }`} style={isActive ? { backgroundColor: step.activeBg, color: step.activeColor, borderColor: step.activeBorder } : {}}>
                    {isActive && step.key !== 'approved' && <span className={`w-1.5 h-1.5 rounded-full ${step.dot} ${step.key === 'in-progress' ? 'animate-pulse' : ''}`} />}
                    {((isActive && step.key === 'approved') || isDone) ? <CheckCircle size={10} className={isDone ? 'text-gray-400' : 'text-emerald-500'} /> : null}
                    {step.label}
                  </span>
                </div>
              );
            })}
            {reportStatus === 'in-review' && (
              <button onClick={() => changeReportStatus('approved')} disabled={!canApprove || approving} title={noPermission(canApprove)}
                className={`ml-1 flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-600 text-white transition-colors ${!canApprove ? 'opacity-50 cursor-not-allowed' : 'hover:bg-emerald-700'}`}>
                <CheckCircle size={11} /> Approve
              </button>
            )}
            {reportStatus === 'approved' && (
              <button onClick={() => changeReportStatus('in-review')} disabled={!canApprove || approving} title={noPermission(canApprove)}
                className={`ml-1 text-[10px] text-gray-400 underline ${!canApprove ? 'opacity-60 cursor-not-allowed' : 'hover:text-red-400'}`}>Revoke</button>
            )}
          </div>
        </div>
      </div>

      {/* Generating spinner */}
      {generating && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
          <div className="flex-1">
            <p className="text-brand-navy text-sm font-semibold">Generating intelligence…</p>
            <div className="flex gap-4 mt-1.5 text-xs text-blue-600">
              {['Analyzing coverage','Mapping list types','Identifying gaps','Generating recommendations'].map((s,i) => (
                <span key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay: `${i*200}ms` }} />{s}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Data states: loading / error (with Retry) / no runs yet */}
      {dataStatus === 'loading' && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
          <p className="text-brand-navy text-sm font-semibold">Loading Preventive Rx data…</p>
        </div>
      )}
      {dataStatus === 'error' && (
        <div className="card flex items-center gap-4 bg-red-50 border border-red-100">
          <XCircle size={18} className="text-red-500 shrink-0" />
          <div className="flex-1">
            <p className="text-red-700 text-sm font-semibold">Couldn't load Preventive Rx data</p>
            <p className="text-xs text-red-500 mt-0.5">{toUserMessage(dataError, { action: DATA_LOAD_ACTION })}</p>
          </div>
          <button onClick={() => (prx.jobRunsStatus === 'error' ? prx.loadJobRuns({ force: true }) : prx.reloadSnapshot())}
            className="btn-secondary flex items-center gap-1.5 text-xs">
            <RefreshCw size={12} /> Retry
          </button>
        </div>
      )}
      {dataStatus === 'empty' && (
        <div className="card flex flex-col items-center justify-center py-16 gap-4 border-2 border-dashed border-gray-200 bg-gray-50">
          <Zap size={36} className="text-gray-300" />
          <div className="text-center">
            <p className="text-sm font-semibold text-gray-500">No Preventive Rx runs yet</p>
            <p className="text-xs text-gray-400 mt-1">Click <strong>Upload Drug List</strong> to submit Carelon's preventive drug list and start a comparison</p>
          </div>
        </div>
      )}

      {generated && dataStatus === 'ready' ? (
        <div className="space-y-5">

      {/* Filter + View toggle — single row */}
      <div className="flex flex-wrap items-center gap-3 text-xs">
        <span className="text-gray-400 font-semibold">Filter:</span>
        {[
          { id: 'common',      label: 'Common (Both)',    bg: 'bg-emerald-100 text-emerald-800' },
          { id: 'carelonOnly', label: 'Carelon Only',     bg: 'bg-blue-100 text-blue-800' },
          { id: 'compOnly',    label: 'Competitor Only',  bg: 'bg-amber-100 text-amber-800' },
        ].map(f => (
          <button key={f.id} onClick={() => setDiffFilter(diffFilter === f.id ? 'all' : f.id)}
            className={`px-3 py-1 rounded-full font-semibold border transition-all ${
              diffFilter === f.id ? f.bg + ' border-current' : 'bg-white border-gray-200 text-gray-500 hover:border-gray-400'
            }`}>{f.label}
          </button>
        ))}
        {diffFilter !== 'all' && <button onClick={() => setDiffFilter('all')} className="text-brand-mid underline">Clear</button>}
        <div className="ml-auto flex items-center gap-2">
          <span className="text-gray-400 font-semibold">View:</span>
          {[{ id: 'drug', label: 'By Drug' }, { id: 'class', label: 'By Drug Class' }].map(v => (
            <button key={v.id} onClick={() => setView(v.id)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold border transition-all ${view === v.id ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-navy'}`}>
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* Drug table */}
      {view === 'drug' ? (
        <div className="card p-0 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input className="input pl-9 text-sm py-1.5 w-full" placeholder="Search by drug name or disease state…"
                value={tableSearch} onChange={e => setTableSearch(e.target.value)} />
            </div>
            {tableSearch && (
              <button onClick={() => setTableSearch('')} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1"><X size={12} /> Clear</button>
            )}
            <span className="ml-auto text-xs text-gray-400">{filtered.length} drugs</span>
          </div>
          <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 460 }}>
            {/* Disease State=140, Drug=160 → left offsets: 0, 140 → Carelon starts at 300, each carelon col=110 → 3 cols=330 → shadow at 630 */}
            <table className="text-left" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
              <thead className="sticky top-0 z-20">
                {/* Row 1 — group labels */}
                <tr>
                  {/* Sticky: Disease State + Drug placeholder */}
                  <th colSpan={2} className="px-4 py-2 bg-white border-b border-gray-100"
                    style={{ position: 'sticky', left: 0, zIndex: 22 }} />
                  {/* Sticky: CarelonRx group */}
                  <th colSpan={CARELON_KEYS.length}
                    className="px-3 py-2 text-xs font-bold text-blue-800 text-center bg-blue-100 border-b border-blue-200 whitespace-nowrap tracking-wide uppercase"
                    style={{ position: 'sticky', left: 300, zIndex: 22 }}>
                    CarelonRx
                  </th>
                  {/* Scrollable group headers */}
                  <th colSpan={PBM_KEYS.length} className="px-3 py-2 text-xs font-bold text-orange-800 text-center bg-orange-50 border-b border-orange-200 whitespace-nowrap tracking-wide uppercase">Pharmacy Benefit Managers (PBMs)</th>
                  <th colSpan={PLAN_KEYS.length} className="px-3 py-2 text-xs font-bold text-purple-800 text-center bg-purple-50 border-b border-purple-200 whitespace-nowrap tracking-wide uppercase">Health Plans / Insurers</th>
                </tr>
                {/* Row 2 — column labels */}
                <tr>
                  {/* Disease State sticky */}
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer select-none whitespace-nowrap bg-gray-50 border-b border-gray-200"
                    style={{ position: 'sticky', left: 0, zIndex: 21, minWidth: 140 }}
                    onClick={() => toggleSort('drugClass')}>
                    <div className="flex items-center gap-1">Disease State
                      {sortCol==='drugClass' ? (sortDir==='asc' ? <ChevronUp size={12} className="text-brand-navy" /> : <ChevronDown size={12} className="text-brand-navy" />) : <ChevronUp size={12} className="text-gray-300" />}
                    </div>
                  </th>
                  {/* Drug sticky */}
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer select-none whitespace-nowrap bg-gray-50 border-b border-gray-200"
                    style={{ position: 'sticky', left: 140, zIndex: 21, minWidth: 160 }}
                    onClick={() => toggleSort('drug')}>
                    <div className="flex items-center gap-1">Drug
                      {sortCol==='drug' ? (sortDir==='asc' ? <ChevronUp size={12} className="text-brand-navy" /> : <ChevronDown size={12} className="text-brand-navy" />) : <ChevronUp size={12} className="text-gray-300" />}
                    </div>
                  </th>
                  {/* CarelonRx cols sticky */}
                  {CARELON_KEYS.map((c, ci) => (
                    <th key={c.key}
                      className="px-3 py-2 text-xs font-semibold text-blue-800 text-center whitespace-nowrap bg-blue-50 border-b border-gray-200"
                      style={{
                        position: 'sticky', left: 300 + ci * 110, zIndex: 21, minWidth: 110,
                        boxShadow: ci === CARELON_KEYS.length - 1 ? '2px 0 4px rgba(0,0,0,0.06)' : undefined,
                      }}>
                      {colHeader(c)}
                    </th>
                  ))}
                  {/* Scrollable PBM cols */}
                  {PBM_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-orange-700 text-center whitespace-nowrap bg-orange-50 border-b border-gray-200" style={{ minWidth: 90 }}>{colHeader(c)}</th>
                  ))}
                  {/* Scrollable Health Plan cols */}
                  {PLAN_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-purple-700 text-center whitespace-nowrap bg-purple-50 border-b border-gray-200" style={{ minWidth: 110 }}>{colHeader(c)}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(() => {
                  const makeTooltipContent = (drugRow, manuallyAdded, sameClsList, coveringComps) => (
                    <div className="bg-gray-900 text-white rounded-lg shadow-2xl p-2 text-left" style={{ width: 190 }}>
                      <div className="flex items-start justify-between gap-1.5 mb-1.5">
                        <div>
                          <p className="font-bold text-[10px] text-white leading-tight">{drugRow.drug}</p>
                          <p className="text-[9px] text-gray-300 mt-px">{drugRow.drugClass}</p>
                        </div>
                        {manuallyAdded && <span className="text-[8px] font-bold px-1 py-px rounded bg-orange-500 text-white shrink-0">Manual</span>}
                      </div>
                      <p className="text-[8px] text-gray-400 uppercase tracking-wider font-bold mb-1">Competitors Covering</p>
                      <div className="flex flex-wrap gap-0.5 mb-1.5 pb-1.5 border-b border-white/10">
                        {coveringComps.length > 0
                          ? coveringComps.map(ck => <span key={ck.key} className="text-[8px] font-semibold px-1 py-px rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">{ck.label}</span>)
                          : <span className="text-[9px] text-gray-500">None</span>}
                      </div>
                      {sameClsList.length > 0 && (
                        <>
                          <p className="text-[8px] text-gray-400 uppercase tracking-wider font-bold mb-1">{drugRow.drugClass} — Others</p>
                          <div className="space-y-1 max-h-24 overflow-y-auto">
                            {sameClsList.map(d => {
                              const dComps = coveringOf(d);
                              return (
                                <div key={d.drug} className="rounded bg-white/5 px-1.5 py-0.5">
                                  <p className="text-[9px] font-bold text-white leading-tight">{d.drug}</p>
                                  <div className="flex flex-wrap gap-0.5 mt-0.5">
                                    {dComps.length > 0
                                      ? dComps.map(ck => <span key={ck.key} className="text-[8px] px-1 py-px rounded bg-blue-500/20 text-blue-300">{ck.label}</span>)
                                      : <span className="text-[8px] text-gray-500">No coverage</span>}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </>
                      )}
                    </div>
                  );
                  return filtered.map((row, i) => (
                  <tr key={i} className="hover:bg-blue-50/10 transition-colors">
                    {/* Disease State — sticky */}
                    <td className="px-4 py-2.5 text-xs text-gray-500 whitespace-nowrap border-b border-gray-100"
                      style={{ position: 'sticky', left: 0, zIndex: 10, backgroundColor: '#fff', minWidth: 140 }}>{row.drugClass}</td>
                    {/* Drug — sticky */}
                    <td className="px-4 py-2.5 text-sm font-semibold text-brand-navy whitespace-nowrap border-b border-gray-100"
                      style={{ position: 'sticky', left: 140, zIndex: 10, backgroundColor: '#fff', minWidth: 160 }}>{row.drug}</td>
                    {/* CarelonRx cols — sticky */}
                    {CARELON_KEYS.map((c, ci) => {
                      const cellKey = cellKeyOf(row, c.key);
                      const override = cellOverrides[cellKey]; // { covered, note } | undefined
                      const isOriginalY = row[c.key] === 'Y';
                      const isManuallyAdded = override !== undefined;
                      const isChecked = override !== undefined ? override.covered : isOriginalY;
                      // Tooltip is built only on hover (from per-drug lookups) and shown by HoverTooltip — no grid re-render
                      const handleME = (e) => showTooltip(e, makeTooltipContent(row, isManuallyAdded, sameClassOf(row), coveringOf(row)));
                      const handleML = hideTooltip;
                      const openModal = () => setConfirmModal({ cellKey, row, comp: c.label, compKey: c.key, column: c, localCovered: isChecked, localNote: override?.note ?? '' });
                      return (
                        <td key={c.key} className="px-3 py-2.5 text-center border-b border-gray-100 relative"
                          style={{
                            position: 'sticky', left: 300 + ci * 110, zIndex: 10,
                            backgroundColor: '#EFF6FF', minWidth: 110,
                            boxShadow: ci === CARELON_KEYS.length - 1 ? '2px 0 4px rgba(0,0,0,0.06)' : undefined,
                          }}>
                          <div className="mx-auto inline-block" onMouseEnter={handleME} onMouseLeave={handleML}>
                            <button onClick={openModal} className="mx-auto block">
                              {isChecked
                                ? (isManuallyAdded ? <CheckCircle size={16} className="text-orange-500 mx-auto" /> : <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>)
                                : (isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : <span className="text-gray-200 text-sm hover:text-emerald-400 transition-colors">—</span>)
                              }
                            </button>
                          </div>
                        </td>
                      );
                    })}
                    {/* PBM cols — scrollable */}
                    {PBM_KEYS.map(c => {
                      const cellKey = cellKeyOf(row, c.key);
                      const override = cellOverrides[cellKey]; // { covered, note } | undefined
                      const isOriginalY = row[c.key] === 'Y';
                      const isManuallyAdded = override !== undefined;
                      const isChecked = override !== undefined ? override.covered : isOriginalY;
                      // Tooltip is built only on hover (from per-drug lookups) and shown by HoverTooltip — no grid re-render
                      const handleME2 = (e) => showTooltip(e, makeTooltipContent(row, isManuallyAdded, sameClassOf(row), coveringOf(row)));
                      const handleML2 = hideTooltip;
                      const openModal2 = () => setConfirmModal({ cellKey, row, comp: c.label, compKey: c.key, column: c, localCovered: isChecked, localNote: override?.note ?? '' });
                      return (
                        <td key={c.key} className="px-3 py-2.5 text-center border-b border-gray-100 relative" style={{ backgroundColor: 'rgba(255,237,213,0.3)', minWidth: 90 }}>
                          <div className="mx-auto inline-block" onMouseEnter={handleME2} onMouseLeave={handleML2}>
                            <button onClick={openModal2} className="mx-auto block">
                              {isChecked
                                ? (isManuallyAdded ? <CheckCircle size={16} className="text-orange-500 mx-auto" /> : <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>)
                                : (isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : <span className="text-gray-200 text-sm hover:text-emerald-400 transition-colors">—</span>)
                              }
                            </button>
                          </div>
                        </td>
                      );
                    })}
                    {/* Health Plan cols — scrollable */}
                    {PLAN_KEYS.map(c => {
                      const cellKey = cellKeyOf(row, c.key);
                      const override = cellOverrides[cellKey]; // { covered, note } | undefined
                      const isOriginalY = row[c.key] === 'Y';
                      const isManuallyAdded = override !== undefined;
                      const isChecked = override !== undefined ? override.covered : isOriginalY;
                      // Tooltip is built only on hover (from per-drug lookups) and shown by HoverTooltip — no grid re-render
                      const handleME3 = (e) => showTooltip(e, makeTooltipContent(row, isManuallyAdded, sameClassOf(row), coveringOf(row)));
                      const handleML3 = hideTooltip;
                      const openModal3 = () => setConfirmModal({ cellKey, row, comp: c.label, compKey: c.key, column: c, localCovered: isChecked, localNote: override?.note ?? '' });
                      return (
                        <td key={c.key} className="px-3 py-2.5 text-center border-b border-gray-100 relative" style={{ backgroundColor: 'rgba(245,243,255,0.4)', minWidth: 110 }}>
                          <div className="mx-auto inline-block" onMouseEnter={handleME3} onMouseLeave={handleML3}>
                            <button onClick={openModal3} className="mx-auto block">
                              {isChecked
                                ? (isManuallyAdded ? <CheckCircle size={16} className="text-orange-500 mx-auto" /> : <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>)
                                : (isManuallyAdded ? <X size={14} className="text-red-400 mx-auto" /> : <span className="text-gray-200 text-sm hover:text-emerald-400 transition-colors">—</span>)
                              }
                            </button>
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ));
                })()}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-2.5 border-t border-gray-100 flex items-center gap-4 text-xs text-gray-400 flex-wrap">
            <span className="flex items-center gap-1 font-bold" style={{ color: '#10b981' }}>✓</span><span>= Covered (source data)</span>
            <span className="flex items-center gap-1"><CheckCircle size={11} className="text-orange-500" /></span><span>= Manually added · click for Brand/Generic</span>
            <span className="flex items-center gap-1 text-gray-300">—</span><span>= Not covered · click to mark</span>
            <span className="ml-auto shrink-0">{filtered.length} drugs · scroll horizontally for all competitors</span>
          </div>
        </div>
      ) : (
        <div className="card p-0 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input className="input pl-9 text-sm py-1.5 w-full" placeholder="Search by drug class…"
                value={tableSearch} onChange={e => setTableSearch(e.target.value)} />
            </div>
            {tableSearch && (
              <button onClick={() => setTableSearch('')} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1"><X size={12} /> Clear</button>
            )}
            <span className="ml-auto text-xs text-gray-400">
              {CLASS_DATA.filter(r => !tableSearch || r.cls.toLowerCase().includes(tableSearch.toLowerCase())).length} classes
            </span>
          </div>
          <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 460 }}>
            <table className="w-full text-left min-w-max">
              <thead className="sticky top-0 z-10 border-b border-gray-200">
                <tr>
                  <th className="px-4 py-2 bg-white border-b border-gray-100" />
                  <th colSpan={CARELON_KEYS.length} className="px-3 py-2 text-xs font-bold text-blue-800 text-center bg-blue-100 border-b border-blue-200 uppercase tracking-wide">CarelonRx</th>
                  <th colSpan={PBM_KEYS.length} className="px-3 py-2 text-xs font-bold text-orange-800 text-center bg-orange-50 border-b border-orange-200 uppercase tracking-wide">Pharmacy Benefit Managers (PBMs)</th>
                  <th colSpan={PLAN_KEYS.length} className="px-3 py-2 text-xs font-bold text-purple-800 text-center bg-purple-50 border-b border-purple-200 uppercase tracking-wide">Health Plans / Insurers</th>
                </tr>
                <tr className="bg-gray-50">
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Drug Class</th>
                  {CARELON_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-blue-800 text-center whitespace-nowrap bg-blue-50">{colHeader(c)}</th>
                  ))}
                  {PBM_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-orange-700 text-center whitespace-nowrap bg-orange-50">{colHeader(c)}</th>
                  ))}
                  {PLAN_KEYS.map(c => (
                    <th key={c.key} className="px-3 py-2 text-xs font-semibold text-purple-700 text-center whitespace-nowrap bg-purple-50">{colHeader(c)}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {CLASS_DATA
                  .filter(r => !tableSearch || r.cls.toLowerCase().includes(tableSearch.toLowerCase()))
                  .map((row, i) => (
                    <tr key={i} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-2 text-sm font-semibold text-brand-navy whitespace-nowrap">{row.cls}</td>
                      {CARELON_KEYS.map(c => (
                        <td key={c.key} className="px-3 py-2 text-center bg-blue-50/60">
                          {row[c.key]==='Y' ? <span className="text-blue-700 font-bold">X</span> : <span className="text-gray-200">—</span>}
                        </td>
                      ))}
                      {PBM_KEYS.map(c => (
                        <td key={c.key} className="px-3 py-2 text-center bg-orange-50/60">
                          {row[c.key]==='Y' ? <span className="text-orange-600 font-bold">X</span> : <span className="text-gray-200">—</span>}
                        </td>
                      ))}
                      {PLAN_KEYS.map(c => (
                        <td key={c.key} className="px-3 py-2 text-center bg-purple-50/60">
                          {row[c.key]==='Y' ? <span className="text-purple-700 font-bold">X</span> : <span className="text-gray-200">—</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── AI Recommendations ── */}
      <div className="card">
        <div className="flex items-center gap-2 mb-1">
          <BarChart2 size={16} className="text-brand-navy" />
          <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>AI Recommendations</h2>
          <span className="ml-2 text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-full px-2.5 py-0.5 font-semibold">Human review required</span>
          <div className="ml-auto flex items-center gap-1 text-xs">
            <span className="text-gray-400 font-semibold">Show:</span>
            {[5, 10].map(n => (
              <button key={n} onClick={() => setAiTopN(n)}
                className={`px-3 py-1 rounded-lg font-semibold border transition-all ${
                  aiTopN === n ? 'bg-brand-navy text-white border-brand-navy' : 'bg-white text-gray-500 border-gray-200 hover:border-brand-navy'
                }`}>Top {n}</button>
            ))}
          </div>
        </div>
        <p className="text-xs text-gray-400 mb-4">AI-generated drug coverage recommendations based on competitor preventive list analysis across all payers.</p>
        {AI_RECS.length === 0 && (
          <p className="text-xs text-gray-400 py-4 text-center">No recommendations for this run.</p>
        )}

        {/* Add recommendations */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide">Drug Addition Recommendations</p>
          </div>
          <div className="space-y-2">
            {AI_RECS.filter(r => r.type === 'add').slice(0, aiTopN).map((r, i) => (
              <div key={i} className="rounded-xl border border-emerald-100 bg-emerald-50/40 p-3.5 flex gap-4">
                <div className="w-1 rounded-full shrink-0 self-stretch bg-emerald-400" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <p className="text-sm font-bold text-gray-800">{r.drug}</p>
                      <p className="text-xs text-gray-400">{r.drugClass}</p>
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 shrink-0">+ Add</span>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed mt-1.5">{r.reason}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="text-xs text-gray-400">Covered by:</span>
                    {r.competitors.map(c => <span key={c} className="text-xs font-semibold px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded">{c}</span>)}
                  </div>
                </div>
                <button className="self-start text-xs font-semibold text-brand-navy flex items-center gap-1 hover:underline shrink-0 mt-0.5">
                  Review <ArrowRight size={11} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Remove / Maintain recommendations */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-red-400" />
            <p className="text-xs font-bold text-red-600 uppercase tracking-wide">Drug Removal Recommendations</p>
          </div>
          <div className="space-y-2">
            {AI_RECS.filter(r => r.type === 'remove').slice(0, aiTopN).map((r, i) => (
              <div key={i} className="rounded-xl border border-red-100 bg-red-50/30 p-3.5 flex gap-4">
                <div className="w-1 rounded-full shrink-0 self-stretch bg-red-400" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <p className="text-sm font-bold text-gray-800">{r.drug}</p>
                      <p className="text-xs text-gray-400">{r.drugClass}</p>
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700 shrink-0">− Remove</span>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed mt-1.5">{r.reason}</p>
                </div>
                <button className="self-start text-xs font-semibold text-brand-navy flex items-center gap-1 hover:underline shrink-0 mt-0.5">
                  Review <ArrowRight size={11} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

        </div>
      ) : null}

      {/* ── Cell Edit Modal ── */}
      {confirmModal && (() => {
        const existingOverride = cellOverrides[confirmModal.cellKey];
        const hasOverride = existingOverride !== undefined;
        const setLocalCovered = (v) => setConfirmModal(m => ({ ...m, localCovered: v }));
        const setLocalNote = (v) => setConfirmModal(m => ({ ...m, localNote: v }));
        return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}
            onClick={() => !confirmModal.saving && setConfirmModal(null)}>
            <div className="bg-white rounded-xl shadow-xl mx-4 p-4" style={{ width: 280 }} onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-bold text-gray-900 text-xs">{confirmModal.row.drug}</p>
                </div>
                <button onClick={() => setConfirmModal(null)} className="text-gray-400 hover:text-gray-600 ml-2 shrink-0"><X size={14}/></button>
              </div>
              <div className="flex gap-2 mb-3">
                <button onClick={() => setLocalCovered(true)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${
                    confirmModal.localCovered ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-gray-200 bg-white text-gray-400'
                  }`}>
                  <CheckCircle size={12}/> Covered
                </button>
                <button onClick={() => setLocalCovered(false)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${
                    !confirmModal.localCovered ? 'border-red-400 bg-red-50 text-red-600' : 'border-gray-200 bg-white text-gray-400'
                  }`}>
                  <X size={12}/> Not Covered
                </button>
              </div>
              {/* Note → sent as `comments` with this cell's update (a note-only save keeps the same Y/N) */}
              <input
                className="input text-xs py-1.5 w-full mb-3"
                placeholder="Add a note (optional)…"
                maxLength={500}
                value={confirmModal.localNote}
                onChange={e => setLocalNote(e.target.value)}
                disabled={confirmModal.saving}
              />
              <div className="flex gap-1.5">
                <button onClick={() => setConfirmModal(null)} disabled={confirmModal.saving}
                  className="flex-1 py-1.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-500 hover:bg-gray-50">
                  Cancel
                </button>
                {hasOverride && (
                  <button onClick={() => saveCellEdit({ revert: true })} disabled={confirmModal.saving}
                    className="px-2.5 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-xs font-semibold text-amber-700 hover:bg-amber-100 flex items-center gap-1">
                    <RefreshCw size={10}/> Revert
                  </button>
                )}
                <button onClick={() => saveCellEdit()} disabled={confirmModal.saving}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold text-white ${confirmModal.saving ? 'opacity-60 cursor-wait' : ''}`}
                  style={{ backgroundColor: '#1A3673' }}>
                  {confirmModal.saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Fixed-position tooltip portal — renders above all scroll/sticky containers */}
      <HoverTooltip ref={tooltipRef} />
    </div>
  );
}

/** Cell hover tooltip with its own state: show/hide re-renders only this component, not the grid. */
const HoverTooltip = forwardRef(function HoverTooltip(_props, ref) {
  const [tooltip, setTooltip] = useState(null); // { x, y, content }
  useImperativeHandle(ref, () => ({ show: setTooltip, hide: () => setTooltip(null) }), []);
  if (!tooltip) return null;
  return (
    <div
      className="pointer-events-none"
      style={{
        position: 'fixed',
        left: tooltip.x,
        top: tooltip.y - 8,
        transform: 'translate(-50%, -100%)',
        zIndex: 99999,
      }}
    >
      {tooltip.content}
      <div className="w-2 h-2 bg-gray-900 rotate-45 mx-auto -mt-1" />
    </div>
  );
});
