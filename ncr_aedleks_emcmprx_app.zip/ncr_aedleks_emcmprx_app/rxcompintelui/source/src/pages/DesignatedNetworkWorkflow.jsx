import { useState, useMemo, useRef, useEffect, useLayoutEffect, useCallback, useDeferredValue } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { DnGridRow, DnCellTooltip } from '../components/DnGrid';
import { useDesignatedRx } from '../context/DesignatedRxContext';
import { computeOverlap, fetchJobRunStatus, saveEdits, buildCellUpdate, updateJobRunStatus, programStatusPortfolio, resultTypeLabel, payorName, CARELON_KEY } from '../services/designatedRx';
import { useApp, useCan, NO_PERMISSION_MSG } from '../context/AppContext';
import { uploadRxDrugFile, DRUG_LIST_EXTENSIONS } from '../services/rxDrugs';
import { saveDownload } from '../services/client';
import { userError, toUserMessage } from '../services/errors';
import { useErrorToast } from '../hooks/useErrorToast';
import { Search, Download, ChevronUp, ChevronDown, CheckCircle, MinusCircle, AlertTriangle, XCircle, Info, Zap, BarChart2, Upload, FileText, X, FileSpreadsheet, TrendingUp, TrendingDown, Clock, RefreshCw, ArrowRight, Target, Lightbulb, ShieldAlert, Activity, Check, Filter } from 'lucide-react';
import AuditTrail from '../components/AuditTrail';
import { useAuditTrail } from '../config/useAuditTrail';

const EMPTY = [];
const COLLATOR = new Intl.Collator(); // same ordering as localeCompare, reused for fast sorting
const GRID_ROW_HEIGHT = 45; // estimated grid row height (px) for virtualisation; real heights are measured
const EMPTY_OBJ = {};
const PREFERRED_COMPS = ['UHC', 'OSCR_HLTH', 'HORIZON', 'BCBS_IL', 'BCBS_TX'];
const AI_TOP_N = 5; // AI Recommendations: show the top 5
const STATUS_POLL_MS = 5000; // status re-check interval while In Progress
const STATUS_MAX_POLLS = 120;  // ≈10 minutes
const LOCKED_EDIT_MSG = 'Editing is not allowed while the snapshot is Approved. Click "Revoke" to move it back to In Review before making changes.';
// User-facing messages for failures that aren't API errors
const SNAPSHOT_LOADING_MSG = 'The snapshot is still loading. Please wait a moment and try again.';
const STILL_PROCESSING_MSG = 'This snapshot is still being processed. Please check back in a few minutes or reload the page.';
const JOB_FAILED_MSG = 'Processing failed for this snapshot. Please upload the drug list again, or contact support if it keeps happening.';
const UNKNOWN_STATUS_MSG = "We couldn't determine the status of this snapshot. Please reload the page.";
const DATA_LOAD_ACTION = 'load the Designated Network data';

// Splits payor keys into the default competitors (in PREFERRED_COMPS order) and the rest (API order).
// Exact match first, then prefix match either way (e.g. HORIZON ↔ HORIZON_NJH, OSCR_HLTH ↔ OSCR_HLT).
function splitPreferredComps(keys) {
  const rest = [...keys];
  const preferred = [];
  for (const p of PREFERRED_COMPS) {
    const P = p.toUpperCase();
    let i = rest.findIndex(k => k.toUpperCase() === P);
    if (i < 0) i = rest.findIndex(k => {
      const K = k.toUpperCase();
      return Math.min(K.length, P.length) >= 3 && (K.startsWith(P) || P.startsWith(K));
    });
    if (i >= 0) preferred.push(...rest.splice(i, 1));
  }
  return { preferred, rest };
}


function SortIcon({ col, sortCol, sortDir }) {
  if (sortCol !== col) return <ChevronUp size={12} className="text-gray-300 ml-1" />;
  return sortDir === 'asc' ? <ChevronUp size={12} className="text-brand-navy ml-1" /> : <ChevronDown size={12} className="text-brand-navy ml-1" />;
}

export default function DesignatedNetworkWorkflow() {
  const dn = useDesignatedRx();
  const { loadJobRuns } = dn;
  useEffect(() => { loadJobRuns(); }, [loadJobRuns]);
  const TABLE_DRUGS = dn.snapshot?.drugs ?? EMPTY;
  const TABLE_COMP_KEYS = dn.snapshot?.compKeys ?? EMPTY;
  const COMP_OVERLAP_API = dn.snapshot?.compOverlap ?? EMPTY_OBJ;
  const PAYOR_URLS = dn.snapshot?.payorUrls ?? EMPTY_OBJ; // { BCBS_MT: 'https://…' } — used only for the Excel export header links
  const CARELON_URL = dn.snapshot?.carelonUrl ?? null;    // Carelon column header link (response's top-level `carelon.url`)
  const compName = (code) => payorName(dn.snapshot, code); // payor code → payor_nm (e.g. AHA → AmeriHealth Administrators)
  // const PORTFOLIO_API = dn.snapshot?.portfolio ?? EMPTY_OBJ;
  const AI_RECS = dn.snapshot?.aiRecs ?? EMPTY;
  const { preferred: DEFAULT_COMPS, rest: OTHER_COMPS } = useMemo(() => splitPreferredComps(TABLE_COMP_KEYS), [TABLE_COMP_KEYS]);
  const ORDERED_COMP_KEYS = useMemo(() => [...DEFAULT_COMPS, ...OTHER_COMPS], [DEFAULT_COMPS, OTHER_COMPS]);
  const OVERLAP_COMPS = useMemo(
    () => [...ORDERED_COMP_KEYS, ...Object.keys(COMP_OVERLAP_API).filter(c => !ORDERED_COMP_KEYS.includes(c))],
    [ORDERED_COMP_KEYS, COMP_OVERLAP_API]);
  const dataStatus = dn.jobRunsStatus === 'error' ? 'error'
    : dn.jobRunsStatus === 'ready' && dn.jobRuns.length === 0 ? 'empty'
      : dn.snapshotStatus === 'error' ? 'error'
        : dn.snapshotStatus === 'ready' ? 'ready'
          : 'loading';
  const dataError = dn.jobRunsError || dn.snapshotError;
  // e.g. "Oct 13, 2026 · ALL" (scheduled runs show their result type; adhoc runs have none)
  const runLabel = [dn.selectedRun?.label ?? '', resultTypeLabel(dn.selectedResultType)].filter(Boolean).join(' · ');
  const [search, setSearch] = useState('');
  const [tableSearch, setTableSearch] = useState('');
  const [view, setView] = useState('drug');
  const [recFilter, setRecFilter] = useState('all');
  const [sortCol, setSortCol] = useState('drug');
  const [sortDir, setSortDir] = useState('asc');
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadSource, setUploadSource] = useState('carelon');
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(true);
  const [exportOpen, setExportOpen] = useState(false);
  const [reportStatus, setReportStatus] = useState('in-progress'); // 'in-progress' | 'in-review' | 'approved'
  const isLocked = reportStatus === 'approved';
  // Role-based access (login user_roles): normal users can only view and export
  const allowed = useCan();
  const canGenerate = allowed('generate'), canUpload = allowed('upload'), canApprove = allowed('approve'), canEdit = allowed('edit');
  const noPermission = (ok) => (ok ? undefined : NO_PERMISSION_MSG); // button tooltip when the action isn't allowed
  const [overlapComp, setOverlapComp] = useState('UHC');
  const [overlapSearch, setOverlapSearch] = useState('');
  const [coverageOpen, setCoverageOpen] = useState(true);
  const [overlapDropOpen, setOverlapDropOpen] = useState(false);
  const [portfolioExpanded, setPortfolioExpanded] = useState(null);
  const [cellOverrides, setCellOverrides] = useState({});
  // Cells edited since the snapshot loaded: cellKey → { loadedOverride, loadedCovered } (drives Revert)
  const [sessionEdits, setSessionEdits] = useState(() => new Map());
  const [cellNote, setCellNote] = useState(null);
  const [confirmModal, setConfirmModal] = useState(null); // { cellKey, row, comp, action: 'add'|'remove' }
  const tooltipRef = useRef(null); // DnCellTooltip handle: show({ x, y, row, comp, manual }) / hide()
  // const TOP_COMPS = useMemo(
  //   () => [...TABLE_COMP_KEYS]
  //     .map((c, i) => ({ c, i, n: TABLE_DRUGS.filter(d => d[c] === 'Y').length }))
  //     .sort((a, b) => b.n - a.n || a.i - b.i)
  //     .slice(0, 5)
  //     .map(x => x.c),
  //   [TABLE_COMP_KEYS, TABLE_DRUGS]);
  const TOP_COMPS = useMemo(() => {
    const byCoverage = OTHER_COMPS
      .map((c, i) => ({ c, i, n: TABLE_DRUGS.filter(d => d[c] === 'Y').length }))
      .sort((a, b) => b.n - a.n || a.i - b.i)
      .map(x => x.c);
    return [...DEFAULT_COMPS, ...byCoverage].slice(0, 5);
  }, [DEFAULT_COMPS, OTHER_COMPS, TABLE_DRUGS]);
  const [selectedComps, setSelectedComps] = useState(() => new Set(TOP_COMPS));
  const [gapFilter, setGapFilter] = useState('all');
  // const [selectedComps, setSelectedComps] = useState(new Set(TABLE_COMP_KEYS));
  const compPickerRef = useRef(null);
  const [compDropOpen, setCompDropOpen] = useState(false);
  // Defaults always lead in PREFERRED_COMPS order; any other selected competitor is appended in the order it was picked
  const visibleComps = useMemo(() => [
    ...DEFAULT_COMPS.filter(c => selectedComps.has(c)),
    ...[...selectedComps].filter(c => OTHER_COMPS.includes(c)),
  ], [DEFAULT_COMPS, OTHER_COMPS, selectedComps]);
  const toggleComp = (c) => setSelectedComps(prev => {
    const next = new Set(prev);
    if (next.has(c)) { if (next.size > 1) next.delete(c); }
    else next.add(c);
    return next;
  });
  const { entries: auditEntries, addEntry: auditAdd, clearAll: auditClear } = useAuditTrail('designated-network');


  // Keep competitor selections valid when a different snapshot loads
  // useEffect(() => {
  //   setSelectedComps(prev => {
  //     const kept = TABLE_COMP_KEYS.filter(c => prev.has(c));
  //     return new Set(kept.length ? kept : TABLE_COMP_KEYS);
  //   });
  // }, [TABLE_COMP_KEYS]);

  const compsRunRef = useRef(null);
  useEffect(() => {
    if (dn.snapshotStatus !== 'ready') return; // wait for the selected snapshot's own data
    const runChanged = compsRunRef.current !== dn.selectedJobRunId;
    compsRunRef.current = dn.selectedJobRunId;
    setSelectedComps(prev => {
      const kept = [...prev].filter(c => TABLE_COMP_KEYS.includes(c));
      return new Set(!runChanged && kept.length ? kept : TOP_COMPS);
    });
  }, [TABLE_COMP_KEYS, TOP_COMPS, dn.selectedJobRunId, dn.snapshotStatus]);

  useEffect(() => {
    setOverlapComp(prev => (OVERLAP_COMPS.includes(prev) ? prev : OVERLAP_COMPS.includes('UHC') ? 'UHC' : OVERLAP_COMPS[0] ?? ''));
  }, [OVERLAP_COMPS]);
  const statusFromApiRef = useRef(false);
  useEffect(() => { statusFromApiRef.current = false; }, [dn.selectedJobRunId]);
  useEffect(() => {
    if (!statusFromApiRef.current && dn.snapshot?.reportStatus) setReportStatus(dn.snapshot.reportStatus);
  }, [dn.snapshot]);

  // Reset manual-override markers whenever a different snapshot file (run or result type) is loaded
  useEffect(() => {
    setCellOverrides(dn.snapshot?.manualOverrides ?? {});
    setSessionEdits(new Map());
    setConfirmModal(null);
    tooltipRef.current?.hide();
  }, [dn.snapshotKey]); 
  const overlapRef = useRef(null);
  const fileInputRef = useRef(null);
  const exportRef = useRef(null);
  const [exporting, setExporting] = useState(null); // format being exported, or null

  useEffect(() => {
    function handleClickOutside(e) {
      if (overlapRef.current && !overlapRef.current.contains(e.target)) setOverlapDropOpen(false);
      if (exportRef.current && !exportRef.current.contains(e.target)) setExportOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // ── Cell edits → PUT /designated-rx/{job_run_id}/edits ──
  const { currentUser } = useApp();
  async function saveCellEdit({ revert = false } = {}) {
    const m = confirmModal;
    const jobRunId = dn.selectedJobRunId;
    if (!m || !jobRunId || m.saving || isLocked || !canEdit) return;
    // const originalCovered = m.row[m.comp] === 'Y';
    // const currentCovered = cellOverrides[m.cellKey]?.covered ?? originalCovered; // what the cell shows now
    const existing = cellOverrides[m.cellKey];
    const currentCovered  = existing?.covered ?? (m.row[m.comp] === 'Y'); // what the cell shows now
    // Revert only undoes this session's edit: back to the value the cell had when the page loaded
    const sessionEdit = sessionEdits.get(m.cellKey);
    const originalCovered = sessionEdit ? sessionEdit.loadedCovered : currentCovered;
    const covered = revert ? originalCovered : m.localCovered;
    const note = revert ? '' : m.localNote;
    const user = currentUser?.id || currentUser?.name || '';
    const moved = currentCovered !== covered;
    // A note added/changed on its own is saved; a cell with neither a new value nor a new note is not sent
    const noteChanged = !revert && note.trim() !== '' && note.trim() !== (existing?.note ?? '').trim();
    if (!moved && !noteChanged && !revert) {
      setConfirmModal(null);
      addToast(`${m.row.drug} · ${m.compLabel || m.comp}: no change — nothing was saved.`, 'warning', { position: 'top' });
      return;
    }
    setConfirmModal(prev => prev && { ...prev, saving: true });
    try {
      await saveEdits(jobRunId, {
        updatedBy: user,
        reportStatus,
        runType: dn.selectedRun?.runType,
        resultType: dn.selectedResultType,
        label: dn.selectedRun?.label,
        updates: [buildCellUpdate({ row: m.row, comp: m.comp, oldCovered: currentCovered, newCovered: covered, note, user })],
        // Bucket arrays are sent empty for now
        inCarelonAdd: [], inCarelonRemove: [], notInCarelonAdd: [], notInCarelonRemove: [],
      });
      // Saved per brand (update carries brand_nm) → only the edited row changes
      const keys = [m.cellKey];
      // First edit of a cell this session: remember how it looked on load so Revert can restore exactly that
      const nextSession = new Map(sessionEdits);
      for (const k of keys) {
        if (!revert && !nextSession.has(k)) nextSession.set(k, { loadedOverride: cellOverrides[k], loadedCovered: currentCovered });
      }
      setCellOverrides(prev => {
        const next = { ...prev };
        for (const k of keys) {
          if (revert) {
            const loaded = nextSession.get(k)?.loadedOverride;
            if (loaded) next[k] = loaded; else delete next[k];
          } else {
            next[k] = { covered, note, original: originalCovered };
          }
        }
        return next;
      });
      if (revert) for (const k of keys) nextSession.delete(k);
      setSessionEdits(nextSession);
      setConfirmModal(null);
      // Do NOT silent-reload here — the local cellOverrides state is already
      // correct, and a reload would race with the S3 write and may revert the
      // edit if the server hasn't persisted yet.
      addToast(`${m.row.drug} · ${m.compLabel || m.comp}: ${revert ? 'reverted' : !moved ? 'note saved' : covered ? 'marked covered' : 'marked not covered'}`, 'success', { position: 'top' });
    } catch (err) {
      // Keep the dialog open so the user can retry
      setConfirmModal(prev => prev && { ...prev, saving: false });
      notifyError(err, 'save your change');
    }
  }

  async function handleExport(format) {
    setExportOpen(false);
    if (format === 'pdf') return; // not available yet
    const jobRunId = dn.selectedJobRunId;
    if (!jobRunId || exporting) return;
    setExporting(format);
    try {
      let filename;
      if (format === 'pptx') {
        if (!dn.snapshot) throw userError(SNAPSHOT_LOADING_MSG);
        const { buildDesignatedNetworkPpt } = await import('../export/dnPptExport');
        const blob = await buildDesignatedNetworkPpt(dn.snapshot, {
          userName: currentUser?.name || currentUser?.id || '',
          date: new Date(),
          competitors: OVERLAP_COMPS,
          table: {
            columns: visibleComps,
            rows: tableRows.map(r => ({
              drug: r.drug, drugClass: r.drugClass, hcpcs: r.hcpcs, programType: r.programType, carelon: r.carelon,
              cells: Object.fromEntries(visibleComps.map(c => {
                const ov = cellOverrides[`${r.drug}|${r.hcpcs}|${c}`];
                return [c, { covered: ov ? ov.covered : r[c] === 'Y', manual: !!ov || !!r.edited?.[c] }];
              })),
            })),
            totalRows: TABLE_DRUGS.length,
            totalColumns: TABLE_COMP_KEYS.length,
            search: tableSearch.trim(),
            snapshotLabel: `${dn.isCurrent ? 'Current' : 'Snapshot'} · ${runLabel}`,
          },
        });
        filename = `Designated_Network_${runLabel.replace(/[^A-Za-z0-9]+/g, '_') || jobRunId}.pptx`;
        saveDownload({ blob, filename });
      } else {
        if (!dn.snapshot) throw userError(SNAPSHOT_LOADING_MSG);
        const { buildDesignatedNetworkXlsx } = await import('../export/dnExcelExport');
        const blob = await buildDesignatedNetworkXlsx({
          columns: visibleComps,
          payorUrls: PAYOR_URLS,
          payorNames: dn.snapshot?.payorNames,
          rows: tableRows.map(r => ({
            drug: r.drug, drugClass: r.drugClass, hcpcs: r.hcpcs, carelon: r.carelon,
            cells: Object.fromEntries(visibleComps.map(c => {
              const ov = cellOverrides[`${r.drug}|${r.hcpcs}|${c}`];
              return [c, { covered: ov ? ov.covered : r[c] === 'Y', manual: !!ov || !!r.edited?.[c] }];
            })),
          })),
        });
        filename = `Designated_Network_${runLabel.replace(/[^A-Za-z0-9]+/g, '_') || jobRunId}.xlsx`;
        saveDownload({ blob, filename });
      }
      addToast(`Export downloaded: ${filename}`, 'success', { position: 'top' });
    } catch (err) {
      console.error('[export]', err);
      notifyError(err, `create the ${format === 'pptx' ? 'PowerPoint' : 'Excel'} export`);
    } finally {
      setExporting(null);
    }
  }

  const [uploading, setUploading] = useState(false);
  const uploadAbortRef = useRef(null);
  useEffect(() => () => uploadAbortRef.current?.abort(), []);

  async function handleFileUpload(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !canUpload) return;
    uploadAbortRef.current?.abort();
    const controller = new AbortController();
    uploadAbortRef.current = controller;
    setUploading(true);
    try {
      const res = await uploadRxDrugFile(file, { signal: controller.signal });
      addToast(res.message || `${file.name} uploaded successfully.`, 'success', { position: 'top' });
      // The backend writes an Inprogress marker to S3 before kicking off the
      // background task, so the status poller will now see "Inprogress" and
      // automatically reload the snapshot when the job completes.
      const uploadedJobRunId = res.body?.job_run_id ?? null;
      if (uploadedJobRunId) {
        if (uploadedJobRunId !== dn.selectedJobRunId) {
          // New day — switch to the new adhoc snapshot and refresh the jobs list
          dn.loadJobRuns({ force: true });
          dn.selectJobRun(uploadedJobRunId, `${uploadedJobRunId}|adhoc`);
        } else {
          // Same snapshot — restart status polling so it picks up Inprogress.
          // Pass fromUpload=true so that even if the S3 marker write failed and
          // the first poll returns "completed" immediately, we still reload the
          // snapshot once to pick up the new result when it lands.
          checkStatus(uploadedJobRunId, { fromUpload: true, runType: 'adhoc' });
        }
      }
    } catch (err) {
      if (err.name === 'AbortError') return;
      notifyError(err, 'upload the drug list');
    } finally {
      if (uploadAbortRef.current === controller) {
        uploadAbortRef.current = null;
        setUploading(false);
      }
    }
  }

  const { addToast } = useApp();
  const notifyLocked = () => addToast(LOCKED_EDIT_MSG, 'warning', { position: 'top', duration: 5000 });
  // Every failure is shown as a toast in plain language (never the raw API error); action completes "We couldn't …"
  const notifyError = useErrorToast();
  // Snapshot list / snapshot failed to load → toast (the page also keeps its Retry card)
  useEffect(() => {
    if (dataError) notifyError(dataError, DATA_LOAD_ACTION);
  }, [dataError, notifyError]);

  // ── Grid performance: per-row override slices + stable cell callbacks so memoised rows skip re-rendering ──
  // cellOverrides { "drug|hcpcs|comp": override } → { "drug|hcpcs": { comp: override } }; untouched rows keep `undefined`
  const overridesByRow = useMemo(() => {
    const out = {};
    for (const [key, ov] of Object.entries(cellOverrides)) {
      const cut = key.lastIndexOf('|');
      const rowKey = key.slice(0, cut);
      (out[rowKey] = out[rowKey] || {})[key.slice(cut + 1)] = ov;
    }
    return out;
  }, [cellOverrides]);

  // Latest-value ref: the callbacks below never change identity but always see current state
  const cellActionsRef = useRef(null);
  useLayoutEffect(() => {
    cellActionsRef.current = {
      click(row, c, isChecked) {
        if (!canEdit) { addToast(NO_PERMISSION_MSG, 'warning', { position: 'top', duration: 5000 }); return; }
        if (isLocked) { notifyLocked(); return; }
        const cellKey = `${row.drug}|${row.hcpcs}|${c}`;
        setConfirmModal({
          cellKey, row, comp: c, compKey: c, compLabel: compName(c),
          localCovered: isChecked,
          localNote: cellOverrides[cellKey]?.note ?? row.notes?.[c] ?? '',
        });
      },
    };
  });
  const handleCellClick = useCallback((row, c, isChecked) => cellActionsRef.current.click(row, c, isChecked), []);
  const handleCellEnter = useCallback((e, row, comp, manual) => {
    const rect = e.currentTarget.getBoundingClientRect();
    tooltipRef.current?.show({ x: rect.left + rect.width / 2, y: rect.top, row, comp, manual });
  }, []);
  const handleCellLeave = useCallback(() => tooltipRef.current?.hide(), []);
  const statusPollRef = useRef(null);
  const [apiStatus, setApiStatus] = useState(null);
  const [approving, setApproving] = useState(false);

  async function handleApprove() {
    const jobRunId = dn.selectedJobRunId;
    if (!jobRunId || approving || !canApprove) return;
    setApproving(true);
    try {
      const res = await updateJobRunStatus(jobRunId, {
        snapshotStatus: 'Approved',
        updatedBy: currentUser?.id || currentUser?.name || '',
        runType: dn.selectedRun?.runType,
        resultType: dn.selectedResultType ?? dn.selectedRun?.availableFiles?.[0] ?? null,
      });
      const status = res?.status || res?.snapshot_status || 'Approved';
      statusFromApiRef.current = true;
      setApiStatus({ status, message: res?.message || '', stage: 'approved' });
      setReportStatus('approved');
      addToast(res?.message || 'Snapshot approved.', 'success', { position: 'top' });
    } catch (err) {
      notifyError(err, 'approve this snapshot');
    } finally {
      setApproving(false);
    }
  }

  // Revoke → PUT /designated-rx/{job_run_id}/status { snapshot_status: "In Review" }
  async function handleRevoke() {
    const jobRunId = dn.selectedJobRunId;
    if (!jobRunId || approving || !canApprove) return;
    setApproving(true);
    try {
      const res = await updateJobRunStatus(jobRunId, {
        snapshotStatus: 'In Review',
        updatedBy: currentUser?.id || currentUser?.name || '',
        runType: dn.selectedRun?.runType,
        resultType: dn.selectedResultType ?? dn.selectedRun?.availableFiles?.[0] ?? null,
      });
      const status = res?.status || res?.snapshot_status || 'In Review';
      statusFromApiRef.current = true;
      setApiStatus({ status, message: res?.message || '', stage: 'in-review' });
      setReportStatus('in-review');
      addToast(res?.message || 'Approval revoked. The snapshot is back In Review.', 'success', { position: 'top' });
    } catch (err) {
      notifyError(err, 'revoke the approval');
    } finally {
      setApproving(false);
    }
  }

  function stopStatusPolling() {
    const poll = statusPollRef.current;
    if (poll) { poll.controller.abort(); clearTimeout(poll.timer); }
    statusPollRef.current = null;
  }

  function checkStatus(jobRunId, { fromUpload = false, runType, resultType } = {}) {
    stopStatusPolling();
    const controller = new AbortController();
    statusPollRef.current = { controller, timer: null };
    setApiStatus(null);

    let polls = 0;
    let wasInProgress = false;
    const check = async () => {
      polls += 1;
      try {
        const res = await fetchJobRunStatus(jobRunId, { runType, resultType, label: dn.selectedRun?.label, signal: controller.signal });
        if (controller.signal.aborted) return;
        // Polls every few seconds while in progress — keep the same object when nothing changed so the page doesn't re-render
        setApiStatus(prev => (prev && prev.status === res.status && prev.stage === res.stage && prev.message === res.message ? prev : res));

        if (res.stage === 'in-progress') {
          wasInProgress = true;
          statusFromApiRef.current = true;
          setReportStatus('in-progress');
          setGenerating(true);
          if (polls < STATUS_MAX_POLLS) {
            statusPollRef.current.timer = setTimeout(check, STATUS_POLL_MS);
            return;
          }
          statusPollRef.current = null;
          setGenerating(false);
          addToast(STILL_PROCESSING_MSG, 'warning', { position: 'top', duration: 6000 });
          return;
        }

        statusPollRef.current = null;
        setGenerating(false);
        if (res.stage === 'failed') {
          console.warn('[status] job failed:', res.status, res.message);
          addToast(JOB_FAILED_MSG, 'error', { position: 'top', duration: 8000 });
        } else if (res.stage) {
          statusFromApiRef.current = true;
          setReportStatus(res.stage);
          if (wasInProgress) {
            // The job finished while the page was open: tell the user and pick up the new data
            if (res.message) addToast(res.message, 'success');
            dn.reloadSnapshot({ silent: true });
          } else if (fromUpload) {
            // fromUpload=true but never saw in-progress: the S3 Inprogress marker
            // write likely failed (non-fatal backend warning). Do a one-time silent
            // reload after a delay so the new result is picked up when it lands.
            setTimeout(() => dn.reloadSnapshot({ silent: true }), 35_000);
          }
        } else {
          console.warn('[status] unrecognised status:', res.status, res.message);
          addToast(UNKNOWN_STATUS_MSG, 'warning', { position: 'top', duration: 6000 });
        }
      } catch (e) {
        if (e.name === 'AbortError') return;
        statusPollRef.current = null;
        setGenerating(false);
        notifyError(e, 'check the snapshot status');
      }
    };
    check();
  }

  // On page load and whenever the selected snapshot (or its result type) changes
  useEffect(() => {
    setGenerating(false);
    setApiStatus(null);
    const runType = dn.selectedRun?.runType;
    // Scheduled run without a result file yet: skip (the data card already explains it)
    if (runType === 'scheduled' && !dn.selectedResultType) return undefined;
    if (dn.selectedJobRunId) checkStatus(dn.selectedJobRunId, { runType, resultType: dn.selectedResultType });
    return stopStatusPolling;
  }, [dn.selectedJobRunId, dn.selectedRun?.runType, dn.selectedResultType]);

  // Generate Intelligence no longer calls the status API (status loads with the page)
  function handleGenerate() { }

  function toggleSort(col) {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  }

  // TABLE_DRUGS with cellOverrides merged in — used for coverage analysis so
  // manual edits are reflected immediately without waiting for a snapshot reload.
  const effectiveDrugs = useMemo(() => TABLE_DRUGS.map(r => {
    const patches = {};
    for (const comp of TABLE_COMP_KEYS) {
      const ov = cellOverrides[`${r.drug}|${r.hcpcs}|${comp}`];
      if (ov !== undefined) patches[comp] = ov.covered ? 'Y' : 'N';
    }
    return Object.keys(patches).length ? { ...r, ...patches } : r;
  }), [TABLE_DRUGS, TABLE_COMP_KEYS, cellOverrides]);

  // Search is deferred: typing updates the input immediately, the grid re-filters in the background
  const deferredSearch = useDeferredValue(tableSearch);

  // Search + sort (Intl.Collator is much faster than calling localeCompare per comparison)
  const filtered = useMemo(() => {
    const q = deferredSearch.trim().toLowerCase();
    const rows = q
      ? TABLE_DRUGS.filter(r => r.drug.toLowerCase().includes(q) || r.drugClass.toLowerCase().includes(q))
      : TABLE_DRUGS.slice();
    const dir = sortDir === 'asc' ? 1 : -1;
    if (sortCol === 'programType') {
      const order = { Mandatory: 0, Voluntary: 1 };
      return rows.sort((a, b) => dir * ((order[a.programType] ?? 2) - (order[b.programType] ?? 2)));
    }
    return rows.sort((a, b) => dir * COLLATOR.compare(a[sortCol] || '', b[sortCol] || ''));
  }, [TABLE_DRUGS, deferredSearch, sortCol, sortDir]);

  // Counts for the All / Not in Carelon / Carelon filter buttons (one pass, memoised)
  const gapCounts = useMemo(() => {
    let inCarelon = 0;
    for (const r of filtered) if (r.carelon === 'Y') inCarelon += 1;
    return { all: filtered.length, gap: filtered.length - inCarelon, nogap: inCarelon };
  }, [filtered]);

  // Exactly the rows the Priority Intelligence table renders (also used by the PPT export)
  const tableRows = useMemo(() => (gapFilter === 'all' ? filtered
    : filtered.filter(r => (gapFilter === 'gap' ? r.carelon !== 'Y' : r.carelon === 'Y'))), [filtered, gapFilter]);

  // Row virtualisation: only rows inside the 520px scroll area (+ overscan) are in the DOM.
  // Search, filters, counts and exports still use the full tableRows.
  const gridScrollRef = useRef(null);
  const rowVirtualizer = useVirtualizer({
    count: tableRows.length,
    getScrollElement: () => gridScrollRef.current,
    estimateSize: () => GRID_ROW_HEIGHT,
    overscan: 15,
  });
  const virtualItems = rowVirtualizer.getVirtualItems();
  const virtualTop = virtualItems.length ? virtualItems[0].start : 0;
  const virtualBottom = virtualItems.length ? rowVirtualizer.getTotalSize() - virtualItems[virtualItems.length - 1].end : 0;
  // Jump back to the top when the row set changes (filter / search / sort / snapshot)
  useEffect(() => { gridScrollRef.current?.scrollTo({ top: 0 }); }, [tableRows]);

  // Coverage Difference Analysis numbers — memoised (was recomputed on every render).
  // Recompute from effectiveDrugs when there are local edits; otherwise use the API's comp_overlap.
  // Chip name lists are de-duplicated: one brand can sit under several HCPCS codes (e.g. PRIVIGEN).
  const coverageOv = useMemo(() => {
    const hasOverrides = Object.keys(cellOverrides).length > 0;
    const ov = (!hasOverrides && COMP_OVERLAP_API[overlapComp]) || (() => {
      const d = computeOverlap(effectiveDrugs, overlapComp);
      return { ...d, compTotal: d.common + d.compOnly };
    })();
    const uniq = list => [...new Set(list || [])];
    return { ...ov, commonDrugs: uniq(ov.commonDrugs), carOnlyDrugs: uniq(ov.carOnlyDrugs), compOnlyDrugs: uniq(ov.compOnlyDrugs) };
  }, [cellOverrides, COMP_OVERLAP_API, overlapComp, effectiveDrugs]);


  const kpis = [
    { label: 'Carelon DN Drugs', value: 106, color: 'text-brand-navy', bg: 'bg-brand-light', sub: 'Full drug list' },
    { label: 'UHC DN Drugs', value: 140, color: 'text-blue-700', bg: 'bg-blue-50', sub: 'Competitor list' },
    { label: 'Common (Both)', value: 31, color: 'text-emerald-700', bg: 'bg-emerald-50', sub: 'Overlap' },
    { label: 'Carelon Only', value: TABLE_DRUGS.filter(d => d.status === 'missing').length, color: 'text-amber-700', bg: 'bg-amber-50', sub: 'Sample shown' },
    { label: 'Competitor Only', value: 109, color: 'text-red-700', bg: 'bg-red-50', sub: 'UHC-only drugs' },
  ];


  return (
    <div className="space-y-5">

      {/* ── Page Header ── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Designated Network</p>
          <h1 className="text-2xl font-bold text-brand-navy">Competitor Drug Comparison</h1>
          <p className="text-xs text-gray-400 mt-1">Compare Carelon's white bagging drug list against competitor DN programs · Identify gaps and opportunities</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative" ref={exportRef}>
            <button
              onClick={() => reportStatus === 'approved' && setExportOpen(o => !o)}
              disabled={reportStatus !== 'approved'}
              title={reportStatus !== 'approved' ? 'Approve the report to enable export' : 'Export report'}
              className={`btn-secondary flex items-center gap-2 text-xs transition-all ${reportStatus !== 'approved' ? 'opacity-40 cursor-not-allowed' : ''}`}>
              {exporting
                ? <div className="w-3.5 h-3.5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
                : <Download size={14} />} {exporting ? 'Exporting…' : 'Export'} <ChevronDown size={12} className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`} />
            </button>
            {exportOpen && (
              <div className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
                {[
                  { label: 'PowerPoint (.pptx)', format: 'pptx', icon: <FileText size={13} className="text-orange-500" /> },
                  { label: 'Excel (.xlsx)', format: 'xlsx', icon: <FileSpreadsheet size={13} className="text-emerald-600" /> },
                ].map(opt => (
                  <button key={opt.label} onClick={() => handleExport(opt.format)}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                    {opt.icon} {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>
          <AuditTrail pageId="designated-network" entries={auditEntries} onClear={auditClear} />
        </div>
      </div>


      {/* ── Action Bar ── */}
      <div className="card py-3 px-4">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleGenerate}
            disabled={generating || !canGenerate} title={noPermission(canGenerate)}
            className={`btn-primary flex items-center gap-2 px-5 py-2 text-sm font-semibold ${generating || !canGenerate ? 'opacity-50 cursor-not-allowed' : ''}`}>
            <Zap size={15} /> {generating ? 'Generating...' : 'Generate Intelligence'}
          </button>
          <div className="h-6 w-px bg-gray-200" />
          <input ref={fileInputRef} type="file" accept={DRUG_LIST_EXTENSIONS.join(',')} className="hidden" onChange={handleFileUpload} />
          <button onClick={() => fileInputRef.current?.click()} disabled={uploading || !canUpload} title={noPermission(canUpload)}
            className={`btn-secondary flex items-center gap-1.5 text-xs ${uploading || !canUpload ? 'opacity-50 cursor-not-allowed' : ''}`}>
            {uploading
              ? <><div className="w-3 h-3 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" /> Uploading…</>
              : <><Upload size={13} /> Upload Drug List</>}
          </button>

          {/* ── Status pipeline ── */}
          <div className="h-6 w-px bg-gray-200" />
          <div className="flex items-center gap-1.5">
            {[
              { key: 'in-progress', label: 'In Progress', activeColor: '#D97706', activeBg: '#FEF3C7', activeBorder: '#FCD34D', dot: 'bg-amber-500' },
              { key: 'in-review', label: 'In Review', activeColor: '#1D4ED8', activeBg: '#EFF6FF', activeBorder: '#93C5FD', dot: 'bg-blue-500' },
              { key: 'approved', label: 'Approved', activeColor: '#059669', activeBg: '#ECFDF5', activeBorder: '#6EE7B7', dot: 'bg-emerald-500' },
            ].map((step, idx) => {
              const steps = ['in-progress', 'in-review', 'approved'];
              const currentIdx = steps.indexOf(reportStatus);
              const stepIdx = steps.indexOf(step.key);
              const isActive = reportStatus === step.key;
              const isDone = stepIdx < currentIdx;
              // Active step shows the status text returned by the status API (e.g. "Approved"),
              // except a finished job ("Completed") which is shown as the In Review step's own label
              const fromApi = isActive && apiStatus?.stage === step.key && apiStatus.status;
              const jobFinished = /(complete|success|done|finished)/i.test(String(apiStatus?.status ?? ''));
              const label = fromApi && !(step.key === 'in-review' && jobFinished) ? apiStatus.status : step.label;
              return (
                <div key={step.key} className="flex items-center gap-1.5">
                  {idx > 0 && <div className={`w-5 h-px ${isDone || isActive ? 'bg-gray-400' : 'bg-gray-200'}`} />}
                  <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${isActive
                      ? 'border-current'
                      : isDone ? 'bg-gray-50 text-gray-400 border-gray-200' : 'bg-white text-gray-300 border-gray-100'
                    }`} style={isActive ? { backgroundColor: step.activeBg, color: step.activeColor, borderColor: step.activeBorder } : {}}>
                    {isActive && step.key !== 'approved' && <span className={`w-1.5 h-1.5 rounded-full ${step.dot} ${step.key === 'in-progress' ? 'animate-pulse' : ''}`} />}
                    {(isActive && step.key === 'approved') || isDone ? <CheckCircle size={10} className={isDone ? 'text-gray-400' : 'text-emerald-500'} /> : null}
                    <span title={fromApi ? apiStatus.message : undefined}>{label}</span>
                  </span>
                </div>
              );
            })}
            {/* Approve button — only in-review */}
            {reportStatus === 'in-review' && (
              <button
                onClick={handleApprove}
                disabled={approving || !canApprove} title={noPermission(canApprove)}
                className={`ml-1 flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-600 text-white transition-colors ${approving || !canApprove ? 'opacity-50 cursor-not-allowed' : 'hover:bg-emerald-700'}`}
              >
                {approving
                  ? <><div className="w-2.5 h-2.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> Approving…</>
                  : <><CheckCircle size={11} /> Approve</>}
              </button>
            )}
            {reportStatus === 'approved' && (
              <button onClick={handleRevoke} disabled={approving || !canApprove} title={noPermission(canApprove)}
                className={`ml-1 text-[10px] text-gray-400 underline ${approving || !canApprove ? 'opacity-60 cursor-not-allowed' : 'hover:text-red-400'}`}>
                {approving ? 'Revoking…' : 'Revoke'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Generating spinner */}
      {generating && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
          <div className="flex-1">
            <p className="text-brand-navy text-sm font-semibold">Generating intelligence…</p>
            <div className="flex gap-4 mt-1.5 text-xs text-blue-600">
              {['Ingesting drug lists', 'Normalizing HCPCS codes', 'Matching overlap', 'Analyzing gaps'].map((s, i) => (
                <span key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay: `${i * 200}ms` }} />{s}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {generated && !generating && dataStatus === 'loading' && (
        <div className="card flex items-center gap-4 bg-blue-50 border border-blue-100">
          <div className="w-5 h-5 border-2 border-brand-navy border-t-transparent rounded-full animate-spin shrink-0" />
          <p className="text-brand-navy text-sm font-semibold">Loading snapshot data…</p>
        </div>
      )}
      {generated && !generating && dataStatus === 'error' && (
        <div className="card flex items-center gap-4 bg-red-50 border border-red-100">
          <AlertTriangle size={18} className="text-red-500 shrink-0" />
          <div className="flex-1">
            <p className="text-red-700 text-sm font-semibold">Couldn't load Designated Network data</p>
            <p className="text-xs text-red-500 mt-0.5">{toUserMessage(dataError, { action: DATA_LOAD_ACTION })}</p>
          </div>
          <button
            onClick={() => (dn.jobRunsStatus === 'error' ? dn.loadJobRuns({ force: true }) : dn.reloadSnapshot())}
            className="btn-secondary flex items-center gap-1.5 text-xs">
            <RefreshCw size={12} /> Retry
          </button>
        </div>
      )}
      {generated && !generating && dataStatus === 'empty' && (
        <div className="card py-10 text-center border-dashed border-2 border-gray-200">
          <p className="text-gray-500 text-sm font-semibold">No snapshots available yet.</p>
        </div>
      )}

      {!generated && !generating ? (
        <div className="card flex flex-col items-center justify-center py-14 gap-4 border-2 border-dashed border-gray-200 bg-gray-50">
          <div className="w-12 h-12 rounded-full bg-brand-light flex items-center justify-center">
            <Zap size={22} className="text-brand-navy" />
          </div>
          <div className="text-center">
            <p className="text-sm font-semibold text-gray-700">Ready to generate insights</p>
            <p className="text-xs text-gray-400 mt-1 max-w-xs">Select a market and competitor above, upload your drug list, then click <strong>Generate Intelligence</strong></p>
          </div>
          <div className="flex items-center gap-6 mt-2">
            {['Ingest', 'Extract', 'Normalize', 'Compare', 'Report'].map((step, i, arr) => (
              <div key={step} className="flex items-center gap-2">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-400">{i + 1}</div>
                  <span className="text-xs text-gray-400">{step}</span>
                </div>
                {i < arr.length - 1 && <ArrowRight size={12} className="text-gray-300 mb-3" />}
              </div>
            ))}
          </div>
        </div>
      ) : generated ? (
        <div className="space-y-6">

          {/* ══════════════════════════════════════════════
              SECTION 2 — Combined Priority Intelligence Table
          ══════════════════════════════════════════════ */}
          {dataStatus === 'ready' && (<>
            <div className="card p-0 overflow-hidden" style={{ border: '2px solid #E1EDFF' }}>
              {/* Table header */}
              <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-3 flex-wrap" style={{ backgroundColor: '#F8FAFF' }}>
                <div className="flex items-center gap-2">
                  <Target size={15} className="text-brand-navy shrink-0" />
                  <div>
                    <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold leading-none mb-0.5"></p>
                    <div className="flex items-center gap-2">
                      <h2 className="font-bold text-brand-navy" style={{ fontSize: 14 }}>Drug-Level Comparison</h2>
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{ backgroundColor: '#1A3673', color: '#fff', letterSpacing: '0.04em' }}>
                        ● {dn.isCurrent ? 'Current' : 'Snapshot'} · {runLabel}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="ml-auto flex items-center gap-2">
                    {/* Carelon gap filter */}
                <div className="flex items-center rounded-lg border border-gray-200 bg-white overflow-hidden text-xs font-semibold">
                  {[
                    { key: 'all',   label: 'All',            count: gapCounts.all },
                    { key: 'gap',   label: 'Not in Carelon', count: gapCounts.gap },
                    { key: 'nogap', label: 'Carelon',        count: gapCounts.nogap },
                  ].map((o, i) => (
                    <button key={o.key} onClick={() => setGapFilter(o.key)}
                      className={`px-3 py-2 flex items-baseline gap-1 leading-none whitespace-nowrap transition-colors ${i > 0 ? 'border-l border-gray-200' : ''} ${
                        gapFilter === o.key
                          ? (o.key === 'gap' ? 'bg-red-50 text-red-600' : 'bg-brand-navy text-white')
                          : 'text-gray-500 hover:bg-gray-50'
                      }`}>
                      {o.label}
                      <span className={`text-[10px] font-bold leading-none tabular-nums ${gapFilter === o.key ? 'opacity-90' : 'text-gray-400'}`}>{o.count}</span>
                    </button>
                  ))}
                </div>

                  {/* Competitor dropdown */}
                  <div className="relative" ref={compPickerRef}>
                    <button onClick={() => setCompDropOpen(o => !o)}
                      className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border border-gray-200 bg-white hover:border-brand-navy text-gray-700 transition-all">
                      <Filter size={12} className="text-gray-400" />
                      Competitors
                      <span className="ml-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-brand-navy text-white">{selectedComps.size}</span>
                      <ChevronDown size={11} className={`text-gray-400 transition-transform ${compDropOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {compDropOpen && (
                      <div className="absolute right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden" style={{ minWidth: 180 }}
                        onMouseLeave={() => setCompDropOpen(false)}>
                        <div className="px-3 py-2 border-b border-gray-100 flex items-center justify-between">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Show Competitors</span>
                          <button onClick={() => setSelectedComps(new Set(ORDERED_COMP_KEYS))} className="text-[10px] text-brand-navy font-bold hover:underline">All</button>
                        </div>
                        <div className="max-h-64 overflow-y-auto">
                          {ORDERED_COMP_KEYS.map(c => (
                            <button key={c} onClick={() => toggleComp(c)}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs hover:bg-gray-50 transition-colors">
                              <span className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-all ${selectedComps.has(c) ? 'bg-brand-navy border-brand-navy' : 'border-gray-300'
                                }`}>
                                {selectedComps.has(c) && <Check size={10} className="text-white" strokeWidth={3} />}
                              </span>
                              <span title={c} className={`font-semibold text-left ${selectedComps.has(c) ? 'text-brand-navy' : 'text-gray-600'}`}>{compName(c)}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="w-px h-5 bg-gray-200" />
                  <div className="relative">
                    <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input className="input pl-8 text-xs py-1.5 w-44" placeholder="Search drug or class…"
                      value={tableSearch} onChange={e => setTableSearch(e.target.value)} />
                  </div>
                  {tableSearch && <button onClick={() => setTableSearch('')} className="text-xs text-gray-400 hover:text-red-500"><X size={12} /></button>}
                </div>
              </div>

              {/* Table */}
              <div ref={gridScrollRef} onScroll={handleCellLeave} className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 520 }}>
                <table className="text-left w-full" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
                  <thead className="sticky top-0 z-20">
                    <tr>
                      {/* ── Sticky fixed columns ── */}
                      {[
                        { col: 'drug', label: 'Drug Name', width: 180 },
                        { col: 'drugClass', label: 'Therapeutic Class', width: 160 },
                        { col: 'hcpcs', label: 'HCPCS', width: 90 },
                      ].reduce((acc, h, i) => {
                        const left = acc.left;
                        acc.els.push(
                          <th key={h.col} onClick={() => toggleSort(h.col)}
                            className="px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer select-none whitespace-nowrap bg-gray-50 border-b border-gray-200"
                            style={{ position: 'sticky', left: left, zIndex: 20, minWidth: h.width, boxShadow: i === 3 ? 'none' : undefined }}>
                            <div className="flex items-center gap-1">{h.label}<SortIcon col={h.col} sortCol={sortCol} sortDir={sortDir} /></div>
                          </th>
                        );
                        acc.left += h.width;
                        return acc;
                      }, { els: [], left: 0 }).els}
                      {/* Carelon — sticky */}
                      <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-center whitespace-nowrap text-brand-navy border-b border-gray-200"
                        style={{ position: 'sticky', left: 430, zIndex: 20, minWidth: 80, backgroundColor: '#EBF3FF', boxShadow: '2px 0 4px rgba(0,0,0,0.06)' }}>
                        {CARELON_URL
                          ? <a href={CARELON_URL} target="_blank" rel="noopener noreferrer" title={CARELON_URL}
                              className="text-blue-600 underline underline-offset-2 hover:text-blue-800">Carelon</a>
                          : 'Carelon'}
                      </th>
                      {/* ── Competitor columns: selected only ── */}
                      {visibleComps.map(c => (
                        <th key={c} className="px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide text-center leading-tight bg-gray-50 border-b border-gray-200"
                          style={{ minWidth: 110, maxWidth: 170 }}>{PAYOR_URLS[c]
                          ? <a href={PAYOR_URLS[c]} target="_blank" rel="noopener noreferrer" title={`${c} · ${PAYOR_URLS[c]}`}
                              className="text-blue-600 underline underline-offset-2 hover:text-blue-800">{compName(c)}</a>
                          : <span title={c}>{compName(c)}</span>}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {/* Virtualised: only the rows in view (+ overscan) are rendered; spacer rows keep the scroll height */}
                    {virtualTop > 0 && <tr aria-hidden="true"><td colSpan={visibleComps.length + 5} style={{ height: virtualTop, padding: 0, border: 0 }} /></tr>}
                    {virtualItems.map(item => {
                      const row = tableRows[item.index];
                      const rowKey = `${row.drug}|${row.hcpcs}`;
                      return (
                        <DnGridRow key={rowKey} index={item.index} measureRef={rowVirtualizer.measureElement}
                          row={row} comps={visibleComps}
                          rowOverrides={overridesByRow[rowKey]}
                          isLocked={isLocked || !canEdit} lockedTitle={canEdit ? LOCKED_EDIT_MSG : NO_PERMISSION_MSG}
                          onCellClick={handleCellClick} onCellEnter={handleCellEnter} onCellLeave={handleCellLeave} />
                      );
                    })}
                    {virtualBottom > 0 && <tr aria-hidden="true"><td colSpan={visibleComps.length + 5} style={{ height: virtualBottom, padding: 0, border: 0 }} /></tr>}
                  </tbody>
                </table>
              </div>
              <div className="px-5 py-2.5 border-t border-gray-100 flex items-center gap-3 text-xs text-gray-400 flex-wrap">
                <div className="flex items-center gap-4 flex-wrap">
                  <span className="flex items-center gap-1 font-bold" style={{ color: '#10b981' }}>✓</span><span>= Matched (source data)</span>
                  <span className="flex items-center gap-1"><CheckCircle size={11} className="text-orange-500" /></span><span>= Manually added · click for Brand/Generic</span>
                  <span className="flex items-center gap-1"><MinusCircle size={11} className="text-gray-400"/></span><span>= Manually marked not covered</span> 
                  <span className="flex items-center gap-1 text-gray-300">—</span><span>= Not Matched · click to mark</span>
                  <span className="text-red-500 font-bold">Gap</span><span>= Not on Carelon list</span>
                </div>
                <span className="ml-auto shrink-0">Scroll to view all · Sort any column header</span>
              </div>
            </div>

            {/* ══════════════════════════════════════════════
              SECTION 3 — Coverage Difference Analysis
          ══════════════════════════════════════════════ */}
            {(function CoverageSection() {
              const ov = coverageOv; // memoised above
              return (
                <div className="card p-0 overflow-hidden">
                  {/* Collapsible header */}
                  <button
                    onClick={() => setCoverageOpen(o => !o)}
                    className="w-full flex items-center justify-between gap-3 px-5 py-4 hover:bg-gray-50 transition-colors text-left"
                  >
                    <div>
                      <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Coverage Difference Analysis</p>
                      <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>Carelon vs. {compName(overlapComp)} — Side-by-Side Comparison</h2>
                      <p className="text-xs text-gray-400 mt-0.5">Normalized brand-name comparison · {ov.common + ov.carOnly + ov.compOnly} total unique drugs</p>
                    </div>
                    <ChevronDown size={15} className={`text-gray-400 transition-transform duration-200 shrink-0 ${coverageOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {coverageOpen && (
                    <div className="px-5 pb-5 pt-1">
                      {/* Competitor switcher */}
                      <div className="flex items-center gap-2 mb-5" ref={overlapRef}>
                        <span className="text-xs text-gray-400 font-semibold">Compare vs:</span>
                        <div className="relative">
                          <button onClick={() => { setOverlapSearch(''); setOverlapDropOpen(o => !o); }}
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-xs font-semibold text-brand-navy hover:border-brand-navy transition-colors min-w-[140px] justify-between">
                            <span title={overlapComp}>{compName(overlapComp)}</span>
                            <ChevronDown size={12} className={`text-gray-400 transition-transform ${overlapDropOpen ? 'rotate-180' : ''}`} />
                          </button>
                          {overlapDropOpen && (
                            <div className="absolute right-0 mt-1 w-52 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden">
                              <div className="p-2 border-b border-gray-100">
                                <div className="relative">
                                  <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                                  <input autoFocus className="w-full pl-7 pr-3 py-1.5 text-xs rounded-lg border border-gray-200 focus:outline-none focus:border-brand-navy"
                                    placeholder="Search competitor…" value={overlapSearch} onChange={e => setOverlapSearch(e.target.value)} />
                                </div>
                              </div>
                              <div className="max-h-48 overflow-y-auto py-1">
                                {OVERLAP_COMPS.filter(c => `${c} ${compName(c)}`.toLowerCase().includes(overlapSearch.toLowerCase())).map(c => (
                                  <button key={c} onClick={() => { setOverlapComp(c); setOverlapDropOpen(false); }}
                                    className={`w-full text-left px-4 py-2 text-xs transition-colors ${overlapComp === c ? 'bg-brand-light text-brand-navy font-semibold' : 'text-gray-700 hover:bg-gray-50'}`} title={c}>{compName(c)}</button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      {/* Status summary bar */}
                      <div className="grid grid-cols-3 gap-3 mb-5">
                        {[
                          { label: 'Match (Both)', value: ov.common, bg: '#D9F5F5', color: '#00BBBA', icon: <CheckCircle size={14} />, sub: 'Present on both lists' },
                          { label: 'Carelon Only', value: ov.carOnly, bg: '#E1EDFF', color: '#1A3673', icon: <AlertTriangle size={14} />, sub: 'Competitive advantage' },
                          { label: `${compName(overlapComp)} Only`, value: ov.compOnly, bg: '#FBEAE7', color: '#E3725F', icon: <XCircle size={14} />, sub: 'Coverage gaps to review' },
                        ].map(m => (
                          <div key={m.label} className="rounded-xl p-4 flex items-center gap-3" style={{ backgroundColor: m.bg }}>
                            <div style={{ color: m.color }}>{m.icon}</div>
                            <div>
                              <p className="text-xl font-bold leading-none" style={{ color: m.color }}>{m.value}</p>
                              <p className="text-xs font-semibold text-gray-700 leading-tight mt-0.5">{m.label}</p>
                              <p className="text-xs text-gray-400">{m.sub}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                      {/* Drug chip lists */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {[
                          { label: 'Match', sub: `${ov.common} drugs`, dot: 'bg-emerald-500', bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-800', chip: 'bg-white border border-emerald-200 text-emerald-700', drugs: ov.commonDrugs, total: ov.common },
                          { label: 'Carelon Only', sub: `${ov.carOnly} drugs · advantage`, dot: 'bg-brand-navy', bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-brand-navy', chip: 'bg-white border border-blue-200 text-brand-navy', drugs: ov.carOnlyDrugs, total: ov.carOnly },
                          { label: 'Missing (Gap)', sub: `${ov.compOnly} drugs · review`, dot: 'bg-red-400', bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', chip: 'bg-white border border-red-200 text-red-700', drugs: ov.compOnlyDrugs, total: ov.compOnly },
                        ].map(cat => (
                          <div key={cat.label} className={`rounded-xl border p-4 ${cat.bg} ${cat.border}`}>
                            <div className="flex items-center gap-2 mb-1">
                              <div className={`w-2 h-2 rounded-full shrink-0 ${cat.dot}`} />
                              <p className={`text-xs font-bold uppercase tracking-wide ${cat.text}`}>{cat.label}</p>
                            </div>
                            <p className={`text-xs mb-3 pl-4 ${cat.text} opacity-60`}>{cat.sub}</p>
                            <div className="flex flex-wrap gap-1.5">
                              {cat.drugs.map((d, i) => <span key={`${d}|${i}`} className={`px-2 py-0.5 rounded text-xs font-semibold ${cat.chip}`}>{d}</span>)}
                              {cat.total > cat.drugs.length && <span className="px-2 py-0.5 rounded text-xs text-gray-400 border border-dashed border-gray-200">+ more…</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* ══════════════════════════════════════════════
              SECTION 3b — Competitor Source Portfolio
          ══════════════════════════════════════════════ */}
           {(() => {
            // Only the API's comparison[payor].program_status: count + payors per status (no static rows)
            const STATUS_STYLE = {
              'Mandatory':         { color: '#1A3673', bg: '#E1EDFF' },
              'Voluntary':         { color: '#44B8F3', bg: '#E3F4FD' },
              'Mixed/Conditional': { color: '#00BBBA', bg: '#D9F5F5' },
              'Other/Unclear':     { color: '#6A97DF', bg: '#E8EFFB' },
            };
            const PORTFOLIO = programStatusPortfolio(dn.snapshot)
              .map(r => ({ ...r, ...STATUS_STYLE[r.label] }));
              const maxCount = Math.max(1, ...PORTFOLIO.map(p => p.count));
              return (
                <div className="card p-0 overflow-hidden">
                  <div className="px-5 py-4 border-b border-gray-100" style={{ backgroundColor: '#F8FAFF' }}>
                    <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Designated network program classification</p>
                    <h2 className="font-bold text-brand-navy" style={{ fontSize: 14 }}></h2>
                  </div>
                  <div className="px-5 py-5 space-y-4">
                  {PORTFOLIO.length === 0 && (
                    <p className="text-xs text-gray-400 py-4 text-center">No program status in this snapshot.</p>
                  )}
                    {PORTFOLIO.map(p => (
                      <div key={p.label}>
                        <button
                          className="w-full flex items-center gap-4 group text-left"
                          onClick={() => setPortfolioExpanded(portfolioExpanded === p.label ? null : p.label)}
                        >
                          {/* Label */}
                          <span className="text-sm font-bold text-brand-navy w-36 shrink-0">{p.label}</span>
                          {/* Bar */}
                          <div className="flex-1 h-8 rounded-md overflow-hidden bg-gray-100">
                            <div
                              className="h-full rounded-md transition-all duration-500"
                              style={{ width: `${(p.count / maxCount) * 100}%`, backgroundColor: p.color }}
                            />
                          </div>
                          {/* Count */}
                          <span className="text-sm font-bold text-brand-navy w-6 text-right shrink-0">{p.count}</span>
                          {/* Expand chevron */}
                          <ChevronDown size={13} className={`text-gray-400 shrink-0 transition-transform duration-200 ${portfolioExpanded === p.label ? 'rotate-180' : ''}`} />
                        </button>
                        {/* Expandable competitor list */}
                        {portfolioExpanded === p.label && (
                          <div className="mt-2 ml-40 flex flex-wrap gap-1.5">
                            {p.competitors.map(c => (
                              <span key={c.code} title={c.code} className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border flex items-center gap-1 ${c.code === CARELON_KEY ? 'ring-1 ring-offset-1' : ''}`}
                                style={{ backgroundColor: p.bg, color: p.color, borderColor: p.color + '44', '--tw-ring-color': p.color }}>
                                {c.name}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* ══════════════════════════════════════════════
              SECTION 4 — AI Recommendations (focal point)
          ══════════════════════════════════════════════ */}
            <div className="card" style={{ border: '2px solid #E1EDFF' }}>
              {/* Header */}
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <div className="flex items-center justify-center w-7 h-7 rounded-lg shrink-0" style={{ backgroundColor: '#1A3673' }}>
                  <Zap size={14} className="text-white" />
                </div>
                <h2 className="font-bold text-brand-navy" style={{ fontSize: 15 }}>AI Recommendations</h2>
                <span className="text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-full px-2.5 py-0.5 font-semibold">Human review required</span>
                {/* Filter tabs */}
                <div className="ml-auto flex items-center gap-1 text-xs">
                  {['all', 'add', 'remove'].map(f => (
                    <button key={f} onClick={() => setRecFilter(f)}
                      className={`px-3 py-1 rounded-lg font-semibold border capitalize transition-all ${recFilter === f
                          ? 'bg-brand-navy text-white border-brand-navy'
                          : 'bg-white text-gray-500 border-gray-200 hover:border-brand-navy'
                        }`}>{f === 'all' ? 'All' : f === 'add' ? '+ Additions' : '− Removals'}</button>
                  ))}
                  <div className="w-px h-4 bg-gray-200 mx-1" />
                  <span className="px-3 py-1 rounded-lg font-semibold border bg-brand-light text-brand-navy border-brand-navy">Top {AI_TOP_N}</span>
                </div>
              </div>
              <p className="text-xs text-gray-400 mb-5">AI-generated drug addition and removal recommendations based on competitor coverage patterns and market analysis.</p>

              {/* Recommendation cards */}
              <div className="space-y-3">
                {AI_RECS.filter(r => recFilter === 'all' || r.type === recFilter).length === 0 && (
                  <p className="text-xs text-gray-400 py-4 text-center">No recommendations for this snapshot.</p>
                )}
                {AI_RECS
                  .filter(r => recFilter === 'all' || r.type === recFilter)
                  .slice(0, AI_TOP_N)
                  .map((r, i) => {
                    const isAdd = r.type === 'add';
                    return (
                      <div key={i} className={`rounded-xl p-4 flex gap-4 border ${isAdd ? 'border-emerald-100 bg-emerald-50/40' : 'border-red-100 bg-red-50/30'}`}>
                        {/* Accent bar */}
                        <div className={`w-1 rounded-full shrink-0 self-stretch ${isAdd ? 'bg-emerald-400' : 'bg-red-400'}`} />
                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-3 flex-wrap mb-1.5">
                            <div>
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${isAdd ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                  {isAdd ? '+ Add Drug' : '− Remove Drug'}
                                </span>
                                {r.impact && <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${r.impact === 'High' ? 'bg-red-50 text-red-600' : r.impact === 'Medium' ? 'bg-amber-50 text-amber-600' : 'bg-gray-100 text-gray-500'
                                  }`}>{r.impact} Impact</span>}
                              </div>
                              <p className="text-sm font-bold text-gray-800">{r.drug}</p>
                              {r.drugClass && <p className="text-xs text-gray-400">{r.drugClass}</p>}
                            </div>
                            {/* Confidence score (only when the API sends one) */}
                            {r.confidence != null && <div className="shrink-0 text-right">
                              <p className="text-xs text-gray-400 font-semibold">AI Confidence</p>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <div className="w-20 bg-gray-100 rounded-full h-1.5">
                                  <div className="h-1.5 rounded-full" style={{ width: `${r.confidence}%`, backgroundColor: r.confidence >= 85 ? '#10b981' : r.confidence >= 70 ? '#f59e0b' : '#ef4444' }} />
                                </div>
                                <span className="text-xs font-bold text-gray-700">{r.confidence}%</span>
                              </div>
                            </div>}
                          </div>
                          <p className="text-xs text-gray-600 leading-relaxed">{r.reason}</p>
                          {r.competitors.length > 0 && (
                            <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                              <span className="text-xs text-gray-400">{isAdd ? 'Matched by:' : 'Still matched by:'}</span>
                              {r.competitors.map(c => (
                                <span key={c} title={c} className={`text-xs font-semibold px-1.5 py-0.5 rounded ${isAdd ? 'bg-blue-50 text-blue-700' : 'bg-gray-100 text-gray-600'}`}>{compName(c)}</span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </>)}

        </div>
      ) : null}

      {/* ── Cell Edit Modal ── */}
      {confirmModal && (() => {
        // Revert is offered only for cells the user edited in this session (not edits loaded with the snapshot)
        const hasOverride = sessionEdits.has(confirmModal.cellKey);
        const setLocalCovered = (v) => setConfirmModal(m => ({ ...m, localCovered: v }));
        const setLocalNote = (v) => setConfirmModal(m => ({ ...m, localNote: v }));
        return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}
            onClick={() => !confirmModal.saving && setConfirmModal(null)}>
            <div className="bg-white rounded-xl shadow-xl mx-4 p-4" style={{ width: 280 }} onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-bold text-gray-900 text-xs">{confirmModal.row.drug}</p>
                  <p className="text-[10px] text-gray-400">{confirmModal.compLabel || confirmModal.comp} · {confirmModal.row.hcpcs}</p>
                </div>
                <button onClick={() => setConfirmModal(null)} className="text-gray-400 hover:text-gray-600 ml-2 shrink-0"><X size={14} /></button>
              </div>
              <div className="flex gap-2 mb-3">
                <button onClick={() => setLocalCovered(true)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${confirmModal.localCovered ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-gray-200 bg-white text-gray-400'
                    }`}>
                  <CheckCircle size={12} /> Matched
                </button>
                <button onClick={() => setLocalCovered(false)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5 ${!confirmModal.localCovered ? 'border-red-400 bg-red-50 text-red-600' : 'border-gray-200 bg-white text-gray-400'
                    }`}>
                  <X size={12} /> Not Matched
                </button>
              </div>
              {/* Note → sent as `comments` with this cell's update in the edits call.
                  Temporarily disabled (API wiring kept) — wrapper carries the hover hint (disabled inputs don't receive hover events) */}
              <div className="mb-3 cursor-not-allowed" title="Feature coming soon">
                <input
                  className="input text-xs py-1.5 w-full bg-gray-100 text-gray-400 border-gray-200 pointer-events-none"
                  placeholder="Add a note — feature coming soon"
                  aria-label="Note"
                  maxLength={500}
                  value={confirmModal.localNote}
                  onChange={e => setLocalNote(e.target.value)}
                  disabled
                  aria-disabled="true"
                />
              </div>
              <div className="flex gap-1.5">
                <button onClick={() => setConfirmModal(null)} disabled={confirmModal.saving}
                  className="flex-1 py-1.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-500 hover:bg-gray-50">
                  Cancel
                </button>
                {hasOverride && (
                  <button
                    onClick={() => saveCellEdit({ revert: true })} disabled={confirmModal.saving}
                    className="px-2.5 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-xs font-semibold text-amber-700 hover:bg-amber-100 flex items-center gap-1">
                    <RefreshCw size={10} /> Revert
                  </button>
                )}
                <button
                  onClick={() => saveCellEdit()} disabled={confirmModal.saving}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold text-white flex items-center justify-center gap-1.5 ${confirmModal.saving ? 'opacity-70 cursor-not-allowed' : ''}`}
                  style={{ backgroundColor: '#1A3673' }}>
                  {confirmModal.saving && <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  {confirmModal.saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Fixed-position cell tooltip — own state, so hovering doesn't re-render the grid */}
      <DnCellTooltip ref={tooltipRef} />
    </div>
  );
}
