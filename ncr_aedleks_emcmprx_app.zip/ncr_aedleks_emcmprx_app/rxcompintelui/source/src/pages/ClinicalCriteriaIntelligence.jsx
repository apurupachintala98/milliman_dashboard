import { useState, useMemo, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search, X, CheckCircle, ChevronDown, ChevronUp, ChevronRight,
  Zap, FileText, ExternalLink, Edit2, Plus, Save, RotateCcw,
  AlertTriangle, Info, Minus, ArrowRight, Loader2, Check,
  MessageSquare, ThumbsUp, ThumbsDown, Flag
} from 'lucide-react';

// ─── Constants ──────────────────────────────────────────────────────────────

const DRUG_LIST = [
  'Skyrizi (risankizumab)',
  'Humira (adalimumab)',
  'Stelara (ustekinumab)',
  'Rinvoq (upadacitinib)',
  'Tremfya (guselkumab)',
  'Dupixent (dupilumab)',
  'Cosentyx (secukinumab)',
  'Taltz (ixekizumab)',
  'Entyvio (vedolizumab)',
  'Xeljanz (tofacitinib)',
];

const ALL_PAYERS = ['UHC', 'Cigna', 'Aetna', 'Caremark'];

// Mock source policies per payer
const POLICY_SOURCES = {
  UHC:      { name: 'UHC Clinical Policy Bulletin: Interleukin Inhibitors (CP.PHAR.317)',      date: '2026-01-15', url: '#' },
  Cigna:    { name: 'Cigna Coverage Policy: IL-23 Inhibitors for Inflammatory Conditions',      date: '2025-12-01', url: '#' },
  Aetna:    { name: 'Aetna Clinical Policy Bulletin: Skyrizi (risankizumab-rzaa) – No. 0950',  date: '2026-02-01', url: '#' },
  Caremark: { name: 'CVS Caremark Prior Authorization Criteria: Skyrizi®',                     date: '2026-03-01', url: '#' },
};

// Mock extracted conditions per drug
const DRUG_CONDITIONS = {
  'Skyrizi (risankizumab)': [
    'Crohn\'s Disease',
    'Plaque Psoriasis',
    'Psoriatic Arthritis',
    'Ulcerative Colitis',
  ],
  'Humira (adalimumab)': [
    'Crohn\'s Disease',
    'Plaque Psoriasis',
    'Psoriatic Arthritis',
    'Rheumatoid Arthritis',
    'Ankylosing Spondylitis',
  ],
  'Stelara (ustekinumab)': [
    'Crohn\'s Disease',
    'Plaque Psoriasis',
    'Psoriatic Arthritis',
  ],
  'Rinvoq (upadacitinib)': [
    'Rheumatoid Arthritis',
    'Psoriatic Arthritis',
    'Atopic Dermatitis',
    'Ulcerative Colitis',
  ],
};
const DEFAULT_CONDITIONS = ['Condition A', 'Condition B'];

// Cell status types
const STATUS = {
  match:          { label: 'Match',         bg: '#F0FDF4', border: '#86EFAC', text: '#166534', icon: 'check' },
  different:      { label: 'Different',     bg: '#FFF7ED', border: '#FED7AA', text: '#9A3412', icon: 'diff'  },
  not_mentioned:  { label: 'Not mentioned', bg: '#F9FAFB', border: '#E5E7EB', text: '#6B7280', icon: 'dash'  },
  not_applicable: { label: 'Not applicable',bg: '#F1F5F9', border: '#CBD5E1', text: '#64748B', icon: 'na'   },
};

// Mock criteria data factory
function buildCriteriaData(condition) {
  const condKey = condition.toLowerCase().replace(/\s+/g, '_');
  const base = {
    "Crohn's Disease": {
      quantity_limits: {
        label: 'Quantity Limits',
        rows: [
          {
            criterion: 'Induction Dose Quantity',
            elevance: '600 mg IV at Weeks 0, 4, 8',
            payers: {
              UHC:      { value: '600 mg IV at Weeks 0, 4, 8',         status: 'match' },
              Cigna:    { value: '600 mg IV at Weeks 0, 4, 8',         status: 'match' },
              Aetna:    { value: '600 mg IV infusion × 3 doses',       status: 'different' },
              Caremark: { value: '600 mg IV induction × 3',            status: 'match' },
            },
          },
          {
            criterion: 'Maintenance Dose Quantity',
            elevance: '360 mg SC every 8 weeks',
            payers: {
              UHC:      { value: '360 mg SC q8w',                      status: 'match' },
              Cigna:    { value: '360 mg SC every 8 weeks',            status: 'match' },
              Aetna:    { value: '360 mg SC q8 weeks',                 status: 'match' },
              Caremark: { value: '360 mg SC q8w OR 600mg IV q12w',     status: 'different' },
            },
          },
        ],
      },
      duration: {
        label: 'Duration',
        rows: [
          {
            criterion: 'Initial Authorization Duration',
            elevance: '12 months',
            payers: {
              UHC:      { value: '12 months',  status: 'match' },
              Cigna:    { value: '12 months',  status: 'match' },
              Aetna:    { value: '6 months',   status: 'different' },
              Caremark: { value: '6 months',   status: 'different' },
            },
          },
          {
            criterion: 'Renewal / Continuation Duration',
            elevance: '12 months if clinical response documented',
            payers: {
              UHC:      { value: '12 months with documented response',         status: 'match' },
              Cigna:    { value: '12 months; response documentation required', status: 'match' },
              Aetna:    { value: '12 months',                                  status: 'match' },
              Caremark: { value: '12 months with positive clinical response',  status: 'match' },
            },
          },
        ],
      },
      clinical_criteria: {
        label: 'Clinical / Prior Authorization Criteria',
        rows: [
          {
            criterion: 'Minimum Age Requirement',
            elevance: '18 years or older',
            payers: {
              UHC:      { value: 'No minimum age specified',    status: 'different' },
              Cigna:    { value: '18 years or older',           status: 'match' },
              Aetna:    { value: '18 years or older',           status: 'match' },
              Caremark: { value: 'No age restriction listed',   status: 'different' },
            },
          },
          {
            criterion: 'Disease Severity',
            elevance: 'Moderate-to-severe Crohn\'s Disease',
            payers: {
              UHC:      { value: 'Moderate-to-severe CD',                        status: 'match' },
              Cigna:    { value: 'Moderate-to-severe CD confirmed by physician', status: 'match' },
              Aetna:    { value: 'Diagnosis of CD; no severity threshold stated',status: 'different' },
              Caremark: { value: 'Moderate-to-severe CD with ≥1 high risk feature', status: 'different' },
            },
          },
          {
            criterion: 'Step Therapy / Prior Treatment Failure',
            elevance: 'Failure, intolerance, or contraindication to ≥1 conventional therapy',
            payers: {
              UHC:      { value: 'Trial and failure or contraindication to conventional tx', status: 'match' },
              Cigna:    { value: 'Failure of ≥1 immunomodulator at adequate dose and duration', status: 'different' },
              Aetna:    { value: 'Failure of at least one approved biologic OR immunomodulator', status: 'different' },
              Caremark: { value: 'T/F immunomodulator at max dose × 3 months OR documented contraindication', status: 'different' },
            },
          },
          {
            criterion: 'Prescriber Specialty Requirement',
            elevance: 'Not required',
            payers: {
              UHC:      { value: 'Prescribed or consulted by Gastroenterologist', status: 'different' },
              Cigna:    { value: 'Not explicitly required',                        status: 'match' },
              Aetna:    { value: 'Gastroenterology consult recommended, not required', status: 'different' },
              Caremark: { value: 'Prescribed or consulted by Gastroenterologist', status: 'different' },
            },
          },
          {
            criterion: 'Tuberculosis Screening',
            elevance: 'Negative TB test required prior to initiation',
            payers: {
              UHC:      { value: 'Negative TB screening required',              status: 'match' },
              Cigna:    { value: 'Negative TB test within 12 months',           status: 'match' },
              Aetna:    { value: 'TB screening required; results must be negative', status: 'match' },
              Caremark: { value: 'Negative TST or IGRA within 12 months',       status: 'match' },
            },
          },
        ],
      },
      additional_criteria: {
        label: 'Additional Criteria',
        rows: [
          {
            criterion: 'Combination Therapy Restrictions',
            elevance: 'Not to be used in combination with other biologics or JAK inhibitors',
            payers: {
              UHC:      { value: 'Not used in combination with other targeted immunomodulators', status: 'match' },
              Cigna:    { value: 'No combination with biologics; standalone use required',       status: 'match' },
              Aetna:    { value: 'Not mentioned',                                                status: 'not_mentioned' },
              Caremark: { value: 'No combination with biologic DMARD, JAK inhibitor, or PDE4 inhibitor', status: 'different' },
            },
          },
          {
            criterion: 'Stable Dose Documentation at Renewal',
            elevance: 'Member must have received and maintained stable dose',
            payers: {
              UHC:      { value: 'Not explicitly required',       status: 'different' },
              Cigna:    { value: 'Not mentioned',                 status: 'not_mentioned' },
              Aetna:    { value: 'Not applicable',                status: 'not_applicable' },
              Caremark: { value: 'Stable dose documentation required at renewal', status: 'match' },
            },
          },
          {
            criterion: 'Medication Source Restriction',
            elevance: 'Medication not obtained through manufacturer samples or PAP',
            payers: {
              UHC:      { value: 'Medication not obtained through manufacturer sponsored supply or PAP', status: 'match' },
              Cigna:    { value: 'Not mentioned',     status: 'not_mentioned' },
              Aetna:    { value: 'Not mentioned',     status: 'not_mentioned' },
              Caremark: { value: 'Not through manufacturer PAP or samples', status: 'match' },
            },
          },
        ],
      },
    },
  };

  // Return data for known condition, or generate placeholder
  return base[condition] || {
    quantity_limits: {
      label: 'Quantity Limits',
      rows: [
        {
          criterion: 'Standard Dose Quantity',
          elevance: 'Per FDA-approved labeling',
          payers: {
            UHC:      { value: 'Per FDA labeling', status: 'match' },
            Cigna:    { value: 'Per FDA labeling', status: 'match' },
            Aetna:    { value: 'Per labeling',     status: 'match' },
            Caremark: { value: 'Not mentioned',    status: 'not_mentioned' },
          },
        },
      ],
    },
    duration: {
      label: 'Duration',
      rows: [
        {
          criterion: 'Initial Authorization Duration',
          elevance: '12 months',
          payers: {
            UHC:      { value: '12 months', status: 'match' },
            Cigna:    { value: '12 months', status: 'match' },
            Aetna:    { value: '6 months',  status: 'different' },
            Caremark: { value: '12 months', status: 'match' },
          },
        },
        {
          criterion: 'Renewal Duration',
          elevance: '12 months with documented response',
          payers: {
            UHC:      { value: '12 months', status: 'match' },
            Cigna:    { value: '12 months', status: 'match' },
            Aetna:    { value: '12 months', status: 'match' },
            Caremark: { value: '12 months', status: 'match' },
          },
        },
      ],
    },
    clinical_criteria: {
      label: 'Clinical / Prior Authorization Criteria',
      rows: [
        {
          criterion: 'Confirmed Diagnosis',
          elevance: 'Confirmed diagnosis by treating physician',
          payers: {
            UHC:      { value: 'Diagnosis confirmed',    status: 'match' },
            Cigna:    { value: 'Diagnosis required',     status: 'match' },
            Aetna:    { value: 'Confirmed diagnosis',    status: 'match' },
            Caremark: { value: 'Not mentioned',          status: 'not_mentioned' },
          },
        },
        {
          criterion: 'Step Therapy',
          elevance: 'Failure or contraindication to first-line therapy',
          payers: {
            UHC:      { value: 'Trial and failure required', status: 'match' },
            Cigna:    { value: 'Step therapy required',      status: 'match' },
            Aetna:    { value: 'Trial of conventional therapy', status: 'different' },
            Caremark: { value: 'Not mentioned',              status: 'not_mentioned' },
          },
        },
      ],
    },
    additional_criteria: {
      label: 'Additional Criteria',
      rows: [
        {
          criterion: 'Combination Restrictions',
          elevance: 'Not to be combined with other biologics',
          payers: {
            UHC:      { value: 'No combination with biologics', status: 'match' },
            Cigna:    { value: 'Standalone use only',           status: 'match' },
            Aetna:    { value: 'Not mentioned',                 status: 'not_mentioned' },
            Caremark: { value: 'Not mentioned',                 status: 'not_mentioned' },
          },
        },
      ],
    },
  };
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatusChip({ status }) {
  const s = STATUS[status] || STATUS.not_mentioned;
  return (
    <span
      className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
      style={{ backgroundColor: s.bg, color: s.text, border: `1px solid ${s.border}` }}
    >
      {status === 'match'          && <Check size={8} />}
      {status === 'different'      && <AlertTriangle size={8} />}
      {status === 'not_mentioned'  && <Minus size={8} />}
      {status === 'not_applicable' && <Info size={8} />}
      {s.label}
    </span>
  );
}

function CriteriaCell({ value, status, onEdit }) {
  const s = STATUS[status] || STATUS.not_mentioned;
  return (
    <div
      className="rounded-lg px-2.5 py-2 text-xs leading-snug relative group"
      style={{ backgroundColor: s.bg, borderLeft: `3px solid ${s.border}` }}
    >
      <div className="flex items-start justify-between gap-1">
        <p className="text-gray-700 flex-1" style={{ fontSize: 11 }}>{value}</p>
        <button
          onClick={onEdit}
          className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-1"
          title="Edit"
        >
          <Edit2 size={10} className="text-gray-400 hover:text-brand-navy" />
        </button>
      </div>
      <div className="mt-1">
        <StatusChip status={status} />
      </div>
    </div>
  );
}

function ElevanceCell({ value }) {
  return (
    <div
      className="rounded-lg px-2.5 py-2 text-xs leading-snug"
      style={{ backgroundColor: '#E8F0FF', borderLeft: '3px solid #1A3673' }}
    >
      <p className="text-brand-navy font-semibold" style={{ fontSize: 11 }}>{value}</p>
    </div>
  );
}

function ProcessingStep({ label, status }) {
  // status: 'pending' | 'running' | 'done' | 'error'
  return (
    <div className="flex items-center gap-3 py-2">
      <div className="w-6 h-6 rounded-full flex items-center justify-center shrink-0">
        {status === 'done'    && <CheckCircle size={16} className="text-emerald-500" />}
        {status === 'running' && <Loader2 size={16} className="text-brand-navy animate-spin" />}
        {status === 'pending' && <div className="w-4 h-4 rounded-full border-2 border-gray-200" />}
        {status === 'error'   && <AlertTriangle size={16} className="text-red-400" />}
      </div>
      <span className={`text-sm ${
        status === 'done' ? 'text-emerald-700 font-semibold' :
        status === 'running' ? 'text-brand-navy font-semibold' :
        'text-gray-400'
      }`}>{label}</span>
    </div>
  );
}

function PolicyCard({ payer, policy, status }) {
  // status: 'found' | 'searching' | 'not_found'
  return (
    <div className="rounded-xl border p-3.5 flex flex-col gap-2" style={{
      borderColor: status === 'found' ? '#86EFAC' : status === 'not_found' ? '#FCA5A5' : '#E5E7EB',
      backgroundColor: status === 'found' ? '#F0FDF4' : status === 'not_found' ? '#FEF2F2' : '#F9FAFB',
    }}>
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-bold text-gray-700">{payer}</span>
        {status === 'found'     && <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">Policy Found</span>}
        {status === 'searching' && <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 flex items-center gap-1"><Loader2 size={8} className="animate-spin"/>Searching…</span>}
        {status === 'not_found' && <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-600">Not Found</span>}
      </div>
      {status === 'found' && policy && (
        <div>
          <p className="text-[11px] font-semibold text-gray-800 leading-snug">{policy.name}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[10px] text-gray-400">Effective: {policy.date}</span>
            <a href={policy.url} className="text-[10px] text-brand-navy font-semibold flex items-center gap-0.5 hover:underline">
              <ExternalLink size={9} /> View Policy
            </a>
          </div>
        </div>
      )}
      {status === 'searching' && (
        <p className="text-[10px] text-gray-400 italic">Searching policy repository…</p>
      )}
      {status === 'not_found' && (
        <p className="text-[10px] text-red-400 italic">No matching clinical criteria policy located.</p>
      )}
    </div>
  );
}

function EditModal({ criterion, payer, currentValue, onSave, onClose }) {
  const [val, setVal] = useState(currentValue);
  const [status, setStatus] = useState('different');
  const [note, setNote] = useState('');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-brand-navy text-sm">Edit / Correct Criterion</h3>
            <p className="text-xs text-gray-400 mt-0.5">{criterion} · {payer}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wide block mb-1">Corrected Value</label>
            <textarea
              className="input resize-none"
              rows={3}
              value={val}
              onChange={e => setVal(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wide block mb-1">Status</label>
            <select className="select text-xs" value={status} onChange={e => setStatus(e.target.value)}>
              <option value="match">Match</option>
              <option value="different">Different</option>
              <option value="not_mentioned">Not mentioned</option>
              <option value="not_applicable">Not applicable</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wide block mb-1">Correction Note (optional)</label>
            <input className="input text-xs" placeholder="e.g. Updated per policy doc v2.1…" value={note} onChange={e => setNote(e.target.value)} />
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onClose} className="btn-secondary text-xs py-1.5 px-4">Cancel</button>
          <button
            onClick={() => { onSave(val, status, note); onClose(); }}
            className="btn-primary text-xs py-1.5 px-4 flex items-center gap-1.5"
          >
            <Save size={12} /> Save Correction
          </button>
        </div>
      </div>
    </div>
  );
}

function AddCriterionModal({ section, payers, onSave, onClose }) {
  const [criterion, setCriterion] = useState('');
  const [elevance, setElevance] = useState('');
  const [payerVals, setPayerVals] = useState(Object.fromEntries(payers.map(p => [p, { value: '', status: 'not_mentioned' }])));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-4 p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-brand-navy text-sm">Add Missing Criterion</h3>
            <p className="text-xs text-gray-400 mt-0.5">Section: {section}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wide block mb-1">Criterion Name</label>
            <input className="input text-xs" placeholder="e.g. Maximum Daily Dose" value={criterion} onChange={e => setCriterion(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wide block mb-1">Elevance Value</label>
            <input className="input text-xs" placeholder="Elevance policy text…" value={elevance} onChange={e => setElevance(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wide block mb-2">Payer Values</label>
            <div className="space-y-2">
              {payers.map(p => (
                <div key={p} className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-gray-600 w-20 shrink-0">{p}</span>
                  <input
                    className="input text-xs flex-1"
                    placeholder={`${p} policy text or 'Not mentioned'`}
                    value={payerVals[p].value}
                    onChange={e => setPayerVals(prev => ({ ...prev, [p]: { ...prev[p], value: e.target.value } }))}
                  />
                  <select
                    className="select text-xs w-36 shrink-0"
                    value={payerVals[p].status}
                    onChange={e => setPayerVals(prev => ({ ...prev, [p]: { ...prev[p], status: e.target.value } }))}
                  >
                    <option value="match">Match</option>
                    <option value="different">Different</option>
                    <option value="not_mentioned">Not mentioned</option>
                    <option value="not_applicable">Not applicable</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onClose} className="btn-secondary text-xs py-1.5 px-4">Cancel</button>
          <button
            disabled={!criterion.trim()}
            onClick={() => {
              if (!criterion.trim()) return;
              onSave({ criterion, elevance, payers: payerVals });
              onClose();
            }}
            className="btn-primary text-xs py-1.5 px-4 flex items-center gap-1.5 disabled:opacity-50"
          >
            <Plus size={12} /> Add Criterion
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Processing steps helper ─────────────────────────────────────────────────

function useProcessingSteps() {
  const [steps, setSteps] = useState([
    { id: 'find',      label: 'Identifying source policy documents',      status: 'pending' },
    { id: 'extract',   label: 'Extracting conditions from policies',       status: 'pending' },
    { id: 'criteria',  label: 'Extracting clinical criteria per condition', status: 'pending' },
    { id: 'normalize', label: 'Normalising and aligning criteria across payers', status: 'pending' },
    { id: 'compare',   label: 'Building comparison matrix',               status: 'pending' },
  ]);

  const run = useCallback((onComplete) => {
    const delay = (ms) => new Promise(res => setTimeout(res, ms));
    (async () => {
      for (let i = 0; i < steps.length; i++) {
        setSteps(prev => prev.map((s, idx) => idx === i ? { ...s, status: 'running' } : s));
        await delay(700 + Math.random() * 500);
        setSteps(prev => prev.map((s, idx) => idx === i ? { ...s, status: 'done' } : s));
      }
      onComplete();
    })();
  }, []);

  const reset = useCallback(() => {
    setSteps(prev => prev.map(s => ({ ...s, status: 'pending' })));
  }, []);

  return { steps, run, reset };
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ClinicalCriteriaIntelligence() {
  const navigate = useNavigate();

  // Step: 'select' | 'processing' | 'policy_id' | 'results'
  const [step, setStep] = useState('select');

  // Drug selection
  const [drugList, setDrugList] = useState(DRUG_LIST);
  const [drugQuery, setDrugQuery] = useState('');
  const [selectedDrug, setSelectedDrug] = useState(null);
  const [drugDropOpen, setDrugDropOpen] = useState(false);
  const drugInputRef = useRef(null);

  // Payer selection
  const [selectedPayers, setSelectedPayers] = useState(['UHC', 'Cigna', 'Aetna', 'Caremark']);

  // Processing
  const { steps: procSteps, run: runSteps, reset: resetSteps } = useProcessingSteps();

  // Policy identification states (per payer)
  const [policyStatuses, setPolicyStatuses] = useState({});

  // Active condition tab
  const [activeCondition, setActiveCondition] = useState(null);

  // Collapsed sections in results
  const [collapsed, setCollapsed] = useState({});

  // Edit modal
  const [editModal, setEditModal] = useState(null); // { sectionKey, rowIdx, payer, value, status }

  // Add criterion modal
  const [addModal, setAddModal] = useState(null); // { sectionKey }

  // User corrections: { [sectionKey]: { [rowIdx]: { [payer]: { value, status } } } }
  const [corrections, setCorrections] = useState({});

  // Feedback
  const [feedbackOpen, setFeedbackOpen] = useState({});

  // Source tooltip
  const [sourceOpen, setSourceOpen] = useState(null);

  // Computed conditions
  const conditions = useMemo(() => {
    if (!selectedDrug) return [];
    return DRUG_CONDITIONS[selectedDrug] || DEFAULT_CONDITIONS;
  }, [selectedDrug]);

  // Criteria data for active condition
  const criteriaData = useMemo(() => {
    if (!activeCondition) return null;
    return buildCriteriaData(activeCondition);
  }, [activeCondition]);

  // Drug dropdown filter
  const filteredDrugs = useMemo(() => {
    const q = drugQuery.toLowerCase().trim();
    return drugList.filter(d => !q || d.toLowerCase().includes(q));
  }, [drugQuery, drugList]);

  function selectDrug(name) {
    setSelectedDrug(name);
    setDrugQuery(name);
    setDrugDropOpen(false);
  }

  function addCustomDrug() {
    const trimmed = drugQuery.trim();
    if (!trimmed) return;
    if (!drugList.includes(trimmed)) setDrugList(prev => [...prev, trimmed]);
    selectDrug(trimmed);
  }

  function togglePayer(p) {
    setSelectedPayers(prev =>
      prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
    );
  }

  function handleGenerate() {
    if (!selectedDrug || selectedPayers.length === 0) return;
    setStep('processing');
    resetSteps();
    // Simulate policy identification in parallel
    const newStatuses = {};
    selectedPayers.forEach(p => { newStatuses[p] = 'searching'; });
    setPolicyStatuses(newStatuses);

    // Reveal policies one by one during processing
    selectedPayers.forEach((p, i) => {
      setTimeout(() => {
        setPolicyStatuses(prev => ({ ...prev, [p]: 'found' }));
      }, 800 + i * 600);
    });

    runSteps(() => {
      setStep('results');
      setActiveCondition(conditions[0] || null);
      setCollapsed({});
      setCorrections({});
    });
  }

  function handleChangeDrug() {
    setStep('select');
    setSelectedDrug(null);
    setDrugQuery('');
    setActiveCondition(null);
    setPolicyStatuses({});
    resetSteps();
  }

  function handleRegenerate() {
    setStep('processing');
    resetSteps();
    setPolicyStatuses(Object.fromEntries(selectedPayers.map(p => [p, 'searching'])));
    selectedPayers.forEach((p, i) => {
      setTimeout(() => {
        setPolicyStatuses(prev => ({ ...prev, [p]: 'found' }));
      }, 800 + i * 600);
    });
    runSteps(() => {
      setStep('results');
      setCollapsed({});
      setCorrections({});
    });
  }

  function toggleSection(key) {
    setCollapsed(prev => ({ ...prev, [key]: !prev[key] }));
  }

  function applyCorrection(sectionKey, rowIdx, payer, value, status) {
    setCorrections(prev => ({
      ...prev,
      [sectionKey]: {
        ...prev[sectionKey],
        [rowIdx]: {
          ...(prev[sectionKey]?.[rowIdx] || {}),
          [payer]: { value, status },
        },
      },
    }));
  }

  // Count differences for summary bar
  const diffSummary = useMemo(() => {
    if (!criteriaData) return { match: 0, different: 0, not_mentioned: 0, not_applicable: 0 };
    const counts = { match: 0, different: 0, not_mentioned: 0, not_applicable: 0 };
    Object.values(criteriaData).forEach(section => {
      section.rows.forEach((row, rowIdx) => {
        selectedPayers.forEach(p => {
          const correction = corrections[section.label]?.[rowIdx]?.[p];
          const cell = correction || row.payers[p];
          if (cell) counts[cell.status] = (counts[cell.status] || 0) + 1;
        });
      });
    });
    return counts;
  }, [criteriaData, selectedPayers, corrections]);

  // ── RENDER ──────────────────────────────────────────────────────────────────

  return (
    <div className="space-y-5">

      {/* ── HEADER ── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold mb-0.5">Clinical Criteria</p>
          <h1 className="text-2xl font-bold text-brand-navy">Clinical Criteria Intelligence</h1>
          {step === 'results' && selectedDrug && (
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-full"
                style={{ backgroundColor: '#EDE9FE', color: '#7C3AED', border: '1px solid #C4B5FD' }}>
                {selectedDrug}
              </span>
              {selectedPayers.map(p => (
                <span key={p} className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: '#E8F0FF', color: '#1A3673', border: '1px solid #B8CEFF' }}>
                  {p}
                </span>
              ))}
            </div>
          )}
        </div>
        {step === 'results' && (
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={handleChangeDrug} className="btn-secondary flex items-center gap-1.5 text-xs py-1.5 px-3">
              <Search size={12} /> Change Drug
            </button>
            <button onClick={handleRegenerate} className="btn-secondary flex items-center gap-1.5 text-xs py-1.5 px-3">
              <RotateCcw size={12} /> Regenerate Intelligence
            </button>
          </div>
        )}
      </div>

      {/* ══════════════════════════════════════════
          STEP: SELECT
      ══════════════════════════════════════════ */}
      {step === 'select' && (
        <div className="space-y-4">

          {/* Drug selector */}
          <div className="card py-5 px-5">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">1 · Select Drug</p>
            <div className="relative" style={{ maxWidth: 540 }}>
              <div className="relative">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                <input
                  ref={drugInputRef}
                  className={`input pl-9 pr-9 text-sm py-2.5 w-full transition-all ${selectedDrug ? 'border-brand-navy ring-1 ring-brand-navy/20' : ''}`}
                  placeholder="Search by brand or generic name (e.g. 'skyrizi', 'risankizumab')…"
                  value={drugQuery}
                  onChange={e => {
                    setDrugQuery(e.target.value);
                    setDrugDropOpen(true);
                    if (!e.target.value) setSelectedDrug(null);
                  }}
                  onFocus={() => setDrugDropOpen(true)}
                  onBlur={() => setTimeout(() => setDrugDropOpen(false), 180)}
                />
                {selectedDrug && !drugDropOpen && (
                  <CheckCircle size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-navy pointer-events-none" />
                )}
                {drugQuery && drugDropOpen && (
                  <button
                    onMouseDown={() => { setDrugQuery(''); setSelectedDrug(null); drugInputRef.current?.focus(); }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500"
                  >
                    <X size={13} />
                  </button>
                )}
              </div>

              {selectedDrug && !drugDropOpen && (
                <div className="flex items-center gap-2 mt-2.5">
                  <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">Selected:</span>
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-full"
                    style={{ backgroundColor: '#EDE9FE', color: '#7C3AED', border: '1px solid #C4B5FD' }}>
                    <CheckCircle size={11} /> {selectedDrug}
                  </span>
                </div>
              )}

              {/* Dropdown */}
              {drugDropOpen && (() => {
                const q = drugQuery.toLowerCase().trim();
                const matched = filteredDrugs;
                const exactMatch = drugList.some(d => d.toLowerCase() === q);
                const noResults = q && matched.length === 0;
                return (
                  <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-2xl z-50 overflow-hidden">
                    {matched.length > 0 && (
                      <div style={{ maxHeight: 240, overflowY: 'auto' }}>
                        {!q && <p className="px-4 pt-3 pb-1 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Available Drugs</p>}
                        {matched.map(d => {
                          const idx = q ? d.toLowerCase().indexOf(q) : -1;
                          return (
                            <button key={d} onMouseDown={() => selectDrug(d)}
                              className={`w-full text-left px-4 py-2.5 text-sm flex items-center gap-2 transition-colors ${
                                selectedDrug === d ? 'bg-[#EDE9FE] text-[#7C3AED] font-bold' : 'text-gray-800 hover:bg-gray-50'
                              }`}>
                              <span className="flex-1">
                                {idx !== -1 ? (
                                  <>
                                    {d.slice(0, idx)}
                                    <strong className="text-brand-navy bg-yellow-100 px-0.5 rounded">{d.slice(idx, idx + q.length)}</strong>
                                    {d.slice(idx + q.length)}
                                  </>
                                ) : d}
                              </span>
                              {selectedDrug === d && <CheckCircle size={13} className="text-[#7C3AED] shrink-0" />}
                            </button>
                          );
                        })}
                      </div>
                    )}
                    {noResults && (
                      <div className="px-4 py-4">
                        <p className="text-sm text-gray-500 mb-3">No match for <strong className="text-gray-800">"{drugQuery}"</strong></p>
                        <button onMouseDown={addCustomDrug}
                          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-bold text-white transition-colors"
                          style={{ backgroundColor: '#7C3AED' }}>
                          <Plus size={14} /> Add "{drugQuery.trim()}" as custom drug
                        </button>
                        <p className="text-[10px] text-gray-400 text-center mt-2">Intelligence will be generated from available policy documents</p>
                      </div>
                    )}
                    {q && !exactMatch && matched.length > 0 && (
                      <div className="border-t border-gray-100 px-4 py-2.5 flex items-center justify-between">
                        <span className="text-xs text-gray-400">Not finding what you need?</span>
                        <button onMouseDown={addCustomDrug}
                          className="text-xs font-bold px-3 py-1.5 rounded-lg border border-[#7C3AED] text-[#7C3AED] hover:bg-[#F5F3FF] transition-colors flex items-center gap-1">
                          <Plus size={11} /> Add "{drugQuery.trim()}"
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          </div>

          {/* Payer selector */}
          <div className="card py-5 px-5">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">2 · Select Competitor Payers</p>
            <div className="flex flex-wrap gap-2">
              {ALL_PAYERS.map(p => {
                const active = selectedPayers.includes(p);
                return (
                  <button key={p} onClick={() => togglePayer(p)}
                    className="flex items-center gap-1.5 text-sm font-semibold px-4 py-2 rounded-lg border transition-all"
                    style={{
                      backgroundColor: active ? '#E8F0FF' : '#fff',
                      borderColor:     active ? '#1A3673' : '#E5E7EB',
                      color:           active ? '#1A3673' : '#6B7280',
                    }}>
                    {active && <CheckCircle size={13} />}
                    {p}
                  </button>
                );
              })}
            </div>
            {selectedPayers.length === 0 && (
              <p className="text-xs text-amber-500 mt-2 flex items-center gap-1"><AlertTriangle size={12} /> Select at least one payer.</p>
            )}
          </div>

          {/* Generate CTA */}
          <div className="card py-5 px-5">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">3 · Generate Intelligence</p>
            <div className="flex items-center gap-4 flex-wrap">
              <button
                onClick={handleGenerate}
                disabled={!selectedDrug || selectedPayers.length === 0}
                className="btn-primary flex items-center gap-2 px-6 py-2.5 text-sm font-bold disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ backgroundColor: '#7C3AED', borderColor: '#7C3AED' }}
              >
                <Zap size={16} /> Generate Intelligence
              </button>
              {(!selectedDrug || selectedPayers.length === 0) && (
                <p className="text-xs text-gray-400">
                  {!selectedDrug ? 'Select a drug to continue.' : 'Select at least one payer to continue.'}
                </p>
              )}
            </div>
            <p className="text-[10px] text-gray-400 mt-3 leading-relaxed">
              Intelligence is generated on-demand. Policies are identified, conditions extracted, and criteria normalised across all selected payers.
            </p>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════
          STEP: PROCESSING
      ══════════════════════════════════════════ */}
      {step === 'processing' && (
        <div className="space-y-4">
          {/* Processing status */}
          <div className="card py-5 px-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: '#EDE9FE' }}>
                <Loader2 size={16} style={{ color: '#7C3AED' }} className="animate-spin" />
              </div>
              <div>
                <h2 className="font-bold text-brand-navy text-sm">Generating Clinical Criteria Intelligence</h2>
                <p className="text-[10px] text-gray-400">
                  {selectedDrug} · {selectedPayers.join(', ')}
                </p>
              </div>
            </div>
            <div className="pl-2 border-l-2 border-gray-100 ml-4 space-y-0.5">
              {procSteps.map(s => (
                <ProcessingStep key={s.id} label={s.label} status={s.status} />
              ))}
            </div>
          </div>

          {/* Policy identification */}
          <div className="card py-5 px-5">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Source Policy Identification</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {selectedPayers.map(p => (
                <PolicyCard
                  key={p}
                  payer={p}
                  policy={POLICY_SOURCES[p]}
                  status={policyStatuses[p] || 'searching'}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════
          STEP: RESULTS
      ══════════════════════════════════════════ */}
      {step === 'results' && criteriaData && (
        <div className="space-y-4">

          {/* Source policies summary */}
          <div className="card py-4 px-5">
            <div className="flex items-center justify-between mb-3">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Source Policies</p>
              <span className="text-[10px] text-gray-400">{selectedPayers.length} payers · {conditions.length} conditions identified</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {selectedPayers.map(p => (
                <div key={p} className="flex items-start gap-2.5 rounded-lg p-2.5 bg-gray-50 border border-gray-100">
                  <CheckCircle size={13} className="text-emerald-500 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-bold text-gray-700">{p}</span>
                      <div className="relative">
                        <button
                          onClick={() => setSourceOpen(s => s === p ? null : p)}
                          className="text-[10px] text-gray-400 hover:text-brand-navy flex items-center gap-0.5 font-semibold"
                        >
                          <FileText size={9} /> Source
                        </button>
                        {sourceOpen === p && POLICY_SOURCES[p] && (
                          <div className="absolute right-0 top-full mt-1 z-30 bg-white border border-gray-200 rounded-xl shadow-xl p-3 w-72 text-xs">
                            <p className="font-bold text-gray-700 mb-1 leading-snug">{POLICY_SOURCES[p].name}</p>
                            <p className="text-gray-400 mb-1">Effective: {POLICY_SOURCES[p].date}</p>
                            <a href={POLICY_SOURCES[p].url} className="flex items-center gap-1 text-brand-navy font-semibold hover:underline">
                              <ExternalLink size={10} /> View Policy Document
                            </a>
                          </div>
                        )}
                      </div>
                    </div>
                    <p className="text-[10px] text-gray-500 truncate mt-0.5">{POLICY_SOURCES[p]?.name || 'Policy found'}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Condition tabs */}
          <div className="card py-4 px-5">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Conditions</p>
            <div className="flex flex-wrap gap-2">
              {conditions.map(cond => {
                const active = activeCondition === cond;
                return (
                  <button key={cond} onClick={() => setActiveCondition(cond)}
                    className="text-sm font-semibold px-4 py-1.5 rounded-full border transition-all"
                    style={{
                      backgroundColor: active ? '#7C3AED' : '#fff',
                      borderColor:     active ? '#7C3AED' : '#E5E7EB',
                      color:           active ? '#fff'    : '#374151',
                    }}>
                    {cond}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Diff summary bar */}
          <div className="card py-3 px-5 flex flex-wrap items-center gap-4">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
              {activeCondition}
            </span>
            <div className="flex items-center gap-3 flex-wrap ml-auto">
              {Object.entries(STATUS).map(([k, v]) => (
                <span key={k} className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded"
                  style={{ backgroundColor: v.bg, color: v.text }}>
                  <span className="text-[11px] font-extrabold">{diffSummary[k] || 0}</span>
                  {v.label}
                </span>
              ))}
              <span className="text-[10px] text-gray-400">vs. <strong className="text-brand-navy">Elevance</strong> baseline</span>
            </div>
          </div>

          {/* Criteria sections */}
          {Object.entries(criteriaData).map(([sectionKey, section]) => {
            const isOpen = !collapsed[sectionKey];
            const sectionColors = {
              quantity_limits:    { color: '#0891B2', bg: '#E0F6FF' },
              duration:           { color: '#059669', bg: '#EDFFF8' },
              clinical_criteria:  { color: '#7C3AED', bg: '#EDE9FE' },
              additional_criteria:{ color: '#B45309', bg: '#FFF8E8' },
            };
            const sc = sectionColors[sectionKey] || { color: '#1A3673', bg: '#E8F0FF' };

            // Merge user-added rows
            const extraRows = (corrections[`__add__${sectionKey}`] || []);
            const allRows = [...section.rows, ...extraRows];

            return (
              <div key={sectionKey} className="card p-0 overflow-hidden">
                {/* Section header */}
                <button
                  className="w-full flex items-center justify-between px-5 py-3 text-left"
                  style={{ backgroundColor: sc.bg }}
                  onClick={() => toggleSection(sectionKey)}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider" style={{ color: sc.color }}>
                      {section.label}
                    </span>
                    <span className="text-[10px] text-gray-400">{allRows.length} criteria</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={e => { e.stopPropagation(); setAddModal({ sectionKey, sectionLabel: section.label }); }}
                      className="text-[10px] font-bold flex items-center gap-0.5 px-2 py-0.5 rounded hover:bg-white/50 transition-colors"
                      style={{ color: sc.color }}
                      title="Add missing criterion"
                    >
                      <Plus size={10} /> Add Criterion
                    </button>
                    {isOpen ? <ChevronUp size={13} style={{ color: sc.color }} /> : <ChevronDown size={13} style={{ color: sc.color }} />}
                  </div>
                </button>

                {/* Table */}
                {isOpen && (
                  <div className="overflow-x-auto">
                    <table className="text-left w-full" style={{ borderCollapse: 'separate', borderSpacing: 0, minWidth: 780 }}>
                      <thead>
                        <tr>
                          <th className="px-4 py-2.5 text-[10px] font-bold text-gray-500 uppercase tracking-wider bg-gray-50 border-b border-gray-200 sticky left-0 z-10" style={{ minWidth: 220 }}>
                            Criteria
                          </th>
                          <th className="px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider border-b border-gray-200 text-center" style={{ minWidth: 180, backgroundColor: '#E8F0FF', color: '#1A3673' }}>
                            <div className="flex items-center justify-center gap-1">
                              Elevance <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-brand-navy text-white">BASELINE</span>
                            </div>
                          </th>
                          {selectedPayers.map(p => (
                            <th key={p} className="px-4 py-2.5 text-[10px] font-bold text-gray-500 uppercase tracking-wider bg-gray-50 border-b border-gray-200 text-center" style={{ minWidth: 170 }}>
                              {p}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {allRows.map((row, rowIdx) => {
                          const isUserAdded = rowIdx >= section.rows.length;
                          return (
                            <tr key={rowIdx} className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors">
                              {/* Criterion name */}
                              <td className="px-4 py-3 align-top sticky left-0 bg-white border-b border-gray-100 z-10" style={{ minWidth: 220 }}>
                                <div className="flex items-start gap-1">
                                  <p className="text-xs font-bold text-gray-800 leading-snug flex-1">{row.criterion}</p>
                                  {isUserAdded && (
                                    <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 shrink-0">User Added</span>
                                  )}
                                </div>
                              </td>

                              {/* Elevance */}
                              <td className="px-3 py-3 align-top border-b border-gray-100" style={{ backgroundColor: '#F5F8FF' }}>
                                <ElevanceCell value={row.elevance} />
                              </td>

                              {/* Competitor payers */}
                              {selectedPayers.map(p => {
                                const correction = corrections[sectionKey]?.[rowIdx]?.[p];
                                const cell = correction || row.payers[p] || { value: 'Not mentioned', status: 'not_mentioned' };
                                const isCorrected = !!correction;
                                return (
                                  <td key={p} className="px-3 py-3 align-top border-b border-gray-100">
                                    <div className="relative">
                                      <CriteriaCell
                                        value={cell.value}
                                        status={cell.status}
                                        onEdit={() => setEditModal({
                                          sectionKey,
                                          rowIdx,
                                          payer: p,
                                          criterion: row.criterion,
                                          value: cell.value,
                                          status: cell.status,
                                        })}
                                      />
                                      {isCorrected && (
                                        <div className="flex items-center gap-1 mt-1">
                                          <span className="text-[8px] font-bold text-amber-600 flex items-center gap-0.5">
                                            <Edit2 size={7} /> Corrected
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                  </td>
                                );
                              })}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}

          {/* Legend */}
          <div className="card py-3 px-5 flex flex-wrap items-center gap-3">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Legend:</span>
            {Object.entries(STATUS).map(([k, v]) => (
              <span key={k} className="flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded"
                style={{ backgroundColor: v.bg, color: v.text }}>
                {k === 'match'          && <Check size={9} />}
                {k === 'different'      && <AlertTriangle size={9} />}
                {k === 'not_mentioned'  && <Minus size={9} />}
                {k === 'not_applicable' && <Info size={9} />}
                {v.label}
              </span>
            ))}
            <span className="text-[10px] text-gray-400 ml-auto">
              Hover any cell to edit · Corrections are saved locally
            </span>
          </div>

          {/* Feedback panel */}
          <div className="card py-4 px-5">
            <div className="flex items-center gap-2 mb-3">
              <MessageSquare size={14} style={{ color: '#7C3AED' }} />
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Feedback on this Intelligence</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border border-emerald-200 text-emerald-700 hover:bg-emerald-50 transition-colors">
                <ThumbsUp size={12} /> Accurate
              </button>
              <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 transition-colors">
                <ThumbsDown size={12} /> Needs Correction
              </button>
              <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border border-amber-200 text-amber-700 hover:bg-amber-50 transition-colors">
                <Flag size={12} /> Flag for Review
              </button>
              <span className="text-[10px] text-gray-400 ml-auto">
                Feedback helps improve future intelligence generation.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ── MODALS ── */}
      {editModal && (
        <EditModal
          criterion={editModal.criterion}
          payer={editModal.payer}
          currentValue={editModal.value}
          currentStatus={editModal.status}
          onSave={(value, status) => applyCorrection(editModal.sectionKey, editModal.rowIdx, editModal.payer, value, status)}
          onClose={() => setEditModal(null)}
        />
      )}

      {addModal && (
        <AddCriterionModal
          section={addModal.sectionLabel}
          payers={selectedPayers}
          onSave={(newRow) => {
            const key = `__add__${addModal.sectionKey}`;
            setCorrections(prev => ({
              ...prev,
              [key]: [...(prev[key] || []), {
                criterion: newRow.criterion,
                elevance: newRow.elevance,
                payers: Object.fromEntries(
                  Object.entries(newRow.payers).map(([p, v]) => [p, { value: v.value || 'Not mentioned', status: v.status }])
                ),
              }],
            }));
          }}
          onClose={() => setAddModal(null)}
        />
      )}
    </div>
  );
}
