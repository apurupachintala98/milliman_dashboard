import { useState } from 'react';
import { login } from '../services/authService';
import { useErrorToast } from '../hooks/useErrorToast';

const FEATURES = [
  { icon: '⚡', label: 'AI-powered competitive intelligence' },
  { icon: '✓', label: 'Audit compliance & traceability' },
  { icon: '🔒', label: 'Role-based access control' },
];

export default function SignIn({ onSignIn, notice = '' }) {
  const [empId, setEmpId] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const notifyError = useErrorToast();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(empId.trim(), password);
      onSignIn(user);
    } catch (err) {
      notifyError(err, 'sign you in');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen w-full flex flex-col" style={{ background: '#f0f2f5' }}>

      {/* Top nav bar */}
      <header className="w-full bg-brand-navy flex items-center px-8 py-3 gap-3 shrink-0">
        <div className="flex items-center gap-3">
          {/* Elevance Health chevron logo */}
          <svg width="28" height="20" viewBox="0 0 28 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 14L14 4L24 14" stroke="#44B8F3" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-white font-semibold tracking-wide" style={{ fontSize: 13.5 }}>Elevance Health</span>
        </div>
        <span className="text-white/30 text-xs">|</span>
        <span className="text-white/70 text-xs">RX Competitive Intelligence</span>
      </header>

      {/* Body */}
      <div className="flex-1 flex items-center justify-center px-8 py-16">
        <div className="w-full max-w-4xl flex items-center gap-20">

          {/* Left — branding & description */}
          <div className="flex-1 min-w-0">
            {/* Logo lockup */}
            <div className="flex items-center gap-2 mb-5">
              <svg width="30" height="22" viewBox="0 0 28 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 14L14 4L24 14" stroke="#44B8F3" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-brand-coral text-xs font-bold tracking-widest uppercase">Elevance Health</span>
            </div>

            {/* Headline */}
            <h1 className="text-brand-navy leading-tight mb-1" style={{ fontSize: 34, fontWeight: 300 }}>
              RX Competitive
            </h1>
            <h2 className="text-brand-navy font-bold mb-5" style={{ fontSize: 34 }}>
              Intelligence Platform
            </h2>

            {/* Description */}
            <p className="text-gray-500 text-sm leading-relaxed max-w-xs mb-7">
              Turning AI-driven competitive analysis into actionable insights for Carelon’s Commercial business across Designated Network, Preventive Rx and Clinical Criteria.
            </p>

            {/* Feature list */}
            <ul className="space-y-2.5 mb-10">
              {FEATURES.map(f => (
                <li key={f.label} className="flex items-center gap-2.5 text-sm text-gray-600">
                  <span className="text-base leading-none">{f.icon}</span>
                  {f.label}
                </li>
              ))}
            </ul>

            {/* Decorative chevrons */}
            <div className="flex items-center gap-1 opacity-20">
              {[...Array(5)].map((_, i) => (
                <svg key={i} width="20" height="28" viewBox="0 0 20 28" fill="none">
                  <path d="M4 2 L16 14 L4 26" stroke="#1A3673" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              ))}
            </div>
          </div>

          {/* Right — sign-in card */}
          <div className="w-80 shrink-0">
            <div className="bg-white rounded-xl shadow-lg px-8 py-8">
              <h3 className="text-brand-navy font-bold text-lg mb-1">Sign in</h3>
              <p className="text-gray-400 text-xs mb-6">Enter your Elevance Health Employee ID</p>

              {notice && (
                <p role="status" className="text-xs text-brand-navy bg-blue-50 border border-blue-100 rounded px-3 py-2 mb-4">{notice}</p>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1.5">Employee ID</label>
                  <input
                    className="input"
                    placeholder="E.G. ab12345"
                    value={empId}
                    onChange={e => setEmpId(e.target.value)}
                    required
                    autoComplete="username"
                    autoFocus
                    style={{ borderColor: empId ? '#1A3673' : undefined }}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1.5">Password</label>
                  <input
                    className="input"
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                    style={{ borderColor: password ? '#1A3673' : undefined }}
                  />
                </div>


                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded text-sm font-semibold text-white transition-colors flex items-center justify-center gap-2"
                  style={{ background: loading ? '#6A97DF' : '#2861BB' }}
                >
                  {loading && (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  )}
                  {loading ? 'Signing in...' : 'Sign in'}
                </button>
              </form>

              <div className="mt-6 text-center space-y-1">
                <p className="text-xs text-gray-400">Elevance Health</p>
                <p className="text-xs text-gray-300">Protected by enterprise. Contact IT for access issues.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
