
export const ENABLED_ROUTES = [
    '/workflow/designated-network',
    '/workflow/preventive-rx',
  ];
  
  export function isRouteEnabled(path) {
    if (path === '/') return true;
    return ENABLED_ROUTES.some(r => path === r || path.startsWith(`${r}/`));
  }