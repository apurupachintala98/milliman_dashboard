import { buildXlsxTable, coverageCell } from './excelTable';

const compWidth = (header) => Math.min(40, Math.max(12, header.length + 4));

/**
 * @param {object}   table
 * @param {string[]} table.columns    visible competitor keys, in on-screen order
 * @param {object[]} table.rows       rows as rendered: { drug, drugClass, hcpcs, carelon, cells: { [comp]: { covered, manual } } }
 * @param {object}   [table.payorUrls] { [comp]: url }
 * @param {object}   [table.payorNames] { [comp]: payor_nm } — header text (falls back to the code)
 * @returns {Promise<Blob>}
 */
export function buildDesignatedNetworkXlsx({ columns = [], rows = [], payorUrls = {}, payorNames = {} }) {
  return buildXlsxTable({
    sheetName: 'Priority Intelligence',
    columns: [
      { header: 'Drug Name', width: 24 },
      { header: 'Therapeutic Class', width: 50 },
      { header: 'HCPCS', width: 12 },
      { header: 'Carelon', width: 12, highlight: true },
      ...columns.map(c => {
        const header = payorNames?.[c] || c;
        return { header, width: compWidth(header), url: payorUrls?.[c] };
      }),
    ],
    rows: rows.map(r => [
      { value: r.drug, style: 'bold' },
      { value: r.drugClass, style: 'text' },
      { value: r.hcpcs, style: 'text' },
      r.carelon === 'Y' ? { value: '✓', style: 'yes' } : { value: 'Gap', style: 'gap' },
      ...columns.map(c => coverageCell(r.cells?.[c])),
    ]),
  });
}
