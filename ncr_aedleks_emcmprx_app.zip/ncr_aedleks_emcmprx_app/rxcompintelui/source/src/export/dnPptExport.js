import JSZip from 'jszip';
import { programStatusPortfolio, payorName } from '../services/designatedRx';
import templateUrl from '../assets/dn-ppt-template.pptx?url';

const SLIDE_CT = 'application/vnd.openxmlformats-officedocument.presentationml.slide+xml';
const SLIDE_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide';
const LAYOUT_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout';
const CONTENT_LAYOUT = '../slideLayouts/slideLayout34.xml'; 

// Reference palette
const NAVY = '102A43', SLATE = '536171', BLUE = '1769AA', TEAL = '0F766E', ORANGE = 'F97316', AMBER = 'FBBF24', RULE = 'D6DEE6';
const PORTFOLIO_COLORS = [BLUE, TEAL, AMBER, SLATE];
const FILL_CARELON_TAG = '<a:solidFill><a:schemeClr val="tx1"/></a:solidFill>';
const FILL_COMP_TAG = '<a:solidFill><a:schemeClr val="accent6"><a:lumMod val="75000"/></a:schemeClr></a:solidFill>';

// ── XML helpers ─────────────────────────────────────────────────────────────
const esc = (v) => String(v ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
const emu = (n) => Math.max(0, Math.round(n));

function run(text, { sz, b = false, color = NAVY }) {
  return `<a:r><a:rPr lang="en-US" sz="${sz}"${b ? ' b="1"' : ''} dirty="0"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:rPr><a:t>${esc(text)}</a:t></a:r>`;
}
function para(runs, { sz, algn } = {}) {
  return `<a:p><a:pPr marL="0" indent="0"${algn ? ` algn="${algn}"` : ''}><a:buNone/></a:pPr>${runs}<a:endParaRPr lang="en-US" sz="${sz}" dirty="0"/></a:p>`;
}

/** Text box / filled box in the reference's style (rect, no outline, zero insets). */
function textShape(ctx, { name, x, y, cx, cy, paras, fill = null, fillXml: rawFill = null, anchor = 'ctr', autofit = true, inset = 0 }) {
  const id = ctx.nextId++;
  const fillXml = rawFill || (fill ? `<a:solidFill><a:srgbClr val="${fill}"/></a:solidFill>` : '<a:noFill/>');
  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${esc(name)} ${id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>`
    + `<p:spPr><a:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${emu(cx)}" cy="${emu(cy)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fillXml}<a:ln/></p:spPr>`
    + `<p:txBody><a:bodyPr wrap="square" lIns="${inset}" tIns="${inset}" rIns="${inset}" bIns="${inset}" rtlCol="0" anchor="${anchor}">${autofit ? '<a:normAutofit/>' : ''}</a:bodyPr><a:lstStyle/>${paras}</p:txBody></p:sp>`;
}

/** Solid bar, as in ref. slide 5 (fill + matching 1pt outline). */
function barShape(ctx, { x, y, cx, cy, color }) {
  const id = ctx.nextId++;
  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Bar ${id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>`
    + `<p:spPr><a:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${emu(cx)}" cy="${emu(cy)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>`
    + `<a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:ln w="12700"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:prstDash val="solid"/></a:ln></p:spPr>`
    + `<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>`;
}

/** Hairline rule, as ref. slide 4 "Shape 2". */
function ruleShape(ctx, { x, y, cx }) {
  const id = ctx.nextId++;
  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Rule ${id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>`
    + `<p:spPr><a:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${emu(cx)}" cy="0"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/>`
    + `<a:ln w="12700"><a:solidFill><a:srgbClr val="${RULE}"/></a:solidFill><a:prstDash val="solid"/></a:ln></p:spPr>`
    + `<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>`;
}

/** A content slide in the reference's frame: layout 34 (header band, logo, page number) + title placeholder. */
function contentSlide(frame, title, shapesXml) {
  const titleSp = `<p:sp><p:nvSpPr><p:cNvPr id="2" name="Title 1"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>`
    + `<p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>${esc(title)}</a:t></a:r></a:p></p:txBody></p:sp>`;
  return frame.head + titleSp + shapesXml + frame.tail;
}

/** Splits a reference slide into the part before its first shape and the part after its shape tree. */
function slideFrame(xml) {
  const head = xml.slice(0, xml.indexOf('</p:grpSpPr>') + '</p:grpSpPr>'.length);
  // Drop the per-slide p14:creationId so generated copies don't share one
  const tail = xml.slice(xml.indexOf('</p:spTree>')).replace(/<p:extLst>.*?<\/p:extLst>(?=<\/p:cSld>)/s, '');
  return { head, tail };
}

// ── Data shaping (mirrors what the page shows) ──────────────────────────────

function overlapFor(model, comp) {
  const api = model.compOverlap?.[comp];
  if (api) return api;
  const commonDrugs = [], carOnlyDrugs = [], compOnlyDrugs = [];
  for (const d of model.drugs || []) {
    const car = d.carelon === 'Y', other = d[comp] === 'Y';
    if (car && other) commonDrugs.push(d.drug);
    else if (car) carOnlyDrugs.push(d.drug);
    else if (other) compOnlyDrugs.push(d.drug);
  }
  return { common: commonDrugs.length, carOnly: carOnlyDrugs.length, compOnly: compOnlyDrugs.length, commonDrugs, carOnlyDrugs, compOnlyDrugs };
}

// competitors: [{ name, count }] sorted by count — the list the page shows when a bar is expanded
function portfolioRows(model) {
  return programStatusPortfolio(model).map(r => ({ label: r.label, count: r.count, competitors: r.competitors }));
}

const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };

// One line at 12pt across the slide holds ~110 characters; keep "+N more" on the same line
function examples(list, maxChars = 100) {
  if (!list?.length) return 'None';
  const shown = [];
  let len = 0;
  for (const name of list) {
    const add = (shown.length ? 5 : 0) + String(name).length;
    if (shown.length && len + add > maxChars) break;
    shown.push(name); len += add;
  }
  const rest = list.length - shown.length;
  return rest > 0 ? `${shown.join('  |  ')}  |  +${rest} more` : shown.join('  |  ');
}

// ── Slide builders ──────────────────────────────────────────────────────────

/** Ref. slide 4 — Carelon vs one competitor. */
function comparisonShapes(ctx, comp, ov) {
  const carTotal = ov.common + ov.carOnly;
  const compTotal = ov.common + ov.compOnly;
  let s = '';
  s += ruleShape(ctx, { x: 502920, y: 1207008, cx: 11155680 });
  s += textShape(ctx, { name: 'Tag', x: 685800, y: 1417320, cx: 1508760, cy: 329184, fillXml: FILL_CARELON_TAG, inset: 508,
    paras: para(run('Carelon DN list', { sz: 1250, b: true, color: 'FFFFFF' }), { sz: 1250, algn: 'ctr' }) });
  const tagW = Math.max(1234440, 320040 + `${comp} List`.length * 100584);
  s += textShape(ctx, { name: 'Tag', x: 9994392 + 1234440 - tagW, y: 1417320, cx: tagW, cy: 329184, fillXml: FILL_COMP_TAG, inset: 508,
    paras: para(run(`${comp} List`, { sz: 1250, b: true, color: 'FFFFFF' }), { sz: 1250, algn: 'ctr' }) });
  s += textShape(ctx, { name: 'Heading', x: 2880360, y: 1417320, cx: 6309360, cy: 301752,
    paras: para(run('Normalized brand-name comparison', { sz: 1550, b: true }), { sz: 1550, algn: 'ctr' }) });
  s += textShape(ctx, { name: 'Total', x: 658368, y: 1920240, cx: 1508760, cy: 384048, autofit: false,
    paras: para(run(String(carTotal), { sz: 2400, b: true, color: TEAL }), { sz: 2400, algn: 'ctr' }) });
  s += textShape(ctx, { name: 'Unit', x: 502920, y: 2340864, cx: 1874520, cy: 292608, autofit: false,
    paras: para(run('Drugs', { sz: 1600, b: true, color: SLATE }), { sz: 1600, algn: 'ctr' }) });
  s += textShape(ctx, { name: 'Total', x: 9692640, y: 1920240, cx: 1874520, cy: 384048, autofit: false,
    paras: para(run(String(compTotal), { sz: 2400, b: true, color: ORANGE }), { sz: 2400, algn: 'ctr' }) });
  s += textShape(ctx, { name: 'Unit', x: 9646920, y: 2340864, cx: 1920240, cy: 292608, autofit: false,
    paras: para(run('Drugs', { sz: 1600, b: true, color: SLATE }), { sz: 1600, algn: 'ctr' }) });

  // Stacked bar: Our list only | Common | {comp} only — widths proportional to counts
  const BAR_X = 2706165, BAR_W = 6712155, BAR_Y = 1993392, BAR_H = 658368, MIN_W = 1280160;
  const segs = [
    { label: 'Our list only', n: ov.carOnly, color: TEAL },
    { label: 'Common', n: ov.common, color: BLUE },
    { label: `${comp} only`, n: ov.compOnly, color: ORANGE },
  ].filter(g => g.n > 0);
  const total = segs.reduce((a, g) => a + g.n, 0);
  if (total > 0) {
    // proportional widths, with a minimum so each label stays readable
    let widths = segs.map(g => (g.n / total) * BAR_W);
    const small = widths.map(w => w < MIN_W);
    const reserved = small.filter(Boolean).length * MIN_W;
    const restTotal = segs.reduce((a, g, i) => a + (small[i] ? 0 : g.n), 0);
    widths = widths.map((w, i) => (small[i] ? MIN_W : restTotal ? (segs[i].n / restTotal) * (BAR_W - reserved) : w));
    let x = BAR_X;
    segs.forEach((g, i) => {
      s += textShape(ctx, { name: 'Segment', x, y: BAR_Y, cx: widths[i], cy: BAR_H, fill: g.color, inset: 254,
        paras: para(run(g.label, { sz: 1220, b: true, color: 'FFFFFF' }), { sz: 1220, algn: 'ctr' })
             + para(run(String(g.n), { sz: 1220, b: true, color: 'FFFFFF' }), { sz: 1220, algn: 'ctr' }) });
      x += widths[i];
    });
  }

  const lists = [
    { title: 'Common examples', color: BLUE, items: ov.commonDrugs, y: 3246120 },
    { title: 'Our list only examples', color: TEAL, items: ov.carOnlyDrugs, y: 4160520 },
    { title: `${comp}-only examples`, color: ORANGE, items: ov.compOnlyDrugs, y: 5074920 },
  ];
  for (const l of lists) {
    s += textShape(ctx, { name: 'Label', x: 777240, y: l.y, cx: 4572000, cy: 237744,
      paras: para(run(l.title, { sz: 1300, b: true, color: l.color }), { sz: 1300 }) });
    s += textShape(ctx, { name: 'Examples', x: 777240, y: l.y + 274320, cx: 10652760, cy: 365760, inset: 381,
      paras: para(run(examples(l.items), { sz: 1210 }), { sz: 1210 }) });
  }
  return s;
}

const PORTFOLIO_ROWS_PER_SLIDE = 4;

const PORTFOLIO_COMP_MAX_CHARS = 180; // ≈ two lines at 11pt under the bar

/** Competitors behind one bar, as on the page's expanded row: "UHC · BCBS_TX · … +N more" (name in the bar color). */
function portfolioCompetitorRuns(competitors, color) {
  if (!competitors?.length) return run('No competitors', { sz: 1100, color: SLATE });
  const shown = [];
  let len = 0;
  for (const c of competitors) {
    const add = c.name.length + (shown.length ? 5 : 0);
    if (shown.length && len + add > PORTFOLIO_COMP_MAX_CHARS) break;
    shown.push(c); len += add;
  }
  const more = competitors.length - shown.length;
  return shown.map((c, i) => (i ? run('  ·  ', { sz: 1100, color: SLATE }) : '')
    + run(c.name, { sz: 1100, b: true, color })).join('')
    + (more > 0 ? run(`  ·  +${more} more`, { sz: 1100, b: true, color: SLATE }) : '');
}

/** Ref. slide 5 — label | bar | count rows, each followed by the competitors that make up the bar. */
function portfolioShapes(ctx, rows, maxCount) {
  const ROW0 = 1965960, STEP = 896112, BAR_X = 2880360, BAR_MAX = 4389120, RIGHT = 11658600;
  let s = textShape(ctx, { name: 'Subtitle', x: 786384, y: 1481328, cx: 5669280, cy: 301752, autofit: false,
    paras: para(run('Program status distribution from the uploaded workbook', { sz: 1600, b: true }), { sz: 1600 }) });
  rows.forEach((r, i) => {
    const y = ROW0 + i * STEP;
    const color = PORTFOLIO_COLORS[r.colorIndex % PORTFOLIO_COLORS.length];
    s += textShape(ctx, { name: 'Label', x: 822960, y, cx: 1920240, cy: 329184,
      paras: para(run(r.label, { sz: 1350, b: true }), { sz: 1350 }) });
    if (r.count > 0) s += barShape(ctx, { x: BAR_X, y: y + 18288, cx: (r.count / maxCount) * BAR_MAX, cy: 292608, color });
    s += textShape(ctx, { name: 'Count', x: 7424928, y: y - 9144, cx: 502920, cy: 320040, autofit: false,
      paras: para(run(String(r.count), { sz: 1350, b: true }), { sz: 1350 }) });
    s += textShape(ctx, { name: 'Competitors', x: BAR_X, y: y + 365760, cx: RIGHT - BAR_X, cy: 457200, anchor: 't',
      paras: para(portfolioCompetitorRuns(r.competitors, color), { sz: 1100 }) });
  });
  return s;
}

/** "Covered by 22 competitors: A, B, C, …" — the full payor name list (wraps; rows grow to fit). */
function coveredByText(competitors, isAdd) {
  if (!competitors?.length) return 'No competitor coverage';
  return `${isAdd ? 'Covered by' : 'Still covered by'} ${competitors.length} competitor${competitors.length === 1 ? '' : 's'}: ${competitors.join(', ')}`;
}

// AI recommendation slide layout (EMU). Rows are sized to their wrapped text and paginated across slides.
const REC = {
  X: 786384, FULL_W: 10607040, SIDE_X: 8869680,
  ROW0: 1965960, BOTTOM: 6217920,              // first row top / last usable y (above logo + page number)
  DRUG_H: 283464, GAP: 182880,                 // drug-name line, space between rows (holds the rule)
  REASON_LINE_H: 158496, COVERED_LINE_H: 150876,
  REASON_CHARS: 175, COVERED_CHARS: 185,       // ≈ characters per line across the full width (10pt / 9.5pt)
};
const recTextWidth = r => (r.confidence != null || r.impact ? REC.SIDE_X - REC.X - 182880 : REC.FULL_W);
const wrapLines = (text, charsPerLine) => Math.max(1, Math.ceil(String(text || '').length / charsPerLine));

/** Height of one recommendation row: drug line + wrapped reason + wrapped "Covered by" list. */
function recLayout(r) {
  const scale = recTextWidth(r) / REC.FULL_W;
  const covered = coveredByText(r.competitors, r.type !== 'remove');
  const textH = wrapLines(r.reason, REC.REASON_CHARS * scale) * REC.REASON_LINE_H
    + wrapLines(covered, REC.COVERED_CHARS * scale) * REC.COVERED_LINE_H;
  return { covered, textH, height: REC.DRUG_H + textH + REC.GAP };
}

/** Split recommendations into slides so every row (with its full payor list) fits. */
export function paginateRecommendations(recs) {
  const pages = [];
  let page = [], used = 0;
  for (const r of recs) {
    const h = recLayout(r).height;
    if (page.length && REC.ROW0 + used + h > REC.BOTTOM) { pages.push(page); page = []; used = 0; }
    page.push(r); used += h;
  }
  if (page.length) pages.push(page);
  return pages;
}

/** AI recommendations — same palette, type scale, bars and rules as the reference (no Add/Remove tag). */
function recommendationShapes(ctx, recs, subtitle) {
  const { X, FULL_W, SIDE_X } = REC;
  let s = textShape(ctx, { name: 'Subtitle', x: X, y: 1481328, cx: FULL_W, cy: 301752,
    paras: para(run(subtitle, { sz: 1600, b: true }), { sz: 1600 }) });
  let y = REC.ROW0;
  recs.forEach((r, i) => {
    const impactColor = r.impact === 'High' ? ORANGE : r.impact === 'Medium' ? BLUE : SLATE;
    const textW = recTextWidth(r); // spans the slide unless the confidence/impact column is shown
    const { covered, textH, height } = recLayout(r);
    if (i > 0) s += ruleShape(ctx, { x: X, y: y - 68580, cx: FULL_W });
    s += textShape(ctx, { name: 'Drug', x: X, y, cx: textW, cy: REC.DRUG_H,
      paras: para(run(r.drug, { sz: 1350, b: true }) + (r.drugClass ? run(`   ${r.drugClass}`, { sz: 1100, color: SLATE }) : ''), { sz: 1350 }) });
    s += textShape(ctx, { name: 'Reason', x: X, y: y + REC.DRUG_H, cx: textW, cy: textH, anchor: 't', autofit: false,
      paras: para(run(r.reason, { sz: 1000 }), { sz: 1000 }) + para(run(covered, { sz: 950, color: SLATE }), { sz: 950 }) });
    // Confidence bar (track + value) and impact — only when the API sends them
    if (r.confidence != null) {
      s += textShape(ctx, { name: 'Label', x: SIDE_X, y, cx: 1463040, cy: 228600,
        paras: para(run('AI confidence', { sz: 1000, b: true, color: SLATE }), { sz: 1000 }) });
      s += barShape(ctx, { x: SIDE_X, y: y + 274320, cx: 1645920, cy: 146304, color: RULE });
      if (r.confidence > 0) s += barShape(ctx, { x: SIDE_X, y: y + 274320, cx: 1645920 * (r.confidence / 100), cy: 146304, color: r.confidence >= 85 ? TEAL : r.confidence >= 70 ? AMBER : ORANGE });
      s += textShape(ctx, { name: 'Pct', x: 10607040, y: y + 210312, cx: 786384, cy: 274320, autofit: false,
        paras: para(run(`${r.confidence}%`, { sz: 1200, b: true }), { sz: 1200 }) });
    }
    if (r.impact) s += textShape(ctx, { name: 'Impact', x: SIDE_X, y: y + 484632, cx: 2523744, cy: 228600,
      paras: para(run(`${r.impact} impact`, { sz: 1050, b: true, color: impactColor }), { sz: 1050 }) });
    y += height;
  });
  return s;
}

/** Priority Intelligence table — native PowerPoint table, styled like the on-screen table. */
const PI_ROWS_PER_SLIDE = 12;
const GREEN = '10B981', RED = 'EF4444', MUTED = '9CA3AF', HEAD_BG = 'F3F4F6', CARELON_HEAD_BG = 'EBF3FF';
const MANDATORY_BG = 'EEF4FF', MANDATORY_CARELON_BG = 'DDEAFF', CARELON_BG = 'EBF3FF';

function cell(text, { sz = 1000, b = false, color = NAVY, fill = null, algn = 'l' } = {}) {
  const fillXml = fill ? `<a:solidFill><a:srgbClr val="${fill}"/></a:solidFill>` : '<a:noFill/>';
  const none = (tag) => `<a:${tag} w="0"><a:noFill/></a:${tag}>`;
  return `<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr algn="${algn}"/>`
    + `<a:r><a:rPr lang="en-US" sz="${sz}"${b ? ' b="1"' : ''} dirty="0"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:rPr><a:t>${esc(text)}</a:t></a:r></a:p></a:txBody>`
    + `<a:tcPr marL="91440" marR="91440" marT="27432" marB="27432" anchor="ctr">${none('lnL')}${none('lnR')}${none('lnT')}`
    + `<a:lnB w="6350"><a:solidFill><a:srgbClr val="${RULE}"/></a:solidFill></a:lnB>${fillXml}</a:tcPr></a:tc>`;
}

function piTableFrame(ctx, { x, y, colWidths, headH, rowH, rowsXml }) {
  const id = ctx.nextId++;
  const w = colWidths.reduce((a, b) => a + b, 0);
  const h = headH + rowH * rowsXml.length;
  return `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${id}" name="Priority Intelligence Table ${id}"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>`
    + `<p:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${emu(w)}" cy="${emu(h)}"/></p:xfrm>`
    + `<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1"/>`
    + `<a:tblGrid>${colWidths.map(c => `<a:gridCol w="${emu(c)}"/>`).join('')}</a:tblGrid>`
    + rowsXml.map((r, i) => `<a:tr h="${emu(i === 0 ? headH : rowH)}">${r}</a:tr>`).join('')
    + `</a:tbl></a:graphicData></a:graphic></p:graphicFrame>`;
}

function priorityTableShapes(ctx, table, pageRows, { heading, filters }) {
  const X = 502920, Y = 1874520, W = 11155680, HEAD_H = 320040, ROW_H = 301752;
  const comps = table.columns || [];
  // Fixed columns as on screen (Drug, Class, HCPCS, Carelon); competitors share the rest
  let fixed = [2011680, 1920240, 777240, 868680];
  const minComp = 548640;
  if (comps.length) {
    const room = W - fixed.reduce((a, b) => a + b, 0);
    if (room / comps.length < minComp) {               // many competitor columns: shrink text columns
      const need = minComp * comps.length - room;
      fixed = [fixed[0] - need * 0.5, fixed[1] - need * 0.5, fixed[2], fixed[3]].map(v => Math.max(v, 640080));
    }
  }
  // Competitor columns never wider than needed; spare width goes to Drug Name / Therapeutic Class
  const MAX_COMP = 1280160;
  let compW = comps.length ? (W - fixed.reduce((a, b) => a + b, 0)) / comps.length : 0;
  if (compW > MAX_COMP || !comps.length) {
    const spare = W - fixed.reduce((a, b) => a + b, 0) - (comps.length ? MAX_COMP * comps.length : 0);
    compW = comps.length ? MAX_COMP : 0;
    fixed = [fixed[0] + spare * 0.35, fixed[1] + spare * 0.65, fixed[2], fixed[3]];
  }
  const colWidths = [...fixed, ...comps.map(() => compW)];
  // Keep every row on one line (row height is fixed): trim text to what fits its column at its font size
  const fit = (text, width, sz) => {
    const t = String(text ?? '');
    const max = Math.max(4, Math.floor((width - 182880) / (sz * 64)));   // ≈ avg glyph width at this size
    return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t;
  };

  let s = textShape(ctx, { name: 'Subtitle', x: 786384, y: 1325880, cx: 10607040, cy: 301752, autofit: false,
    paras: para(run(heading, { sz: 1600, b: true }), { sz: 1600 }) });
  s += textShape(ctx, { name: 'Filters', x: 786384, y: 1600200, cx: 10607040, cy: 228600, autofit: false,
    paras: para(run(filters, { sz: 1100, color: SLATE }), { sz: 1100 }) });

  if (!pageRows.length) {
    s += textShape(ctx, { name: 'Empty', x: X, y: Y, cx: W, cy: 640080, autofit: false,
      paras: para(run('No drugs match the filters applied in the application.', { sz: 1350, color: SLATE }), { sz: 1350, algn: 'ctr' }) });
    return s;
  }

  const head = cell('DRUG NAME', { sz: 900, b: true, color: SLATE, fill: HEAD_BG })
    + cell('THERAPEUTIC CLASS', { sz: 900, b: true, color: SLATE, fill: HEAD_BG })
    + cell('HCPCS', { sz: 900, b: true, color: SLATE, fill: HEAD_BG })
    + cell('CARELON', { sz: 900, b: true, color: '1A3673', fill: CARELON_HEAD_BG, algn: 'ctr' })
    + comps.map(c => cell(c.toUpperCase(), { sz: 900, b: true, color: SLATE, fill: HEAD_BG, algn: 'ctr' })).join('');

  const body = pageRows.map(r => {
    const mand = r.programType === 'Mandatory';
    const bg = mand ? MANDATORY_BG : null;
    return cell(fit(`${mand ? '● ' : ''}${r.drug}`, colWidths[0], 1150), { sz: 1050, b: true, color: mand ? '1A3673' : '374151', fill: bg })
      + cell(fit(r.drugClass, colWidths[1], 950), { sz: 950, color: SLATE, fill: bg })
      + cell(r.hcpcs, { sz: 950, color: MUTED, fill: bg })
      + (r.carelon === 'Y'
        ? cell('✓', { sz: 1200, b: true, color: GREEN, fill: mand ? MANDATORY_CARELON_BG : CARELON_BG, algn: 'ctr' })
        : cell('Gap', { sz: 1000, b: true, color: RED, fill: mand ? MANDATORY_CARELON_BG : CARELON_BG, algn: 'ctr' }))
      + comps.map(c => {
        const v = r.cells?.[c] || { covered: false, manual: false };
        if (v.manual) return cell(v.covered ? '✓' : '✗', { sz: 1200, b: true, color: v.covered ? ORANGE : RED, fill: bg, algn: 'ctr' });
        return v.covered
          ? cell('✓', { sz: 1200, b: true, color: GREEN, fill: bg, algn: 'ctr' })
          : cell('—', { sz: 1000, color: 'D1D5DB', fill: bg, algn: 'ctr' });
      }).join('');
  });

  s += piTableFrame(ctx, { x: X, y: Y, colWidths, headH: HEAD_H, rowH: ROW_H, rowsXml: [head, ...body] });

  // Legend, as under the on-screen table
  const legendY = Y + HEAD_H + ROW_H * pageRows.length + 91440;   // rows never wrap (text is fitted), so heights are exact
  s += textShape(ctx, { name: 'Legend', x: X, y: legendY, cx: W, cy: 228600, autofit: false,
    paras: para(
      run('● ', { sz: 900, color: '1A3673' }) + run('Mandatory row     ', { sz: 900, color: MUTED })
      + run('✓ ', { sz: 900, b: true, color: GREEN }) + run('Covered (source data)     ', { sz: 900, color: MUTED })
      + run('✓ ✗ ', { sz: 900, b: true, color: ORANGE }) + run('Manually edited     ', { sz: 900, color: MUTED })
      + run('— ', { sz: 900, color: MUTED }) + run('Not covered     ', { sz: 900, color: MUTED })
      + run('Gap ', { sz: 900, b: true, color: RED }) + run('Not on Carelon list', { sz: 900, color: MUTED }),
      { sz: 900 }) });
  return s;
}

function priorityTableSubtitle(table, page, pages) {
  const heading = `Drug-Level Comparison · ${table.snapshotLabel || ''}`.replace(/ · $/, '');
  const parts = [];
  const shown = table.rows.length, total = table.totalRows ?? shown;
  parts.push(shown === total ? `${shown} drugs` : `${shown} of ${total} drugs`);
  if (table.columns && table.totalColumns && table.columns.length !== table.totalColumns) parts.push(`${table.columns.length} of ${table.totalColumns} competitors`);
  if (table.search) parts.push(`search “${table.search}”`);
  if (pages > 1) parts.push(`page ${page + 1} of ${pages}`);
  return { heading, filters: `Showing ${parts.join(' · ')}` };
}

// ── Package assembly ────────────────────────────────────────────────────────

export function formatExportDate(d = new Date()) {
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

/**
 * @param {object} model   snapshot model from toSnapshotModel() (designatedRx.js)
 * @param {object} opts    { userName, date: Date, competitors: string[] (comparison order) }
 * @returns {Promise<Blob>} the .pptx
 */
export async function buildDesignatedNetworkPpt(model, { userName = '', date = new Date(), competitors, table = null } = {}) {
  const buf = await (await fetch(templateUrl)).arrayBuffer();
  const zip = await JSZip.loadAsync(buf);
  const read = (p) => zip.file(p).async('string');

  // ── Slide 1: user name + today's date (formatting comes from the placeholders)
  let s1 = await read('ppt/slides/slide1.xml');
  s1 = s1.replace(/(<p:ph type="subTitle"[^>]*\/>.*?<a:t>)[^<]*(<\/a:t>)/s, `$1${esc(userName)}$2`);
  s1 = s1.replace(/(<p:ph type="body"[^>]*idx="11"[^>]*\/>.*?<a:t>)[^<]*(<\/a:t>)/s, `$1${esc(formatExportDate(date))}$2`);
  zip.file('ppt/slides/slide1.xml', s1);

  const frame = slideFrame(await read('ppt/slides/slide5.xml'));

  // ── Build generated slides (title, shapes)
  const generated = [];

  // Priority Intelligence table — only the rows/columns the user has filtered to in the app
  // if (table) {
  //   const pages = chunk(table.rows || [], PI_ROWS_PER_SLIDE);
  //   if (!pages.length) pages.push([]);
  //   pages.forEach((rows, page) => {
  //     const ctx = { nextId: 3 };
  //     generated.push(contentSlide(frame, 'Priority Intelligence Table',
  //       priorityTableShapes(ctx, table, rows, priorityTableSubtitle(table, page, pages.length))));
  //   });
 // }
  const comps = (competitors && competitors.length ? competitors : model.compKeys) || [];
  for (const comp of comps) {
    const ctx = { nextId: 3 };
    generated.push(contentSlide(frame, 'Competitor Comparison', comparisonShapes(ctx, payorName(model, comp), overlapFor(model, comp))));
  }

  const pRows = portfolioRows(model).map((r, i) => ({ ...r, colorIndex: i }));
  const maxCount = Math.max(1, ...pRows.map(r => r.count));
  chunk(pRows, PORTFOLIO_ROWS_PER_SLIDE).forEach((rows, page, all) => {
    const ctx = { nextId: 3 };
    generated.push(contentSlide(frame, all.length > 1 ? `Competitor Source Portfolio (${page + 1}/${all.length})` : 'Competitor Source Portfolio',
      portfolioShapes(ctx, rows, maxCount)));
  });

  // Payor codes → payor_nm for display ("Covered by: AmeriHealth Administrators, …")
  const recs = (model.aiRecs || []).map(r => ({ ...r, competitors: (r.competitors || []).map(c => payorName(model, c)) }));
  // Rows grow with the full payor list, so slides hold as many recommendations as fit (continued on new slides)
  let first = 1;
  paginateRecommendations(recs).forEach((group, page, all) => {
    const ctx = { nextId: 3 };
    const last = first + group.length - 1;
    const title = page === 0 ? `AI Recommendations — Top ${recs.length}` : 'AI Recommendations (cont.)';
    const subtitle = all.length > 1
      ? `Recommendations ${first}–${last} of ${recs.length} · based on competitor coverage patterns`
      : 'Drug addition and removal recommendations based on competitor coverage patterns';
    generated.push(contentSlide(frame, title, recommendationShapes(ctx, group, subtitle)));
    first = last + 1;
  });

  // ── Remove reference slides 3–5 (and media only they used)
  let ct = await read('[Content_Types].xml');
  let presRels = await read('ppt/_rels/presentation.xml.rels');
  let pres = await read('ppt/presentation.xml');
  for (const n of [3, 4, 5]) {
    const rels = zip.file(`ppt/slides/_rels/slide${n}.xml.rels`) ? await read(`ppt/slides/_rels/slide${n}.xml.rels`) : '';
    for (const m of rels.matchAll(/Target="\.\.\/media\/([^"]+)"/g)) zip.remove(`ppt/media/${m[1]}`);
    zip.remove(`ppt/slides/slide${n}.xml`);
    zip.remove(`ppt/slides/_rels/slide${n}.xml.rels`);
    ct = ct.replace(new RegExp(`<Override PartName="/ppt/slides/slide${n}\\.xml"[^>]*/>`), '');
    const rid = new RegExp(`<Relationship Id="([^"]+)"[^>]*Target="slides/slide${n}\\.xml"[^>]*/>`).exec(presRels);
    if (rid) {
      presRels = presRels.replace(rid[0], '');
      pres = pres.replace(new RegExp(`<p:sldId id="\\d+" r:id="${rid[1]}"/>`), '');
    }
  }

  // ── Register generated slides as slide3.xml, slide4.xml, …
  let sldIds = '', nextSldId = 1000;
  generated.forEach((xml, i) => {
    const n = 3 + i, rId = `rIdDn${n}`;
    zip.file(`ppt/slides/slide${n}.xml`, xml);
    zip.file(`ppt/slides/_rels/slide${n}.xml.rels`,
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${LAYOUT_REL}" Target="${CONTENT_LAYOUT}"/></Relationships>`);
    ct = ct.replace('</Types>', `<Override PartName="/ppt/slides/slide${n}.xml" ContentType="${SLIDE_CT}"/></Types>`);
    presRels = presRels.replace('</Relationships>', `<Relationship Id="${rId}" Type="${SLIDE_REL}" Target="slides/slide${n}.xml"/></Relationships>`);
    sldIds += `<p:sldId id="${nextSldId++}" r:id="${rId}"/>`;
  });
  pres = pres.replace('</p:sldIdLst>', `${sldIds}</p:sldIdLst>`);
  zip.file('[Content_Types].xml', ct);
  zip.file('ppt/_rels/presentation.xml.rels', presRels);
  zip.file('ppt/presentation.xml', pres);

  // docProps/app.xml slide count
  const appPath = 'docProps/app.xml';
  if (zip.file(appPath)) {
    const app = (await read(appPath)).replace(/<Slides>\d+<\/Slides>/, `<Slides>${2 + generated.length}</Slides>`);
    zip.file(appPath, app);
  }

  return zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' });
}