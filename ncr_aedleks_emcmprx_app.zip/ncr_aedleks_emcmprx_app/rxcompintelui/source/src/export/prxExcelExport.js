import { buildXlsxTable, coverageCell } from './excelTable';

const listWidth = (header) => Math.min(40, Math.max(12, header.length + 4));

/**
 * Preventive Rx comparison as on screen: Drug Class | Drug | Carelon lists | competitor lists.
 * @param {object}   table
 * @param {object[]} table.carelonColumns  [{ key, label }] Carelon preventive lists (highlighted headers)
 * @param {object[]} table.compColumns     [{ key, label }] PBM / health-plan lists, in on-screen order
 * @param {object[]} table.rows            { drug, drugClass, cells: { [key]: { covered, manual } } }
 * @returns {Promise<Blob>}
 */
export function buildPreventiveRxXlsx({ carelonColumns = [], compColumns = [], rows = [] }) {
  const listKeys = [...carelonColumns, ...compColumns].map(c => c.key);
  return buildXlsxTable({
    sheetName: 'Preventive Rx Comparison',
    columns: [
      { header: 'Drug Class', width: 22 },
      { header: 'Drug', width: 30 },
      ...carelonColumns.map(c => ({ header: `Carelon ${c.label}`, width: listWidth(`Carelon ${c.label}`), highlight: true })),
      ...compColumns.map(c => ({ header: c.label, width: listWidth(c.label) })),
    ],
    rows: rows.map(r => [
      { value: r.drugClass, style: 'text' },
      { value: r.drug, style: 'bold' },
      ...listKeys.map(k => coverageCell(r.cells?.[k])),
    ]),
  });
}
