import { memo, forwardRef, useImperativeHandle, useState } from 'react';
import { CheckCircle, MinusCircle } from 'lucide-react';

const EMPTY_OVERRIDES = {};

/**
 * One Drug-Level Comparison row. Memoised: it only re-renders when its own data,
 * its own cell overrides, the visible competitor columns or the lock state change.
 * Callbacks must be stable (see DesignatedNetworkWorkflow) for the memo to hold.
 */
export const DnGridRow = memo(function DnGridRow({ index, measureRef, row, comps, rowOverrides = EMPTY_OVERRIDES, isLocked, lockedTitle, onCellClick, onCellEnter, onCellLeave }) {
  return (
    // data-index + measureRef: lets the row virtualiser measure this row's real height
    <tr ref={measureRef} data-index={index} className="transition-colors" style={{ backgroundColor: '#fff' }}>
      {/* Drug Name — sticky col 1 */}
      <td className="px-4 py-2.5 whitespace-nowrap border-b border-gray-100"
        style={{ position: 'sticky', left: 0, zIndex: 10, backgroundColor: '#fff', minWidth: 180, isolation: 'isolate' }}>
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-semibold text-gray-700">{row.drug}</span>
        </div>
      </td>
      {/* Therapeutic Class — sticky col 2 */}
      <td className="px-4 py-2.5 text-xs text-gray-500 whitespace-nowrap border-b border-gray-100"
        style={{ position: 'sticky', left: 180, zIndex: 10, backgroundColor: '#fff', minWidth: 160, isolation: 'isolate' }}>{row.drugClass}</td>
      {/* HCPCS — sticky col 3 */}
      <td className="px-4 py-2.5 text-xs font-mono text-gray-400 whitespace-nowrap border-b border-gray-100"
        style={{ position: 'sticky', left: 340, zIndex: 10, backgroundColor: '#fff', minWidth: 90, isolation: 'isolate' }}>{row.hcpcs}</td>
      {/* Carelon — sticky col 4 */}
      <td className="px-4 py-2.5 text-center border-b border-gray-100"
        style={{ position: 'sticky', left: 430, zIndex: 10, backgroundColor: '#EBF3FF', minWidth: 80, boxShadow: '2px 0 4px rgba(0,0,0,0.06)', isolation: 'isolate' }}>
        {/* Carelon status comes straight from the API (result.in_carelon → ✓, result.not_in_carelon → Gap); not editable */}
        {row.carelon === 'Y'
          ? <span className="text-base font-bold" style={{ color: '#10b981' }}>✓</span>
          : <span className="text-xs font-bold text-red-500">Gap</span>}
      </td>
      {/* Competitor columns */}
      {comps.map(c => {
        const override = rowOverrides[c]; // { covered, note, original } | undefined
        const isManuallyAdded = override !== undefined || !!row.edited?.[c];
        const isChecked = override !== undefined ? override.covered : row[c] === 'Y';
        return (
          <td key={c} className="px-4 py-2.5 text-center border-b border-gray-100 relative">
            <div className="mx-auto inline-block"
              onMouseEnter={e => onCellEnter(e, row, c, isManuallyAdded)}
              onMouseLeave={onCellLeave}>
              {isChecked ? (
                <button onClick={() => onCellClick(row, c, isChecked)} title={isLocked ? lockedTitle : undefined}
                  className={`block ${isLocked ? 'cursor-not-allowed' : ''}`}>
                  {isManuallyAdded
                    ? <CheckCircle size={15} className="text-orange-500 mx-auto" />
                    : <span className="text-base font-bold hover:opacity-70 transition-opacity" style={{ color: '#10b981' }}>✓</span>}
                </button>
              ) : (
                <button onClick={() => onCellClick(row, c, isChecked)} title={isLocked ? lockedTitle : undefined}
                  className={`text-gray-300 text-sm transition-colors ${isLocked ? 'cursor-not-allowed' : 'hover:text-emerald-400'}`}>
                  {isManuallyAdded ? <MinusCircle size={15} className="text-gray-400 mx-auto" /> : '—'}
                </button>
              )}
            </div>
          </td>
        );
      })}
      {/* spacer cell for More button column */}
      <td className="border-b border-gray-100" />
    </tr>
  );
});

/**
 * Fixed-position cell tooltip with its own state, so hovering a cell re-renders only
 * this component (not the whole page/grid). Controlled via ref: show({ x, y, row, comp, manual }) / hide().
 */
export const DnCellTooltip = forwardRef(function DnCellTooltip(_, ref) {
  const [tip, setTip] = useState(null);
  useImperativeHandle(ref, () => ({ show: setTip, hide: () => setTip(null) }), []);
  if (!tip) return null;
  // This payor's matched drug name(s) for the row's HCPCS (match_nm), comma separated
  const matchNames = tip.row.matchNames?.[tip.comp] ?? [];
  return (
    <div className="pointer-events-none"
      style={{ position: 'fixed', left: tip.x, top: tip.y - 8, transform: 'translate(-50%, -100%)', zIndex: 99999 }}>
      <div className="bg-gray-900 text-white rounded-lg shadow-2xl p-2 text-left" style={{ width: 190 }}>
        <div className="mb-1.5">
          {matchNames.length
            ? <p className="font-bold text-[10px] text-white leading-tight">{matchNames.join(', ')}</p>
            : <p className="text-[10px] text-gray-400 italic leading-tight">No matching drug name</p>}
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">HCPCS</span>
          <span className="text-[9px] font-mono font-bold text-amber-400 bg-amber-400/10 px-1 py-px rounded">{tip.row.hcpcs}</span>
          {tip.manual && <span className="text-[8px] font-bold px-1 py-px rounded bg-orange-500 text-white">Manual</span>}
        </div>
      </div>
      <div className="w-2 h-2 bg-gray-900 rotate-45 mx-auto -mt-1" />
    </div>
  );
});
