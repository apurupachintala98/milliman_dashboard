import { CheckCircle, XCircle, AlertTriangle, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

const ICONS = {
  success: <CheckCircle size={16} className="text-brand-teal shrink-0" />,
  error:   <XCircle size={16} className="text-brand-coral shrink-0" />,
  warning: <AlertTriangle size={16} className="text-yellow-500 shrink-0" />,
};

function ToastStack({ toasts, dismissToast, className }) {
  if (!toasts.length) return null;
  return (
    <div className={className}>
      {toasts.map(t => (
        <div key={t.id} className="bg-white border border-gray-200 rounded-lg shadow-lg px-4 py-3 flex items-start gap-3 animate-fade-in">
          {ICONS[t.type] || ICONS.success}
          <p className="text-sm text-gray-700 flex-1">{t.message}</p>
          <button onClick={() => dismissToast(t.id)} className="text-gray-300 hover:text-gray-500 shrink-0">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}

export default function ToastContainer() {
  const { toasts, dismissToast } = useApp();
  if (!toasts.length) return null;
  return (
    <>
      <ToastStack toasts={toasts.filter(t => t.position === 'top')} dismissToast={dismissToast}
        className="fixed top-4 left-1/2 -translate-x-1/2 z-[110] flex flex-col gap-2 w-full max-w-sm px-4" />
      <ToastStack toasts={toasts.filter(t => t.position !== 'top')} dismissToast={dismissToast}
        className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm" />
    </>
  );
}