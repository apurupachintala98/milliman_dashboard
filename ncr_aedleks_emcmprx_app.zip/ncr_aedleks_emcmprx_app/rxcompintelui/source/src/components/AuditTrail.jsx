import { useState, useEffect, useRef } from 'react';
import { Clock, X, ChevronDown, Trash2, User, Edit2, CheckCircle, Plus, Filter, Download } from 'lucide-react';

// ─── Action type config ───────────────────────────────────────────────────────
const ACTION_STYLES = {
  generate:   { color: '#1A3673', bg: '#E8F0FF', icon: CheckCircle,  label: 'Generated' },
  approve:    { color: '#059669', bg: '#ECFDF5', icon: CheckCircle,  label: 'Approved'  },
  edit:       { color: '#B45309', bg: '#FFF8E8', icon: Edit2,        label: 'Edited'    },
  add:        { color: '#7C3AED', bg: '#EDE9FE', icon: Plus,         label: 'Added'     },
  filter:     { color: '#0891B2', bg: '#E0F6FF', icon: Filter,       label: 'Filtered'  },
  upload:     { color: '#6D28D9', bg: '#F5F3FF', icon: Download,     label: 'Uploaded'  },
  status:     { color: '#D97706', bg: '#FEF3C7', icon: Clock,        label: 'Status'    },
  default:    { color: '#6B7280', bg: '#F9FAFB', icon: Clock,        label: 'Action'    },
};

function getStyle(action) {
  return ACTION_STYLES[action?.toLowerCase()] || ACTION_STYLES.default;
}

function formatTime(iso) {
  const d = new Date(iso);
  const diffMs = Date.now() - d;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHrs  = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  if (diffMins < 1)  return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHrs  < 24) return `${diffHrs}h ago`;
  if (diffDays < 7)  return `${diffDays}d ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatFull(iso) {
  return new Date(iso).toLocaleString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

// ─── AuditTrail panel component ───────────────────────────────────────────────
export default function AuditTrail({ entries, onClear, buttonLabel = 'Audit Trail' }) {
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState('all');
  const panelRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    function handle(e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [open]);

  const actionTypes = ['all', ...Object.keys(ACTION_STYLES).filter(k => k !== 'default')];
  const filtered = filter === 'all' ? entries : entries.filter(e => e.action?.toLowerCase() === filter);

  return (
    <div className="relative" ref={panelRef}>
      <button
        onClick={() => setOpen(o => !o)}
        className="btn-secondary flex items-center gap-2 text-xs transition-all"
      >
        <Clock size={14} />
        {buttonLabel}
        {entries.length > 0 && (
          <span className="ml-0.5 w-4 h-4 rounded-full text-white flex items-center justify-center text-[9px] font-bold"
            style={{ backgroundColor: '#1A3673' }}>
            {entries.length > 99 ? '99+' : entries.length}
          </span>
        )}
        <ChevronDown size={11} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div
          className="absolute right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-2xl z-50 flex flex-col"
          style={{ width: 420, maxHeight: 560 }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <Clock size={14} className="text-brand-navy" />
              <span className="text-sm font-bold text-brand-navy">Audit Trail</span>
              <span className="text-[10px] text-gray-400 font-semibold px-2 py-0.5 rounded-full bg-gray-100">
                {entries.length} {entries.length === 1 ? 'entry' : 'entries'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {entries.length > 0 && (
                <button
                  onClick={() => { if (window.confirm('Clear all audit entries for this page?')) onClear(); }}
                  className="text-[10px] text-red-400 hover:text-red-600 flex items-center gap-1 font-semibold"
                >
                  <Trash2 size={10} /> Clear
                </button>
              )}
              <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={15} />
              </button>
            </div>
          </div>

          {/* Filter chips */}
          {entries.length > 0 && (
            <div className="px-4 py-2 flex flex-wrap gap-1.5 border-b border-gray-100">
              {actionTypes.map(t => {
                const s = getStyle(t === 'all' ? 'default' : t);
                const isActive = filter === t;
                return (
                  <button key={t} onClick={() => setFilter(t)}
                    className="text-[10px] font-bold px-2 py-0.5 rounded-full capitalize transition-all border"
                    style={{
                      backgroundColor: isActive ? s.bg : '#fff',
                      color:           isActive ? s.color : '#9CA3AF',
                      borderColor:     isActive ? s.color + '55' : '#E5E7EB',
                    }}>
                    {t === 'all' ? 'All' : ACTION_STYLES[t]?.label || t}
                  </button>
                );
              })}
            </div>
          )}

          {/* Entries list */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
            {filtered.length === 0 ? (
              <div className="py-10 text-center">
                <Clock size={28} className="mx-auto mb-2 text-gray-200" />
                <p className="text-sm text-gray-400 font-semibold">No audit entries yet</p>
                <p className="text-xs text-gray-300 mt-1">Actions like generating, editing, and approving will be recorded here.</p>
              </div>
            ) : (
              filtered.map(entry => {
                const s = getStyle(entry.action);
                const Icon = s.icon;
                return (
                  <div key={entry.id} className="flex items-start gap-3 rounded-xl p-2.5 hover:bg-gray-50 transition-colors">
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                      style={{ backgroundColor: s.bg }}>
                      <Icon size={13} style={{ color: s.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-gray-800">{entry.details}</span>
                        <span className="text-[10px] text-gray-400 shrink-0 whitespace-nowrap"
                          title={formatFull(entry.timestamp)}>
                          {formatTime(entry.timestamp)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                          style={{ backgroundColor: s.bg, color: s.color }}>
                          {s.label}
                        </span>
                        <span className="flex items-center gap-0.5 text-[10px] text-gray-400">
                          <User size={9} /> {entry.user}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="px-4 py-2.5 border-t border-gray-100 text-[10px] text-gray-400 text-center">
            Audit entries are stored locally in this browser session.
          </div>
        </div>
      )}
    </div>
  );
}
