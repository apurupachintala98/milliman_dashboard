import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

function formatRemaining(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

/** "Are you still there?" prompt with a live countdown to automatic sign-out. */
export default function IdleWarningModal({ deadline, onStay, onSignOut }) {
  const [now, setNow] = useState(Date.now);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}
      role="alertdialog" aria-modal="true" aria-labelledby="idle-warning-title">
      <div className="bg-white rounded-xl shadow-xl mx-4 p-6" style={{ width: 360 }}>
        <div className="flex items-center gap-2 mb-2">
          <Clock size={18} className="text-brand-coral shrink-0" />
          <h2 id="idle-warning-title" className="font-bold text-brand-navy text-sm">Are you still there?</h2>
        </div>
        <p className="text-xs text-gray-600 leading-relaxed">
          You've been inactive for a while. For your security, you'll be signed out in{' '}
          <span className="font-bold text-brand-navy tabular-nums">{formatRemaining(deadline - now)}</span>.
        </p>
        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onSignOut} className="btn-secondary text-xs">Sign out</button>
          <button onClick={onStay} className="btn-primary text-xs" autoFocus>Stay signed in</button>
        </div>
      </div>
    </div>
  );
}
