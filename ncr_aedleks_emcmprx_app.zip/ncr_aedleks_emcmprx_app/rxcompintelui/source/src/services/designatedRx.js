import { apiGet, apiPutJson } from './client';
import { userError, toUserError } from './errors';

export async function fetchJobRuns({ signal } = {}) {
  try {
    const body = await apiGet('/designated-rx/job-runs', { signal });
    return normalizeJobRuns(body);
  } catch (e) {
    throw toUserError(e, { action: 'load the Designated Network snapshots', byStatus: { 404: 'No Designated Network snapshots were found.' } });
  }
}

export const resultTypeLabel = (resultType) => str(resultType).toUpperCase();

/**
 * GET /designated-rx/{job_run_id}?run_type=…&result_type=…
 * Scheduled runs need a result_type from the run's available_files; adhoc runs omit it.
 */
export async function fetchSnapshot(jobRunId, { runType, resultType, availableFiles = [], label, signal } = {}) {
  const runLabel = label || jobRunId;
  const type = resultTypeLabel(resultType);
  if (runType === 'scheduled') {
    if (!availableFiles.length) {
      throw userError(`No result files are available for the ${runLabel} snapshot yet. Please try again later or choose another snapshot.`);
    }
    if (!resultType || !availableFiles.includes(resultType)) {
      throw userError(`Please choose one of the available result types (${availableFiles.map(resultTypeLabel).join(', ')}) under the ${runLabel} snapshot in the sidebar.`);
    }
  }
  const params = new URLSearchParams();
  if (runType) params.set('run_type', runType);
  if (runType !== 'adhoc' && resultType) params.set('result_type', resultType);
  const query = params.toString() ? `?${params}` : '';
  try {
    const body = await apiGet(`/designated-rx/${encodeURIComponent(jobRunId)}${query}`, { signal });
    return toSnapshotModel(body);
  } catch (e) {
    throw toUserError(e, { action: `load the ${runLabel} snapshot`, byStatus: {
      400: `A result type is required to open the ${runLabel} snapshot. Please choose one of its result types in the sidebar.`,
      404: type
        ? `The ${type} results for the ${runLabel} snapshot could not be found. They may still be generating or were not produced for this run. Please choose another result type or snapshot.`
        : `The results for the ${runLabel} snapshot could not be found. They may still be generating. Please try again later or choose another snapshot.`,
    } });
  }
}

const JOB_ID_FIELDS   = ['job_run_id', 'jobRunId', 'id'];
const JOB_DATE_FIELDS = ['date', 'job_run_dt', 'job_run_date', 'run_date', 'snapshot_date', 'creatd_dtm', 'created_at', 'updtd_dtm'];

function pick(obj, fields) {
  for (const f of fields) {
    if (obj?.[f] !== undefined && obj[f] !== null && obj[f] !== '') return obj[f];
  }
  return undefined;
}

function unwrapList(body, keys) {
  if (Array.isArray(body)) return body;
  for (const k of keys) {
    if (Array.isArray(body?.[k])) return body[k];
  }
  return [];
}

export function formatSnapshotDate(date) {
  if (!date || Number.isNaN(date.getTime())) return '';
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function parseDate(value) {
  if (!value) return null;
  const d = /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(`${value}T00:00:00`) : new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

function isTrue(v) {
  return v === true || /^(true|y|yes|1)$/i.test(String(v ?? '').trim());
}

/** Default result type for a run: 'all' when available, else the first file; adhoc runs have none. */
export function defaultResultType(run) {
  const files = run?.availableFiles ?? [];
  return files.find(f => f.toLowerCase() === 'all') ?? files[0] ?? null;
}

/** → [{ jobRunId, key, runType, date: Date|null, label: 'Sep 22, 2026', current: bool, availableFiles: ['all', 'ca'] }] newest first */
export function normalizeJobRuns(body) {
  const list = unwrapList(body, ['data', 'job_runs', 'jobRuns', 'items', 'results']);
  const seen = new Set();
  const runs = [];
  // for (const item of list) {
  //   const jobRunId = typeof item === 'string' ? item : pick(item, JOB_ID_FIELDS);
  //   if (!jobRunId || seen.has(String(jobRunId))) continue;
  //   seen.add(String(jobRunId));
  //   const date = typeof item === 'string' ? null : parseDate(pick(item, JOB_DATE_FIELDS));
  //   const current = typeof item === 'string' ? false : isTrue(item.current);
  //   runs.push({ jobRunId: String(jobRunId), date, label: formatSnapshotDate(date) || String(jobRunId), current });
  // }

  for (const item of list) {
    const jobRunId = typeof item === 'string' ? item : pick(item, JOB_ID_FIELDS);
    const runType = typeof item === 'string' ? 'scheduled' : (str(item.run_type).toLowerCase() === 'adhoc' ? 'adhoc' : 'scheduled');
    const key = `${jobRunId}|${runType}`;
    if (!jobRunId || seen.has(key)) continue;
    seen.add(key);
    const date = typeof item === 'string' ? null : parseDate(pick(item, JOB_DATE_FIELDS));
    const current = typeof item === 'string' ? false : isTrue(item.current);
    // available_files: result files for scheduled runs (e.g. ["all", "ca"]); always [] for adhoc
    const availableFiles = runType === 'adhoc' || !Array.isArray(item?.available_files) ? []
      : [...new Set(item.available_files.map(f => str(f).trim()).filter(Boolean))];
    runs.push({ jobRunId: String(jobRunId), key, runType, date, label: formatSnapshotDate(date) || String(jobRunId), current, availableFiles });
  }
  runs.sort((a, b) => (b.date?.getTime() ?? 0) - (a.date?.getTime() ?? 0));
  return runs;
}

const PROGRAM_STATUS_LABELS = ['Mandatory', 'Voluntary', 'Mixed/Conditional', 'Other/Unclear'];
const PORTFOLIO_LABELS = [...PROGRAM_STATUS_LABELS, 'Full Portfolio', 'Carelon Gaps'];

function programStatusLabel(status) {
  const s = str(status).toLowerCase();
  if (s.includes('mandatory')) return 'Mandatory';
  if (s.includes('voluntary')) return 'Voluntary';
  if (s.includes('mixed') || s.includes('conditional')) return 'Mixed/Conditional';
  return 'Other/Unclear';
}

/** Key used for Carelon's own program status (top-level `carelon` object) alongside the competitor payor codes. */
export const CARELON_KEY = 'CARELON';

export function programStatusPortfolio(model) {
  const statusByPayor = model?.payorStatus || {};   // { CARELON: { Mandatory: 1 }, BCBS_MT: { Mandatory: 2, … }, … }
  if (!Object.keys(statusByPayor).length) return [];
  return PROGRAM_STATUS_LABELS.map(label => {
    // code: payor key; name: payor_nm for display (e.g. AHA → "AmeriHealth Administrators", CARELON → "CarelonRx")
    const competitors = Object.entries(statusByPayor)
      .map(([code, counts]) => ({ code, name: payorName(model, code), count: counts?.[label] || 0 }))
      .filter(c => c.count > 0)
      .sort((x, y) => (y.code === CARELON_KEY) - (x.code === CARELON_KEY) || y.count - x.count); // Carelon first
    const count = competitors.reduce((sum, c) => sum + c.count, 0);
    return { label, count, competitors };
  });
}
const REPORT_STATUSES  = ['in-progress', 'in-review', 'approved'];

function toYN(value) {
  if (value === true) return 'Y';
  return /^(y|yes|true|1)$/i.test(String(value ?? '').trim()) ? 'Y' : 'N';
}

function str(v) {
  return v === null || v === undefined ? '' : String(v);
}

function strList(list) {
  return Array.isArray(list) ? list.map(d => (typeof d === 'string' ? d : str(d?.drug ?? d?.brand_nm ?? d?.drug_nm))).filter(Boolean) : [];
}

function num(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}


function programTypeOf(status) {
  const s = str(status).toLowerCase();
  if (s.includes('mandatory')) return 'Mandatory';
  if (s.includes('voluntary')) return 'Voluntary';
  return '';
}

function codeLabel(code) {
  return str(code).replace(/^NO_HCPCS_/, '');
}

// function drugsFromResult({ inCarelon, notInCarelon, comparison, compKeys }) {
//   const programByPayer = {};
//   for (const [p, c] of Object.entries(comparison)) programByPayer[p] = programTypeOf(c?.program_status);

//   const rows = new Map();
//   const add = (r, carelon) => {
//     const drug = str(r?.brand_nm).trim() || codeLabel(r?.hcpcs_cd);
//     if (!drug) return;
//     const hcpcs = str(r?.hcpcs_cd);
//     const key = `${drug}|${hcpcs}`;
//     let row = rows.get(key);
//     if (!row) {
//       row = { drug, drugClass: str(r?.drug_desc) || str(r?.drug_nm), hcpcs, programType: '', carelon, drugNm: str(r?.drug_nm) };
//       // The original result.in_carelon / result.not_in_carelon object, sent back unchanged in the edit buckets
//       Object.defineProperty(row, 'source', { value: r, enumerable: false });
//       // Payors edited by a user: the API adds `participating` to that payor's entry (any value)
//       Object.defineProperty(row, 'edited', { value: {}, enumerable: false });
//       for (const c of compKeys) row[c] = 'N';
//       rows.set(key, row);
//     }
//     if (carelon === 'Y') row.carelon = 'Y';
//     for (const [payer, entry] of Object.entries(r?.payor || {})) {
//       row.edited[payer] = !!entry && typeof entry === 'object' && 'participating' in entry; // key present = edited
//       const p = entry && typeof entry === 'object' ? entry.participating : undefined;
//       const covered = p === undefined || p === null || p === '' ? 'Y' : toYN(p);
//       row[payer] = covered; // always overwrite
//       const prog = programByPayer[payer];
//       if (covered === 'Y' && prog && row.programType !== 'Mandatory') row.programType = prog;
//     }
//   };
//   inCarelon.forEach(r => add(r, 'Y'));
//   notInCarelon.forEach(r => add(r, 'N'));

//   return [...rows.values()];
// }

function drugsFromResult({ inCarelon, notInCarelon, comparison, compKeys }) {
  const programByPayer = {};
  for (const [p, c] of Object.entries(comparison)) programByPayer[p] = programTypeOf(c?.program_status);
 
  const rows = new Map();
  // brand_nm is a list when several brands share one HCPCS (e.g. ["ACTHAR HP", "H.P. ACTHAR"]) → one row per brand
  const add = (r, carelon) => {
    const brands = brandNames(r?.brand_nm);
    for (const drug of brands.length ? brands : [codeLabel(r?.hcpcs_cd)]) addRow(r, carelon, drug);
  };
  const addRow = (r, carelon, drug) => {
    if (!drug) return;
    const hcpcs = str(r?.hcpcs_cd);
    const key = `${drug}|${hcpcs}`;
    let row = rows.get(key);
    if (!row) {
      row = { drug, drugClass: str(r?.drug_desc) || str(r?.drug_nm), hcpcs, programType: '', carelon, drugNm: str(r?.drug_nm) };
      Object.defineProperty(row, 'source', { value: r, enumerable: false });
      Object.defineProperty(row, 'edited', { value: {}, enumerable: false });
      // matchNames: { [payer]: ['TOFIDENCE', 'TYENNE'] } — the payor's own drug names matched to this row (result[*].payor[payer].match_nm)
      Object.defineProperty(row, 'matchNames', { value: {}, enumerable: false });
      // notes: { [payer]: 'comment text' } — last saved comment per payor cell, from API response payor[payer].note
      Object.defineProperty(row, 'notes', { value: {}, enumerable: false });
      for (const c of compKeys) row[c] = 'N';
      rows.set(key, row);
    }
    if (carelon === 'Y') row.carelon = 'Y';
    for (const [payer, entry] of Object.entries(r?.payor || {})) {
      const names = brandNames(entry?.match_nm);
      if (names.length) row.matchNames[payer] = [...new Set([...(row.matchNames[payer] || []), ...names])];
      row.edited[payer] = !!entry && typeof entry === 'object' && 'participating' in entry; // key present = edited
      const p = entry && typeof entry === 'object' ? entry.participating : undefined;
      const covered = p === undefined || p === null || p === '' ? 'Y' : toYN(p);
      row[payer] = covered; // always overwrite
      if (commentText(entry?.note)) row.notes[payer] = commentText(entry.note);
      const prog = programByPayer[payer];
      // Mandatory highlight: comparison[payer].program_status of a payor covering this drug
      if (covered === 'Y' && prog && row.programType !== 'Mandatory') row.programType = prog;
    }
  };
  inCarelon.forEach(r => add(r, 'Y'));
  notInCarelon.forEach(r => add(r, 'N'));
 
  return [...rows.values()];
}

/** brand_nm → list of brand names (string in the old format; list when several brands share one HCPCS). */
function brandNames(value) {
  const list = Array.isArray(value) ? value : [value];
  return [...new Set(list.map(v => str(v).trim()).filter(Boolean))];
}

/** Rows created from the same result item (brands sharing one HCPCS), including `row` itself. */
export function sameSourceRows(rows, row) {
  return row?.source ? rows.filter(d => d.source === row.source) : [row];
}

function overlapFromComparison(comparison, resultDrugs) {
  // HCPCS → all of its brand names (counts below still come from the API, per HCPCS)
  const namesByCode = {};
  const addName = (code, name) => { (namesByCode[code] = namesByCode[code] || []).includes(name) || namesByCode[code].push(name); };
  for (const r of resultDrugs) {
    for (const name of brandNames(r?.brand_nm)) {
      if (r?.hcpcs_cd) addName(r.hcpcs_cd, name);
      addName(`NO_HCPCS_${name}`, name);
    }
  }
  const names = (codes) => (Array.isArray(codes) ? codes : []).flatMap(c => namesByCode[c] || [codeLabel(c)]).filter(Boolean);
  const out = {};
  for (const [payer, c] of Object.entries(comparison)) {
    if (!c || typeof c !== 'object') continue;
    const commonDrugs = names(c.match), carOnlyDrugs = names(c.carelon_only), compOnlyDrugs = names(c.gap);
    const common = num(c.match_cnt, commonDrugs.length);
    const carOnly = num(c.carelon_only_cnt, carOnlyDrugs.length);
    const compOnly = num(c.not_in_carelon_cnt, compOnlyDrugs.length);
    out[payer] = { common, carOnly, compOnly, compTotal: common + compOnly, commonDrugs, carOnlyDrugs, compOnlyDrugs };
  }
  return out;
}

/**
 * Maps the /designated-rx/{job_run_id} response to what each page section renders.
 *
 *   competitors, drug_data  → Priority Intelligence table (+ fallbacks below)
 *   comp_overlap            → Coverage Difference Analysis
 *   source_portfolio        → Competitor Source Portfolio
 *   recommendations         → AI Recommendations
 *   report_status           → status pipeline (when it's a known value)
 */
export function toSnapshotModel(body) {
  const b = body && typeof body === 'object' ? body : {};

  const result = b.result && typeof b.result === 'object' ? b.result : {};
  const inCarelon = Array.isArray(result.in_carelon) ? result.in_carelon : [];
  const notInCarelon = Array.isArray(result.not_in_carelon) ? result.not_in_carelon : [];
  // Per-payer comparison (current key "comparison"; older responses spelled it "comparision")
  const comparison = [b.comparison, b.comparision].find(c => c && typeof c === 'object' && Object.keys(c).length) || {};

  // ── Competitors: `competitors`, else all_payors + comparison keys + payors found in result ──
  let compKeys = Array.isArray(b.competitors) ? b.competitors.map(str).filter(Boolean) : [];
  if (!compKeys.length) {
    const seen = new Set();
    const add = (k) => { const v = str(k).trim(); if (v && !seen.has(v)) { seen.add(v); compKeys.push(v); } };
    (Array.isArray(b.all_payors) ? b.all_payors : []).forEach(add);
    Object.keys(comparison).forEach(add);
    for (const r of [...inCarelon, ...notInCarelon]) Object.keys(r?.payor || {}).forEach(add);
  }

  // Generic drug name per HCPCS, from result.in_carelon / result.not_in_carelon (used by the edits API)
  const genericByHcpcs = {};
  for (const r of [...inCarelon, ...notInCarelon]) {
    if (r?.hcpcs_cd && r?.drug_nm && !genericByHcpcs[r.hcpcs_cd]) genericByHcpcs[r.hcpcs_cd] = str(r.drug_nm);
  }

  // ── Priority Intelligence table ──
  let drugs;
  if (Array.isArray(b.drug_data) && b.drug_data.length) {
    drugs = b.drug_data.map(r => {
      const row = {
        drug:        str(r.drug),
        drugClass:   str(r.drugClass),
        hcpcs:       str(r.hcpcs),
        programType: str(r.programType),
        carelon:     toYN(r.carelon),
        drugNm:      str(r.drug_nm) || genericByHcpcs[str(r.hcpcs)] || '',
      };
      for (const c of compKeys) row[c] = toYN(r[c]); // missing key → 'N'
      return row;
    }).filter(r => r.drug);
  } else {
    drugs = drugsFromResult({ inCarelon, notInCarelon, comparison, compKeys });
  }

  // ── Manual overrides: seeded from the audit log so edited cells keep their circle after refresh ──
  // manual_overrides: [{ hcpcs_cd, drug_nm, payor, old_val, new_val, comments, ts }, …]
  const manualOverrides = {};
  const overrideLog = (Array.isArray(b.manual_overrides) ? b.manual_overrides : [])
    .slice().sort((a, c) => str(a?.ts).localeCompare(str(c?.ts)));   // oldest → newest
  for (const entry of overrideLog) {
    if (!entry?.payor) continue; // skip carelon bucket moves
    const hcpcs = str(entry.hcpcs_cd);
    // Entries with brand_nm are per brand → only that brand's row. Older entries (no brand_nm) were per HCPCS →
    // every brand row of that result item.
    const brand = str(entry.brand_nm).trim().toLowerCase();
    const brandRow = brand ? drugs.find(d => (!hcpcs || d.hcpcs === hcpcs) && d.drug.toLowerCase() === brand) : null;
    const drug = brandRow || drugs.find(d => (hcpcs && d.hcpcs === hcpcs) || (entry.drug_nm && d.drugNm === entry.drug_nm));
    if (!drug) continue;
    for (const d of brandRow ? [brandRow] : sameSourceRows(drugs, drug)) {
      const cellKey = `${d.drug}|${d.hcpcs}|${entry.payor}`;
      const prev = manualOverrides[cellKey];
      manualOverrides[cellKey] = {
        covered: entry.new_val === 'Y',
        note: commentText(entry.comments),
        original: prev ? prev.original : entry.old_val === 'Y', // value before the first edit (used by Revert)
      };
    }
  }
  // A cell whose latest entry put it back to its original value with no comment was reverted → no circle
  for (const [k, o] of Object.entries(manualOverrides)) {
    if (o.covered === o.original && !o.note) delete manualOverrides[k];
  }

  // ── Coverage Difference Analysis ── comp_overlap, else built from `comparison`
  const compOverlap = {};
  if (b.comp_overlap && typeof b.comp_overlap === 'object') {
    for (const [comp, o] of Object.entries(b.comp_overlap)) {
      if (!o || typeof o !== 'object') continue;
      const commonDrugs = strList(o.commonDrugs), carOnlyDrugs = strList(o.carOnlyDrugs), compOnlyDrugs = strList(o.compOnlyDrugs);
      const common = num(o.common, commonDrugs.length), carOnly = num(o.carOnly, carOnlyDrugs.length), compOnly = num(o.compOnly, compOnlyDrugs.length);
      compOverlap[comp] = {
        common, carOnly, compOnly,
        compTotal: num(o.compTotal, common + compOnly),
        commonDrugs, carOnlyDrugs, compOnlyDrugs,
      };
    }
  }
  if (!Object.keys(compOverlap).length) {
    Object.assign(compOverlap, overlapFromComparison(comparison, [...inCarelon, ...notInCarelon]));
  }

  // ── Program status per payor (comparison[payor].program_status) ──
  // program_status may be one value or a list (one per program) → { payor: { label: programCount } }
  // Carelon's own program (top-level `carelon.program_status`) is included first, under CARELON_KEY
  const payorStatus = {};
  const programSources = b.carelon && typeof b.carelon === 'object' && 'program_status' in b.carelon
    ? { [CARELON_KEY]: b.carelon, ...comparison } : comparison;
  for (const [p, c] of Object.entries(programSources)) {
    if (!c || typeof c !== 'object' || !('program_status' in c)) continue;
    const list = Array.isArray(c.program_status) ? c.program_status : [c.program_status];
    const counts = {};
    for (const st of list) {
      const label = programStatusLabel(st && typeof st === 'object' ? st.program_status ?? st.status : st);
      counts[label] = (counts[label] || 0) + 1;
    }
    payorStatus[p] = counts;
  }

  // ── Competitor Source Portfolio ── (label → entry; missing labels computed on the page)
  const portfolio = {};
  for (const p of Array.isArray(b.source_portfolio) ? b.source_portfolio : []) {
    const label = PORTFOLIO_LABELS.find(l => l.toLowerCase() === str(p?.label).trim().toLowerCase());
    if (!label) continue;
    portfolio[label] = {
      count: num(p.count),
      competitors: (Array.isArray(p.competitors) ? p.competitors : [])
        .map(c => ({ name: str(c?.name), count: num(c?.count) }))
        .filter(c => c.name && c.count > 0)
        .sort((x, y) => y.count - x.count),
    };
  }

  // ── AI Recommendations ──
  // `recommendations[]`: { brand_nm, recommendation, recommendation_type, payors[] }
  // (falls back to `ai_recommendations` only when `recommendations` is empty)
  const recSource = [b.recommendations, b.ai_recommendations].find(a => Array.isArray(a) && a.length) || [];
  const aiRecs = recSource.map(r => {
    const recType = str(r.recommendation_type ?? r.type);
    const conf = r.confidence ?? null;
    const comps = Array.isArray(r.payors) ? r.payors : Array.isArray(r.competitors) ? r.competitors : [];
    return {
      type:        /remov/i.test(recType) ? 'remove' : 'add',   // e.g. "drug_gaps" → add
      recType,
      drug:        brandNames(r.brand_nm).join(', ') || str(r.drug),
      drugClass:   str(r.drugClass),
      confidence:  conf === null || conf === '' ? null : Math.max(0, Math.min(100, num(conf))),
      impact:      str(r.impact) || null,
      reason:      str(r.recommendation) || str(r.reason),
      competitors: comps.map(str).filter(Boolean),
    };
  }).filter(r => r.drug);

  const reportStatus = REPORT_STATUSES.includes(str(b.report_status).toLowerCase()) ? str(b.report_status).toLowerCase() : null;

  // ── Payor URLs / display names: comparison[payor].url|payor_nm, else the first one under result[*].payor[payor] ──
  // payorNames: { AHA: 'AmeriHealth Administrators', … } — codes without a payor_nm fall back to the code (payorName)
  const payorUrls = {};
  const payorNames = {};
  for (const [p, c] of Object.entries(comparison)) {
    if (str(c?.url).trim()) payorUrls[p] = str(c.url).trim();
    if (str(c?.payor_nm).trim()) payorNames[p] = str(c.payor_nm).trim();
  }
  for (const r of [...inCarelon, ...notInCarelon]) {
    for (const [p, e] of Object.entries(r?.payor || {})) {
      const u = str(e?.url).trim();
      if (u && !payorUrls[p]) payorUrls[p] = u;
      const n = str(e?.payor_nm).trim();
      if (n && !payorNames[p]) payorNames[p] = n;
    }
  }

  // ── Carelon's own program document: top-level `carelon: { payor_nm, url, program_status, … }` ──
  const carelonUrl = str(b.carelon?.url).trim() || null;
  payorNames[CARELON_KEY] = str(b.carelon?.payor_nm).trim() || 'CarelonRx';

  return { compKeys, drugs, compOverlap, portfolio, aiRecs, reportStatus, payorUrls, payorNames, carelonUrl, payorStatus, runDate: b.run_date ?? null, status: b.status ?? null, manualOverrides };
}

/** Display name for a payor code (e.g. AHA → "AmeriHealth Administrators"); falls back to the code. */
export const payorName = (model, code) => model?.payorNames?.[code] || code;

/** Carelon vs one competitor — feeds the Coverage Difference Analysis section. */
export function computeOverlap(drugs, comp) {
  const commonDrugs = [], carOnlyDrugs = [], compOnlyDrugs = [];
  for (const d of drugs) {
    const car = d.carelon === 'Y';
    const other = d[comp] === 'Y';
    if (car && other) commonDrugs.push(d.drug);
    else if (car) carOnlyDrugs.push(d.drug);
    else if (other) compOnlyDrugs.push(d.drug);
  }
  return {
    compTotal: commonDrugs.length + compOnlyDrugs.length,
    common: commonDrugs.length,
    carOnly: carOnlyDrugs.length,
    compOnly: compOnlyDrugs.length,
    commonDrugs, carOnlyDrugs, compOnlyDrugs,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Job run status — GET /designated-rx/{job_run_id}/status
// { schdl_job_run_id, status: "Completed", message }
// ─────────────────────────────────────────────────────────────────────────────

/** Backend status text → pipeline step ('in-progress' | 'in-review' | 'approved'), or 'failed' / null */
export function toPipelineStage(status) {
  const s = String(status ?? '').trim().toLowerCase().replace(/[\s_-]+/g, ' ');
  if (!s) return null;
  if (/(fail|error|cancel|abort)/.test(s)) return 'failed';
  if (/approved/.test(s)) return 'approved';                                  // only an explicit Approve
  if (/(review|complete|success|done|finished)/.test(s)) return 'in-review';  // job finished → awaiting review
  if (/(progress|running|pending|queued|started|submitted|processing)/.test(s)) return 'in-progress';
  return null;
}

/** PUT /designated-rx/{job_run_id}/status?run_type=…&result_type=… — { snapshot_status, updated_by } (Approve → "Approved", Revoke → "In Review") */
export async function updateJobRunStatus(jobRunId, { snapshotStatus, updatedBy, runType, resultType }, { signal } = {}) {
  const params = new URLSearchParams();
  if (runType) params.set('run_type', runType);
  if (runType !== 'adhoc' && resultType) params.set('result_type', resultType);
  const query = params.toString() ? `?${params}` : '';
  const approving = /approved/i.test(snapshotStatus);
  try {
    return await apiPutJson(`/designated-rx/${encodeURIComponent(jobRunId)}/status${query}`, {
      snapshot_status: snapshotStatus,
      updated_by: updatedBy || '',
    }, { signal });
  } catch (e) {
    throw toUserError(e, { action: approving ? 'approve this snapshot' : 'revoke the approval', byStatus: {
      400: `A result type is required to ${approving ? 'approve' : 'revoke'} this snapshot. Please choose one of its result types in the sidebar and try again.`,
      404: 'This snapshot could not be found. Please refresh the page and try again.',
      409: `This snapshot's status was already changed. Please refresh the page to see its current status.`,
    } });
  }
}

/** GET /designated-rx/{job_run_id}/status?run_type=…&result_type=… (result_type for scheduled runs only) */
export async function fetchJobRunStatus(jobRunId, { runType, resultType, label, signal } = {}) {
  const params = new URLSearchParams();
  if (runType) params.set('run_type', runType);
  if (runType !== 'adhoc' && resultType) params.set('result_type', resultType);
  const query = params.toString() ? `?${params}` : '';
  const runLabel = label || jobRunId;
  const type = resultTypeLabel(resultType);
  let body;
  try {
    body = await apiGet(`/designated-rx/${encodeURIComponent(jobRunId)}/status${query}`, { signal });
  } catch (e) {
    throw toUserError(e, { action: `check the status of the ${runLabel} snapshot`, byStatus: {
      400: `A result type is required to check the status of the ${runLabel} snapshot. Please choose one of its result types in the sidebar.`,
      404: type
        ? `The status of the ${type} results for the ${runLabel} snapshot is not available yet. Please try again later or choose another result type.`
        : `The status of the ${runLabel} snapshot is not available yet. Please try again later.`,
    } });
  }
  const status = body?.status ?? null;
  return {
    jobRunId: body?.schdl_job_run_id ?? jobRunId,
    status,
    message: body?.message ?? '',
    stage: toPipelineStage(status),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Edits — PUT /designated-rx/{job_run_id}/edits
// {
//   updated_by, report_status,
//   updates: [...],                       ← competitor cell edits (✓ / —)
//   in_carelon_add: [], in_carelon_remove: [],
//   not_in_carelon_add: [], not_in_carelon_remove: []
// }
// ─────────────────────────────────────────────────────────────────────────────

/**
 * One cell edit, in the backend's `updates` item format:
 *   { update_key, ts, user, hcpcs_cd, brand_nm, drug_nm, old_val, new_val, comments, payor }
 * update_key: 1-based position within this request's `updates` array.
 * brand_nm: the row's brand (Drug Name column) from result.in_carelon / not_in_carelon `brand_nm` —
 *           distinguishes brands that share one HCPCS (brand_nm may be a list there; each brand is its own row).
 * drug_nm: generic name (Therapeutic Class column) from result.* `drug_nm`.
 */
export function buildCellUpdate({ row, comp, oldCovered, newCovered, note, user, updateKey = 1 }) {
  return {
    update_key: updateKey,
    ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    user: user || '',
    hcpcs_cd: row.hcpcs,
    brand_nm: rowBrandName(row),
    drug_nm: row.drugNm || row.drug,
    old_val: oldCovered ? 'Y' : 'N',
    new_val: newCovered ? 'Y' : 'N',
    comments: str(note).trim(),   // note text from the popup; '' when there's no note
    payor: (comp && comp !== 'carelon') ? comp : null,   // competitor key that was edited, e.g. "BCBS_MT"
  };
}

/** `comments` / `note` from the API → display text (array of strings joined; plain strings kept as-is). */
function commentText(value) {
  return Array.isArray(value) ? value.map(str).map(s => s.trim()).filter(Boolean).join('; ') : str(value).trim();
}

/** The row's brand from its result item's brand_nm (string or list); '' when the item has no brand name. */
function rowBrandName(row) {
  if (!row?.source) return row?.drug || '';
  const brands = brandNames(row.source.brand_nm);
  return brands.includes(row.drug) ? row.drug : (brands[0] ?? '');
}

export function carelonBuckets(row, oldInCarelon, newInCarelon) {
  const empty = { inCarelonAdd: [], inCarelonRemove: [], notInCarelonAdd: [], notInCarelonRemove: [] };
  if (oldInCarelon === newInCarelon) return empty;
  const src = row.source || {};
  const base = {
    hcpcs_cd: src.hcpcs_cd ?? (row.hcpcs || null),
    brand_nm: src.brand_nm ?? row.drug,
    drug_nm: src.drug_nm ?? (row.drugNm || ''),
    drug_desc: src.drug_desc ?? '',
  };
  const inCarelonObj = { ...base, payor: src.payor || {} }; // payor sent back exactly as received
  const notInCarelonObj = { ...base, payor: {} };
  return newInCarelon
    ? { ...empty, notInCarelonRemove: [notInCarelonObj], inCarelonAdd: [inCarelonObj] }
    : { ...empty, inCarelonRemove: [inCarelonObj], notInCarelonAdd: [notInCarelonObj] };
}

/** PUT /designated-rx/{job_run_id}/edits?run_type=…&result_type=… (result_type for scheduled runs only) */
export async function saveEdits(jobRunId, {
  updatedBy, reportStatus, updates = [], runType, resultType, label,
}, { signal } = {}) {
  const params = new URLSearchParams();
  if (runType) params.set('run_type', runType);
  if (runType !== 'adhoc' && resultType) params.set('result_type', resultType);
  const query = params.toString() ? `?${params}` : '';
  const runLabel = label || jobRunId;
  const type = resultTypeLabel(resultType);
  // Only real changes go to the audit log: a changed value, or a note-only edit (same value + comment).
  // Entries with neither are dropped; update_key is renumbered.
  const changed = updates.filter(u => u.old_val !== u.new_val || commentText(u.comments) !== '')
    .map((u, i) => ({ ...u, update_key: i + 1 }));
  if (!changed.length) return { skipped: true, message: 'No changes to save.' };
  try {
    return await apiPutJson(`/designated-rx/${encodeURIComponent(jobRunId)}/edits${query}`, {
      updated_by: updatedBy || '',
      report_status: reportStatus || 'in-progress',
      updates: changed,
      // Sent empty for now
      in_carelon_add: [],
      in_carelon_remove: [],
      not_in_carelon_add: [],
      not_in_carelon_remove: [],
    }, { signal });
  } catch (e) {
    throw toUserError(e, { action: 'save your change', byStatus: {
      400: `Your change could not be saved because a result type is required for the ${runLabel} snapshot. Please choose one of its result types in the sidebar and try again.`,
      404: type
        ? `Your change could not be saved because the ${type} results for the ${runLabel} snapshot could not be found. Please refresh the page or choose another result type.`
        : `Your change could not be saved because the results for the ${runLabel} snapshot could not be found. Please refresh the page and try again.`,
      409: 'Your change could not be saved because this cell was changed by someone else. Please refresh the page and try again.',
    } });
  }
}
