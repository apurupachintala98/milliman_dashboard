import { apiPostForm } from './client';
import { userError, toUserError } from './errors';

const UPLOAD_FILE_FIELD = 'file';

// Drug list formats accepted by the upload (also used for the file picker's `accept`)
export const DRUG_LIST_EXTENSIONS = ['.pdf', '.xlsx', '.xls', '.csv', '.docx', '.json'];
const SUPPORTED = DRUG_LIST_EXTENSIONS.join(', ');

/** User-level checks before uploading; throws a userError the page can show as-is. */
function validateDrugListFile(file) {
  const ext = file.name.includes('.') ? file.name.slice(file.name.lastIndexOf('.')).toLowerCase() : '';
  if (!DRUG_LIST_EXTENSIONS.includes(ext)) {
    throw userError(`"${file.name}" is not a supported file type. Please upload a drug list as ${SUPPORTED}.`);
  }
  if (file.size === 0) {
    throw userError(`"${file.name}" is empty. Please choose a drug list file that contains data.`);
  }
}

//upload drug data api

export async function uploadRxDrugFile(file, { signal } = {}) {
  validateDrugListFile(file);
  const form = new FormData();
  form.append(UPLOAD_FILE_FIELD, file, file.name);
  try {
    const body = await apiPostForm('/rx-drugs/process-drug-list', form, { signal });
    return {
      message: (body && typeof body === 'object' && (body.message || body.detail)) || 'Drug list uploaded successfully.',
      body,
    };
  } catch (e) {
    const unreadable = `We couldn't process "${file.name}". Please check that it is a valid drug list (${SUPPORTED}) and try again.`;
    throw toUserError(e, { action: 'upload the drug list', byStatus: { 400: unreadable, 422: unreadable } });
  }
}
