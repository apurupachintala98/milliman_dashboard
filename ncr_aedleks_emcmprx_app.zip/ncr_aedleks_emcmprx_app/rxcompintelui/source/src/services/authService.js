import { API_CONFIG } from '../config/apiConfig';
import { LOGIN_ENV } from '../config/apiBaseUrl';
import apiClient from './apiClient';
import { userError, toUserError } from './errors';
import { hasAppAccess, NO_ACCESS_MSG } from './access';

const TOKEN_KEY = 'rxci_token';
const USER_KEY  = 'rxci_user';

const LOGIN_ERRORS = {
  action: 'sign you in',
  byStatus: {
    401: 'The Employee ID or password is incorrect. Please try again.',
    403: "Your account doesn't have access to RX Competitive Intelligence. Please contact IT for access.",
    422: 'Please enter both your Employee ID and password.',
    503: 'The sign-in service is temporarily unavailable. Please try again in a few minutes.',
  },
};

// POST /ldap/validate → { success, message, user_info, user_roles, access_token, token_type }
export async function login(user_id, password) {
  let res;
  try {
    res = await fetch(API_CONFIG.auth.login, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ user_id, password, role: '', aplctn_cd: '', env: LOGIN_ENV, ad_domain: 'us' }),
    });
  } catch (e) {
    throw toUserError(e, LOGIN_ERRORS);
  }

  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw toUserError({ status: res.status, message: body?.detail, body }, LOGIN_ERRORS);
  }

  const loginBody = await res.json();
  // LDAP can answer 200 with success: false (e.g. wrong password) — treat it as invalid credentials
  if (loginBody?.success === false) {
    throw toUserError({ status: 401, message: loginBody.message, body: loginBody }, LOGIN_ERRORS);
  }
  // Only RXCOMPINTL User / Super User roles may sign in — stop here (no token saved) for anyone else
  if (!hasAppAccess(loginBody?.user_roles)) {
    console.warn('[auth] sign-in blocked: no RX Comp Intel role in user_roles', loginBody?.user_roles);
    throw userError(NO_ACCESS_MSG, { status: 403 });
  }
  saveToken(loginBody);

  try {
    // user_roles comes with the login response — kept with the profile so it survives a page refresh
    return await fetchMe({ user_roles: loginBody.user_roles });
  } catch (e) {
    clearSession();
    throw toUserError(e, { action: 'load your profile', byStatus: {
      401: 'Sign-in could not be completed. Please try again.',
      403: "Your account doesn't have access to RX Competitive Intelligence. Please contact IT for access.",
    } });
  }
}

/** POST /auth/refresh — exchanges the current (still valid) token for a new one and stores it. */
export async function refreshToken() {
  saveToken(await apiClient.post(API_CONFIG.auth.refresh, {}));
}

function saveToken({ access_token, token_type, expires_in } = {}) {
  if (!access_token) throw userError('Sign-in could not be completed. Please try again.');
  sessionStorage.setItem(TOKEN_KEY, JSON.stringify({ access_token, token_type, expires_in, issued_at: Date.now() }));
}

/** Token expiry (ms epoch): JWT `exp`, else issued_at + expires_in; null when unknown. */
export function getTokenExpiry(token = getToken()) {
  try {
    const payload = JSON.parse(atob(token.access_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    if (payload.exp) return payload.exp * 1000;
  } catch { /* not a decodable JWT — fall back to expires_in */ }
  const expiresIn = Number(token?.expires_in);
  return token?.issued_at && expiresIn ? token.issued_at + expiresIn * 1000 : null;
}

/** GET /auth/me; `extra` (e.g. login `user_roles`) is merged in and stored with the profile. */
export async function fetchMe(extra = {}) {
  const user = { ...(await apiClient.get(API_CONFIG.auth.me)), ...extra };
  sessionStorage.setItem(USER_KEY, JSON.stringify(user));
  return user;
}

export const getToken = () => JSON.parse(sessionStorage.getItem(TOKEN_KEY) ?? 'null');
export const getUser  = () => JSON.parse(sessionStorage.getItem(USER_KEY)  ?? 'null');

export function clearSession() {
  sessionStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(USER_KEY);
}
