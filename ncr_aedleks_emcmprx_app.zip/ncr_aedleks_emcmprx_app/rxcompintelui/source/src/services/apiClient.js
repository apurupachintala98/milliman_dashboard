import { getToken } from './authService';

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

function authHeaders(extra = {}) {
  const token = getToken()?.access_token;
  return {
    accept: 'application/json',
    ...extra,
    ...(token && { Authorization: `Bearer ${token}` }),
  };
}

function errorMessage(body, res) {
  const detail = body && typeof body === 'object' ? body.detail : null;
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) {
    return detail.map(d => {
      const field = Array.isArray(d?.loc) ? d.loc.filter(x => x !== 'body').join('.') : '';
      return field ? `${field}: ${d?.msg ?? 'invalid'}` : (d?.msg ?? JSON.stringify(d));
    }).join('; ');
  }
  if (typeof body === 'string' && body.length < 200) return body;
  return `Request failed (${res.status})`;
}

async function handleResponse(res) {
  let body = null;
  const text = await res.text();
  if (text) {
    try { body = JSON.parse(text); } catch { body = text; }
  }
  if (!res.ok) throw new ApiError(errorMessage(body, res), res.status, body);
  return body;
}

function filenameFromDisposition(header) {
  if (!header) return null;
  const star = /filename\*\s*=\s*(?:UTF-8'')?([^;]+)/i.exec(header);
  if (star) { try { return decodeURIComponent(star[1].trim().replace(/^"|"$/g, '')); } catch { /* fall through */ } }
  const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(header);
  return plain ? plain[1].trim() : null;
}

const jsonHeaders = () => authHeaders({ 'Content-Type': 'application/json' });

const apiClient = {
  get: (url, { signal } = {}) =>
    fetch(url, { method: 'GET', headers: authHeaders(), signal }).then(handleResponse),

  post: (url, body, { signal } = {}) =>
    fetch(url, { method: 'POST', headers: jsonHeaders(), body: JSON.stringify(body), signal }).then(handleResponse),

  put: (url, body, { signal } = {}) =>
    fetch(url, { method: 'PUT', headers: jsonHeaders(), body: JSON.stringify(body), signal }).then(handleResponse),

  /** multipart/form-data POST. Don't set Content-Type — the browser adds it with the boundary. */
  postForm: (url, formData, { signal } = {}) =>
    fetch(url, { method: 'POST', headers: authHeaders(), body: formData, signal }).then(handleResponse),

  /** File download: returns { blob, filename, contentType } or { url, filename } when the API replies with a link. */
  async download(url, { signal } = {}) {
    const res = await fetch(url, { method: 'GET', headers: authHeaders({ accept: '*/*' }), signal });
    const contentType = res.headers.get('Content-Type') || '';
    if (!res.ok || contentType.includes('application/json')) {
      const body = await handleResponse(res);
      const fileUrl = body && typeof body === 'object'
        ? (body.url || body.download_url || body.presigned_url || body.s3_url || body.file_url)
        : null;
      if (!fileUrl) throw new ApiError('Export response did not include a file or download URL', res.status, body);
      return { url: fileUrl, filename: body.filename || body.file_name || null };
    }
    const blob = await res.blob();
    return { blob, filename: filenameFromDisposition(res.headers.get('Content-Disposition')), contentType };
  },
};

/** Save a downloaded blob (or open a URL) as a file in the browser. */
export function saveDownload({ blob, url, filename }) {
  const a = document.createElement('a');
  const href = blob ? URL.createObjectURL(blob) : url;
  a.href = href;
  if (filename) a.download = filename;
  if (!blob) { a.target = '_blank'; a.rel = 'noopener'; }
  document.body.appendChild(a);
  a.click();
  a.remove();
  if (blob) setTimeout(() => URL.revokeObjectURL(href), 10000);
}

export default apiClient;
