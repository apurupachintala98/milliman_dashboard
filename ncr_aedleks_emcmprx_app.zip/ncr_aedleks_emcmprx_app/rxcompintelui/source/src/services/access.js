/**
 * Application access from the login `user_roles` (POST /ldap/validate).
 * Only these AD roles may use RX Competitive Intelligence — matched on the suffix so every environment works
 * (MCM_DEV_…, MCM_UAT_…, MCM_PROD_…). Anyone without one of them has no access.
 */
const ACCESS_ROLES = [
  { suffix: '_RXCOMPINTL_SUPER_USER', role: 'super-user' }, // checked first: super user wins
  { suffix: '_RXCOMPINTL_USER',       role: 'user' },
];

export const NO_ACCESS_MSG = "Your account doesn't have access to RX Competitive Intelligence. Please request the RX Comp Intel User or Super User role from IT.";

/** Login user_roles → app role: 'super-user' | 'user', or null when the user has no access. */
export function roleFromUserRoles(userRoles) {
  if (!Array.isArray(userRoles)) return null;
  const codes = userRoles.map(r => String(r).trim().toUpperCase());
  return ACCESS_ROLES.find(a => codes.some(c => c.endsWith(a.suffix)))?.role ?? null;
}

export const hasAppAccess = (userRoles) => roleFromUserRoles(userRoles) !== null;
