import { API_CONFIG } from '../config/apiConfig';
import apiClient, { saveDownload } from './apiClient';

export async function fetchJobRuns({ signal } = {}) {
  const body = await apiClient.get(API_CONFIG.designatedRx.jobRuns, { signal });
  return normalizeJobRuns(body);
}

export async function fetchSnapshot(jobRunId, { signal } = {}) {
  const body = await apiClient.get(API_CONFIG.designatedRx.snapshot(jobRunId), { signal });
  return toSnapshotModel(body);
}

const JOB_ID_FIELDS   = ['job_run_id', 'jobRunId', 'id'];
const JOB_DATE_FIELDS = ['date', 'job_run_dt', 'job_run_date', 'run_date', 'snapshot_date', 'creatd_dtm', 'created_at', 'updtd_dtm'];

function pick(obj, fields) {
  for (const f of fields) {
    if (obj?.[f] !== undefined && obj[f] !== null && obj[f] !== '') return obj[f];
  }
  return undefined;
}

function unwrapList(body, keys) {
  if (Array.isArray(body)) return body;
  for (const k of keys) {
    if (Array.isArray(body?.[k])) return body[k];
  }
  return [];
}

export function formatSnapshotDate(date) {
  if (!date || Number.isNaN(date.getTime())) return '';
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function parseDate(value) {
  if (!value) return null;
  const d = /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(`${value}T00:00:00`) : new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

function isTrue(v) {
  return v === true || /^(true|y|yes|1)$/i.test(String(v ?? '').trim());
}

export function normalizeJobRuns(body) {
  const list = unwrapList(body, ['data', 'job_runs', 'jobRuns', 'items', 'results']);
  const seen = new Set();
  const runs = [];
  for (const item of list) {
    const jobRunId = typeof item === 'string' ? item : pick(item, JOB_ID_FIELDS);
    if (!jobRunId || seen.has(String(jobRunId))) continue;
    seen.add(String(jobRunId));
    const date = typeof item === 'string' ? null : parseDate(pick(item, JOB_DATE_FIELDS));
    const current = typeof item === 'string' ? false : isTrue(item.current);
    runs.push({ jobRunId: String(jobRunId), date, label: formatSnapshotDate(date) || String(jobRunId), current });
  }
  runs.sort((a, b) => (b.date?.getTime() ?? 0) - (a.date?.getTime() ?? 0));
  return runs;
}

const PORTFOLIO_LABELS = ['Mandatory', 'Voluntary', 'Full Portfolio', 'Carelon Gaps'];
const REPORT_STATUSES  = ['in-progress', 'in-review', 'approved'];

function toYN(value) {
  if (value === true) return 'Y';
  return /^(y|yes|true|1)$/i.test(String(value ?? '').trim()) ? 'Y' : 'N';
}

function str(v) {
  return v === null || v === undefined ? '' : String(v);
}

function strList(list) {
  return Array.isArray(list) ? list.map(d => (typeof d === 'string' ? d : str(d?.drug ?? d?.brand_nm ?? d?.drug_nm))).filter(Boolean) : [];
}

function num(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}


export function toSnapshotModel(body) {
  const b = body && typeof body === 'object' ? body : {};

  const compKeys = Array.isArray(b.competitors) ? b.competitors.map(str).filter(Boolean) : [];
  const genericByHcpcs = {};
  for (const list of [b.result?.in_carelon, b.result?.not_in_carelon]) {
    for (const r of Array.isArray(list) ? list : []) {
      if (r?.hcpcs_cd && r?.drug_nm && !genericByHcpcs[r.hcpcs_cd]) genericByHcpcs[r.hcpcs_cd] = str(r.drug_nm);
    }
  }
  const drugs = (Array.isArray(b.drug_data) ? b.drug_data : []).map(r => {
    const row = {
      drug:        str(r.drug),
      drugClass:   str(r.drugClass),
      hcpcs:       str(r.hcpcs),
      programType: str(r.programType),
      carelon:     toYN(r.carelon),
      drugNm:      str(r.drug_nm) || genericByHcpcs[str(r.hcpcs)] || '',
    };
    for (const c of compKeys) row[c] = toYN(r[c]); // missing key → 'N'
    return row;
  }).filter(r => r.drug);

  const compOverlap = {};
  if (b.comp_overlap && typeof b.comp_overlap === 'object') {
    for (const [comp, o] of Object.entries(b.comp_overlap)) {
      if (!o || typeof o !== 'object') continue;
      const commonDrugs = strList(o.commonDrugs), carOnlyDrugs = strList(o.carOnlyDrugs), compOnlyDrugs = strList(o.compOnlyDrugs);
      const common = num(o.common, commonDrugs.length), carOnly = num(o.carOnly, carOnlyDrugs.length), compOnly = num(o.compOnly, compOnlyDrugs.length);
      compOverlap[comp] = {
        common, carOnly, compOnly,
        compTotal: num(o.compTotal, common + compOnly),
        commonDrugs, carOnlyDrugs, compOnlyDrugs,
      };
    }
  }

  const portfolio = {};
  for (const p of Array.isArray(b.source_portfolio) ? b.source_portfolio : []) {
    const label = PORTFOLIO_LABELS.find(l => l.toLowerCase() === str(p?.label).trim().toLowerCase());
    if (!label) continue;
    portfolio[label] = {
      count: num(p.count),
      competitors: (Array.isArray(p.competitors) ? p.competitors : [])
        .map(c => ({ name: str(c?.name), count: num(c?.count) }))
        .filter(c => c.name && c.count > 0)
        .sort((x, y) => y.count - x.count),
    };
  }

  // ── AI Recommendations ──
  const recSource = Array.isArray(b.ai_recommendations) ? b.ai_recommendations
    : Array.isArray(b.recommendations) ? b.recommendations : [];
  const aiRecs = recSource.map(r => ({
    type:        str(r.type).toLowerCase() === 'remove' ? 'remove' : 'add',
    drug:        str(r.drug),
    drugClass:   str(r.drugClass),
    confidence:  Math.max(0, Math.min(100, num(r.confidence))),
    impact:      str(r.impact) || 'Low',
    reason:      str(r.reason),
    competitors: Array.isArray(r.competitors) ? r.competitors.map(str).filter(Boolean) : [],
  })).filter(r => r.drug);

  const reportStatus = REPORT_STATUSES.includes(str(b.report_status).toLowerCase()) ? str(b.report_status).toLowerCase() : null;

  return { compKeys, drugs, compOverlap, portfolio, aiRecs, reportStatus, runDate: b.run_date ?? null, status: b.status ?? null, manualOverrides };
}

export function computeOverlap(drugs, comp) {
  const commonDrugs = [], carOnlyDrugs = [], compOnlyDrugs = [];
  for (const d of drugs) {
    const car = d.carelon === 'Y';
    const other = d[comp] === 'Y';
    if (car && other) commonDrugs.push(d.drug);
    else if (car) carOnlyDrugs.push(d.drug);
    else if (other) compOnlyDrugs.push(d.drug);
  }
  return {
    compTotal: commonDrugs.length + compOnlyDrugs.length,
    common: commonDrugs.length,
    carOnly: carOnlyDrugs.length,
    compOnly: compOnlyDrugs.length,
    commonDrugs, carOnlyDrugs, compOnlyDrugs,
  };
}

export function toPipelineStage(status) {
  const s = String(status ?? '').trim().toLowerCase().replace(/[\s_-]+/g, ' ');
  if (!s) return null;
  if (/(fail|error|cancel|abort)/.test(s)) return 'failed';
  if (/(complete|approved|success|done|finished)/.test(s)) return 'approved';
  if (/review/.test(s)) return 'in-review';
  if (/(progress|running|pending|queued|started|submitted|processing)/.test(s)) return 'in-progress';
  return null;
}

export async function fetchJobRunStatus(jobRunId, { signal } = {}) {
  const body = await apiClient.get(API_CONFIG.designatedRx.status(jobRunId), { signal });
  const status = body?.status ?? null;
  return {
    jobRunId: body?.schdl_job_run_id ?? jobRunId,
    status,
    message: body?.message ?? '',
    stage: toPipelineStage(status),
  };
}


export async function exportSnapshotExcel(jobRunId, { signal } = {}) {
  const file = await apiClient.download(API_CONFIG.designatedRx.export(jobRunId), { signal });
  const filename = file.filename || `designated-network-${jobRunId}.xlsx`;
  saveDownload({ ...file, filename });
  return filename;
}


export function buildCellUpdate({ row, comp, oldCovered, newCovered, note, user, updateKey = 1 }) {
  return {
    update_key: updateKey,
    ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    user: user || '',
    hcpcs_cd: row.hcpcs,
    drug_nm: row.drugNm || row.drug,
    old_val: oldCovered ? 'Y' : 'N',
    new_val: newCovered ? 'Y' : 'N',
    payor: (comp && comp !== 'carelon') ? comp : null,
    comments: note || '',
  };
}

export async function saveEdits(jobRunId, {
  updatedBy, reportStatus, updates = [],
  inCarelonAdd = [], inCarelonRemove = [], notInCarelonAdd = [], notInCarelonRemove = [],
}, { signal } = {}) {
  return apiClient.put(API_CONFIG.designatedRx.edits(jobRunId), {
    updated_by: updatedBy || '',
    report_status: reportStatus || 'in-progress',
    updates,
    in_carelon_add: inCarelonAdd,
    in_carelon_remove: inCarelonRemove,
    not_in_carelon_add: notInCarelonAdd,
    not_in_carelon_remove: notInCarelonRemove,
  }, { signal });
}