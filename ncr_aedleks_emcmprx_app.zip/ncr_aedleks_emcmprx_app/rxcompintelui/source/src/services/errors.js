/**
 * Turns any failure (API, network, or the app's own validation) into a message the user can understand and act on.
 * Raw backend text is never shown to the user — the original error is logged to the console for debugging.
 */

/** An error whose message is already safe and helpful to show to the user as-is. */
export const userError = (message, { status, cause } = {}) =>
  Object.assign(new Error(message), { userFacing: true, status, cause });

const NETWORK_MESSAGE = "We couldn't reach the server. Please check your network/VPN connection and try again.";

const messageForStatus = (status, action) => ({
  400: `Some of the information sent wasn't accepted, so we couldn't ${action}. Please check it and try again.`,
  401: 'Your session has expired. Please sign in again.',
  403: `You don't have permission to ${action}. Please contact your administrator.`,
  404: `We couldn't find what's needed to ${action}. Please refresh the page and try again.`,
  408: `The request took too long, so we couldn't ${action}. Please try again.`,
  409: `This was changed by someone else, so we couldn't ${action}. Please refresh the page and try again.`,
  413: 'The file is too large. Please upload a smaller file.',
  415: 'This file type is not supported. Please upload a file in a supported format.',
  422: `Some of the information sent wasn't valid, so we couldn't ${action}. Please check it and try again.`,
  429: 'There are too many requests right now. Please wait a moment and try again.',
}[status] || (status >= 500
  ? `The service ran into a problem while trying to ${action}. Please try again in a few minutes.`
  : `We couldn't ${action}. Please try again.`));

// fetch() rejects with a TypeError when the server can't be reached (Chrome/Edge, Firefox, Safari wording)
const isNetworkError = (e) => e instanceof TypeError && /failed to fetch|networkerror|load failed|network request failed/i.test(e.message);

/**
 * User-facing message for any failure.
 * @param {*} error  API error (has numeric `status`), userError(), network TypeError, or anything else
 * @param {object} options  { action: 'save your change', byStatus: { 404: '…' } } — action completes "We couldn't …"
 */
export function toUserMessage(error, { action = 'complete your request', byStatus = {} } = {}) {
  if (error?.userFacing) return error.message;
  if (typeof error?.status === 'number') return byStatus[error.status] || messageForStatus(error.status, action);
  if (isNetworkError(error)) return NETWORK_MESSAGE;
  return `Something went wrong while trying to ${action}. Please try again.`;
}

/** Wraps a failure as a userError (cancellations and user-facing errors pass through) and logs the original. */
export function toUserError(error, options) {
  if (error?.name === 'AbortError' || error?.userFacing) return error;
  console.error('[api]', error?.status ?? '', error?.message ?? '', error?.body ?? error);
  return userError(toUserMessage(error, options), { status: error?.status, cause: error });
}
