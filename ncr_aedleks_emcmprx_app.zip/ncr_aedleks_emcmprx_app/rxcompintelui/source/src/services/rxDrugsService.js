import { API_CONFIG } from '../config/apiConfig';
import apiClient from './apiClient';

const UPLOAD_FILE_FIELD = 'file';

export async function uploadRxDrugFile(file, { signal } = {}) {
  const form = new FormData();
  form.append(UPLOAD_FILE_FIELD, file, file.name);
  const body = await apiClient.postForm(API_CONFIG.rxDrugs.upload, form, { signal });
  return {
    message: (body && typeof body === 'object' && (body.message || body.detail)) || 'Drug list uploaded successfully.',
    body,
  };
}