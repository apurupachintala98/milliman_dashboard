import { apiGet, apiPutJson, apiPostForm } from './client';
import { userError, toUserError } from './errors';
import { normalizeJobRuns } from './designatedRx';

/**
 * Preventive Rx API (/preventive-rx). Same flow as Designated Network, but every run is ad-hoc
 * (one per day from POST /process-drug-list) — there are no scheduled / historical snapshots or result types.
 */
const BASE = '/preventive-rx';
const enc = encodeURIComponent;

const str = (v) => (v === null || v === undefined ? '' : String(v));
const toYN = (v) => (v === true || /^(y|yes|true|1)$/i.test(str(v).trim()) ? 'Y' : 'N');
const isHttpUrl = (u) => /^https?:\/\//i.test(str(u).trim());

// ── Job runs ─────────────────────────────────────────────────────────────────

/** GET /preventive-rx/job-runs → [{ jobRunId, key, runType: 'adhoc', date, label, current }] newest first */
export async function fetchPrxJobRuns({ signal } = {}) {
  try {
    const body = await apiGet(`${BASE}/job-runs?page_size=100&sort=desc`, { signal });
    const runs = normalizeJobRuns(body).map(r => ({ ...r, runType: 'adhoc', key: `${r.jobRunId}|adhoc`, availableFiles: [] }));
    console.log('[prx] job-runs raw:', body, '→ runs:', runs.map(r => `${r.jobRunId}${r.current ? ' (current)' : ''}`)); // DEBUG [prx]
    return runs;
  } catch (e) {
    throw toUserError(e, { action: 'load the Preventive Rx runs', byStatus: { 404: 'No Preventive Rx runs were found.' } });
  }
}

// ── Page data ────────────────────────────────────────────────────────────────

/** GET /preventive-rx/{id} (+ GET /{id}/edits for saved manual changes) → page model (see toPrxModel). */
export async function fetchPrxSnapshot(jobRunId, { label, signal } = {}) {
  const runLabel = label || jobRunId;
  try {
    const [body, edits] = await Promise.all([
      apiGet(`${BASE}/${enc(jobRunId)}`, { signal }),
      // Edits are optional: a run without saved edits (or an older backend) must still load
      apiGet(`${BASE}/${enc(jobRunId)}/edits`, { signal }).catch(e => (e?.name === 'AbortError' ? Promise.reject(e) : null)),
    ]);
    // DEBUG [prx]: raw response → mapped model
    console.log('[prx] GET', jobRunId, 'raw:', {
      status: body?.status, keys: Object.keys(body || {}),
      drug_data: Array.isArray(body?.drug_data) ? body.drug_data.length : body?.drug_data,
      class_data: Array.isArray(body?.class_data) ? body.class_data.length : body?.class_data,
      carelon_keys: body?.carelon_keys, pbm_keys: body?.pbm_keys?.length, plan_keys: body?.plan_keys?.length,
      firstDrugRow: body?.drug_data?.[0], firstClassRow: body?.class_data?.[0], edits,
    });
    const model = toPrxModel(body, edits);
    console.log('[prx] mapped model:', {
      stage: model.stage, drugs: model.drugs.length, classes: model.classes.length,
      carelonColumns: model.carelonColumns.map(c => `${c.key} <- ${c.rowKey}`),
      pbmColumns: model.pbmColumns.map(c => `${c.key} <- ${c.rowKey}`), planColumns: model.planColumns.map(c => `${c.key} <- ${c.rowKey}`),
      firstDrug: model.drugs[0], firstClass: model.classes[0], manualOverrides: Object.keys(model.manualOverrides).length,
    });
    return model;
  } catch (e) {
    console.error('[prx] GET', jobRunId, 'failed:', e);
    throw toUserError(e, { action: `load the ${runLabel} Preventive Rx run`, byStatus: {
      400: `The ${runLabel} run could not be opened. Please choose another run.`,
      404: `The results for the ${runLabel} run could not be found. They may still be generating. Please try again later or choose another run.`,
    } });
  }
}

/**
 * Preventive Rx status → pipeline step:
 *   'processing' (Queued / Inprogress — keep polling) | 'failed' | 'in-progress' | 'in-review' | 'approved' | null
 * Note "Inprogress" (pipeline running) vs "In Progress" (user opened the run for editing).
 */
export function prxStage(status) {
  // Same rules as Designated Network (toPipelineStage): any running-type status keeps the page polling
  const s = str(status).trim().toLowerCase().replace(/[\s_-]+/g, ' ');
  if (!s) return null;
  if (/(fail|error|cancel|abort)/.test(s)) return 'failed';
  if (/approved/.test(s)) return 'approved';
  if (/(review|complete|updated|success|done|finished)/.test(s)) return 'in-review'; // finished → awaiting review
  if (/(progress|inprogress|running|pending|queued|started|submitted|processing)/.test(s)) return 'processing';
  return null;
}

/** GET /preventive-rx/{id}/status → { status, message, stage } */
export async function fetchPrxStatus(jobRunId, { label, signal } = {}) {
  const runLabel = label || jobRunId;
  try {
    const body = await apiGet(`${BASE}/${enc(jobRunId)}/status`, { signal });
    const status = body?.status ?? null;
    console.log('[prx] status', jobRunId, '→', body, '→ stage:', prxStage(status)); // DEBUG [prx]
    return { jobRunId: body?.schdl_job_run_id ?? jobRunId, status, message: str(body?.message), stage: prxStage(status) };
  } catch (e) {
    throw toUserError(e, { action: `check the status of the ${runLabel} run`, byStatus: {
      404: `The status of the ${runLabel} run is not available yet. Please try again later.`,
    } });
  }
}

// ── Edits / status / submit ──────────────────────────────────────────────────

/** One cell edit in the backend's UpdateLogEntry format (drug = drug_nm, column = payor). */
export function buildPrxCellUpdate({ row, column, oldCovered, newCovered, note, user, updateKey = 1 }) {
  return {
    update_key: updateKey,
    ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    user: user || '',
    drug_nm: row.drug,
    payor: column?.rowKey || column?.key, // the drug_data field edited, e.g. "CRX_PLUS_2022" / "CM-HDHP/HSA"
    old_val: oldCovered ? 'Y' : 'N',
    new_val: newCovered ? 'Y' : 'N',
    comments: str(note).trim(),
  };
}

/** PUT /preventive-rx/{id}/edits — { updated_by, report_status, updates } (entries are appended, never replaced) */
export async function savePrxEdits(jobRunId, { updatedBy, reportStatus, updates = [], label }, { signal } = {}) {
  const runLabel = label || jobRunId;
  try {
    return await apiPutJson(`${BASE}/${enc(jobRunId)}/edits`, {
      updated_by: updatedBy || '',
      report_status: reportStatus || 'in-progress',
      updates: updates.map((u, i) => ({ ...u, update_key: i + 1 })),
    }, { signal });
  } catch (e) {
    throw toUserError(e, { action: 'save your change', byStatus: {
      404: `Your change could not be saved because the ${runLabel} run could not be found. Please refresh the page and try again.`,
    } });
  }
}

/** PUT /preventive-rx/{id}/status — { snapshot_status, updated_by } (Approve → "Approved", Revoke → "In Review") */
export async function updatePrxStatus(jobRunId, { snapshotStatus, updatedBy }, { signal } = {}) {
  const approving = /approved/i.test(snapshotStatus);
  try {
    return await apiPutJson(`${BASE}/${enc(jobRunId)}/status`, { snapshot_status: snapshotStatus, updated_by: updatedBy || '' }, { signal });
  } catch (e) {
    throw toUserError(e, { action: approving ? 'approve this run' : 'revoke the approval', byStatus: {
      400: `This run can't be ${approving ? 'approved' : 'moved back to In Review'} from its current status. Please refresh the page to see its current status.`,
      404: 'This run could not be found. Please refresh the page and try again.',
      409: "This run's status was already changed. Please refresh the page to see its current status.",
    } });
  }
}

export const PRX_UPLOAD_EXTENSIONS = ['.xlsx', '.xls'];

/**
 * Drug list upload: the Excel workbook is sent as-is (multipart `file`); the backend parses it,
 * saves it to S3 and starts the AI comparison.
 * POST /preventive-rx/process-drug-list → 202 { job_run_id, status: "Queued", message }
 */
export async function submitPrxDrugListFile(file, { signal } = {}) {
  const ext = (file?.name || '').includes('.') ? file.name.slice(file.name.lastIndexOf('.')).toLowerCase() : '';
  if (!PRX_UPLOAD_EXTENSIONS.includes(ext)) {
    throw userError(`"${file?.name}" is not supported. Please upload the Preventive Rx drug list as an Excel file (${PRX_UPLOAD_EXTENSIONS.join(', ')}).`);
  }
  if (!file.size) throw userError(`"${file.name}" is empty. Please choose the Preventive Rx drug list workbook.`);
  const form = new FormData();
  form.append('file', file, file.name);
  try {
    const body = await apiPostForm(`${BASE}/process-drug-list`, form, { signal });
    return { jobRunId: body?.job_run_id ?? null, message: str(body?.message) || 'Drug list submitted. Processing has started.', body };
  } catch (e) {
    const invalid = `We couldn't process "${file.name}". Please check that it's the Preventive Rx drug list workbook (drug, drug class and plan columns) and try again.`;
    throw toUserError(e, { action: 'submit the drug list', byStatus: {
      400: invalid, 422: invalid,
      502: 'The AI comparison service could not start processing this drug list. Please try again in a few minutes.',
    } });
  }
}

// ── Response mapping ─────────────────────────────────────────────────────────

const REPORT_STATUSES = ['in-progress', 'in-review', 'approved'];

/**
 * Grid columns from carelon_keys / pbm_keys / plan_keys — one column per plan.
 * Each column: { key (plan key), rowKey (field holding Y/N in drug_data / class_data), label, payor, plan, url }.
 * drug_data keys Carelon plans by the internal plan_key (CRX_ENHANCED, …) while carelon_keys lists
 * "CRL_RX_INT-Enhanced", so the row field is resolved by plan key, then internal plan_key (matched on plan_nm).
 */
function buildColumns(groups, { rowFields, internalKeyByName, isCarelon }) {
  const cols = [];
  for (const g of Array.isArray(groups) ? groups : []) {
    const payor = str(g?.label || g?.payor_nm || g?.key).trim();
    const plans = Array.isArray(g?.plans) && g.plans.length ? g.plans : [{ key: g?.key, plan_nm: '' }];
    for (const p of plans) {
      const key = str(p?.key || p?.plan_key).trim();
      if (!key) continue;
      const plan = str(p?.plan_nm).trim();
      const candidates = [key, internalKeyByName[plan.toLowerCase()], str(p?.plan_key)].filter(Boolean);
      const rowKey = candidates.find(k => rowFields.has(k)) || key;
      cols.push({
        key, rowKey, payor, plan,
        label: isCarelon ? (plan || payor) : [payor, plan].filter(Boolean).join(' · '),
        url: isHttpUrl(p?.url) ? str(p.url).trim() : null,
      });
    }
  }
  return cols;
}

/**
 * Saved edits (GET /{id}/edits updates[]) → { "drug|columnKey": { covered, note, original } } — oldest → newest.
 * `payor` holds the drug_data field (rowKey); it's mapped back to the grid column key.
 */
function overridesFromEdits(edits, columnKeyByField) {
  const out = {};
  const log = (Array.isArray(edits?.updates) ? edits.updates : []).slice().sort((a, b) => str(a?.ts).localeCompare(str(b?.ts)));
  for (const u of log) {
    const drug = str(u?.drug_nm || u?.drug).trim();
    const field = str(u?.payor).trim();
    const col = columnKeyByField[field] || field;
    if (!drug || !col) continue;
    const k = `${drug}|${col}`;
    out[k] = { covered: toYN(u.new_val) === 'Y', note: str(u.comments).trim(), original: out[k] ? out[k].original : toYN(u.old_val) === 'Y' };
  }
  // Back to the original value with no note = reverted → no manual marker
  for (const [k, o] of Object.entries(out)) if (o.covered === o.original && !o.note) delete out[k];
  return out;
}

/** GET /preventive-rx/{id} (+ edits) → what the page renders. */
export function toPrxModel(body, edits = null) {
  const b = body && typeof body === 'object' ? body : {};
  const drugRows = Array.isArray(b.drug_data) ? b.drug_data : [];
  const classRows = Array.isArray(b.class_data) ? b.class_data : [];
  const rowFields = new Set([...drugRows, ...classRows].flatMap(r => Object.keys(r || {})));
  const internalKeyByName = {};
  for (const p of Array.isArray(b.internal_drug_list?.plans) ? b.internal_drug_list.plans : []) {
    if (p?.plan_nm && p?.plan_key) internalKeyByName[str(p.plan_nm).trim().toLowerCase()] = str(p.plan_key);
  }
  const opts = { rowFields, internalKeyByName };
  const carelonColumns = buildColumns(b.carelon_keys, { ...opts, isCarelon: true });
  const pbmColumns = buildColumns(b.pbm_keys, opts);
  const planColumns = buildColumns(b.plan_keys, opts);
  const allColumns = [...carelonColumns, ...pbmColumns, ...planColumns];
  // DEBUG [prx]: columns whose Y/N field isn't in drug_data / class_data render as "—" for every row
  const unmatched = allColumns.filter(c => !rowFields.has(c.rowKey));
  if (unmatched.length) {
    console.warn('[prx] columns with no matching field in drug_data/class_data:',
      unmatched.map(c => ({ key: c.key, rowKey: c.rowKey, payor: c.payor, plan: c.plan })),
      '\nrow fields available:', [...rowFields]);
  }

  const values = (r) => Object.fromEntries(allColumns.map(c => [c.key, toYN(r?.[c.rowKey])]));
  const drugs = drugRows.map(r => ({
    drug: str(r?.drug || r?.drug_nm).trim(),
    drugClass: str(r?.drug_class || r?.drugClass || r?.class_nm).trim(),
    matchNames: Array.isArray(r?.match_names) ? r.match_names.map(str).filter(Boolean) : [],
    ...values(r),
  })).filter(r => r.drug);
  const classes = classRows.map(r => ({ cls: str(r?.cls || r?.class_nm || r?.drug_class).trim(), ...values(r) })).filter(r => r.cls);

  const recSource = [b.recommendations, b.ai_recommendations].find(a => Array.isArray(a) && a.length) || [];
  const recommendations = recSource.map(r => {
    const type = str(r?.recommendation_type ?? r?.type);
    return {
      type: /remov/i.test(type) ? 'remove' : 'add',
      drug: str(r?.brand_nm || r?.drug || r?.drug_nm),
      drugClass: str(r?.drug_class || r?.drugClass),
      reason: str(r?.recommendation || r?.reason),
      competitors: (Array.isArray(r?.payors) ? r.payors : Array.isArray(r?.competitors) ? r.competitors : []).map(str).filter(Boolean),
    };
  }).filter(r => r.drug);

  const reportStatus = REPORT_STATUSES.includes(str(b.report_status).toLowerCase()) ? str(b.report_status).toLowerCase() : null;
  return {
    status: b.status ?? null,
    stage: prxStage(b.status),
    runDate: b.run_date ?? null,
    reportStatus,
    carelonColumns, pbmColumns, planColumns,
    drugs, classes, recommendations,
    manualOverrides: overridesFromEdits(edits, Object.fromEntries(allColumns.flatMap(c => [[c.rowKey, c.key], [c.key, c.key]]))),
  };
}
