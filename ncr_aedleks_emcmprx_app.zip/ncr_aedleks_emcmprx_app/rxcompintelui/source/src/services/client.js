import { getToken } from '../services/authService';
import { API_BASE_URL } from '../config/apiBaseUrl';

const BASE_URL = API_BASE_URL.replace(/\/+$/, '');

let unauthorizedHandler = null;

export function getBearerToken() {
  return getToken()?.access_token || null;
}

export function onUnauthorized(handler) {
  unauthorizedHandler = handler;
  return () => { if (unauthorizedHandler === handler) unauthorizedHandler = null; };
}

function authHeaders() {
  const token = getBearerToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

function errorMessage(body, res) {
  const detail = body && typeof body === 'object' ? body.detail : null;
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) {
    return detail.map(d => {
      const field = Array.isArray(d?.loc) ? d.loc.filter(x => x !== 'body').join('.') : '';
      return field ? `${field}: ${d?.msg ?? 'invalid'}` : (d?.msg ?? JSON.stringify(d));
    }).join('; ');
  }
  if (typeof body === 'string' && body.length < 200) return body;
  return `${res.status} ${res.statusText || 'Request failed'}`;
}

let sessionCheck = null;
export function verifySession() {
  if (!sessionCheck) {
    sessionCheck = fetch(`${BASE_URL}/auth/me`, { headers: { Accept: 'application/json', ...authHeaders() } })
      .then(r => (r.ok ? true : r.status === 401 || r.status === 403 ? false : null))
      .catch(() => null)
      .finally(() => { setTimeout(() => { sessionCheck = null; }, 2000); });
  }
  return sessionCheck;
}

async function handleResponse(res, { skipAuthHandler = false } = {}) {
  if (res.status === 401 && !skipAuthHandler && unauthorizedHandler) {
    const handler = unauthorizedHandler;
    verifySession().then(valid => {
      if (valid === false) handler({ reason: '401', url: res.url });
      else console.warn(`[auth] ${res.url} returned 401, but /auth/me still accepts the token — staying signed in`);
    });
  }
  let body = null;
  const text = await res.text();
  if (text) {
    try { body = JSON.parse(text); } catch { body = text; }
  }
  if (!res.ok) {
    throw new ApiError(errorMessage(body, res), res.status, body);
  }
  return body;
}

export async function apiGet(path, { signal } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      ...authHeaders(),
    },
    signal,
  });
  return handleResponse(res);
}

export async function apiPostJson(path, data, { signal, skipAuthHandler = false } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(data),
    signal,
  });
  return handleResponse(res, { skipAuthHandler });
}

export async function apiPutJson(path, data, { signal } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'PUT',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...authHeaders(),
    },
    body: JSON.stringify(data),
    signal,
  });
  return handleResponse(res);
}

export async function apiPostForm(path, formData, { signal } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      ...authHeaders(),
    },
    body: formData,
    signal,
  });
  return handleResponse(res);
}

function filenameFromDisposition(header) {
  if (!header) return null;
  const star = /filename\*\s*=\s*(?:UTF-8'')?([^;]+)/i.exec(header);
  if (star) { try { return decodeURIComponent(star[1].trim().replace(/^"|"$/g, '')); } catch { /* fall through */ } }
  const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(header);
  return plain ? plain[1].trim() : null;
}

export async function apiDownload(path, { signal } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'GET',
    headers: { ...authHeaders() },
    signal,
  });
  const contentType = res.headers.get('Content-Type') || '';
  if (!res.ok || contentType.includes('application/json')) {
    const body = await handleResponse(res); // throws on error (401 → onUnauthorized)
    const url = body && typeof body === 'object'
      ? (body.url || body.download_url || body.presigned_url || body.s3_url || body.file_url)
      : null;
    if (!url) throw new ApiError('Export response did not include a file or download URL', res.status, body);
    return { url, filename: (body.filename || body.file_name || null) };
  }
  const blob = await res.blob();
  return { blob, filename: filenameFromDisposition(res.headers.get('Content-Disposition')), contentType };
}

export function saveDownload({ blob, url, filename }) {
  const a = document.createElement('a');
  const href = blob ? URL.createObjectURL(blob) : url;
  a.href = href;
  if (filename) a.download = filename;
  if (!blob) { a.target = '_blank'; a.rel = 'noopener'; }
  document.body.appendChild(a);
  a.click();
  a.remove();
  if (blob) setTimeout(() => URL.revokeObjectURL(href), 10000);
}