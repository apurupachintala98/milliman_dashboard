import React, { createContext, useContext, useState, useCallback } from 'react';
import { CheckCircle, XCircle, Info, X, AlertTriangle } from 'lucide-react';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const showToast = useCallback((message, type = 'info') => {
    setToasts(prev => {
      if (prev.some(t => t.message === message && t.type === type)) return prev;
      const id = Date.now().toString();
      setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 5000);
      return [...prev, { id, message, type }];
    });
  }, []);

  const dismiss = useCallback((id) => setToasts(prev => prev.filter(t => t.id !== id)), []);

  const bgMap = { success: 'bg-[#00BBBA]', error: 'bg-[#E3725F]', info: 'bg-[#1A3673]', warning: 'bg-amber-500' };
  const IconMap = { success: CheckCircle, error: XCircle, info: Info, warning: AlertTriangle };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2" style={{ maxWidth: '90vw', width: 'max-content' }}>
        {toasts.map(toast => {
          const Icon = IconMap[toast.type];
          return (
            <div key={toast.id} className={`${bgMap[toast.type]} text-white flex items-start gap-3 px-4 py-3 rounded-lg shadow-lg text-sm w-full animate-in`}>
              <Icon size={16} className="flex-shrink-0" />
              <span style={{ whiteSpace: 'nowrap' }}>{toast.message}</span>
              <button onClick={() => dismiss(toast.id)} className="flex-shrink-0 hover:opacity-70"><X size={14} /></button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
