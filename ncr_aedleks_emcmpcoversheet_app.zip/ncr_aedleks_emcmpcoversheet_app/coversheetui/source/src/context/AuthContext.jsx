import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

const ROLE_PERMISSIONS = {
  'Read-Only':        ['view_dashboard', 'access_admin'],
  'Demand Manager':   ['view_dashboard', 'submit_review', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan'],
  'Financial Analyst':['view_dashboard', 'submit_review', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan'],
  'Governance':       ['view_dashboard', 'edit_coversheet', 'submit_review', 'approve_reject', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan', 'override_section1'],

};

const AuthContext = createContext(null);

function readUserFromStorage() {
  try {
    const raw = sessionStorage.getItem('user');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser]               = useState(readUserFromStorage);
  const [activeRole, setActiveRole]   = useState(() => readUserFromStorage()?.role ?? null);
  const [availableRoles, setAvailableRoles] = useState([]);

  // Keep state in sync when another tab/component fires 'userLoggedIn'
  useEffect(() => {
    const syncFromStorage = () => {
      const stored = readUserFromStorage();
      setUser(stored);
      setActiveRole(stored?.role ?? null);
    };

    window.addEventListener('userLoggedIn', syncFromStorage);
    window.addEventListener('storage', syncFromStorage);
    return () => {
      window.removeEventListener('userLoggedIn', syncFromStorage);
      window.removeEventListener('storage', syncFromStorage);
    };
  }, []);

  const login = useCallback((userIdOrEmpId) => {
    // Legacy shim: still supports direct userId login for any existing callers,
    // but real authentication now goes through LoginPage → sessionStorage.
    const stored = readUserFromStorage();
    if (stored) {
      setUser(stored);
      setActiveRole(stored.role ?? stored.roles?.[0] ?? null);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('jwt_token');
    sessionStorage.clear();
    setUser(null);
    setActiveRole(null);
  }, []);

  const switchRole = useCallback((role) => {
    setActiveRole(role);
  }, []);

  const setRoles = useCallback((roles) => {
    setAvailableRoles(roles ?? []);
  }, []);

  const can = useCallback((action) => {
    if (!activeRole) return false;
    return ROLE_PERMISSIONS[activeRole]?.includes(action) ?? false;
  }, [activeRole]);

  const canAccessCin = useCallback((cin) => {
    if (!user) return false;
    const access = user.cinAccess ?? ['ALL'];
    return access.includes('ALL') || access.includes(cin);
  }, [user]);

  /**
   * Resolves all roles the current user is eligible for on a given coversheet phase.
   *
   * Returns { defaultRole, availableRoles }:
   *   - defaultRole:    the first matched role (or 'Read-Only' if no match)
   *   - availableRoles: all roles the user may switch to, always includes 'Read-Only'
   *
   * access_control slots → role mapping:
   *   demand_manager / demand_manager_backup   → 'Demand Manager'
   *   financial_analyst / financial_analyst_backup → 'Financial Analyst'
   *   (only granted when permissions includes 'coversheet:edit')
   */
  const resolvePhaseRole = useCallback((accessControl) => {
    // Collect every possible identifier the logged-in user might be known by
    const candidateIds = [
      user?.userId,
      user?.employeeId,
      user?.user_id,
      (() => { try { return JSON.parse(sessionStorage.getItem('auth') ?? '{}').userId; } catch { return null; } })(),
    ]
      .filter(Boolean)
      .map(v => String(v).trim().toUpperCase());

    if (!accessControl || candidateIds.length === 0) {
      return { defaultRole: 'Read-Only', availableRoles: ['Read-Only'] };
    }

    const slots = [
      { slot: accessControl.demand_manager,           role: 'Demand Manager' },
      { slot: accessControl.demand_manager_backup,    role: 'Demand Manager' },
      { slot: accessControl.financial_analyst,        role: 'Financial Analyst' },
      { slot: accessControl.financial_analyst_backup, role: 'Financial Analyst' },
    ];

    // Collect all distinct roles this user is matched to (preserving order, deduped)
    const matchedRoles = [];
    for (const { slot, role } of slots) {
      if (!slot) continue;
      const slotUser = String(slot.user_name ?? '').trim().toUpperCase();
      if (candidateIds.includes(slotUser)) {
        const hasEdit = (slot.permissions ?? []).includes('coversheet:edit');
        const grantedRole = hasEdit ? role : 'Read-Only';
        if (!matchedRoles.includes(grantedRole)) matchedRoles.push(grantedRole);
      }
    }

    if (matchedRoles.length === 0) {
      return { defaultRole: 'Read-Only', availableRoles: ['Read-Only'] };
    }

    // Always include Read-Only as a manual fallback option
    const availableRoles = [...matchedRoles];
    if (!availableRoles.includes('Read-Only')) availableRoles.push('Read-Only');

    return { defaultRole: matchedRoles[0], availableRoles };
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, activeRole, availableRoles, login, logout, switchRole, setRoles, can, canAccessCin, resolvePhaseRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
