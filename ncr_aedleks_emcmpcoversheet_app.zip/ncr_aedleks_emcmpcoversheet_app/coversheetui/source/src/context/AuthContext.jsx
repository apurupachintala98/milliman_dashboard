import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

const ROLE_PERMISSIONS = {
  'Read-Only':        ['view_dashboard', 'access_admin'],
  'Demand Manager':   ['view_dashboard', 'submit_review', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan'],
  'Financial Analyst':['view_dashboard', 'submit_review', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan'],
  'Governance':       ['view_dashboard', 'edit_coversheet', 'submit_review', 'approve_reject', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan', 'access_admin'],

};

export function getRolePermissions(role) {
  return ROLE_PERMISSIONS[role] ?? [];
}

// Returns true if the user's JWT roles include 'governance'.
function hasGovernanceRole(user) {
  return (user?.roles ?? []).some(r => String(r).toLowerCase().includes('governance'));
}

// Build the available-roles list from JWT only (used on dashboard / no coversheet context).
// Order: Governance (if JWT has it) → Read-Only.
function jwtAvailableRoles(user) {
  const list = [];
  if (hasGovernanceRole(user)) list.push('Governance');
  if (!list.includes('Read-Only')) list.push('Read-Only');
  return list;
}

// Derive the best default active role from the stored user object (JWT-based, no config context).
// Governance from the JWT always wins.
function deriveDefaultRole(user) {
  if (!user) return null;
  if (hasGovernanceRole(user)) return 'Governance';
  return user.role ?? user.roles?.[0] ?? null;
}

const AuthContext = createContext(null);

function readUserFromStorage() {
  try {
    const raw = sessionStorage.getItem('user');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser]               = useState(readUserFromStorage);
  const [activeRole, setActiveRole]   = useState(() => deriveDefaultRole(readUserFromStorage()));
  const [availableRoles, setAvailableRoles] = useState(() => {
    const stored = readUserFromStorage();
    return stored ? jwtAvailableRoles(stored) : [];
  });

  // Keep state in sync when another tab/component fires 'userLoggedIn'
  useEffect(() => {
    const syncFromStorage = () => {
      const stored = readUserFromStorage();
      setUser(stored);
      setActiveRole(deriveDefaultRole(stored));
      setAvailableRoles(stored ? jwtAvailableRoles(stored) : []);
    };

    window.addEventListener('userLoggedIn', syncFromStorage);
    window.addEventListener('storage', syncFromStorage);
    return () => {
      window.removeEventListener('userLoggedIn', syncFromStorage);
      window.removeEventListener('storage', syncFromStorage);
    };
  }, []);

  const login = useCallback((userIdOrEmpId) => {
    // Legacy shim: still supports direct userId login for any existing callers,
    // but real authentication now goes through LoginPage → sessionStorage.
    const stored = readUserFromStorage();
    if (stored) {
      setUser(stored);
      setActiveRole(deriveDefaultRole(stored));
      setAvailableRoles(jwtAvailableRoles(stored));
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('jwt_token');
    sessionStorage.clear();
    setUser(null);
    setActiveRole(null);
  }, []);

  const switchRole = useCallback((role) => {
    setActiveRole(role);
  }, []);

  const setRoles = useCallback((roles) => {
    setAvailableRoles(roles ?? []);
  }, []);

  // Call this when leaving a coversheet (e.g. back to dashboard) to reset the
  // role dropdown to only the JWT-level roles (not config-API slot roles).
  const resetToJwtRoles = useCallback(() => {
    const stored = readUserFromStorage();
    setActiveRole(deriveDefaultRole(stored));
    setAvailableRoles(stored ? jwtAvailableRoles(stored) : []);
  }, []);

  const can = useCallback((action) => {
    if (!activeRole) return false;
    return ROLE_PERMISSIONS[activeRole]?.includes(action) ?? false;
  }, [activeRole]);

  const canAccessCin = useCallback((cin) => {
    if (!user) return false;
    const access = user.cinAccess ?? ['ALL'];
    return access.includes('ALL') || access.includes(cin);
  }, [user]);

  /**
   * Resolves all roles the current user is eligible for on a given coversheet phase.
   *
   * Returns { defaultRole, availableRoles }:
   *   - defaultRole:    Governance if the JWT has it (always), otherwise first slot role,
   *                     otherwise Read-Only.
   *   - availableRoles: Governance (if JWT) → slot roles (DM/FA) → Read-Only.
   *                     The user can switch to any of these from the dropdown.
   *
   * access_control slots → role mapping:
   *   demand_manager / demand_manager_backup       → 'Demand Manager'
   *   financial_analyst / financial_analyst_backup → 'Financial Analyst'
   *   (only granted when the slot's permissions include 'coversheet:edit')
   */
  const resolvePhaseRole = useCallback((accessControl) => {
    const isGov = hasGovernanceRole(user);

    // Collect every possible identifier the logged-in user might be known by
    const candidateIds = [
      user?.userId,
      user?.employeeId,
      user?.user_id,
      (() => { try { return JSON.parse(sessionStorage.getItem('auth') ?? '{}').userId; } catch { return null; } })(),
    ]
      .filter(Boolean)
      .map(v => String(v).trim().toUpperCase());

    // ── Step 1: check config-API access_control slots ─────────────────────────
    const slotRoles = []; // e.g. ['Demand Manager'] or ['Financial Analyst']
    if (accessControl && candidateIds.length > 0) {
      const slots = [
        { slot: accessControl.demand_manager,           role: 'Demand Manager' },
        { slot: accessControl.demand_manager_backup,    role: 'Demand Manager' },
        { slot: accessControl.financial_analyst,        role: 'Financial Analyst' },
        { slot: accessControl.financial_analyst_backup, role: 'Financial Analyst' },
      ];
      for (const { slot, role } of slots) {
        if (!slot) continue;
        const slotUser = String(slot.user_name ?? '').trim().toUpperCase();
        if (candidateIds.includes(slotUser)) {
          const hasEdit = (slot.permissions ?? []).includes('coversheet:edit');
          const grantedRole = hasEdit ? role : 'Read-Only';
          if (!slotRoles.includes(grantedRole)) slotRoles.push(grantedRole);
        }
      }
    }

    // ── Step 2: build available list (Governance first → slot roles → Read-Only) ─
    // Governance is always first so the user can switch to it from the dropdown.
    const available = [];
    if (isGov) available.push('Governance');
    for (const r of slotRoles) {
      if (!available.includes(r)) available.push(r);
    }
    if (!available.includes('Read-Only')) available.push('Read-Only');

    // ── Step 3: pick default ──────────────────────────────────────────────────
    // Governance is always the default when the JWT has it, regardless of slot matches.
    // Slot roles (DM/FA) are available in the dropdown for the user to switch to.
    const defaultRole = isGov ? 'Governance' : (slotRoles[0] ?? 'Read-Only');

    return { defaultRole, availableRoles: available };
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, activeRole, availableRoles, login, logout, switchRole, setRoles, resetToJwtRoles, can, canAccessCin, resolvePhaseRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
