export const MOCK_USERS = [
  { id: 'u1', name: 'Sarah Johnson', email: 'sarah.johnson@elevancehealth.com', employeeId: 'AH40101', roles: ['Demand Manager'], cinAccess: ['CIN0013697', 'CIN0013699', 'CIN0013701'], avatar: 'SJ' },
  { id: 'u2', name: 'Michael Chen', email: 'michael.chen@elevancehealth.com', employeeId: 'AH40102', roles: ['Financial Analyst'], cinAccess: ['CIN0013697', 'CIN0013698', 'CIN0013700'], avatar: 'MC' },
  { id: 'u3', name: 'Patricia Williams', email: 'patricia.williams@elevancehealth.com', employeeId: 'AH40103', roles: ['Governance'], cinAccess: ['ALL'], avatar: 'PW' },
  { id: 'u4', name: 'David Martinez', email: 'david.martinez@elevancehealth.com', employeeId: 'AH40104', roles: ['Read-Only'], cinAccess: ['CIN0013697', 'CIN0013698'], avatar: 'DM' },
  { id: 'u5', name: 'Lisa Thompson', email: 'lisa.thompson@elevancehealth.com', employeeId: 'AH40105', roles: ['Read-Only'], cinAccess: ['CIN0013698', 'CIN0013700'], avatar: 'LT' },
  { id: 'u6', name: 'Robert Kim', email: 'robert.kim@elevancehealth.com', employeeId: 'AH40106', roles: ['Admin'], cinAccess: ['ALL'], avatar: 'RK' },
  { id: 'u7', name: 'Amanda Foster', email: 'amanda.foster@elevancehealth.com', employeeId: 'AF40130', roles: ['Financial Analyst', 'Governance'], cinAccess: ['ALL'], avatar: 'AF' },
];

export const PORTFOLIO_GROUPS = {
  'Medical Management': ['PI – Medical Edits', 'Utilization Management', 'Case Management', 'Disease Management'],
  'Pharmacy': ['Rx Cost Management', 'Specialty Pharmacy', 'PBM Optimization'],
  'Network': ['Network Optimization', 'Value-Based Care', 'Provider Performance'],
  'Quality': ['HEDIS Improvement', 'Stars Program', 'Clinical Quality'],
};

// Dummy commit - 2

export const MOCK_COVERSHEETS = [
  {
    id: 'cs1', cin: 'CIN0013697', snowCardId: 'SNOW-87423', name: 'PI-Medical Edits Q1 Screening 2024',
    type: 'Screening', portfolioGroup: 'Medical Management', portfolio: 'PI – Medical Edits',
    status: 'In Review', createdDate: '2024-01-15', lastModified: '2024-01-28',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp1', number: 'BP-2024-001-A', fiscalPeriod: 'FY2024', market: 'Ohio', lob: 'Commercial', mbu: 'MBU-OH-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'Commercial HMO Ohio Savings', currency: 'USD' },
      { id: 'bp2', number: 'BP-2024-001-B', fiscalPeriod: 'FY2024', market: 'Indiana', lob: 'Medicare', mbu: 'MBU-IN-MED', sbu: 'SBU-MED', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'Medicare Advantage Indiana Savings', currency: 'USD' },
      { id: 'bp3', number: 'BP-2024-001-C', fiscalPeriod: 'FY2024', market: 'Virginia', lob: 'Medicaid', mbu: 'MBU-VA-MCD', sbu: 'SBU-MCD', metric: 'Savings', metricType: 'COC-FI', metricFrequency: 'Monthly', description: 'Medicaid Virginia Savings', currency: 'USD' },
    ],
    costPlans: [
      { id: 'cp1', number: 'CP-2024-001-A', description: 'IT Infrastructure Setup', costType: 'IT Expense', metric: 'Cost', metricType: 'Implementation', metricFrequency: 'One-time' },
      { id: 'cp2', number: 'CP-2024-001-B', description: 'Project Manager FTE', costType: 'FTE Request', metric: 'Cost', metricType: 'Ongoing', metricFrequency: 'Monthly' },
    ],
  },
  {
    id: 'cs2', cin: 'CIN0013698', snowCardId: 'SNOW-87501', name: 'Rx Cost Mgmt MVA Jan 2024',
    type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Approved', createdDate: '2024-01-08', lastModified: '2024-01-25',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: true,
    benefitPlans: [
      { id: 'bp4', number: 'BP-2024-002-A', fiscalPeriod: 'FY2024', market: 'Texas', lob: 'Commercial', mbu: 'MBU-TX-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'Rx Savings Texas Commercial', currency: 'USD' },
    ],
    costPlans: [],
  },
  {
    id: 'cs3', cin: 'CIN0013699', snowCardId: 'SNOW-87612', name: 'Network Optimization Screening 2024',
    type: 'Screening', portfolioGroup: 'Network', portfolio: 'Network Optimization',
    status: 'Draft', createdDate: '2024-01-22', lastModified: '2024-01-22',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: false, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp5', number: 'BP-2024-003-A', fiscalPeriod: 'FY2024', market: 'Georgia', lob: 'Commercial', mbu: 'MBU-GA-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Quarterly', description: 'Network Savings Georgia', currency: 'USD' },
    ],
    costPlans: [
      { id: 'cp3', number: 'CP-2024-003-A', description: 'Analytics Platform License', costType: 'IT Expense', metric: 'Cost', metricType: 'Ongoing', metricFrequency: 'Annual' },
    ],
  },
  {
    id: 'cs4', cin: 'CIN0013700', snowCardId: 'SNOW-87734', name: 'HEDIS Improvement Closing 2023',
    type: 'Closing', portfolioGroup: 'Quality', portfolio: 'HEDIS Improvement',
    status: 'Approved', createdDate: '2023-12-01', lastModified: '2024-01-10',
    createdBy: 'Michael Chen', demandManager: 'Amanda Foster', financialAnalyst: 'Michael Chen',
    backupDM: 'Sarah Johnson', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp6', number: 'BP-2023-004-A', fiscalPeriod: 'FY2023', market: 'California', lob: 'Medicare', mbu: 'MBU-CA-MED', sbu: 'SBU-MED', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Annual', description: 'Stars Quality Savings CA', currency: 'USD' },
    ],
    costPlans: [],
  },
  {
    id: 'cs5', cin: 'CIN0013701', snowCardId: 'SNOW-87890', name: 'Utilization Management MVA Feb 2024',
    type: 'MVA', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'In Progress', createdDate: '2024-01-30', lastModified: '2024-02-02',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: true, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp7', number: 'BP-2024-005-A', fiscalPeriod: 'FY2024', market: 'New York', lob: 'Commercial', mbu: 'MBU-NY-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'UM Savings NY Commercial', currency: 'USD' },
      { id: 'bp8', number: 'BP-2024-005-B', fiscalPeriod: 'FY2024', market: 'New Jersey', lob: 'Medicaid', mbu: 'MBU-NJ-MCD', sbu: 'SBU-MCD', metric: 'Savings', metricType: 'COC-FI', metricFrequency: 'Monthly', description: 'UM Medicaid NJ', currency: 'USD' },
    ],
    costPlans: [
      { id: 'cp4', number: 'CP-2024-005-A', description: 'Clinical Staff FTE x3', costType: 'FTE Request', metric: 'Cost', metricType: 'Ongoing', metricFrequency: 'Monthly' },
    ],
  },
  {
    id: 'cs5b', cin: 'CIN0013701', snowCardId: 'SNOW-87851', name: 'Utilization Management MVA Jan 2024',
    type: 'MVA', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'Approved', createdDate: '2023-12-15', lastModified: '2024-01-05',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: true, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs5c', cin: 'CIN0013701', snowCardId: 'SNOW-87812', name: 'Utilization Management MVA Dec 2023',
    type: 'MVA', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'Approved', createdDate: '2023-11-20', lastModified: '2023-12-10',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: false, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs2b', cin: 'CIN0013698', snowCardId: 'SNOW-87462', name: 'Rx Cost Mgmt MVA Dec 2023',
    type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Approved', createdDate: '2023-11-10', lastModified: '2023-12-01',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs2c', cin: 'CIN0013698', snowCardId: 'SNOW-87430', name: 'Rx Cost Mgmt MVA Nov 2023',
    type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Inactive', createdDate: '2023-10-05', lastModified: '2023-11-01',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: false, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs8x', cin: 'CIN0013698', snowCardId: 'SNOW-87420', name: 'Rx Cost Management Screening 2024',
    type: 'Screening', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Approved', createdDate: '2023-12-20', lastModified: '2024-01-05',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs9x', cin: 'CIN0013700', snowCardId: 'SNOW-87700', name: 'HEDIS Improvement Screening 2023',
    type: 'Screening', portfolioGroup: 'Quality', portfolio: 'HEDIS Improvement',
    status: 'Approved', createdDate: '2023-10-01', lastModified: '2023-11-15',
    createdBy: 'Michael Chen', demandManager: 'Amanda Foster', financialAnalyst: 'Michael Chen',
    backupDM: 'Sarah Johnson', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs7x', cin: 'CIN0013701', snowCardId: 'SNOW-87800', name: 'Utilization Management Screening 2024',
    type: 'Screening', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'Approved', createdDate: '2024-01-10', lastModified: '2024-01-20',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: true, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs6x', cin: 'CIN0013702', snowCardId: 'SNOW-76211', name: 'Case Management Screening 2023',
    type: 'Screening', portfolioGroup: 'Medical Management', portfolio: 'Case Management',
    status: 'Inactive', createdDate: '2023-09-15', lastModified: '2023-11-30',
    createdBy: 'Amanda Foster', demandManager: 'Amanda Foster', financialAnalyst: 'Michael Chen',
    backupDM: 'Patricia Williams', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  { id: 'cs6',  cin: 'CIN0013702', snowCardId: 'SNOW-88001', name: 'Stars Program Screening Q2 2024',       type: 'Screening', portfolioGroup: 'Quality',             portfolio: 'Stars Program',            status: 'Draft',       createdDate: '2024-02-05', lastModified: '2024-02-05', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Patricia Williams', backupDM: 'Sarah Johnson',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs7',  cin: 'CIN0013703', snowCardId: 'SNOW-88102', name: 'Clinical Quality Closing FY2023',        type: 'Closing',   portfolioGroup: 'Quality',             portfolio: 'Clinical Quality',         status: 'Approved',    createdDate: '2023-10-12', lastModified: '2024-01-18', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs8',  cin: 'CIN0013704', snowCardId: 'SNOW-88203', name: 'HEDIS Screening Q1 2024',                type: 'Screening', portfolioGroup: 'Quality',             portfolio: 'HEDIS Improvement',        status: 'In Progress', createdDate: '2024-01-18', lastModified: '2024-02-01', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs9',  cin: 'CIN0013705', snowCardId: 'SNOW-88304', name: 'Pharmacy Formulary MVA Mar 2024',        type: 'MVA',       portfolioGroup: 'Pharmacy',            portfolio: 'Rx Cost Management',       status: 'In Review',   createdDate: '2024-02-10', lastModified: '2024-02-20', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Michael Chen',      backupDM: 'Amanda Foster',      backupFA: 'Patricia Williams', hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs10', cin: 'CIN0013706', snowCardId: 'SNOW-88405', name: 'Specialty Drug Management Screening',    type: 'Screening', portfolioGroup: 'Pharmacy',            portfolio: 'Specialty Drug Mgmt',      status: 'Draft',       createdDate: '2024-02-14', lastModified: '2024-02-14', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Sarah Johnson',     backupDM: 'Patricia Williams',  backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs11', cin: 'CIN0013707', snowCardId: 'SNOW-88506', name: 'Care Management Closing FY2023',         type: 'Closing',   portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'Approved',    createdDate: '2023-09-05', lastModified: '2024-01-02', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Michael Chen',      backupDM: 'Sarah Johnson',      backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs12', cin: 'CIN0013708', snowCardId: 'SNOW-88607', name: 'PI-Coding Accuracy MVA Q1 2024',         type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'PI – Medical Edits',       status: 'In Progress', createdDate: '2024-01-25', lastModified: '2024-02-08', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs13', cin: 'CIN0013709', snowCardId: 'SNOW-88708', name: 'Network Adequacy Screening 2024',        type: 'Screening', portfolioGroup: 'Network',             portfolio: 'Network Optimization',     status: 'Draft',       createdDate: '2024-02-18', lastModified: '2024-02-18', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs14', cin: 'CIN0013710', snowCardId: 'SNOW-88809', name: 'Provider Contracting Closing FY2023',    type: 'Closing',   portfolioGroup: 'Network',             portfolio: 'Provider Contracting',     status: 'Inactive',    createdDate: '2023-08-15', lastModified: '2023-12-20', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs15', cin: 'CIN0013711', snowCardId: 'SNOW-88910', name: 'Value-Based Care MVA Feb 2024',          type: 'MVA',       portfolioGroup: 'Network',             portfolio: 'Value-Based Care',         status: 'In Review',   createdDate: '2024-02-01', lastModified: '2024-02-22', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs16', cin: 'CIN0013712', snowCardId: 'SNOW-89011', name: 'Telehealth Expansion Screening',         type: 'Screening', portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'Draft',       createdDate: '2024-02-22', lastModified: '2024-02-22', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs17', cin: 'CIN0013713', snowCardId: 'SNOW-89112', name: 'Behavioral Health MVA Q1 2024',          type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'Utilization Management',   status: 'In Progress', createdDate: '2024-01-28', lastModified: '2024-02-15', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs18', cin: 'CIN0013714', snowCardId: 'SNOW-89213', name: 'Diabetes Management Closing FY2023',     type: 'Closing',   portfolioGroup: 'Quality',             portfolio: 'Clinical Quality',         status: 'Approved',    createdDate: '2023-11-01', lastModified: '2024-01-15', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs19', cin: 'CIN0013715', snowCardId: 'SNOW-89314', name: 'Generic Drug Substitution Screening',    type: 'Screening', portfolioGroup: 'Pharmacy',            portfolio: 'Rx Cost Management',       status: 'In Review',   createdDate: '2024-02-08', lastModified: '2024-02-25', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs20', cin: 'CIN0013716', snowCardId: 'SNOW-89415', name: 'Inpatient Readmissions MVA Mar 2024',    type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'PI – Medical Edits',       status: 'Draft',       createdDate: '2024-02-25', lastModified: '2024-02-25', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs21', cin: 'CIN0013717', snowCardId: 'SNOW-89516', name: 'Preventive Care Gap Closing FY2023',     type: 'Closing',   portfolioGroup: 'Quality',             portfolio: 'HEDIS Improvement',        status: 'Approved',    createdDate: '2023-09-20', lastModified: '2024-01-08', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs22', cin: 'CIN0013718', snowCardId: 'SNOW-89617', name: 'Ambulatory Surgery Screening Q2',        type: 'Screening', portfolioGroup: 'Medical Management',  portfolio: 'Utilization Management',   status: 'In Progress', createdDate: '2024-02-28', lastModified: '2024-03-01', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs23', cin: 'CIN0013719', snowCardId: 'SNOW-89718', name: 'Mail Order Pharmacy MVA Apr 2024',       type: 'MVA',       portfolioGroup: 'Pharmacy',            portfolio: 'Specialty Drug Mgmt',      status: 'In Review',   createdDate: '2024-03-05', lastModified: '2024-03-10', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs24', cin: 'CIN0013720', snowCardId: 'SNOW-89819', name: 'ER Diversion Closing FY2023',            type: 'Closing',   portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'Inactive',    createdDate: '2023-07-10', lastModified: '2023-11-30', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs25', cin: 'CIN0013721', snowCardId: 'SNOW-89920', name: 'Prior Authorization Screening 2024',     type: 'Screening', portfolioGroup: 'Medical Management',  portfolio: 'Utilization Management',   status: 'Draft',       createdDate: '2024-03-08', lastModified: '2024-03-08', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs26', cin: 'CIN0013722', snowCardId: 'SNOW-90021', name: 'Long-Term Care MVA Q2 2024',             type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'In Progress', createdDate: '2024-03-12', lastModified: '2024-03-18', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs27', cin: 'CIN0013723', snowCardId: 'SNOW-90122', name: 'Biosimilar Adoption Closing FY2024',     type: 'Closing',   portfolioGroup: 'Pharmacy',            portfolio: 'Rx Cost Management',       status: 'Approved',    createdDate: '2024-01-05', lastModified: '2024-03-20', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs28', cin: 'CIN0013724', snowCardId: 'SNOW-90223', name: 'Specialty Pharmacy Screening Q2 2024',   type: 'Screening', portfolioGroup: 'Pharmacy',            portfolio: 'Specialty Drug Mgmt',      status: 'In Review',   createdDate: '2024-03-15', lastModified: '2024-03-22', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs29', cin: 'CIN0013725', snowCardId: 'SNOW-90324', name: 'Outpatient Cost Control MVA Apr 2024',   type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'PI – Medical Edits',       status: 'Draft',       createdDate: '2024-03-20', lastModified: '2024-03-20', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs30', cin: 'CIN0013726', snowCardId: 'SNOW-90425', name: 'Home Health Optimization Closing FY24',  type: 'Closing',   portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'In Progress', createdDate: '2024-02-20', lastModified: '2024-03-25', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
];

export const MOCK_AUDIT_ENTRIES = [
  { id: 'a1', coversheetId: 'cs1', timestamp: '2024-01-28 14:32:15', userId: 'u1', userName: 'Sarah Johnson', userRole: 'Demand Manager', action: 'Status Changed', section: 'Overview', details: 'Status updated to In Review', fieldName: 'Status', previousValue: 'In Progress', newValue: 'In Review' },
  { id: 'a2', coversheetId: 'cs1', timestamp: '2024-01-27 11:15:42', userId: 'u2', userName: 'Michael Chen', userRole: 'Financial Analyst', action: 'Financial Model Uploaded', section: 'Financial Model', details: 'Uploaded PI_Medical_Edits_Model_v3.xlsx — Manual model type selected' },
  { id: 'a3', coversheetId: 'cs1', timestamp: '2024-01-27 10:05:33', userId: 'u2', userName: 'Michael Chen', userRole: 'Financial Analyst', action: 'Data Uploaded', section: 'Data Upload', details: 'Uploaded Claims_Data_Q1_2024.xlsx (2.4 MB), tagged as Claims / Primary' },
  { id: 'a4', coversheetId: 'cs1', timestamp: '2024-01-26 16:44:19', userId: 'u2', userName: 'Michael Chen', userRole: 'Financial Analyst', action: 'Scaling Retrieved', section: 'Membership Scaling', details: 'Medical scaling data retrieved from SharePoint — Medical_Scaling_Tool_2024.xlsx' },
  { id: 'a5', coversheetId: 'cs1', timestamp: '2024-01-25 09:22:07', userId: 'u7', userName: 'Amanda Foster', userRole: 'Governance', action: 'Role Switch', section: 'System', details: 'Switched from Financial Analyst to Governance' },
  { id: 'a6', coversheetId: 'cs1', timestamp: '2024-01-15 13:00:00', userId: 'u1', userName: 'Sarah Johnson', userRole: 'Demand Manager', action: 'Coversheet Created', section: 'System', details: 'Coversheet created from SNOW trigger — SNOW-87423' },
  { id: 'a7', coversheetId: 'cs2', timestamp: '2024-01-25 15:30:00', userId: 'u3', userName: 'Patricia Williams', userRole: 'Governance', action: 'Approved', section: 'Overview', details: 'Coversheet approved for SNOW push' },
  { id: 'a8', coversheetId: 'cs2', timestamp: '2024-01-25 16:05:12', userId: 'u1', userName: 'Sarah Johnson', userRole: 'Demand Manager', action: 'Pushed to SNOW', section: 'Overview', details: 'Data pushed to ServiceNow — SNOW-87501. Excel attached (Rx_Cost_Mgmt_MVA_Jan2024.xlsx)' },
];

export const MOCK_NOTIFICATIONS = [
  { id: 'n1', message: 'Coversheet CIN-2024-001 is ready for your review', type: 'info', timestamp: '2024-01-28 14:32', read: false, coversheetId: 'cs1' },
  { id: 'n2', message: 'CIN-2024-002: SNOW reconciliation error — benefit plan mismatch detected', type: 'error', timestamp: '2024-01-27 09:15', read: false, coversheetId: 'cs2' },
  { id: 'n3', message: 'CIN-2024-002 has been approved by Patricia Williams', type: 'success', timestamp: '2024-01-25 15:30', read: true, coversheetId: 'cs2' },
  { id: 'n4', message: 'CIN-2024-003: New coversheet created from SNOW trigger SNOW-87612', type: 'info', timestamp: '2024-01-22 13:00', read: true, coversheetId: 'cs3' },
  { id: 'n5', message: 'CIN-2024-005 status changed to In Progress', type: 'info', timestamp: '2024-02-02 10:45', read: false, coversheetId: 'cs5' },
];

export const MOCK_SCALING_FACTORS = [
  { market: 'Ohio', lob: 'Commercial', mbu: 'MBU-OH-COM', factor: 1.124, membershipCount: 245800 },
  { market: 'Ohio', lob: 'Medicare', mbu: 'MBU-OH-MED', factor: 0.987, membershipCount: 89200 },
  { market: 'Indiana', lob: 'Commercial', mbu: 'MBU-IN-COM', factor: 1.089, membershipCount: 178300 },
  { market: 'Indiana', lob: 'Medicare', mbu: 'MBU-IN-MED', factor: 1.203, membershipCount: 67400 },
  { market: 'Virginia', lob: 'Medicaid', mbu: 'MBU-VA-MCD', factor: 0.934, membershipCount: 312100 },
  { market: 'Virginia', lob: 'Commercial', mbu: 'MBU-VA-COM', factor: 1.056, membershipCount: 156700 },
  { market: 'Georgia', lob: 'Commercial', mbu: 'MBU-GA-COM', factor: 1.178, membershipCount: 201500 },
  { market: 'Texas', lob: 'Commercial', mbu: 'MBU-TX-COM', factor: 1.312, membershipCount: 489200 },
];

export const MOCK_FINANCIAL_OUTPUTS = [
  { state: 'Ohio', mbu: 'MBU-OH-COM', unscaledSavings: 1245000, scaledSavings: 1399530, scalingFactor: 1.124 },
  { state: 'Ohio', mbu: 'MBU-OH-MED', unscaledSavings: 678000, scaledSavings: 669186, scalingFactor: 0.987 },
  { state: 'Indiana', mbu: 'MBU-IN-COM', unscaledSavings: 892000, scaledSavings: 971388, scalingFactor: 1.089 },
  { state: 'Indiana', mbu: 'MBU-IN-MED', unscaledSavings: 445000, scaledSavings: 535335, scalingFactor: 1.203 },
  { state: 'Virginia', mbu: 'MBU-VA-MCD', unscaledSavings: 1123000, scaledSavings: 1048942, scalingFactor: 0.934 },
  { state: 'Virginia', mbu: 'MBU-VA-COM', unscaledSavings: 567000, scaledSavings: 598752, scalingFactor: 1.056 },
];

export const MEMBERSHIP_MARKETS = ['CA','CA/HMO','CA/PPO','CO','CT','GA','IN','KY','ME','MO','NC','NH','NV','NY','OH','VA','WI','National'];

export const MOCK_MEMBERSHIP_SUMMARY = [
  { mbu: 'CSBO National Accounts',                           period: 'Plan',   values: { CA:42187,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5888,  KY:12284,  ME:0,      MO:0,      NC:508764, NH:228,    NV:0,      NY:1604334, OH:148304, VA:316,    WI:0,      National:622022  } },
  { mbu: 'CSBO National Accounts',                           period: 'Actual', values: { CA:39842,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5102,  KY:11897,  ME:0,      MO:0,      NC:492381, NH:204,    NV:0,      NY:1588210, OH:141892, VA:298,    WI:0,      National:599662  } },
  { mbu: 'CSBO Local Large Group',                           period: 'Plan',   values: { CA:2168894,'CA/HMO':0,    'CA/PPO':0,    CO:179131, CT:476325, GA:1876486,IN:1827185,KY:857165, ME:241383, MO:488371, NC:0,      NH:401551, NV:0,      NY:0,      OH:2716008,VA:5177399,WI:1681732,National:18016630} },
  { mbu: 'CSBO Local Large Group',                           period: 'Actual', values: { CA:2104211,'CA/HMO':0,    'CA/PPO':0,    CO:165842, CT:451203, GA:1798423,IN:1762041,KY:831492, ME:228761, MO:469834, NC:0,      NH:388214, NV:0,      NY:0,      OH:2634917,VA:5023841,WI:1598204,National:17477983} },
  { mbu: 'CSBO Small Group',                                 period: 'Plan',   values: { CA:218570, 'CA/HMO':0,    'CA/PPO':0,    CO:44921,  CT:100413, GA:434016, IN:389145, KY:183241, ME:58912,  MO:104823, NC:0,      NH:88412,  NV:0,      NY:0,      OH:614231, VA:1183421,WI:382145, National:3824250 } },
  { mbu: 'CSBO Small Group',                                 period: 'Actual', values: { CA:211384, 'CA/HMO':0,    'CA/PPO':0,    CO:42183,  CT:96814,  GA:418423, IN:374812, KY:178234, ME:56123,  MO:101234, NC:0,      NH:85412,  NV:0,      NY:0,      OH:591823, VA:1142384,WI:368241, National:3707067 } },
  { mbu: 'GBD Medicare Advantage All',                       period: 'Plan',   values: { CA:103651, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:522022, WI:79842,  National:822522  } },
  { mbu: 'GBD Medicare Advantage Non-Special Needs Plans',   period: 'Plan',   values: { CA:0,      'CA/HMO':83250,'CA/PPO':20401,CO:0,      CT:29245,  GA:0,      IN:1079557,KY:1463408,ME:0,      MO:233457, NC:0,      NH:0,      NV:0,      NY:3888271,OH:1150430,VA:0,      WI:0,      National:852151  } },
  { mbu: 'GBD Medicare Advantage Non-Special Needs Plans',   period: 'Actual', values: { CA:0,      'CA/HMO':80142,'CA/PPO':18923,CO:0,      CT:27831,  GA:0,      IN:1042381,KY:1411234,ME:0,      MO:221834, NC:0,      NH:0,      NV:0,      NY:3741823,OH:1108412,VA:0,      WI:0,      National:812151  } },
  { mbu: 'GBD Medicare Advantage SNP MMP',                   period: 'Plan',   values: { CA:117161, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:852512  } },
  { mbu: 'GBD Medicare Advantage SNP MMP',                   period: 'Actual', values: { CA:110234, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:810342  } },
  { mbu: 'GBD Medicare Advantage SNP D-SNP',                 period: 'Plan',   values: { CA:551054, 'CA/HMO':0,    'CA/PPO':0,    CO:124252, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:812511  } },
  { mbu: 'GBD Medicare Advantage SNP D-SNP',                 period: 'Actual', values: { CA:528431, 'CA/HMO':0,    'CA/PPO':0,    CO:118423, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:781234  } },
  { mbu: 'GBD Medicaid Dual',                                period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4919024,GA:6894250,IN:889122, KY:0,      ME:3404528,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3239812,WI:0,      National:24710536} },
  { mbu: 'GBD Medicaid Dual',                                period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4712341,GA:6634812,IN:852341, KY:0,      ME:3281234,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3108423,WI:0,      National:23812341} },
  { mbu: 'GBD Medicaid Plan',                                period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4919024,GA:6894250,IN:889122, KY:0,      ME:3404528,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3239812,WI:0,      National:24710536} },
  { mbu: 'GBD Medicaid Plan',                                period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4712341,GA:6634812,IN:852341, KY:0,      ME:3281234,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3108423,WI:0,      National:23812341} },
];

export const MOCK_COST_LINE_ITEMS = [
  { id: 'cl1', costType: 'IT Expense', description: 'Server Infrastructure Upgrade', amount: 125000, period: 'Q1 2024', source: 'Uploaded' },
  { id: 'cl2', costType: 'IT Expense', description: 'Software Licensing – Analytics Platform', amount: 48000, period: 'Annual', source: 'Uploaded' },
  { id: 'cl3', costType: 'FTE Request', description: 'Project Manager (1.0 FTE)', amount: 95000, period: 'Annual', source: 'Uploaded' },
  { id: 'cl4', costType: 'FTE Request', description: 'Clinical Analyst (0.5 FTE)', amount: 52500, period: 'Annual', source: 'Manual' },
  { id: 'cl5', costType: 'Other', description: 'Vendor Consulting Fees', amount: 35000, period: 'Q1–Q2 2024', source: 'Manual' },
];

export const MOCK_UPLOADED_FILES = [
  { id: 'f1', name: 'Claims_Data_Q1_2024.xlsx', size: '2.4 MB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 10:05' },
  { id: 'f2', name: 'Membership_Summary_2024.xlsx', size: '1.1 MB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 10:07' },
  { id: 'f3', name: 'PI_Medical_Edits_Model_v3.xlsx', size: '3.8 MB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 11:15' },
  { id: 'f4', name: 'SQL_Query_Claims_Extract.sql', size: '4 KB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 10:06' },
];

export const PREVIEW_TABLE_DATA = Array.from({ length: 25 }, (_, i) => ({
  claimId: `CLM-${(100000 + i).toString()}`,
  memberId: `MEM-${(200000 + i * 17).toString()}`,
  dateOfService: `2024-01-${(i % 28 + 1).toString().padStart(2, '0')}`,
  paidAmount: (Math.random() * 5000 + 200).toFixed(2),
  market: ['Ohio', 'Indiana', 'Virginia'][i % 3],
  lob: ['Commercial', 'Medicare', 'Medicaid'][i % 3],
  diagnosisCode: ['Z79.4', 'I10', 'E11.9', 'J45.50', 'M54.5'][i % 5],
}));
