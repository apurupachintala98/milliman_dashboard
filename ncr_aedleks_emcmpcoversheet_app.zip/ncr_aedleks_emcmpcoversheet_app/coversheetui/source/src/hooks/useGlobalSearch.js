import { useState, useMemo } from 'react';

/**
 * Reusable hook for global text search across all string fields of a dataset.
 * @param {Array} data - Array of row objects to search through
 * @returns {{ searchTerm, setSearchTerm, searchedData }}
 */
export const useGlobalSearch = (data) => {
  const [searchTerm, setSearchTerm] = useState('');

  const searchedData = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return data;
    return data.filter(row =>
      Object.values(row).some(v => typeof v === 'string' && v.toLowerCase().includes(q))
    );
  }, [data, searchTerm]);

  return { searchTerm, setSearchTerm, searchedData };
};
