import { useState, useMemo } from 'react';

/**
 * Reusable hook for table sorting
 * @param {Array} data - Array of data to sort
 * @param {string} initialField - Initial field to sort by
 * @param {string} initialDir - Initial sort direction ('asc' or 'desc')
 */
export const useTableSort = (data, initialField = '', initialDir = 'asc') => {
  const [sortField, setSortField] = useState(initialField);
  const [sortDir, setSortDir] = useState(initialDir);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const sortedData = useMemo(() => {
    if (!sortField) return data;

    return [...data].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];

      // Handle null/undefined
      if (aVal == null && bVal == null) return 0;
      if (aVal == null) return 1;
      if (bVal == null) return -1;

      // Numeric comparison
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
      }

      // String comparison
      const aStr = String(aVal).toLowerCase();
      const bStr = String(bVal).toLowerCase();
      const comparison = aStr.localeCompare(bStr);
      return sortDir === 'asc' ? comparison : -comparison;
    });
  }, [data, sortField, sortDir]);

  return {
    sortField,
    sortDir,
    handleSort,
    sortedData,
  };
};
