import { useState, useMemo } from 'react';

/**
 * Reusable hook for table filtering
 * @param {Array} data - Array of data to filter
 * @param {Object} initialFilters - Initial filter values { field: value }
 */
export const useTableFilter = (data, initialFilters = {}) => {
  const [filters, setFilters] = useState(initialFilters);
  const [pendingFilters, setPendingFilters] = useState(initialFilters);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const updatePendingFilter = (field, value) => {
    setPendingFilters(prev => ({ ...prev, [field]: value }));
  };

  const applyFilters = () => {
    setFilters(pendingFilters);
    setIsFilterOpen(false);
  };

  const clearPendingFilters = () => {
    const cleared = Object.keys(pendingFilters).reduce((acc, key) => {
      acc[key] = '';
      return acc;
    }, {});
    setPendingFilters(cleared);
  };

  const clearAllFilters = () => {
    const cleared = Object.keys(filters).reduce((acc, key) => {
      acc[key] = '';
      return acc;
    }, {});
    setFilters(cleared);
    setPendingFilters(cleared);
  };

  const cancelFilters = () => {
    setPendingFilters(filters);
    setIsFilterOpen(false);
  };

  const filteredData = useMemo(() => {
    return data.filter(row => {
      return Object.entries(filters).every(([field, value]) => {
        if (!value) return true; // No filter applied
        const rowValue = row[field];
        if (rowValue == null) return false;
        return String(rowValue).toLowerCase().includes(String(value).toLowerCase());
      });
    });
  }, [data, filters]);

  const activeFilterCount = useMemo(() => {
    return Object.values(filters).filter(v => v !== '').length;
  }, [filters]);

  return {
    filters,
    pendingFilters,
    isFilterOpen,
    setIsFilterOpen,
    updatePendingFilter,
    applyFilters,
    clearPendingFilters,
    clearAllFilters,
    cancelFilters,
    filteredData,
    activeFilterCount,
  };
};
