import { useState, useEffect, useCallback, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ChevronDown, LogOut, LayoutDashboard, Settings, Clock, Check, User } from 'lucide-react';
import elevanceLogo from '../assets/Elevance_Health_logo.png';
import elevanceIcon from '../assets/Elevance_E_logo.png';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { coversheetApi } from '../config/apiConfig';

// Derive display name and initials avatar from the real LDAP user object
function getUserDisplay(user) {
  if (!user) return { name: '', avatar: '?' };
  const name = user.displayName ?? user.userId ?? '';
  const avatar = name.split(/[\s,]+/).filter(Boolean).map(w => w[0].toUpperCase()).slice(0, 2).join('') || '?';
  return { name, avatar };
}

export default function Layout({ children }) {
  const { user, logout, can, activeRole, availableRoles, switchRole } = useAuth();
  const { name: userName, avatar: userAvatar } = getUserDisplay(user);
  const { showToast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(true);
  const [recentCoversheets, setRecentCoversheets] = useState([]);
  const [roleDropOpen, setRoleDropOpen] = useState(false);
  const roleDropRef = useRef(null);

  const fetchRecent = useCallback(() => {
    coversheetApi.getRecentCoversheets(10)
      .then(data => setRecentCoversheets(data.items || []))
      .catch(() => setRecentCoversheets([]));
  }, []);

  useEffect(() => { fetchRecent(); }, [fetchRecent]);

  useEffect(() => { fetchRecent(); }, [location.pathname, fetchRecent]);

  useEffect(() => {
    if (!roleDropOpen) return;
    const handle = (e) => { if (roleDropRef.current && !roleDropRef.current.contains(e.target)) setRoleDropOpen(false); };
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [roleDropOpen]);

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ── Sidebar wrapper ── */}
      <div style={{ position: 'relative', flexShrink: 0, width: collapsed ? 64 : 240, transition: 'width 0.28s cubic-bezier(0.4,0,0.2,1)' }}>
        {/* Toggle button — outside aside so it never gets clipped */}
        <button
          onClick={() => setCollapsed(v => !v)}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          style={{
            position: 'absolute', top: 17, right: -11, zIndex: 100,
            width: 22, height: 22,
            background: '#fff', border: '1px solid #d1d5db',
            borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
            color: '#1A3673',
          }}
        >
          {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
        </button>

        <aside
          style={{ width: '100%', height: '100%', overflow: 'hidden' }}
          className="bg-[#1A3673] flex flex-col overflow-y-auto"
        >
        {/* App header */}
        <div className="border-b border-white/10" style={{ padding: collapsed ? '12px 0 12px 8px' : '12px 16px', display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'flex-start', minHeight: 64, transition: 'padding 0.28s cubic-bezier(0.4,0,0.2,1)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, overflow: 'hidden' }}>
            {/* E icon — visible when collapsed */}
            <img src={elevanceIcon} alt="E" style={{ height: 40, width: 40, objectFit: 'contain', flexShrink: 0, opacity: collapsed ? 1 : 0, transform: collapsed ? 'scale(1)' : 'scale(0.8)', transition: 'opacity 0.2s ease, transform 0.28s cubic-bezier(0.4,0,0.2,1)', position: collapsed ? 'relative' : 'absolute', pointerEvents: 'none' }} />
            {/* Full logo + text — visible when expanded */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: collapsed ? 0 : 1, transform: collapsed ? 'translateX(-10px)' : 'translateX(0)', transition: 'opacity 0.22s ease 0.06s, transform 0.28s cubic-bezier(0.4,0,0.2,1)', pointerEvents: 'none' }}>
              <img src={elevanceLogo} alt="Elevance Health" style={{ height: 38, width: 'auto', objectFit: 'contain', flexShrink: 0 }} />
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <span style={{ fontSize: 15, fontWeight: 700, color: '#fff', lineHeight: 1.3, whiteSpace: 'nowrap' }}>Cost of Care</span>
                <span style={{ fontSize: 11, color: 'rgba(147,197,253,0.9)', lineHeight: 1.3, whiteSpace: 'normal', wordBreak: 'break-word', maxWidth: 120 }}>Value Realization (CoCVR)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3">
          <Link to="/dashboard"
            title={collapsed ? 'Dashboard' : ''}
            className={isActive('/dashboard') ? 'sidebar-item-active' : 'sidebar-item'}
            style={{ justifyContent: collapsed ? 'center' : undefined, padding: collapsed ? '10px 0 10px 8px' : undefined, transition: 'background 0.18s ease, color 0.18s ease, padding 0.28s cubic-bezier(0.4,0,0.2,1)' }}
            onMouseEnter={e => { if (collapsed) e.currentTarget.querySelector('svg').style.transform = 'scale(1.25)'; }}
            onMouseLeave={e => { if (collapsed) e.currentTarget.querySelector('svg').style.transform = 'scale(1)'; }}>
            <LayoutDashboard size={20} style={{ flexShrink: 0, transition: 'transform 0.18s cubic-bezier(0.34,1.56,0.64,1)' }} />
            <span style={{ opacity: collapsed ? 0 : 1, maxWidth: collapsed ? 0 : 200, overflow: 'hidden', whiteSpace: 'nowrap', transition: 'opacity 0.2s ease, max-width 0.28s cubic-bezier(0.4,0,0.2,1)' }}>Dashboard</span>
          </Link>

          {/* Recently accessed */}
          <div className="mt-3" style={{ position: 'relative' }}>
            {!collapsed && <p className="sidebar-section-label flex items-center gap-1"><Clock size={9} /> RECENTLY ACCESSED</p>}
            {collapsed && <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', margin: '6px 8px' }} />}

            {/* Collapsed: icon button — expands the sidebar */}
            {collapsed && (
              <button
                onClick={() => setCollapsed(false)}
                title="Recently Accessed"
                style={{ width:'100%', display:'flex', justifyContent:'center', padding:'10px 0 10px 2px', background:'none', border:'none', cursor:'pointer', color:'rgba(255,255,255,0.55)', transition: 'background 0.18s ease, color 0.18s ease' }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.12)'; e.currentTarget.style.color = '#fff'; e.currentTarget.querySelector('svg').style.transform = 'scale(1.25)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'rgba(255,255,255,0.55)'; e.currentTarget.querySelector('svg').style.transform = 'scale(1)'; }}
              >
                <Clock size={20} style={{ transition: 'transform 0.18s cubic-bezier(0.34,1.56,0.64,1)' }} />
              </button>
            )}

            {/* Expanded: inline list */}
            {!collapsed && (
              recentCoversheets.length === 0 ? (
                <p style={{ fontSize:10, color:'rgba(255,255,255,0.35)', padding:'6px 12px' }}>No recently accessed</p>
              ) : (
                recentCoversheets.map(cs => (
                  <Link key={cs.cvrsht_id} to={`/coversheet/${cs.cvrsht_id}`}
                    onClick={() => setCollapsed(true)}
                    className={`${isActive(`/coversheet/${cs.cvrsht_id}`) ? 'sidebar-item-active' : 'sidebar-item'} flex-col !items-start gap-0 py-1.5`}>
                    <span className="text-[11px] font-medium leading-tight truncate w-full">{cs.recommended_model_name || ''}</span>
                    <span className="text-[9px] text-blue-300 mt-0.5">{cs.u_cin}{cs.cvrsht_actn_stts_cd ? ` · ${cs.cvrsht_actn_stts_cd.charAt(0).toUpperCase() + cs.cvrsht_actn_stts_cd.slice(1)}` : ''}</span>
                  </Link>
                ))
              )
            )}
          </div>



        </nav>

        {/* User info at bottom */}
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', padding: collapsed ? '14px 0' : '12px 16px', transition: 'padding 0.28s cubic-bezier(0.4,0,0.2,1)' }}>
          {/* Avatar row — always visible, layout shifts smoothly */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'flex-start', gap: collapsed ? 0 : 10, marginBottom: collapsed ? 10 : 8, transition: 'justify-content 0.28s ease, gap 0.28s ease, margin-bottom 0.28s ease' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#44B8F3', color: '#fff', fontSize: 14, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              {userAvatar}
            </div>
            {/* Name — fade in when expanded */}
            <div style={{ minWidth: 0, opacity: collapsed ? 0 : 1, maxWidth: collapsed ? 0 : 160, overflow: 'hidden', transition: 'opacity 0.22s ease, max-width 0.28s cubic-bezier(0.4,0,0.2,1)' }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: '#fff', whiteSpace: 'nowrap', margin: 0 }}>{userName}</p>
            </div>
          </div>
          {/* Sign out row — icon always visible, text fades in */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'flex-start', transition: 'justify-content 0.28s ease' }}>
            <button
              onClick={() => { logout(); navigate('/'); }}
              title="Sign out"
              style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(147,197,253,0.8)', padding: '2px 0', fontSize: 13, transition: 'color 0.18s ease, transform 0.18s cubic-bezier(0.34,1.56,0.64,1)' }}
              onMouseEnter={e => { e.currentTarget.style.color = '#fff'; e.currentTarget.style.transform = collapsed ? 'scale(1.3)' : 'scale(1.06)'; }}
              onMouseLeave={e => { e.currentTarget.style.color = 'rgba(147,197,253,0.8)'; e.currentTarget.style.transform = 'scale(1)'; }}
            >
              <LogOut size={20} style={{ flexShrink: 0 }} />
              <span style={{ opacity: collapsed ? 0 : 1, maxWidth: collapsed ? 0 : 80, overflow: 'hidden', whiteSpace: 'nowrap', transition: 'opacity 0.2s ease, max-width 0.28s cubic-bezier(0.4,0,0.2,1)' }}>Sign out</span>
            </button>
          </div>
        </div>
      </aside>
      </div>{/* /sidebar wrapper */}

      {/* ── Main area ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="bg-[#E1EDFF] border-b border-[#C7DEFF] px-6 py-2.5 flex items-center justify-between flex-shrink-0 shadow-sm">
          <div className="flex items-center gap-1 text-xs text-gray-400">
            <span className="text-[#1A3673] font-medium">MCM Command Center</span>
            <span>›</span>
            <span className="text-[#1A3673] font-bold text-sm">Cost of Care Value Realization (CoCVR)</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Role dropdown — separate from avatar */}
            {user && activeRole && (
              <div style={{ position: 'relative' }} ref={roleDropRef}>
                <button
                  onClick={() => availableRoles.length > 1 && setRoleDropOpen(v => !v)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    background: '#fff', border: '1px solid #d1d5db',
                    borderRadius: 999, padding: '4px 10px',
                    cursor: availableRoles.length > 1 ? 'pointer' : 'default',
                    outline: 'none',
                  }}
                >
                  <User size={12} style={{ color: '#1A3673', flexShrink: 0 }} />
                  <span style={{ fontSize: 12, fontWeight: 600, color: '#1A3673', whiteSpace: 'nowrap' }}>
                    {activeRole}
                  </span>
                  {availableRoles.length > 1 && (
                    <ChevronDown size={11} style={{ color: '#6b7280' }} />
                  )}
                </button>

                {/* Dropdown */}
                {roleDropOpen && availableRoles.length > 1 && (
                  <div style={{
                    position: 'absolute', top: 'calc(100% + 6px)', right: 0, zIndex: 9999,
                    background: '#fff', borderRadius: 10, boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                    border: '1px solid #e5e7eb', minWidth: 170, overflow: 'hidden',
                  }}>
                    <p style={{ padding: '8px 12px 4px', fontSize: 9, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.5px', margin: 0 }}>
                      Switch Role
                    </p>
                    {availableRoles.map(r => (
                      <button
                        key={r}
                        onClick={() => { switchRole(r); setRoleDropOpen(false); showToast(`Role switched to "${r}"`, 'info'); }}
                        style={{
                          width: '100%', textAlign: 'left', padding: '7px 12px',
                          fontSize: 12, fontWeight: r === activeRole ? 700 : 500,
                          color: r === activeRole ? '#1A3673' : '#374151',
                          background: r === activeRole ? '#E1EDFF' : 'none',
                          border: 'none', cursor: 'pointer',
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 6,
                        }}
                        onMouseEnter={e => { if (r !== activeRole) e.currentTarget.style.background = '#f9fafb'; }}
                        onMouseLeave={e => { if (r !== activeRole) e.currentTarget.style.background = 'none'; }}
                      >
                        {r}
                        {r === activeRole && <Check size={11} style={{ color: '#1A3673', flexShrink: 0 }} />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Avatar — separate */}
            {user && (
              <div className="w-7 h-7 rounded-full bg-[#1A3673] text-white text-xs font-bold flex items-center justify-center">
                {userAvatar}
              </div>
            )}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto bg-[#F5F5F5]">
          {children}
        </main>
      </div>
    </div>
  );
}
