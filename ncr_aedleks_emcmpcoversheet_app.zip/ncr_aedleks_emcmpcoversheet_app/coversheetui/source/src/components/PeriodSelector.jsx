import { ChevronDown } from 'lucide-react';

export const FISCAL_MONTHS = [
  'Feb-24','Mar-24','Apr-24','May-24','Jun-24','Jul-24',
  'Aug-24','Sep-24','Oct-24','Nov-24','Dec-24','Jan-25',
];

export const QUARTERS = [
  { label: 'Q1 (Feb–Apr)', months: ['Feb-24','Mar-24','Apr-24'] },
  { label: 'Q2 (May–Jul)', months: ['May-24','Jun-24','Jul-24'] },
  { label: 'Q3 (Aug–Oct)', months: ['Aug-24','Sep-24','Oct-24'] },
  { label: 'Q4 (Nov–Jan)', months: ['Nov-24','Dec-24','Jan-25'] },
];

export const FISCAL_YEARS = ['FY2022', 'FY2023', 'FY2024', 'FY2025'];

export default function PeriodSelector({ value, onChange }) {
  const setMode = (mode) => {
    if (mode === 'Monthly')        onChange({ mode, month: value.month ?? FISCAL_MONTHS[0] });
    else if (mode === 'Quarterly') onChange({ mode, quarter: value.quarter ?? QUARTERS[0].label });
    else                           onChange({ mode, year: value.year ?? 'FY2024' });
  };

  const dropdownCls = (active) =>
    `relative flex items-center rounded-full px-2.5 py-1 border transition text-xs font-medium ${
      active
        ? 'border-[#1A3673] bg-[#E3F4FD] text-[#1A3673]'
        : 'border-gray-200 bg-white text-gray-400'
    }`;

  return (
    <div className="flex items-center gap-1.5">

      {/* Month pill + dropdown */}
      <div className={dropdownCls(value.mode === 'Monthly')} onClick={() => setMode('Monthly')} style={{ cursor: 'pointer' }}>
        <span className="text-[10px] font-semibold mr-1.5 whitespace-nowrap">Monthly</span>
        <select
          value={value.showAll && value.mode === 'Monthly' ? '__all__' : (value.month ?? FISCAL_MONTHS[0])}
          onClick={e => e.stopPropagation()}
          onChange={e => {
            if (e.target.value === '__all__') onChange({ mode: 'Monthly', showAll: true });
            else onChange({ mode: 'Monthly', month: e.target.value, showAll: false });
          }}
          className="bg-transparent outline-none cursor-pointer text-xs font-medium appearance-none pr-4"
        >
          <option value="__all__">All Months</option>
          {FISCAL_MONTHS.map(m => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
        <ChevronDown size={11} className="pointer-events-none absolute right-2 text-current opacity-60" />
      </div>

      {/* Quarter pill + dropdown */}
      <div className={dropdownCls(value.mode === 'Quarterly')} onClick={() => setMode('Quarterly')} style={{ cursor: 'pointer' }}>
        <span className="text-[10px] font-semibold mr-1.5 whitespace-nowrap">Quarterly</span>
        <select
          value={value.showAll && value.mode === 'Quarterly' ? '__all__' : (value.quarter ?? QUARTERS[0].label)}
          onClick={e => e.stopPropagation()}
          onChange={e => {
            if (e.target.value === '__all__') onChange({ mode: 'Quarterly', showAll: true });
            else onChange({ mode: 'Quarterly', quarter: e.target.value, showAll: false });
          }}
          className="bg-transparent outline-none cursor-pointer text-xs font-medium appearance-none pr-4"
        >
          <option value="__all__">All Quarters</option>
          {QUARTERS.map(q => (
            <option key={q.label} value={q.label}>{q.label}</option>
          ))}
        </select>
        <ChevronDown size={11} className="pointer-events-none absolute right-2 text-current opacity-60" />
      </div>

      {/* Year pill + dropdown */}
      <div className={dropdownCls(value.mode === 'Yearly')} onClick={() => setMode('Yearly')} style={{ cursor: 'pointer' }}>
        <span className="text-[10px] font-semibold mr-1.5 whitespace-nowrap">Yearly</span>
        <select
          value={value.year ?? 'FY2024'}
          onClick={e => e.stopPropagation()}
          onChange={e => onChange({ mode: 'Yearly', year: e.target.value })}
          className="bg-transparent outline-none cursor-pointer text-xs font-medium appearance-none pr-4"
        >
          {FISCAL_YEARS.map(y => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
        <ChevronDown size={11} className="pointer-events-none absolute right-2 text-current opacity-60" />
      </div>

    </div>
  );
}
