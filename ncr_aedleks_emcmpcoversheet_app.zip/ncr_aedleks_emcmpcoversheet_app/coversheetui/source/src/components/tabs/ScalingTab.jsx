import { useState, useEffect, useRef } from 'react';
import { Database, CheckCircle, Settings, X, Download, Loader2, AlertCircle, BarChart2, ChevronDown } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { membershipScalingApi } from '../../config/apiConfig';
import * as XLSX from 'xlsx';

// ── Shared module-level helpers ───────────────────────────────────────────────
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const currentYear = new Date().getFullYear();

function defaultPeriodForYear(yr) {
  const y2  = String(yr).slice(2);
  const py2 = String(yr - 1).slice(2);
  return { planStart:`Jan-${y2}`, planEnd:`Dec-${y2}`, actualStart:`Jan-${py2}`, actualEnd:`Dec-${py2}` };
}

// Convert ISO "2026-01-01" or already "Jan-26" → "Jan-26"
function isoToMonYY(val) {
  if (!val) return val;
  if (/^\d{4}-\d{2}/.test(val)) {
    const [yr, mm] = val.split('-');
    return `${MONTHS[parseInt(mm) - 1]}-${String(yr).slice(2)}`;
  }
  return val;
}

// Convert "Jan-26" → ISO; isEnd=true gives last day of month
function toIso(mmYY, isEnd = false) {
  if (!mmYY) return undefined;
  const norm = isoToMonYY(mmYY);
  const [mon, y2] = norm.split('-');
  const monthNum = { Jan:1,Feb:2,Mar:3,Apr:4,May:5,Jun:6,Jul:7,Aug:8,Sep:9,Oct:10,Nov:11,Dec:12 };
  const fullYear = parseInt(y2) < 50 ? 2000 + parseInt(y2) : 1900 + parseInt(y2);
  const m  = monthNum[mon] ?? 1;
  const mm = String(m).padStart(2, '0');
  if (!isEnd) return `${fullYear}-${mm}-01`;
  return `${fullYear}-${mm}-${new Date(fullYear, m, 0).getDate()}`;
}

function monthsForYear(yr) {
  const y2 = String(yr).slice(2);
  return MONTHS.map(m => `${m}-${y2}`);
}

// All month options 2022→currentYear+2 for period dropdowns
const ALL_MONTH_OPTIONS = (() => {
  const opts = [];
  for (let y = 2022; y <= currentYear + 2; y++) {
    const y2 = String(y).slice(2);
    MONTHS.forEach(m => opts.push(`${m}-${y2}`));
  }
  return opts;
})();

// ── Membership Adjustment Summary — driven by API summary_scaling_ratios ──────
// market_headers: { "E": "CA", "F": "CA HMO", ... } — defines column order
// summary_scaling_ratios keys use spaces ("CA HMO", "CA PPO")
// membershipGroups: optional — used when market_headers absent (GET /parms) to
// derive column order from the membership_groups[0].markets key insertion order,
// which the API already sends in E→AQ column order.
function buildAdjSummaryRows(ratios, marketHeaders, membershipGroups) {
  if (!ratios) return { markets: [], rows: [] };

  // All markets that appear in any ratio row
  const allRatioMarkets = new Set();
  Object.values(ratios).forEach(obj => Object.keys(obj).forEach(k => allRatioMarkets.add(k)));

  let markets;
  if (marketHeaders && Object.keys(marketHeaders).length > 0) {
    // POST /apply-fctr path: use market_headers object (E→AQ key order)
    const ordered = Object.values(marketHeaders).filter(m => allRatioMarkets.has(m));
    if (allRatioMarkets.has('National') && !ordered.includes('National')) ordered.push('National');
    markets = ordered;
  } else if (membershipGroups?.length > 0) {
    // GET /parms path: no market_headers — use key order of first group's markets
    // (API sends them in the same E→AQ column order), exclude Subtotal
    const groupKeys = Object.keys(membershipGroups[0]?.markets ?? {})
      .filter(m => !/^subtotal$/i.test(m) && allRatioMarkets.has(m));
    // Ensure National is last if present
    const withoutNat = groupKeys.filter(m => m !== 'National');
    const nat        = groupKeys.includes('National') ? ['National'] : [];
    markets = [...withoutNat, ...nat];
  } else {
    // Last resort fallback: alphabetical, National last
    markets = [...allRatioMarkets]
      .filter(m => m !== 'National')
      .sort()
      .concat(allRatioMarkets.has('National') ? ['National'] : []);
  }

  // Row definitions — map API snake_case keys → display metric labels
  const ROW_DEFS = [
    { apiKey: 'national_pct_of_csbd_market',    label: 'National as a % of CSBD Market'        },
    { apiKey: 'ca_hmo_vs_ppo_pct_of_ca_market', label: 'CA HMO vs. CA PPO as a % of CA Market' },
    { apiKey: 'national_grs_pct_in',            label: 'National GRS % (IN)'                   },
    { apiKey: 'grs_vs_mcr_adv_pct_of_market',   label: 'GRS vs MCR Adv as a % of Market'       },
    { apiKey: 'national_pcts',                  label: 'National %s'                            },
  ];

  const rows = ROW_DEFS
    .filter(({ apiKey }) => ratios[apiKey])
    .map(({ apiKey, label }) => ({
      metric: label,
      // Multiply by 100: API sends decimals (0.0164 → 1.64%)
      // Keep null as null (undefined market = no data = show —)
      // Keep 0 as 0 (market exists but value is 0% — show 0.00%)
      values: Object.fromEntries(
        Object.entries(ratios[apiKey]).map(([mkt, v]) => [mkt, v == null ? null : v * 100])
      ),
    }));

  return { markets, rows };
}

function MembershipAdjustmentSummary({ summaryRatios, marketHeaders, membershipGroups }) {
  const [open, setOpen] = useState(true);
  const H_ROW = 26;
  const METRIC_W = 260;

  const { markets, rows } = buildAdjSummaryRows(summaryRatios, marketHeaders, membershipGroups);

  return (
    <div className="card overflow-hidden">
      <button type="button" onClick={() => setOpen(o => !o)} aria-expanded={open}
        className="card-header w-full text-left" style={{ cursor:'pointer', flexWrap:'wrap', gap:8 }}>
        <div className="card-title">
          <BarChart2 size={14} />
          Membership Adjustment Summary
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span style={{ fontSize:10, fontWeight:600, color:'#1A3673', background:'#E1EDFF', borderRadius:4, padding:'2px 8px' }}>
            RPM / Claims Edits Formulas
          </span>
          <ChevronDown size={16} style={{ color:'#1A3673', transition:'transform .2s', transform: open ? 'rotate(0deg)' : 'rotate(-90deg)' }} />
        </div>
      </button>

      {open && (
        <div style={{ overflowX:'auto' }}>
          <table style={{ borderCollapse:'collapse', minWidth:'max-content', width:'100%', fontSize:10.5 }}>
            <thead>
              <tr style={{ background:'#1A3673', height:H_ROW }}>
                <th style={{ padding:'0 10px', textAlign:'left', color:'#fff', fontWeight:700, whiteSpace:'nowrap',
                  position:'sticky', left:0, zIndex:10, background:'#1A3673', minWidth:METRIC_W,
                  borderRight:'2px solid rgba(255,255,255,0.25)' }}>Metric</th>
                {markets.map(m => (
                  <th key={m} style={{ padding:'0 10px', textAlign:'right', whiteSpace:'nowrap', minWidth:72, fontWeight:600,
                    color: m==='National'?'#44B8F3':'#fff',
                    background: m==='National'?'rgba(68,184,243,0.15)':'#1A3673',
                    borderLeft: m==='National'?'2px solid rgba(255,255,255,0.25)':undefined }}>{m}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => {
                const rowBg = i % 2 === 0 ? '#fff' : '#f8f9fb';
                return (
                  <tr key={row.metric} style={{ height:H_ROW, background:rowBg, borderTop:'1px solid #f0f0f0' }}>
                    <td style={{ padding:'0 10px', fontWeight:700, fontSize:10, color:'#1A3673', whiteSpace:'nowrap',
                      position:'sticky', left:0, zIndex:5, background:rowBg, minWidth:METRIC_W,
                      borderRight:'2px solid #e5e7eb' }}>{row.metric}</td>
                    {markets.map(m => {
                      // undefined = market not in this row's data → show —
                      // null     = API explicitly null → show —
                      // 0        = valid zero value → show 0.00%
                      const raw = row.values[m];
                      const missing = !(m in row.values) || raw == null;
                      const isNat = m === 'National';
                      return (
                        <td key={m} style={{ padding:'0 10px', textAlign:'right', fontFamily:'monospace', whiteSpace:'nowrap',
                          color: missing ? '#d1d5db' : isNat ? '#1A3673' : '#374151', fontWeight: isNat ? 700 : 400,
                          background: isNat ? 'rgba(68,184,243,0.06)' : undefined,
                          borderLeft: isNat ? '2px solid #e5e7eb' : undefined }}>
                          {missing ? '—' : `${raw.toFixed(2)}%`}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function MembershipTable({ apiData, applied, sourceFile, retrievedAt }) {
  const { showToast } = useToast();

  // Real API shape:
  // membership_groups: [{ membership_type, mbu_label, markets: { "CA": { plan, actual, ratio }, ... } }]
  // market_headers: { "E": "CA", ... } — values are market names matching keys in markets{}
  const groups     = apiData?.membership_groups ?? [];
  const marketHdrs = apiData?.market_headers    ?? {};

  // ── View state: yearly / monthly toggle ─────────────────────────────────────
  const [view, setView] = useState('yearly');

  // FY year tabs — derived from applied.planDataYears (multi-year) or fallback to single plan_year
  const years = applied?.planDataYears?.length
    ? applied.planDataYears
    : (applied?.plan_year ? [String(applied.plan_year)] : [String(currentYear)]);
  const [activeYear, setActiveYear] = useState(() => years[0] ?? String(currentYear));
  const safeActiveYear = years.includes(activeYear) ? activeYear : (years[0] ?? String(currentYear));

  const handleExport = () => {
    try {
      const mktNames = Object.keys(marketHdrs).length > 0
        ? Object.values(marketHdrs)
        : Object.keys(groups[0]?.markets ?? {});

      const wb = XLSX.utils.book_new();

      // ── Sheet 1: Membership Data ──────────────────────────────────────────
      const headers = ['MBU', 'Period', ...mktNames];
      const rows = [headers];
      groups.forEach(grp => {
        const label = grp.mbu_label ?? grp.membership_type ?? '';
        [
          { period: 'Plan',   field: 'plan'   },
          { period: 'Actual', field: 'actual' },
          { period: 'Ratio',  field: 'ratio'  },
        ].forEach(({ period, field }) => {
          const row = [label, period];
          mktNames.forEach(mkt => {
            const val = grp.markets?.[mkt]?.[field] ?? null;
            if (val === null || val === undefined) {
              row.push('');
            } else if (field === 'ratio') {
              const n = parseFloat(val);
              row.push(isNaN(n) ? '' : Math.round(Math.abs(n) > 1 ? n : n * 100) + '%');
            } else {
              const n = parseFloat(val);
              row.push(isNaN(n) ? '' : n);
            }
          });
          rows.push(row);
        });
      });

      const wsData = XLSX.utils.aoa_to_sheet(rows);
      // Style header row bold
      const range = XLSX.utils.decode_range(wsData['!ref']);
      for (let c = range.s.c; c <= range.e.c; c++) {
        const cell = wsData[XLSX.utils.encode_cell({ r: 0, c })];
        if (cell) cell.s = { font: { bold: true } };
      }
      // Column widths
      wsData['!cols'] = [{ wch: 30 }, { wch: 8 }, ...mktNames.map(() => ({ wch: 14 }))];
      XLSX.utils.book_append_sheet(wb, wsData, 'Membership Data');

      // ── Sheet 2: Parameters ───────────────────────────────────────────────
      const paramRows = [
        ['Parameter', 'Value'],
        ['Scenario',        applied?.mbrshp_scnro        ?? ''],
        ['Membership Type', applied?.mbrshp_type         ?? ''],
        ['Plan Year',       applied?.plan_year            ?? ''],
        ['Plan Start',      applied?.planStart            ?? ''],
        ['Plan End',        applied?.planEnd              ?? ''],
        ['Actual Start',    applied?.actualStart          ?? ''],
        ['Actual End',      applied?.actualEnd            ?? ''],
        ['Student Health',  applied?.stdnt_hlth           ?? ''],
        ['LTSS',            applied?.mdcd_ltss            ?? ''],
        ['GA/GRS SHBP',     applied?.ga_grs_shbp_mbrshp  ?? ''],
        ['Ltd Coverage',    applied?.lmtd_cvrg_bh_fmly_plang ?? ''],
        ['CoC Only',        applied?.coc_elgbl_mrkt_only  ?? ''],
        ['Source File',     sourceFile                    ?? ''],
        ['Retrieved At',    retrievedAt                   ?? ''],
      ];
      const wsParams = XLSX.utils.aoa_to_sheet(paramRows);
      wsParams['!cols'] = [{ wch: 22 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, wsParams, 'Parameters');

      const fileName = `MembershipScaling_${applied?.mbrshp_scnro ?? 'export'}_${new Date().toISOString().slice(0,10)}.xlsx`;
      XLSX.writeFile(wb, fileName);
      showToast('Export downloaded', 'success');
    } catch (err) {
      showToast(`Export failed: ${err.message}`, 'error');
    }
  };

  // market_headers may be absent in parms response — fall back to keys from first group's markets.
  // Note: market_headers intentionally omits "Subtotal" — it lives only inside markets{} on each group.
  // We always check the actual market keys for a Subtotal entry and append it separately.
  const baseMarketNames = Object.keys(marketHdrs).length > 0
    ? Object.values(marketHdrs)
    : Object.keys(groups[0]?.markets ?? {}).filter(m => !/^subtotal$/i.test(m));

  // Detect Subtotal from the actual data keys (not market_headers, which omits it)
  const firstGroupKeys = Object.keys(groups[0]?.markets ?? {});
  const subtotalKey    = firstGroupKeys.find(m => /^subtotal$/i.test(m)) ?? null;
  const hasSubtotal    = subtotalKey !== null;
  const marketNames    = baseMarketNames.filter(m => !/^subtotal$/i.test(m));

  const fmtN = (v) => {
    if (v === null || v === undefined) return '—';
    const n = parseFloat(v);
    return isNaN(n) || n === 0 ? '—' : n.toLocaleString();
  };
  const rColor = (v) => {
    const n = parseFloat(v);
    if (v === null || isNaN(n)) return '#9ca3af';
    // normalize to 0–1 scale regardless of whether API returns decimal (0.98) or percent (98)
    const pct = Math.abs(n) > 1 ? n / 100 : n;
    if (pct >= 0.98) return '#00BBBA';
    if (pct >= 0.90) return '#d97706';
    return '#E3725F';
  };
  const rFmt = (v) => {
    if (v === null || v === undefined) return '—';
    const n = parseFloat(v);
    if (isNaN(n)) return '—';
    // If value is already a percentage (>1), show as-is; otherwise convert decimal (0.98 → 98%)
    return `${Math.round(Math.abs(n) > 1 ? n : n * 100)}%`;
  };

  const MBU_W  = 180;
  const PER_W  = 52;
  const COL_W  = 82;
  const H_ROW  = 22;

  // Measure the actual rendered MBU column width so Period sticks immediately after it
  const mbuHeaderRef = useRef(null);
  const [mbuActualW, setMbuActualW] = useState(MBU_W);
  useEffect(() => {
    if (!mbuHeaderRef.current) return;
    const observer = new ResizeObserver(() => {
      if (mbuHeaderRef.current) setMbuActualW(mbuHeaderRef.current.offsetWidth);
    });
    observer.observe(mbuHeaderRef.current);
    setMbuActualW(mbuHeaderRef.current.offsetWidth);
    return () => observer.disconnect();
  }, []);

  const PLAN_BADGE  = { bg:'#00BBBA', text:'#fff', label:'Plan'   };
  const ACT_BADGE   = { bg:'#2861BB', text:'#fff', label:'Actual'  };
  const RATIO_BADGE = { bg:'#1A3673', text:'#fff', label:'Ratio'   };

  if (!groups.length) {
    return (
      <div className="card p-8 flex flex-col items-center justify-center gap-2 text-gray-400">
        <AlertCircle size={28} />
        <p className="text-sm">No membership data returned from the API.</p>
      </div>
    );
  }

  return (
    <div className="card overflow-hidden">
      {/* Card header */}
      <div className="card-header" style={{ flexWrap:'wrap', gap:8 }}>
        <div className="card-title">
          <Database size={14} />
          Membership Adjustment Ratio — {applied?.mbrshp_scnro?.toUpperCase()}
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          {/* FY year tabs — only shown when multiple years selected */}
          {years.length > 1 && (
            <div style={{ display:'flex', background:'#f3f4f6', borderRadius:8, padding:2, gap:2 }}>
              {years.map(yr => (
                <button key={yr} onClick={() => setActiveYear(yr)}
                  style={{ padding:'3px 10px', borderRadius:6, fontSize:10, fontWeight:700, cursor:'pointer', border:'none',
                    background: safeActiveYear === yr ? '#1A3673' : 'transparent',
                    color:      safeActiveYear === yr ? '#fff'    : '#6b7280', transition:'all .15s' }}>
                  FY {yr}
                </button>
              ))}
            </div>
          )}
          {/* Yearly / Monthly toggle */}
          <div style={{ display:'flex', background:'#f3f4f6', borderRadius:8, padding:2, gap:2 }}>
            {['yearly','monthly'].map(v => (
              <button key={v} onClick={() => setView(v)}
                style={{ padding:'3px 12px', borderRadius:6, fontSize:10, fontWeight:600, cursor:'pointer', border:'none',
                  background: view === v ? '#1A3673' : 'transparent',
                  color:      view === v ? '#fff'    : '#6b7280', transition:'all .15s' }}>
                {v === 'yearly' ? 'Yearly' : 'Monthly'}
              </button>
            ))}
          </div>
          <button className="btn-text text-xs flex items-center gap-1" onClick={handleExport}>
            <Download size={12} /> Export
          </button>
        </div>
      </div>

      {/* ════════════  YEARLY VIEW  ════════════ */}
      {view === 'yearly' && <div style={{ overflowX:'auto', overflowY:'auto', maxHeight:'70vh' }}>
        <table style={{ borderCollapse:'collapse', minWidth:'max-content', fontSize:10.5, tableLayout:'fixed' }}>
          <thead style={{ position:'sticky', top:0, zIndex:20 }}>
            <tr style={{ background:'#1A3673', height:H_ROW }}>
              <th ref={mbuHeaderRef} style={{ padding:'0 10px', textAlign:'left', color:'#fff', fontWeight:700,
                whiteSpace:'nowrap', position:'sticky', left:0, zIndex:30, background:'#1A3673',
                width:MBU_W, minWidth:MBU_W, borderRight:'1px solid rgba(255,255,255,0.2)' }}>MBU</th>
              <th style={{ padding:'0 6px', textAlign:'center', color:'#fff', fontWeight:700,
                whiteSpace:'nowrap', position:'sticky', left:mbuActualW, zIndex:30, background:'#1A3673',
                width:PER_W, minWidth:PER_W, borderRight:'2px solid rgba(255,255,255,0.3)' }}>Period</th>
              {marketNames.map((m, i) => (
                <th key={i} style={{ padding:'0 6px', textAlign:'right', whiteSpace:'nowrap',
                  width:COL_W, minWidth:COL_W, fontWeight:600, color:'#fff', background:'#1A3673' }}>{m}</th>
              ))}
              {hasSubtotal && (
                <th style={{ padding:'0 6px', textAlign:'right', whiteSpace:'nowrap',
                  width:COL_W, minWidth:COL_W, fontWeight:700, color:'#fff', background:'#0f2147',
                  borderLeft:'2px solid rgba(255,255,255,0.4)' }}>{subtotalKey}</th>
              )}
            </tr>
          </thead>
          <tbody>
            {groups.map((grp, gi) => {
              const isSub = /subtotal|total/i.test(grp.membership_type ?? '');
              const grpBg = isSub ? '#EEF2FF' : (gi % 2 === 0 ? '#fff' : '#f8f9fb');
              const rows = [
                { badge: PLAN_BADGE,  field: 'plan',   isRatio: false },
                { badge: ACT_BADGE,   field: 'actual', isRatio: false },
                { badge: RATIO_BADGE, field: 'ratio',  isRatio: true  },
              ];
              return rows.map(({ badge, field, isRatio }, ri) => {
                const isFirst = ri === 0;
                const isLast  = ri === 2;
                return (
                  <tr key={`${gi}-${field}`} style={{
                    height: H_ROW,
                    background: isRatio ? (isSub ? '#E8EAF6' : '#f5f5ff') : grpBg,
                    borderTop: isFirst ? '2px solid #e5e7eb' : '1px solid #f0f0f0',
                    borderBottom: isLast ? '1px solid #e5e7eb' : undefined,
                  }}>
                    {/* MBU label — only on first sub-row, spans via visual trick */}
                    <td style={{
                      padding: isFirst ? '0 10px' : '0',
                      fontSize: 10, fontWeight: isSub ? 700 : 600, color: '#1A3673',
                      whiteSpace:'nowrap', verticalAlign: isFirst ? 'middle' : 'top',
                      position:'sticky', left:0, zIndex:10,
                      background: isRatio ? (isSub ? '#E8EAF6' : '#f5f5ff') : grpBg,
                      width:MBU_W, minWidth:MBU_W,
                      borderRight:'1px solid #e5e7eb',
                      overflow:'hidden', textOverflow:'ellipsis',
                    }}>
                      {isFirst ? (grp.mbu_label ?? grp.membership_type ?? '—') : ''}
                    </td>
                    {/* Period badge */}
                    <td style={{
                      padding:'0 4px', textAlign:'center',
                      position:'sticky', left:mbuActualW, zIndex:10,
                      background: '#fff',
                      width:PER_W, minWidth:PER_W,
                      borderRight:'2px solid #e5e7eb',
                    }}>
                      <span style={{
                        display:'inline-block', padding:'1px 6px', borderRadius:3,
                        fontSize:9, fontWeight:700, letterSpacing:'0.02em',
                        background: badge.bg, color: badge.text,
                      }}>{badge.label}</span>
                    </td>
                    {/* Market values */}
                    {marketNames.map((mkt, ci) => {
                      const val = grp.markets?.[mkt]?.[field] ?? null;
                      return (
                        <td key={ci} style={{
                          padding:'0 6px', textAlign:'right',
                          fontFamily:'monospace', whiteSpace:'nowrap',
                          width:COL_W, minWidth:COL_W,
                          fontWeight: isSub ? 700 : (isRatio ? 700 : 400),
                          color: isRatio ? rColor(val) : '#374151',
                          fontSize: isRatio ? 10 : 10.5,
                        }}>
                          {isRatio ? rFmt(val) : fmtN(val)}
                        </td>
                      );
                    })}
                    {/* Subtotal column */}
                    {hasSubtotal && (() => {
                      const val = grp.markets?.[subtotalKey]?.[field] ?? null;
                      return (
                        <td style={{
                          padding:'0 6px', textAlign:'right',
                          fontFamily:'monospace', whiteSpace:'nowrap',
                          width:COL_W, minWidth:COL_W,
                          fontWeight: 700,
                          color: isRatio ? rColor(val) : '#0f2147',
                          fontSize: isRatio ? 10 : 10.5,
                          borderLeft:'2px solid #c7d2fe',
                          background: isRatio ? (isSub ? '#dde3f8' : '#eef0fb') : (isSub ? '#dde3f8' : '#eef0fb'),
                        }}>
                          {isRatio ? rFmt(val) : fmtN(val)}
                        </td>
                      );
                    })()}
                  </tr>
                );
              });
            })}
          </tbody>
        </table>
      </div>}

      {/* ════════════  MONTHLY VIEW  ════════════ */}
      {view === 'monthly' && (() => {
        const MONTH_KEYS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        const hasMonthlyData = groups.some(grp =>
          Object.keys(grp.markets ?? {}).some(mkt =>
            MONTH_KEYS.some(mo => grp.markets[mkt]?.[mo] !== undefined)
          )
        );
        if (!hasMonthlyData) {
          return (
            <div style={{ padding:'32px 24px', textAlign:'center', borderTop:'1px solid #e5e7eb', background:'#fafafa' }}>
              <p style={{ fontSize:13, color:'#6b7280', margin:0 }}>Monthly data not available</p>
            </div>
          );
        }
        // If API returns monthly data (month keys inside markets), render it
        return (
          <div style={{ overflowX:'auto', overflowY:'auto', maxHeight:'70vh' }}>
            <table style={{ borderCollapse:'collapse', minWidth:'max-content', fontSize:10.5, tableLayout:'fixed' }}>
              <thead style={{ position:'sticky', top:0, zIndex:20 }}>
                <tr style={{ background:'#1A3673', height:H_ROW }}>
                  <th style={{ padding:'0 10px', textAlign:'left', color:'#fff', fontWeight:700,
                    whiteSpace:'nowrap', position:'sticky', left:0, zIndex:30, background:'#1A3673',
                    width:MBU_W, minWidth:MBU_W, borderRight:'1px solid rgba(255,255,255,0.2)' }}>MBU</th>
                  <th style={{ padding:'0 6px', textAlign:'center', color:'#fff', fontWeight:700,
                    whiteSpace:'nowrap', position:'sticky', left:mbuActualW, zIndex:30, background:'#1A3673',
                    width:PER_W, minWidth:PER_W, borderRight:'2px solid rgba(255,255,255,0.3)' }}>Period</th>
                  {MONTH_KEYS.map((mo, i) => (
                    <th key={i} style={{ padding:'0 6px', textAlign:'right', whiteSpace:'nowrap',
                      width:COL_W, minWidth:COL_W, fontWeight:600, color:'#fff', background:'#1A3673' }}>{mo}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {groups.map((grp, gi) => {
                  const isSub = /subtotal|total/i.test(grp.membership_type ?? '');
                  const grpBg = isSub ? '#EEF2FF' : (gi % 2 === 0 ? '#fff' : '#f8f9fb');
                  const subRows = [
                    { badge: PLAN_BADGE,  field: 'plan',   isRatio: false },
                    { badge: ACT_BADGE,   field: 'actual', isRatio: false },
                    { badge: RATIO_BADGE, field: 'ratio',  isRatio: true  },
                  ];
                  return subRows.map(({ badge, field, isRatio }, ri) => {
                    const isFirst = ri === 0;
                    const isLast  = ri === 2;
                    return (
                      <tr key={`${gi}-${field}`} style={{
                        height: H_ROW,
                        background: isRatio ? (isSub ? '#E8EAF6' : '#f5f5ff') : grpBg,
                        borderTop: isFirst ? '2px solid #e5e7eb' : '1px solid #f0f0f0',
                        borderBottom: isLast ? '1px solid #e5e7eb' : undefined,
                      }}>
                        <td style={{
                          padding: isFirst ? '0 10px' : '0',
                          fontSize:10, fontWeight: isSub ? 700 : 600, color:'#1A3673',
                          whiteSpace:'nowrap', verticalAlign: isFirst ? 'middle' : 'top',
                          position:'sticky', left:0, zIndex:10,
                          background: isRatio ? (isSub ? '#E8EAF6' : '#f5f5ff') : grpBg,
                          width:MBU_W, minWidth:MBU_W, borderRight:'1px solid #e5e7eb',
                          overflow:'hidden', textOverflow:'ellipsis',
                        }}>
                          {isFirst ? (grp.mbu_label ?? grp.membership_type ?? '—') : ''}
                        </td>
                        <td style={{
                          padding:'0 4px', textAlign:'center',
                          position:'sticky', left:mbuActualW, zIndex:10,
                          background: '#fff',
                          width:PER_W, minWidth:PER_W, borderRight:'2px solid #e5e7eb',
                        }}>
                          <span style={{ display:'inline-block', padding:'1px 6px', borderRadius:3,
                            fontSize:9, fontWeight:700, background:badge.bg, color:badge.text }}>
                            {badge.label}
                          </span>
                        </td>
                        {MONTH_KEYS.map((mo, ci) => {
                          const val = grp.markets?.[mo]?.[field] ?? null;
                          return (
                            <td key={ci} style={{
                              padding:'0 6px', textAlign:'right',
                              fontFamily:'monospace', whiteSpace:'nowrap',
                              width:COL_W, minWidth:COL_W,
                              fontWeight: isSub ? 700 : (isRatio ? 700 : 400),
                              color: isRatio ? rColor(val) : '#374151',
                              fontSize: isRatio ? 10 : 10.5,
                            }}>
                              {isRatio ? rFmt(val) : fmtN(val)}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  });
                })}
              </tbody>
            </table>
          </div>
        );
      })()}

      {/* Footer */}
      {sourceFile && (
        <div style={{ padding:'5px 14px', background:'#f9fafb', borderTop:'1px solid #e5e7eb',
          fontSize:10, color:'#6b7280', display:'flex', alignItems:'center', gap:12, flexWrap:'wrap' }}>
          <span>Source: <strong style={{ color:'#374151' }}>{sourceFile}</strong></span>
        </div>
      )}
    </div>
  );
}

const DEFAULT_PARAMS = {
  mbrshp_type:              'Medical',
  mbrshp_scnro:             'Mbrs excl full med cap',
  // multi-year: planDataYears is the array of selected years; yearPeriods holds plan/actual periods per year
  planDataYears:            [String(currentYear)],
  yearPeriods:              { [String(currentYear)]: defaultPeriodForYear(currentYear) },
  stdnt_hlth:               'N',
  mdcd_ltss:                'No Exclusion',
  ga_grs_shbp_mbrshp:       'Y',
  lmtd_cvrg_bh_fmly_plang:  'N',
  coc_elgbl_mrkt_only:      'Y',
};


export default function ScalingTab({ coversheet, onEdit, onRefetchConfig }) {
  const { can } = useAuth();
  const { showToast } = useToast();
  const canEdit = can('edit_cost_plan');

  // Draft = what the user is editing; applied = last successfully retrieved
  const [draft, setDraft] = useState(DEFAULT_PARAMS);
  const [applied, setApplied] = useState(null);
  const [apiData, setApiData] = useState(null);

  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState(null);
  const [retrievedAt, setRetrievedAt] = useState('');
  const [sourceFile, setSourceFile] = useState('');

  // On mount: load saved params+results from DB via GET /parms — run only once per cvrsht_id
  useEffect(() => {
    const cvrsht_id = coversheet?.id || coversheet?.cvrsht_id;
    if (!cvrsht_id) return;
    let cancelled = false;
    setLoading(true);
    membershipScalingApi.getParms(cvrsht_id)
      .then(saved => {
        if (cancelled) return;
        if (!saved || Object.keys(saved).length === 0) return;
        const p = saved.parameters;
        if (p) {
          // Reconstruct planDataYears + yearPeriods from the saved single-year API fields
          const yr = p.plan_year ? String(p.plan_year) : String(currentYear);
          const yearPeriod = {
            planStart:   p.plan_strt_dt ? isoToMonYY(p.plan_strt_dt) : `Jan-${yr.slice(2)}`,
            planEnd:     p.plan_end_dt  ? isoToMonYY(p.plan_end_dt)  : `Dec-${yr.slice(2)}`,
            actualStart: p.actl_strt_dt ? isoToMonYY(p.actl_strt_dt) : `Jan-${String(parseInt(yr)-1).slice(2)}`,
            actualEnd:   p.actl_end_dt  ? isoToMonYY(p.actl_end_dt)  : `Dec-${String(parseInt(yr)-1).slice(2)}`,
          };
          const KNOWN_SCENARIOS = ['Mbrs excl full med cap','Mbrs excl prof cap and full med cap','Mbrs incl full med cap','Prior Year Actual','Budget Scenario','Conservative','Aggressive'];
          setDraft(prev => ({
            ...prev,
            mbrshp_type:             p.mbrshp_type              ?? prev.mbrshp_type,
            mbrshp_scnro:            KNOWN_SCENARIOS.includes(p.mbrshp_scnro) ? p.mbrshp_scnro : (prev.mbrshp_scnro ?? DEFAULT_PARAMS.mbrshp_scnro),
            stdnt_hlth:              p.stdnt_hlth               ?? prev.stdnt_hlth,
            mdcd_ltss:               p.mdcd_ltss || prev.mdcd_ltss,
            ga_grs_shbp_mbrshp:      p.ga_grs_shbp_mbrshp       ?? prev.ga_grs_shbp_mbrshp,
            lmtd_cvrg_bh_fmly_plang: p.lmtd_cvrg_bh_fmly_plang  ?? prev.lmtd_cvrg_bh_fmly_plang,
            coc_elgbl_mrkt_only:     p.coc_elgbl_mrkt_only      ?? prev.coc_elgbl_mrkt_only,
            planDataYears: [yr],
            yearPeriods:   { [yr]: yearPeriod },
          }));
        }
        if (saved.membership_groups?.length) {
          setApiData(saved);
          setApplied(p ? { ...p, planDataYears: p.plan_year ? [String(p.plan_year)] : [String(currentYear)] } : {});
          setLoaded(true);
          setRetrievedAt(saved.metrics?.last_updated ?? new Date().toLocaleString());
          setSourceFile(saved.metrics?.source_file ?? '');
          const mbrshpType = saved.membership_groups[0]?.membership_type;
          if (mbrshpType) setDraft(prev => ({ ...prev, mbrshp_type: mbrshpType }));
        }
      })
      .catch(err => console.warn('[Membership Scaling] getParms failed:', err.message))
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Modal + year-dropdown state
  const [modalOpen, setModalOpen]     = useState(false);
  const [tempDraft, setTempDraft]     = useState(draft);
  const [yearDropOpen, setYearDropOpen] = useState(false);
  const yearDropRef = useRef(null);

  // Close year dropdown on outside click
  useEffect(() => {
    if (!yearDropOpen) return;
    const handler = (e) => { if (yearDropRef.current && !yearDropRef.current.contains(e.target)) setYearDropOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [yearDropOpen]);



  const openModal  = () => { setTempDraft({ ...draft, yearPeriods: { ...draft.yearPeriods } }); setYearDropOpen(false); setModalOpen(true); };
  const closeModal = () => { setModalOpen(false); setYearDropOpen(false); };
  const applyModal = () => {
    if (!tempDraft.planDataYears?.length) return;
    setDraft({ ...tempDraft });
    setModalOpen(false);
    setYearDropOpen(false);
    handleRetrieveWith(tempDraft);
  };

  const setT = (key, value) => setTempDraft(p => ({ ...p, [key]: value }));

  const scenarios = [
    'Mbrs excl full med cap',
    'Mbrs excl prof cap and full med cap',
    'Mbrs incl full med cap',
    'Prior Year Actual',
    'Budget Scenario',
    'Conservative',
    'Aggressive',
  ];

  // Available years for multi-select (2022 → currentYear+1)
  const availableYears = Array.from({ length: currentYear + 1 - 2022 + 1 }, (_, i) => String(2022 + i));

  const handleRetrieveWith = async (params) => {
    setLoading(true);
    setApiError(null);
    // Use the primary (first) selected year for the API call
    const primaryYear = params.planDataYears?.[0] ?? String(currentYear);
    const period = params.yearPeriods?.[primaryYear] ?? defaultPeriodForYear(parseInt(primaryYear));
    const payload = {
      cvrsht_id:                coversheet.id || coversheet.cvrsht_id,
      plan_year:                parseInt(primaryYear),
      mbrshp_scnro:             params.mbrshp_scnro,
      stdnt_hlth:               params.stdnt_hlth,
      mdcd_ltss:                params.mdcd_ltss,
      ga_grs_shbp_mbrshp:       params.ga_grs_shbp_mbrshp,
      lmtd_cvrg_bh_fmly_plang:  params.lmtd_cvrg_bh_fmly_plang,
      coc_elgbl_mrkt_only:      params.coc_elgbl_mrkt_only,
      plan_strt_dt:             toIso(period.planStart),
      plan_end_dt:              toIso(period.planEnd, true),
      actl_strt_dt:             toIso(period.actualStart),
      actl_end_dt:              toIso(period.actualEnd, true),
      mbrshp_type:              params.mbrshp_type,
    };
    try {
      const result = await membershipScalingApi.applyFactor(payload);
      setApiData(result);
      setApplied({ ...params });
      setLoaded(true);
      setRetrievedAt(new Date().toLocaleString());
      setSourceFile(result?.metrics?.source_file ?? '');
      const action = result?.metrics?.action;
      console.debug('[ScalingTab] payload mdcd_ltss:', payload.mdcd_ltss, '| API action:', action);
      const msg = action === 'unchanged'
        ? 'No changes detected — existing results loaded'
        : action === 'updated'
          ? 'Parameters changed — results recalculated and saved'
          : 'Membership scaling calculated and saved';
      showToast(msg, 'success');
      onEdit();
      onRefetchConfig?.();
    } catch (err) {
      setApiError(err.message);
      showToast(`Calculation failed: ${err.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">

      {/* Modal overlay */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(15,25,56,0.45)', backdropFilter: 'blur(2px)' }}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 flex flex-col" style={{ border: '1px solid #e5e7eb', maxHeight: '90vh' }}>
            {/* Modal header */}
            <div className="flex items-center justify-between px-5 py-4" style={{ background: '#1A3673' }}>
              <div className="flex items-center gap-2 text-white">
                <Settings size={15} />
                <span className="font-semibold text-sm">Edit Scaling Parameters</span>
              </div>
              <button onClick={closeModal} className="text-white/60 hover:text-white transition">
                <X size={16} />
              </button>
            </div>

            {/* Modal body */}
            <div className="px-5 py-5 space-y-5 overflow-y-auto flex-1">

              {/* Type + Plan Year (multi-select) */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="form-label">Membership Type</label>
                  <div className="flex gap-1 mt-1">
                    {['Medical','Rx'].map(t => (
                      <button key={t} onClick={() => setT('mbrshp_type', t)}
                        className={`px-3 py-1 text-xs font-semibold rounded border transition ${tempDraft.mbrshp_type===t ? 'bg-[#1A3673] text-white border-[#1A3673]' : 'border-gray-200 text-gray-500 hover:border-[#1A3673]'}`}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Multi-year checkbox dropdown */}
                <div className="relative" ref={yearDropRef}>
                  <label className="form-label">Plan Year <span className="text-[10px] text-gray-400 font-normal">(multi-select)</span> <span className="text-[#2861BB]">*</span></label>
                  <button type="button" onClick={() => setYearDropOpen(o => !o)}
                    className="form-select text-xs mt-1 w-full flex items-center justify-between"
                    style={{ cursor:'pointer', textAlign:'left' }}>
                    <span style={{ color: (tempDraft.planDataYears?.length ?? 0) === 0 ? '#9ca3af' : '#374151' }}>
                      {(tempDraft.planDataYears?.length ?? 0) === 0 ? 'Select year(s)…' : tempDraft.planDataYears.join(', ')}
                    </span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                      style={{ transform: yearDropOpen ? 'rotate(180deg)' : 'none', transition:'transform .15s', flexShrink:0 }}>
                      <path d="m6 9 6 6 6-6"/>
                    </svg>
                  </button>
                  {yearDropOpen && (
                    <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden" style={{ top:'100%' }}>
                      {availableYears.map(y => {
                        const sel = tempDraft.planDataYears?.includes(y) ?? false;
                        return (
                          <label key={y} className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-[#E1EDFF] transition"
                            onClick={() => {
                              const newYears = sel
                                ? (tempDraft.planDataYears ?? []).filter(x => x !== y)
                                : [...(tempDraft.planDataYears ?? []), y].sort();
                              const newPeriods = { ...(tempDraft.yearPeriods ?? {}) };
                              if (!sel && !newPeriods[y]) newPeriods[y] = defaultPeriodForYear(parseInt(y));
                              if (sel) delete newPeriods[y];
                              setTempDraft(p => ({ ...p, planDataYears: newYears, yearPeriods: newPeriods }));
                            }}>
                            <span style={{ width:14, height:14, borderRadius:3, flexShrink:0, display:'inline-flex',
                              alignItems:'center', justifyContent:'center',
                              border: sel ? 'none' : '1.5px solid #d1d5db', background: sel ? '#1A3673' : '#fff' }}>
                              {sel && <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3"><path d="M20 6 9 17l-5-5"/></svg>}
                            </span>
                            <span className="text-xs font-medium text-gray-700">{y}</span>
                            {sel && <span className="ml-auto text-[9px] font-bold text-[#1A3673] bg-[#E1EDFF] px-1.5 py-0.5 rounded">Selected</span>}
                          </label>
                        );
                      })}
                      <div className="border-t border-gray-100 px-3 py-1.5 flex justify-between items-center bg-gray-50">
                        <span className="text-[10px] text-gray-400">{tempDraft.planDataYears?.length ?? 0} selected</span>
                        <button onClick={() => setYearDropOpen(false)} className="text-[10px] font-semibold text-[#1A3673] hover:underline">Done</button>
                      </div>
                    </div>
                  )}
                  {(tempDraft.planDataYears?.length ?? 0) > 1 && !yearDropOpen && (
                    <p className="text-[10px] text-[#2861BB] mt-1">Comparing {tempDraft.planDataYears.join(' vs ')} side-by-side</p>
                  )}
                  {(tempDraft.planDataYears?.length ?? 0) === 0 && !yearDropOpen && (
                    <p className="text-[10px] text-[#E3725F] mt-1">Select at least one year</p>
                  )}
                </div>
              </div>

              <div>
                <label className="form-label">Membership Scenario <span className="text-[#2861BB]">*</span></label>
                <select className="form-select text-xs mt-1 w-full" value={tempDraft.mbrshp_scnro}
                  onChange={e => setT('mbrshp_scnro', e.target.value)}>
                  {scenarios.map(s => <option key={s}>{s}</option>)}
                </select>
              </div>

              {/* Per-year Plan & Actual Periods */}
              <div>
                <label className="form-label mb-2">Plan &amp; Actual Periods</label>
                <div className="space-y-2 mt-1">
                  {(tempDraft.planDataYears ?? []).map(yr => {
                    const yp = tempDraft.yearPeriods?.[yr] ?? defaultPeriodForYear(parseInt(yr));
                    const setYP = (field, val) =>
                      setTempDraft(p => ({ ...p, yearPeriods: { ...p.yearPeriods, [yr]: { ...(p.yearPeriods?.[yr] ?? yp), [field]: val } } }));
                    return (
                      <div key={yr} className="p-3 rounded-lg border border-gray-100 bg-gray-50">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-[10px] font-bold text-white bg-[#1A3673] px-2 py-0.5 rounded">FY {yr}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Plan Period</span>
                            <div className="flex items-center gap-1 mt-1">
                              <select className="form-select text-xs flex-1" value={yp.planStart} onChange={e => setYP('planStart', e.target.value)}>
                                {ALL_MONTH_OPTIONS.map(m => <option key={m}>{m}</option>)}
                              </select>
                              <span className="text-gray-400 text-[10px]">→</span>
                              <select className="form-select text-xs flex-1" value={yp.planEnd} onChange={e => setYP('planEnd', e.target.value)}>
                                {ALL_MONTH_OPTIONS.map(m => <option key={m}>{m}</option>)}
                              </select>
                            </div>
                          </div>
                          <div>
                            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Actual Period</span>
                            <div className="flex items-center gap-1 mt-1">
                              <select className="form-select text-xs flex-1" value={yp.actualStart} onChange={e => setYP('actualStart', e.target.value)}>
                                {ALL_MONTH_OPTIONS.map(m => <option key={m}>{m}</option>)}
                              </select>
                              <span className="text-gray-400 text-[10px]">→</span>
                              <select className="form-select text-xs flex-1" value={yp.actualEnd} onChange={e => setYP('actualEnd', e.target.value)}>
                                {ALL_MONTH_OPTIONS.map(m => <option key={m}>{m}</option>)}
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  {(tempDraft.planDataYears?.length ?? 0) === 0 && (
                    <p className="text-[11px] text-gray-400 italic">Select at least one year above to configure periods.</p>
                  )}
                </div>
              </div>

              {/* Inclusion flags */}
              <div>
                <label className="form-label mb-2">Membership Inclusions</label>
                <div className="grid grid-cols-2 gap-y-2 gap-x-4 mt-1 p-3 bg-gray-50 rounded-lg border border-gray-100">
                  {[
                    { short: 'Student Health',           key: 'stdnt_hlth'              },
                    { short: 'GA/GRS SHBP Membership',   key: 'ga_grs_shbp_mbrshp'     },
                    { short: 'Ltd Coverage BH/Fam Plan',  key: 'lmtd_cvrg_bh_fmly_plang' },
                    { short: 'CoC Markets Only',          key: 'coc_elgbl_mrkt_only'    },
                  ].map(({ short, key }) => (
                    <div key={short} className="flex items-center justify-between gap-2">
                      <span className="text-[11px] text-gray-600">{short}</span>
                      <div className="flex gap-1">
                        {['Y','N'].map(opt => (
                          <button key={opt} onClick={() => setT(key, opt)}
                            className={`w-7 h-6 text-[10px] font-bold rounded border transition ${
                              tempDraft[key] === opt
                                ? opt==='Y' ? 'bg-[#00BBBA] text-white border-[#00BBBA]' : 'bg-[#E3725F] text-white border-[#E3725F]'
                                : 'bg-white text-gray-300 border-gray-200 hover:border-gray-400'
                            }`}>{opt}</button>
                        ))}
                      </div>
                    </div>
                  ))}
                  {/* mdcd_ltss — dropdown */}
                  <div className="flex items-center justify-between gap-2 col-span-2">
                    <span className="text-[11px] text-gray-600">MN Medicaid Abd Non-Dual (LTSS)</span>
                    <select className="form-select text-xs" value={tempDraft.mdcd_ltss}
                      onChange={e => setT('mdcd_ltss', e.target.value)}>
                      {['No Exclusion', 'Full Exclusion', 'Partial Exclusion'].map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal footer */}
            <div className="flex items-center justify-end gap-2 px-5 py-4 bg-gray-50 border-t border-gray-100">
              <button onClick={closeModal} className="px-4 py-1.5 text-xs font-medium text-gray-500 border border-gray-200 rounded-lg hover:border-gray-400 transition">
                Cancel
              </button>
              <button onClick={applyModal} disabled={(tempDraft.planDataYears?.length ?? 0) === 0}
                className="btn-primary text-xs flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed">
                <CheckCircle size={11} /> Apply Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Parameters card — compact read-only summary */}
      <div className="card">
        <div className="card-header">
          <div className="card-title"><Database size={15} />Scaling Parameters</div>
          <div className="flex items-center gap-2">
            {loaded && !loading && (
              <div className="flex items-center gap-1.5 text-xs text-[#00BBBA]">
                <CheckCircle size={12} /> Retrieved {retrievedAt}
              </div>
            )}
            {canEdit && (
              <button onClick={openModal} className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-[#1A3673] border border-[#1A3673]/30 rounded-lg hover:bg-[#E1EDFF] transition">
                <Settings size={12} /> Edit Parameters
              </button>
            )}
          </div>
        </div>

        {/* Read-only param summary chips */}
        <div className="px-4 py-3 flex flex-wrap items-center gap-x-5 gap-y-2 border-b border-gray-100">
          {loading ? (
            /* Skeleton placeholders while API is loading */
            <div className="flex items-center gap-3 flex-wrap">
              {[80, 56, 140, 100, 100].map((w, i) => (
                <div key={i} className="h-5 rounded animate-pulse bg-gray-200" style={{ width: w }} />
              ))}
            </div>
          ) : (
            <>
              {[
                { label: 'Type',     value: draft.mbrshp_type },
                { label: 'Scenario', value: draft.mbrshp_scnro },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{label}</span>
                  <span className="text-[11px] font-semibold text-[#1A3673] bg-[#E1EDFF] rounded px-2 py-0.5">{value}</span>
                </div>
              ))}
              {/* FY year badges with per-year period ranges */}
              {(draft.planDataYears ?? []).map(yr => {
                const yp = draft.yearPeriods?.[yr] ?? defaultPeriodForYear(parseInt(yr));
                return (
                  <div key={yr} className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold text-white bg-[#1A3673] px-1.5 py-0.5 rounded">FY {yr}</span>
                    <span className="text-[10px] text-gray-500">Plan: <strong className="text-[#1A3673]">{yp.planStart}→{yp.planEnd}</strong></span>
                    <span className="text-[10px] text-gray-500">Actual: <strong className="text-[#2861BB]">{yp.actualStart}→{yp.actualEnd}</strong></span>
                  </div>
                );
              })}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Include</span>
                {[
                  { short: 'Student Health', key: 'stdnt_hlth'              },
                  { short: 'GA/GRS SHBP',    key: 'ga_grs_shbp_mbrshp'     },
                  { short: 'Ltd Coverage',   key: 'lmtd_cvrg_bh_fmly_plang' },
                  { short: 'CoC Only',       key: 'coc_elgbl_mrkt_only'    },
                ].map(({ short, key }) => (
                  <span key={key} className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                    draft[key]==='Y' ? 'bg-[#D9F5F5] text-[#00BBBA] border-[#B2EBEA]' : 'bg-gray-100 text-gray-400 border-gray-200 line-through'
                  }`}>{short}</span>
                ))}
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                  draft.mdcd_ltss === 'No Exclusion' ? 'bg-[#D9F5F5] text-[#00BBBA] border-[#B2EBEA]' : 'bg-gray-100 text-gray-400 border-gray-200'
                }`}>LTSS: {draft.mdcd_ltss}</span>
              </div>
            </>
          )}
        </div>

        {/* Source file row — only when loaded and not loading */}
        {loaded && !loading && sourceFile && (
          <div className="px-4 py-2.5 flex items-center gap-3 border-t border-gray-100 bg-gray-50">
            <div className="flex items-center gap-1.5 text-[10px] text-[#00BBBA]">
              <CheckCircle size={11} />
              <span className="font-medium">{sourceFile}</span>
              <span className="text-gray-400">· {retrievedAt}</span>
            </div>
          </div>
        )}
      </div>

      {/* Full-area loader — shown while any API call is in flight */}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-3">
          <Loader2 size={32} className="animate-spin text-[#1A3673]" />
          <span className="text-sm text-gray-400 font-medium">Loading membership data…</span>
        </div>
      )}

      {/* API error */}
      {!loading && apiError && (
        <div className="flex items-center gap-2 px-4 py-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
          <AlertCircle size={14} /> {apiError}
        </div>
      )}

      {/* Membership Summary tables — only shown when loaded AND not loading */}
      {!loading && loaded && apiData && <MembershipAdjustmentSummary summaryRatios={apiData.summary_scaling_ratios} marketHeaders={apiData.market_headers} membershipGroups={apiData.membership_groups} />}
      {!loading && loaded && apiData && <MembershipTable apiData={apiData} applied={applied} sourceFile={sourceFile} retrievedAt={retrievedAt} />}
    </div>
  );
}
