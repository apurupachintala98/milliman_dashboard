import { useState } from 'react';
import { Download, Clock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { MOCK_AUDIT_ENTRIES } from '../../data/mockData';
import { ColFilter } from '../ColFilter';

export default function AuditTrailTab({ coversheetId }) {
  const { can } = useAuth();
  const { showToast } = useToast();
  const canExport = can('export_audit');

  const [filterSection, setFilterSection] = useState('');

  const entries = MOCK_AUDIT_ENTRIES.filter(e => e.coversheetId === coversheetId);

  const filteredEntries = entries.filter(e => {
    if (filterSection && e.section !== filterSection) return false;
    return true;
  });

  const sections = [...new Set(entries.map(e => e.section))];

  const handleExport = () => {
    const header = ['Timestamp', 'User', 'Role', 'Action', 'Section', 'Details', 'Field', 'Previous Value', 'New Value'];
    const rows = filteredEntries.map(e => [
      e.timestamp, e.userName, e.userRole, e.action, e.section, e.details,
      e.fieldName ?? '', e.previousValue ?? '', e.newValue ?? '',
    ]);
    const csv = [header, ...rows].map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `audit_trail_${coversheetId}.csv`; a.click();
    URL.revokeObjectURL(url);
    showToast('Audit log exported as CSV', 'success');
  };

  const actionIcon = {
    'Coversheet Created': '🆕',
    'Status Changed': '🔄',
    'Approved': '✅',
    'Pushed to SNOW': '📤',
    'Role Switch': '👤',
    'Data Uploaded': '📁',
    'Financial Model Uploaded': '📊',
    'Scaling Retrieved': '⚡',
    'Field Updated': '✏️',
  };

  const roleColor = {
    'Demand Manager': 'bg-[#E3F4FD] text-[#1A3673]',
    'Financial Analyst': 'bg-[#E1EDFF] text-[#2861BB]',
    'Governance': 'bg-[#D9F5F5] text-[#00BBBA]',
    'Admin': 'bg-purple-50 text-purple-700',
    'Read-Only': 'bg-gray-100 text-gray-600',
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="card p-4 flex items-center justify-end flex-wrap gap-3">
        {canExport ? (
          <button className="btn-outline text-xs flex items-center gap-1.5 py-1.5" onClick={handleExport}>
            <Download size={12} /> Export CSV
          </button>
        ) : (
          <span className="text-xs text-gray-400">Export not available for this role</span>
        )}
      </div>

      {/* Log entries */}
      <div className="card overflow-hidden">
        <div className="card-header">
          <div className="card-title"><Clock size={14} />Audit Trail ({filteredEntries.length} entries)</div>
          <span className="text-xs text-gray-400">Chronological — most recent first</span>
        </div>

        {filteredEntries.length === 0 && (
          <div className="p-8 text-center text-gray-400 text-sm">No audit entries found.</div>
        )}

        <div className="divide-y divide-gray-50">
          {[...filteredEntries].reverse().map(entry => (
            <div key={entry.id} className="px-4 py-3 hover:bg-gray-50 transition">
              <div className="flex items-start gap-3">
                <span className="text-lg flex-shrink-0 mt-0.5">
                  {actionIcon[entry.action] ?? '📝'}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-sm font-semibold text-[#1A3673]">{entry.action}</span>
                    <span className={`badge text-[10px] ${roleColor[entry.userRole] ?? 'bg-gray-100 text-gray-600'}`}>
                      {entry.userRole}
                    </span>
                    <span className="badge-draft badge text-[10px]">{entry.section}</span>
                  </div>
                  <p className="text-xs text-gray-700 mb-1">{entry.details}</p>
                  {entry.fieldName && (
                    <div className="flex items-center gap-2 text-xs bg-[#F5F5F5] rounded px-2 py-1 inline-flex mt-1">
                      <span className="font-medium text-gray-600">{entry.fieldName}:</span>
                      <span className="text-[#E3725F] line-through">{entry.previousValue}</span>
                      <span className="text-gray-400">→</span>
                      <span className="text-[#00BBBA] font-medium">{entry.newValue}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-xs text-gray-400">{entry.timestamp}</span>
                    <span className="text-gray-200">•</span>
                    <span className="text-xs text-gray-500 font-medium">{entry.userName}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Field-level changes table */}
      {filteredEntries.some(e => e.fieldName) && (
        <div className="card">
          <div className="card-header">
            <div className="card-title">Field-Level Changes</div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#1A3673]">
                  <th className="px-3 py-2 text-left whitespace-nowrap"><ColFilter label="Timestamp" value="" onChange={() => {}} type="text" /></th>
                  <th className="px-3 py-2 text-left whitespace-nowrap"><ColFilter label="User" value="" onChange={() => {}} type="text" /></th>
                  <th className="px-3 py-2 text-left whitespace-nowrap"><ColFilter label="Section" value={filterSection} onChange={setFilterSection} options={sections} /></th>
                  <th className="px-3 py-2 text-left whitespace-nowrap"><ColFilter label="Field" value="" onChange={() => {}} type="text" /></th>
                  <th className="px-3 py-2 text-left text-white font-semibold text-xs">Previous Value</th>
                  <th className="px-3 py-2 text-left text-white font-semibold text-xs">New Value</th>
                </tr>
              </thead>
              <tbody>
                {filteredEntries.filter(e => e.fieldName).map((e, i) => (
                  <tr key={e.id} className={i % 2 === 0 ? 'table-row-even' : 'table-row-odd'}>
                    <td className="table-td text-xs text-gray-500">{e.timestamp}</td>
                    <td className="table-td text-xs font-medium">{e.userName}</td>
                    <td className="table-td"><span className="badge-draft badge text-[10px]">{e.section}</span></td>
                    <td className="table-td font-medium text-xs text-[#1A3673]">{e.fieldName}</td>
                    <td className="table-td text-xs text-[#E3725F]">{e.previousValue}</td>
                    <td className="table-td text-xs text-[#00BBBA] font-medium">{e.newValue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
