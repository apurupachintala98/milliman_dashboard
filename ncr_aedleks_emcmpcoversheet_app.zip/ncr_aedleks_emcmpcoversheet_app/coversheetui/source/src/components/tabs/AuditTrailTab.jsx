import { useMemo, useState } from 'react';
import { Download, Clock, Search, X, ArrowRight, CalendarDays } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { MOCK_AUDIT_ENTRIES } from '../../mockData';
import { ColFilter } from '../ColFilter';
import { CHANGE_TYPES, CHANGE_DOT, sourceColor, isEmptyValue as isEmpty } from '../../auditConfig';

const formatTimestamp = (ts) => {
  const d = new Date(ts.replace(' ', 'T'));
  return {
    date: d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }),
    time: d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };
};

function FilterPill({ children }) {
  return <div className="flex items-center px-3 py-1 border border-gray-300 rounded-full bg-white">{children}</div>;
}

export default function AuditTrailTab({ coversheetId }) {
  const { can } = useAuth();
  const { showToast } = useToast();
  const canExport = can('export_audit');

  const [search, setSearch] = useState('');
  const [users, setUsers] = useState([]);
  const [sources, setSources] = useState([]);
  const [types, setTypes] = useState([]);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  // Mock data uses placeholder ids (cs1, cs2, …) that never match a real coversheet id,
  // so fall back to all mock entries until the audit API is integrated.
  const entries = useMemo(() => {
    const own = MOCK_AUDIT_ENTRIES.filter(e => e.coversheetId === coversheetId);
    const list = own.length ? own : MOCK_AUDIT_ENTRIES;
    return [...list].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }, [coversheetId]);

  const userOptions = [...new Set(entries.map(e => e.userName))].sort();
  const sourceOptions = [...new Set(entries.map(e => e.section))];
  const typeOptions = CHANGE_TYPES.filter(t => entries.some(e => e.changeType === t));

  const q = search.trim().toLowerCase();
  const filtered = entries.filter(e => {
    const day = e.timestamp.slice(0, 10);
    if (users.length && !users.includes(e.userName)) return false;
    if (sources.length && !sources.includes(e.section)) return false;
    if (types.length && !types.includes(e.changeType)) return false;
    if (dateFrom && day < dateFrom) return false;
    if (dateTo && day > dateTo) return false;
    if (q && ![e.userName, e.section, e.fieldName, e.previousValue, e.newValue, e.details, e.action]
      .some(v => v?.toLowerCase().includes(q))) return false;
    return true;
  });

  const hasFilters = !!(q || users.length || sources.length || types.length || dateFrom || dateTo);
  const clearAll = () => { setSearch(''); setUsers([]); setSources([]); setTypes([]); setDateFrom(''); setDateTo(''); };
  const toggleSource = (s) => setSources(v => v.includes(s) ? v.filter(x => x !== s) : [...v, s]);

  const handleExport = () => {
    const header = ['Timestamp', 'User', 'Role', 'Source', 'Change Type', 'Field', 'Old Value', 'New Value', 'Details'];
    const rows = filtered.map(e => [
      e.timestamp, e.userName, e.userRole, e.section, e.changeType,
      e.fieldName ?? '', e.previousValue ?? '', e.newValue ?? '', e.details,
    ]);
    const csv = [header, ...rows].map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = `audit_trail_${coversheetId}.csv`; a.click();
    URL.revokeObjectURL(url);
    showToast('Audit log exported as CSV', 'success');
  };

  const dateInputCls = 'text-[11px] text-gray-700 bg-transparent border-none outline-none w-[110px]';

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="card px-4 py-3 space-y-2.5">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative w-64">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search field, value, user..."
              className="w-full pl-7 pr-6 py-1 text-[11px] border border-gray-300 rounded-full bg-white text-gray-700 placeholder-gray-400 focus:outline-none focus:border-[#1A3673] focus:ring-1 focus:ring-[#1A3673]/20"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X size={12} />
              </button>
            )}
          </div>

          <FilterPill><ColFilter label="User" dark={false} values={users} onChangeMulti={setUsers} options={userOptions} /></FilterPill>
          <FilterPill><ColFilter label="Source Tab" dark={false} values={sources} onChangeMulti={setSources} options={sourceOptions} /></FilterPill>
          <FilterPill><ColFilter label="Change Type" dark={false} values={types} onChangeMulti={setTypes} options={typeOptions} /></FilterPill>

          <FilterPill>
            <CalendarDays size={12} className="text-gray-400 mr-1.5" />
            <input type="date" value={dateFrom} max={dateTo || undefined} onChange={e => setDateFrom(e.target.value)} className={dateInputCls} aria-label="From date" />
            <span className="text-gray-300 mx-1">–</span>
            <input type="date" value={dateTo} min={dateFrom || undefined} onChange={e => setDateTo(e.target.value)} className={dateInputCls} aria-label="To date" />
          </FilterPill>

          {hasFilters && (
            <button onClick={clearAll} className="text-[11px] text-[#E3725F] hover:underline flex items-center gap-0.5">
              <X size={10} /> Clear filters
            </button>
          )}

          <div className="ml-auto">
            {canExport ? (
              <button className="btn-outline text-xs py-1" onClick={handleExport} disabled={filtered.length === 0}>
                <Download size={12} /> Export CSV
              </button>
            ) : (
              <span className="text-[11px] text-gray-400">Export not available for this role</span>
            )}
          </div>
        </div>

        {/* Source quick filters */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mr-1">Changes by source</span>
          {sourceOptions.map(s => {
            const active = sources.includes(s);
            const count = entries.filter(e => e.section === s).length;
            return (
              <button
                key={s}
                onClick={() => toggleSource(s)}
                className={`badge text-[10px] gap-1 transition ring-1 ${sourceColor(s)} ${active ? 'ring-[#1A3673]' : 'ring-transparent opacity-80 hover:opacity-100'}`}
              >
                {s} <span className="font-bold">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Audit table */}
      <div className="card overflow-hidden">
        <div className="card-header">
          <div className="card-title">
            <Clock size={14} />Audit Trail
            <span className="text-[11px] font-normal normal-case tracking-normal text-gray-400">
              {hasFilters ? `${filtered.length} of ${entries.length}` : entries.length} changes
            </span>
          </div>
          <span className="text-[11px] text-gray-400">Latest first</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="table-th w-[120px]">Timestamp</th>
                <th className="table-th w-[150px]">User</th>
                <th className="table-th w-[140px]">Source</th>
                <th className="table-th w-[110px]">Change Type</th>
                <th className="table-th">Field</th>
                <th className="table-th">Old Value</th>
                <th className="table-th w-6 px-0" aria-label="changed to" />
                <th className="table-th">New Value</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="table-td text-center text-gray-400 py-10">
                    {entries.length === 0 ? 'No changes have been recorded yet.' : 'No changes match the current filters.'}
                    {hasFilters && <button onClick={clearAll} className="ml-2 text-[#2861BB] hover:underline">Clear filters</button>}
                  </td>
                </tr>
              )}
              {filtered.map((e, i) => {
                const { date, time } = formatTimestamp(e.timestamp);
                return (
                  <tr key={e.id} className={`${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'} hover:bg-[#E3F4FD]/50 transition align-top`}>
                    <td className="table-td whitespace-nowrap" title={e.timestamp}>
                      <div className="font-medium text-gray-800">{date}</div>
                      <div className="text-[10px] text-gray-400">{time}</div>
                    </td>
                    <td className="table-td whitespace-nowrap">
                      <div className="font-medium text-gray-800">{e.userName}</div>
                      <div className="text-[10px] text-gray-400">{e.userRole}</div>
                    </td>
                    <td className="table-td">
                      <span className={`badge text-[10px] ${sourceColor(e.section)}`}>{e.section}</span>
                    </td>
                    <td className="table-td whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 text-[11px] text-gray-600">
                        <span className={`w-1.5 h-1.5 rounded-full ${CHANGE_DOT[e.changeType]}`} />{e.changeType}
                      </span>
                    </td>
                    <td className="table-td">
                      <div className="font-semibold text-[#1A3673]">{e.fieldName ?? e.action}</div>
                      {e.details && <div className="text-[10px] text-gray-400 truncate max-w-[260px]" title={e.details}>{e.details}</div>}
                    </td>
                    <td className="table-td">
                      {isEmpty(e.previousValue)
                        ? <span className="text-gray-300">—</span>
                        : <span className="inline-block rounded px-1.5 py-0.5 bg-[#FDEEEB] text-[#C4513D] line-through decoration-[#E3725F]/60">{e.previousValue}</span>}
                    </td>
                    <td className="table-td px-0 text-center">
                      <ArrowRight size={12} className="inline text-gray-300 mt-0.5" />
                    </td>
                    <td className="table-td">
                      {isEmpty(e.newValue)
                        ? <span className="text-gray-300">—</span>
                        : <span className="inline-block rounded px-1.5 py-0.5 bg-[#D9F5F5] text-[#007F7E] font-semibold">{e.newValue}</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}