import { useState, useEffect, useRef } from 'react';
import { Filter, X, Search, Loader2, AlertCircle, RefreshCw, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import { useToast } from '../../context/ToastContext';
import { financialSummaryApi } from '../../config/apiConfig';

// ── Formatters ────────────────────────────────────────────────────────────────
const fmtNum = (v) => {
  if (v === null || v === undefined) return '—';
  const n = parseFloat(v);
  if (isNaN(n)) return '—';
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};
const fmtShort = (v) => {
  const n = parseFloat(v);
  if (isNaN(n)) return '—';
  if (Math.abs(n) >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (Math.abs(n) >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
};

const TYPE_STYLES = {
  Unscaled: { text: '#2861BB', badgeBg: '#E1EDFF', badgeText: '#2861BB' },
  Scaled:   { text: '#00897B', badgeBg: '#D9F5F5', badgeText: '#00897B' },
};

// ── Month label: "2026-01" → "01/26" ─────────────────────────────────────────
const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fmtMonth = (col) => {
  // col = "2026-01" → "Jan-26"
  const month = parseInt(col.slice(5), 10);
  const year  = col.slice(2, 4);
  return `${MONTH_NAMES[month - 1] ?? col.slice(5)}-${year}`;
};

// ── Section table ─────────────────────────────────────────────────────────────
function SectionTable({ section, activeMonths, period }) {
  const [collapsed,       setCollapsed]       = useState(false);
  const [isFilterOpen,    setIsFilterOpen]     = useState(false);
  const [pendingFilters,  setPendingFilters]   = useState({ market: '', type: '' });
  const [filters,         setFilters]          = useState({ market: '', type: '' });
  const [globalSearch,    setGlobalSearch]     = useState('');

  const rows    = section.rows ?? [];
  const markets = [...new Set(rows.map(r => r.market))].sort();

  // Column list based on period mode
  const visibleCols = (() => {
    if (period.mode === 'Yearly') return [];
    if (period.mode === 'Monthly') {
      if (period.month === 'All') return activeMonths;
      return activeMonths.filter(m => m === period.month);
    }
    if (period.mode === 'Quarterly') {
      if (period.quarter === 'All') return activeMonths;
      const qMap = { Q1:[0,1,2], Q2:[3,4,5], Q3:[6,7,8], Q4:[9,10,11] };
      const idx = qMap[period.quarter] ?? [];
      return activeMonths.filter((_, i) => idx.includes(i));
    }
    return activeMonths;
  })();

  const matchesFilters = (r) => {
    if (filters.market && r.market !== filters.market) return false;
    if (filters.type   && r.type   !== filters.type)   return false;
    if (globalSearch) {
      const q = globalSearch.toLowerCase();
      return [r.market, r.lob, r.type, String(r.total)].some(v => v?.toLowerCase().includes(q));
    }
    return true;
  };

  const filtered = rows.filter(matchesFilters);
  const marketGroups = markets
    .map(mkt => ({
      market:   mkt,
      unscaled: filtered.find(r => r.market === mkt && r.type === 'Unscaled') ?? null,
      scaled:   filtered.find(r => r.market === mkt && r.type === 'Scaled')   ?? null,
    }))
    .filter(g => g.unscaled || g.scaled);

  const applyFilters  = () => { setFilters({ ...pendingFilters }); setIsFilterOpen(false); };
  const clearFilters  = () => { const c = { market:'', type:'' }; setFilters(c); setPendingFilters(c); setGlobalSearch(''); setIsFilterOpen(false); };
  const cancelFilters = () => { setPendingFilters({ ...filters }); setIsFilterOpen(false); };
  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  const periodLabel = period.mode === 'Yearly' ? 'Yearly'
    : period.mode === 'Quarterly' ? (period.quarter === 'All' ? 'All Quarters' : period.quarter)
    : (period.month === 'All' ? 'All Months' : fmtMonth(period.month));

  return (
    <div className="card overflow-hidden">

      {/* ── Section header row ── */}
      <div
        className="flex items-center justify-between px-4 py-3 cursor-pointer select-none hover:bg-gray-50 transition border-b border-gray-100"
        onClick={() => setCollapsed(c => !c)}
      >
        {/* Left: arrow + title + badges */}
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-gray-400 text-[11px] flex-shrink-0">{collapsed ? '▸' : '▾'}</span>
          <span className="text-sm font-bold text-[#1A3673] uppercase tracking-wide truncate">
            {section.display_name ?? section.lob}
          </span>
          <span className="flex-shrink-0 text-[10px] font-bold px-2 py-0.5 rounded border border-[#1A3673]/30 bg-[#E1EDFF] text-[#1A3673]">
            PIVOT
          </span>
          <span className="flex-shrink-0 text-[10px] text-gray-400">{periodLabel}</span>
          <span className="flex-shrink-0 text-[10px] text-gray-400">{section.market_count} market{section.market_count !== 1 ? 's' : ''}</span>
        </div>
        {/* Right: totals */}
        <div className="flex items-center gap-4 flex-shrink-0 ml-4" onClick={e => e.stopPropagation()}>
          <span className="text-[11px]">
            <span className="font-bold text-[#2861BB]">{fmtShort(section.unscaled_total)}</span>
            <span className="text-gray-400 ml-1">unscaled</span>
          </span>
          <span className="text-[11px]">
            <span className="font-bold text-[#00897B]">{fmtShort(section.scaled_total)}</span>
            <span className="text-gray-400 ml-1">scaled</span>
          </span>
        </div>
      </div>

      {/* ── Filter Modal (full-screen overlay, matches dashboard) ── */}
      {isFilterOpen && (
        <div
          style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={cancelFilters}
        >
          <div
            style={{ background:'#fff', borderRadius:12, maxWidth:560, width:'100%', maxHeight:'90vh', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div style={{ padding:'16px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <Filter size={18} color="#fff" />
                <h3 style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Filter — {section.display_name ?? section.lob}</h3>
              </div>
              <button onClick={cancelFilters} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}>
                <X size={18} />
              </button>
            </div>
            {/* Body */}
            <div style={{ padding:24 }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Market</label>
                  <select
                    value={pendingFilters.market}
                    onChange={e => setPendingFilters(p => ({ ...p, market: e.target.value }))}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}
                  >
                    <option value="">All</option>
                    {markets.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Type</label>
                  <select
                    value={pendingFilters.type}
                    onChange={e => setPendingFilters(p => ({ ...p, type: e.target.value }))}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}
                  >
                    <option value="">All</option>
                    <option value="Unscaled">Unscaled</option>
                    <option value="Scaled">Scaled</option>
                  </select>
                </div>
              </div>
            </div>
            {/* Footer */}
            <div style={{ padding:'16px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
              <button
                onClick={clearFilters}
                style={{ padding:'8px 16px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}
              >
                Clear All
              </button>
              <div style={{ display:'flex', gap:10 }}>
                <button
                  onClick={cancelFilters}
                  style={{ padding:'8px 20px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}
                >
                  Cancel
                </button>
                <button
                  onClick={applyFilters}
                  style={{ padding:'8px 24px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Search + filter toolbar (below section header) ── */}
      {!collapsed && (
        <div style={{ padding:'10px 14px', borderBottom:'1px solid #e5e7eb', background:'#fafafa', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8 }}>
          {/* Left: search + filter button */}
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            {/* Pill search */}
            <div style={{ position:'relative', flex:'0 1 280px' }}>
              <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
              <input
                type="text"
                value={globalSearch}
                onChange={e => setGlobalSearch(e.target.value)}
                placeholder="Search markets…"
                style={{ width:'100%', paddingLeft:32, paddingRight: globalSearch ? 28 : 10, paddingTop:6, paddingBottom:6, fontSize:13, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
                onFocus={e => e.target.style.borderColor = '#1A3673'}
                onBlur={e => e.target.style.borderColor = '#d1d5db'}
              />
              {globalSearch && (
                <button
                  onClick={() => setGlobalSearch('')}
                  style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}
                >
                  <X size={13} />
                </button>
              )}
            </div>
            {/* Filter button — solid dark pill matching dashboard */}
            <button
              onClick={() => setIsFilterOpen(true)}
              onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
              onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
              title="Filter rows"
              style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'6px 14px', cursor:'pointer', transition:'transform 0.1s ease', position:'relative' }}
            >
              <Filter size={13} />
              {activeFilterCount > 0 && (
                <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 7px', minWidth:20, textAlign:'center' }}>
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>
          {/* Right: Clear All — only visible when filters active */}
          {(activeFilterCount > 0 || globalSearch) && (
            <button
              onClick={clearFilters}
              style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'5px 14px', cursor:'pointer' }}
            >
              <X size={12} /> Clear All
            </button>
          )}
        </div>
      )}

      {/* ── Table ── */}
      {!collapsed && (
        <div style={{ overflowX: 'auto' }}>
          <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
            <thead>
              <tr style={{ background: '#1A3673', height: 30 }}>
                <th className="px-3 py-2 text-left text-white font-semibold whitespace-nowrap sticky left-0 z-10" style={{ background: '#1A3673', minWidth: 110 }}>Market</th>
                <th className="px-3 py-2 text-center text-white font-semibold whitespace-nowrap" style={{ minWidth: 80 }}>Scale Factor</th>
                <th className="px-3 py-2 text-center text-white font-semibold whitespace-nowrap" style={{ minWidth: 80 }}>Start</th>
                <th className="px-3 py-2 text-center text-white font-semibold whitespace-nowrap" style={{ minWidth: 80 }}>End</th>
                <th className="px-3 py-2 text-center text-white font-semibold whitespace-nowrap" style={{ minWidth: 70 }}>Type</th>
                <th className="px-4 py-2 text-right font-semibold whitespace-nowrap text-[#44B8F3]" style={{ background: 'rgba(68,184,243,0.15)', minWidth: 110 }}>Total</th>
                {period.mode !== 'Yearly' && visibleCols.map(col => (
                  <th key={col} className="px-4 py-2 text-right text-[#C7EAFB] font-semibold whitespace-nowrap" style={{ minWidth: 88 }}>
                    {fmtMonth(col)}
                  </th>
                ))}
                <th className="px-3 py-2 text-left text-white font-semibold whitespace-nowrap" style={{ minWidth: 130 }}>Comments</th>
              </tr>
            </thead>
            <tbody>
              {marketGroups.map(({ market, unscaled, scaled }, gi) => {
                const rowBg  = gi % 2 === 0 ? '#fff' : '#f8f9fb';
                const subRows = [
                  { key: 'Unscaled', row: unscaled },
                  { key: 'Scaled',   row: scaled   },
                ].filter(s => s.row);

                return subRows.map(({ key, row }, si) => {
                  const st       = TYPE_STYLES[key];
                  const isFirst  = si === 0;
                  const borderTop = isFirst && gi > 0 ? '2px solid #e5e7eb' : !isFirst ? '1px solid #f0f0f0' : undefined;

                  return (
                    <tr key={`${gi}-${key}`} style={{ background: rowBg, borderTop }}>
                      {/* Market — rowspan */}
                      {isFirst && (
                        <td rowSpan={subRows.length}
                          className="px-3 py-2 font-semibold text-[#1A3673] whitespace-nowrap align-middle sticky left-0 z-10"
                          style={{ background: rowBg, borderRight: '1px solid #e5e7eb', borderTop: gi > 0 ? '2px solid #e5e7eb' : undefined }}>
                          {market}
                        </td>
                      )}
                      {/* Scale factor — rowspan, use scaled row value */}
                      {isFirst && (
                        <td rowSpan={subRows.length} className="px-3 py-2 text-center align-middle font-mono text-[11px]"
                          style={{ borderRight: '1px solid #e5e7eb', borderTop: gi > 0 ? '2px solid #e5e7eb' : undefined }}>
                          {scaled?.scaling_factor != null
                            ? <span className={scaled.scaling_factor > 0 ? 'text-[#00BBBA] font-semibold' : 'text-gray-400'}>
                                {Number(scaled.scaling_factor).toFixed(3)}
                              </span>
                            : <span className="text-gray-300">—</span>}
                        </td>
                      )}
                      {/* Start */}
                      {isFirst && (
                        <td rowSpan={subRows.length} className="px-3 py-2 text-center align-middle whitespace-nowrap text-[11px] text-gray-500"
                          style={{ borderRight: '1px solid #e5e7eb', borderTop: gi > 0 ? '2px solid #e5e7eb' : undefined }}>
                          {row?.start_date ?? '—'}
                        </td>
                      )}
                      {/* End */}
                      {isFirst && (
                        <td rowSpan={subRows.length} className="px-3 py-2 text-center align-middle whitespace-nowrap text-[11px] text-gray-500"
                          style={{ borderRight: '2px solid #e5e7eb', borderTop: gi > 0 ? '2px solid #e5e7eb' : undefined }}>
                          {row?.end_date ?? '—'}
                        </td>
                      )}
                      {/* Type badge */}
                      <td className="px-3 py-1.5 text-center whitespace-nowrap" style={{ borderRight: '1px solid #e5e7eb' }}>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                          style={{ background: st.badgeBg, color: st.badgeText }}>
                          {key}
                        </span>
                      </td>
                      {/* Total */}
                      <td className="px-4 py-1.5 text-right font-mono text-[11px] font-semibold whitespace-nowrap"
                        style={{ borderRight: '1px solid #e5e7eb', background: 'rgba(68,184,243,0.05)' }}>
                        <span style={{ color: st.text }}>{fmtNum(row?.total)}</span>
                      </td>
                      {/* Monthly cols */}
                      {period.mode !== 'Yearly' && visibleCols.map(col => {
                        const v = row?.monthly?.[col] ?? null;
                        return (
                          <td key={col} className="px-4 py-1.5 text-right font-mono text-[11px] whitespace-nowrap"
                            style={{ borderRight: '1px solid #f0f0f0' }}>
                            <span style={{ color: v === null || v === 0 ? '#d1d5db' : st.text }}>
                              {v === null ? '—' : v === 0 ? '—' : fmtNum(v)}
                            </span>
                          </td>
                        );
                      })}
                      {/* Comments */}
                      {isFirst && (
                        <td rowSpan={subRows.length} className="px-3 py-2 text-[10px] text-gray-500 align-top"
                          style={{ borderLeft: '1px solid #f0f0f0', maxWidth: 200 }}>
                          {row?.comments
                            ? <span className="flex items-start gap-1"><span>💬</span><span className="leading-relaxed">{row.comments}</span></span>
                            : <span className="text-gray-300 italic">—</span>}
                        </td>
                      )}
                    </tr>
                  );
                });
              })}
              {marketGroups.length === 0 && (
                <tr>
                  <td colSpan={99} className="text-center py-8 text-xs text-gray-400">
                    No rows match the current filters.{' '}
                    <button onClick={clearFilters} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Main tab ──────────────────────────────────────────────────────────────────
export default function FinancialSummaryTab({ coversheet }) {
  const { showToast } = useToast();
  const [data,     setData]    = useState(null);
  const [loading,  setLoading] = useState(false);
  const [error,    setError]   = useState(null);

  // Period state — mirrors the screenshot controls
  const [periodMode,    setPeriodMode]    = useState('Monthly');
  const [selectedMonth, setSelectedMonth] = useState('All');
  const [selectedQ,     setSelectedQ]     = useState('All');

  const cvrsht_id   = coversheet?.id || coversheet?.cvrsht_id;
  const fetchingRef = useRef(false);

  const fetchData = async () => {
    if (!cvrsht_id || fetchingRef.current) return;
    fetchingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const result = await financialSummaryApi.calculate(cvrsht_id);
      setData(result);
    } catch (err) {
      // Duplicate-key means a concurrent call already saved the data — not a real error.
      const isDuplicate = err.message?.includes('duplicate key') || err.message?.includes('unique constraint');
      if (!isDuplicate) {
        setError(err.message);
        showToast(`Financial summary failed: ${err.message}`, 'error');
      }
    } finally {
      setLoading(false);
      fetchingRef.current = false;
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const activeMonths = data?.active_months ?? [];
  const sections     = data?.sections     ?? [];

  // Build period object passed down to section tables
  const period = { mode: periodMode, month: selectedMonth, quarter: selectedQ };

  // Month options derived from activeMonths
  const monthOptions = activeMonths;

  // Period label chip (top-right)
  const periodChipLabel = periodMode === 'Yearly' ? 'Yearly'
    : periodMode === 'Quarterly' ? (selectedQ === 'All' ? `All ${activeMonths.length > 0 ? activeMonths.length : 12} Months` : selectedQ)
    : (selectedMonth === 'All' ? `All ${activeMonths.length} Months` : fmtMonth(selectedMonth));

  // ── Loader ────────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-32 gap-4">
        <Loader2 size={36} className="animate-spin text-[#1A3673]" />
        <p className="text-sm text-gray-500 font-medium">Calculating financial summary…</p>
        <p className="text-xs text-gray-400">{cvrsht_id}</p>
      </div>
    );
  }

  // ── Error ─────────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center">
          <AlertCircle size={22} className="text-[#E3725F]" />
        </div>
        <p className="text-sm text-gray-600 font-medium">Could not load financial summary</p>
        <p className="text-xs text-gray-400 max-w-sm text-center">{error}</p>
        <button onClick={() => { fetchingRef.current = false; fetchData(); }}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#1A3673] text-white rounded-lg hover:bg-[#2861BB] transition">
          <RefreshCw size={12} /> Retry
        </button>
      </div>
    );
  }

  if (!data) return null;

  // ── Export to Excel ──────────────────────────────────────────────────────
  const handleExport = () => {
    try {
      const wb = XLSX.utils.book_new();
      const colsToExport = period.mode !== 'Yearly' ? activeMonths : [];

      data.sections?.forEach((section) => {
        const rows = section.rows ?? [];

        // Build header row
        const header = ['Market', 'LOB', 'Type', 'Scale Factor', 'Start', 'End', 'Total'];
        colsToExport.forEach(col => header.push(fmtMonth(col)));
        header.push('Comments');

        const sheetRows = [header];

        // Group by market, Unscaled then Scaled
        const markets = [...new Set(rows.map(r => r.market))].sort();
        markets.forEach(mkt => {
          ['Unscaled', 'Scaled'].forEach(type => {
            const row = rows.find(r => r.market === mkt && r.type === type);
            if (!row) return;
            const dataRow = [
              row.market,
              row.lob ?? '',
              row.type,
              row.scaling_factor != null ? Number(row.scaling_factor) : '',
              row.start_date ?? '',
              row.end_date   ?? '',
              row.total      != null ? Number(row.total) : '',
            ];
            colsToExport.forEach(col => {
              const v = row.monthly?.[col];
              dataRow.push(v != null ? Number(v) : '');
            });
            dataRow.push(row.comments ?? '');
            sheetRows.push(dataRow);
          });
        });

        // Section totals row
        const totalsRow = ['TOTAL', '', '', '', '', '',
          Number(section.unscaled_total) + Number(section.scaled_total),
        ];
        colsToExport.forEach(() => totalsRow.push(''));
        totalsRow.push('');
        sheetRows.push(totalsRow);

        const ws = XLSX.utils.aoa_to_sheet(sheetRows);

        // Column widths
        ws['!cols'] = [
          { wch: 18 }, { wch: 14 }, { wch: 10 }, { wch: 12 },
          { wch: 10 }, { wch: 10 }, { wch: 14 },
          ...colsToExport.map(() => ({ wch: 12 })),
          { wch: 30 },
        ];

        // Bold header row
        const range = XLSX.utils.decode_range(ws['!ref'] ?? 'A1');
        for (let c = range.s.c; c <= range.e.c; c++) {
          const cell = ws[XLSX.utils.encode_cell({ r: 0, c })];
          if (cell) cell.s = { font: { bold: true } };
        }
        // Bold totals row
        const lastR = sheetRows.length - 1;
        for (let c = range.s.c; c <= range.e.c; c++) {
          const cell = ws[XLSX.utils.encode_cell({ r: lastR, c })];
          if (cell) cell.s = { font: { bold: true } };
        }

        // Sheet name: max 31 chars (Excel limit)
        const sheetName = (section.display_name ?? section.lob ?? 'Sheet').slice(0, 31);
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
      });

      // Summary sheet — one row per section
      const summaryRows = [
        ['LOB', 'Markets', 'Unscaled Total', 'Scaled Total', 'Period Start', 'Period End'],
        ...(data.sections ?? []).map(s => [
          s.display_name ?? s.lob ?? '',
          s.market_count ?? '',
          s.unscaled_total != null ? Number(s.unscaled_total) : '',
          s.scaled_total   != null ? Number(s.scaled_total)   : '',
          data.savings_period?.start ?? '',
          data.savings_period?.end   ?? '',
        ]),
      ];
      const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
      wsSummary['!cols'] = [{ wch: 20 }, { wch: 10 }, { wch: 16 }, { wch: 14 }, { wch: 12 }, { wch: 12 }];
      XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary');

      const fileName = `FinancialSummary_${cvrsht_id ?? 'export'}_${new Date().toISOString().slice(0, 10)}.xlsx`;
      XLSX.writeFile(wb, fileName);
      showToast('Export downloaded', 'success');
    } catch (err) {
      showToast(`Export failed: ${err.message}`, 'error');
    }
  };

  return (
    <div className="space-y-0 pt-2">

      {/* ══ Single combined header + VIEW BY bar ═════════════════════════════ */}
      <div className="flex items-center gap-4 py-2.5 px-1 border-b border-gray-100 bg-white flex-wrap">

        {/* Title + subtitle */}
        <div className="flex-shrink-0">
          <p className="text-sm font-bold text-gray-800 leading-tight">{data.financial_model_type ?? 'Financial Summary Breakdown'}</p>
          <p className="text-[11px] text-gray-400">
            {data.category_label}
            {data.savings_period?.start && (
              <> · {data.savings_period.start} – {data.savings_period.end}</>
            )}
          </p>
        </div>

        {/* Separator */}
        <span className="w-px h-8 bg-gray-200 flex-shrink-0" />

        {/* VIEW BY label */}
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex-shrink-0">View by</span>

        {/* Mode pills */}
        <div className="flex bg-gray-100 rounded-lg p-0.5 gap-0.5 flex-shrink-0">
          {['Monthly', 'Quarterly', 'Yearly'].map(m => (
            <button key={m} onClick={() => setPeriodMode(m)}
              className={`px-3 py-1 text-[11px] font-semibold rounded-md transition ${
                periodMode === m ? 'bg-[#1A3673] text-white shadow-sm' : 'text-gray-500 hover:text-[#1A3673]'
              }`}>
              {m}
            </button>
          ))}
        </div>

        {/* Separator */}
        <span className="w-px h-5 bg-gray-200 flex-shrink-0" />

        {/* Month dropdown */}
        {periodMode === 'Monthly' && (
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-semibold text-gray-500">Month</span>
            <select
              value={selectedMonth}
              onChange={e => setSelectedMonth(e.target.value)}
              className="text-[11px] border border-gray-200 rounded-md px-2 py-1 focus:outline-none focus:border-[#1A3673] bg-white"
            >
              <option value="All">All Months</option>
              {monthOptions.map(m => <option key={m} value={m}>{fmtMonth(m)}</option>)}
            </select>
          </div>
        )}

        {/* Quarter dropdown */}
        {periodMode === 'Quarterly' && (
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-semibold text-gray-500">Quarter</span>
            <select
              value={selectedQ}
              onChange={e => setSelectedQ(e.target.value)}
              className="text-[11px] border border-gray-200 rounded-md px-2 py-1 focus:outline-none focus:border-[#1A3673] bg-white"
            >
              <option value="All">All Quarters</option>
              {['Q1','Q2','Q3','Q4'].map(q => <option key={q} value={q}>{q}</option>)}
            </select>
          </div>
        )}

        {/* Period chip + Export — far right */}
        <div className="ml-auto flex items-center gap-2 flex-shrink-0">
          <span className="text-[11px] font-semibold px-3 py-1.5 rounded-lg bg-[#E1EDFF] text-[#1A3673] border border-[#1A3673]/20">
            {periodChipLabel}
          </span>
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold bg-[#1A3673] text-white rounded-lg hover:bg-[#2861BB] transition"
          >
            <Download size={11} /> Export
          </button>
        </div>

      </div>



      {/* ══ Section tables ════════════════════════════════════════════════════ */}
      <div className="space-y-3 pb-6">
        {sections.map((section, i) => (
          <SectionTable
            key={section.lob ?? i}
            section={section}
            activeMonths={activeMonths}
            period={period}
          />
        ))}
        {sections.length === 0 && (
          <div className="card p-10 flex flex-col items-center justify-center gap-2 text-gray-400">
            <AlertCircle size={24} />
            <p className="text-sm">No sections returned from the API.</p>
          </div>
        )}
      </div>
    </div>
  );
}
