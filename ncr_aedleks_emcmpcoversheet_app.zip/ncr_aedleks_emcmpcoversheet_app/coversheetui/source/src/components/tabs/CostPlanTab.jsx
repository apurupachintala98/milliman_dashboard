import { useState, useCallback, useEffect, useRef } from 'react';
import { Trash2, Pencil, DollarSign, Users, Info, Plus, FileSpreadsheet, ChevronDown, Calendar, Building2, Search, Filter, X, Loader2, AlertTriangle, Save } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { costPlanApi } from '../../config/apiConfig';

const DEFAULT_COST_META = {
  costType: 'One-time',
  timeframeStart: '', timeframeEnd: '',
  distribution: 'equal', periods: [],
};

function buildPeriods(start, end, total, mode, existing) {
  if (!start || !end) return [];
  const [sy, sm] = start.split('-').map(Number);
  const [ey, em] = end.split('-').map(Number);
  const labels = [];
  let y = sy, m = sm;
  while (y < ey || (y === ey && m <= em)) {
    labels.push(`${y}-${String(m).padStart(2, '0')}`);
    m++; if (m > 12) { m = 1; y++; }
    if (labels.length > 120) break; // safety
  }
  if (labels.length === 0) return [];
  if (mode === 'equal') {
    const perPeriod = Math.round((total / labels.length) * 100) / 100;
    return labels.map(label => ({ label, amount: perPeriod }));
  }
  const existingMap = Object.fromEntries(existing.map(p => [p.label, p.amount]));
  return labels.map(label => ({ label, amount: existingMap[label] ?? 0 }));
}

const fmtPeriod = (ym) => {
  if (!ym) return '';
  const [y, m] = ym.split('-');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${months[parseInt(m)-1]} ${y}`;
};


const BLANK_FTE = (section) => ({
  section, costPlanNumber: '',
  positions: 0, startDate: '', jobCode: '', jobTitle: '', department: '',
  approvedBy: '', hiringManager: '',
  onshoreOffshore: '', cocNonCoc: '', caOnly: '',
  cost: 0, snowDescription: '',
  periodStart: '', periodEnd: '',
  costMeta: { ...DEFAULT_COST_META },
});


const SECTION_IDS = { it: 'IT_EXPENSE', fte: 'FTE_EXPENSE', vnd: 'VENDOR_EXPENSES', oth: 'OTHERS' };
const LOE_GROUP_ID = 'LOE';

const num = (v) => (typeof v === 'number' && !isNaN(v) ? v : parseFloat(v) || 0);
const toYm = (d) => (d ? String(d).slice(0, 7) : '');

function toIsoDate(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'object') return toIsoDate(v.value ?? v.display_value ?? v.date ?? '');
  const pad = (n) => String(n).padStart(2, '0');
  if (typeof v === 'number') {
    const d = new Date(v);
    return isNaN(d) ? '' : `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${m[1]}-${pad(m[2])}-${pad(m[3])}`;
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); // US MM/DD/YYYY
  if (m) return `${m[3]}-${pad(m[1])}-${pad(m[2])}`;
  const d = new Date(s);
  return isNaN(d) ? '' : `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
const toYmd = (d) => toIsoDate(d);
const MAPPERS = {};  
const cdOf = (d) => (d?.costDistribution && typeof d.costDistribution === 'object' ? d.costDistribution : {});
const periodKeys = (d) => {
  const cd = cdOf(d);
  return {
    periodStart: toYmd(cd.from) || toYmd(d.periodStart),   // shown / edited
    periodEnd:   toYmd(cd.to)   || toYmd(d.periodEnd),
    periodMin:   toYmd(d.periodStart),                     // allowed range only
    periodMax:   toYmd(d.periodEnd),
  };
};

function mapCostMeta(rowData, total) {
  const dist = rowData.costDistribution || {};
  const costType = dist.costType || rowData.costType || DEFAULT_COST_META.costType;
  const timeframeStart = toYmd(dist.from) || toYmd(rowData.periodStart);
  const timeframeEnd   = toYmd(dist.to)   || toYmd(rowData.periodEnd);
  const distribution   = /manual/i.test(dist.method || '') ? 'manual' : 'equal';
  const existing = Array.isArray(dist.periods)
    ? dist.periods.map(p => ({ label: toYm(p.label ?? p.month), amount: num(p.amount) }))
    : [];
  return {
    costType, timeframeStart, timeframeEnd, distribution,
    periods: buildPeriods(timeframeStart, timeframeEnd, total, distribution, existing),
  };
}

const cpnOf = (row, d) => row.costPlanNumber ?? d.costPlanNumber ?? '';

const apiKeys = (row, sectionId) => ({
  id: row.rowId, rowId: row.rowId, groupId: row.groupId, sectionId,
  costPlanOrderNumber: row.costPlanOrderNumber ?? null,
  readOnly: !!row.readOnly,
  apiRow: { rowData: { ...(row.rowData || {}) }, totalCost: row.totalCost ?? null, sortOrder: row.sortOrder ?? null },
});

function mapLoeRow(row, sectionId) {
  const d = row.rowData || {};
  const estimate = num(d.estimate);
  const opsMaintenanceCost = num(d.opsSupport);
  const totalCost = row.totalCost != null ? num(row.totalCost) : estimate + opsMaintenanceCost;
  return {
    ...apiKeys(row, sectionId),
    cin: d.cin ?? '', costPlanNumber: cpnOf(row, d), costPlanDescription: d.costPlanDescription ?? '',
    sizing: d.sizing ?? '', bdm: d.bdm ?? '', timber: d.timber ?? '',
    estimate, opsMaintenanceCost, totalCost,
    projectNumber: d.projectNumber ?? '', notes: d.notes ?? '',
    ...periodKeys(d),
    costMeta: mapCostMeta(d, totalCost),
  };
}

function mapItSummaryRow(row, sectionId) {
  const d = row.rowData || {};
  return {
    ...apiKeys(row, sectionId),
    costPlanNumber: cpnOf(row, d),
    description: d.item ?? d.description ?? d.costPlanDescription ?? '',
    totalCost: num(row.totalCost ?? d.totalCost ?? d.amount),
    timeline: d.timeline ?? '',
  };
}

function mapFteRow(row, sectionId) {
  const d = row.rowData || {};
  const cost = num(d.cost ?? row.totalCost);
  return {
    ...apiKeys(row, sectionId),
    section: row.groupId,
    costPlanNumber: cpnOf(row, d),
    positions: num(d.positions), startDate: d.startDate ?? '', jobCode: d.jobCode ?? '', jobTitle: d.jobTitle ?? '',
    department: d.department ?? '', approvedBy: d.approvedBy ?? '', hiringManager: d.hiringManager ?? '',
    onshoreOffshore: d.onshoreOffshore ?? '', cocNonCoc: d.coc ?? '', caOnly: d.caOnly ?? '',
    cost, snowDescription: d.costPlanDescription ?? '',
    ...periodKeys(d),
    costMeta: mapCostMeta(d, cost),
  };
}

function mapOtherRow(row, sectionId) {
  const d = row.rowData || {};
  const amount = num(d.amount ?? row.totalCost);
  return {
    ...apiKeys(row, sectionId),
    costPlanNumber: cpnOf(row, d), category: d.category ?? '',
    description: d.costPlanDescription ?? '', vendor: d.vendor ?? '',
    costType: d.costType ?? '', amount, timeline: d.timeline ?? '', notes: d.notes ?? '',
    ...periodKeys(d),
    costMeta: mapCostMeta(d, amount),
  };
}

function mapVendorRow(row, sectionId) {
  const d = row.rowData || {};
  const monthly = d.monthlyScaledActuals ?? d.monthlyActuals ?? d.months ?? [];
  const fee = d.vendorFeePct ?? d.vendorFeePercent ?? d.vendorFee ?? null;
  return {
    ...apiKeys(row, sectionId),
    vendor: d.costPlanDescription ?? d.costPlanDescription ?? '',
    costPlanNumber: cpnOf(row, d),
    description: d.costPlanDescription ?? d.description ?? '',
    vendorFeePct: fee == null || fee === '' ? null : num(fee),
    savedFeePct:  fee == null || fee === '' ? null : num(fee),  
    monthlyScaledActuals: (Array.isArray(monthly) ? monthly : [])
      .map(m => ({ month: toYm(m.month ?? m.period ?? m.label), amount: num(m.amount ?? m.value) }))
      .filter(m => m.month),
  };
}

Object.assign(MAPPERS, { loe: mapLoeRow, fte: mapFteRow, oth: mapOtherRow });

const EDIT_FIELDS = {
  loe: [['sizing'], ['bdm'], ['timber'], ['estimate'], ['opsMaintenanceCost', 'opsSupport'], ['costType'],
        ['projectNumber'], ['notes']],
  fte: [['positions'], ['startDate'], ['jobCode'], ['jobTitle'], ['department'], ['approvedBy'], ['hiringManager'],
        ['onshoreOffshore'], ['cocNonCoc', 'coc'], ['caOnly'], ['cost'], ['costType'], ['snowDescription', 'costPlanDescription']],
  oth: [['category'], ['description', 'costPlanDescription'], ['vendor'], ['costType'], ['amount'], ['timeline'], ['notes']],
};
const uiVal = (kind, r, k) => (k === 'costType' && kind !== 'oth' ? r.costMeta?.costType : r[k]);
const uiTotal = (kind, r) => (kind === 'loe' ? r.totalCost : kind === 'fte' ? r.cost : r.amount);

function buildEditPatch(kind, original, draft) {
  const patch = {};
  for (const [ui, api = ui] of EDIT_FIELDS[kind]) {
    const before = uiVal(kind, original, ui), after = uiVal(kind, draft, ui);
    if ((before ?? '') !== (after ?? '')) patch[api] = after;
  }
  return patch;
}

function dateChange(oldStart, oldEnd, newStart, newEnd) {
  if ((oldStart || '') === (newStart || '') && (oldEnd || '') === (newEnd || '')) return null;
  return { from: newStart || null, to: newEnd || null };
}


function mergeRowData(base, patch, dates) {
  const merged = { ...base, ...patch };
  const cd = base.costDistribution && typeof base.costDistribution === 'object' ? base.costDistribution : null;
  if (dates || (cd && 'costType' in patch)) {
    const next = { ...(cd || { costType: merged.costType || DEFAULT_COST_META.costType, method: 'Spread Equally' }) };
    if (dates) { next.from = dates.from; next.to = dates.to; }
    if (cd && 'costType' in patch) next.costType = patch.costType;
    merged.costDistribution = next;
  }
  return merged;
}

function withDisplayDates(uiRow, start, end, total) {
  const s = toYmd(start), e = toYmd(end);
  const meta = uiRow.costMeta;
  return {
    ...uiRow, periodStart: s, periodEnd: e,
    costMeta: { ...meta, timeframeStart: s, timeframeEnd: e,
      periods: buildPeriods(s, e, total, meta.distribution, meta.periods) },
  };
}

const bySortOrder = (a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0);

function mapCostsResponse(data) {
  const sections = Array.isArray(data?.sections) ? data.sections : [];
  const find = (sid) => sections.find(s => s.sectionId === sid);
  const groupRows = (g) => [...(g.rows || [])].sort(bySortOrder);
  const meta = (s) => (s ? { title: s.title, description: s.description, subtotal: s.subtotal } : null);

  const it = find(SECTION_IDS.it);
  const itGroups = it?.groups || [];
  const loeGroup = itGroups.find(g => g.groupId === LOE_GROUP_ID);
  const loeRows = loeGroup ? groupRows(loeGroup).map(r => mapLoeRow(r, it.sectionId)) : [];
  const itRows = itGroups.filter(g => g.groupId !== LOE_GROUP_ID)
    .flatMap(g => groupRows(g).map(r => mapItSummaryRow(r, it.sectionId)));

  const fte = find(SECTION_IDS.fte);
  const fteGroups = (fte?.groups || []).map(g => ({ groupId: g.groupId, groupName: g.groupName || g.groupId }));
  const fteRows = (fte?.groups || []).flatMap(g => groupRows(g).map(r => mapFteRow(r, fte.sectionId)));

  const vnd = find(SECTION_IDS.vnd);
  const vndGroup = vnd?.groups?.[0];
  const vendorRows = (vnd?.groups || []).flatMap(g => groupRows(g).map(r => mapVendorRow(r, vnd.sectionId)));
  const vendorRowNumbers = new Set(vendorRows.map(r => r.costPlanNumber));
  const suggestedVendorPlans = (Array.isArray(data?.costPlans) ? data.costPlans : [])
    .filter(p => p?.costPlanNumber && p.suggestedSectionId === SECTION_IDS.vnd && !vendorRowNumbers.has(p.costPlanNumber))
    .map(p => ({
      id: `vendor-plan:${p.costPlanNumber}`, rowId: null, groupId: p.suggestedGroupId || vndGroup?.groupId || null,
      sectionId: SECTION_IDS.vnd, readOnly: false,
      vendor: p.vendor ?? '', costPlanNumber: p.costPlanNumber, description: p.description ?? '',
      vendorFeePct: null, savedFeePct: null, monthlyScaledActuals: [],
    }));
  const vendorPlans = [...vendorRows, ...suggestedVendorPlans];

  const oth = find(SECTION_IDS.oth);
  const othGroup = oth?.groups?.[0];
  const otherRows = (oth?.groups || []).flatMap(g => groupRows(g).map(r => mapOtherRow(r, oth.sectionId)));

  const planPeriods = Object.fromEntries((Array.isArray(data?.costPlans) ? data.costPlans : [])
    .filter(p => p?.costPlanNumber && p.periodStart && p.periodEnd)
    .map(p => [p.costPlanNumber, { min: toYmd(p.periodStart), max: toYmd(p.periodEnd) }]));
  const planDesc = Object.fromEntries((Array.isArray(data?.costPlans) ? data.costPlans : [])
    .filter(p => p?.costPlanNumber).map(p => [p.costPlanNumber, p.description || '']));
  const withDesc = (rows, key) => rows.map(r => (!r[key] && planDesc[r.costPlanNumber] ? { ...r, [key]: planDesc[r.costPlanNumber] } : r));

  const groupMeta = (g) => (g ? { groupId: g.groupId, groupName: g.groupName || g.groupId } : null);
  return {
    sections: { it: meta(it), fte: meta(fte), vnd: meta(vnd), oth: meta(oth) },
    groups: {
      loe: groupMeta(loeGroup),
      itOther: itGroups.filter(g => g.groupId !== LOE_GROUP_ID).map(groupMeta),
      vnd: groupMeta(vndGroup),
      oth: groupMeta(othGroup),
    },
    ...uniqueIds({
      loeRows: withDesc(loeRows, 'costPlanDescription'),
      itRows,
      fteRows: withDesc(fteRows, 'snowDescription'),
      vendorPlans: withDesc(vendorPlans, 'description'),
      otherRows: withDesc(otherRows, 'description'),
    }),
    fteGroups,
    planPeriods,
  };
}

function uniqueIds(lists) {
  const seen = new Set();
  const out = {};
  for (const [name, rows] of Object.entries(lists)) {
    out[name] = rows.map((r, i) => {
      let id = r.id || `${name}-${i}`;
      if (seen.has(id)) id = `${id}#${i}`;
      while (seen.has(id)) id = `${id}~`;
      seen.add(id);
      return id === r.id ? r : { ...r, id };
    });
  }
  return out;
}

const toDate = (d) => toIsoDate(d) || null;

const periodOf = (r, plan) => ({
  periodStart: toDate(r.periodStart) || toDate(plan?.start_fiscal_period_start_date_time),
  periodEnd:   toDate(r.periodEnd)   || toDate(plan?.end_fiscal_period_end_date_time),
});

function buildCostDistribution(costType, r, plan) {
  const { periodStart, periodEnd } = periodOf(r, plan);
  return { costType, from: periodStart, to: periodEnd, method: 'Spread Equally' };
}

function buildLoeRowData(r, plan, cin) {
  const costType = r.costType || DEFAULT_COST_META.costType;
  return {
    costPlanNumber: r.costPlanNumber,
    costPlanDescription: plan?.u_short_description ?? '',
    cin: cin ?? '',
    sizing: r.sizing, bdm: r.bdm, timber: r.timber,
    estimate: r.estimate, opsSupport: r.opsMaintenanceCost,
    costType, projectNumber: r.projectNumber, notes: r.notes,
    costDistribution: buildCostDistribution(costType, r, plan),
  };
}

function buildFteRowData(r, plan) {
  const costType = r.costMeta?.costType || DEFAULT_COST_META.costType;
  return {
    costPlanNumber: r.costPlanNumber,
    costPlanDescription: r.snowDescription || plan?.u_short_description || '',
    positions: r.positions, startDate: r.startDate, jobCode: r.jobCode, jobTitle: r.jobTitle,
    department: r.department, approvedBy: r.approvedBy, hiringManager: r.hiringManager,
    onshoreOffshore: r.onshoreOffshore, coc: r.cocNonCoc, caOnly: r.caOnly,
    cost: r.cost, costType,
    costDistribution: buildCostDistribution(costType, r, plan),
  };
}

function buildOtherRowData(r, plan) {
  const costType = r.costType || DEFAULT_COST_META.costType;
  return {
    costPlanNumber: r.costPlanNumber,
    costPlanDescription: r.description || plan?.u_short_description || '',
    category: r.category, vendor: r.vendor, amount: r.amount,
    timeline: r.timeline, notes: r.notes, costType,
    costDistribution: buildCostDistribution(costType, r, plan),
  };
}

const extractCreatedRow = (res) =>
  [res, res?.row, res?.data, res?.data?.row].find(c => c && typeof c === 'object' && c.rowId) || null;

function CostPlanSelect({ value, onChange, costPlans, loading, error, className = 'w-40' }) {
  return (
    <select className={`form-select text-xs ${className}`} value={value} onChange={e => onChange(e.target.value)}
      disabled={loading} title={error ? `Could not load cost plans: ${error}` : undefined}
      style={error ? { borderColor: '#E3725F' } : undefined}>
      <option value="">{loading ? 'Loading…' : error ? 'Failed to load' : costPlans.length ? 'Select Cost Plan #' : 'No cost plans'}</option>
      {costPlans.map(p => (
        <option key={p.cost_plan_id || p.u_number} value={p.u_number}>
          {p.u_number}{p.u_short_description ? ` — ${p.u_short_description}` : ''}
        </option>
      ))}
    </select>
  );
}


function parseFeePct(raw) {
  const s = raw.trim().replace(/%$/, '').trim();
  if (!s) return { value: null };
  if (s.startsWith('-')) return { value: null, error: 'Vendor Fee % cannot be negative.' };
  if (!/^(\d+\.?\d*|\.\d+)$/.test(s)) return { value: null, error: 'Enter a percentage, e.g. 5 or 5.25.' };
  const n = parseFloat(s);
  if (n > 100) return { value: null, error: 'Vendor Fee % cannot exceed 100%.' };
  return { value: n };
}

const fmtMoney = (n) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
const round2 = (n) => {
  if (!Number.isFinite(n)) return 0;
  const abs = Math.abs(n);
  const r = /e/i.test(String(abs)) ? Math.round(abs * 100) / 100 : Number(`${Math.round(Number(`${abs}e2`))}e-2`);
  return n < 0 ? -r : r;
};
const calcVendorFee = (amount, pct) => round2((amount * pct) / 100);
const fmtWhole = (n) => `$${Math.round(n).toLocaleString('en-US')}`;
const vHead = { padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' };
const vCell = { padding: '10px 12px', textAlign: 'right', verticalAlign: 'middle', whiteSpace: 'nowrap' };

function SavingsFeeCell({ savings, fee, bold = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, lineHeight: 1.4, fontFamily: 'monospace' }}>
      <span title={savings == null ? undefined : fmtMoney(savings)} style={{ fontSize: 11, fontWeight: bold ? 700 : 500, color: savings == null ? '#d1d5db' : '#1f2937' }}>
        {savings == null ? '—' : fmtWhole(savings)}
      </span>
      <span title={fee == null ? undefined : fmtMoney(fee)} style={{ fontSize: 11, fontWeight: bold ? 700 : 500, color: fee == null ? '#d1d5db' : '#2861BB' }}>
        {fee == null ? '—' : fmtWhole(fee)}
      </span>
    </div>
  );
}

function MeasureLabels({ bold = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, lineHeight: 1.4, whiteSpace: 'nowrap' }}>
      <span style={{ fontSize: 11, fontWeight: bold ? 700 : 600, color: '#1f2937' }}>Scaled Savings</span>
      <span style={{ fontSize: 11, fontWeight: bold ? 700 : 600, color: '#2861BB' }}>Vendor Fee</span>
    </div>
  );
}

const fmtCost = (n) => n === 0 ? '—' : `$${n.toLocaleString()}`;

function CostSection({ id, title, subtitle, icon: Icon, total, accent, tint, defaultOpen = false, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section id={`cost-${id}`} className="rounded-xl overflow-hidden scroll-mt-20" style={{ border: `1px solid ${accent}40`, background: tint }}>
      <button type="button" onClick={() => setOpen(o => !o)} aria-expanded={open}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:brightness-110 transition" style={{ background: accent }}>
        <ChevronDown size={16} className="text-white transition-transform" style={{ transform: open ? 'rotate(0deg)' : 'rotate(-90deg)' }} />
        <Icon size={16} className="text-white" />
        <div className="flex-1">
          <p className="text-sm font-bold text-white uppercase tracking-wider">{title}</p>
          <p className="text-[10px] text-white/80">{subtitle}</p>
        </div>
        <div className="text-right">
          <p className="text-[9px] text-white/70 uppercase tracking-wider">Subtotal</p>
          <p className="text-sm font-bold font-mono text-white">{fmtCost(total)}</p>
        </div>
      </button>
      {open && <div className="p-4 space-y-4">{children}</div>}
    </section>
  );
}

// ── Cost Distribution Panel ───────────────────────────────────────────────────
function CostDistributionPanel({ total, meta, colSpan, onSave, range, readOnly = false }) {
  const [draft, setDraft] = useState(() => ({ ...meta, periods: meta.periods.map(p => ({ ...p })) }));
  const [amtDrafts, setAmtDrafts] = useState(() => meta.periods.map(p => p.amount === 0 ? '' : String(p.amount)));
  const [unsaved, setUnsaved] = useState(false);

  const metaRef = useRef(meta);
  useEffect(() => {
    if (metaRef.current !== meta) {
      metaRef.current = meta;
      setDraft({ ...meta, periods: meta.periods.map(p => ({ ...p })) });
      setAmtDrafts(meta.periods.map(p => p.amount === 0 ? '' : String(p.amount)));
      setUnsaved(false);
    }
  }, [meta]);

  const patch = (p) => {
    setDraft(prev => {
      const next = { ...prev, ...p };
      if ('timeframeStart' in p || 'timeframeEnd' in p || 'distribution' in p) {
        next.periods = buildPeriods(next.timeframeStart, next.timeframeEnd, total, next.distribution, prev.periods);
        if (next.distribution === 'manual') {
          setAmtDrafts(next.periods.map(pp => pp.amount === 0 ? '' : String(pp.amount)));
        }
      }
      return next;
    });
    setUnsaved(true);
  };

  const handleAmtChange = (i, raw) => {
    const next = [...amtDrafts];
    next[i] = raw;
    setAmtDrafts(next);
    const num = parseFloat(raw);
    setDraft(prev => {
      const periods = prev.periods.map((p, pi) => pi === i ? { ...p, amount: isNaN(num) ? 0 : num } : p);
      return { ...prev, periods };
    });
    setUnsaved(true);
  };

  const [saving, setSaving] = useState(false);
  const handleSave = async () => {
    const finalPeriods = draft.periods.map((p, i) => ({
      ...p,
      amount: amtDrafts[i] !== undefined ? (parseFloat(amtDrafts[i]) || 0) : p.amount,
    }));
    const finalMeta = { ...draft, periods: finalPeriods };
    metaRef.current = finalMeta; 
    setSaving(true);
    const ok = await onSave(finalMeta);
    setSaving(false);
    if (ok === false) return; 
    setUnsaved(false);
  };

  const handleDiscard = () => {
    setDraft({ ...meta, periods: meta.periods.map(p => ({ ...p })) });
    setAmtDrafts(meta.periods.map(p => p.amount === 0 ? '' : String(p.amount)));
    setUnsaved(false);
  };

  const periodTotal = draft.periods.reduce((s, p) => s + p.amount, 0);
  const diff = Math.round((total - periodTotal) * 100) / 100;

  return (
    <tr style={{ background: '#F0F9FF' }}>
      <td colSpan={colSpan} style={{ padding: 0, borderBottom: '2px solid #BAE6FD' }}>
        <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Calendar size={12} style={{ color: '#2861BB' }} />
              <span style={{ fontSize: 11, fontWeight: 700, color: '#1A3673', letterSpacing: 0.3 }}>Cost Distribution</span>
              {unsaved && (
                <span style={{ fontSize: 9, fontWeight: 700, color: '#D97706', background: '#FEF3C7', border: '1px solid #FDE68A', borderRadius: 999, padding: '1px 7px', letterSpacing: 0.3 }}>
                  UNSAVED
                </span>
              )}
            </div>
            {unsaved && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <button onClick={handleDiscard} disabled={saving}
                  style={{ fontSize: 10, fontWeight: 600, padding: '3px 12px', borderRadius: 6, cursor: 'pointer', border: '1px solid #D1D5DB', background: '#fff', color: '#6B7280' }}>
                  Discard
                </button>
                <button onClick={handleSave} disabled={saving}
                  style={{ fontSize: 10, fontWeight: 700, padding: '3px 14px', borderRadius: 6, cursor: saving ? 'wait' : 'pointer', opacity: saving ? 0.7 : 1, border: '1px solid #1A3673', background: '#1A3673', color: '#fff' }}>
                  {saving ? 'Saving…' : 'Save Changes'}
                </button>
              </div>
            )}
          </div>

          <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* ── Controls row ── */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8 }}>Cost Type</span>
              <select className="form-select text-xs" value={draft.costType}
                onChange={e => patch({ costType: e.target.value })}>
                <option>One-time</option><option>Recurring</option>
              </select>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8 }}>From</span>
              <input type="date" className="form-select text-xs w-36" value={draft.timeframeStart}
                min={range?.min} max={range?.max}
                title={range ? `Allowed: ${fmtDate(range.min)} – ${fmtDate(range.max)}` : undefined}
                onChange={e => patch({ timeframeStart: e.target.value })} />
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600 }}>To</span>
              <input type="date" className="form-select text-xs w-36" value={draft.timeframeEnd}
                min={(draft.timeframeStart && (!range?.min || draft.timeframeStart > range.min) ? draft.timeframeStart : range?.min) || undefined}
                max={range?.max}
                title={range ? `Allowed: ${fmtDate(range.min)} – ${fmtDate(range.max)}` : undefined}
                onChange={e => patch({ timeframeEnd: e.target.value })} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8 }}>Method</span>
              <button onClick={() => patch({ distribution: 'equal' })}
                style={{ fontSize: 10, fontWeight: 600, padding: '3px 12px', borderRadius: 6, cursor: 'pointer', border: `1px solid ${draft.distribution === 'equal' ? '#1A3673' : '#D1D5DB'}`, background: draft.distribution === 'equal' ? '#1A3673' : '#fff', color: draft.distribution === 'equal' ? '#fff' : '#6B7280' }}>
                Spread Equally
              </button>
              <button onClick={() => patch({ distribution: 'manual' })}
                style={{ fontSize: 10, fontWeight: 600, padding: '3px 12px', borderRadius: 6, cursor: 'pointer', border: `1px solid ${draft.distribution === 'manual' ? '#1A3673' : '#D1D5DB'}`, background: draft.distribution === 'manual' ? '#1A3673' : '#fff', color: draft.distribution === 'manual' ? '#fff' : '#6B7280' }}>
                Enter Manually
              </button>
            </div>
          </div>

          {/* ── Period grid ── */}
          {draft.periods.length === 0 ? (
            <p style={{ fontSize: 10, color: '#9CA3AF', fontStyle: 'italic', margin: 0 }}>
              Set a From and To date above to generate the distribution schedule.
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'flex-end', flexWrap: 'wrap', gap: 8 }}>
                {draft.periods.map((p, i) => (
                  <div key={p.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
                    <span style={{ fontSize: 9, color: '#6B7280', fontWeight: 600, whiteSpace: 'nowrap' }}>{fmtPeriod(p.label)}</span>
                    {draft.distribution === 'equal' ? (
                      <span style={{ fontSize: 10, fontFamily: 'monospace', color: '#1A3673', fontWeight: 700, background: '#DBEAFE', border: '1px solid #BFDBFE', borderRadius: 5, padding: '3px 8px', whiteSpace: 'nowrap', minWidth: 72, textAlign: 'center', display: 'block' }}>
                        ${p.amount.toLocaleString()}
                      </span>
                    ) : (
                      <input
                        type="number" min={0}
                        className="form-select text-xs text-right"
                        style={{ width: 88, fontFamily: 'monospace', background: '#fff', border: '1px solid #93C5FD' }}
                        value={amtDrafts[i] ?? ''}
                        placeholder="0.00"
                        onChange={e => handleAmtChange(i, e.target.value)}
                        onBlur={() => {
                          if (!amtDrafts[i]) {
                            const next = [...amtDrafts]; next[i] = '';
                            setAmtDrafts(next);
                          }
                        }}
                      />
                    )}
                  </div>
                ))}
              </div>

              {/* Allocation summary bar */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 6, fontSize: 10 }}>
                <span style={{ color: '#6B7280' }}>Allocated: <strong style={{ fontFamily: 'monospace', color: '#1A3673' }}>${periodTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong></span>
                <span style={{ color: '#CBD5E1' }}>|</span>
                <span style={{ color: '#6B7280' }}>Total: <strong style={{ fontFamily: 'monospace', color: '#1A3673' }}>${total.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong></span>
                <span style={{ color: '#CBD5E1' }}>|</span>
                {diff === 0 && draft.periods.length > 0 ? (
                  <span style={{ fontWeight: 700, color: '#16A34A' }}>✓ Fully allocated</span>
                ) : diff > 0 ? (
                  <span style={{ fontWeight: 700, color: '#DC2626' }}>${diff.toLocaleString('en-US', { minimumFractionDigits: 2 })} remaining</span>
                ) : (
                  <span style={{ fontWeight: 700, color: '#7C3AED' }}>${Math.abs(diff).toLocaleString('en-US', { minimumFractionDigits: 2 })} over budget</span>
                )}
              </div>
            </div>
          )}
          </fieldset>

        </div>
      </td>
    </tr>
  );
}

function coversheetPeriod(cvrsht_id) {
  const m = String(cvrsht_id || '').match(/(\d{4})(\d{2})-(\d{4})(\d{2})$/);
  if (!m) return null;
  const [, sy, sm, ey, em] = m;
  const lastDay = new Date(Number(ey), Number(em), 0).getDate();
  return { min: `${sy}-${sm}-01`, max: `${ey}-${em}-${String(lastDay).padStart(2, '0')}` };
}

function validatePeriod(range, start, end) {
  const s = toYmd(start), e = toYmd(end);
  if (range?.min && range?.max) {
    const outside = (d) => d && (d < range.min || d > range.max);
    if (outside(s) || outside(e)) {
      return `Please select dates between ${fmtDate(range.min)} and ${fmtDate(range.max)}.`;
    }
  }
  if (s && e && s > e) return 'Start date must be on or before the end date.';
  return null;
}

// ── Period (periodStart / periodEnd) cells ───────────────────────────────────
const fmtDate = (d) => {
  if (!d) return '';
  const [y, m, day] = String(d).slice(0, 10).split('-');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return y && m && day ? `${months[parseInt(m) - 1]} ${day}, ${y}` : String(d);
};

function PeriodCells({ start, end }) {
  const cell = (v) => (
    <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>
      {v ? fmtDate(v) : <span style={{ color: '#d1d5db' }}>—</span>}
    </td>
  );
  return <>{cell(start)}{cell(end)}</>;
}

function PeriodInputs({ start, end, onChange, range }) {
  const title = range ? `Allowed: ${fmtDate(range.min)} – ${fmtDate(range.max)}` : undefined;
  return (
    <>
      <td className="table-td"><input type="date" className="form-select text-xs w-32" title={title} value={start || ''}
        min={range?.min} max={range?.max} onChange={e => onChange('periodStart', e.target.value)} /></td>
      <td className="table-td"><input type="date" className="form-select text-xs w-32" title={title} value={end || ''}
        min={(start && (!range?.min || start > range.min) ? start : range?.min) || undefined} max={range?.max}
        onChange={e => onChange('periodEnd', e.target.value)} /></td>
    </>
  );
}

function RowActions({ editing, expanded, deleting, readOnly = false, onEditRow, onDelete, onToggleDist }) {
  const iconBtn = { background: 'none', border: 'none', cursor: 'pointer', marginRight: 4 };
  return (
    <>
      {!readOnly && <>
      <button onClick={onEditRow} title="Edit" disabled={deleting}
        style={{ ...iconBtn, color: editing ? '#2861BB' : '#d1d5db' }}
        onMouseEnter={e => (e.currentTarget.style.color = '#2861BB')}
        onMouseLeave={e => (e.currentTarget.style.color = editing ? '#2861BB' : '#d1d5db')}>
        <Pencil size={12} />
      </button>
      <button onClick={onDelete} title="Delete" disabled={deleting}
        style={{ ...iconBtn, color: '#d1d5db', cursor: deleting ? 'wait' : 'pointer' }}
        onMouseEnter={e => (e.currentTarget.style.color = '#E3725F')}
        onMouseLeave={e => (e.currentTarget.style.color = '#d1d5db')}>
        {deleting ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
      </button>
      </>}
      <button onClick={onToggleDist} title="Cost distribution"
        style={{ color: expanded ? '#2861BB' : '#d1d5db', background: 'none', border: 'none', cursor: 'pointer' }}
        onMouseEnter={e => (e.currentTarget.style.color = '#2861BB')}
        onMouseLeave={e => (e.currentTarget.style.color = expanded ? '#2861BB' : '#d1d5db')}>
        <Calendar size={12} />
      </button>
    </>
  );
}

function SaveCancel({ saving, onSave, onCancel }) {
  return (
    <>
      <button onClick={onSave} disabled={saving}
        className="text-[10px] font-bold text-white bg-[#00BBBA] rounded px-2 py-0.5 mr-1 hover:bg-[#00a8a7] disabled:opacity-60 inline-flex items-center gap-1">
        {saving && <Loader2 size={10} className="animate-spin" />}{saving ? 'Saving…' : 'Save'}
      </button>
      <button onClick={onCancel} disabled={saving} className="text-[10px] font-medium text-gray-400 hover:text-gray-600">Cancel</button>
    </>
  );
}

function EditRowButtons({ onSave, onCancel }) {
  const [saving, setSaving] = useState(false);
  const save = async () => { setSaving(true); try { await onSave(); } finally { setSaving(false); } };
  return (
    <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
      <SaveCancel saving={saving} onSave={save} onCancel={onCancel} />
    </td>
  );
}

function CostPlanNumberCell({ value }) {
  return (
    <td className="table-td" title="Cost Plan Number cannot be changed" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>
      {value || '—'}
    </td>
  );
}

function LoeEditRow({ row, onSave, onCancel, range }) {
  const [d, setD] = useState(() => ({ ...row, costMeta: { ...row.costMeta } }));
  const set = (k, v) => setD(p => ({ ...p, [k]: v }));
  const setNum = (k, raw) => setD(p => {
    const next = { ...p, [k]: parseFloat(raw) || 0 };
    return { ...next, totalCost: next.estimate + next.opsMaintenanceCost };
  });
  return (
    <tr style={{ background: '#EFF6FF', borderBottom: '2px solid #93c5fd' }}>
      <CostPlanNumberCell value={d.costPlanNumber} />
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Sizing" value={d.sizing} onChange={e => set('sizing', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-16" placeholder="BDM" value={d.bdm} onChange={e => set('bdm', e.target.value)} /></td>
      <td className="table-td">
        <select className="form-select text-xs w-16" value={d.timber} onChange={e => set('timber', e.target.value)}>
          <option value="">—</option><option>Y</option><option>N</option>
        </select>
      </td>
      <td className="table-td"><input type="number" className="form-select text-xs w-24 text-right" placeholder="0" value={d.estimate || ''} onChange={e => setNum('estimate', e.target.value)} /></td>
      <td className="table-td"><input type="number" className="form-select text-xs w-28 text-right" placeholder="0" value={d.opsMaintenanceCost || ''} onChange={e => setNum('opsMaintenanceCost', e.target.value)} /></td>
      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>{d.totalCost > 0 ? `$${d.totalCost.toLocaleString()}` : '—'}</td>
      <td className="table-td">
        <select className="form-select text-xs w-24" value={d.costMeta.costType} onChange={e => setD(p => ({ ...p, costMeta: { ...p.costMeta, costType: e.target.value } }))}>
          <option>One-time</option><option>Recurring</option>
        </select>
      </td>
      <PeriodInputs start={d.periodStart} end={d.periodEnd} onChange={set} range={range} />
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Project #" value={d.projectNumber} onChange={e => set('projectNumber', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-36" placeholder="Notes" value={d.notes} onChange={e => set('notes', e.target.value)} /></td>
      <EditRowButtons onSave={() => onSave(d)} onCancel={onCancel} />
    </tr>
  );
}

function FteEditRow({ row, caOptions, onSave, onCancel, range }) {
  const [d, setD] = useState(() => ({ ...row, costMeta: { ...row.costMeta } }));
  const set = (k, v) => setD(p => ({ ...p, [k]: v }));
  return (
    <tr style={{ background: '#D9F5F5', borderBottom: '2px solid #66D6D6' }}>
      <CostPlanNumberCell value={d.costPlanNumber} />
      <td className="table-td"><input type="number" className="form-select text-xs w-16 text-center" placeholder="0" value={d.positions || ''} onChange={e => set('positions', parseInt(e.target.value) || 0)} /></td>
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Start Date" value={d.startDate} onChange={e => set('startDate', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-20" placeholder="Job Code" value={d.jobCode} onChange={e => set('jobCode', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-28" placeholder="Job Title" value={d.jobTitle} onChange={e => set('jobTitle', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-28" placeholder="Department" value={d.department} onChange={e => set('department', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Approved By" value={d.approvedBy} onChange={e => set('approvedBy', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Hiring Mgr" value={d.hiringManager} onChange={e => set('hiringManager', e.target.value)} /></td>
      <td className="table-td"><select className="form-select text-xs w-24" value={d.onshoreOffshore} onChange={e => set('onshoreOffshore', e.target.value)}><option value="">—</option><option>Onshore</option><option>Offshore</option></select></td>
      <td className="table-td"><select className="form-select text-xs w-20" value={d.cocNonCoc} onChange={e => set('cocNonCoc', e.target.value)}><option value="">—</option><option>CoC</option><option>Non-CoC</option></select></td>
      <td className="table-td"><select className="form-select text-xs w-24" value={d.caOnly} onChange={e => set('caOnly', e.target.value)}><option value="">—</option>{caOptions.map(o => <option key={o}>{o}</option>)}</select></td>
      <td className="table-td"><input type="number" className="form-select text-xs w-24 text-right" placeholder="Cost" value={d.cost || ''} onChange={e => set('cost', parseFloat(e.target.value) || 0)} /></td>
      <td className="table-td">
        <select className="form-select text-xs w-24" value={d.costMeta.costType} onChange={e => setD(p => ({ ...p, costMeta: { ...p.costMeta, costType: e.target.value } }))}>
          <option>One-time</option><option>Recurring</option>
        </select>
      </td>
      <PeriodInputs start={d.periodStart} end={d.periodEnd} onChange={set} range={range} />
      <td className="table-td"><input className="form-select text-xs w-36" placeholder="SNOW Desc" value={d.snowDescription} onChange={e => set('snowDescription', e.target.value)} /></td>
      <EditRowButtons onSave={() => onSave(d)} onCancel={onCancel} />
    </tr>
  );
}

function OtherEditRow({ row, onSave, onCancel, range }) {
  const [d, setD] = useState(() => ({ ...row, costMeta: { ...row.costMeta } }));
  const set = (k, v) => setD(p => ({ ...p, [k]: v }));
  const costTypes = ['One-time', 'Recurring', 'Capital', 'Operational'];
  return (
    <tr style={{ background: '#faf5ff', borderBottom: '2px solid #c4b5fd' }}>
      <CostPlanNumberCell value={d.costPlanNumber} />
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Category" value={d.category} onChange={e => set('category', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-40" placeholder="Description" value={d.description} onChange={e => set('description', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-32" placeholder="Vendor" value={d.vendor} onChange={e => set('vendor', e.target.value)} /></td>
      <td className="table-td">
        <select className="form-select text-xs w-28" value={d.costType} onChange={e => set('costType', e.target.value)}>
          {!costTypes.includes(d.costType) && <option value={d.costType}>{d.costType || '—'}</option>}
          {costTypes.map(o => <option key={o}>{o}</option>)}
        </select>
      </td>
      <PeriodInputs start={d.periodStart} end={d.periodEnd} onChange={set} range={range} />
      <td className="table-td"><input type="number" className="form-select text-xs w-28 text-right" placeholder="0" value={d.amount || ''} onChange={e => set('amount', parseFloat(e.target.value) || 0)} /></td>
      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Timeline" value={d.timeline} onChange={e => set('timeline', e.target.value)} /></td>
      <td className="table-td"><input className="form-select text-xs w-36" placeholder="Notes" value={d.notes} onChange={e => set('notes', e.target.value)} /></td>
      <EditRowButtons onSave={() => onSave(d)} onCancel={onCancel} />
    </tr>
  );
}


export default function CostPlanTab({ coversheet, onEdit }) {
  const { can } = useAuth();
  const { showToast } = useToast();
  const canEdit = can('edit_cost_plan');

  const cvrsht_id = coversheet?.id || coversheet?.cvrsht_id;

  const [loeRows, setLoeRows] = useState([]);
  const [itRows, setItRows] = useState([]);
  const [fteRows, setFteRows] = useState([]);
  const [fteGroups, setFteGroups] = useState([]);
  const [costSections, setCostSections] = useState({ it: null, fte: null, vnd: null, oth: null });
  const [costGroups, setCostGroups] = useState({ loe: null, itOther: [], vnd: null, oth: null });
  const [costsLoading, setCostsLoading] = useState(false);
  const [costsError, setCostsError] = useState(null);

  const loadCosts = useCallback(async (signal = { cancelled: false }) => {
    if (!cvrsht_id) return;
    setCostsLoading(true);
    setCostsError(null);
    try {
      const data = await costPlanApi.getCosts(cvrsht_id);
      if (signal.cancelled) return;
      const m = mapCostsResponse(data);
      setCostSections(m.sections);
      setCostGroups(m.groups);
      setPlanPeriods(m.planPeriods);
      setLoeRows(m.loeRows);
      setItRows(m.itRows);
      setVendorPlans(m.vendorPlans);
      setFeeDrafts({});
      setFteGroups(m.fteGroups);
      setFteRows(m.fteRows);
      setOtherRows(m.otherRows);
      setExpandedRows(new Set());
      setEditingRow(null);
    } catch (err) {
      if (signal.cancelled) return;
      console.error('[CostPlanTab] Failed to load costs:', err);
      setCostsError(err.message || 'Failed to load cost details.');
      showToast(`Failed to load cost details: ${err.message}`, 'error');
    } finally {
      if (!signal.cancelled) setCostsLoading(false);
    }
  }, [cvrsht_id, showToast]);

  useEffect(() => {
    const signal = { cancelled: false };
    loadCosts(signal);
    return () => { signal.cancelled = true; };
  }, [loadCosts]);

  const [costPlans, setCostPlans] = useState([]);
  const [planPeriods, setPlanPeriods] = useState({}); 
  const [costPlansLoading, setCostPlansLoading] = useState(false);
  const [costPlansError, setCostPlansError] = useState(null);
  useEffect(() => {
    if (!cvrsht_id) return;
    let cancelled = false;
    setCostPlansLoading(true);
    setCostPlansError(null);
    costPlanApi.getCostPlanNumbers(cvrsht_id)
      .then(plans => {
        if (cancelled) return;
        const seen = new Set();
        setCostPlans(plans
          .filter(p => p.u_number && !p.deld_dtm && !seen.has(p.u_number) && seen.add(p.u_number))
          .sort((a, b) => a.u_number.localeCompare(b.u_number)));
      })
      .catch(err => {
        if (cancelled) return;
        console.error('[CostPlanTab] Failed to load cost plans:', err);
        setCostPlansError(err.message || 'Failed to load cost plans.');
      })
      .finally(() => { if (!cancelled) setCostPlansLoading(false); });
    return () => { cancelled = true; };
  }, [cvrsht_id]);
  const findCostPlan = (num) => costPlans.find(p => p.u_number === num) || null;

  const rangeFor = (cpn) => {
    if (cpn && planPeriods[cpn]) return planPeriods[cpn];
    const plan = cpn ? findCostPlan(cpn) : null;
    const min = toYmd(plan?.start_fiscal_period_start_date_time), max = toYmd(plan?.end_fiscal_period_end_date_time);
    if (min && max) return { min, max };
    return coversheetPeriod(cvrsht_id);
  };
  const rangeForRow = (row) => (row?.periodMin && row?.periodMax ? { min: row.periodMin, max: row.periodMax } : rangeFor(row?.costPlanNumber));
  const checkPeriod = (range, start, end) => {
    const err = validatePeriod(range, start, end);
    if (err) showToast(err, 'warning');
    return !err;
  };

  const [addSaving, setAddSaving] = useState(null);
  const submitAdd = async ({ key, groupId, sectionId, draft, rowData, mapRow, setRows, onDone }) => {
    if (!draft.costPlanNumber) { showToast('Please select a Cost Plan Number.', 'warning'); return; }
    if (!groupId) { showToast('Cannot add row: cost group is not available.', 'error'); return; }
    const cd0 = rowData.costDistribution || {};
    if (!checkPeriod(draft.costPlanNumber, cd0.from, cd0.to)) return; // nothing is added
    setAddSaving(key);
    try {
      const res = await costPlanApi.addRow(cvrsht_id, groupId, rowData);
      let created = extractCreatedRow(res);
      if (!created) {
        const data = await costPlanApi.getCosts(cvrsht_id);
        const group = (data?.sections || []).flatMap(s => s.groups || []).find(g => g.groupId === groupId);
        const kind = key === 'loe' ? 'loe' : key === 'oth' ? 'oth' : 'fte';
        const known = new Set(rowsOf(kind).map(r => r.rowId).filter(Boolean));
        const rank = (r) => Number(r.costPlanOrderNumber ?? r.sortOrder ?? 0);
        created = (group?.rows || [])
          .filter(r => (r.costPlanNumber ?? r.rowData?.costPlanNumber) === rowData.costPlanNumber && !known.has(r.rowId))
          .sort((a, b) => rank(b) - rank(a))[0] || null;
      }
      const row = created
        ? mapRow({ groupId, ...created, rowData: { ...rowData, ...(created.rowData || {}) } }, sectionId)
        : mapRow({ rowId: null, groupId, rowData }, sectionId);
      if (!row.id) row.id = `${key}${Date.now()}`;
      const cd = rowData.costDistribution || {};
      const shown = (!row.periodStart && !row.periodEnd && (cd.from || cd.to))
        ? withDisplayDates(row, cd.from, cd.to, uiTotal(key === 'loe' ? 'loe' : key === 'oth' ? 'oth' : 'fte', row))
        : row;
      setRows(p => [...p, p.some(x => x.id === shown.id) ? { ...shown, id: `${shown.id}#${Date.now()}` } : shown]);
      onDone();
      showToast(`"${rowData.costPlanNumber}" added`, 'success');
    } catch (err) {
      console.error('[CostPlanTab] Add failed:', err);
      showToast(`Failed to add "${rowData.costPlanNumber}": ${err.message}`, 'error');
    } finally {
      setAddSaving(null);
    }
  };

  // ── Edit (inline) ────────────────────────────────────────────────────────────
  const [editingRow, setEditingRow] = useState(null);
  const startEdit = (id) => setEditingRow(cur => (cur === id ? null : id));
  const saveLoeEdit = (d) => saveRowEdit('loe', d);
  const saveFteEdit = (d) => saveRowEdit('fte', d);
  const saveOthEdit = (d) => saveRowEdit('oth', d);

  const rowsOf    = (kind) => (kind === 'loe' ? loeRows : kind === 'fte' ? fteRows : otherRows);
  const setRowsOf = (kind) => (kind === 'loe' ? setLoeRows : kind === 'fte' ? setFteRows : setOtherRows);
  const rowIdFor = (row) => {
    const cpn = row.costPlanNumber;
    const order = row.costPlanOrderNumber;
    return cpn && order != null && order !== '' ? `${cpn}::${order}` : row.rowId;
  };

  const putRow = async (row, patch, totalCost, dates = null) => {
    const rowData = mergeRowData(row.apiRow?.rowData || {}, patch, dates);
    const payload = { rowData, totalCost, sortOrder: row.apiRow?.sortOrder ?? 0 };
    const res = await costPlanApi.updateRow(cvrsht_id, row.groupId, rowIdFor(row), payload);
    const returned = extractCreatedRow(res);
    return {
      rowId: returned?.rowId || row.rowId, groupId: returned?.groupId || row.groupId,
      costPlanNumber:      returned?.costPlanNumber ?? row.costPlanNumber,
      costPlanOrderNumber: returned?.costPlanOrderNumber ?? row.costPlanOrderNumber,
      readOnly:            returned?.readOnly ?? row.readOnly,
      totalCost: returned?.totalCost ?? payload.totalCost, sortOrder: returned?.sortOrder ?? payload.sortOrder,
      rowData: { ...rowData, ...(returned?.rowData || {}) },
      display: dates ? {
        start: returned?.rowData?.periodStart ?? dates.from,
        end:   returned?.rowData?.periodEnd   ?? dates.to,
      } : null,
    };
  };

  const saveRowEdit = async (kind, draft) => {
    const row = rowsOf(kind).find(r => r.id === draft.id);
    if (!row) return;
    const patch = buildEditPatch(kind, row, draft);
    const dates = dateChange(row.periodStart, row.periodEnd, draft.periodStart, draft.periodEnd);
    if (!Object.keys(patch).length && !dates) { setEditingRow(null); return; }
    if (dates && !checkPeriod(row.costPlanNumber, draft.periodStart, draft.periodEnd)) return; // edit row stays open
    try {
      const saved = await putRow(row, patch, uiTotal(kind, draft), dates);
      let fresh = MAPPERS[kind](saved, row.sectionId);
      if (saved.display) fresh = withDisplayDates(fresh, saved.display.start, saved.display.end, uiTotal(kind, fresh));
      fresh.id = row.id; 
      for (const k of ['costPlanDescription', 'snowDescription', 'description']) {
        if (k in row && !fresh[k] && row[k]) fresh[k] = row[k]; 
      }
      if (row.costMeta?.distribution === 'manual') {
        const { costType, timeframeStart, timeframeEnd } = fresh.costMeta;
        fresh.costMeta = { ...row.costMeta, costType, timeframeStart, timeframeEnd,
          periods: buildPeriods(timeframeStart, timeframeEnd, uiTotal(kind, fresh), 'manual', row.costMeta.periods) };
      }
      setRowsOf(kind)(p => p.map(r => r.id === row.id ? fresh : r));
      setEditingRow(null);
      onEdit();
      showToast(`"${row.costPlanNumber}" updated`, 'success');
    } catch (err) {
      console.error('[CostPlanTab] Update failed:', err);
      showToast(`Failed to update "${row.costPlanNumber}": ${err.message}`, 'error');
    }
  };

  const saveDistribution = async (kind, id, m) => {
    const row = rowsOf(kind).find(r => r.id === id);
    if (!row) return false;
    const dates = dateChange(row.costMeta.timeframeStart, row.costMeta.timeframeEnd, m.timeframeStart, m.timeframeEnd);
    if (dates && !checkPeriod(row.costPlanNumber, m.timeframeStart, m.timeframeEnd)) return false; 
    if (!dates) {
      setRowsOf(kind)(p => p.map(r => r.id === id ? { ...r, costMeta: m } : r));
      onEdit();
      return true;
    }
    try {
      const saved = await putRow(row, {}, row.apiRow?.totalCost ?? uiTotal(kind, row), dates);
      setRowsOf(kind)(p => p.map(r => r.id === id ? {
        ...r, costMeta: m,
        periodStart: toYmd(saved.display.start), periodEnd: toYmd(saved.display.end),
        apiRow: { rowData: saved.rowData, totalCost: saved.totalCost, sortOrder: saved.sortOrder },
      } : r));
      onEdit();
      showToast(`Dates updated for "${row.costPlanNumber}"`, 'success');
      return true;
    } catch (err) {
      console.error('[CostPlanTab] Date update failed:', err);
      showToast(`Failed to update dates for "${row.costPlanNumber}": ${err.message}`, 'error');
      return false;
    }
  };

  const [confirmDelete, setConfirmDelete] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const removeRowLocally = (kind, id) => {
    const setter = kind === 'loe' ? setLoeRows : kind === 'fte' ? setFteRows : setOtherRows;
    setter(p => p.filter(x => x.id !== id));
    setExpandedRows(prev => { const n = new Set(prev); n.delete(id); return n; });
    setEditingRow(cur => (cur === id ? null : cur));
  };
  const handleConfirmDelete = async () => {
    if (!confirmDelete) return;
    const { row, kind, label } = confirmDelete;
    setConfirmDelete(null);
    if (!row.rowId) { removeRowLocally(kind, row.id); onEdit(); return; }
    setDeletingId(row.id);
    try {
      await costPlanApi.deleteRow(cvrsht_id, row.groupId, row.rowId);
      removeRowLocally(kind, row.id);
      showToast(`"${label}" deleted`, 'success');
    } catch (err) {
      console.error('[CostPlanTab] Delete failed:', err);
      showToast(`Failed to delete "${label}": ${err.message}`, 'error');
    } finally {
      setDeletingId(null);
    }
  };

  // LOE add state
  const [addingLoe, setAddingLoe] = useState(false);
  const BLANK_LOE = { costPlanNumber: '', sizing: '', bdm: '', timber: '', estimate: 0, opsMaintenanceCost: 0, totalCost: 0, costType: 'One-time', projectNumber: '', notes: '', periodStart: '', periodEnd: '' };
  const [newLoe, setNewLoe] = useState(BLANK_LOE);

  // FTE add state
  const [addingFteSection, setAddingFteSection] = useState(null);
  const [newFte, setNewFte] = useState(BLANK_FTE('G&A'));

  const BLANK_LOE_F = { sizing: '', timber: '', costPlanNumber: '' };
  const BLANK_FTE_F = { onshoreOffshore: '', cocNonCoc: '', caOnly: '', costPlanNumber: '' };
  const BLANK_OTH_F = { category: '', costType: '', costPlanNumber: '' };
  const BLANK_VND_F = { vendor: '' };

  const [cpSearch,     setCpSearch]     = useState({ loe: '', fte: '', oth: '', vnd: '' });
  const [cpFilterOpen, setCpFilterOpen] = useState({ loe: false, fte: false, oth: false, vnd: false });
  const [cpPending,    setCpPending]    = useState({ loe: { ...BLANK_LOE_F }, fte: { ...BLANK_FTE_F }, oth: { ...BLANK_OTH_F }, vnd: { ...BLANK_VND_F } });
  const [cpActive,     setCpActive]     = useState({ loe: { ...BLANK_LOE_F }, fte: { ...BLANK_FTE_F }, oth: { ...BLANK_OTH_F }, vnd: { ...BLANK_VND_F } });

  const cpOpenFilter  = (sec) => { setCpPending(p => ({ ...p, [sec]: { ...cpActive[sec] } })); setCpFilterOpen(p => ({ ...p, [sec]: true })); };
  const cpCloseFilter = (sec) => { setCpPending(p => ({ ...p, [sec]: { ...cpActive[sec] } })); setCpFilterOpen(p => ({ ...p, [sec]: false })); };
  const cpApply       = (sec) => { setCpActive(p => ({ ...p, [sec]: { ...cpPending[sec] } })); setCpFilterOpen(p => ({ ...p, [sec]: false })); };
  const cpClearAll    = (sec, blank) => { setCpActive(p => ({ ...p, [sec]: { ...blank } })); setCpPending(p => ({ ...p, [sec]: { ...blank } })); setCpFilterOpen(p => ({ ...p, [sec]: false })); setCpSearch(p => ({ ...p, [sec]: '' })); };
  const cpPatch       = (sec, field, val) => setCpPending(p => ({ ...p, [sec]: { ...p[sec], [field]: val } }));
  const cpActiveCount = (sec) => Object.values(cpActive[sec]).filter(v => v !== '').length;

  // Others state
  const [otherRows, setOtherRows] = useState([]);
  const [newOther, setNewOther] = useState({ costPlanNumber: '', category: '', description: '', vendor: '', costType: 'One-time', amount: 0, timeline: '', notes: '', periodStart: '', periodEnd: '', costMeta: { ...DEFAULT_COST_META } });
  const [addingOther, setAddingOther] = useState(false);

  const [vendorPlans, setVendorPlans] = useState([]);
  const [feeDrafts, setFeeDrafts] = useState({});
  const [vendorPreview, setVendorPreview] = useState({});
  const [defaultFeePct, setDefaultFeePct] = useState({});
  const previewSeq = useRef({});     
  const fetchVendorPreview = useCallback(async (plan, pct) => {
    if (!cvrsht_id || !plan?.costPlanNumber) return;
    const seq = (previewSeq.current[plan.id] || 0) + 1;
    previewSeq.current[plan.id] = seq;
    setVendorPreview(v => ({ ...v, [plan.id]: { ...(v[plan.id] || {}), loading: true, error: null } }));
    try {
      const data = await costPlanApi.getVendorPreview(cvrsht_id, plan.costPlanNumber, pct ?? undefined);
      if (previewSeq.current[plan.id] !== seq) return;
      setVendorPreview(v => ({ ...v, [plan.id]: { loading: false, error: null, data } }));
      if (pct == null && data?.vendorFeePct != null) setDefaultFeePct(d => ({ ...d, [plan.id]: data.vendorFeePct }));
    } catch (err) {
      if (previewSeq.current[plan.id] !== seq) return;
      console.error('[CostPlanTab] Vendor preview failed:', plan.costPlanNumber, err);
      setVendorPreview(v => ({ ...v, [plan.id]: { ...(v[plan.id] || {}), loading: false, error: err.message || 'Preview failed' } }));
    }
  }, [cvrsht_id]);
  const vendorPlanKey = vendorPlans.map(p => `${p.id}|${p.costPlanNumber}`).join(',');
  useEffect(() => {
    vendorPlans.forEach(p => fetchVendorPreview(p, p.vendorFeePct));
  }, [vendorPlanKey, fetchVendorPreview]);

  const feeDraftOf = (p) => feeDrafts[p.id]
    ?? (p.vendorFeePct != null ? String(p.vendorFeePct)
      : vendorPreview[p.id]?.data?.vendorFeePct != null ? String(vendorPreview[p.id].data.vendorFeePct) : '');
  const handleFeeChange = (id, raw) => {
    setFeeDrafts(d => ({ ...d, [id]: raw }));
    const { value, error } = parseFeePct(raw);
    if (error) return;
    setVendorPlans(ps => ps.map(p => p.id === id ? { ...p, vendorFeePct: value } : p));
    onEdit();
  };

  const [vendorSaving, setVendorSaving] = useState(null); 
  const vendorBaselinePct = (p) => p.savedFeePct ?? defaultFeePct[p.id] ?? null;
  const hasUnsavedFee = (p) => {
    if (feeDrafts[p.id] === undefined) return false;
    const { value, error } = parseFeePct(feeDrafts[p.id]);
    return !error && value != null && value !== vendorBaselinePct(p);
  };
  const unsavedVendorPlans = vendorPlans.filter(hasUnsavedFee);

  const saveVendorPlan = async (plan) => {
    const { value: pct, error } = parseFeePct(feeDraftOf(plan));
    if (error || pct == null) { showToast(error || `Enter a Vendor Fee % for "${plan.costPlanNumber}".`, 'warning'); return false; }
    const costPlanOrderNumber = vendorPreview[plan.id]?.data?.costPlanOrderNumber ?? plan.costPlanOrderNumber ?? null;
    if (costPlanOrderNumber == null || costPlanOrderNumber === '') {
      showToast(`Cannot save "${plan.costPlanNumber}": the vendor preview did not return a Cost Plan Order Number.`, 'error');
      return false;
    }
    const rowId = `${plan.costPlanNumber}::${costPlanOrderNumber}`;
    try {
      const groupId = plan.groupId || costGroups.vnd?.groupId || 'VENDOR_COST_PLANS';
      const payload = {
        rowData: {
          costPlanNumber: plan.costPlanNumber,
          costPlanOrderNumber,
          vendorFeePct: pct,
        },
      };
      const res = await costPlanApi.updateRow(cvrsht_id, groupId, rowId, payload);
      const returned = extractCreatedRow(res);
      const saved = {
        rowId: returned?.rowId ?? rowId,
        groupId: returned?.groupId ?? groupId,
        costPlanOrderNumber: returned?.costPlanOrderNumber ?? costPlanOrderNumber,
        totalCost: returned?.totalCost ?? null,
        sortOrder: returned?.sortOrder ?? null,
        rowData: { ...(plan.apiRow?.rowData || {}), ...payload.rowData, ...(returned?.rowData || {}) },
      };

      setVendorPlans(ps => ps.map(p => p.id === plan.id ? {
        ...p,
        rowId: saved.rowId ?? p.rowId, groupId: saved.groupId ?? p.groupId,
        costPlanOrderNumber: saved.costPlanOrderNumber ?? p.costPlanOrderNumber ?? null,
        vendorFeePct: pct, savedFeePct: pct,
        apiRow: { rowData: saved.rowData, totalCost: saved.totalCost ?? p.apiRow?.totalCost ?? null, sortOrder: saved.sortOrder ?? p.apiRow?.sortOrder ?? null },
      } : p));
      setFeeDrafts(d => { const n = { ...d }; delete n[plan.id]; return n; });
      fetchVendorPreview(plan, pct);
      return true;
    } catch (err) {
      console.error('[CostPlanTab] Vendor fee save failed:', plan.costPlanNumber, err);
      showToast(`Failed to save Vendor Fee for "${plan.costPlanNumber}": ${err.message}`, 'error');
      return false;
    }
  };

  const saveOneVendor = async (plan) => {
    setVendorSaving(plan.id);
    const ok = await saveVendorPlan(plan);
    setVendorSaving(null);
    if (ok) { showToast(`Vendor Fee saved for "${plan.costPlanNumber}"`, 'success'); onEdit(); }
  };
  const saveAllVendors = async () => {
    const plans = vendorPlans.filter(hasUnsavedFee);
    if (!plans.length) return;
    setVendorSaving('all');
    let ok = 0;
    for (const p of plans) { if (await saveVendorPlan(p)) ok++; }
    setVendorSaving(null);
    if (ok) { showToast(`Vendor Fee saved for ${ok} cost plan${ok !== 1 ? 's' : ''}`, 'success'); onEdit(); }
  };

  const [expandedRows, setExpandedRows] = useState(new Set());
  const toggleExpand = useCallback((id) => setExpandedRows(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  }), []);

  const saveLoeMeta = (id, m) => saveDistribution('loe', id, m);
  const saveFteMeta = (id, m) => saveDistribution('fte', id, m);
  const saveOthMeta = (id, m) => saveDistribution('oth', id, m);

  const applyFilter = (rows, sec, fields) => {
    const q = cpSearch[sec].trim().toLowerCase();
    const act = cpActive[sec];
    return rows.filter(r => {
      const matchSearch = !q || fields.some(f => String(r[f] ?? '').toLowerCase().includes(q));
      const matchFilters = Object.entries(act).every(([k, v]) => !v || String(r[k] ?? '') === v);
      return matchSearch && matchFilters;
    });
  };

  const filteredLoe = applyFilter(loeRows,    'loe', ['costPlanNumber', 'sizing', 'bdm', 'notes', 'projectNumber']);
  const filteredOth = applyFilter(otherRows,  'oth', ['costPlanNumber', 'category', 'description', 'vendor', 'costType', 'notes']);

  // ── Toolbar helper ────────────────────────────────────────────────────────────
  const SectionToolbar = ({ sec, placeholder }) => {
    const srch = cpSearch[sec];
    const cnt  = cpActiveCount(sec);
    return (
      <div style={{ margin:'0 0 0 0', padding:'8px 16px', background:'#fafafa', borderBottom:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ position:'relative', flex:'0 1 300px' }}>
            <Search size={13} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
            <input type="text" value={srch}
              onChange={e => setCpSearch(p => ({ ...p, [sec]: e.target.value }))}
              placeholder={placeholder}
              style={{ width:'100%', paddingLeft:28, paddingRight: srch ? 26 : 10, paddingTop:5, paddingBottom:5, fontSize:12, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
              onFocus={e => e.target.style.borderColor='#1A3673'}
              onBlur={e => e.target.style.borderColor='#d1d5db'} />
            {srch && (
              <button onClick={() => setCpSearch(p => ({ ...p, [sec]: '' }))}
                style={{ position:'absolute', right:7, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                <X size={12} />
              </button>
            )}
          </div>
          <button onClick={() => cpOpenFilter(sec)}
            style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'5px 12px', cursor:'pointer', position:'relative' }}>
            <Filter size={12} />
            {cnt > 0 && (
              <span style={{ position:'absolute', top:-5, right:-5, background:'#E3725F', color:'#fff', fontSize:9, fontWeight:700, borderRadius:999, padding:'2px 6px', minWidth:18, textAlign:'center' }}>{cnt}</span>
            )}
          </button>
        </div>
        {(cnt > 0 || srch) && (
          <button onClick={() => cpClearAll(sec, sec === 'loe' ? BLANK_LOE_F : sec === 'fte' ? BLANK_FTE_F : sec === 'oth' ? BLANK_OTH_F : BLANK_VND_F)}
            style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'4px 10px', cursor:'pointer' }}>
            <X size={10} /> Clear All
          </button>
        )}
      </div>
    );
  };

  const itTotal     = loeRows.reduce((s, r) => s + r.totalCost, 0) + itRows.reduce((s, r) => s + r.totalCost, 0);
  const fteTotal    = fteRows.reduce((s, r) => s + r.cost, 0);
  const othersTotal = otherRows.reduce((s, r) => s + r.amount, 0);

  const hasIt  = !!costSections.it  || loeRows.length > 0 || itRows.length > 0;
  const hasFte = !!costSections.fte || fteRows.length > 0;
  const hasOth = !!costSections.oth || otherRows.length > 0;
  const hasVnd = !!costSections.vnd || vendorPlans.length > 0;

  const caOptions = [...new Set(['CA Only', 'Non-CA', ...fteRows.map(r => r.caOnly).filter(Boolean)])];

  const cpSelectProps = { costPlans, loading: costPlansLoading, error: costPlansError };

  const saveNewLoe = () => submitAdd({
    key: 'loe', groupId: costGroups.loe?.groupId || LOE_GROUP_ID, sectionId: SECTION_IDS.it, draft: newLoe,
    rowData: buildLoeRowData(newLoe, findCostPlan(newLoe.costPlanNumber), coversheet?.cin),
    mapRow: mapLoeRow, setRows: setLoeRows,
    onDone: () => { setNewLoe(BLANK_LOE); setAddingLoe(false); onEdit(); },
  });
  const saveNewFte = (section) => submitAdd({
    key: section, groupId: section, sectionId: SECTION_IDS.fte, draft: newFte,
    rowData: buildFteRowData(newFte, findCostPlan(newFte.costPlanNumber)),
    mapRow: mapFteRow, setRows: setFteRows,
    onDone: () => { setAddingFteSection(null); onEdit(); },
  });
  const saveNewOther = () => submitAdd({
    key: 'oth', groupId: costGroups.oth?.groupId || 'OTHER_COSTS', sectionId: SECTION_IDS.oth, draft: newOther,
    rowData: buildOtherRowData(newOther, findCostPlan(newOther.costPlanNumber)),
    mapRow: mapOtherRow, setRows: setOtherRows,
    onDone: () => {
      setNewOther({ costPlanNumber: '', category: '', description: '', vendor: '', costType: 'One-time', amount: 0, timeline: '', notes: '', periodStart: '', periodEnd: '', costMeta: { ...DEFAULT_COST_META } });
      setAddingOther(false); onEdit();
    },
  });
  const pickPlan = (setter, descField) => (num) => {
    const plan = findCostPlan(num);
    const start = toYmd(plan?.start_fiscal_period_start_date_time) || planPeriods[num]?.min || '';
    const end   = toYmd(plan?.end_fiscal_period_end_date_time)     || planPeriods[num]?.max || '';
    if (num && (!start || !end)) {
      console.warn('[CostPlanTab] No start/end date for cost plan', num, {
        start_fiscal_period_start_date_time: plan?.start_fiscal_period_start_date_time,
        end_fiscal_period_end_date_time: plan?.end_fiscal_period_end_date_time,
      });
    }
    setter(p => ({
      ...p, costPlanNumber: num,
      ...(descField && !p[descField] && plan?.u_short_description ? { [descField]: plan.u_short_description } : {}),
      periodStart: start,
      periodEnd:   end,
    }));
  };

  const vendorPlansView = vendorPlans.map(p => {
    const previewDesc = vendorPreview[p.id]?.data?.costPlanDescription;
    return { ...p, vendorName: p.vendor || '', vendor: previewDesc || p.vendor || '' };
  });
  const filteredVendorPlans = applyFilter(vendorPlansView, 'vnd', ['vendor', 'vendorName', 'costPlanNumber', 'description']);

  const vendorGroups = [...new Set(filteredVendorPlans.map(p => p.vendor))].map(vendor => ({
    vendor,
    plans: filteredVendorPlans.filter(p => p.vendor === vendor).map(p => {
      const { value: pct, error } = parseFeePct(feeDraftOf(p));
      const pv = vendorPreview[p.id] || {};
      const preview = pv.data;
      if (preview) {
      //   const months = (preview.months || []).map(m => ({ month: m, amount: num(preview.scaledSavings?.[m]) }));
      //   const fees = Object.fromEntries((preview.months || []).map(m => [m, preview.vendorFee?.[m] == null ? null : num(preview.vendorFee[m])]));
      //   return {
      //     plan: p, pct: error ? null : pct, error, months,
      //     feeFor: (mo) => (mo in fees ? fees[mo] : null),
      //     totalActual: preview.scaledSavingsTotal != null ? num(preview.scaledSavingsTotal) : months.reduce((s, m) => s + m.amount, 0),
      //     totalFee: preview.totalCost != null ? num(preview.totalCost) : Object.values(fees).reduce((s, f) => s + (f ?? 0), 0),
      //     loading: pv.loading, previewError: pv.error,
      //   };
      // }
      const months = (preview.months || []).map(m => ({ month: m, amount: num(preview.scaledSavings?.[m]) }));
      const typedPct = feeDrafts[p.id] !== undefined && !error && pct != null ? pct : null;
      const live = typedPct != null && typedPct !== preview.vendorFeePct;
      const fees = Object.fromEntries((preview.months || []).map(m => {
        if (live) return [m, preview.scaledSavings?.[m] == null ? null : calcVendorFee(num(preview.scaledSavings[m]), typedPct)];
        return [m, preview.vendorFee?.[m] == null ? null : num(preview.vendorFee[m])];
      }));
      const feeSum = round2(Object.values(fees).reduce((s, f) => s + (f ?? 0), 0));
      return {
        plan: p, pct: error ? null : pct, error, months,
        feeFor: (mo) => (mo in fees ? fees[mo] : null),
        totalActual: preview.scaledSavingsTotal != null ? num(preview.scaledSavingsTotal) : months.reduce((s, m) => s + m.amount, 0),
        totalFee: live ? feeSum : (preview.totalCost != null ? num(preview.totalCost) : feeSum),
        loading: pv.loading, previewError: pv.error,
      };
    }
      const months = [...p.monthlyScaledActuals].sort((a, b) => a.month.localeCompare(b.month));
      const totalActual = months.reduce((s, m) => s + m.amount, 0);
      const totalFee = pct == null || error ? null : months.reduce((s, m) => s + calcVendorFee(m.amount, pct), 0);
      const feeFor = (mo) => { const amt = months.find(m => m.month === mo)?.amount; return amt == null || pct == null || error ? null : calcVendorFee(amt, pct); };
      return { plan: p, pct: error ? null : pct, error, months, feeFor, totalActual, totalFee, loading: pv.loading, previewError: pv.error };
    }),
  }));
  const vendorActualTotal = vendorGroups.reduce((s, g) => s + g.plans.reduce((a, p) => a + p.totalActual, 0), 0);
  const vendorFeeTotal    = vendorGroups.reduce((s, g) => s + g.plans.reduce((a, p) => a + (p.totalFee ?? 0), 0), 0);
  const grandTotal        = itTotal + fteTotal + vendorFeeTotal + othersTotal;
  const vendorPlanRows = vendorGroups.flatMap(g => g.plans);
  const vendorMonths = [...new Set(vendorPlanRows.flatMap(p => p.months.map(m => m.month)))].sort();
  const savingsFor = (months, month) => months.find(m => m.month === month)?.amount;
  const vendorMonthSavings = vendorMonths.map(mo => vendorPlanRows.reduce((s, p) => s + (savingsFor(p.months, mo) ?? 0), 0));
  const vendorMonthFees    = vendorMonths.map(mo => vendorPlanRows.reduce((s, p) => s + (p.feeFor(mo) ?? 0), 0));
  const V_W    = { vendor: 120, plan: 170, fee: 124, measure: 130, total: 116 };
  const V_LEFT = { vendor: 0, plan: 120, fee: 290, measure: 414, total: 544 };
  const vStick = (col, bg, z = 5, edge = '#e5e7eb') => ({
    position: 'sticky', left: V_LEFT[col], zIndex: z, background: bg,
    width: V_W[col], minWidth: V_W[col], maxWidth: V_W[col],
    ...(col === 'total' ? { boxShadow: `inset -2px 0 0 ${edge}` } : {}),
  });
  const V_FOOT_BG = '#EEF1F6';
  return (
    <div className="space-y-4">

      {/* KPI strip */}
      <div className="grid grid-cols-5 gap-3">
        {([
          { id: 'it',  label: 'IT Expense',  value: fmtCost(itTotal),     icon: DollarSign,      color: 'text-[#2861BB]', bg: 'bg-[#E1EDFF]', ring: 'hover:border-[#2861BB]' },
          { id: 'fte', label: 'FTE Expense', value: fmtCost(fteTotal),    icon: Users,           color: 'text-[#00BBBA]', bg: 'bg-teal-50',   ring: 'hover:border-[#00BBBA]' },
          { id: 'vnd', label: 'Vendor Expenses', value: fmtCost(vendorFeeTotal), icon: Building2, color: 'text-[#1A3673]', bg: 'bg-slate-50', ring: 'hover:border-[#1A3673]' },
          { id: 'oth', label: 'Others',      value: fmtCost(othersTotal), icon: FileSpreadsheet, color: 'text-[#7c3aed]', bg: 'bg-purple-50', ring: 'hover:border-[#7c3aed]' },
        ]).map(k => {
          return (
            <button key={k.id} onClick={() => document.getElementById(`cost-${k.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
              title={`Jump to ${k.label}`}
              className={`${k.bg} rounded-lg border border-gray-100 p-3 text-left transition ${k.ring} hover:shadow-sm`}>
              <p className={`flex items-center gap-1 text-[10px] font-semibold mb-1 ${k.color}`}><k.icon size={11} /> {k.label}</p>
              <p className={`text-sm font-bold ${k.color}`}>{k.value}</p>
            </button>
          );
        })}
        <div className="bg-red-50 rounded-lg border border-gray-100 p-3">
          <p className="text-[10px] text-gray-500 mb-1">Total Costs</p>
          <p className="text-sm font-bold text-[#E3725F]">{fmtCost(grandTotal)}</p>
        </div>
      </div>

      {/* GET /costs status */}
      {costsLoading && (
        <div className="flex items-center gap-2 px-4 py-3 bg-[#E3F4FD] border border-[#C7EAFB] rounded-lg text-xs text-[#1A3673]">
          <Loader2 size={13} className="animate-spin" /> Loading cost details…
        </div>
      )}
      {!costsLoading && costsError && (
        <div className="flex items-center justify-between gap-2 px-4 py-3 bg-[#FBEAE7] border border-[#EEAA9F] rounded-lg text-xs text-gray-700">
          <div className="flex items-center gap-2">
            <AlertTriangle size={13} className="text-[#E3725F] flex-shrink-0" />
            <span>Could not load cost details: {costsError}</span>
          </div>
          <button onClick={() => loadCosts()} className="text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg px-2.5 py-1 hover:bg-[#2861BB] transition">Retry</button>
        </div>
      )}

      {/* ═══════════ 1. IT EXPENSE ═══════════ */}
      {hasIt && (
      <CostSection id="it"  title={costSections.it?.title || 'IT Expense'}  subtitle={costSections.it?.description || 'Level of Effort estimates and IT cost summary'} icon={DollarSign}      total={itTotal}     accent="#2861BB" tint="#F5F9FF">
          <div className="flex items-start gap-2 px-4 py-3 bg-[#E3F4FD] border border-[#C7EAFB] rounded-lg text-xs text-gray-600">
            <Info size={13} className="text-[#2861BB] flex-shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p>IT Costs listed in the <strong>CoCVR</strong> tab must link to totals on this tab.</p>
              <p>Include either a Level of Effort (LOE) estimate below or a summary of costs with a screenshot of the related costs.</p>
            </div>
          </div>

          {/* ── LOE Table ─────────────────────────────────────────────── */}
          <div className="card overflow-hidden">
            <div className="card-header">
              <div>
                <div className="card-title">{costGroups.loe?.groupName || 'LOE per your request'}</div>
                <p className="text-[10px] text-gray-400 mt-0.5">Level of Effort estimate detail</p>
              </div>
              {canEdit && (
                <button onClick={() => setAddingLoe(true)}
                  className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition">
                  <Plus size={11} /> Add Row
                </button>
              )}
            </div>

            <SectionToolbar sec="loe" placeholder="Search cost plan, sizing, notes…" />

            {/* LOE filter modal */}
            {cpFilterOpen.loe && (
              <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
                onClick={() => cpCloseFilter('loe')}>
                <div style={{ background:'#fff', borderRadius:12, maxWidth:600, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
                  onClick={e => e.stopPropagation()}>
                  <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — LOE</span></div>
                    <button onClick={() => cpCloseFilter('loe')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
                  </div>
                  <div style={{ padding:20, display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:14 }}>
                    <div>
                      <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                      <input type="text" value={cpPending.loe.costPlanNumber} onChange={e => cpPatch('loe','costPlanNumber',e.target.value)} placeholder="Search…"
                        style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }} />
                    </div>
                    <div>
                      <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Sizing</label>
                      <select value={cpPending.loe.sizing} onChange={e => cpPatch('loe','sizing',e.target.value)}
                        style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                        <option value="">All</option>
                        {[...new Set(loeRows.map(r => r.sizing).filter(Boolean))].sort().map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Timber</label>
                      <select value={cpPending.loe.timber} onChange={e => cpPatch('loe','timber',e.target.value)}
                        style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                        <option value="">All</option><option value="Y">Y</option><option value="N">N</option>
                      </select>
                    </div>
                  </div>
                  <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                    <button onClick={() => cpPatch('loe', 'sizing', '') || cpPatch('loe', 'timber', '') || cpPatch('loe', 'costPlanNumber', '') || setCpPending(p => ({ ...p, loe: { ...BLANK_LOE_F } }))}
                      style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                    <div style={{ display:'flex', gap:8 }}>
                      <button onClick={() => cpCloseFilter('loe')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                      <button onClick={() => cpApply('loe')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div style={{ overflowX: 'auto' }}>
              <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
                <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                  <tr style={{ background: '#1A3673', height: 32 }}>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Number</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Sizing</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>BDM</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Timber</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Estimate</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Ops, Maintenance &amp; Support</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Total Cost</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Type</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Start Date</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>End Date</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Project #</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Notes</th>
                    <th style={{ padding: '0 10px', width: 20 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLoe.length === 0 && !addingLoe ? (
                    <tr><td colSpan={13} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No LOE rows match the current filters. <button onClick={() => cpClearAll('loe', BLANK_LOE_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                  ) : filteredLoe.map((r, i) => [
                    editingRow === r.id ? (
                      <LoeEditRow key={`${r.id}-edit`} row={r} range={rangeFor(r.costPlanNumber)} onSave={saveLoeEdit} onCancel={() => setEditingRow(null)} />
                    ) :
                    <tr key={r.id} style={{ height: 28, background: i % 2 === 0 ? '#fff' : '#EFF6FF', borderBottom: '1px solid #f3f4f6' }}>
                      <td className="table-td" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>{r.costPlanNumber || '—'}</td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.sizing || '—'}</td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.bdm || '—'}</td>
                      <td className="table-td" style={{ textAlign: 'center' }}>
                        {r.timber
                          ? <span style={{ fontSize: 10, fontWeight: 700, padding: '1px 8px', borderRadius: 999, background: r.timber === 'Y' ? '#f0fdf4' : '#fef2f2', color: r.timber === 'Y' ? '#16a34a' : '#dc2626', border: `1px solid ${r.timber === 'Y' ? '#86efac' : '#fca5a5'}` }}>{r.timber}</span>
                          : <span style={{ color: '#d1d5db' }}>—</span>}
                      </td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', color: '#9ca3af', whiteSpace: 'nowrap' }}>
                        {r.estimate === 0 ? '—' : `$${r.estimate.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', color: '#9ca3af', whiteSpace: 'nowrap' }}>
                        {r.opsMaintenanceCost === 0 ? '—' : `$${r.opsMaintenanceCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                        {r.totalCost === 0 ? '—' : `$${r.totalCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                        <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.costMeta.costType === 'Recurring' ? '#FEF3C7' : '#F0FDF4', color: r.costMeta.costType === 'Recurring' ? '#92400E' : '#15803D', border: `1px solid ${r.costMeta.costType === 'Recurring' ? '#FDE68A' : '#86EFAC'}` }}>{r.costMeta.costType}</span>
                      </td>
                      <PeriodCells start={r.periodStart} end={r.periodEnd} />
                      <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.projectNumber || '—'}</td>
                      <td className="table-td" style={{ maxWidth: 220 }}>
                        <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#4b5563' }} title={r.notes}>{r.notes || '—'}</span>
                      </td>
                      <td className="table-td" style={{ textAlign: 'center', width: 64, whiteSpace: 'nowrap' }}>
                        <RowActions editing={editingRow === r.id} expanded={expandedRows.has(r.id)} deleting={deletingId === r.id}
                          readOnly={r.readOnly || !canEdit}
                          onEditRow={() => startEdit(r.id)}
                          onDelete={() => setConfirmDelete({ row: r, kind: 'loe', label: r.costPlanNumber || 'LOE row' })}
                          onToggleDist={() => toggleExpand(r.id)} />
                      </td>
                    </tr>,
                    expandedRows.has(r.id) && (
                      <CostDistributionPanel readOnly={!canEdit} key={`${r.id}-dist`} rowId={r.id} rowType="loe" total={r.totalCost} range={rangeFor(r.costPlanNumber)} meta={r.costMeta} colSpan={13}
                        onSave={m => saveLoeMeta(r.id, m)} />
                    ),
                  ])}
                  {addingLoe && (
                    <tr style={{ background: '#EFF6FF', borderBottom: '2px solid #93c5fd' }}>
                      <td className="table-td"><CostPlanSelect value={newLoe.costPlanNumber} onChange={pickPlan(setNewLoe)} {...cpSelectProps} /></td>
                      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Sizing" value={newLoe.sizing} onChange={e => setNewLoe(p => ({ ...p, sizing: e.target.value }))} /></td>
                      <td className="table-td"><input className="form-select text-xs w-16" placeholder="BDM" value={newLoe.bdm} onChange={e => setNewLoe(p => ({ ...p, bdm: e.target.value }))} /></td>
                      <td className="table-td">
                        <select className="form-select text-xs w-16" value={newLoe.timber} onChange={e => setNewLoe(p => ({ ...p, timber: e.target.value }))}>
                          <option value="">—</option><option>Y</option><option>N</option>
                        </select>
                      </td>
                      <td className="table-td"><input type="number" className="form-select text-xs w-24 text-right" placeholder="0" value={newLoe.estimate || ''} onChange={e => setNewLoe(p => { const est = parseFloat(e.target.value)||0; return { ...p, estimate: est, totalCost: est + p.opsMaintenanceCost }; })} /></td>
                      <td className="table-td"><input type="number" className="form-select text-xs w-28 text-right" placeholder="0" value={newLoe.opsMaintenanceCost || ''} onChange={e => setNewLoe(p => { const ops = parseFloat(e.target.value)||0; return { ...p, opsMaintenanceCost: ops, totalCost: p.estimate + ops }; })} /></td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>{newLoe.totalCost > 0 ? `$${newLoe.totalCost.toLocaleString()}` : '—'}</td>
                      <td className="table-td">
                        <select className="form-select text-xs w-24" value={newLoe.costType} onChange={e => setNewLoe(p => ({ ...p, costType: e.target.value }))}>
                          <option>One-time</option><option>Recurring</option>
                        </select>
                      </td>
                      <PeriodInputs start={newLoe.periodStart} end={newLoe.periodEnd} onChange={(k, val) => setNewLoe(p => ({ ...p, [k]: val }))} range={rangeFor(newLoe.costPlanNumber)} />
                      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Project #" value={newLoe.projectNumber} onChange={e => setNewLoe(p => ({ ...p, projectNumber: e.target.value }))} /></td>
                      <td className="table-td"><input className="form-select text-xs w-36" placeholder="Notes" value={newLoe.notes} onChange={e => setNewLoe(p => ({ ...p, notes: e.target.value }))} /></td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                        <SaveCancel saving={addSaving === 'loe'} onSave={saveNewLoe} onCancel={() => { setAddingLoe(false); setNewLoe(BLANK_LOE); }} />
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot>
                  <tr style={{ height: 30, background: 'rgba(26,54,115,0.07)', borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                    <td colSpan={6} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673' }}>TOTAL ({loeRows.length} row{loeRows.length !== 1 ? 's' : ''})</td>
                    <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                      ${loeRows.reduce((s, r) => s + r.totalCost, 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td colSpan={6}></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* ── IT COST SUMMARY (read-only rows from the API) ───────────── */}
          {costGroups.itOther.map(g => {
            const rows = itRows.filter(r => r.groupId === g.groupId);
            const total = rows.reduce((s, r) => s + r.totalCost, 0);
            return (
              <div key={g.groupId} className="card overflow-hidden">
                <div className="card-header">
                  <div className="flex items-center gap-2">
                    <div className="card-title">{g.groupName}</div>
                    <span className="text-[10px] text-gray-400">({rows.length} row{rows.length !== 1 ? 's' : ''})</span>
                  </div>
                </div>
                <div style={{ overflowX: 'auto' }}>
                  <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
                    <thead>
                      <tr style={{ background: '#1A3673', height: 32 }}>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'left' }}>Item</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Total Cost</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'left' }}>Timeline</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.length === 0 ? (
                        <tr><td colSpan={3} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No rows.</td></tr>
                      ) : rows.map((r, i) => (
                        <tr key={r.id} style={{ height: 28, background: i % 2 === 0 ? '#fff' : '#EFF6FF', borderBottom: '1px solid #f3f4f6' }}>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#374151' }}>{r.description || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: r.totalCost ? '#1A3673' : '#d1d5db', whiteSpace: 'nowrap' }}>
                            {r.totalCost ? `$${r.totalCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.timeline || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr style={{ height: 30, background: 'rgba(26,54,115,0.07)', borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                        <td style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673' }}>TOTAL</td>
                        <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                          ${total.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            );
          })}

      </CostSection>
      )}

      {/* ═══════════ 2. FTE REQUEST ═══════════ */}
      {hasFte && (
      <CostSection id="fte" title={costSections.fte?.title || 'FTE Expense'} subtitle={costSections.fte?.description || 'Resource requests by department — G&A, CCCR, Claims Ops'} icon={Users}           total={fteTotal}    accent="#2861BB" tint="#F5F9FF">
          <div className="flex items-start gap-2 px-4 py-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-gray-700">
            <Info size={13} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-800">FTE Estimates — ALL EVALUATIONS COMPLETED — No FTEs NEEDED</p>
              <p className="mt-0.5 text-gray-600">Reference the PI-Medical Edits Resource Evaluation Process</p>
            </div>
          </div>

          {/* FTE filter modal (shared across all FTE sub-sections) */}
          {cpFilterOpen.fte && (
            <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
              onClick={() => cpCloseFilter('fte')}>
              <div style={{ background:'#fff', borderRadius:12, maxWidth:640, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
                onClick={e => e.stopPropagation()}>
                <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — FTE</span></div>
                  <button onClick={() => cpCloseFilter('fte')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
                </div>
                <div style={{ padding:20, display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:14 }}>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                    <input type="text" value={cpPending.fte.costPlanNumber} onChange={e => cpPatch('fte','costPlanNumber',e.target.value)} placeholder="Search…"
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }} />
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Onshore / Offshore</label>
                    <select value={cpPending.fte.onshoreOffshore} onChange={e => cpPatch('fte','onshoreOffshore',e.target.value)}
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                      <option value="">All</option><option value="Onshore">Onshore</option><option value="Offshore">Offshore</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>CoC / Non-CoC</label>
                    <select value={cpPending.fte.cocNonCoc} onChange={e => cpPatch('fte','cocNonCoc',e.target.value)}
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                      <option value="">All</option><option value="CoC">CoC</option><option value="Non-CoC">Non-CoC</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>CA Only</label>
                    <select value={cpPending.fte.caOnly} onChange={e => cpPatch('fte','caOnly',e.target.value)}
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                      <option value="">All</option>
                      {caOptions.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                  <button onClick={() => setCpPending(p => ({ ...p, fte: { ...BLANK_FTE_F } }))}
                    style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                  <div style={{ display:'flex', gap:8 }}>
                    <button onClick={() => cpCloseFilter('fte')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                    <button onClick={() => cpApply('fte')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {fteGroups.map(({ groupId: section, groupName }, groupIdx) => {
            const rows = fteRows.filter(r => r.section === section);
            const sectionTotal = rows.reduce((s, r) => s + r.cost, 0);
            return (
              <div key={section} className="card overflow-hidden">
                <div className="card-header">
                  <div className="flex items-center gap-2">
                    <div className="card-title"><Users size={14} /> {groupName}</div>
                    <span className="text-[10px] text-gray-400">({rows.length} row{rows.length !== 1 ? 's' : ''})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold font-mono text-[#00BBBA]">{fmtCost(sectionTotal)}</span>
                    {canEdit && (
                      <button onClick={() => { setNewFte(BLANK_FTE(section)); setAddingFteSection(section); }}
                        className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition">
                        <Plus size={11} /> Add Row
                      </button>
                    )}
                  </div>
                </div>

                {groupIdx === 0 && <SectionToolbar sec="fte" placeholder="Search cost plan, job title, department…" />}

                <div style={{ overflowX: 'auto' }}>
                  <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
                    <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                      <tr style={{ background: '#1A3673', height: 32 }}>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Number</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}># Positions</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Start Date / Timeline</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Job Code</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Job Title</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Department</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Approved By</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Hiring Manager</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Onshore/Offshore</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>CoC?</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>CA Only</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Cost</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Type</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Period Start</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Period End</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Short Desc (SNOW)</th>
                        <th style={{ padding: '0 10px', width: 20 }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        const filteredFte = applyFilter(rows, 'fte', ['costPlanNumber', 'jobTitle', 'department', 'jobCode', 'approvedBy', 'hiringManager']);
                        const fteEmpty = filteredFte.length === 0 && addingFteSection !== section;
                        return fteEmpty ? (
                        <tr><td colSpan={17} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No rows match the current filters. <button onClick={() => cpClearAll('fte', BLANK_FTE_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                      ) : <>{filteredFte.map((r, i) => [
                        editingRow === r.id ? (
                          <FteEditRow key={`${r.id}-edit`} row={r} caOptions={caOptions} range={rangeFor(r.costPlanNumber)} onSave={saveFteEdit} onCancel={() => setEditingRow(null)} />
                        ) :
                        <tr key={r.id} style={{ height: 28, background: i % 2 === 0 ? '#fff' : '#EFF6FF', borderBottom: '1px solid #f3f4f6' }}>
                          <td className="table-td" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>{r.costPlanNumber || '—'}</td>
                          <td className="table-td" style={{ textAlign: 'center', color: r.positions === 0 ? '#d1d5db' : '#374151', fontFamily: 'monospace' }}>{r.positions}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.startDate || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ fontFamily: 'monospace', color: '#6b7280', whiteSpace: 'nowrap' }}>{r.jobCode || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#374151' }}>{r.jobTitle || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.department || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.approvedBy || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.hiringManager || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            {r.onshoreOffshore
                              ? <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.onshoreOffshore === 'Onshore' ? '#E3F4FD' : '#D9F5F5', color: r.onshoreOffshore === 'Onshore' ? '#2861BB' : '#00BBBA', border: `1px solid ${r.onshoreOffshore === 'Onshore' ? '#C7EAFB' : '#66D6D6'}` }}>{r.onshoreOffshore}</span>
                              : <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            {r.cocNonCoc
                              ? <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.cocNonCoc === 'CoC' ? '#f0fdfa' : '#f9fafb', color: r.cocNonCoc === 'CoC' ? '#00BBBA' : '#6b7280', border: `1px solid ${r.cocNonCoc === 'CoC' ? '#66D6D6' : '#e5e7eb'}` }}>{r.cocNonCoc}</span>
                              : <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            {r.caOnly
                              ? <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: '#fef3c7', color: '#92400e', border: '1px solid #fde68a' }}>{r.caOnly}</span>
                              : <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                          <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: r.cost === 0 ? '#d1d5db' : '#1A3673', whiteSpace: 'nowrap' }}>
                            {r.cost === 0 ? '—' : `$${r.cost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.costMeta.costType === 'Recurring' ? '#FEF3C7' : '#F0FDF4', color: r.costMeta.costType === 'Recurring' ? '#92400E' : '#15803D', border: `1px solid ${r.costMeta.costType === 'Recurring' ? '#FDE68A' : '#86EFAC'}` }}>{r.costMeta.costType}</span>
                          </td>
                          <PeriodCells start={r.periodStart} end={r.periodEnd} />
                          <td className="table-td" style={{ maxWidth: 220 }}>
                            <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#4b5563' }}>{r.snowDescription || <span style={{ color: '#d1d5db' }}>—</span>}</span>
                          </td>
                          <td className="table-td" style={{ textAlign: 'center', width: 64, whiteSpace: 'nowrap' }}>
                            <RowActions editing={editingRow === r.id} expanded={expandedRows.has(r.id)} deleting={deletingId === r.id}
                              readOnly={r.readOnly || !canEdit}
                          onEditRow={() => startEdit(r.id)}
                              onDelete={() => setConfirmDelete({ row: r, kind: 'fte', label: r.costPlanNumber || r.jobTitle || 'FTE row' })}
                              onToggleDist={() => toggleExpand(r.id)} />
                          </td>
                        </tr>,
                        expandedRows.has(r.id) && (
                          <CostDistributionPanel readOnly={!canEdit} key={`${r.id}-dist`} rowId={r.id} rowType="fte" total={r.cost} range={rangeFor(r.costPlanNumber)} meta={r.costMeta} colSpan={17}
                            onSave={m => saveFteMeta(r.id, m)} />
                        ),
                      ])}{addingFteSection === section && (
                        <tr style={{ background: '#D9F5F5', borderBottom: '2px solid #66D6D6' }}>
                          <td className="table-td"><CostPlanSelect value={newFte.costPlanNumber} onChange={pickPlan(setNewFte, 'snowDescription')} {...cpSelectProps} /></td>
                          <td className="table-td"><input type="number" className="form-select text-xs w-16 text-center" placeholder="0" value={newFte.positions || ''} onChange={e => setNewFte(p => ({ ...p, positions: parseInt(e.target.value)||0 }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-24" placeholder="Start Date" value={newFte.startDate} onChange={e => setNewFte(p => ({ ...p, startDate: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-20" placeholder="Job Code" value={newFte.jobCode} onChange={e => setNewFte(p => ({ ...p, jobCode: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-28" placeholder="Job Title" value={newFte.jobTitle} onChange={e => setNewFte(p => ({ ...p, jobTitle: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-28" placeholder="Department" value={newFte.department} onChange={e => setNewFte(p => ({ ...p, department: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-24" placeholder="Approved By" value={newFte.approvedBy} onChange={e => setNewFte(p => ({ ...p, approvedBy: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-24" placeholder="Hiring Mgr" value={newFte.hiringManager} onChange={e => setNewFte(p => ({ ...p, hiringManager: e.target.value }))} /></td>
                          <td className="table-td"><select className="form-select text-xs w-24" value={newFte.onshoreOffshore} onChange={e => setNewFte(p => ({ ...p, onshoreOffshore: e.target.value }))}><option value="">—</option><option>Onshore</option><option>Offshore</option></select></td>
                          <td className="table-td"><select className="form-select text-xs w-20" value={newFte.cocNonCoc} onChange={e => setNewFte(p => ({ ...p, cocNonCoc: e.target.value }))}><option value="">—</option><option>CoC</option><option>Non-CoC</option></select></td>
                          <td className="table-td"><select className="form-select text-xs w-24" value={newFte.caOnly} onChange={e => setNewFte(p => ({ ...p, caOnly: e.target.value }))}><option value="">—</option>{caOptions.map(o => <option key={o}>{o}</option>)}</select></td>
                          <td className="table-td"><input type="number" className="form-select text-xs w-24 text-right" placeholder="Cost" value={newFte.cost || ''} onChange={e => setNewFte(p => ({ ...p, cost: parseFloat(e.target.value)||0 }))} /></td>
                          <td className="table-td">
                            <select className="form-select text-xs w-24" value={newFte.costMeta.costType} onChange={e => setNewFte(p => ({ ...p, costMeta: { ...p.costMeta, costType: e.target.value } }))}>
                              <option>One-time</option><option>Recurring</option>
                            </select>
                          </td>
                          <PeriodInputs start={newFte.periodStart} end={newFte.periodEnd} onChange={(k, val) => setNewFte(p => ({ ...p, [k]: val }))} range={rangeFor(newFte.costPlanNumber)} />
                          <td className="table-td"><input className="form-select text-xs w-36" placeholder="SNOW Desc" value={newFte.snowDescription} onChange={e => setNewFte(p => ({ ...p, snowDescription: e.target.value }))} /></td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}><SaveCancel saving={addSaving === section} onSave={() => saveNewFte(section)} onCancel={() => setAddingFteSection(null)} /></td>
                        </tr>
                      )}</> ;
                      })()
                      }
                    </tbody>
                    <tfoot>
                      <tr style={{ height: 30, background: 'rgba(26,54,115,0.07)', borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                        <td colSpan={11} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673' }}>TOTAL — {groupName} ({rows.length} row{rows.length !== 1 ? 's' : ''})</td>
                        <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                          {sectionTotal === 0 ? '—' : `$${sectionTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                        </td>
                        <td colSpan={5}></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            );
          })}
      </CostSection>
      )}

      {/* ═══════════ 3. VENDOR EXPENSES ═══════════ */}
      {hasVnd && (
      <CostSection id="vnd" title={costSections.vnd?.title || 'Vendor Expenses'} subtitle={costSections.vnd?.description || 'Vendor cost plans — monthly scaled savings and calculated vendor fees'} icon={Building2} total={vendorFeeTotal} accent="#2861BB" tint="#F5F9FF" defaultOpen>
        {/* Vendor filter modal */}
        {cpFilterOpen.vnd && (
          <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
            onClick={() => cpCloseFilter('vnd')}>
            <div style={{ background:'#fff', borderRadius:12, maxWidth:480, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
              onClick={e => e.stopPropagation()}>
              <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — Vendor Expenses</span></div>
                <button onClick={() => cpCloseFilter('vnd')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
              </div>
              <div style={{ padding:20 }}>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Vendor</label>
                  <select value={cpPending.vnd.vendor} onChange={e => cpPatch('vnd','vendor',e.target.value)}
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All Vendors</option>
                    {[...new Set(vendorPlans.map(p => p.vendor).filter(Boolean))].sort().map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                <button onClick={() => setCpPending(p => ({ ...p, vnd: { ...BLANK_VND_F } }))}
                  style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                <div style={{ display:'flex', gap:8 }}>
                  <button onClick={() => cpCloseFilter('vnd')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                  <button onClick={() => cpApply('vnd')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="card overflow-hidden">
          <div className="card-header" style={{ flexWrap: 'wrap', gap: 8 }}>
            <div className="flex items-center gap-2">
              <div className="card-title"><Building2 size={14} /> {costGroups.vnd?.groupName || 'Vendor Cost Plans'}</div>
              <span className="text-[10px] text-gray-400">({filteredVendorPlans.length} plan{filteredVendorPlans.length !== 1 ? 's' : ''} · {vendorGroups.length} vendor{vendorGroups.length !== 1 ? 's' : ''})</span>
            </div>
            {/* Shown only when a Vendor Fee % has been entered / changed (or while saving) */}
            {canEdit && (unsavedVendorPlans.length > 0 || vendorSaving === 'all') && (
              <button onClick={saveAllVendors} disabled={!unsavedVendorPlans.length || !!vendorSaving}
                title="Save Vendor Fee % changes"
                className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition disabled:opacity-40 disabled:cursor-not-allowed">
                {vendorSaving === 'all' ? <Loader2 size={11} className="animate-spin" /> : <Save size={11} />}
                {vendorSaving === 'all' ? 'Saving…' : `Save changes${unsavedVendorPlans.length ? ` (${unsavedVendorPlans.length})` : ''}`}
              </button>
            )}
          </div>

          <SectionToolbar sec="vnd" placeholder="Search vendor, cost plan, description…" />

          <div style={{ overflowX: 'auto' }}>
            <table className="w-full text-xs" style={{ borderCollapse: 'separate', borderSpacing: 0, minWidth: 'max-content' }}>
              <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                <tr style={{ height: 32 }}>
                  <th style={{ ...vHead, textAlign: 'left', ...vStick('vendor', '#1A3673', 15) }}>Vendor</th>
                  <th style={{ ...vHead, textAlign: 'left', ...vStick('plan', '#1A3673', 15) }}>Cost Plan</th>
                  <th style={{ ...vHead, textAlign: 'right', ...vStick('fee', '#1A3673', 15) }}>Vendor Fee %</th>
                  <th style={{ ...vHead, textAlign: 'left', ...vStick('measure', '#1A3673', 15) }}>Measure</th>
                  <th style={{ ...vHead, textAlign: 'right', ...vStick('total', '#1A3673', 15, 'rgba(255,255,255,0.3)') }}>Total</th>
                  {vendorMonths.map(mo => (
                    <th key={mo} style={{ ...vHead, textAlign: 'right', minWidth: 96, background: '#1A3673' }}>{fmtPeriod(mo)}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {vendorGroups.length === 0 ? (
                  <tr><td colSpan={5 + vendorMonths.length} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>{vendorPlans.length === 0 ? 'No vendor cost plans.' : <>No vendor plans match the current filters. <button onClick={() => cpClearAll('vnd', BLANK_VND_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></>}</td></tr>
                ) : (() => {
                  let rowIdx = 0;
                  return vendorGroups.flatMap((g, gi) => g.plans.map(({ plan, error, months, feeFor, totalActual, totalFee, loading: pvLoading, previewError }, pi) => {
                    const bg = rowIdx++ % 2 === 0 ? '#fff' : '#EFF6FF';
                    const inputId = `vendor-fee-${plan.id}`;
                    const top = pi === 0 && gi > 0 ? '2px solid #e5e7eb' : '1px solid #f3f4f6';
                    return (
                      <tr key={plan.id} style={{ background: bg }}>
                        {pi === 0 && (
                          <td rowSpan={g.plans.length} style={{ padding: '8px', verticalAlign: 'top', borderTop: top, borderRight: '1px solid #e5e7eb',
                            whiteSpace: 'normal', wordBreak: 'break-word', fontWeight: 700, color: '#1A3673', ...vStick('vendor', '#fff') }}>
                            {plan.vendor || <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                        )}
                        <td style={{ padding: '8px', verticalAlign: 'top', borderTop: top, borderRight: '1px solid #e5e7eb', whiteSpace: 'normal', wordBreak: 'break-word', ...vStick('plan', bg) }}>
                          <span style={{ display: 'block', fontFamily: 'monospace', color: '#1A3673' }}>{plan.costPlanNumber}</span>
                          {plan.description && <span style={{ display: 'block', fontSize: 10, color: '#6b7280', marginTop: 2, lineHeight: 1.35 }}>{plan.description}</span>}
                          {previewError && <span role="alert" style={{ display: 'block', fontSize: 9.5, color: '#E3725F', marginTop: 4, lineHeight: 1.35 }}>Preview failed: {previewError}</span>}
                        </td>
                        <td style={{ padding: '6px 8px', verticalAlign: 'middle', textAlign: 'right', borderTop: top, borderRight: '1px solid #e5e7eb', ...vStick('fee', bg) }}>
                          <div className="flex items-center justify-end gap-1">
                            <input id={inputId} type="text" inputMode="decimal" aria-label={`Vendor Fee % for ${plan.costPlanNumber}`}
                              aria-invalid={!!error} aria-describedby={error ? `${inputId}-err` : undefined}
                              className="form-select text-xs text-right" placeholder="0.00"
                              style={{ width: 56, fontFamily: 'monospace', background: '#fff', border: `1px solid ${error ? '#E3725F' : '#93C5FD'}` }}
                              readOnly={!canEdit}
                              value={feeDraftOf(plan)} onChange={e => handleFeeChange(plan.id, e.target.value)}
                              onKeyDown={e => { if (canEdit && e.key === 'Enter' && hasUnsavedFee(plan) && !vendorSaving) saveOneVendor(plan); }} />
                            <span style={{ fontSize: 11, color: '#6b7280', fontWeight: 600 }}>%</span>
                            {canEdit && (() => {
                              const unsaved = hasUnsavedFee(plan);
                              const busy = vendorSaving === plan.id || (vendorSaving === 'all' && unsaved);
                              const show = unsaved || busy; // icon appears only after the % is entered / changed
                              return (
                                <button onClick={() => saveOneVendor(plan)} disabled={!unsaved || !!vendorSaving}
                                  title="Save Vendor Fee %" aria-label={`Save Vendor Fee % for ${plan.costPlanNumber}`}
                                  aria-hidden={!show} tabIndex={show ? 0 : -1}
                                  // hidden (not removed) so the % box doesn't shift when it appears
                                  style={{ background: 'none', border: 'none', padding: 2, display: 'inline-flex', cursor: unsaved && !vendorSaving ? 'pointer' : 'default',
                                    color: '#1A3673', visibility: show ? 'visible' : 'hidden' }}>
                                  {busy ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
                                </button>
                              );
                            })()}
                          </div>
                          {error && <p id={`${inputId}-err`} role="alert" style={{ fontSize: 9.5, color: '#E3725F', marginTop: 4, whiteSpace: 'normal', textAlign: 'left' }}>{error}</p>}
                        </td>
                        <td style={{ ...vCell, textAlign: 'left', borderTop: top, borderRight: '1px solid #e5e7eb', ...vStick('measure', bg) }}>
                          <MeasureLabels />
                        </td>
                        <td style={{ ...vCell, borderTop: top, ...vStick('total', bg) }}>
                          {pvLoading && !months.length
                            ? <span className="inline-flex items-center gap-1 text-[10px] text-gray-400"><Loader2 size={11} className="animate-spin" /> Loading…</span>
                            : <SavingsFeeCell savings={months.length ? totalActual : null} fee={months.length ? totalFee : null} bold />}
                        </td>
                        {vendorMonths.map(mo => {
                          const amt = savingsFor(months, mo);
                          return <td key={mo} style={{ ...vCell, borderTop: top, opacity: pvLoading ? 0.5 : 1 }}><SavingsFeeCell savings={amt ?? null} fee={amt == null ? null : feeFor(mo)} /></td>;
                        })}
                      </tr>
                    );
                  }));
                })()}
              </tbody>

              <tfoot>
                <tr style={{ background: V_FOOT_BG }}>
                  <td colSpan={3} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673', verticalAlign: 'middle', borderTop: '2px solid rgba(26,54,115,0.15)',
                    position: 'sticky', left: 0, zIndex: 5, background: V_FOOT_BG, minWidth: V_LEFT.measure, maxWidth: V_LEFT.measure }}>TOTAL ({vendorPlans.length} cost plan{vendorPlans.length !== 1 ? 's' : ''})</td>
                  <td style={{ ...vCell, textAlign: 'left', borderTop: '2px solid rgba(26,54,115,0.15)', ...vStick('measure', V_FOOT_BG) }}>
                    <MeasureLabels bold />
                  </td>
                  <td style={{ ...vCell, borderTop: '2px solid rgba(26,54,115,0.15)', ...vStick('total', V_FOOT_BG, 5, 'rgba(26,54,115,0.15)') }}>
                    <SavingsFeeCell savings={vendorActualTotal} fee={vendorFeeTotal} bold />
                  </td>
                  {vendorMonths.map((mo, i) => (
                    <td key={mo} style={{ ...vCell, borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                      <SavingsFeeCell savings={vendorMonthSavings[i] || null} fee={vendorMonthFees[i] || null} bold />
                    </td>
                  ))}
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </CostSection>
      )}

      {/* ═══════════ 4. OTHERS ═══════════ */}
      {hasOth && (
      <CostSection id="oth" title={costSections.oth?.title || 'Others'}      subtitle={costSections.oth?.description || 'Licensing, training and miscellaneous costs'} icon={FileSpreadsheet} total={othersTotal} accent="#2861BB" tint="#F5F9FF">
        <div className="flex items-start gap-2 px-4 py-3 bg-purple-50 border border-purple-200 rounded-lg text-xs text-gray-600">
          <Info size={13} className="text-purple-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-purple-800">Other Costs — Licensing, Training, Vendor, Miscellaneous</p>
            <p className="mt-0.5 text-gray-600">Capture any additional costs not covered under IT Expense or FTE Request. These roll into Total Costs and Net ROI.</p>
          </div>
        </div>

        {/* Others filter modal */}
        {cpFilterOpen.oth && (
          <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
            onClick={() => cpCloseFilter('oth')}>
            <div style={{ background:'#fff', borderRadius:12, maxWidth:620, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
              onClick={e => e.stopPropagation()}>
              <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — Others</span></div>
                <button onClick={() => cpCloseFilter('oth')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
              </div>
              <div style={{ padding:20, display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:14 }}>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                  <input type="text" value={cpPending.oth.costPlanNumber} onChange={e => cpPatch('oth','costPlanNumber',e.target.value)} placeholder="Search…"
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }} />
                </div>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Category</label>
                  <select value={cpPending.oth.category} onChange={e => cpPatch('oth','category',e.target.value)}
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {[...new Set(otherRows.map(r => r.category).filter(Boolean))].sort().map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Type</label>
                  <select value={cpPending.oth.costType} onChange={e => cpPatch('oth','costType',e.target.value)}
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option><option value="One-time">One-time</option><option value="Recurring">Recurring</option><option value="Capital">Capital</option><option value="Operational">Operational</option>
                  </select>
                </div>
              </div>
              <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                <button onClick={() => setCpPending(p => ({ ...p, oth: { ...BLANK_OTH_F } }))}
                  style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                <div style={{ display:'flex', gap:8 }}>
                  <button onClick={() => cpCloseFilter('oth')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                  <button onClick={() => cpApply('oth')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="card overflow-hidden">
          <div className="card-header">
            <div className="flex items-center gap-2">
              <div className="card-title"><FileSpreadsheet size={14} /> {costGroups.oth?.groupName || 'Other Costs'}</div>
              <span className="text-[10px] text-gray-400">({otherRows.length} row{otherRows.length !== 1 ? 's' : ''})</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold font-mono text-[#7c3aed]">{fmtCost(othersTotal)}</span>
              {canEdit && (
                <button onClick={() => setAddingOther(true)}
                  className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition">
                  <Plus size={11} /> Add Row
                </button>
              )}
            </div>
          </div>

          <SectionToolbar sec="oth" placeholder="Search cost plan, category, vendor, description…" />

          <div style={{ overflowX: 'auto' }}>
            <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
              <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                <tr style={{ background: '#1A3673', height: 32 }}>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Number</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Category</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Description</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Vendor / Provider</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Type</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Start Date</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>End Date</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Amount</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Timeline</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Notes</th>
                  <th style={{ padding: '0 10px', width: 20 }}></th>
                </tr>
              </thead>
              <tbody>
                {filteredOth.length === 0 && !addingOther ? (
                  <tr><td colSpan={11} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No rows match the current filters. <button onClick={() => cpClearAll('oth', BLANK_OTH_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                ) : filteredOth.map((r, i) => [
                  editingRow === r.id ? (
                    <OtherEditRow key={`${r.id}-edit`} row={r} range={rangeFor(r.costPlanNumber)} onSave={saveOthEdit} onCancel={() => setEditingRow(null)} />
                  ) :
                  <tr key={r.id} style={{ height: 32, background: i % 2 === 0 ? '#fff' : '#faf5ff', borderBottom: '1px solid #f3f4f6' }}>
                    <td className="table-td" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>{r.costPlanNumber || '—'}</td>
                    <td className="table-td" style={{ color: '#7c3aed', fontWeight: 600, whiteSpace: 'nowrap' }}>{r.category || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                    <td className="table-td" style={{ maxWidth: 200 }}>
                      <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#374151' }} title={r.description}>{r.description || <span style={{ color: '#d1d5db' }}>—</span>}</span>
                    </td>
                    <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.vendor || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                    <td className="table-td">
                      {r.costType ? (
                        <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.costType === 'Recurring' ? '#fef3c7' : '#f0fdf4', color: r.costType === 'Recurring' ? '#92400e' : '#15803d', border: `1px solid ${r.costType === 'Recurring' ? '#fde68a' : '#86efac'}` }}>{r.costType}</span>
                      ) : <span style={{ color: '#d1d5db' }}>—</span>}
                    </td>
                    <PeriodCells start={r.periodStart} end={r.periodEnd} />
                    <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: r.amount > 0 ? 700 : 400, color: r.amount > 0 ? '#7c3aed' : '#d1d5db', whiteSpace: 'nowrap' }}>
                      {r.amount > 0 ? `$${r.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
                    </td>
                    <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.timeline || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                    <td className="table-td" style={{ maxWidth: 220 }}>
                      <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#4b5563' }} title={r.notes}>{r.notes || <span style={{ color: '#d1d5db' }}>—</span>}</span>
                    </td>
                    <td className="table-td" style={{ textAlign: 'center', width: 64, whiteSpace: 'nowrap' }}>
                      <RowActions editing={editingRow === r.id} expanded={expandedRows.has(r.id)} deleting={deletingId === r.id}
                        readOnly={r.readOnly || !canEdit}
                          onEditRow={() => startEdit(r.id)}
                        onDelete={() => setConfirmDelete({ row: r, kind: 'oth', label: r.costPlanNumber || r.description || 'Cost row' })}
                        onToggleDist={() => toggleExpand(r.id)} />
                    </td>
                  </tr>,
                  expandedRows.has(r.id) && (
                    <CostDistributionPanel readOnly={!canEdit} key={`${r.id}-dist`} rowId={r.id} rowType="oth" total={r.amount} range={rangeFor(r.costPlanNumber)} meta={r.costMeta} colSpan={11}
                      onSave={m => saveOthMeta(r.id, m)} />
                  ),
                ])}
                {addingOther && (
                  <tr style={{ background: '#faf5ff', borderBottom: '2px solid #c4b5fd' }}>
                    <td className="table-td"><CostPlanSelect value={newOther.costPlanNumber} onChange={pickPlan(setNewOther, 'description')} {...cpSelectProps} /></td>
                    <td className="table-td"><input className="form-select text-xs w-24" placeholder="Category" value={newOther.category} onChange={e => setNewOther(p => ({ ...p, category: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-40" placeholder="Description" value={newOther.description} onChange={e => setNewOther(p => ({ ...p, description: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-32" placeholder="Vendor" value={newOther.vendor} onChange={e => setNewOther(p => ({ ...p, vendor: e.target.value }))} /></td>
                    <td className="table-td">
                      <select className="form-select text-xs w-28" value={newOther.costType} onChange={e => setNewOther(p => ({ ...p, costType: e.target.value }))}>
                        <option>One-time</option><option>Recurring</option><option>Capital</option><option>Operational</option>
                      </select>
                    </td>
                    <PeriodInputs start={newOther.periodStart} end={newOther.periodEnd} onChange={(k, val) => setNewOther(p => ({ ...p, [k]: val }))} range={rangeFor(newOther.costPlanNumber)} />
                    <td className="table-td"><input type="number" className="form-select text-xs w-28 text-right" placeholder="0" value={newOther.amount || ''} onChange={e => setNewOther(p => ({ ...p, amount: parseFloat(e.target.value) || 0 }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-24" placeholder="Timeline" value={newOther.timeline} onChange={e => setNewOther(p => ({ ...p, timeline: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-36" placeholder="Notes" value={newOther.notes} onChange={e => setNewOther(p => ({ ...p, notes: e.target.value }))} /></td>
                    <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                      <SaveCancel saving={addSaving === 'oth'} onSave={saveNewOther} onCancel={() => setAddingOther(false)} />
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr style={{ height: 34, background: 'rgba(124,58,237,0.07)', borderTop: '2px solid rgba(124,58,237,0.2)' }}>
                  <td colSpan={7} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#7c3aed' }}>TOTAL ({otherRows.length} row{otherRows.length !== 1 ? 's' : ''})</td>
                  <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: '#7c3aed', whiteSpace: 'nowrap' }}>
                    {othersTotal === 0 ? '—' : `$${othersTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                  </td>
                  <td colSpan={3}></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </CostSection>
      )}

      {/* Confirm Delete Dialog */}
      {confirmDelete && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={() => setConfirmDelete(null)}>
          <div style={{ background:'#fff', borderRadius:12, width:420, boxShadow:'0 20px 60px rgba(0,0,0,0.3)', overflow:'hidden' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding:'16px 20px', borderBottom:'1px solid #e5e7eb', background:'#1A3673', display:'flex', alignItems:'center', gap:10 }}>
              <Trash2 size={18} color="#fff" />
              <h3 style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Delete Cost Row</h3>
            </div>
            <div style={{ padding:24 }}>
              <p style={{ margin:'0 0 6px', fontSize:14, color:'#374151' }}>Are you sure you want to delete this cost row?</p>
              <p style={{ margin:0, fontSize:13, fontWeight:600, color:'#1A3673', wordBreak:'break-all' }}>{confirmDelete.label}</p>
            </div>
            <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', justifyContent:'flex-end', gap:10 }}>
              <button onClick={() => setConfirmDelete(null)}
                style={{ padding:'7px 18px', fontSize:13, fontWeight:600, borderRadius:8, border:'1px solid #d1d5db', background:'#fff', color:'#374151', cursor:'pointer' }}>
                Cancel
              </button>
              <button onClick={handleConfirmDelete}
                style={{ padding:'7px 18px', fontSize:13, fontWeight:600, borderRadius:8, border:'none', background:'#1A3673', color:'#fff', cursor:'pointer' }}>
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}