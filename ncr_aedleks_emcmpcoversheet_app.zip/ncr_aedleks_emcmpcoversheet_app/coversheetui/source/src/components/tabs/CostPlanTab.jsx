import { useState, useCallback, useEffect, useRef } from 'react';
import { Trash2, DollarSign, Users, Info, Plus, FileSpreadsheet, ChevronDown, Calendar, Building2, Search, Filter, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

// ── Cost distribution metadata (shared by all row types) ─────────────────────

const DEFAULT_COST_META = {
  costType: 'One-time',
  timeframeStart: '', timeframeEnd: '',
  distribution: 'equal', periods: [],
};

// Build monthly period labels between two YYYY-MM strings
function buildPeriods(start, end, total, mode, existing) {
  if (!start || !end) return [];
  const [sy, sm] = start.split('-').map(Number);
  const [ey, em] = end.split('-').map(Number);
  const labels = [];
  let y = sy, m = sm;
  while (y < ey || (y === ey && m <= em)) {
    labels.push(`${y}-${String(m).padStart(2, '0')}`);
    m++; if (m > 12) { m = 1; y++; }
    if (labels.length > 120) break; // safety
  }
  if (labels.length === 0) return [];
  if (mode === 'equal') {
    const perPeriod = Math.round((total / labels.length) * 100) / 100;
    return labels.map(label => ({ label, amount: perPeriod }));
  }
  // manual — preserve existing values, pad new periods with 0
  const existingMap = Object.fromEntries(existing.map(p => [p.label, p.amount]));
  return labels.map(label => ({ label, amount: existingMap[label] ?? 0 }));
}

const fmtPeriod = (ym) => {
  if (!ym) return '';
  const [y, m] = ym.split('-');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${months[parseInt(m)-1]} ${y}`;
};

// ── IT Expense / FTE / Others / Vendor row shapes (runtime only — no TS types) ─

const DEFAULT_LOE = [
  { id: 'loe1', costPlanNumber: 'CP-2024-001', sizing: 'Simple (S)', bdm: 'GBDF', timber: 'N', estimate: 72100, opsMaintenanceCost: 7210, totalCost: 79310, projectNumber: 'PRJ-2024-001', notes: 'Request from Gayle Rubin', costMeta: { ...DEFAULT_COST_META  } },
  { id: 'loe2', costPlanNumber: 'CP-2024-002', sizing: 'Medium (M)', bdm: 'HCFC', timber: 'Y', estimate: 145000, opsMaintenanceCost: 14500, totalCost: 159500, projectNumber: 'PRJ-2024-002', notes: 'Priority Q2 initiative', costMeta: { ...DEFAULT_COST_META, costType: 'Recurring' } },
  { id: 'loe3', costPlanNumber: 'CP-2024-003', sizing: 'Large (L)', bdm: 'PDMG', timber: 'N', estimate: 210000, opsMaintenanceCost: 21000, totalCost: 231000, projectNumber: 'PRJ-2024-003', notes: 'Compliance-driven — deadline Q3', costMeta: { ...DEFAULT_COST_META  } },
  { id: 'loe4', costPlanNumber: 'CP-2024-004', sizing: 'Simple (S)', bdm: 'DGTL', timber: 'Y', estimate: 38500, opsMaintenanceCost: 3850, totalCost: 42350, projectNumber: 'PRJ-2024-004', notes: 'Requested by digital experience team', costMeta: { ...DEFAULT_COST_META  } },
];

const DEFAULT_IT = [
  { id: 'it1', description: 'IT Costs - IT LOE',        totalCost: 512160, timeline: 'Q2–Q3 2024' },
  { id: 'it2', description: 'IT Costs - EX Code',       totalCost: 18750,  timeline: 'Q2 2024'    },
  { id: 'it3', description: 'IT Costs - Infra Hosting', totalCost: 24000,  timeline: 'Annual'     },
];

const BLANK_FTE = (section) => ({
  section, costPlanNumber: '',
  positions: 0, startDate: '', jobCode: '', jobTitle: '', department: '',
  approvedBy: '', hiringManager: '',
  onshoreOffshore: '', cocNonCoc: '', caOnly: '',
  cost: 0, snowDescription: '',
  costMeta: { ...DEFAULT_COST_META },
});

const FTE_SECTIONS = ['G&A', 'CCCR', 'Claims Ops'];

const DEFAULT_FTE = [
  { id: 'fte1', section: 'G&A',        costPlanNumber: 'CP-2024-101', positions: 1, startDate: '2024-04-01', jobCode: 'BAS-204', jobTitle: 'Business Analyst',         department: 'Corp Strategy',    approvedBy: 'J. Martinez',  hiringManager: 'D. Patel',   onshoreOffshore: 'Onshore',  cocNonCoc: 'CoC',     caOnly: 'Non-CA',   cost: 95000,  snowDescription: 'MCR NUBC BA support',     costMeta: { ...DEFAULT_COST_META, costType: 'Recurring' } },
  { id: 'fte2', section: 'G&A',        costPlanNumber: 'CP-2024-102', positions: 1, startDate: '2024-05-15', jobCode: 'PM-107',  jobTitle: 'Project Manager',          department: 'PMO',             approvedBy: 'S. Nguyen',    hiringManager: 'K. Brown',   onshoreOffshore: 'Onshore',  cocNonCoc: 'Non-CoC', caOnly: 'Non-CA',   cost: 110000, snowDescription: 'Auto-adj PM role',        costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
  { id: 'fte3', section: 'CCCR',       costPlanNumber: 'CP-2024-103', positions: 2, startDate: '2024-04-01', jobCode: 'DA-312',  jobTitle: 'Data Analyst',             department: 'Data Governance', approvedBy: 'L. Thompson',  hiringManager: 'R. Singh',   onshoreOffshore: 'Offshore', cocNonCoc: 'CoC',     caOnly: 'Non-CA',   cost: 80000,  snowDescription: 'Provider data QA',        costMeta: { ...DEFAULT_COST_META, costType: 'Recurring' } },
  { id: 'fte4', section: 'CCCR',       costPlanNumber: 'CP-2024-104', positions: 1, startDate: '2024-06-01', jobCode: 'SE-445',  jobTitle: 'Senior Software Engineer',  department: 'Digital Eng',     approvedBy: 'M. Collins',   hiringManager: 'A. Kumar',   onshoreOffshore: 'Onshore',  cocNonCoc: 'CoC',     caOnly: 'CA-Only',  cost: 135000, snowDescription: 'SSO dev resource',        costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
  { id: 'fte5', section: 'Claims Ops', costPlanNumber: 'CP-2024-105', positions: 1, startDate: '2024-04-15', jobCode: 'CLM-088', jobTitle: 'Claims Operations Analyst', department: 'Claims Ops',      approvedBy: 'P. Williams',  hiringManager: 'T. Nguyen',  onshoreOffshore: 'Onshore',  cocNonCoc: 'Non-CoC', caOnly: 'Non-CA',   cost: 72000,  snowDescription: 'Claims ops NUBC support', costMeta: { ...DEFAULT_COST_META, costType: 'Recurring' } },
  { id: 'fte6', section: 'Claims Ops', costPlanNumber: 'CP-2024-106', positions: 2, startDate: '2024-05-01', jobCode: 'CLM-091', jobTitle: 'Claims Adjudicator',        department: 'Claims Ops',      approvedBy: 'P. Williams',  hiringManager: 'T. Nguyen',  onshoreOffshore: 'Offshore', cocNonCoc: 'CoC',     caOnly: 'Non-CA',   cost: 88000,  snowDescription: 'Auto-adj ops staff',      costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
];



const DEFAULT_OTHERS = [
  { id: 'oth1', costPlanNumber: 'CP-2024-201', category: 'Licensing',    description: 'Snowflake Data Platform License',    vendor: 'Snowflake Inc.',    costType: 'Recurring', amount: 48000,  timeline: 'Annual',     notes: 'Enterprise tier — 3-yr contract',  costMeta: { ...DEFAULT_COST_META, costType: 'Recurring' } },
  { id: 'oth2', costPlanNumber: 'CP-2024-202', category: 'Training',     description: 'Agile & SAFe Certification Program', vendor: 'Scaled Agile',      costType: 'One-time',  amount: 12500,  timeline: 'Q2 2024',    notes: '25 team members',                  costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
  { id: 'oth3', costPlanNumber: 'CP-2024-203', category: 'Consulting',   description: 'HEDIS Compliance Advisory',           vendor: 'Veeva Consulting',  costType: 'One-time',  amount: 35000,  timeline: 'Q3 2024',    notes: 'Regulatory readiness review',      costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
  { id: 'oth4', costPlanNumber: 'CP-2024-204', category: 'Hardware',     description: 'Dev Environment Workstations',        vendor: 'Dell Technologies', costType: 'Capital',   amount: 22400,  timeline: 'Q2 2024',    notes: '8 units @ $2,800 each',            costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
  { id: 'oth5', costPlanNumber: 'CP-2024-205', category: 'Travel',       description: 'Stakeholder Workshop — Chicago',      vendor: 'Internal',          costType: 'One-time',  amount: 8750,   timeline: 'May 2024',   notes: 'Travel + venue for 3-day workshop', costMeta: { ...DEFAULT_COST_META, costType: 'One-time'  } },
  { id: 'oth6', costPlanNumber: 'CP-2024-206', category: 'Subscription', description: 'Jira / Confluence Cloud',             vendor: 'Atlassian',         costType: 'Recurring', amount: 6300,   timeline: 'Annual',     notes: '90 seats',                         costMeta: { ...DEFAULT_COST_META, costType: 'Recurring' } },
];

// ── Vendor Expense ────────────────────────────────────────────────────────────
const DEFAULT_VENDOR_PLANS = [
  { id: 'vnd1', vendor: 'Cotiviti', costPlanNumber: 'CP-2024-301', description: 'Prepay Claims Edit Review', vendorFeePct: 5,
    monthlyScaledActuals: [
      { month: '2024-01', amount: 100000 }, { month: '2024-02', amount: 112500 }, { month: '2024-03', amount: 108250 },
      { month: '2024-04', amount: 121400 }, { month: '2024-05', amount: 118900 }, { month: '2024-06', amount: 125600 },
      { month: '2024-07', amount: 129300 }, { month: '2024-08', amount: 131750 }, { month: '2024-09', amount: 127400 },
      { month: '2024-10', amount: 134200 }, { month: '2024-11', amount: 136850 }, { month: '2024-12', amount: 140100 },
    ] },
  { id: 'vnd2', vendor: 'Cotiviti', costPlanNumber: 'CP-2024-302', description: 'Post-pay Payment Integrity Recovery Audit', vendorFeePct: null,
    monthlyScaledActuals: [
      { month: '2024-01', amount: 64200 }, { month: '2024-02', amount: 58750 }, { month: '2024-03', amount: 71300 },
      { month: '2024-04', amount: 69800 }, { month: '2024-05', amount: 73450 }, { month: '2024-06', amount: 76100 },
      { month: '2024-07', amount: 78400 }, { month: '2024-08', amount: 74950 }, { month: '2024-09', amount: 80200 },
      { month: '2024-10', amount: 82650 }, { month: '2024-11', amount: 79800 }, { month: '2024-12', amount: 85300 },
    ] },
  { id: 'vnd3', vendor: 'Optum Payment Integrity', costPlanNumber: 'CP-2024-303', description: 'Clinical Coding Validation', vendorFeePct: 3.5,
    monthlyScaledActuals: [
      { month: '2024-01', amount: 42800 }, { month: '2024-02', amount: 45100 }, { month: '2024-03', amount: 43950 },
      { month: '2024-04', amount: 47200 }, { month: '2024-05', amount: 48600 }, { month: '2024-06', amount: 50300 },
      { month: '2024-07', amount: 51850 }, { month: '2024-08', amount: 53200 }, { month: '2024-09', amount: 52400 },
      { month: '2024-10', amount: 54900 }, { month: '2024-11', amount: 56100 }, { month: '2024-12', amount: 57650 },
    ] },
];

function parseFeePct(raw) {
  const s = raw.trim().replace(/%$/, '').trim();
  if (!s) return { value: null };
  if (s.startsWith('-')) return { value: null, error: 'Vendor Fee % cannot be negative.' };
  if (!/^(\d+\.?\d*|\.\d+)$/.test(s)) return { value: null, error: 'Enter a percentage, e.g. 5 or 5.25.' };
  const n = parseFloat(s);
  if (n > 100) return { value: null, error: 'Vendor Fee % cannot exceed 100%.' };
  return { value: n };
}

const fmtMoney = (n) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
const calcVendorFee = (amount, pct) => Math.round(amount * pct) / 100;
const fmtWhole = (n) => `$${Math.round(n).toLocaleString('en-US')}`;
const vHead = { padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' };
const vCell = { padding: '10px 12px', textAlign: 'right', verticalAlign: 'middle', whiteSpace: 'nowrap' };

function SavingsFeeCell({ savings, fee, bold = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, lineHeight: 1.4, fontFamily: 'monospace' }}>
      <span title={savings == null ? undefined : fmtMoney(savings)} style={{ fontSize: 11, fontWeight: bold ? 700 : 500, color: savings == null ? '#d1d5db' : '#1f2937' }}>
        {savings == null ? '—' : fmtWhole(savings)}
      </span>
      <span title={fee == null ? undefined : fmtMoney(fee)} style={{ fontSize: 11, fontWeight: bold ? 700 : 500, color: fee == null ? '#d1d5db' : '#2861BB' }}>
        {fee == null ? '—' : fmtWhole(fee)}
      </span>
    </div>
  );
}

function MeasureLabels({ bold = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, lineHeight: 1.4, whiteSpace: 'nowrap' }}>
      <span style={{ fontSize: 11, fontWeight: bold ? 700 : 600, color: '#1f2937' }}>Scaled Savings</span>
      <span style={{ fontSize: 11, fontWeight: bold ? 700 : 600, color: '#2861BB' }}>Vendor Fee</span>
    </div>
  );
}

const fmtCost = (n) => n === 0 ? '—' : `$${n.toLocaleString()}`;

// ── Cost category section wrapper ────────────────────────────────────────────
function CostSection({ id, title, subtitle, icon: Icon, total, accent, tint, defaultOpen = false, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section id={`cost-${id}`} className="rounded-xl overflow-hidden scroll-mt-20" style={{ border: `1px solid ${accent}40`, background: tint }}>
      <button type="button" onClick={() => setOpen(o => !o)} aria-expanded={open}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:brightness-110 transition" style={{ background: accent }}>
        <ChevronDown size={16} className="text-white transition-transform" style={{ transform: open ? 'rotate(0deg)' : 'rotate(-90deg)' }} />
        <Icon size={16} className="text-white" />
        <div className="flex-1">
          <p className="text-sm font-bold text-white uppercase tracking-wider">{title}</p>
          <p className="text-[10px] text-white/80">{subtitle}</p>
        </div>
        <div className="text-right">
          <p className="text-[9px] text-white/70 uppercase tracking-wider">Subtotal</p>
          <p className="text-sm font-bold font-mono text-white">{fmtCost(total)}</p>
        </div>
      </button>
      {open && <div className="p-4 space-y-4">{children}</div>}
    </section>
  );
}

// ── Cost Distribution Panel ───────────────────────────────────────────────────
function CostDistributionPanel({ total, meta, colSpan, onSave }) {
  // Fully local draft — completely decoupled from parent. Only committed on Save.
  const [draft, setDraft] = useState(() => ({ ...meta, periods: meta.periods.map(p => ({ ...p })) }));
  // String inputs for manual period amounts (avoids controlled-input blocking mid-type)
  const [amtDrafts, setAmtDrafts] = useState(() => meta.periods.map(p => p.amount === 0 ? '' : String(p.amount)));
  const [dirty, setDirty] = useState(false);

  // When the row's saved meta changes externally (e.g. parent reset), re-sync
  const metaRef = useRef(meta);
  useEffect(() => {
    // Only re-sync if meta changed from outside (not from our own save)
    if (metaRef.current !== meta) {
      metaRef.current = meta;
      setDraft({ ...meta, periods: meta.periods.map(p => ({ ...p })) });
      setAmtDrafts(meta.periods.map(p => p.amount === 0 ? '' : String(p.amount)));
      setDirty(false);
    }
  }, [meta]);

  const patch = (p) => {
    setDraft(prev => {
      const next = { ...prev, ...p };
      // Rebuild periods whenever timeframe or distribution mode changes
      if ('timeframeStart' in p || 'timeframeEnd' in p || 'distribution' in p) {
        next.periods = buildPeriods(next.timeframeStart, next.timeframeEnd, total, next.distribution, prev.periods);
        if (next.distribution === 'manual') {
          setAmtDrafts(next.periods.map(pp => pp.amount === 0 ? '' : String(pp.amount)));
        }
      }
      return next;
    });
    setDirty(true);
  };

  const handleAmtChange = (i, raw) => {
    const next = [...amtDrafts];
    next[i] = raw;
    setAmtDrafts(next);
    const num = parseFloat(raw);
    setDraft(prev => {
      const periods = prev.periods.map((p, pi) => pi === i ? { ...p, amount: isNaN(num) ? 0 : num } : p);
      return { ...prev, periods };
    });
    setDirty(true);
  };

  const handleSave = () => {
    // Flush any empty amtDraft strings → 0 before saving
    const finalPeriods = draft.periods.map((p, i) => ({
      ...p,
      amount: amtDrafts[i] !== undefined ? (parseFloat(amtDrafts[i]) || 0) : p.amount,
    }));
    const finalMeta = { ...draft, periods: finalPeriods };
    metaRef.current = finalMeta; // mark as internal update so useEffect doesn't re-sync
    onSave(finalMeta);
    setDirty(false);
  };

  const handleDiscard = () => {
    setDraft({ ...meta, periods: meta.periods.map(p => ({ ...p })) });
    setAmtDrafts(meta.periods.map(p => p.amount === 0 ? '' : String(p.amount)));
    setDirty(false);
  };

  const periodTotal = draft.periods.reduce((s, p) => s + p.amount, 0);
  const diff = Math.round((total - periodTotal) * 100) / 100;

  return (
    <tr style={{ background: '#F0F9FF' }}>
      <td colSpan={colSpan} style={{ padding: 0, borderBottom: '2px solid #BAE6FD' }}>
        <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* ── Header bar: title + dirty Save/Discard buttons ── */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Calendar size={12} style={{ color: '#2861BB' }} />
              <span style={{ fontSize: 11, fontWeight: 700, color: '#1A3673', letterSpacing: 0.3 }}>Cost Distribution</span>
              {dirty && (
                <span style={{ fontSize: 9, fontWeight: 700, color: '#D97706', background: '#FEF3C7', border: '1px solid #FDE68A', borderRadius: 999, padding: '1px 7px', letterSpacing: 0.3 }}>
                  UNSAVED
                </span>
              )}
            </div>
            {dirty && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <button onClick={handleDiscard}
                  style={{ fontSize: 10, fontWeight: 600, padding: '3px 12px', borderRadius: 6, cursor: 'pointer', border: '1px solid #D1D5DB', background: '#fff', color: '#6B7280' }}>
                  Discard
                </button>
                <button onClick={handleSave}
                  style={{ fontSize: 10, fontWeight: 700, padding: '3px 14px', borderRadius: 6, cursor: 'pointer', border: '1px solid #1A3673', background: '#1A3673', color: '#fff' }}>
                  Save Changes
                </button>
              </div>
            )}
          </div>

          {/* ── Controls row ── */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8 }}>Cost Type</span>
              <select className="form-select text-xs" value={draft.costType}
                onChange={e => patch({ costType: e.target.value })}>
                <option>One-time</option><option>Recurring</option>
              </select>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8 }}>From</span>
              <input type="month" className="form-select text-xs w-32" value={draft.timeframeStart}
                onChange={e => patch({ timeframeStart: e.target.value })} />
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600 }}>To</span>
              <input type="month" className="form-select text-xs w-32" value={draft.timeframeEnd}
                onChange={e => patch({ timeframeEnd: e.target.value })} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 10, color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8 }}>Method</span>
              <button onClick={() => patch({ distribution: 'equal' })}
                style={{ fontSize: 10, fontWeight: 600, padding: '3px 12px', borderRadius: 6, cursor: 'pointer', border: `1px solid ${draft.distribution === 'equal' ? '#1A3673' : '#D1D5DB'}`, background: draft.distribution === 'equal' ? '#1A3673' : '#fff', color: draft.distribution === 'equal' ? '#fff' : '#6B7280' }}>
                Spread Equally
              </button>
              <button onClick={() => patch({ distribution: 'manual' })}
                style={{ fontSize: 10, fontWeight: 600, padding: '3px 12px', borderRadius: 6, cursor: 'pointer', border: `1px solid ${draft.distribution === 'manual' ? '#1A3673' : '#D1D5DB'}`, background: draft.distribution === 'manual' ? '#1A3673' : '#fff', color: draft.distribution === 'manual' ? '#fff' : '#6B7280' }}>
                Enter Manually
              </button>
            </div>
          </div>

          {/* ── Period grid ── */}
          {draft.periods.length === 0 ? (
            <p style={{ fontSize: 10, color: '#9CA3AF', fontStyle: 'italic', margin: 0 }}>
              Set a From and To month above to generate the distribution schedule.
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'flex-end', flexWrap: 'wrap', gap: 8 }}>
                {draft.periods.map((p, i) => (
                  <div key={p.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
                    <span style={{ fontSize: 9, color: '#6B7280', fontWeight: 600, whiteSpace: 'nowrap' }}>{fmtPeriod(p.label)}</span>
                    {draft.distribution === 'equal' ? (
                      <span style={{ fontSize: 10, fontFamily: 'monospace', color: '#1A3673', fontWeight: 700, background: '#DBEAFE', border: '1px solid #BFDBFE', borderRadius: 5, padding: '3px 8px', whiteSpace: 'nowrap', minWidth: 72, textAlign: 'center', display: 'block' }}>
                        ${p.amount.toLocaleString()}
                      </span>
                    ) : (
                      <input
                        type="number" min={0}
                        className="form-select text-xs text-right"
                        style={{ width: 88, fontFamily: 'monospace', background: '#fff', border: '1px solid #93C5FD' }}
                        value={amtDrafts[i] ?? ''}
                        placeholder="0.00"
                        onChange={e => handleAmtChange(i, e.target.value)}
                        onBlur={() => {
                          if (!amtDrafts[i]) {
                            const next = [...amtDrafts]; next[i] = '';
                            setAmtDrafts(next);
                          }
                        }}
                      />
                    )}
                  </div>
                ))}
              </div>

              {/* Allocation summary bar */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 6, fontSize: 10 }}>
                <span style={{ color: '#6B7280' }}>Allocated: <strong style={{ fontFamily: 'monospace', color: '#1A3673' }}>${periodTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong></span>
                <span style={{ color: '#CBD5E1' }}>|</span>
                <span style={{ color: '#6B7280' }}>Total: <strong style={{ fontFamily: 'monospace', color: '#1A3673' }}>${total.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong></span>
                <span style={{ color: '#CBD5E1' }}>|</span>
                {diff === 0 && draft.periods.length > 0 ? (
                  <span style={{ fontWeight: 700, color: '#16A34A' }}>✓ Fully allocated</span>
                ) : diff > 0 ? (
                  <span style={{ fontWeight: 700, color: '#DC2626' }}>${diff.toLocaleString('en-US', { minimumFractionDigits: 2 })} remaining</span>
                ) : (
                  <span style={{ fontWeight: 700, color: '#7C3AED' }}>${Math.abs(diff).toLocaleString('en-US', { minimumFractionDigits: 2 })} over budget</span>
                )}
              </div>
            </div>
          )}

        </div>
      </td>
    </tr>
  );
}

export default function CostPlanTab({ coversheet, onEdit }) {
  const { can } = useAuth();
  const { showToast } = useToast();
  const canEdit = can('edit_cost_plan');

  // LOE state
  const [loeRows, setLoeRows] = useState(DEFAULT_LOE);

  // IT state
  const [itRows] = useState(DEFAULT_IT);

  // FTE state
  const [fteRows, setFteRows] = useState(DEFAULT_FTE);

  // LOE add state
  const [addingLoe, setAddingLoe] = useState(false);
  const [newLoe, setNewLoe] = useState({ costPlanNumber: '', sizing: '', bdm: '', timber: '', estimate: 0, opsMaintenanceCost: 0, totalCost: 0, projectNumber: '', notes: '' });

  // FTE add state
  const [addingFteSection, setAddingFteSection] = useState(null);
  const [newFte, setNewFte] = useState(BLANK_FTE('G&A'));

  // ── Per-section search + filter state ────────────────────────────────────────
  // Each section: { search: '', filterOpen: false, pending: {...}, active: {...} }
  const BLANK_LOE_F = { sizing: '', timber: '', costPlanNumber: '' };
  const BLANK_FTE_F = { onshoreOffshore: '', cocNonCoc: '', caOnly: '', costPlanNumber: '' };
  const BLANK_OTH_F = { category: '', costType: '', costPlanNumber: '' };
  const BLANK_VND_F = { vendor: '' };

  const [cpSearch,     setCpSearch]     = useState({ loe: '', fte: '', oth: '', vnd: '' });
  const [cpFilterOpen, setCpFilterOpen] = useState({ loe: false, fte: false, oth: false, vnd: false });
  const [cpPending,    setCpPending]    = useState({ loe: { ...BLANK_LOE_F }, fte: { ...BLANK_FTE_F }, oth: { ...BLANK_OTH_F }, vnd: { ...BLANK_VND_F } });
  const [cpActive,     setCpActive]     = useState({ loe: { ...BLANK_LOE_F }, fte: { ...BLANK_FTE_F }, oth: { ...BLANK_OTH_F }, vnd: { ...BLANK_VND_F } });

  const cpOpenFilter  = (sec) => { setCpPending(p => ({ ...p, [sec]: { ...cpActive[sec] } })); setCpFilterOpen(p => ({ ...p, [sec]: true })); };
  const cpCloseFilter = (sec) => { setCpPending(p => ({ ...p, [sec]: { ...cpActive[sec] } })); setCpFilterOpen(p => ({ ...p, [sec]: false })); };
  const cpApply       = (sec) => { setCpActive(p => ({ ...p, [sec]: { ...cpPending[sec] } })); setCpFilterOpen(p => ({ ...p, [sec]: false })); };
  const cpClearAll    = (sec, blank) => { setCpActive(p => ({ ...p, [sec]: { ...blank } })); setCpPending(p => ({ ...p, [sec]: { ...blank } })); setCpFilterOpen(p => ({ ...p, [sec]: false })); setCpSearch(p => ({ ...p, [sec]: '' })); };
  const cpPatch       = (sec, field, val) => setCpPending(p => ({ ...p, [sec]: { ...p[sec], [field]: val } }));
  const cpActiveCount = (sec) => Object.values(cpActive[sec]).filter(v => v !== '').length;

  // Others state
  const [otherRows, setOtherRows] = useState(DEFAULT_OTHERS);
  const [newOther, setNewOther] = useState({ costPlanNumber: '', category: '', description: '', vendor: '', costType: 'One-time', amount: 0, timeline: '', notes: '', costMeta: { ...DEFAULT_COST_META } });
  const [addingOther, setAddingOther] = useState(false);

  // Vendor state — feeDrafts hold raw input text; only valid values are stored on the plan
  const [vendorPlans, setVendorPlans] = useState(DEFAULT_VENDOR_PLANS);
  const [feeDrafts, setFeeDrafts] = useState({});
  const feeDraftOf = (p) => feeDrafts[p.id] ?? (p.vendorFeePct == null ? '' : String(p.vendorFeePct));
  const handleFeeChange = (id, raw) => {
    setFeeDrafts(d => ({ ...d, [id]: raw }));
    const { value, error } = parseFeePct(raw);
    if (error) return;
    setVendorPlans(ps => ps.map(p => p.id === id ? { ...p, vendorFeePct: value } : p));
    onEdit();
  };

  // Expanded rows for cost distribution panels (keyed by row id)
  const [expandedRows, setExpandedRows] = useState(new Set());
  const toggleExpand = useCallback((id) => setExpandedRows(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  }), []);

  // Save full CostMeta for a row (called from CostDistributionPanel on Save Changes)
  const saveLoeMeta = useCallback((id, m) => { setLoeRows(prev => prev.map(r => r.id === id ? { ...r, costMeta: m } : r)); onEdit(); }, [onEdit]);
  const saveFteMeta = useCallback((id, m) => { setFteRows(prev => prev.map(r => r.id === id ? { ...r, costMeta: m } : r)); onEdit(); }, [onEdit]);
  const saveOthMeta = useCallback((id, m) => { setOtherRows(prev => prev.map(r => r.id === id ? { ...r, costMeta: m } : r)); onEdit(); }, [onEdit]);

  // ── Filtered data per section ─────────────────────────────────────────────────
  const applyFilter = (rows, sec, fields) => {
    const q = cpSearch[sec].trim().toLowerCase();
    const act = cpActive[sec];
    return rows.filter(r => {
      const matchSearch = !q || fields.some(f => String(r[f] ?? '').toLowerCase().includes(q));
      const matchFilters = Object.entries(act).every(([k, v]) => !v || String(r[k] ?? '') === v);
      return matchSearch && matchFilters;
    });
  };

  const filteredLoe = applyFilter(loeRows,    'loe', ['costPlanNumber', 'sizing', 'bdm', 'notes', 'projectNumber']);
  const filteredOth = applyFilter(otherRows,  'oth', ['costPlanNumber', 'category', 'description', 'vendor', 'costType', 'notes']);

  if (!canEdit) {
    return (
      <div className="flex flex-col items-center justify-center h-48 gap-3">
        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">🔒</div>
        <p className="text-sm text-gray-500">You don't have access to the Cost Plan tab.</p>
        <p className="text-xs text-gray-400">Access: Demand Manager, Financial Analyst, Governance, Admin</p>
      </div>
    );
  }

  // ── Toolbar helper ────────────────────────────────────────────────────────────
  const SectionToolbar = ({ sec, placeholder }) => {
    const srch = cpSearch[sec];
    const cnt  = cpActiveCount(sec);
    return (
      <div style={{ margin:'0 0 0 0', padding:'8px 16px', background:'#fafafa', borderBottom:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ position:'relative', flex:'0 1 300px' }}>
            <Search size={13} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
            <input type="text" value={srch}
              onChange={e => setCpSearch(p => ({ ...p, [sec]: e.target.value }))}
              placeholder={placeholder}
              style={{ width:'100%', paddingLeft:28, paddingRight: srch ? 26 : 10, paddingTop:5, paddingBottom:5, fontSize:12, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
              onFocus={e => e.target.style.borderColor='#1A3673'}
              onBlur={e => e.target.style.borderColor='#d1d5db'} />
            {srch && (
              <button onClick={() => setCpSearch(p => ({ ...p, [sec]: '' }))}
                style={{ position:'absolute', right:7, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                <X size={12} />
              </button>
            )}
          </div>
          <button onClick={() => cpOpenFilter(sec)}
            style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'5px 12px', cursor:'pointer', position:'relative' }}>
            <Filter size={12} />
            {cnt > 0 && (
              <span style={{ position:'absolute', top:-5, right:-5, background:'#E3725F', color:'#fff', fontSize:9, fontWeight:700, borderRadius:999, padding:'2px 6px', minWidth:18, textAlign:'center' }}>{cnt}</span>
            )}
          </button>
        </div>
        {(cnt > 0 || srch) && (
          <button onClick={() => cpClearAll(sec, sec === 'loe' ? BLANK_LOE_F : sec === 'fte' ? BLANK_FTE_F : sec === 'oth' ? BLANK_OTH_F : BLANK_VND_F)}
            style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'4px 10px', cursor:'pointer' }}>
            <X size={10} /> Clear All
          </button>
        )}
      </div>
    );
  };

  const itTotal     = itRows.reduce((s, r) => s + r.totalCost, 0);
  const fteTotal    = fteRows.reduce((s, r) => s + r.cost, 0);
  const othersTotal = otherRows.reduce((s, r) => s + r.amount, 0);
  const grandTotal  = itTotal + fteTotal + othersTotal;

  const hasIt  = loeRows.length > 0 || itRows.length > 0;
  const hasFte = fteRows.length > 0;
  const hasOth = otherRows.length > 0;
  const hasVnd = vendorPlans.length > 0;

  const filteredVendorPlans = applyFilter(vendorPlans, 'vnd', ['vendor', 'costPlanNumber', 'description']);

  const vendorGroups = [...new Set(filteredVendorPlans.map(p => p.vendor))].map(vendor => ({
    vendor,
    plans: filteredVendorPlans.filter(p => p.vendor === vendor).map(p => {
      const { value: pct, error } = parseFeePct(feeDraftOf(p));
      const months = [...p.monthlyScaledActuals].sort((a, b) => a.month.localeCompare(b.month));
      const totalActual = months.reduce((s, m) => s + m.amount, 0);
      const totalFee = pct == null || error ? null : months.reduce((s, m) => s + calcVendorFee(m.amount, pct), 0);
      return { plan: p, pct: error ? null : pct, error, months, totalActual, totalFee };
    }),
  }));
  const vendorActualTotal = vendorGroups.reduce((s, g) => s + g.plans.reduce((a, p) => a + p.totalActual, 0), 0);
  const vendorFeeTotal    = vendorGroups.reduce((s, g) => s + g.plans.reduce((a, p) => a + (p.totalFee ?? 0), 0), 0);
  const vendorYears  = [...new Set(filteredVendorPlans.flatMap(p => p.monthlyScaledActuals.map(m => m.month.slice(0, 4))))].sort();
  const vendorMonths = vendorYears.flatMap(y => Array.from({ length: 12 }, (_, i) => `${y}-${String(i + 1).padStart(2, '0')}`));
  const vendorPlanRows = vendorGroups.flatMap(g => g.plans);
  const savingsFor = (months, month) => months.find(m => m.month === month)?.amount;
  const vendorMonthSavings = vendorMonths.map(mo => vendorPlanRows.reduce((s, p) => s + (savingsFor(p.months, mo) ?? 0), 0));
  const vendorMonthFees    = vendorMonths.map(mo => vendorPlanRows.reduce((s, p) => {
    const amt = savingsFor(p.months, mo);
    return s + (amt == null || p.pct == null ? 0 : calcVendorFee(amt, p.pct));
  }, 0));
  const V_W    = { vendor: 120, plan: 170, fee: 96, measure: 130, total: 116 };
  const V_LEFT = { vendor: 0, plan: 120, fee: 290, measure: 386, total: 516 };
  const vStick = (col, bg, z = 5, edge = '#e5e7eb') => ({
    position: 'sticky', left: V_LEFT[col], zIndex: z, background: bg,
    width: V_W[col], minWidth: V_W[col], maxWidth: V_W[col],
    ...(col === 'total' ? { boxShadow: `inset -2px 0 0 ${edge}` } : {}),
  });
  const V_FOOT_BG = '#EEF1F6';
  return (
    <div className="space-y-4">

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-3">
        {([
          { id: 'it',  label: 'IT Expense',  value: fmtCost(itTotal),     icon: DollarSign,      color: 'text-[#2861BB]', bg: 'bg-[#E1EDFF]', ring: 'hover:border-[#2861BB]' },
          { id: 'fte', label: 'FTE Expense', value: fmtCost(fteTotal),    icon: Users,           color: 'text-[#00BBBA]', bg: 'bg-teal-50',   ring: 'hover:border-[#00BBBA]' },
          { id: 'oth', label: 'Others',      value: fmtCost(othersTotal), icon: FileSpreadsheet, color: 'text-[#7c3aed]', bg: 'bg-purple-50', ring: 'hover:border-[#7c3aed]' },
        ]).map(k => {
          return (
            <button key={k.id} onClick={() => document.getElementById(`cost-${k.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
              title={`Jump to ${k.label}`}
              className={`${k.bg} rounded-lg border border-gray-100 p-3 text-left transition ${k.ring} hover:shadow-sm`}>
              <p className={`flex items-center gap-1 text-[10px] font-semibold mb-1 ${k.color}`}><k.icon size={11} /> {k.label}</p>
              <p className={`text-sm font-bold ${k.color}`}>{k.value}</p>
            </button>
          );
        })}
        <div className="bg-red-50 rounded-lg border border-gray-100 p-3">
          <p className="text-[10px] text-gray-500 mb-1">Total Costs</p>
          <p className="text-sm font-bold text-[#E3725F]">{fmtCost(grandTotal)}</p>
        </div>
      </div>

      {/* ═══════════ 1. IT EXPENSE ═══════════ */}
      {hasIt && (
      <CostSection id="it"  title="IT Expense"  subtitle="Level of Effort estimates and IT cost summary" icon={DollarSign}      total={itTotal}     accent="#2861BB" tint="#F5F9FF">
          {/* Instructions banner */}
          <div className="flex items-start gap-2 px-4 py-3 bg-[#E3F4FD] border border-[#C7EAFB] rounded-lg text-xs text-gray-600">
            <Info size={13} className="text-[#2861BB] flex-shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p>IT Costs listed in the <strong>CoCVR</strong> tab must link to totals on this tab.</p>
              <p>Include either a Level of Effort (LOE) estimate below or a summary of costs with a screenshot of the related costs.</p>
            </div>
          </div>

          {/* ── LOE Table ─────────────────────────────────────────────── */}
          <div className="card overflow-hidden">
            <div className="card-header">
              <div>
                <div className="card-title">LOE per your request</div>
                <p className="text-[10px] text-gray-400 mt-0.5">Level of Effort estimate detail</p>
              </div>
              {canEdit && (
                <button onClick={() => setAddingLoe(true)}
                  className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition">
                  <Plus size={11} /> Add Row
                </button>
              )}
            </div>

            <SectionToolbar sec="loe" placeholder="Search cost plan, sizing, notes…" />

            {/* LOE filter modal */}
            {cpFilterOpen.loe && (
              <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
                onClick={() => cpCloseFilter('loe')}>
                <div style={{ background:'#fff', borderRadius:12, maxWidth:600, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
                  onClick={e => e.stopPropagation()}>
                  <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — LOE</span></div>
                    <button onClick={() => cpCloseFilter('loe')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
                  </div>
                  <div style={{ padding:20, display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:14 }}>
                    <div>
                      <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                      <input type="text" value={cpPending.loe.costPlanNumber} onChange={e => cpPatch('loe','costPlanNumber',e.target.value)} placeholder="Search…"
                        style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }} />
                    </div>
                    <div>
                      <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Sizing</label>
                      <select value={cpPending.loe.sizing} onChange={e => cpPatch('loe','sizing',e.target.value)}
                        style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                        <option value="">All</option>
                        {[...new Set(loeRows.map(r => r.sizing).filter(Boolean))].sort().map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Timber</label>
                      <select value={cpPending.loe.timber} onChange={e => cpPatch('loe','timber',e.target.value)}
                        style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                        <option value="">All</option><option value="Y">Y</option><option value="N">N</option>
                      </select>
                    </div>
                  </div>
                  <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                    <button onClick={() => cpPatch('loe', 'sizing', '') || cpPatch('loe', 'timber', '') || cpPatch('loe', 'costPlanNumber', '') || setCpPending(p => ({ ...p, loe: { ...BLANK_LOE_F } }))}
                      style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                    <div style={{ display:'flex', gap:8 }}>
                      <button onClick={() => cpCloseFilter('loe')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                      <button onClick={() => cpApply('loe')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div style={{ overflowX: 'auto' }}>
              <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
                <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                  <tr style={{ background: '#1A3673', height: 32 }}>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Number</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Sizing</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>BDM</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Timber</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Estimate</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Ops, Maintenance &amp; Support</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Total Cost</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Type</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Project #</th>
                    <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Notes</th>
                    <th style={{ padding: '0 10px', width: 20 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLoe.length === 0 && !addingLoe ? (
                    <tr><td colSpan={11} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No LOE rows match the current filters. <button onClick={() => cpClearAll('loe', BLANK_LOE_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                  ) : filteredLoe.map((r, i) => [
                    <tr key={r.id} style={{ height: 28, background: i % 2 === 0 ? '#fff' : '#EFF6FF', borderBottom: '1px solid #f3f4f6' }}>
                      <td className="table-td" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>{r.costPlanNumber || '—'}</td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.sizing || '—'}</td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.bdm || '—'}</td>
                      <td className="table-td" style={{ textAlign: 'center' }}>
                        {r.timber
                          ? <span style={{ fontSize: 10, fontWeight: 700, padding: '1px 8px', borderRadius: 999, background: r.timber === 'Y' ? '#f0fdf4' : '#fef2f2', color: r.timber === 'Y' ? '#16a34a' : '#dc2626', border: `1px solid ${r.timber === 'Y' ? '#86efac' : '#fca5a5'}` }}>{r.timber}</span>
                          : <span style={{ color: '#d1d5db' }}>—</span>}
                      </td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', color: '#9ca3af', whiteSpace: 'nowrap' }}>
                        {r.estimate === 0 ? '—' : `$${r.estimate.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', color: '#9ca3af', whiteSpace: 'nowrap' }}>
                        {r.opsMaintenanceCost === 0 ? '—' : `$${r.opsMaintenanceCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                        {r.totalCost === 0 ? '—' : `$${r.totalCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                      </td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                        <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.costMeta.costType === 'Recurring' ? '#FEF3C7' : '#F0FDF4', color: r.costMeta.costType === 'Recurring' ? '#92400E' : '#15803D', border: `1px solid ${r.costMeta.costType === 'Recurring' ? '#FDE68A' : '#86EFAC'}` }}>{r.costMeta.costType}</span>
                      </td>
                      <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.projectNumber || '—'}</td>
                      <td className="table-td" style={{ maxWidth: 220 }}>
                        <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#4b5563' }} title={r.notes}>{r.notes || '—'}</span>
                      </td>
                      <td className="table-td" style={{ textAlign: 'center', width: 48, whiteSpace: 'nowrap' }}>
                        <button onClick={() => toggleExpand(r.id)} title="Cost distribution"
                          style={{ color: expandedRows.has(r.id) ? '#2861BB' : '#d1d5db', background: 'none', border: 'none', cursor: 'pointer', marginRight: 4 }}
                          onMouseEnter={e => (e.currentTarget.style.color = '#2861BB')}
                          onMouseLeave={e => (e.currentTarget.style.color = expandedRows.has(r.id) ? '#2861BB' : '#d1d5db')}>
                          <Calendar size={12} />
                        </button>
                        <button onClick={() => { setLoeRows(p => p.filter(x => x.id !== r.id)); onEdit(); }}
                          style={{ color: '#d1d5db', background: 'none', border: 'none', cursor: 'pointer' }}
                          onMouseEnter={e => (e.currentTarget.style.color = '#E3725F')}
                          onMouseLeave={e => (e.currentTarget.style.color = '#d1d5db')}>
                          <Trash2 size={12} />
                        </button>
                      </td>
                    </tr>,
                    expandedRows.has(r.id) && (
                      <CostDistributionPanel key={`${r.id}-dist`} rowId={r.id} rowType="loe" total={r.totalCost} meta={r.costMeta} colSpan={11}
                        onSave={m => saveLoeMeta(r.id, m)} />
                    ),
                  ])}
                  {addingLoe && (
                    <tr style={{ background: '#EFF6FF', borderBottom: '2px solid #93c5fd' }}>
                      <td className="table-td"><input className="form-select text-xs w-28" placeholder="Cost Plan #" value={newLoe.costPlanNumber} onChange={e => setNewLoe(p => ({ ...p, costPlanNumber: e.target.value }))} /></td>
                      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Sizing" value={newLoe.sizing} onChange={e => setNewLoe(p => ({ ...p, sizing: e.target.value }))} /></td>
                      <td className="table-td"><input className="form-select text-xs w-16" placeholder="BDM" value={newLoe.bdm} onChange={e => setNewLoe(p => ({ ...p, bdm: e.target.value }))} /></td>
                      <td className="table-td">
                        <select className="form-select text-xs w-16" value={newLoe.timber} onChange={e => setNewLoe(p => ({ ...p, timber: e.target.value }))}>
                          <option value="">—</option><option>Y</option><option>N</option>
                        </select>
                      </td>
                      <td className="table-td"><input type="number" className="form-select text-xs w-24 text-right" placeholder="0" value={newLoe.estimate || ''} onChange={e => setNewLoe(p => { const est = parseFloat(e.target.value)||0; return { ...p, estimate: est, totalCost: est + p.opsMaintenanceCost }; })} /></td>
                      <td className="table-td"><input type="number" className="form-select text-xs w-28 text-right" placeholder="0" value={newLoe.opsMaintenanceCost || ''} onChange={e => setNewLoe(p => { const ops = parseFloat(e.target.value)||0; return { ...p, opsMaintenanceCost: ops, totalCost: p.estimate + ops }; })} /></td>
                      <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>{newLoe.totalCost > 0 ? `$${newLoe.totalCost.toLocaleString()}` : '—'}</td>
                      <td className="table-td"><input className="form-select text-xs w-24" placeholder="Project #" value={newLoe.projectNumber} onChange={e => setNewLoe(p => ({ ...p, projectNumber: e.target.value }))} /></td>
                      <td className="table-td"><input className="form-select text-xs w-36" placeholder="Notes" value={newLoe.notes} onChange={e => setNewLoe(p => ({ ...p, notes: e.target.value }))} /></td>
                      <td className="table-td" colSpan={2} style={{ whiteSpace: 'nowrap' }}>
                        <button onClick={() => { setLoeRows(p => [...p, { ...newLoe, id: `loe${Date.now()}` }]); setNewLoe({ costPlanNumber: '', sizing: '', bdm: '', timber: '', estimate: 0, opsMaintenanceCost: 0, totalCost: 0, projectNumber: '', notes: '', costMeta: { ...DEFAULT_COST_META } }); setAddingLoe(false); onEdit(); }} className="text-[10px] font-bold text-white bg-[#00BBBA] rounded px-2 py-0.5 mr-1 hover:bg-[#00a8a7]">Save</button>
                        <button onClick={() => setAddingLoe(false)} className="text-[10px] font-medium text-gray-400 hover:text-gray-600">Cancel</button>
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot>
                  <tr style={{ height: 30, background: 'rgba(26,54,115,0.07)', borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                    <td colSpan={6} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673' }}>TOTAL ({loeRows.length} row{loeRows.length !== 1 ? 's' : ''})</td>
                    <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                      ${loeRows.reduce((s, r) => s + r.totalCost, 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td colSpan={4}></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

      </CostSection>
      )}

      {/* ═══════════ 2. FTE REQUEST ═══════════ */}
      {hasFte && (
      <CostSection id="fte" title="FTE Expense" subtitle="Resource requests by department — G&A, CCCR, Claims Ops" icon={Users}           total={fteTotal}    accent="#2861BB" tint="#F5F9FF">
          <div className="flex items-start gap-2 px-4 py-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-gray-700">
            <Info size={13} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-800">FTE Estimates — ALL EVALUATIONS COMPLETED — No FTEs NEEDED</p>
              <p className="mt-0.5 text-gray-600">Reference the PI-Medical Edits Resource Evaluation Process</p>
            </div>
          </div>

          {/* FTE filter modal (shared across all FTE sub-sections) */}
          {cpFilterOpen.fte && (
            <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
              onClick={() => cpCloseFilter('fte')}>
              <div style={{ background:'#fff', borderRadius:12, maxWidth:640, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
                onClick={e => e.stopPropagation()}>
                <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — FTE</span></div>
                  <button onClick={() => cpCloseFilter('fte')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
                </div>
                <div style={{ padding:20, display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:14 }}>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                    <input type="text" value={cpPending.fte.costPlanNumber} onChange={e => cpPatch('fte','costPlanNumber',e.target.value)} placeholder="Search…"
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }} />
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Onshore / Offshore</label>
                    <select value={cpPending.fte.onshoreOffshore} onChange={e => cpPatch('fte','onshoreOffshore',e.target.value)}
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                      <option value="">All</option><option value="Onshore">Onshore</option><option value="Offshore">Offshore</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>CoC / Non-CoC</label>
                    <select value={cpPending.fte.cocNonCoc} onChange={e => cpPatch('fte','cocNonCoc',e.target.value)}
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                      <option value="">All</option><option value="CoC">CoC</option><option value="Non-CoC">Non-CoC</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>CA Only</label>
                    <select value={cpPending.fte.caOnly} onChange={e => cpPatch('fte','caOnly',e.target.value)}
                      style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                      <option value="">All</option><option value="CA-Only">CA-Only</option><option value="Non-CA">Non-CA</option>
                    </select>
                  </div>
                </div>
                <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                  <button onClick={() => setCpPending(p => ({ ...p, fte: { ...BLANK_FTE_F } }))}
                    style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                  <div style={{ display:'flex', gap:8 }}>
                    <button onClick={() => cpCloseFilter('fte')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                    <button onClick={() => cpApply('fte')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {FTE_SECTIONS.map(section => {
            const rows = fteRows.filter(r => r.section === section);
            const sectionTotal = rows.reduce((s, r) => s + r.cost, 0);
            return (
              <div key={section} className="card overflow-hidden">
                <div className="card-header">
                  <div className="flex items-center gap-2">
                    <div className="card-title"><Users size={14} /> {section} Resource Request</div>
                    <span className="text-[10px] text-gray-400">({rows.length} row{rows.length !== 1 ? 's' : ''})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold font-mono text-[#00BBBA]">{fmtCost(sectionTotal)}</span>
                    {canEdit && (
                      <button onClick={() => { setNewFte(BLANK_FTE(section)); setAddingFteSection(section); }}
                        className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition">
                        <Plus size={11} /> Add Row
                      </button>
                    )}
                  </div>
                </div>

                {section === FTE_SECTIONS[0] && <SectionToolbar sec="fte" placeholder="Search cost plan, job title, department…" />}

                <div style={{ overflowX: 'auto' }}>
                  <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
                    <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                      <tr style={{ background: '#1A3673', height: 32 }}>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Number</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}># Positions</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Start Date / Timeline</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Job Code</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Job Title</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Department</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Approved By</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Hiring Manager</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Onshore/Offshore</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>CoC?</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>CA Only</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Cost</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Type</th>
                        <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Short Desc (SNOW)</th>
                        <th style={{ padding: '0 10px', width: 20 }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        const filteredFte = applyFilter(rows, 'fte', ['costPlanNumber', 'jobTitle', 'department', 'jobCode', 'approvedBy', 'hiringManager']);
                        const fteEmpty = filteredFte.length === 0 && addingFteSection !== section;
                        return fteEmpty ? (
                        <tr><td colSpan={15} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No rows match the current filters. <button onClick={() => cpClearAll('fte', BLANK_FTE_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                      ) : <>{filteredFte.map((r, i) => [
                        <tr key={r.id} style={{ height: 28, background: i % 2 === 0 ? '#fff' : '#EFF6FF', borderBottom: '1px solid #f3f4f6' }}>
                          <td className="table-td" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>{r.costPlanNumber || '—'}</td>
                          <td className="table-td" style={{ textAlign: 'center', color: r.positions === 0 ? '#d1d5db' : '#374151', fontFamily: 'monospace' }}>{r.positions}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.startDate || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ fontFamily: 'monospace', color: '#6b7280', whiteSpace: 'nowrap' }}>{r.jobCode || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#374151' }}>{r.jobTitle || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.department || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.approvedBy || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.hiringManager || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            {r.onshoreOffshore
                              ? <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.onshoreOffshore === 'Onshore' ? '#E3F4FD' : '#D9F5F5', color: r.onshoreOffshore === 'Onshore' ? '#2861BB' : '#00BBBA', border: `1px solid ${r.onshoreOffshore === 'Onshore' ? '#C7EAFB' : '#66D6D6'}` }}>{r.onshoreOffshore}</span>
                              : <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            {r.cocNonCoc
                              ? <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.cocNonCoc === 'CoC' ? '#f0fdfa' : '#f9fafb', color: r.cocNonCoc === 'CoC' ? '#00BBBA' : '#6b7280', border: `1px solid ${r.cocNonCoc === 'CoC' ? '#66D6D6' : '#e5e7eb'}` }}>{r.cocNonCoc}</span>
                              : <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            {r.caOnly
                              ? <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: '#fef3c7', color: '#92400e', border: '1px solid #fde68a' }}>{r.caOnly}</span>
                              : <span style={{ color: '#d1d5db' }}>—</span>}
                          </td>
                          <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: r.cost === 0 ? '#d1d5db' : '#1A3673', whiteSpace: 'nowrap' }}>
                            {r.cost === 0 ? '—' : `$${r.cost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                          </td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                            <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.costMeta.costType === 'Recurring' ? '#FEF3C7' : '#F0FDF4', color: r.costMeta.costType === 'Recurring' ? '#92400E' : '#15803D', border: `1px solid ${r.costMeta.costType === 'Recurring' ? '#FDE68A' : '#86EFAC'}` }}>{r.costMeta.costType}</span>
                          </td>
                          <td className="table-td" style={{ maxWidth: 220 }}>
                            <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#4b5563' }}>{r.snowDescription || <span style={{ color: '#d1d5db' }}>—</span>}</span>
                          </td>
                          <td className="table-td" style={{ textAlign: 'center', width: 48, whiteSpace: 'nowrap' }}>
                            <button onClick={() => toggleExpand(r.id)} title="Cost distribution"
                              style={{ color: expandedRows.has(r.id) ? '#2861BB' : '#d1d5db', background: 'none', border: 'none', cursor: 'pointer', marginRight: 4 }}
                              onMouseEnter={e => (e.currentTarget.style.color = '#2861BB')}
                              onMouseLeave={e => (e.currentTarget.style.color = expandedRows.has(r.id) ? '#2861BB' : '#d1d5db')}>
                              <Calendar size={12} />
                            </button>
                            <button onClick={() => { setFteRows(p => p.filter(x => x.id !== r.id)); onEdit(); }}
                              style={{ color: '#d1d5db', background: 'none', border: 'none', cursor: 'pointer' }}
                              onMouseEnter={e => (e.currentTarget.style.color = '#E3725F')}
                              onMouseLeave={e => (e.currentTarget.style.color = '#d1d5db')}>
                              <Trash2 size={12} />
                            </button>
                          </td>
                        </tr>,
                        expandedRows.has(r.id) && (
                          <CostDistributionPanel key={`${r.id}-dist`} rowId={r.id} rowType="fte" total={r.cost} meta={r.costMeta} colSpan={15}
                            onSave={m => saveFteMeta(r.id, m)} />
                        ),
                      ])}{addingFteSection === section && (
                        <tr style={{ background: '#D9F5F5', borderBottom: '2px solid #66D6D6' }}>
                          <td className="table-td"><input className="form-select text-xs w-28" placeholder="Cost Plan #" value={newFte.costPlanNumber} onChange={e => setNewFte(p => ({ ...p, costPlanNumber: e.target.value }))} /></td>
                          <td className="table-td"><input type="number" className="form-select text-xs w-16 text-center" placeholder="0" value={newFte.positions || ''} onChange={e => setNewFte(p => ({ ...p, positions: parseInt(e.target.value)||0 }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-24" placeholder="Start Date" value={newFte.startDate} onChange={e => setNewFte(p => ({ ...p, startDate: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-20" placeholder="Job Code" value={newFte.jobCode} onChange={e => setNewFte(p => ({ ...p, jobCode: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-28" placeholder="Job Title" value={newFte.jobTitle} onChange={e => setNewFte(p => ({ ...p, jobTitle: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-28" placeholder="Department" value={newFte.department} onChange={e => setNewFte(p => ({ ...p, department: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-24" placeholder="Approved By" value={newFte.approvedBy} onChange={e => setNewFte(p => ({ ...p, approvedBy: e.target.value }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-24" placeholder="Hiring Mgr" value={newFte.hiringManager} onChange={e => setNewFte(p => ({ ...p, hiringManager: e.target.value }))} /></td>
                          <td className="table-td"><select className="form-select text-xs w-24" value={newFte.onshoreOffshore} onChange={e => setNewFte(p => ({ ...p, onshoreOffshore: e.target.value }))}><option value="">—</option><option>Onshore</option><option>Offshore</option></select></td>
                          <td className="table-td"><select className="form-select text-xs w-20" value={newFte.cocNonCoc} onChange={e => setNewFte(p => ({ ...p, cocNonCoc: e.target.value }))}><option value="">—</option><option>CoC</option><option>Non-CoC</option></select></td>
                          <td className="table-td"><select className="form-select text-xs w-24" value={newFte.caOnly} onChange={e => setNewFte(p => ({ ...p, caOnly: e.target.value }))}><option value="">—</option><option>CA-Only</option><option>Non-CA</option></select></td>
                          <td className="table-td"><input type="number" className="form-select text-xs w-24 text-right" placeholder="Cost" value={newFte.cost || ''} onChange={e => setNewFte(p => ({ ...p, cost: parseFloat(e.target.value)||0 }))} /></td>
                          <td className="table-td"><input className="form-select text-xs w-36" placeholder="SNOW Desc" value={newFte.snowDescription} onChange={e => setNewFte(p => ({ ...p, snowDescription: e.target.value }))} /></td>
                          <td className="table-td" style={{ whiteSpace: 'nowrap' }}><button onClick={() => { setFteRows(p => [...p, { ...newFte, id: `fte${Date.now()}`, section }]); setAddingFteSection(null); onEdit(); }} className="text-[10px] font-bold text-white bg-[#00BBBA] rounded px-2 py-0.5 mr-1 hover:bg-[#00a8a7]">Save</button><button onClick={() => setAddingFteSection(null)} className="text-[10px] font-medium text-gray-400 hover:text-gray-600">Cancel</button></td>
                        </tr>
                      )}</> ;
                      })()
                      }
                    </tbody>
                    <tfoot>
                      <tr style={{ height: 30, background: 'rgba(26,54,115,0.07)', borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                        <td colSpan={11} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673' }}>TOTAL — {section} ({rows.length} row{rows.length !== 1 ? 's' : ''})</td>
                        <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: '#1A3673', whiteSpace: 'nowrap' }}>
                          {sectionTotal === 0 ? '—' : `$${sectionTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                        </td>
                        <td colSpan={3}></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            );
          })}
      </CostSection>
      )}

      {/* ═══════════ 3. VENDOR EXPENSES ═══════════ */}
      {hasVnd && (
      <CostSection id="vnd" title="Vendor Expenses" subtitle="Vendor cost plans — monthly scaled savings and calculated vendor fees" icon={Building2} total={vendorFeeTotal} accent="#2861BB" tint="#F5F9FF" defaultOpen>
        {/* Vendor filter modal */}
        {cpFilterOpen.vnd && (
          <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
            onClick={() => cpCloseFilter('vnd')}>
            <div style={{ background:'#fff', borderRadius:12, maxWidth:480, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
              onClick={e => e.stopPropagation()}>
              <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — Vendor Expenses</span></div>
                <button onClick={() => cpCloseFilter('vnd')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
              </div>
              <div style={{ padding:20 }}>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Vendor</label>
                  <select value={cpPending.vnd.vendor} onChange={e => cpPatch('vnd','vendor',e.target.value)}
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All Vendors</option>
                    {[...new Set(vendorPlans.map(p => p.vendor).filter(Boolean))].sort().map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                <button onClick={() => setCpPending(p => ({ ...p, vnd: { ...BLANK_VND_F } }))}
                  style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                <div style={{ display:'flex', gap:8 }}>
                  <button onClick={() => cpCloseFilter('vnd')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                  <button onClick={() => cpApply('vnd')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="card overflow-hidden">
          <div className="card-header" style={{ flexWrap: 'wrap', gap: 8 }}>
            <div className="flex items-center gap-2">
              <div className="card-title"><Building2 size={14} /> Vendor Cost Plans</div>
              <span className="text-[10px] text-gray-400">({filteredVendorPlans.length} plan{filteredVendorPlans.length !== 1 ? 's' : ''} · {vendorGroups.length} vendor{vendorGroups.length !== 1 ? 's' : ''})</span>
            </div>
          </div>

          <SectionToolbar sec="vnd" placeholder="Search vendor, cost plan, description…" />

          <div style={{ overflowX: 'auto' }}>
            <table className="w-full text-xs" style={{ borderCollapse: 'separate', borderSpacing: 0, minWidth: 'max-content' }}>
              <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                <tr style={{ height: 32 }}>
                  <th style={{ ...vHead, textAlign: 'left', ...vStick('vendor', '#1A3673', 15) }}>Vendor</th>
                  <th style={{ ...vHead, textAlign: 'left', ...vStick('plan', '#1A3673', 15) }}>Cost Plan</th>
                  <th style={{ ...vHead, textAlign: 'right', ...vStick('fee', '#1A3673', 15) }}>Vendor Fee %</th>
                  <th style={{ ...vHead, textAlign: 'left', ...vStick('measure', '#1A3673', 15) }}>Measure</th>
                  <th style={{ ...vHead, textAlign: 'right', ...vStick('total', '#1A3673', 15, 'rgba(255,255,255,0.3)') }}>Total</th>
                  {vendorMonths.map(mo => (
                    <th key={mo} style={{ ...vHead, textAlign: 'right', minWidth: 96, background: '#1A3673' }}>{fmtPeriod(mo)}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {vendorGroups.length === 0 ? (
                  <tr><td colSpan={5 + vendorMonths.length} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No vendor plans match the current filters. <button onClick={() => cpClearAll('vnd', BLANK_VND_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                ) : (() => {
                  let rowIdx = 0;
                  return vendorGroups.flatMap((g, gi) => g.plans.map(({ plan, pct, error, months, totalActual, totalFee }, pi) => {
                    const bg = rowIdx++ % 2 === 0 ? '#fff' : '#EFF6FF';
                    const inputId = `vendor-fee-${plan.id}`;
                    const top = pi === 0 && gi > 0 ? '2px solid #e5e7eb' : '1px solid #f3f4f6';
                    return (
                      <tr key={plan.id} style={{ background: bg }}>
                        {pi === 0 && (
                          <td rowSpan={g.plans.length} style={{ padding: '8px', verticalAlign: 'top', borderTop: top, borderRight: '1px solid #e5e7eb',
                            whiteSpace: 'normal', wordBreak: 'break-word', fontWeight: 700, color: '#1A3673', ...vStick('vendor', '#fff') }}>
                            {plan.vendor}
                          </td>
                        )}
                        <td style={{ padding: '8px', verticalAlign: 'top', borderTop: top, borderRight: '1px solid #e5e7eb', whiteSpace: 'normal', wordBreak: 'break-word', ...vStick('plan', bg) }}>
                          <span style={{ display: 'block', fontFamily: 'monospace', color: '#1A3673' }}>{plan.costPlanNumber}</span>
                          {plan.description && <span style={{ display: 'block', fontSize: 10, color: '#6b7280', marginTop: 2, lineHeight: 1.35 }}>{plan.description}</span>}
                        </td>
                        <td style={{ padding: '6px 8px', verticalAlign: 'middle', textAlign: 'right', borderTop: top, borderRight: '1px solid #e5e7eb', ...vStick('fee', bg) }}>
                          <div className="flex items-center justify-end gap-1">
                            <input id={inputId} type="text" inputMode="decimal" aria-label={`Vendor Fee % for ${plan.costPlanNumber}`}
                              aria-invalid={!!error} aria-describedby={error ? `${inputId}-err` : undefined}
                              className="form-select text-xs text-right" placeholder="0.00"
                              style={{ width: 56, fontFamily: 'monospace', background: '#fff', border: `1px solid ${error ? '#E3725F' : '#93C5FD'}` }}
                              value={feeDraftOf(plan)} onChange={e => handleFeeChange(plan.id, e.target.value)} />
                            <span style={{ fontSize: 11, color: '#6b7280', fontWeight: 600 }}>%</span>
                          </div>
                          {error && <p id={`${inputId}-err`} role="alert" style={{ fontSize: 9.5, color: '#E3725F', marginTop: 4, whiteSpace: 'normal', textAlign: 'left' }}>{error}</p>}
                        </td>
                        <td style={{ ...vCell, textAlign: 'left', borderTop: top, borderRight: '1px solid #e5e7eb', ...vStick('measure', bg) }}>
                          <MeasureLabels />
                        </td>
                        <td style={{ ...vCell, borderTop: top, ...vStick('total', bg) }}>
                          <SavingsFeeCell savings={totalActual} fee={totalFee} bold />
                        </td>
                        {vendorMonths.map(mo => {
                          const amt = savingsFor(months, mo);
                          const fee = amt == null || pct == null ? null : calcVendorFee(amt, pct);
                          return <td key={mo} style={{ ...vCell, borderTop: top }}><SavingsFeeCell savings={amt ?? null} fee={fee} /></td>;
                        })}
                      </tr>
                    );
                  }));
                })()}
              </tbody>

              <tfoot>
                <tr style={{ background: V_FOOT_BG }}>
                  <td colSpan={3} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#1A3673', verticalAlign: 'middle', borderTop: '2px solid rgba(26,54,115,0.15)',
                    position: 'sticky', left: 0, zIndex: 5, background: V_FOOT_BG, minWidth: V_LEFT.measure, maxWidth: V_LEFT.measure }}>TOTAL ({vendorPlans.length} cost plan{vendorPlans.length !== 1 ? 's' : ''})</td>
                  <td style={{ ...vCell, textAlign: 'left', borderTop: '2px solid rgba(26,54,115,0.15)', ...vStick('measure', V_FOOT_BG) }}>
                    <MeasureLabels bold />
                  </td>
                  <td style={{ ...vCell, borderTop: '2px solid rgba(26,54,115,0.15)', ...vStick('total', V_FOOT_BG, 5, 'rgba(26,54,115,0.15)') }}>
                    <SavingsFeeCell savings={vendorActualTotal} fee={vendorFeeTotal} bold />
                  </td>
                  {vendorMonths.map((mo, i) => (
                    <td key={mo} style={{ ...vCell, borderTop: '2px solid rgba(26,54,115,0.15)' }}>
                      <SavingsFeeCell savings={vendorMonthSavings[i] || null} fee={vendorMonthFees[i] || null} bold />
                    </td>
                  ))}
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </CostSection>
      )}

      {/* ═══════════ 4. OTHERS ═══════════ */}
      {hasOth && (
      <CostSection id="oth" title="Others"      subtitle="Licensing, training and miscellaneous costs" icon={FileSpreadsheet} total={othersTotal} accent="#2861BB" tint="#F5F9FF">
        <div className="flex items-start gap-2 px-4 py-3 bg-purple-50 border border-purple-200 rounded-lg text-xs text-gray-600">
          <Info size={13} className="text-purple-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-purple-800">Other Costs — Licensing, Training, Vendor, Miscellaneous</p>
            <p className="mt-0.5 text-gray-600">Capture any additional costs not covered under IT Expense or FTE Request. These roll into Total Costs and Net ROI.</p>
          </div>
        </div>

        {/* Others filter modal */}
        {cpFilterOpen.oth && (
          <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
            onClick={() => cpCloseFilter('oth')}>
            <div style={{ background:'#fff', borderRadius:12, maxWidth:620, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
              onClick={e => e.stopPropagation()}>
              <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — Others</span></div>
                <button onClick={() => cpCloseFilter('oth')} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff' }}><X size={18} /></button>
              </div>
              <div style={{ padding:20, display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:14 }}>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                  <input type="text" value={cpPending.oth.costPlanNumber} onChange={e => cpPatch('oth','costPlanNumber',e.target.value)} placeholder="Search…"
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }} />
                </div>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Category</label>
                  <select value={cpPending.oth.category} onChange={e => cpPatch('oth','category',e.target.value)}
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {[...new Set(otherRows.map(r => r.category).filter(Boolean))].sort().map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:10, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Type</label>
                  <select value={cpPending.oth.costType} onChange={e => cpPatch('oth','costType',e.target.value)}
                    style={{ width:'100%', padding:'7px 10px', fontSize:12, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option><option value="One-time">One-time</option><option value="Recurring">Recurring</option><option value="Capital">Capital</option><option value="Operational">Operational</option>
                  </select>
                </div>
              </div>
              <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
                <button onClick={() => setCpPending(p => ({ ...p, oth: { ...BLANK_OTH_F } }))}
                  style={{ padding:'6px 14px', fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                <div style={{ display:'flex', gap:8 }}>
                  <button onClick={() => cpCloseFilter('oth')} style={{ padding:'6px 18px', fontSize:12, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                  <button onClick={() => cpApply('oth')} style={{ padding:'6px 20px', fontSize:12, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="card overflow-hidden">
          <div className="card-header">
            <div className="flex items-center gap-2">
              <div className="card-title"><FileSpreadsheet size={14} /> Other Costs</div>
              <span className="text-[10px] text-gray-400">({otherRows.length} row{otherRows.length !== 1 ? 's' : ''})</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold font-mono text-[#7c3aed]">{fmtCost(othersTotal)}</span>
              {canEdit && (
                <button onClick={() => setAddingOther(true)}
                  className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-[#1A3673] rounded-lg hover:bg-[#2861BB] transition">
                  <Plus size={11} /> Add Row
                </button>
              )}
            </div>
          </div>

          <SectionToolbar sec="oth" placeholder="Search cost plan, category, vendor, description…" />

          <div style={{ overflowX: 'auto' }}>
            <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 'max-content' }}>
              <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                <tr style={{ background: '#1A3673', height: 32 }}>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Plan Number</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Category</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Description</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Vendor / Provider</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Cost Type</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap', textAlign: 'right' }}>Amount</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Timeline</th>
                  <th style={{ padding: '0 10px', color: '#fff', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>Notes</th>
                  <th style={{ padding: '0 10px', width: 20 }}></th>
                </tr>
              </thead>
              <tbody>
                {filteredOth.length === 0 && !addingOther ? (
                  <tr><td colSpan={9} style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>No rows match the current filters. <button onClick={() => cpClearAll('oth', BLANK_OTH_F)} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></td></tr>
                ) : filteredOth.map((r, i) => [
                  <tr key={r.id} style={{ height: 32, background: i % 2 === 0 ? '#fff' : '#faf5ff', borderBottom: '1px solid #f3f4f6' }}>
                    <td className="table-td" style={{ fontFamily: 'monospace', color: '#1A3673', whiteSpace: 'nowrap' }}>{r.costPlanNumber || '—'}</td>
                    <td className="table-td" style={{ color: '#7c3aed', fontWeight: 600, whiteSpace: 'nowrap' }}>{r.category || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                    <td className="table-td" style={{ maxWidth: 200 }}>
                      <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#374151' }} title={r.description}>{r.description || <span style={{ color: '#d1d5db' }}>—</span>}</span>
                    </td>
                    <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.vendor || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                    <td className="table-td">
                      {r.costType ? (
                        <span style={{ fontSize: 10, fontWeight: 600, padding: '1px 8px', borderRadius: 999, background: r.costType === 'Recurring' ? '#fef3c7' : '#f0fdf4', color: r.costType === 'Recurring' ? '#92400e' : '#15803d', border: `1px solid ${r.costType === 'Recurring' ? '#fde68a' : '#86efac'}` }}>{r.costType}</span>
                      ) : <span style={{ color: '#d1d5db' }}>—</span>}
                    </td>
                    <td className="table-td" style={{ textAlign: 'right', fontFamily: 'monospace', fontWeight: r.amount > 0 ? 700 : 400, color: r.amount > 0 ? '#7c3aed' : '#d1d5db', whiteSpace: 'nowrap' }}>
                      {r.amount > 0 ? `$${r.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
                    </td>
                    <td className="table-td" style={{ whiteSpace: 'nowrap', color: '#6b7280' }}>{r.timeline || <span style={{ color: '#d1d5db' }}>—</span>}</td>
                    <td className="table-td" style={{ maxWidth: 220 }}>
                      <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#4b5563' }} title={r.notes}>{r.notes || <span style={{ color: '#d1d5db' }}>—</span>}</span>
                    </td>
                    <td className="table-td" style={{ textAlign: 'center', width: 48, whiteSpace: 'nowrap' }}>
                      <button onClick={() => toggleExpand(r.id)} title="Cost distribution"
                        style={{ color: expandedRows.has(r.id) ? '#2861BB' : '#d1d5db', background: 'none', border: 'none', cursor: 'pointer', marginRight: 4 }}
                        onMouseEnter={e => (e.currentTarget.style.color = '#2861BB')}
                        onMouseLeave={e => (e.currentTarget.style.color = expandedRows.has(r.id) ? '#2861BB' : '#d1d5db')}>
                        <Calendar size={12} />
                      </button>
                      {canEdit && (
                        <button onClick={() => { setOtherRows(p => p.filter(x => x.id !== r.id)); onEdit(); }}
                          style={{ color: '#d1d5db', background: 'none', border: 'none', cursor: 'pointer' }}
                          onMouseEnter={e => (e.currentTarget.style.color = '#E3725F')}
                          onMouseLeave={e => (e.currentTarget.style.color = '#d1d5db')}>
                          <Trash2 size={12} />
                        </button>
                      )}
                    </td>
                  </tr>,
                  expandedRows.has(r.id) && (
                    <CostDistributionPanel key={`${r.id}-dist`} rowId={r.id} rowType="oth" total={r.amount} meta={r.costMeta} colSpan={9}
                      onSave={m => saveOthMeta(r.id, m)} />
                  ),
                ])}
                {addingOther && (
                  <tr style={{ background: '#faf5ff', borderBottom: '2px solid #c4b5fd' }}>
                    <td className="table-td"><input className="form-select text-xs w-28" placeholder="Cost Plan #" value={newOther.costPlanNumber} onChange={e => setNewOther(p => ({ ...p, costPlanNumber: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-24" placeholder="Category" value={newOther.category} onChange={e => setNewOther(p => ({ ...p, category: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-40" placeholder="Description" value={newOther.description} onChange={e => setNewOther(p => ({ ...p, description: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-32" placeholder="Vendor" value={newOther.vendor} onChange={e => setNewOther(p => ({ ...p, vendor: e.target.value }))} /></td>
                    <td className="table-td">
                      <select className="form-select text-xs w-28" value={newOther.costType} onChange={e => setNewOther(p => ({ ...p, costType: e.target.value }))}>
                        <option>One-time</option><option>Recurring</option><option>Capital</option><option>Operational</option>
                      </select>
                    </td>
                    <td className="table-td"><input type="number" className="form-select text-xs w-28 text-right" placeholder="0" value={newOther.amount || ''} onChange={e => setNewOther(p => ({ ...p, amount: parseFloat(e.target.value) || 0 }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-24" placeholder="Timeline" value={newOther.timeline} onChange={e => setNewOther(p => ({ ...p, timeline: e.target.value }))} /></td>
                    <td className="table-td"><input className="form-select text-xs w-36" placeholder="Notes" value={newOther.notes} onChange={e => setNewOther(p => ({ ...p, notes: e.target.value }))} /></td>
                    <td className="table-td" style={{ whiteSpace: 'nowrap' }}>
                      <button onClick={() => {
                          setOtherRows(p => [...p, { ...newOther, id: `oth${Date.now()}` }]);
                          setNewOther({ costPlanNumber: '', category: '', description: '', vendor: '', costType: 'One-time', amount: 0, timeline: '', notes: '', costMeta: { ...DEFAULT_COST_META } });
                          setAddingOther(false); onEdit();
                        }} className="text-[10px] font-bold text-white bg-[#00BBBA] rounded px-2 py-0.5 mr-1 hover:bg-[#00a8a7]">
                        Save
                      </button>
                      <button onClick={() => setAddingOther(false)} className="text-[10px] font-medium text-gray-400 hover:text-gray-600">
                        Cancel
                      </button>
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr style={{ height: 34, background: 'rgba(124,58,237,0.07)', borderTop: '2px solid rgba(124,58,237,0.2)' }}>
                  <td colSpan={5} style={{ padding: '0 10px', fontWeight: 700, fontSize: 11, color: '#7c3aed' }}>TOTAL ({otherRows.length} row{otherRows.length !== 1 ? 's' : ''})</td>
                  <td style={{ padding: '0 10px', textAlign: 'right', fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: '#7c3aed', whiteSpace: 'nowrap' }}>
                    {othersTotal === 0 ? '—' : `$${othersTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                  </td>
                  <td colSpan={3}></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </CostSection>
      )}

    </div>
  );
}
