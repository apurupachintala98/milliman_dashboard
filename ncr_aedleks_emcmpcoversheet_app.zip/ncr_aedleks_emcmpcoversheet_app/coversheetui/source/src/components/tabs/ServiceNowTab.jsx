import { useState, useMemo, useEffect } from 'react';
import { Filter, X, Download, ArrowUpCircle, ArrowDownCircle, Search, ChevronUp, ChevronDown, Loader2 } from 'lucide-react';
import theme from '../../theme';
import { useTableSort } from '../../hooks/useTableSort';
import { useTableFilter } from '../../hooks/useTableFilter';
import { useGlobalSearch } from '../../hooks/useGlobalSearch';
import { snowApi } from '../../config/apiConfig';
import { useToast } from '../../context/ToastContext';

const fmt = (n) =>
  n < 0
    ? <span style={{color:'#E3725F'}}>({`$${Math.abs(n).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}`})</span>
    : <span>{`$${n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}`}</span>;

const fmtExport = (v) => {
  if (v === null || v === undefined || v === '—' || v === '') return '';
  if (typeof v === 'number') return v.toFixed(2);
  return String(v);
};

// ── DATA matching Excel: MVA Financial Impacts CIN0024932 Jan26-Mar26 ──
const FROM_ROWS = [
  {bp:'BPLN0351528',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:0.00,    actualBenefit:0.00,      lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'North Carolina',freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0.00},
  {bp:'BPLN0351519',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:2608.52,  actualBenefit:6278.28,   lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Iowa',            freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:6278.28},
  {bp:'BPLN0353307',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:2257.38,  actualBenefit:902.88,    lob:'GRS (Group Medicare)',mbu:'GBD GRS',                  metric:'Medical',sbu:'GBD',market:'New Hampshire',   freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:902.88},
  {bp:'BPLN0353311',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:165.91,   actualBenefit:154.07,    lob:'GRS (Group Medicare)',mbu:'GBD GRS',                  metric:'Medical',sbu:'GBD',market:'Virginia',         freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:154.07},
  {bp:'BPLN0351513',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:703.11,   actualBenefit:778.89,    lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'California',      freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:778.89},
  {bp:'BPLN0351514',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:39.40,    actualBenefit:37.37,     lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Colorado',        freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:37.37},
  {bp:'BPLN0353308',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:0.00,     actualBenefit:0.00,      lob:'GRS (Group Medicare)',mbu:'GBD GRS',                  metric:'Medical',sbu:'GBD',market:'Nevada',           freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0.00},
  {bp:'BPLN0351520',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:3264.91,  actualBenefit:7340.47,   lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Kentucky',       freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:7340.47},
  {bp:'BPLN0351531',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:16558.21, actualBenefit:12430.59,  lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Texas',           freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:12430.59},
  {bp:'BPLN0351515',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:0.79,     actualBenefit:1.06,      lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Connecticut',    freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:1.06},
  {bp:'BPLN0353301',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:207.27,   actualBenefit:191.75,    lob:'GRS (Group Medicare)',mbu:'GBD GRS',                  metric:'Medical',sbu:'GBD',market:'Connecticut',    freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:191.75},
  {bp:'BPLN0351534',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:6777.96,  actualBenefit:17837.94,  lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Wisconsin',      freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:17837.94},
  {bp:'BPLN0351516',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:17696.42, actualBenefit:24509.64,  lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Florida',        freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:24509.64},
  {bp:'BPLN0351532',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:0.00,     actualBenefit:0.00,      lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Virginia',        freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0.00},
  {bp:'BPLN0351518',fiscalPeriod:'FY26: M01',catTrend:'',currency:'USD',enteredBenefit:3636.23,  actualBenefit:4606.34,   lob:'Individual Medicare',mbu:'GBD Medicare Advantage All',metric:'Medical',sbu:'GBD',market:'Indiana',        freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:4606.34},
];

// TO_ROWS reuses same data for the "To ServiceNow" direction (push back)
const TO_ROWS = FROM_ROWS.map(r => ({ ...r }));

const FROM_SNP    = FROM_ROWS.filter(r => r.lob === 'Individual Medicare');
const FROM_NONSNP = FROM_ROWS.filter(r => r.lob !== 'Individual Medicare');
const TO_SNP      = TO_ROWS.filter(r => r.lob === 'Individual Medicare');
const TO_NONSNP   = TO_ROWS.filter(r => r.lob !== 'Individual Medicare');


function UnifiedTable({ sections, direction, snowId }) {
  const isImport = direction === 'to';
  const allRows   = sections.flatMap(s => s.rows);

  // Use reusable filter hook
  const {
    filters,
    pendingFilters,
    isFilterOpen,
    setIsFilterOpen,
    updatePendingFilter,
    applyFilters,
    clearPendingFilters,
    clearAllFilters,
    cancelFilters,
    filteredData,
    activeFilterCount,
  } = useTableFilter(allRows, {
    bp: '',
    fiscalPeriod: '',
    catTrend: '',
    lob: '',
    mbu: '',
    metric: '',
    sbu: '',
    market: '',
    freq: '',
    mtype: '',
    mdesc: '',
  });

  // Apply global search on top of hook-filtered data
  const { searchTerm: globalSearch, setSearchTerm: setGlobalSearch, searchedData: globalFilteredData } = useGlobalSearch(filteredData);

  // Use reusable sort hook
  const {
    sortField,
    sortDir,
    handleSort,
    sortedData,
  } = useTableSort(globalFilteredData, '', 'asc');
  // Get unique values for filter dropdowns
  const uniq = (fn) => Array.from(new Set(allRows.map(fn).filter(v => v !== null && v !== undefined && v !== ''))).sort();
  const fps    = uniq(r => r.fiscalPeriod);
  const cats   = uniq(r => r.catTrend);
  const lobs   = uniq(r => r.lob);
  const mbus   = uniq(r => r.mbu);
  const mets   = uniq(r => r.metric);
  const sbus   = uniq(r => r.sbu);
  const markets= uniq(r => r.market);
  const freqs  = uniq(r => r.freq);
  const mtypes = uniq(r => r.mtype);
  const mdescs = uniq(r => r.mdesc);

  // Open filter popup - sync current filters to pending
  const openFilterPopup = () => {
    // No need to sync - hook handles this automatically
    setIsFilterOpen(true);
  };

  const exportCSV = () => {
    const headers = ['Benefit Plan Number','Fiscal Period','Cost Category','Currency','Entered Benefit','Actual Benefit','LOB','MBU','Metric','SBU','Market','Frequency','Metric Type','Metric Desc'];
    const dataRows = sortedData.map(r => [
      r.bp, r.fiscalPeriod, r.catTrend, r.currency,
      fmtExport(r.enteredBenefit), fmtExport(r.actualBenefit),
      r.lob, r.mbu, r.metric, r.sbu, r.market, r.freq, r.mtype, r.mdesc,
    ]);
    const csv = [headers, ...dataRows].map(row => row.map(c => `"${fmtExport(c).replace(/"/g,'""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const planNums = [...new Set(sortedData.map(r => r.bp))].slice(0, 3).join('_');
    const filename = `BenefitPlan_SNOW${planNums ? '_' + planNums : ''}.csv`;
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  const accentColor = '#1A3673';
  return (
    <div className="card overflow-hidden">
      {/* ── Top bar: search + actions only ───────────────────────────────── */}
      <div style={{ padding:'10px 14px', borderBottom:'1px solid #e5e7eb', background:'#fafafa', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, flexWrap:'wrap' }}>
        {/* Global search with filter – left side */}
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ position:'relative', flex:'0 1 280px' }}>
            <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
            <input
              type="text"
              value={globalSearch}
              onChange={e => setGlobalSearch(e.target.value)}
              placeholder="Search plans..."
              style={{ width:'100%', paddingLeft:32, paddingRight: globalSearch ? 28 : 10, paddingTop:6, paddingBottom:6, fontSize:13, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
              onFocus={e => e.target.style.borderColor = '#1A3673'}
              onBlur={e => e.target.style.borderColor = '#d1d5db'}
            />
            {globalSearch && (
              <button onClick={() => setGlobalSearch('')}
                style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                <X size={13} />
              </button>
            )}
          </div>
          <button 
            onClick={openFilterPopup}
            onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
            onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
            title="Apply filters"
            style={{ 
              display:'inline-flex', 
              alignItems:'center', 
              gap:6, 
              fontSize:13, 
              fontWeight:600, 
              background:'#1A3673', 
              color:'#fff', 
              border:'none', 
              borderRadius:999, 
              padding:'6px 14px', 
              cursor:'pointer',
              transition:'transform 0.1s ease',
              position:'relative'
            }}
          >
            <Filter size={13} />
            {activeFilterCount > 0 && (
              <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 7px', minWidth:20, textAlign:'center' }}>
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          {activeFilterCount > 0 && (
            <button onClick={clearAllFilters}
              style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'5px 12px', cursor:'pointer' }}>
              <X size={11} /> Clear All
            </button>
          )}
          <button 
            onClick={exportCSV}
            onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
            onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
            style={{ 
              display:'inline-flex', 
              alignItems:'center', 
              gap:6, 
              fontSize:13, 
              fontWeight:600, 
              background:'#1A3673', 
              color:'#fff', 
              border:'none', 
              borderRadius:999, 
              padding:'6px 14px', 
              cursor:'pointer',
              transition:'transform 0.1s ease'
            }}
          >
            <Download size={13} /> Export
          </button>

        </div>
      </div>

      {/* Filter Popup Modal */}
      {isFilterOpen && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={cancelFilters}>
          <div style={{ background:'#fff', borderRadius:12, maxWidth:900, width:'100%', maxHeight:'90vh', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={(e) => e.stopPropagation()}>
            <div style={{ padding:'16px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <Filter size={20} color="#fff" />
                <h3 style={{ margin:0, fontSize:16, fontWeight:700, color:'#fff' }}>Filter Plans</h3>
              </div>
              <button onClick={cancelFilters} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}>
                <X size={20} />
              </button>
            </div>
            
            <div style={{ padding:24, maxHeight:'calc(90vh - 180px)', overflowY:'auto' }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:16 }}>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>BP Number</label>
                  <input type="text" value={pendingFilters.bp} onChange={(e) => updatePendingFilter('bp', e.target.value)}
                    placeholder="Search BP Number..."
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none' }}
                    onFocus={(e) => e.target.style.borderColor = '#1A3673'}
                    onBlur={(e) => e.target.style.borderColor = '#d1d5db'} />
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Fiscal Period</label>
                  <select value={pendingFilters.fiscalPeriod} onChange={(e) => updatePendingFilter('fiscalPeriod', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {fps.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Category</label>
                  <select value={pendingFilters.catTrend} onChange={(e) => updatePendingFilter('catTrend', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {cats.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>LOB</label>
                  <select value={pendingFilters.lob} onChange={(e) => updatePendingFilter('lob', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {lobs.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>MBU</label>
                  <select value={pendingFilters.mbu} onChange={(e) => updatePendingFilter('mbu', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {mbus.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric</label>
                  <select value={pendingFilters.metric} onChange={(e) => updatePendingFilter('metric', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {mets.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>SBU</label>
                  <select value={pendingFilters.sbu} onChange={(e) => updatePendingFilter('sbu', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {sbus.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Market</label>
                  <select value={pendingFilters.market} onChange={(e) => updatePendingFilter('market', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {markets.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Frequency</label>
                  <select value={pendingFilters.freq} onChange={(e) => updatePendingFilter('freq', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {freqs.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Type</label>
                  <select value={pendingFilters.mtype} onChange={(e) => updatePendingFilter('mtype', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {mtypes.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Desc</label>
                  <select value={pendingFilters.mdesc} onChange={(e) => updatePendingFilter('mdesc', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {mdescs.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
              </div>
            </div>
            
            <div style={{ padding:'16px 20px', borderTop:`2px solid ${theme.colors.gray200}`, display:'flex', alignItems:'center', justifyContent:'space-between', background:theme.colors.gray50 }}>
              <button onClick={() => { clearPendingFilters(); setGlobalSearch(''); }} style={{ padding:'8px 16px', fontSize:theme.fontSize.base, fontWeight:theme.fontWeight.semibold, color:theme.colors.error, background:theme.colors.errorBg, border:`1px solid ${theme.colors.errorBorder}`, borderRadius:theme.borderRadius.sm, cursor:'pointer', transition:'all 0.15s ease' }}
                onMouseEnter={(e) => e.currentTarget.style.background = theme.colors.errorLight}
                onMouseLeave={(e) => e.currentTarget.style.background = theme.colors.errorBg}>
                Clear All
              </button>
              <div style={{ display:'flex', gap:10 }}>
                <button onClick={cancelFilters} style={{ padding:'8px 20px', fontSize:theme.fontSize.md, fontWeight:theme.fontWeight.semibold, color:theme.colors.textSecondary, background:theme.colors.white, border:`1px solid ${theme.colors.gray300}`, borderRadius:theme.borderRadius.sm, cursor:'pointer', transition:'all 0.15s ease' }}
                  onMouseEnter={(e) => e.currentTarget.style.background = theme.colors.gray100}
                  onMouseLeave={(e) => e.currentTarget.style.background = theme.colors.white}>
                  Cancel
                </button>
                <button onClick={applyFilters} style={{ padding:'8px 24px', fontSize:theme.fontSize.md, fontWeight:theme.fontWeight.semibold, color:theme.colors.white, background:theme.colors.primary, border:'none', borderRadius:theme.borderRadius.sm, cursor:'pointer', transition:'all 0.15s ease' }}
                  onMouseEnter={(e) => e.currentTarget.style.opacity = '0.9'}
                  onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}>
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Unified table ────────────────────────────────────────────────────── */}
      <div style={{ overflowX:'auto', maxHeight:520 }}>
        <table className="w-full" style={{ borderCollapse:'collapse', minWidth:'max-content', fontSize:12 }}>
          <thead style={{ position:'sticky', top:0, zIndex:10 }}>
            <tr style={{ background: accentColor, height:32 }}>
              <th onClick={() => handleSort('bp')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Benefit Plan Number <span style={{ opacity: sortField === 'bp' ? 1 : 0.3 }}>{sortField === 'bp' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('fiscalPeriod')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Fiscal Period <span style={{ opacity: sortField === 'fiscalPeriod' ? 1 : 0.3 }}>{sortField === 'fiscalPeriod' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('catTrend')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Cost Category <span style={{ opacity: sortField === 'catTrend' ? 1 : 0.3 }}>{sortField === 'catTrend' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('currency')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Currency <span style={{ opacity: sortField === 'currency' ? 1 : 0.3 }}>{sortField === 'currency' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('enteredBenefit')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', textAlign:'right', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4, justifyContent:'flex-end' }}>
                  Entered Benefit <span style={{ opacity: sortField === 'enteredBenefit' ? 1 : 0.3 }}>{sortField === 'enteredBenefit' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('actualBenefit')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', textAlign:'right', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4, justifyContent:'flex-end' }}>
                  Actual Benefit <span style={{ opacity: sortField === 'actualBenefit' ? 1 : 0.3 }}>{sortField === 'actualBenefit' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('lob')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  LOB <span style={{ opacity: sortField === 'lob' ? 1 : 0.3 }}>{sortField === 'lob' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('mbu')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  MBU <span style={{ opacity: sortField === 'mbu' ? 1 : 0.3 }}>{sortField === 'mbu' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('metric')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Metric <span style={{ opacity: sortField === 'metric' ? 1 : 0.3 }}>{sortField === 'metric' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('sbu')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  SBU <span style={{ opacity: sortField === 'sbu' ? 1 : 0.3 }}>{sortField === 'sbu' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('market')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Market <span style={{ opacity: sortField === 'market' ? 1 : 0.3 }}>{sortField === 'market' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              {/* Frequency column — commented out
              <th onClick={() => handleSort('freq')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Frequency
                </div>
              </th>
              */}
              <th onClick={() => handleSort('mtype')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Metric Type <span style={{ opacity: sortField === 'mtype' ? 1 : 0.3 }}>{sortField === 'mtype' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th onClick={() => handleSort('mdesc')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                  Metric Desc <span style={{ opacity: sortField === 'mdesc' ? 1 : 0.3 }}>{sortField === 'mdesc' && sortDir === 'asc' ? '▲' : '▼'}</span>
                </div>
              </th>
              <th style={{ padding:'0 10px', width:20 }}></th>
            </tr>
          </thead>
          <tbody>
            {sortedData.map((r, i) => {
              const dash = <span style={{color:'#d1d5db'}}>—</span>;
              const txt  = (v) => (!v || v === '—') ? dash : v;
              return (
                <tr key={r.bp} style={{ height:30, background: i%2===0 ? '#fff' : '#EFF6FF', borderBottom:'1px solid #f3f4f6' }}>
                  <td style={{ padding:'0 10px', fontFamily:'monospace', fontSize:12, color:'#1A3673', whiteSpace:'nowrap' }}>{txt(r.bp)}</td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.fiscalPeriod)}</td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.catTrend)}</td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.currency)}</td>
                  <td style={{ padding:'0 10px', textAlign:'right', fontFamily:'monospace', fontSize:12, whiteSpace:'nowrap' }}>{fmt(r.enteredBenefit)}</td>
                  <td style={{ padding:'0 10px', textAlign:'right', fontFamily:'monospace', fontSize:12, fontWeight:700, color:'#1A3673', whiteSpace:'nowrap' }}>{fmt(r.actualBenefit)}</td>
                  <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                    {(!r.lob || r.lob === '—') ? dash : <span style={{ fontSize:11, fontWeight:600, padding:'2px 8px', borderRadius:999, background:'#f0fdfa', color:'#00BBBA', border:'1px solid #66D6D6', whiteSpace:'nowrap' }}>{r.lob}</span>}
                  </td>
                  <td style={{ padding:'0 10px', maxWidth:180 }}>
                    {(!r.mbu || r.mbu === '—') ? dash : <span style={{ display:'block', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', color:'#4b5563' }} title={r.mbu}>{r.mbu}</span>}
                  </td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.metric)}</td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.sbu)}</td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.market)}</td>
                  {/* <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.freq)}</td> */}
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.mtype)}</td>
                  <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.mdesc)}</td>
                  <td style={{ padding:'0 10px', width:32 }}></td>
                </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr style={{ height:30, background:'rgba(26,54,115,0.07)', borderTop:'2px solid rgba(26,54,115,0.15)' }}>
              <td colSpan={12} style={{ padding:'0 10px', fontSize:12, fontWeight:700, color:'#1A3673' }}>
                TOTAL ({sortedData.length} record{sortedData.length !== 1 ? 's' : ''}){(activeFilterCount > 0 || globalSearch) ? ` — filtered from ${allRows.length}` : ''}
              </td>
              <td style={{ padding:'0 10px', textAlign:'right', fontFamily:'monospace', fontSize:12, fontWeight:700, color:'#374151', whiteSpace:'nowrap' }}>
                ${sortedData.reduce((s, r) => s + (r.actualBenefit || 0), 0).toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:2 })}
              </td>
              <td style={{ padding:'0 10px', width:32 }}></td>
            </tr>
          </tfoot>
        </table>
        {sortedData.length === 0 && (
          <div style={{ padding:24, textAlign:'center', color:'#9ca3af', fontSize:11 }}>No plans match your filters. <button onClick={() => { clearAllFilters(); setGlobalSearch(''); }} style={{ color:'#1A3673', background:'none', border:'none', cursor:'pointer', fontWeight:600, fontSize:11 }}>Clear filters</button></div>
        )}
      </div>
    </div>
  );
}

const GROUP_MED_FROM = [
  {bp:'BPLN0272800',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'California',  freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272801',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Florida',     freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272802',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Texas',       freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272803',fiscalPeriod:'FY26: M01',catTrend:'Outpatient All',currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'New York',    freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272804',fiscalPeriod:'FY26: M01',catTrend:'Outpatient All',currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Ohio',        freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272805',fiscalPeriod:'FY26: M01',catTrend:'ER Facility',   currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Illinois',    freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272806',fiscalPeriod:'FY26: M01',catTrend:'ER Facility',   currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Pennsylvania',freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
  {bp:'BPLN0272807',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:0,       actualBenefit:0,       lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Georgia',     freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:0},
];

const GROUP_MED_TO = [
  {bp:'BPLN0272800',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:22490.25,actualBenefit:24310.50,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'California',  freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:24310.50},
  {bp:'BPLN0272801',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:17250.00,actualBenefit:18740.00,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Florida',     freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:18740.00},
  {bp:'BPLN0272802',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:29870.75,actualBenefit:31560.75,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Texas',       freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:31560.75},
  {bp:'BPLN0272803',fiscalPeriod:'FY26: M01',catTrend:'Outpatient All',currency:'USD',enteredBenefit:14520.25,actualBenefit:15890.25,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'New York',    freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:15890.25},
  {bp:'BPLN0272804',fiscalPeriod:'FY26: M01',catTrend:'Outpatient All',currency:'USD',enteredBenefit:20640.50,actualBenefit:22140.50,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Ohio',        freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:22140.50},
  {bp:'BPLN0272805',fiscalPeriod:'FY26: M01',catTrend:'ER Facility',   currency:'USD',enteredBenefit:11890.75,actualBenefit:12480.75,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Illinois',    freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:12480.75},
  {bp:'BPLN0272806',fiscalPeriod:'FY26: M01',catTrend:'ER Facility',   currency:'USD',enteredBenefit:18340.00,actualBenefit:19320.00,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Pennsylvania',freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:19320.00},
  {bp:'BPLN0272807',fiscalPeriod:'FY26: M01',catTrend:'Inpatient All', currency:'USD',enteredBenefit:15110.25,actualBenefit:16250.25,lob:'GRS (Group Medicare)',mbu:'GBD GRS',metric:'Medical',sbu:'GBD',market:'Georgia',     freq:'Recurring',mtype:'Benefit Expense',mdesc:'Medical Claims',total:16250.25},
];

// ── API field → UI field mappers ─────────────────────────────────────────────
const mapBenefitPlan = (b) => ({
  bp:            b.u_number || '—',
  fiscalPeriod:  b.start_fiscal_period_name || '—',
  catTrend:      b.sub_category_display || '—',
  currency:      b.currency_code || 'USD',
  enteredBenefit: parseFloat(b.estimated_benefit) || 0,
  actualBenefit:  parseFloat(b.actual_benefit)    || 0,
  lob:           b.lob             || '—',
  mbu:           b.u_mbu_code      || '—',
  metric:        b.u_metric        || '—',
  sbu:           b.sbu             || '—',
  market:        b.u_market_name   || '—',
  freq:          '—',
  mtype:         b.u_metric_type_display        || '—',
  mdesc:         b.u_metric_description_display || '—',
  total:         parseFloat(b.actual_benefit) || 0,
});

const mapCostPlan = (c) => ({
  cpNum:    c.u_number || '—',
  fp:       c.start_fiscal_period_name || '—',
  costType: (() => {
    const lines = c.breakdown_lines;
    if (Array.isArray(lines) && lines.length > 0) {
      const names = [...new Set(lines.map(l => l?.resource_type?.name).filter(Boolean))];
      if (names.length > 0) return names.join(', ');
    }
    return c.cost_type_cd || '—';
  })(),
  freq:     c.u_metric_frequency_display     || '—',
  mtype:    c.u_metric_type_display          || '—',
  mdesc:    c.u_metric_description_display   || '—',
  planDesc:     c.u_short_description                    || '—',
  costFrom:     parseFloat(c.cost_local_currency)          || 0,
  costTo:       parseFloat(c.actual_cost_default_currency) || 0,
});

export default function ServiceNowTab({ coversheet }) {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState('from');

  const [bpRows, setBpRows]       = useState([]);
  const [cpRows, setCpRows]       = useState([]);
  const [bpLoading, setBpLoading] = useState(false);
  const [cpLoading, setCpLoading] = useState(false);
  const [bpError, setBpError]     = useState(null);
  const [cpError, setCpError]     = useState(null);

  const cvrsht_id = coversheet?.id || coversheet?.cvrsht_id;

  // Map UI tab value → API direction param
  const direction = activeTab === 'from' ? 'from_snow' : 'to_snow';

  useEffect(() => {
    setBpLoading(true);
    setBpError(null);
    snowApi.fetchBenefitPlans(cvrsht_id, 1, 100, direction)
      .then(data => setBpRows((data.benefit_plans || []).map(mapBenefitPlan)))
      .catch(err => setBpError(err.message))
      .finally(() => setBpLoading(false));
  }, [cvrsht_id, direction]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setCpLoading(true);
    setCpError(null);
    snowApi.fetchCostPlans(cvrsht_id, 1, 100, direction)
      .then(data => setCpRows((data.cost_plans || []).map(mapCostPlan)))
      .catch(err => setCpError(err.message))
      .finally(() => setCpLoading(false));
  }, [cvrsht_id, direction]); // eslint-disable-line react-hooks/exhaustive-deps


  const CP_ROWS = cpRows;
  const cpPrioColor = { High:'#E3725F', Medium:'#d97706', Low:'#6b7280' };
  const cpApprColor = {
    'Approved':{bg:'#f0fdfa',color:'#00BBBA',border:'#66D6D6'}, 'Pending':{bg:'#fef9ec',color:'#92400e',border:'#fde68a'},
  };
  const cpCatBadge = {
    'IT Expense': {bg:'#E1EDFF',color:'#1A3673',border:'#6A97DF'},
    'FTE Request':{bg:'#f0fdf4',color:'#166534',border:'#86efac'},
    'Others':     {bg:'#fef9ec',color:'#92400e',border:'#fde68a'},
  };
  const uniqCp = (fn) => [...new Set(CP_ROWS.map(fn))].sort();
  
  // Use reusable filter hook for Cost Plan
  const {
    filters: cpFilters,
    pendingFilters: cpPendingFilters,
    isFilterOpen: cpIsFilterOpen,
    setIsFilterOpen: setCpIsFilterOpen,
    updatePendingFilter: cpUpdatePendingFilter,
    applyFilters: cpApplyFilters,
    clearPendingFilters: cpClearPendingFilters,
    clearAllFilters: cpClearAllFilters,
    cancelFilters: cpCancelFilters,
    filteredData: cpFilteredData,
    activeFilterCount: cpActiveFilterCount,
  } = useTableFilter(CP_ROWS, {
    cpNum: '',
    fp: '',
    costType: '',
    freq: '',
    mtype: '',
    mdesc: '',
  });

  // Use reusable sort hook for Cost Plan
  const {
    sortField: cpSortField,
    sortDir: cpSortDir,
    handleSort: cpHandleSort,
    sortedData: cpSortedData,
  } = useTableSort(cpFilteredData, '', 'asc');
  
  // Open filter popup
  const openCpFilterPopup = () => {
    setCpIsFilterOpen(true);
  };
  
  // Custom filter logic that also searches in planDesc field
  const cpFilteredDataWithDesc = useMemo(() => {
    return cpFilteredData.filter(r => {
      if (cpFilters.cpNum && !r.cpNum.toLowerCase().includes(cpFilters.cpNum.toLowerCase()) && !r.planDesc.toLowerCase().includes(cpFilters.cpNum.toLowerCase())) {
        return false;
      }
      return true;
    });
  }, [cpFilteredData, cpFilters.cpNum]);
  
  // Apply global search on cost plan data
  const { searchTerm: cpGlobalSearch, setSearchTerm: setCpGlobalSearch, searchedData: cpGlobalFiltered } = useGlobalSearch(cpFilteredDataWithDesc);

  // Re-sort after custom filtering
  const finalCpData = useMemo(() => {
    if (!cpSortField) return cpGlobalFiltered;
    return [...cpGlobalFiltered].sort((a, b) => {
      let aVal = a[cpSortField];
      let bVal = b[cpSortField];
      
      // Handle numeric fields
      if (cpSortField === 'cost') {
        aVal = Number(activeTab === 'from' ? a.costFrom : a.costTo) || 0;
        bVal = Number(activeTab === 'from' ? b.costFrom : b.costTo) || 0;
      }
      
      // Handle string fields
      if (typeof aVal === 'string') aVal = aVal.toLowerCase();
      if (typeof bVal === 'string') bVal = bVal.toLowerCase();
      
      if (aVal < bVal) return cpSortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return cpSortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [cpGlobalFiltered, cpSortField, cpSortDir]);
  const [bpExpanded, setBpExpanded] = useState(false);
  const [cpExpanded, setCpExpanded] = useState(false);

  const cpExportCSV = () => {
    const hdr = ['Cost Plan Number','Fiscal Period','Cost Type','Frequency','Metric Type','Metric Desc','Plan Description','Cost'];
    const rows = finalCpData.map(r => [r.cpNum, r.fp, r.costType, r.freq, r.mtype, r.mdesc, r.planDesc, fmtExport(activeTab === 'from' ? r.costFrom : r.costTo)]);
    const csv = [hdr, ...rows].map(row => row.map(c => `"${fmtExport(c).replace(/"/g,'""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const planNums = [...new Set(finalCpData.map(r => r.cpNum))].slice(0, 3).join('_');
    const filename = `CostPlan_SNOW${planNums ? '_' + planNums : ''}.csv`;
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      {/* Direction toggle — pinned to top of scroll area, cancels the pt-6 from wrapper */}
      <div className="sticky top-0 z-20 -mx-6 px-6 -mt-6 pt-2 pb-2" style={{ backgroundColor: '#F5F5F5', borderBottom: '1px solid #e5e7eb' }}>
      <div className="card p-1 flex gap-1">
        <button
          onClick={() => setActiveTab('from')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition ${
            activeTab === 'from' ? 'bg-[#1A3673] text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <ArrowDownCircle size={13} /> From ServiceNow
        </button>
        <button
          onClick={() => setActiveTab('to')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition ${
            activeTab === 'to' ? 'bg-[#1A3673] text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <ArrowUpCircle size={13} /> To ServiceNow
        </button>
      </div>
      </div>

      <div className="space-y-4 pt-4">
      {/* KPI strip — commented out, not needed for now
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'SNP Plans',      value: `${FROM_SNP.length} plans`,                                        bg: '#f0fdfa', color: '#00BBBA' },
          { label: 'Non-SNP Plans',  value: `${FROM_NONSNP.length} plans`,                                     bg: '#EFF6FF', color: '#2861BB' },
          { label: 'Total Exported', value: `$${totalExport.toLocaleString(undefined,{maximumFractionDigits:0})}`, bg: '#fef9ec', color: '#d97706' },
          { label: 'Total Import',   value: `$${totalImport.toLocaleString(undefined,{maximumFractionDigits:0})}`, bg: '#f0fdf4', color: '#16a34a' },
        ].map(k => (
          <div key={k.label} style={{ background:k.bg, borderRadius:8, border:'1px solid #e5e7eb', padding:'10px 14px' }}>
            <p style={{ fontSize:14, color:'#1A3673', fontWeight:500, margin:'0 0 4px' }}>{k.label}</p>
            <p style={{ fontSize:16, fontWeight:600, color:k.color, margin:0 }}>{k.value}</p>
          </div>
        ))}
      </div>
      */}

      {/* ── Benefit Plan collapsible section ── */}
      <div className="card overflow-hidden">
        <button
          onClick={() => setBpExpanded(v => !v)}
          style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', background:'#fafafa', border:'none', cursor:'pointer', borderBottom: bpExpanded ? '1px solid #e5e7eb' : 'none' }}
        >
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ fontSize:13, fontWeight:700, color:'#1A3673', letterSpacing:'0.04em', textTransform:'uppercase' }}>Benefit Plan</span>
          </div>
          <span style={{ color:'#6b7280', display:'flex', alignItems:'center' }}>
            {bpExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </span>
        </button>
        {bpExpanded && (
          bpLoading ? (
            <div style={{ padding:32, display:'flex', alignItems:'center', justifyContent:'center', gap:8, color:'#6b7280' }}>
              <Loader2 size={16} style={{ animation:'spin 1s linear infinite' }} /> Loading benefit plans…
            </div>
          ) : bpError ? (
            <div style={{ padding:16, color:'#E3725F', fontSize:13, textAlign:'center' }}>Failed to load: {bpError}</div>
          ) : (
            <UnifiedTable
              direction={activeTab}
              snowId={coversheet.snowCardId}
              sections={[{ label: 'Benefit Plans', planType: 'All', rows: bpRows }]}
            />
          )
        )}
      </div>

      {/* Cost Plan Filter Popup Modal */}
      {cpIsFilterOpen && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={cpCancelFilters}>
          <div style={{ background:'#fff', borderRadius:12, maxWidth:800, width:'100%', maxHeight:'90vh', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={(e) => e.stopPropagation()}>
            <div style={{ padding:'16px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <Filter size={20} color="#fff" />
                <h3 style={{ margin:0, fontSize:16, fontWeight:700, color:'#fff' }}>Filter Cost Plan</h3>
              </div>
              <button onClick={cpCancelFilters} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}>
                <X size={20} />
              </button>
            </div>
            
            <div style={{ padding:24, maxHeight:'calc(90vh - 180px)', overflowY:'auto' }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:16 }}>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Plan Number</label>
                  <input type="text" value={cpPendingFilters.cpNum} onChange={(e) => cpUpdatePendingFilter('cpNum', e.target.value)}
                    placeholder="Search plan number or description..."
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none' }}
                    onFocus={(e) => e.target.style.borderColor = '#1A3673'}
                    onBlur={(e) => e.target.style.borderColor = '#d1d5db'} />
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Fiscal Period</label>
                  <select value={cpPendingFilters.fp} onChange={(e) => cpUpdatePendingFilter('fp', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {uniqCp(r=>r.fp).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Type</label>
                  <select value={cpPendingFilters.costType} onChange={(e) => cpUpdatePendingFilter('costType', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {uniqCp(r=>r.costType).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Frequency</label>
                  <select value={cpPendingFilters.freq} onChange={(e) => cpUpdatePendingFilter('freq', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {uniqCp(r=>r.freq).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Type</label>
                  <select value={cpPendingFilters.mtype} onChange={(e) => cpUpdatePendingFilter('mtype', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {uniqCp(r=>r.mtype).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Desc</label>
                  <select value={cpPendingFilters.mdesc} onChange={(e) => cpUpdatePendingFilter('mdesc', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {uniqCp(r=>r.mdesc).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
              </div>
            </div>
            
            <div style={{ padding:'16px 20px', borderTop:`2px solid ${theme.colors.gray200}`, display:'flex', alignItems:'center', justifyContent:'space-between', background:theme.colors.gray50 }}>
              <button onClick={() => { cpClearPendingFilters(); setCpGlobalSearch(''); }} style={{ padding:'8px 16px', fontSize:theme.fontSize.base, fontWeight:theme.fontWeight.semibold, color:theme.colors.error, background:theme.colors.errorBg, border:`1px solid ${theme.colors.errorBorder}`, borderRadius:theme.borderRadius.sm, cursor:'pointer', transition:'all 0.15s ease' }}
                onMouseEnter={(e) => e.currentTarget.style.background = theme.colors.errorLight}
                onMouseLeave={(e) => e.currentTarget.style.background = theme.colors.errorBg}>
                Clear All
              </button>
              <div style={{ display:'flex', gap:10 }}>
                <button onClick={cpCancelFilters} style={{ padding:'8px 20px', fontSize:theme.fontSize.md, fontWeight:theme.fontWeight.semibold, color:theme.colors.textSecondary, background:theme.colors.white, border:`1px solid ${theme.colors.gray300}`, borderRadius:theme.borderRadius.sm, cursor:'pointer', transition:'all 0.15s ease' }}
                  onMouseEnter={(e) => e.currentTarget.style.background = theme.colors.gray100}
                  onMouseLeave={(e) => e.currentTarget.style.background = theme.colors.white}>
                  Cancel
                </button>
                <button onClick={cpApplyFilters} style={{ padding:'8px 24px', fontSize:theme.fontSize.md, fontWeight:theme.fontWeight.semibold, color:theme.colors.white, background:theme.colors.primary, border:'none', borderRadius:theme.borderRadius.sm, cursor:'pointer', transition:'all 0.15s ease' }}
                  onMouseEnter={(e) => e.currentTarget.style.opacity = '0.9'}
                  onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}>
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Cost Plan collapsible section ── */}
      <div className="card overflow-hidden">
        <button
          onClick={() => setCpExpanded(v => !v)}
          style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', background:'#fafafa', border:'none', cursor:'pointer', borderBottom: cpExpanded ? '1px solid #e5e7eb' : 'none' }}
        >
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ fontSize:13, fontWeight:700, color:'#1A3673', letterSpacing:'0.04em', textTransform:'uppercase' }}>Cost Plan</span>
          </div>
          <span style={{ color:'#6b7280', display:'flex', alignItems:'center' }}>
            {cpExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </span>
        </button>
      {cpExpanded && (
        cpLoading ? (
          <div style={{ padding:32, display:'flex', alignItems:'center', justifyContent:'center', gap:8, color:'#6b7280' }}>
            <Loader2 size={16} style={{ animation:'spin 1s linear infinite' }} /> Loading cost plans&hellip;
          </div>
        ) : cpError ? (
          <div style={{ padding:16, color:'#E3725F', fontSize:13, textAlign:'center' }}>Failed to load: {cpError}</div>
        ) : (
        <div className="card overflow-hidden" style={{ borderRadius:0, boxShadow:'none', margin:0 }}>
          {/* top bar */}
          <div style={{ padding:'10px 14px', borderBottom:'1px solid #e5e7eb', background:'#fafafa', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, flexWrap:'wrap' }}>
            {/* Left: title + global search + filter */}
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <div style={{ position:'relative', flex:'0 1 260px', minWidth:200 }}>
                <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                <input
                  type="text"
                  value={cpGlobalSearch}
                  onChange={e => setCpGlobalSearch(e.target.value)}
                  placeholder="Search cost plans..."
                  style={{ width:'100%', paddingLeft:32, paddingRight: cpGlobalSearch ? 28 : 10, paddingTop:6, paddingBottom:6, fontSize:13, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
                  onFocus={e => e.target.style.borderColor = '#1A3673'}
                  onBlur={e => e.target.style.borderColor = '#d1d5db'}
                />
                {cpGlobalSearch && (
                  <button onClick={() => setCpGlobalSearch('')}
                    style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                    <X size={13} />
                  </button>
                )}
              </div>
              <button 
                onClick={openCpFilterPopup}
                onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
                onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
                title="Apply filters"
                style={{ 
                  display:'inline-flex', 
                  alignItems:'center', 
                  gap:6, 
                  fontSize:13, 
                  fontWeight:600, 
                  background:'#1A3673', 
                  color:'#fff', 
                  border:'none', 
                  borderRadius:999, 
                  padding:'6px 14px', 
                  cursor:'pointer',
                  transition:'transform 0.1s ease',
                  position:'relative'
                }}
              >
                <Filter size={13} />
                {cpActiveFilterCount > 0 && (
                  <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 7px', minWidth:20, textAlign:'center' }}>
                    {cpActiveFilterCount}
                  </span>
                )}
              </button>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              {(cpActiveFilterCount > 0 || cpGlobalSearch) && (
                <button onClick={() => { cpClearAllFilters(); setCpGlobalSearch(''); }}
                  style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'5px 12px', cursor:'pointer', whiteSpace:'nowrap', flexShrink:0 }}>
                  <X size={11} /> Clear All
                </button>
              )}
              <button 
                onClick={cpExportCSV}
                onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
                onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
                style={{ 
                  display:'inline-flex', 
                  alignItems:'center', 
                  gap:6, 
                  fontSize:13, 
                  fontWeight:600, 
                  background:'#1A3673', 
                  color:'#fff', 
                  border:'none', 
                  borderRadius:999, 
                  padding:'6px 14px', 
                  cursor:'pointer',
                  transition: 'all 0.15s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.opacity = '0.9'}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.opacity = '1';
                }}
              >
                <Download size={13} /> Export
              </button>
            </div>
          </div>
          {/* table */}
          <div style={{ overflowX:'auto', maxHeight:480 }}>
            <table className="w-full" style={{ borderCollapse:'collapse', minWidth:'max-content', fontSize:12 }}>
              <thead style={{ position:'sticky', top:0, zIndex:10 }}>
                <tr style={{ background:'#1A3673', height:32 }}>
                  <th onClick={() => cpHandleSort('cpNum')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Cost Plan Number <span style={{ opacity: cpSortField === 'cpNum' ? 1 : 0.3 }}>{cpSortField === 'cpNum' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('fp')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Fiscal Period <span style={{ opacity: cpSortField === 'fp' ? 1 : 0.3 }}>{cpSortField === 'fp' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('costType')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Cost Type <span style={{ opacity: cpSortField === 'costType' ? 1 : 0.3 }}>{cpSortField === 'costType' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('freq')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Frequency <span style={{ opacity: cpSortField === 'freq' ? 1 : 0.3 }}>{cpSortField === 'freq' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('mtype')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Metric Type <span style={{ opacity: cpSortField === 'mtype' ? 1 : 0.3 }}>{cpSortField === 'mtype' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('mdesc')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Metric Desc <span style={{ opacity: cpSortField === 'mdesc' ? 1 : 0.3 }}>{cpSortField === 'mdesc' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('planDesc')} style={{ padding:'0 10px', whiteSpace:'nowrap', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Plan Description <span style={{ opacity: cpSortField === 'planDesc' ? 1 : 0.3 }}>{cpSortField === 'planDesc' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => cpHandleSort('cost')} style={{ padding:'0 10px', whiteSpace:'nowrap', textAlign:'right', color:'#fff', fontWeight:600, fontSize:12, cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4, justifyContent:'flex-end' }}>
                      Cost <span style={{ opacity: cpSortField === 'cost' ? 1 : 0.3 }}>{cpSortField === 'cost' && cpSortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {finalCpData.length === 0 ? (
                  <tr><td colSpan={8} style={{ padding:'24px 12px', textAlign:'center', color:'#9ca3af', fontSize:11 }}>No records match the current filters. <button onClick={() => { cpClearAllFilters(); setCpGlobalSearch(''); }} style={{ color:'#1A3673', background:'none', border:'none', cursor:'pointer', fontWeight:600, fontSize:11 }}>Clear filters</button></td></tr>
                ) : finalCpData.map((r, i) => {
                  const dash = <span style={{color:'#d1d5db'}}>—</span>;
                  const txt  = (v) => (!v || v === '—') ? dash : v;
                  return (
                    <tr key={r.cpNum} style={{ height:30, background:i%2===0?'#fff':'#EFF6FF', borderBottom:'1px solid #f3f4f6' }}>
                      <td style={{ padding:'0 12px', fontFamily:'monospace', fontSize:12, color:'#1A3673', whiteSpace:'nowrap', fontWeight:600 }}>{txt(r.cpNum)}</td>
                      <td style={{ padding:'0 12px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.fp)}</td>
                      <td style={{ padding:'0 12px', whiteSpace:'nowrap' }}>
                        {(!r.costType || r.costType === '—') ? dash : <span style={{ fontSize:11, fontWeight:600, padding:'2px 8px', borderRadius:999, background:'#f0fdfa', color:'#00BBBA', border:'1px solid #66D6D6' }}>{r.costType}</span>}
                      </td>
                      <td style={{ padding:'0 12px', color:'#6b7280', whiteSpace:'nowrap' }}>{txt(r.freq)}</td>
                      <td style={{ padding:'0 12px', color:'#4b5563', whiteSpace:'nowrap' }}>{txt(r.mtype)}</td>
                      <td style={{ padding:'0 12px', color:'#4b5563', whiteSpace:'nowrap' }}>{txt(r.mdesc)}</td>
                      <td style={{ padding:'0 12px', color:'#374151', maxWidth:240, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }} title={r.planDesc}>{txt(r.planDesc)}</td>
                      <td style={{ padding:'0 12px', textAlign:'right', fontFamily:'monospace', fontSize:12, fontWeight:700, color:'#1A3673', whiteSpace:'nowrap' }}>
                        {(() => { const v = activeTab === 'from' ? r.costFrom : r.costTo; return v == null ? dash : `$${v.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}`; })()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr style={{ height:30, background:'rgba(26,54,115,0.07)', borderTop:'2px solid rgba(26,54,115,0.15)' }}>
                  <td colSpan={7} style={{ padding:'0 12px', fontSize:12, fontWeight:700, color:'#1A3673' }}>TOTAL ({finalCpData.length} record{finalCpData.length!==1?'s':''})</td>
                  <td style={{ padding:'0 12px', textAlign:'right', fontFamily:'monospace', fontSize:12, fontWeight:700, color:'#374151', whiteSpace:'nowrap' }}>
                    ${finalCpData.reduce((s,r)=>s+(activeTab==='from'?r.costFrom:r.costTo),0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        )
      )}
      </div>{/* /Cost Plan outer card */}

      </div>{/* /space-y-4 pt-4 */}
    </div>
  );
}
