import { useState, useRef, useMemo, useEffect, memo } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, X, Trash2, FolderOpen, Search, Filter, ChevronDown, ChevronUp, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Eye, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { uploadApi } from '../../config/apiConfig';
import { useTableFilter } from '../../hooks/useTableFilter';
import { useTableSort } from '../../hooks/useTableSort';
import { useGlobalSearch } from '../../hooks/useGlobalSearch';

const DESTINATIONS = [
  { id: 'auto',                 label: 'Auto-detect',        description: 'Automatically route based on file name and type',  accepts: ['*'] },
  { id: 'data',                 label: 'Data Tab',           description: 'Claims data, source extracts, raw files',           accepts: ['.xlsx', '.csv', '.xls'] },
  { id: 'costs',                label: 'Costs Tab',          description: 'Cost line items, FTE requests, IT expenses',        accepts: ['.xlsx', '.xls', '.csv'] },
  { id: 'financial_model',      label: 'Financial Model Tab',description: 'Financial model workbooks',                         accepts: ['.xlsx', '.xls'] },
  { id: 'financial_summary',    label: 'Financial Summary Tab', description: 'Financial summary reports',                      accepts: ['.xlsx', '.xls', '.pdf'] },
  { id: 'scaling',              label: 'Membership Scaling Tab', description: 'Scaling factor spreadsheets',                  accepts: ['.xlsx', '.xls', '.csv'] },
  { id: 'multi_sheet_original', label: 'Multi Sheet Original',  description: '',                                              accepts: ['*'] },
  { id: 'coversheet',           label: 'Coversheet',           description: 'Coversheet documents',                             accepts: ['*'] },
];

const CATEGORY_KEYWORD_MAP = [
  { dest: 'data',                 keywords: ['data', 'query', 'queries'] },
  { dest: 'costs',                keywords: ['costs', 'costplan', 'cost plan', 'cost plans'] },
  { dest: 'financial_model',      keywords: ['financial_model'] },
  { dest: 'financial_summary',    keywords: ['financial_summary'] },
  { dest: 'scaling',              keywords: ['scaling', 'scale'] },
  { dest: 'multi_sheet_original', keywords: ['multi_sheet_original'] },
  { dest: 'coversheet',           keywords: ['coversheet'] },
];

const normalizeCategory = (cat) => {
  if (!cat) return null;
  const lower = cat.toLowerCase().replace(/[\s-]/g, '_');
  for (const { dest, keywords } of CATEGORY_KEYWORD_MAP) {
    if (keywords.some(k => k.replace(/[\s-]/g, '_') === lower)) return dest;
  }
  return cat;
};

function detectDestination(fileName) {
  const lower = fileName.toLowerCase().replace(/[\s-]/g, '_');
  for (const { dest, keywords } of CATEGORY_KEYWORD_MAP) {
    if (keywords.some(k => lower.includes(k.replace(/[\s-]/g, '_')))) return dest;
  }
  return 'data';
}

const stripPrefix = (name) => {
  if (!name) return name;
  const idx = name.indexOf('_');
  if (idx <= 0) return name;
  const prefix = name.slice(0, idx);
  if (/^CVR(-[A-Z0-9]+)+$/i.test(prefix)) return name.slice(idx + 1);
  return name;
};

const _IMG_EXTS    = new Set(['png','jpg','jpeg','gif','bmp','webp','svg']);
const _TABLE_TYPES = new Set(['csv','excel','xlsx','xls']);
const _TEXT_TYPES  = new Set(['txt','text','sql','docx','doc']);
const _GENERIC     = { image: true, text: true, document: true };

const UploadFilePreview = memo(function UploadFilePreview({ pdata, fileName }) {
  const ext      = (fileName?.split('.').pop() ?? '').toLowerCase();
  const apiType  = pdata?.type?.toLowerCase() ?? '';
  const resolved = ext || (_GENERIC[apiType] ? '' : apiType) || apiType;

  const imgSrc = useMemo(() => {
    const isImg = _IMG_EXTS.has(resolved) || apiType === 'image' || apiType.startsWith('image/');
    if (!isImg) return null;
    const raw = pdata.image_data ?? pdata.content ?? pdata.url ?? pdata.image_url ?? '';
    if (!raw) return null;
    if (raw.startsWith('http') || raw.startsWith('data:') || raw.startsWith('/') || raw.startsWith('blob:')) return raw;
    let mime = pdata.mime_type || `image/${resolved || 'png'}`;
    if (raw.startsWith('iVBORw0')) mime = 'image/png';
    else if (raw.startsWith('/9j/'))   mime = 'image/jpeg';
    else if (raw.startsWith('R0lGOD')) mime = 'image/gif';
    else if (raw.startsWith('UklGR'))  mime = 'image/webp';
    return `data:${mime};base64,${raw}`;
  }, [pdata, resolved, apiType]);

  const isTable = _TABLE_TYPES.has(resolved) || (_TABLE_TYPES.has(apiType) && !resolved);

  if (isTable && pdata.headers && pdata.rows) {
    const colLetter = (i) => { let s='',n=i; do { s=String.fromCharCode(65+(n%26))+s; n=Math.floor(n/26)-1; } while(n>=0); return s; };
    const sheetName = pdata.sheet_name || 'Sheet1';
    const totalRows = pdata.total_rows ?? pdata.rows.length;
    const XL = { toolbar:'#217346', headerBg:'#E8E8E8', headerBorder:'#B0B0B0', rowNumBg:'#F2F2F2', rowNumColor:'#666', gridLine:'#D0D7DE', cellBg:'#fff', altBg:'#F9FBFF', selBg:'#E8F4FE' };
    return (
      <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0, fontFamily:'"Calibri","Segoe UI",Arial,sans-serif', background:'#fff' }}>
        <div style={{ background:XL.toolbar, padding:'5px 12px', display:'flex', alignItems:'center', gap:12, flexShrink:0 }}>
          <span style={{ fontSize:12, fontWeight:700, color:'#fff' }}>Spreadsheet Preview</span>
          <span style={{ fontSize:11, color:'#a7f3d0', marginLeft:'auto' }}>Showing {pdata.rows.length.toLocaleString()} of {totalRows.toLocaleString()} rows · {pdata.headers.length} columns</span>
        </div>
        <div style={{ background:'#F3F3F3', borderBottom:`1px solid ${XL.gridLine}`, padding:'3px 10px', display:'flex', alignItems:'center', gap:8, flexShrink:0 }}>
          <span style={{ fontSize:11, color:'#555', fontWeight:600, minWidth:28, textAlign:'center', border:`1px solid ${XL.headerBorder}`, borderRadius:2, padding:'1px 4px', background:'#fff' }}>A1</span>
          <span style={{ fontSize:11, color:'#888', marginLeft:2 }}>fx</span>
          <span style={{ fontSize:11, color:'#333', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{pdata.rows[0]?.[0] ?? ''}</span>
        </div>
        <div style={{ flex:1, overflow:'auto', minHeight:0 }}>
          <table style={{ borderCollapse:'collapse', fontSize:12, tableLayout:'auto', minWidth:'max-content', width:'100%' }}>
            <thead style={{ position:'sticky', top:0, zIndex:3 }}>
              <tr>
                <th style={{ minWidth:46, width:46, background:XL.headerBg, border:`1px solid ${XL.headerBorder}`, padding:0 }} />
                {pdata.headers.map((_,i) => <th key={i} style={{ background:XL.headerBg, border:`1px solid ${XL.headerBorder}`, padding:'3px 8px', fontSize:11, fontWeight:700, color:'#333', textAlign:'center', whiteSpace:'nowrap', minWidth:80, userSelect:'none' }}>{colLetter(i)}</th>)}
              </tr>
              <tr>
                <th style={{ minWidth:46, width:46, background:XL.headerBg, border:`1px solid ${XL.headerBorder}`, fontSize:11, fontWeight:700, color:XL.rowNumColor, textAlign:'center', userSelect:'none' }}>#</th>
                {pdata.headers.map((h,i) => <th key={i} style={{ background:'#DEEAF1', border:`1px solid ${XL.headerBorder}`, padding:'5px 10px', fontSize:12, fontWeight:700, color:'#1A3673', textAlign:'left', whiteSpace:'nowrap', minWidth:80, borderBottom:'2px solid #1A3673' }}>{h ?? ''}</th>)}
              </tr>
            </thead>
            <tbody>
              {pdata.rows.map((row, ri) => (
                <tr key={ri} style={{ background: ri%2===0 ? XL.cellBg : XL.altBg }}
                  onMouseEnter={e => { e.currentTarget.style.background=XL.selBg; }}
                  onMouseLeave={e => { e.currentTarget.style.background=ri%2===0?XL.cellBg:XL.altBg; }}>
                  <td style={{ background:XL.rowNumBg, border:`1px solid ${XL.headerBorder}`, padding:'3px 8px', fontSize:11, color:XL.rowNumColor, textAlign:'center', fontWeight:500, userSelect:'none', minWidth:46, width:46 }}>{ri+1}</td>
                  {pdata.headers.map((_,ci) => <td key={ci} style={{ border:`1px solid ${XL.gridLine}`, padding:'4px 10px', whiteSpace:'nowrap', color:'#1f2937', fontSize:12, maxWidth:260, overflow:'hidden', textOverflow:'ellipsis' }}>{row[ci] ?? ''}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ background:'#EDEDED', borderTop:`1px solid ${XL.gridLine}`, display:'flex', alignItems:'stretch', flexShrink:0, height:26 }}>
          <div style={{ display:'flex', alignItems:'center', padding:'0 16px', background:XL.toolbar, color:'#fff', fontSize:11, fontWeight:700, borderRight:'2px solid #155e3a', cursor:'default', userSelect:'none' }}>{sheetName}</div>
          <div style={{ flex:1 }} />
          {totalRows > pdata.rows.length && <span style={{ fontSize:10, color:'#888', padding:'0 10px', display:'flex', alignItems:'center' }}>{totalRows - pdata.rows.length} more rows not shown</span>}
        </div>
      </div>
    );
  }

  if (_TEXT_TYPES.has(resolved) || (apiType === 'text' && !ext)) {
    const content = pdata.content ?? (Array.isArray(pdata.rows) ? pdata.rows.join('\n') : '');
    const isSql = resolved === 'sql';
    return (
      <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0 }}>
        <div style={{ padding:'8px 16px', background: isSql?'#eff6ff':'#f9fafb', borderBottom:`2px solid ${isSql?'#bfdbfe':'#e5e7eb'}`, display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
          <span style={{ fontSize:12, fontWeight:700, color: isSql?'#1d4ed8':'#374151' }}>{isSql?'SQL Preview':resolved==='docx'?'Document Preview':'Text Preview'}</span>
        </div>
        <div style={{ overflow:'auto', flex:1, minHeight:0 }}>
          <pre style={{ margin:0, padding:16, fontSize:12, fontFamily:'"Fira Mono","Consolas",monospace', color: isSql?'#1e40af':'#1f2937', background: isSql?'#eff6ff':'#fff', whiteSpace:'pre-wrap', lineHeight:1.8 }}>{content}</pre>
        </div>
      </div>
    );
  }

  if (resolved === 'pdf' || apiType === 'pdf') {
    const textContent = pdata.text_content ?? pdata.content ?? '';
    if (textContent) return (
      <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0 }}>
        <div style={{ padding:'8px 16px', background:'#f0f4fa', borderBottom:'2px solid #fecaca', display:'flex', justifyContent:'space-between', alignItems:'center', flexShrink:0 }}>
          <span style={{ fontSize:12, fontWeight:700, color:'#b91c1c' }}>PDF Text Preview</span>
          <span style={{ fontSize:11, color:'#6b7280' }}>Page {pdata.preview_pages??1} of {pdata.total_pages??1}</span>
        </div>
        <div style={{ overflow:'auto', flex:1, minHeight:0 }}>
          <pre style={{ margin:0, padding:16, fontSize:12, fontFamily:'inherit', color:'#1f2937', background:'#fff', whiteSpace:'pre-wrap', lineHeight:1.8 }}>{textContent}</pre>
        </div>
      </div>
    );
    return <div style={{ padding:48, textAlign:'center', color:'#6b7280', fontSize:13 }}>PDF preview unavailable. Download the file to view.</div>;
  }

  if (imgSrc) return (
    <div style={{ flex:1, overflow:'auto', background:'#f9fafb', padding:24, display:'flex', justifyContent:'center', alignItems:'flex-start' }}>
      <img src={imgSrc} alt={fileName} loading="lazy" style={{ maxWidth:'100%', borderRadius:6, objectFit:'contain', boxShadow:'0 2px 12px rgba(0,0,0,0.10)', display:'block' }} />
    </div>
  );

  return <div style={{ padding:32, textAlign:'center', color:'#6b7280', fontSize:13 }}>Preview not available for this file type ({ext || resolved || 'unknown'}).</div>;
});

export default function UploadDocumentTab({ coversheet, onRefetchConfig }) {
  const { can } = useAuth();
  const canEdit = can('edit_cost_plan');
  const { showToast } = useToast();
  const fileInputRef = useRef(null);
  const [destination, setDestination] = useState('auto');
  const [dragOver, setDragOver] = useState(false);
  const [uploaded, setUploaded] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({}); // { [tempId]: 0-100 }
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [pageSize, setPageSize] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  const formatFileSize = (bytes) => {
    if (!bytes) return '—';
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  useEffect(() => {
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    uploadApi.fetchDocuments(cvrsht_id)
      .then(data => {
        if (data.success && Array.isArray(data.documents)) {
          setUploaded(data.documents.map(doc => ({
            id: doc.file_id,
            name: doc.file_name,
            size: formatFileSize(doc.file_size),
            destination: normalizeCategory(doc.category) || detectDestination(doc.file_name),
            detectedBy: 'auto',
            uploadedAt: doc.upload_date
              ? new Date(doc.upload_date).toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
              : '—',
            uploadedBy: doc.uploaded_by || doc.owner_name || '—',
            status: 'routed',
          })));
        }
      })
      .catch(err => console.warn('[UploadDocumentTab] Could not load documents:', err.message));
  }, [coversheet?.cvrsht_id, coversheet?.id]);

  // ── Filter hook ──────────────────────────────────────────────────────────
  const {
    pendingFilters,
    isFilterOpen,
    setIsFilterOpen,
    updatePendingFilter,
    applyFilters,
    clearPendingFilters,
    clearAllFilters,
    cancelFilters,
    activeFilterCount,
  } = useTableFilter(uploaded, {
    name: '',
    destination: '',
    detectedBy: '',
  });

  // Separate uploading items — pinned at top, bypass filter/sort/page
  const uploadingItems = useMemo(() => uploaded.filter(doc => doc.status === 'uploading'), [uploaded]);

  // Apply filters manually — only to non-uploading items
  const filteredData = useMemo(() => {
    return uploaded.filter(doc => {
      if (doc.status === 'uploading') return false;
      if (pendingFilters.name && !doc.name.toLowerCase().includes(pendingFilters.name.toLowerCase())) return false;
      if (pendingFilters.destination && doc.destination !== pendingFilters.destination) return false;
      if (pendingFilters.detectedBy && doc.detectedBy !== pendingFilters.detectedBy) return false;
      return true;
    });
  }, [uploaded, pendingFilters]);

  // ── Global search hook ───────────────────────────────────────────────────
  const { searchTerm: globalSearch, setSearchTerm: setGlobalSearch, searchedData } = useGlobalSearch(filteredData);

  // ── Sort hook ────────────────────────────────────────────────────────────
  const { sortField, sortDir, handleSort, sortedData } = useTableSort(searchedData, 'uploadedAt', 'desc');

  const totalPages = Math.max(1, Math.ceil(sortedData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const pagedData = sortedData.slice((safePage - 1) * pageSize, safePage * pageSize);

  const handleFiles = async (files) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    const ALLOWED_EXTENSIONS = new Set(['.xlsx','.xls','.csv','.pdf','.docx','.sql','.txt','.png','.jpg','.jpeg','.gif','.bmp','.webp','.svg']);
    for (const file of Array.from(files)) {
      const ext = '.' + file.name.split('.').pop().toLowerCase();
      if (!ALLOWED_EXTENSIONS.has(ext)) {
        showToast(`"${file.name}" is not a supported file type. Allowed: ${[...ALLOWED_EXTENSIONS].join(', ')}`, 'error');
        continue;
      }
      const category = destination === 'auto' ? null : destination;
      const detected = destination === 'auto' ? 'auto' : destination;
      const tempId = `temp-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      setUploaded(prev => [{
        id: tempId,
        name: file.name,
        size: formatFileSize(file.size),
        destination: detected,
        detectedBy: destination === 'auto' ? 'auto' : 'manual',
        uploadedAt: '—',
        uploadedBy: '—',
        status: 'uploading',
      }, ...prev]);

      // Simulate progress 0 → 90% while upload is in-flight
      setUploadProgress(prev => ({ ...prev, [tempId]: 0 }));
      let pct = 0;
      const tick = setInterval(() => {
        pct = Math.min(pct + Math.random() * 12, 90);
        setUploadProgress(prev => ({ ...prev, [tempId]: Math.round(pct) }));
      }, 200);

      try {
        const data = await uploadApi.uploadFile(file, category, cvrsht_id);
        clearInterval(tick);
        setUploadProgress(prev => ({ ...prev, [tempId]: 100 }));

        if (data.upload_status === 'duplicate') {
          setUploaded(prev => prev.filter(d => d.id !== tempId));
          setUploadProgress(prev => { const n = { ...prev }; delete n[tempId]; return n; });
          showToast(data.message || `"${file.name}" already exists`, 'warning');
          continue;
        }
        const meta = data.metadata || {};
        setUploaded(prev => prev.map(d => d.id === tempId ? {
          id: data.file_id,
          name: data.file_name,
          size: formatFileSize(meta.file_size ?? file.size),
          destination: meta.category || detected,
          detectedBy: destination === 'auto' ? 'auto' : 'manual',
          uploadedAt: meta.upload_date
            ? new Date(meta.upload_date).toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
            : new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }),
          uploadedBy: meta.owner_name || meta.uploaded_by || '—',
          status: 'routed',
        } : d));
        // Clean up progress after short delay
        setTimeout(() => setUploadProgress(prev => { const n = { ...prev }; delete n[tempId]; return n; }), 800);
        const destLabel = DESTINATIONS.find(d => d.id === detected)?.label ?? detected;
        showToast(`"${data.file_name}" uploaded to ${destLabel}`, 'success');
        onRefetchConfig?.();
      } catch (err) {
        clearInterval(tick);
        setUploadProgress(prev => { const n = { ...prev }; delete n[tempId]; return n; });
        console.error('Upload error:', err);
        setUploaded(prev => prev.filter(d => d.id !== tempId));
        showToast(`Failed to upload "${file.name}": ${err.message}`, 'error');
      }
    }
    setUploading(false);
  };

  const removeDoc = async () => {
    if (!confirmDelete) return;
    const { id, name } = confirmDelete;
    setConfirmDelete(null);
    try {
      await uploadApi.deleteDocument(id);
      setUploaded(prev => prev.filter(d => d.id !== id));
      showToast(`"${name}" deleted`, 'success');
    } catch (err) {
      console.error('Delete error:', err);
      showToast(`Failed to delete "${name}": ${err.message}`, 'error');
    }
  };

  const destInfo = (dest) => DESTINATIONS.find(d => d.id === dest);

  /* ── Preview state ── */
  const [previewModal, setPreviewModal]   = useState(null);
  const [previewData,  setPreviewData]   = useState({});
  const [previewLoad,  setPreviewLoad]   = useState({});

  const openPreviewModal = async (doc) => {
    const cached = previewData[doc.id];
    if (cached) { setPreviewModal({ doc, data: cached }); return; }
    setPreviewLoad(prev => ({ ...prev, [doc.id]: true }));
    try {
      const data = await uploadApi.previewDocument(doc.id);
      setPreviewData(prev => ({ ...prev, [doc.id]: data }));
      setPreviewModal({ doc, data });
    } catch (err) {
      showToast(`Preview failed: ${err.message}`, 'error');
    } finally {
      setPreviewLoad(prev => ({ ...prev, [doc.id]: false }));
    }
  };
  const closePreviewModal = () => setPreviewModal(null);

  return (
    <div className="space-y-4">

      {/* Upload card — hidden for Read-Only users */}
      {canEdit && <div className="card p-4 space-y-4">
        {/* Title */}
        <div>
          <p className="card-title">Upload Document</p>
          <p className="text-xs text-gray-400 mt-0.5">
            Upload any file for <span className="font-medium text-[#1A3673]">{coversheet.cin}</span> — auto-routed to the correct tab based on file name
          </p>
        </div>

        {/* Send to selector + drop zone side by side */}
        <div className="flex items-center gap-4">
          {/* Left: Send to label + dropdown stacked, description under dropdown */}
          <div className="flex flex-col gap-1.5">
            <span className="text-sm font-semibold text-gray-600">Send to:</span>
            <div className="flex items-center gap-2 border border-gray-300 rounded-lg px-3 py-2 bg-white text-sm text-[#1A3673] font-medium cursor-pointer select-none min-w-[200px]">
              <FolderOpen size={14} />
              <select
                value={destination}
                onChange={e => setDestination(e.target.value)}
                className="bg-transparent outline-none cursor-pointer text-sm text-[#1A3673] font-medium w-full"
              >
                {DESTINATIONS.map(d => (
                  <option key={d.id} value={d.id}>{d.label}</option>
                ))}
              </select>
            </div>
            <span className="text-xs text-gray-400 italic">{destInfo(destination)?.description}</span>
          </div>

          {/* Right: Drop zone */}
          <div
            className={`flex-1 border-2 border-dashed rounded-xl transition-all ${
              uploading
                ? 'border-[#1A3673] bg-[#EEF3FB] cursor-default'
                : dragOver
                  ? 'border-[#1A3673] bg-[#E3F4FD] cursor-pointer'
                  : 'border-gray-200 bg-gray-50/50 hover:border-[#44B8F3] hover:bg-[#E3F4FD]/30 cursor-pointer'
            }`}
            onClick={() => !uploading && fileInputRef.current?.click()}
            onDragOver={e => { e.preventDefault(); if (!uploading) setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
          >
            <style>{`
              @keyframes upload-bounce {
                0%, 100% { transform: translateY(0); }
                40%       { transform: translateY(-5px); }
                70%       { transform: translateY(-2px); }
              }
              .upload-icon-animate { animation: upload-bounce 1.4s ease-in-out infinite; }
            `}</style>

            {uploading && uploadingItems.length > 0 ? (
              /* ── Progress view ── */
              <div style={{ padding:'14px 18px', display:'flex', flexDirection:'column', gap:10 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:2 }}>
                  <Loader2 size={15} style={{ color:'#1A3673', flexShrink:0 }} className="animate-spin" />
                  <span style={{ fontSize:13, fontWeight:700, color:'#1A3673' }}>
                    {uploadingItems.length > 1 ? `Uploading ${uploadingItems.length} files…` : `Uploading file…`}
                  </span>
                </div>
                {uploadingItems.map(item => {
                  const pct = uploadProgress[item.id] ?? 0;
                  return (
                    <div key={item.id} style={{ display:'flex', flexDirection:'column', gap:4 }}>
                      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                        <span style={{ fontSize:12, color:'#374151', fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:'85%' }}>{item.name}</span>
                        <span style={{ fontSize:11, fontWeight:700, color:'#1A3673', flexShrink:0 }}>{pct}%</span>
                      </div>
                      <div style={{ height:5, borderRadius:999, background:'#c7d2e7', overflow:'hidden' }}>
                        <div style={{ height:'100%', borderRadius:999, background:'#1A3673', width:`${pct}%`, transition:'width 0.2s ease' }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* ── Idle / drag view ── */
              <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:16, padding:'16px 20px' }}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${dragOver ? 'bg-[#1A3673] text-white' : 'bg-white border border-gray-200 text-[#44B8F3]'}`}>
                  <span className="upload-icon-animate" style={{ display:'flex' }}>
                    <Upload size={18} />
                  </span>
                </div>
                <div>
                  <p className="text-base font-semibold text-[#1A3673]">
                    {dragOver ? 'Drop to upload' : 'Drag & drop files here, or click to browse'}
                  </p>
                  <p className="text-sm text-gray-400 mt-0.5">Supports CSV, XLSX, XLS, SQL and more</p>
                </div>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".xlsx,.xls,.csv,.pdf,.docx,.sql,.txt,.png,.jpg,.jpeg,.gif,.bmp,.webp,.svg"
              className="hidden"
              onChange={e => handleFiles(e.target.files)}
            />
          </div>
        </div>
      </div>}

      {/* Filter Popup Modal */}
      {isFilterOpen && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={cancelFilters}>
          <div style={{ background:'#fff', borderRadius:12, maxWidth:700, width:'100%', maxHeight:'90vh', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div style={{ padding:'16px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <Filter size={20} color="#fff" />
                <h3 style={{ margin:0, fontSize:16, fontWeight:700, color:'#fff' }}>Filter Files</h3>
              </div>
              <button onClick={cancelFilters} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}>
                <X size={20} />
              </button>
            </div>

            {/* Body */}
            <div style={{ padding:24, maxHeight:'calc(90vh - 180px)', overflowY:'auto' }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:16 }}>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Tab Name</label>
                  <input type="text" value={pendingFilters.name} onChange={e => updatePendingFilter('name', e.target.value)}
                    placeholder="Search tab name..."
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }}
                    onFocus={e => e.target.style.borderColor = '#1A3673'}
                    onBlur={e => e.target.style.borderColor = '#d1d5db'} />
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Tab Type</label>
                  <select value={pendingFilters.destination} onChange={e => updatePendingFilter('destination', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {DESTINATIONS.filter(d => d.id !== 'auto').map(d => <option key={d.id} value={d.id}>{d.label}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Detected By</label>
                  <select value={pendingFilters.detectedBy} onChange={e => updatePendingFilter('detectedBy', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    <option value="auto">Auto-detected</option>
                    <option value="manual">Manual</option>
                  </select>
                </div>

              </div>
            </div>

            {/* Footer */}
            <div style={{ padding:'16px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
              <button onClick={clearPendingFilters}
                style={{ padding:'8px 16px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>
                Clear All
              </button>
              <div style={{ display:'flex', gap:10 }}>
                <button onClick={cancelFilters}
                  style={{ padding:'8px 20px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>
                  Cancel
                </button>
                <button onClick={applyFilters}
                  style={{ padding:'8px 24px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Uploaded files table — full width */}
      {uploaded.length > 0 && (

        <div className="card overflow-hidden">
          {/* Top bar: title left, search + filter right */}
          <div style={{ padding:'10px 14px', borderBottom:'1px solid #e5e7eb', background:'#fff', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, flexWrap:'wrap' }}>
            <p className="card-title" style={{ margin:0 }}>Uploaded Files</p>
            {/* Search + filter – right side */}
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ position:'relative', flex:'0 1 280px' }}>
                <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                <input
                  type="text"
                  value={globalSearch}
                  onChange={e => setGlobalSearch(e.target.value)}
                  placeholder="Search files..."
                  style={{ width:'100%', paddingLeft:32, paddingRight: globalSearch ? 28 : 10, paddingTop:6, paddingBottom:6, fontSize:13, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
                  onFocus={e => e.target.style.borderColor = '#1A3673'}
                  onBlur={e => e.target.style.borderColor = '#d1d5db'}
                />
                {globalSearch && (
                  <button onClick={() => setGlobalSearch('')}
                    style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                    <X size={13} />
                  </button>
                )}
              </div>
              <button
                onClick={() => setIsFilterOpen(true)}
                onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
                onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
                title="Apply filters"
                style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'6px 14px', cursor:'pointer', transition:'transform 0.1s ease', position:'relative' }}>
                <Filter size={13} />
                {activeFilterCount > 0 && (
                  <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 7px', minWidth:20, textAlign:'center' }}>
                    {activeFilterCount}
                  </span>
                )}
              </button>
              {activeFilterCount > 0 && (
                <button onClick={clearAllFilters}
                  style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'5px 12px', cursor:'pointer', whiteSpace:'nowrap', flexShrink:0 }}>
                  <X size={11} /> Clear All
                </button>
              )}
            </div>
          </div>
          <div style={{ overflowX:'auto', maxHeight:480 }}>
            <table className="w-full" style={{ borderCollapse:'collapse', minWidth:'max-content', fontSize:13 }}>
              <thead style={{ position:'sticky', top:0, zIndex:10 }}>
                <tr style={{ background:'#1A3673', height:36 }}>
                  <th onClick={() => handleSort('name')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:13, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      File Name <span style={{ opacity: sortField === 'name' ? 1 : 0.3 }}>{sortField === 'name' && sortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => handleSort('size')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:13, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Size <span style={{ opacity: sortField === 'size' ? 1 : 0.3 }}>{sortField === 'size' && sortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => handleSort('uploadedAt')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:13, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Uploaded At <span style={{ opacity: sortField === 'uploadedAt' ? 1 : 0.3 }}>{sortField === 'uploadedAt' && sortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => handleSort('destination')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:13, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Tab Type <span style={{ opacity: sortField === 'destination' ? 1 : 0.3 }}>{sortField === 'destination' && sortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th onClick={() => handleSort('detectedBy')} style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:13, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      Detected By <span style={{ opacity: sortField === 'detectedBy' ? 1 : 0.3 }}>{sortField === 'detectedBy' && sortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                  <th style={{ padding:'0 10px', color:'#fff', fontWeight:600, fontSize:13, textAlign:'center', whiteSpace:'nowrap' }}>Preview</th>
                  <th style={{ padding:'0 10px', width:32 }}></th>
                </tr>
              </thead>
              <tbody>
                {/* Pinned uploading rows — always visible at top, bypasses filter/sort/page */}
                {uploadingItems.map((doc) => {
                  const info = destInfo(doc.destination);
                  const pct = uploadProgress[doc.id] ?? 0;
                  return (
                    <tr key={doc.id} style={{ background:'#EEF3FB', borderBottom:'1px solid #e5e7eb' }}>
                      <td style={{ padding:'8px 10px', whiteSpace:'nowrap' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                          <Loader2 size={13} style={{ color:'#1A3673', flexShrink:0, animation:'spin 1s linear infinite' }} className="animate-spin" />
                          <div style={{ display:'flex', flexDirection:'column', gap:4, minWidth:180 }}>
                            <span style={{ fontWeight:500, color:'#374151' }} title={doc.name}>{stripPrefix(doc.name)}</span>
                            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                              <div style={{ flex:1, height:4, borderRadius:999, background:'#c7d2e7', overflow:'hidden', minWidth:120 }}>
                                <div style={{ height:'100%', borderRadius:999, background:'#1A3673', width:`${pct}%`, transition:'width 0.2s ease' }} />
                              </div>
                              <span style={{ fontSize:10, fontWeight:700, color:'#1A3673', flexShrink:0 }}>{pct}%</span>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td style={{ padding:'0 10px', color:'#9ca3af', whiteSpace:'nowrap' }}>{doc.size}</td>
                      <td style={{ padding:'0 10px', color:'#9ca3af', whiteSpace:'nowrap', fontStyle:'italic' }}>Uploading…</td>
                      <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                        <span style={{ fontSize:12, fontWeight:600, padding:'2px 8px', borderRadius:999, background:'#E3F4FD', color:'#1A3673', border:'1px solid #C7EAFB' }}>{info?.label}</span>
                      </td>
                      <td style={{ padding:'0 10px', color:'#9ca3af', fontSize:12, fontStyle:'italic' }}>—</td>
                      <td /><td />
                    </tr>
                  );
                })}

                {pagedData.map((doc, i) => {
                  const info = destInfo(doc.destination);

                  return (
                    <tr key={doc.id} style={{ height:34, background: i%2===0 ? '#fff' : '#EFF6FF', borderBottom:'1px solid #f3f4f6' }}>
                      <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                          <FileText size={13} style={{ color:'#9ca3af', flexShrink:0 }} />
                          <span style={{ fontWeight:500, color:'#374151', whiteSpace:'nowrap' }} title={doc.name}>{stripPrefix(doc.name)}</span>
                        </div>
                      </td>
                      <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{doc.size}</td>
                      <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{doc.uploadedAt}</td>
                      <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                        <span style={{ fontSize:12, fontWeight:600, padding:'2px 8px', borderRadius:999, background:'#E3F4FD', color:'#1A3673', border:'1px solid #C7EAFB', whiteSpace:'nowrap' }}>
                          {info?.label}
                        </span>
                      </td>
                      <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                        {doc.detectedBy === 'auto'
                          ? <span style={{ fontSize:12, color:'#6b7280', fontStyle:'italic' }}>Auto-detected</span>
                          : <span style={{ fontSize:12, color:'#6b7280' }}>Manual</span>}
                      </td>
                      <td style={{ padding:'0 10px', textAlign:'center' }}>
                        <button
                          onClick={() => openPreviewModal(doc)}
                          disabled={!!previewLoad[doc.id]}
                          title="Preview file"
                          style={{ background:'#f3f4f6', border:'none', borderRadius:6, cursor:'pointer', color:'#1A3673', padding:'3px 8px', display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, opacity: previewLoad[doc.id] ? 0.6 : 1, transition:'background 0.15s' }}
                          onMouseEnter={e => { if (!previewLoad[doc.id]) e.currentTarget.style.background='#dbeafe'; }}
                          onMouseLeave={e => e.currentTarget.style.background='#f3f4f6'}>
                          {previewLoad[doc.id] ? <Loader2 size={13} className="animate-spin" /> : <Eye size={13} />}
                        </button>
                      </td>
                      {canEdit && (
                        <td style={{ padding:'0 10px', textAlign:'center', width:32 }}>
                          <button onClick={() => setConfirmDelete(doc)} title="Delete" style={{ background:'none', border:'none', cursor:'pointer', color:'#1A3673', transition:'color 0.15s', display:'flex', alignItems:'center', justifyContent:'center' }}
                            onMouseEnter={e => e.currentTarget.style.color = '#2861BB'}
                            onMouseLeave={e => e.currentTarget.style.color = '#1A3673'}>
                            <Trash2 size={13} />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {sortedData.length === 0 && (
              <div style={{ padding:24, textAlign:'center', color:'#9ca3af', fontSize:11 }}>No files match your filters. <button onClick={() => { clearAllFilters(); setGlobalSearch(''); }} style={{ color:'#1A3673', background:'none', border:'none', cursor:'pointer', fontWeight:600, fontSize:11 }}>Clear filters</button></div>
            )}
          </div>

          {/* Pagination footer */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', borderTop:'1px solid #e5e7eb', background:'#fafafa', flexWrap:'wrap', gap:8 }}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ fontSize:12, color:'#6b7280' }}>Rows per page:</span>
              <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                style={{ fontSize:12, fontWeight:600, color:'#374151', border:'1px solid #d1d5db', borderRadius:6, padding:'3px 8px', background:'#fff', cursor:'pointer', outline:'none' }}>
                {[10, 25, 50, 100].map(n => <option key={n} value={n}>{n}</option>)}
              </select>
              <span style={{ fontSize:12, color:'#9ca3af', marginLeft:4 }}>
                {sortedData.length === 0 ? '0' : `${(safePage - 1) * pageSize + 1}–${Math.min(safePage * pageSize, sortedData.length)}`} of {sortedData.length}
              </span>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:4 }}>
              <button onClick={() => setCurrentPage(1)} disabled={safePage === 1}
                style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===1 ? 'not-allowed' : 'pointer', color: safePage===1 ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
                <ChevronsLeft size={14} />
              </button>
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={safePage === 1}
                style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===1 ? 'not-allowed' : 'pointer', color: safePage===1 ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
                <ChevronLeft size={14} />
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(p => p === 1 || p === totalPages || Math.abs(p - safePage) <= 1)
                .reduce((acc, p, idx, arr) => {
                  if (idx > 0 && p - arr[idx - 1] > 1) acc.push('...');
                  acc.push(p);
                  return acc;
                }, [])
                .map((p, idx) => p === '...' ? (
                  <span key={`ellipsis-${idx}`} style={{ padding:'4px 6px', fontSize:12, color:'#9ca3af' }}>…</span>
                ) : (
                  <button key={p} onClick={() => setCurrentPage(p)}
                    style={{ padding:'4px 10px', borderRadius:6, border:'1px solid', fontSize:12, fontWeight:600, cursor:'pointer', transition:'all .15s',
                      background: safePage === p ? '#1A3673' : '#fff',
                      color:      safePage === p ? '#fff'    : '#374151',
                      borderColor: safePage === p ? '#1A3673' : '#d1d5db' }}>
                    {p}
                  </button>
                ))}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={safePage === totalPages}
                style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===totalPages ? 'not-allowed' : 'pointer', color: safePage===totalPages ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
                <ChevronRight size={14} />
              </button>
              <button onClick={() => setCurrentPage(totalPages)} disabled={safePage === totalPages}
                style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===totalPages ? 'not-allowed' : 'pointer', color: safePage===totalPages ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
                <ChevronsRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Preview Modal ── */}
      {previewModal && (
        <div onClick={e => { if (e.target === e.currentTarget) closePreviewModal(); }}
          style={{ position:'fixed', inset:0, zIndex:10000, background:'rgba(0,0,0,0.65)', display:'flex', alignItems:'center', justifyContent:'center', padding:32 }}>
          <div style={{ background:'#fff', borderRadius:12, boxShadow:'0 8px 48px rgba(0,0,0,0.30)', width:'calc(100vw - 64px)', height:'calc(100vh - 64px)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 18px', borderBottom:'1px solid #e5e7eb', background:'#1A3673', borderRadius:'12px 12px 0 0', flexShrink:0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, minWidth:0 }}>
                <FileText size={15} style={{ color:'#93c5fd', flexShrink:0 }} />
                <span style={{ fontWeight:700, fontSize:14, color:'#fff', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{previewModal.doc.name}</span>
                {previewModal.doc.name?.includes('.') && (
                  <span style={{ fontSize:11, fontWeight:600, padding:'2px 8px', borderRadius:4, background:'rgba(255,255,255,0.15)', color:'#e0f2fe', flexShrink:0 }}>
                    {previewModal.doc.name.split('.').pop().toUpperCase()}
                  </span>
                )}
              </div>
              <button onClick={closePreviewModal}
                style={{ background:'rgba(255,255,255,0.15)', border:'none', borderRadius:6, cursor:'pointer', color:'#fff', display:'flex', alignItems:'center', padding:6 }}
                onMouseEnter={e => e.currentTarget.style.background='rgba(255,255,255,0.25)'}
                onMouseLeave={e => e.currentTarget.style.background='rgba(255,255,255,0.15)'}>
                <X size={16} />
              </button>
            </div>
            <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'auto', minHeight:0 }}>
              <UploadFilePreview pdata={previewModal.data} fileName={previewModal.doc.name} />
            </div>
          </div>
        </div>
      )}

      {/* Confirm Delete Dialog */}
      {confirmDelete && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={() => setConfirmDelete(null)}>
          <div style={{ background:'#fff', borderRadius:12, width:420, boxShadow:'0 20px 60px rgba(0,0,0,0.3)', overflow:'hidden' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding:'16px 20px', borderBottom:'1px solid #e5e7eb', background:'#1A3673', display:'flex', alignItems:'center', gap:10 }}>
              <Trash2 size={18} color="#fff" />
              <h3 style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Delete File</h3>
            </div>
            <div style={{ padding:24 }}>
              <p style={{ margin:'0 0 6px', fontSize:14, color:'#374151' }}>Are you sure you want to delete this file?</p>
              <p style={{ margin:0, fontSize:13, fontWeight:600, color:'#1A3673', wordBreak:'break-all' }}>{confirmDelete.name}</p>
            </div>
            <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', justifyContent:'flex-end', gap:10 }}>
              <button onClick={() => setConfirmDelete(null)}
                style={{ padding:'7px 18px', fontSize:13, fontWeight:600, borderRadius:8, border:'1px solid #d1d5db', background:'#fff', color:'#374151', cursor:'pointer' }}>
                Cancel
              </button>
              <button onClick={removeDoc}
                style={{ padding:'7px 18px', fontSize:13, fontWeight:600, borderRadius:8, border:'none', background:'#1A3673', color:'#fff', cursor:'pointer' }}>
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
