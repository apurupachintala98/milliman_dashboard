import { useState, useCallback } from 'react';
import { CheckCircle, Send, XCircle, Upload, Download, AlertCircle, Loader, CheckSquare, AlertTriangle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { coversheetApi } from '../../config/apiConfig';


const SectionHeader = ({ title, badge }) => (
  <div className="card-header">
    <div className="card-title">{title}</div>
    {badge}
  </div>
);

const Field = ({ label, value, mono }) => (
  <div className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
    <span className="text-xs text-gray-500 w-44 flex-shrink-0 pt-0.5">{label}</span>
    <span className={`text-xs text-gray-800 flex-1 ${mono ? 'font-mono text-[#1A3673]' : ''}`}>{value || <span className="text-gray-300">—</span>}</span>
  </div>
);

const QualityCheck = ({ label, value, note }) => (
  <div className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
    <span className={`mt-0.5 flex-shrink-0 ${value === 'Y' ? 'text-[#00BBBA]' : value === 'N' ? 'text-[#E3725F]' : 'text-gray-400'}`}>
      {value === 'Y' ? <CheckSquare size={13} /> : value === 'N' ? <AlertTriangle size={13} /> : <AlertCircle size={13} />}
    </span>
    <div className="flex-1 min-w-0">
      <span className="text-xs text-gray-700">{label}</span>
      {note && <p className="text-[10px] text-gray-400 mt-0.5 leading-snug">{note}</p>}
    </div>
    <span className={`text-xs font-bold flex-shrink-0 ${value === 'Y' ? 'text-[#00BBBA]' : value === 'N' ? 'text-[#E3725F]' : 'text-gray-400'}`}>{value}</span>
  </div>
);

const ROLE_PERMISSIONS = {
  'Read-Only':        ['view_dashboard'],
  'Demand Manager':   ['view_dashboard', 'submit_review', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan'],
  'Financial Analyst':['view_dashboard', 'submit_review', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan'],
  'Governance':       ['view_dashboard', 'edit_coversheet', 'submit_review', 'approve_reject', 'push_to_snow', 'download_coversheet', 'export_audit', 'edit_cost_plan', 'override_section1'],

};

export default function OverviewTab({
  coversheet, onStatusChange, onEdit, coversheetConfig, onConfigChange, resolvedRole,
}) {
  const { activeRole: ctxRole } = useAuth();
  // resolvedRole is computed synchronously in the parent via useMemo — always current on phase switch
  // fall back to ctxRole only if resolvedRole is not provided
  const effectiveRole = resolvedRole ?? ctxRole;
  const can = (action) => ROLE_PERMISSIONS[effectiveRole]?.includes(action) ?? false;
  const { showToast } = useToast();
  const [activeSection] = useState('overview');
  const [showPushModal, setShowPushModal] = useState(false);
  const [hasEdits, setHasEdits] = useState(false);

  const FIELDS = [
    { label: 'CIN / Project ID',        key: 'cin' },
    { label: 'Initiative Name',          key: 'name' },
    { label: 'Demand / Project Manager', key: 'demandManager' },
    { label: 'Backup DM',                key: 'backupDM' },
    { label: 'Financial Analyst',        key: 'financialAnalyst' },
    { label: 'Backup FA',                key: 'backupFA' },
    { label: 'SNOW System ID',           key: 'snowCardId' },
    { label: 'Portfolio Group',          key: 'portfolioGroup' },
    { label: 'Portfolio',                key: 'portfolio' },
    { label: 'Coversheet Version',       key: 'coverSheetVersion' },
    { label: 'Recommended Model Name',   key: 'recommended_model_name' },
    { label: 'Created By',               key: 'createdBy' },
    { label: 'Created Date',             key: 'createdDate' },
    { label: 'Last Modified',            key: 'lastModified' },
  ];

  const buildInitial = () => Object.fromEntries(
    FIELDS.map(f => [f.key, String(coversheet[f.key] ?? '')])
  );

  const [fieldValues, setFieldValues] = useState(buildInitial);
  const [savedValues, setSavedValues] = useState(buildInitial);

  const [pushing, setPushing] = useState(false);
  const [pushDone, setPushDone] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    if (!can('download_coversheet')) return;
    setDownloading(true);
    try {
      await coversheetApi.downloadCoversheet(coversheet.id);
      showToast('Coversheet downloaded successfully', 'success');
    } catch (err) {
      showToast(`Download failed: ${err.message}`, 'error');
    } finally {
      setDownloading(false);
    }
  };

  const canOverride = can('override_section1');

  const handlePushToSnow = () => {
    setPushing(true);
    setTimeout(() => {
      setPushing(false);
      setPushDone(true);
      setTimeout(() => {
        setShowPushModal(false);
        setPushDone(false);
        showToast('Successfully pushed to ServiceNow!', 'success');
      }, 1500);
    }, 2500);
  };

  const baseActualsTotal = parseFloat(coversheet.totalActualBenefit ?? 0);
  const scaledActualsTotal = parseFloat(coversheet.totalEnteredBenefit ?? 0);
  const totalCosts = parseFloat(coversheet.totalActualCost ?? 0);
  const roi = scaledActualsTotal - totalCosts;

  const qualityChecks = [
    { label: 'Savings shown on Paid amount basis (not allowed or billed)?', value: 'Y', note: 'For Medicare Rx initiatives, indicates use of the "at-risk" basis' },
    { label: 'Savings limited to appropriate funding types by line of business?', value: 'Y', note: 'Medicaid - All funding, CSBD/GRS - Fully insured non-refunding only, Medicare Advantage/MMP - Fully insured' },
    { label: 'Admin costs limited to appropriate funding types by line of business?', value: 'Y', note: 'ASO admin should only be included if the initiative is an approved exception' },
    { label: 'Savings shown on an incremental basis?', value: 'Y' },
    { label: 'Results adjusted to a plan membership basis?', value: 'Y', note: 'All recurring benefit expense impacts should be adjusted to a Plan membership basis' },
    { label: 'Tracking actuals includes updated projections for future months?', value: 'No' },
  ];

  return (
    <div className="space-y-4">



      {/* ── Financial Summary KPIs ── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Base Actuals Total',   value: `$${(baseActualsTotal / 1000).toFixed(1)}K`,  color: 'text-[#1A3673]', bg: 'bg-[#E3F4FD]' },
          { label: 'Scaled Actuals Total', value: `$${(scaledActualsTotal / 1000).toFixed(1)}K`, color: 'text-[#2861BB]', bg: 'bg-blue-50' },
          { label: 'Total Costs',          value: `$${(totalCosts / 1000).toFixed(1)}K`, color: 'text-[#E3725F]', bg: 'bg-red-50' },
          { label: 'Net ROI',              value: `$${(roi / 1000).toFixed(1)}K`, color: 'text-[#00BBBA]', bg: 'bg-teal-50' },
        ].map(item => (
          <div key={item.label} className={`${item.bg} rounded-lg p-3 text-center`}>
            <p className={`text-xl font-bold ${item.color}`}>{item.value}</p>
            <p className="text-[10px] text-gray-500 mt-0.5 leading-snug">{item.label}</p>
          </div>
        ))}
      </div>


      {/* ── Section 1: Initiative Overview ── */}
      {activeSection === 'overview' && (
        <div className="card">
          <SectionHeader num="1" title="Initiative Overview"
            badge={canOverride
              ? <span className="text-xs text-[#00BBBA] font-medium">Governance Override ✓</span>
              : null}
          />
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-x-8">
            {FIELDS.map(({ label, key }) => (
              <div key={key} className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500 w-44 flex-shrink-0 pt-0.5">{label}</span>
                {canOverride
                  ? <input
                      value={fieldValues[key]}
                      onChange={e => { setFieldValues(p => ({ ...p, [key]: e.target.value })); setHasEdits(true); onEdit(); }}
                      className="form-input flex-1 text-xs py-0.5"
                    />
                  : <span className="text-xs text-gray-800 flex-1">{savedValues[key]}</span>
                }
              </div>
            ))}
          </div>
          {canOverride && hasEdits && (
            <div className="px-4 py-3 border-t border-gray-100 flex justify-end gap-2 bg-gray-50">
              <button className="px-4 py-1.5 text-xs font-medium text-gray-500 border border-gray-200 rounded-lg hover:border-gray-400 transition"
                onClick={() => { setFieldValues(savedValues); setHasEdits(false); }}>
                Discard
              </button>
              <button className="btn-primary text-xs flex items-center gap-1.5"
                onClick={() => { setSavedValues(fieldValues); setHasEdits(false); showToast('Changes saved successfully', 'success'); }}>
                <CheckCircle size={11} /> Apply
              </button>
            </div>
          )}
        </div>
      )}



      {/* ── Push to SNOW Modal ── */}
      {showPushModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-base font-bold text-[#1A3673]">Confirm Push to ServiceNow</h3>
              <p className="text-xs text-gray-500 mt-1">Review the data to be submitted before confirming.</p>
            </div>
            <div className="p-6 space-y-4">
              <div className="bg-[#F5F5F5] rounded-lg p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-gray-600">Coversheet:</span><span className="font-medium text-[#1A3673]">{coversheet.name}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">CIN:</span><span className="font-medium">{coversheet.cin}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">SNOW Card:</span><span className="font-medium">{coversheet.snowCardId}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Benefit Plans:</span><span className="font-medium">{coversheet.benefitPlans.length} plans</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Base Actuals Total:</span><span className="font-bold text-[#1A3673]">${baseActualsTotal.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Scaled Actuals Total:</span><span className="font-bold text-[#00BBBA]">${scaledActualsTotal.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span></div>
                {totalCosts > 0 && <div className="flex justify-between"><span className="text-gray-600">Total Costs:</span><span className="font-medium text-[#E3725F]">${totalCosts.toLocaleString()}</span></div>}
                <div className="flex justify-between border-t border-gray-200 pt-2"><span className="text-gray-600 font-semibold">Net ROI:</span><span className="font-bold text-[#00BBBA]">${roi.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span></div>
              </div>
              <div className="text-xs text-gray-500 bg-blue-50 p-3 rounded-lg">
                Excel coversheet (9 tabs) will be attached to SNOW record as audit document.
              </div>
              {pushing && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-[#1A3673]">
                    <Loader size={14} className="animate-spin" /> Pushing to ServiceNow...
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2">
                    <div className="bg-[#44B8F3] h-2 rounded-full animate-pulse" style={{ width: '70%' }} />
                  </div>
                </div>
              )}
              {pushDone && (
                <div className="flex items-center gap-2 text-sm text-[#00BBBA] font-semibold">
                  <CheckCircle size={16} /> Push successful! Audit entry logged.
                </div>
              )}
            </div>
            {!pushing && !pushDone && (
              <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
                <button className="btn-outline" onClick={() => setShowPushModal(false)}>Cancel</button>
                <button className="btn-primary flex items-center gap-1.5 bg-[#2861BB]" onClick={handlePushToSnow}>
                  <Upload size={13} /> Confirm Push
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
