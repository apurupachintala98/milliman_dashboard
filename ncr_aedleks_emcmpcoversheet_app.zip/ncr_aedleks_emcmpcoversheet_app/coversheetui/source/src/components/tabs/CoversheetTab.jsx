import { useState, useRef, useCallback, useEffect } from 'react';
import { CheckSquare, AlertTriangle, Pencil, Check, Search, Filter, X, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { modelingApi, coversheetTabApi } from '../../config/apiConfig';

const DEFAULT_PERIOD = { mode: 'Monthly', selectedKey: 'All' };

const SECTIONS = [
  { key: 'modeling', label: 'Modeling & Quality' },
  { key: 'cost',     label: 'Cost Plan' },
  { key: 'benefit',  label: 'Benefit Plan' },
  { key: 'roi',      label: 'ROI' },
];

const PLACEHOLDER = <span className="text-gray-300 select-none">—</span>;


const EditToggle = ({ editing, onToggle, onCancel, disabled }) => (
  editing ? (
    <div className="flex items-center gap-1 flex-shrink-0">
      <button
        onClick={onCancel}
        disabled={disabled}
        className={`inline-flex items-center gap-1 text-[10px] font-medium rounded-full px-2 py-0.5 border transition ${
          disabled
            ? 'bg-gray-100 text-gray-300 border-gray-200 cursor-not-allowed'
            : 'bg-red-50 text-[#E3725F] border-[#E3725F]/40 hover:bg-red-100'
        }`}
      >
        <X size={9} /> Cancel
      </button>
      <button
        onClick={onToggle}
        disabled={disabled}
        className={`inline-flex items-center gap-1 text-[10px] font-medium rounded-full px-2 py-0.5 border transition ${
          disabled
            ? 'bg-gray-100 text-gray-300 border-gray-200 cursor-not-allowed'
            : 'bg-[#1A3673] text-white border-[#1A3673] hover:bg-[#2861BB]'
        }`}
      >
        <Check size={9} /> Done
      </button>
    </div>
  ) : (
    <button
      onClick={onToggle}
      disabled={disabled}
      className={`inline-flex items-center gap-1 text-[10px] font-medium rounded-full px-2 py-0.5 border transition flex-shrink-0 ${
        disabled
          ? 'bg-gray-100 text-gray-300 border-gray-200 cursor-not-allowed'
          : 'bg-gray-100 text-gray-500 border-gray-200 hover:bg-gray-200'
      }`}
    >
      <Pencil size={9} /> Edit
    </button>
  )
);

const Field = ({ label, value, editing, onChange }) => (
  <div className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
    <span className="text-xs text-gray-500 w-56 flex-shrink-0 pt-0.5">{label}</span>
    {editing && onChange
      ? <input
          className="form-input flex-1 text-xs py-0.5"
          value={value}
          onChange={e => onChange(e.target.value)}
        />
      : <span className="text-xs text-gray-800 flex-1">{value || PLACEHOLDER}</span>
    }
  </div>
);

// Single date-picker — passes the same date to both start and end in the payload
const SingleDateField = ({ label, value, editing, onChange }) => (
  <div className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
    <span className="text-xs text-gray-500 w-56 flex-shrink-0 pt-0.5">{label}</span>
    {editing ? (
      <input
        type="date"
        className="form-input text-xs py-0.5 flex-1"
        value={value || ''}
        onChange={e => onChange(e.target.value)}
      />
    ) : (
      <span className="text-xs text-gray-800 flex-1">{value || PLACEHOLDER}</span>
    )}
  </div>
);

// Two date-pickers (Start → End) for date-range fields
const DateRangeField = ({ label, start, end, editing, onStartChange, onEndChange }) => {
  const display = start || end
    ? `${start || '—'}  →  ${end || '—'}`
    : null;
  return (
    <div className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
      <span className="text-xs text-gray-500 w-56 flex-shrink-0 pt-0.5">{label}</span>
      {editing ? (
        <div className="flex items-center gap-2 flex-1 flex-wrap">
          <div className="flex flex-col gap-0.5 flex-1 min-w-[130px]">
            <span className="text-[10px] text-gray-400 font-medium">Start</span>
            <input
              type="date"
              className="form-input text-xs py-0.5"
              value={start || ''}
              onChange={e => onStartChange(e.target.value)}
            />
          </div>
          <span className="text-gray-300 text-xs mt-4">→</span>
          <div className="flex flex-col gap-0.5 flex-1 min-w-[130px]">
            <span className="text-[10px] text-gray-400 font-medium">End</span>
            <input
              type="date"
              className="form-input text-xs py-0.5"
              value={end || ''}
              onChange={e => onEndChange(e.target.value)}
            />
          </div>
        </div>
      ) : (
        <span className="text-xs text-gray-800 flex-1">{display || PLACEHOLDER}</span>
      )}
    </div>
  );
};

const INITIAL_QUALITY_CHECKS = [
  { label: 'Savings shown on Paid amount basis (not allowed or billed)?',           value: 'Y', note: 'For Medicare Rx initiatives, indicates use of the "at-risk" basis' },
  { label: 'Savings limited to appropriate funding types by line of business?',      value: 'Y', note: 'Medicaid - All funding, CSBD/GRS - Fully insured non-refunding only, Medicare Advantage/MMP - Fully insured' },
  { label: 'Admin costs limited to appropriate funding types by line of business?',  value: 'Y', note: 'ASO admin should only be included if the initiative is an approved exception' },
  { label: 'Savings shown on an incremental basis?',                                 value: 'Y' },
  { label: 'Results adjusted to a plan membership basis?',                           value: 'Y', note: 'All recurring benefit expense impacts should be adjusted to a Plan membership basis' },
  { label: 'Tracking actuals includes updated projections for future months?',       value: 'N' },
];

export default function CoversheetTab({ onEdit, coversheet, coversheetConfig, onConfigChange, onModelingSaved, phaseStatus }) {
  const { can, activeRole } = useAuth();
  const { showToast } = useToast();
  const canEdit = can('edit_cost_plan');
  const isReadOnly = activeRole === 'Read-Only';

  const flags       = coversheetConfig?.flags ?? {};
  const scalingOn   = flags.scaling_applicable_flag?.value?.toUpperCase() === 'YES';
  const costOn      = flags.cost_plan_applicable_flag?.value?.toUpperCase() === 'YES';
  const [savingFlag, setSavingFlag] = useState(null);

  const handleFlagToggle = useCallback(async (flagKey, currentValue) => {
    if (!coversheetConfig || !coversheet?.cin || coversheet.cin === '—' || isReadOnly) return;
    const newValue = currentValue ? 'NO' : 'YES';
    const updatedConfig = {
      ...coversheetConfig,
      flags: { ...coversheetConfig.flags, [flagKey]: { ...coversheetConfig.flags[flagKey], value: newValue } },
    };
    onConfigChange(updatedConfig);
    setSavingFlag(flagKey);
    try {
      const { configApi } = await import('../../config/apiConfig');
      await configApi.updateConfig(coversheet.cin, updatedConfig);
      showToast(`${flagKey === 'scaling_applicable_flag' ? 'Membership Scaling' : 'Cost Plan'} ${newValue === 'YES' ? 'enabled' : 'disabled'}`, 'success');
    } catch (err) {
      onConfigChange(coversheetConfig);
      showToast(`Failed to update: ${err.message}`, 'error');
    } finally {
      setSavingFlag(null);
    }
  }, [coversheetConfig, coversheet, onConfigChange, showToast, isReadOnly]);
  const [activeSection, setActiveSection] = useState('modeling');
  const [editing, setEditing] = useState(false);
  const [qualityChecks, setQualityChecks] = useState(INITIAL_QUALITY_CHECKS);
  const [period, setPeriod] = useState(DEFAULT_PERIOD);

  // ROI table filter state
  const [roiGlobalSearch, setRoiGlobalSearch] = useState('');
  const [roiFilterOpen,   setRoiFilterOpen]   = useState(false);
  const [roiFilters,      setRoiFilters]      = useState({ cat: '', freq: '', type: '' });
  const [roiPending,      setRoiPending]      = useState({ cat: '', freq: '', type: '' });

  // Cost Plan table filter state
  const [cpGlobalSearch, setCpGlobalSearch] = useState('');
  const [cpFilterOpen,   setCpFilterOpen]   = useState(false);
  const [cpFilters,      setCpFilters]      = useState({ cpNumber: '', costType: '', frequency: '', metricType: '', metricDesc: '', description: '' });
  const [cpPending,      setCpPending]      = useState({ cpNumber: '', costType: '', frequency: '', metricType: '', metricDesc: '', description: '' });

  // Scroll sync refs for Cost Plan split table
  const cpScrollTrackRef = useRef(null);
  const cpScrollInnerRef = useRef(null);
  const cpSyncFromTrack  = (e) => { if (cpScrollInnerRef.current) cpScrollInnerRef.current.scrollLeft = e.target.scrollLeft; };

  // Scroll sync refs for ROI split table
  const roiScrollTrackRef = useRef(null);
  const roiScrollInnerRef = useRef(null);
  const roiSyncFromTrack  = (e) => { if (roiScrollInnerRef.current) roiScrollInnerRef.current.scrollLeft = e.target.scrollLeft; };

  // Editable modeling fields
  const [modelingFields, setModelingFields] = useState({
    dataSourceProj:         '',
    dataSourceActuals:      '',
    incurredStart:          '',
    incurredEnd:            '',
    paidThruStart:          '',
    paidThruEnd:            '',
    initiativeStart:        '',
    initiativeEnd:          '',
    earliestImpact:         '',
    lastActual:             '',
    methodDesc:             '',
    methodComments:         '',
  });
  const [modelingLoading, setModelingLoading] = useState(false);
  const [modelingSaving,  setModelingSaving]  = useState(false);

  // ── Coversheet Tab financial data (Benefit Plan, Cost Plan, ROI) ─────────────
  const [tabData,    setTabData]    = useState(null);
  const [tabLoading, setTabLoading] = useState(false);
  const [tabError,   setTabError]   = useState(null);

  // Map period.mode → API view param
  const periodModeToView = (mode) =>
    mode === 'Quarterly' ? 'quarterly' : mode === 'Yearly' ? 'yearly' : 'monthly';

  // Fetch coversheet-tab data whenever coversheet ID or view changes
  useEffect(() => {
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    if (!cvrsht_id) return;
    setTabLoading(true);
    setTabError(null);
    coversheetTabApi.get(cvrsht_id, { view: periodModeToView(period.mode), basis: 'auto' })
      .then(data => { setTabData(data); })
      .catch(err => { setTabError(err.message); showToast(`Failed to load financial data: ${err.message}`, 'error'); })
      .finally(() => setTabLoading(false));
  }, [coversheet?.cvrsht_id, coversheet?.id, period.mode]); // eslint-disable-line react-hooks/exhaustive-deps

  // Helper: map a date-only string "YYYY-MM-DD" → display, pass through other strings
  const fmtDate = (v) => v || '';

  // Map API response → UI state
  const applyApiData = useCallback((data) => {
    setModelingFields({
      dataSourceProj:    data.projn_ds_nm                   ?? '',
      dataSourceActuals: data.actl_ds_nm                    ?? '',
      incurredStart:     data.incrd_exprnc_prd_strt_dt      ?? '',
      incurredEnd:       data.incrd_exprnc_prd_end_dt       ?? '',
      paidThruStart:     data.paid_thru_exprnc_prd_strt_dt  ?? '',
      paidThruEnd:       data.paid_thru_exprnc_prd_end_dt   ?? '',
      initiativeStart:   data.initv_prd_strt_dt             ?? '',
      initiativeEnd:     data.initv_prd_end_dt              ?? '',
      earliestImpact:    data.erlst_impct_dt                ?? '',
      lastActual:        data.last_actl_mnth_dt             ?? '',
      methodDesc:        data.svng_projn_mthdlgy_desc       ?? '',
      methodComments:    data.addnl_cmnts_txt               ?? '',
    });
    if (Array.isArray(data.qlty_chk_txt) && data.qlty_chk_txt.length > 0) {
      setQualityChecks(data.qlty_chk_txt.map(q => ({
        label: q.question    ?? '',
        value: q.answer      ?? 'N',
        note:  q.description ?? '',
      })));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Load from API on mount
  useEffect(() => {
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    if (!cvrsht_id) return;
    setModelingLoading(true);
    modelingApi.get(cvrsht_id)
      .then(applyApiData)
      .catch(err => showToast(`Failed to load modeling data: ${err.message}`, 'error'))
      .finally(() => setModelingLoading(false));
  }, [coversheet?.cvrsht_id, coversheet?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Build PUT payload from current state
  const buildPayload = () => ({
    projn_ds_nm:                  modelingFields.dataSourceProj   || null,
    actl_ds_nm:                   modelingFields.dataSourceActuals || null,
    incrd_exprnc_prd_strt_dt:     modelingFields.incurredStart    || null,
    incrd_exprnc_prd_end_dt:      modelingFields.incurredEnd      || null,
    paid_thru_exprnc_prd_strt_dt: modelingFields.paidThruStart    || null,
    paid_thru_exprnc_prd_end_dt:  modelingFields.paidThruEnd      || null,
    initv_prd_strt_dt:            modelingFields.initiativeStart  || null,
    initv_prd_end_dt:             modelingFields.initiativeEnd    || null,
    erlst_impct_dt:               modelingFields.earliestImpact   || null,
    last_actl_mnth_dt:            modelingFields.lastActual       || null,
    svng_projn_mthdlgy_desc:      modelingFields.methodDesc       || null,
    addnl_cmnts_txt:              modelingFields.methodComments   || null,
    qlty_chk_txt: qualityChecks.map(q => ({
      question:    q.label,
      answer:      q.value,
      description: q.note || '',
    })),
  });

  const setField = (key) => (val) => {
    setModelingFields(prev => ({ ...prev, [key]: val }));
    onEdit();
  };

  // ── Pending-params gate ──────────────────────────────────────────────────────
  // When status is "Pending Coversheet Parameters Selection", the 4 mandatory
  // Modeling Considerations fields must be saved before Quality Checks and
  // Savings Projection Methodology become editable.
  const isPendingParams = phaseStatus === 'pending_coversheet_parameters_selection';

  // All 4 mandatory fields must be non-empty (server-side saved values).
  // We check modelingFields which are loaded from the API on mount, so if they
  // have values it means the server already has them.
  const mandatoryFilled =
    !!modelingFields.dataSourceProj.trim() &&
    !!modelingFields.dataSourceActuals.trim() &&
    !!modelingFields.incurredStart &&
    !!modelingFields.incurredEnd &&
    !!modelingFields.paidThruStart;

  // Secondary sections are locked only while status is pending AND mandatory fields not yet filled
  const secondaryLocked = isPendingParams && !mandatoryFilled;

  const [qualitySaving, setQualitySaving] = useState(null); // index being saved

  const toggleQuality = async (index) => {
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    if (!cvrsht_id || qualitySaving !== null) return;

    // Optimistic update
    const updated = qualityChecks.map((q, i) =>
      i === index ? { ...q, value: q.value === 'Y' ? 'N' : 'Y' } : q
    );
    setQualityChecks(updated);
    setQualitySaving(index);

    try {
      await modelingApi.update(cvrsht_id, { ...buildPayload(), qlty_chk_txt: updated.map(q => ({ question: q.label, answer: q.value, description: q.note || '' })) });
      onEdit();
      onModelingSaved?.();
      // Re-fetch to sync with server
      modelingApi.get(cvrsht_id).then(applyApiData).catch(() => {});
    } catch (err) {
      showToast(`Failed to save quality check: ${err.message}`, 'error');
      // Revert optimistic update
      modelingApi.get(cvrsht_id).then(applyApiData).catch(() => {});
    } finally {
      setQualitySaving(null);
    }
  };

  const handleEditToggle = async () => {
    if (editing) {
      // When status is pending params, block saving if mandatory fields are empty
      if (isPendingParams) {
        const missing = [];
        if (!modelingFields.dataSourceProj.trim())    missing.push('Data Source — Projections');
        if (!modelingFields.dataSourceActuals.trim()) missing.push('Data Source — Actuals');
        if (!modelingFields.incurredStart || !modelingFields.incurredEnd)
          missing.push('Experience Period (Incurred)');
        if (!modelingFields.paidThruStart)
          missing.push('Experience Period (Paid Through)');
        if (missing.length) {
          showToast(`Please fill in: ${missing.join(', ')}`, 'error');
          return; // keep editing open
        }
      }
      // Save on Done
      const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
      if (!cvrsht_id) { setEditing(false); return; }
      setModelingSaving(true);
      try {
        await modelingApi.update(cvrsht_id, buildPayload());
        showToast('Modeling & Quality saved', 'success');
        onEdit();
        onModelingSaved?.();
        // Re-fetch GET to ensure UI reflects exactly what the server stored
        modelingApi.get(cvrsht_id)
          .then(applyApiData)
          .catch(() => {}); // silent — user already has their saved values
      } catch (err) {
        showToast(`Save failed: ${err.message}`, 'error');
        // Revert UI to last known server state on failure
        const cvrsht_id2 = coversheet?.cvrsht_id || coversheet?.id;
        if (cvrsht_id2) {
          modelingApi.get(cvrsht_id2)
            .then(applyApiData)
            .catch(() => {});
        }
        return; // keep editing mode open so user can retry
      } finally {
        setModelingSaving(false);
      }
    }
    setEditing(e => !e);
  };

  const handleCancelEdit = () => {
    // Revert to last server-saved state and exit editing
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    if (cvrsht_id) {
      modelingApi.get(cvrsht_id).then(applyApiData).catch(() => {});
    }
    setEditing(false);
  };

  return (
    <div>

      {/* ── Sticky controls ── */}
      <div className="sticky top-0 z-20 -mx-6 px-6 pt-4 pb-3 space-y-2 border-b border-gray-200" style={{ backgroundColor: '#F5F5F5' }}>

        {/* Sub-tab nav */}
        <div className="card p-1 flex gap-1">
          {SECTIONS.map(s => {
            const isActive = activeSection === s.key;
            const isHighlighted = !isActive
              && s.key === 'modeling'
              && phaseStatus === 'pending_coversheet_parameters_selection';
            return (
              <button key={s.key} onClick={() => setActiveSection(s.key)}
                className={`relative flex-1 py-2 rounded-md text-xs font-medium transition ${
                  isActive
                    ? 'bg-[#1A3673] text-white shadow-sm'
                    : isHighlighted
                      ? 'bg-amber-50 text-amber-700 ring-1 ring-amber-400'
                      : 'text-gray-500 hover:bg-gray-100'
                }`}>
                {s.label}
                {isHighlighted && (
                  <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                )}
              </button>
            );
          })}
        </div>

        {/* Period filter bar — shown only for financial sections */}
        {activeSection !== 'modeling' && (
        <div className="card px-4 py-2.5 flex items-center gap-4">
          <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide flex-shrink-0">View by</span>
          <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-0.5">
            {(['Monthly','Quarterly','Yearly']).map(m => (
              <button key={m} onClick={() => setPeriod({ mode: m, selectedKey: 'All' })}
                className={`px-4 py-1.5 text-[11px] font-medium rounded-md transition ${
                  period.mode === m ? 'bg-[#1A3673] text-white shadow-sm' : 'text-gray-500 hover:text-[#1A3673]'
                }`}>{m}</button>
            ))}
          </div>
          <div className="w-px h-5 bg-gray-200 flex-shrink-0" />
          {tabData?.columns?.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-gray-400">
                {period.mode === 'Monthly' ? 'Month' : period.mode === 'Quarterly' ? 'Quarter' : 'Year'}
              </span>
              <select
                className="text-[11px] border border-gray-200 rounded-md px-2.5 py-1.5 bg-white focus:outline-none focus:border-[#1A3673] cursor-pointer"
                value={period.selectedKey}
                onChange={e => setPeriod(p => ({ ...p, selectedKey: e.target.value }))}>
                <option value="All">
                  {period.mode === 'Monthly' ? 'All Months' : period.mode === 'Quarterly' ? 'All Quarters' : 'All Years'}
                </option>
                {tabData.columns.map(col => <option key={col.key} value={col.key}>{col.label}</option>)}
              </select>
            </div>
          )}
          {tabLoading && <Loader2 size={13} className="animate-spin text-gray-400 flex-shrink-0" />}

          <div className="ml-auto text-[10px] text-[#1A3673] font-semibold bg-[#E1EDFF] rounded px-2 py-1">
            {period.selectedKey === 'All'
              ? (period.mode === 'Monthly' ? 'All Months' : period.mode === 'Quarterly' ? 'All Quarters' : 'All Years')
              : (tabData?.columns?.find(c => c.key === period.selectedKey)?.label ?? period.selectedKey)}
          </div>
        </div>
        )}

      </div>{/* /sticky controls */}

      <div className="space-y-4 pt-2">

      {/* ── Modeling & Quality ── */}
      {activeSection === 'modeling' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-4">
            {/* Modeling Considerations */}
            <div className="card overflow-hidden">
              <div className="card-header">
                <div className="card-title">Modeling Considerations</div>
                <div className="flex items-center gap-2">
                  {modelingLoading && <Loader2 size={13} className="animate-spin text-gray-400" />}
                  {modelingSaving  && <Loader2 size={13} className="animate-spin text-[#1A3673]" />}
                  {canEdit && <EditToggle editing={editing} onToggle={handleEditToggle} onCancel={handleCancelEdit} disabled={modelingLoading || modelingSaving} />}
                </div>
              </div>
              {/* Mandatory-fields notice shown only while status is pending params */}
              {isPendingParams && !mandatoryFilled && (
                <div className="mx-4 mt-3 mb-1 flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2">
                  <AlertTriangle size={13} className="text-amber-500 flex-shrink-0 mt-0.5" />
                  <p className="text-[11px] text-amber-700 leading-snug">
                    Complete the 4 required fields below to unlock <strong>Quality Checks</strong> and <strong>Savings Projection Methodology</strong>.
                  </p>
                </div>
              )}
              <div className="p-4">
                <Field
                  label={<>Data Source — Projections{isPendingParams && <span className="text-[#E3725F] ml-0.5">*</span>}</>}
                  value={modelingFields.dataSourceProj}    editing={editing} onChange={setField('dataSourceProj')} />
                <Field
                  label={<>Data Source — Actuals{isPendingParams && <span className="text-[#E3725F] ml-0.5">*</span>}</>}
                  value={modelingFields.dataSourceActuals} editing={editing} onChange={setField('dataSourceActuals')} />
                <DateRangeField
                  label={<>Experience Period (Incurred){isPendingParams && <span className="text-[#E3725F] ml-0.5">*</span>}</>}
                  start={modelingFields.incurredStart}
                  end={modelingFields.incurredEnd}
                  editing={editing}
                  onStartChange={setField('incurredStart')}
                  onEndChange={setField('incurredEnd')}
                />
                <SingleDateField
                  label={<>Experience Period (Paid Through){isPendingParams && <span className="text-[#E3725F] ml-0.5">*</span>}</>}
                  value={modelingFields.paidThruStart}
                  editing={editing}
                  onChange={v => { setField('paidThruStart')(v); setField('paidThruEnd')(v); }}
                />
                <Field
                  label="Initiative Period"
                  value={[modelingFields.initiativeStart, modelingFields.initiativeEnd].filter(Boolean).join('  →  ')}
                  editing={false}
                />
                <Field label="Earliest Impact Date (SNOW)"     value={modelingFields.earliestImpact}    editing={false} />
                <Field label="Last Actual Month in SNOW"       value={modelingFields.lastActual}        editing={false} />

                {/* ── Applicable Flags ── */}
                {coversheetConfig && (
                  <div className="mt-1">
                    {/* Membership Scaling — always visible; interactive only in edit mode */}
                    <div className="flex items-center gap-2 py-1.5 border-b border-gray-50">
                      <span className="text-xs text-gray-500 w-56 flex-shrink-0">Membership Scaling</span>
                      <button
                        onClick={editing ? () => handleFlagToggle('scaling_applicable_flag', scalingOn) : undefined}
                        disabled={!editing || savingFlag === 'scaling_applicable_flag' || isReadOnly}
                        title={!editing ? 'Click Edit to change' : isReadOnly ? 'Read-Only — cannot change' : scalingOn ? 'Click to disable' : 'Click to enable'}
                        style={{
                          width: 56, height: 22, borderRadius: 999, border: 'none',
                          cursor: editing && !isReadOnly ? 'pointer' : 'not-allowed',
                          background: scalingOn ? '#1A3673' : '#d1d5db',
                          position: 'relative', transition: 'background 0.2s', flexShrink: 0,
                          opacity: editing ? 1 : 0.6,
                        }}
                      >
                        {/* Sliding thumb */}
                        <span style={{
                          position: 'absolute', top: 3, left: scalingOn ? 35 : 3,
                          width: 16, height: 16, borderRadius: '50%', background: '#fff',
                          transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
                          zIndex: 1,
                        }} />
                        {/* Yes label — visible when ON */}
                        <span style={{
                          position: 'absolute', left: 7, top: '50%', transform: 'translateY(-50%)',
                          fontSize: 9, fontWeight: 700, color: '#fff',
                          opacity: scalingOn ? 1 : 0, transition: 'opacity 0.15s',
                          userSelect: 'none', pointerEvents: 'none',
                        }}>Yes</span>
                        {/* No label — visible when OFF */}
                        <span style={{
                          position: 'absolute', right: 7, top: '50%', transform: 'translateY(-50%)',
                          fontSize: 9, fontWeight: 700, color: '#fff',
                          opacity: scalingOn ? 0 : 1, transition: 'opacity 0.15s',
                          userSelect: 'none', pointerEvents: 'none',
                        }}>No</span>
                      </button>
                    </div>

                    {/* Cost Plan — read-only display */}
                    <div className="flex items-center gap-2 py-1.5 border-b border-gray-50 last:border-0">
                      <span className="text-xs text-gray-500 w-56 flex-shrink-0">Cost Plan Applicable</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        costOn ? 'bg-[#D9F5F5] text-[#00BBBA] border-[#B2EBEA]' : 'bg-gray-100 text-gray-400 border-gray-200'
                      }`}>{costOn ? 'YES' : 'NO'}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Savings Projection Methodology */}
            <div className="card relative">
              {/* Locked overlay when mandatory fields are not yet filled */}
              {secondaryLocked && (
                <div
                  title="Complete the 4 required fields below to unlock Quality Checks and Savings Projection Methodology"
                  className="absolute inset-0 z-10 rounded-lg cursor-not-allowed"
                  style={{ background: 'rgba(245,245,245,0.7)', backdropFilter: 'blur(1px)' }}
                />
              )}
              <div className="card-header">
                <div className="card-title">Savings Projection Methodology</div>
                {canEdit && <EditToggle editing={editing} onToggle={handleEditToggle} onCancel={handleCancelEdit} disabled={secondaryLocked || modelingLoading || modelingSaving} />}
              </div>
              <div className="p-4 space-y-3">
                <div>
                  <p className="text-xs font-semibold text-gray-600 mb-1">Methodology Description</p>
                  {editing && !secondaryLocked
                    ? <textarea rows={3} className="form-input w-full text-xs py-1 resize-y" value={modelingFields.methodDesc} onChange={e => setField('methodDesc')(e.target.value)} />
                    : <p className="text-xs text-gray-700 leading-relaxed bg-gray-50 rounded p-3">{modelingFields.methodDesc}</p>
                  }
                </div>
                <div>
                  <p className="text-xs font-semibold text-gray-600 mb-1">Additional Comments / Key Decision Points</p>
                  {editing && !secondaryLocked
                    ? <textarea rows={2} placeholder="Enter comments..." className="form-input w-full text-xs py-1 resize-y" value={modelingFields.methodComments} onChange={e => setField('methodComments')(e.target.value)} />
                    : <p className="text-xs text-gray-400 italic">{modelingFields.methodComments || 'No additional comments entered.'}</p>
                  }
                </div>
              </div>
            </div>
          </div>

          {/* Quality Checks */}
          <div className="card relative">
            {/* Locked overlay when mandatory fields are not yet filled */}
            {secondaryLocked && (
              <div
                title="Complete the 4 required fields below to unlock Quality Checks and Savings Projection Methodology"
                className="absolute inset-0 z-10 rounded-lg cursor-not-allowed"
                style={{ background: 'rgba(245,245,245,0.7)', backdropFilter: 'blur(1px)' }}
              />
            )}
            <div className="card-header">
              <div className="card-title">Quality Checks</div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-[#00BBBA] font-semibold">
                  {qualityChecks.filter(q => q.value === 'Y').length}/{qualityChecks.length} Pass
                </span>
              </div>
            </div>
            <div className="p-4">
              {qualityChecks.map((q, i) => (
                <div key={q.label} className="flex items-start gap-2 py-1.5 border-b border-gray-50 last:border-0">
                  <span className={`mt-0.5 flex-shrink-0 ${q.value === 'Y' ? 'text-[#00BBBA]' : 'text-[#E3725F]'}`}>
                    {q.value === 'Y' ? <CheckSquare size={13} /> : <AlertTriangle size={13} />}
                  </span>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs text-gray-700">{q.label}</span>
                    {q.note && <p className="text-[10px] text-gray-400 mt-0.5 leading-snug">{q.note}</p>}
                  </div>
                  <button
                    onClick={() => canEdit && !secondaryLocked && toggleQuality(i)}
                    title={secondaryLocked ? 'Complete Modeling Considerations fields first' : canEdit ? 'Click to toggle Y / N' : 'Read-Only — cannot edit quality checks'}
                    disabled={!canEdit || secondaryLocked || qualitySaving !== null}
                    className={`text-xs font-bold flex-shrink-0 px-2 py-0.5 rounded-full border transition inline-flex items-center gap-1
                      ${q.value === 'Y' ? 'bg-teal-50 text-[#00BBBA] border-[#00BBBA]/30' : 'bg-red-50 text-[#E3725F] border-[#E3725F]/30'}
                      ${canEdit && !secondaryLocked && qualitySaving === null
                        ? q.value === 'Y' ? 'hover:bg-red-50 hover:text-[#E3725F] hover:border-[#E3725F]/30' : 'hover:bg-teal-50 hover:text-[#00BBBA] hover:border-[#00BBBA]/30'
                        : 'cursor-not-allowed opacity-60'
                      }`}>
                    {qualitySaving === i
                      ? <Loader2 size={10} className="animate-spin" />
                      : q.value}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Benefit Plan ── */}
      {activeSection === 'benefit' && (() => {
        // Use API-provided columns; filter to selectedKey if not 'All'
        const apiCols = tabData?.columns ?? [];
        const MONTH_LABELS = period.selectedKey === 'All'
          ? apiCols.map(c => c.label)
          : [apiCols.find(c => c.key === period.selectedKey)?.label ?? period.selectedKey];
        // Get per-column amounts for a benefit_plan row from API
        const aggregateM = (bpRow) => {
          const rowCols = bpRow.columns ?? [];
          if (period.selectedKey === 'All') return apiCols.map(c => rowCols.find(rc => rc.key === c.key)?.amount ?? 0);
          return [rowCols.find(rc => rc.key === period.selectedKey)?.amount ?? 0];
        };
        const allBP = tabData?.benefit_plans ?? [];
        const hasSnpSplit = tabData?.has_snp_split !== false; // default true when missing
        // lob_display lives on each benefit plan row, not at the top level
        const lobDisplay  = allBP[0]?.lob_display ?? tabData?.lob_display ?? 'Benefit Plans';
        const NON_SNP = hasSnpSplit ? allBP.filter(bp => !bp.snp) : [];
        const SNP     = hasSnpSplit ? allBP.filter(bp =>  bp.snp) : [];
        const fmtAmt = (n) => n < 0
          ? <span className="text-[#E3725F]">({`$${Math.abs(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`})</span>
          : <span className={n === 0 ? 'text-gray-300' : ''}>{n === 0 ? '—' : `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</span>;
        const sumTotal = (rows) => rows.reduce((s, r) => s + r.total, 0);

        const BPTable = ({ rows, title }) => {
          const [collapsed, setCollapsed] = useState(false);
          const [search, setSearch] = useState('');
          const [bpFilterOpen, setBpFilterOpen] = useState(false);
          const [bpFilters,    setBpFilters]    = useState({ bpNumber:'', mbu:'', market:'', abbr:'', freq:'', metricType:'', costCat:'' });
          const [bpPending,    setBpPending]    = useState({ bpNumber:'', mbu:'', market:'', abbr:'', freq:'', metricType:'', costCat:'' });
          const [abbrSearch,   setAbbrSearch]   = useState('');
          const [abbrOpen,     setAbbrOpen]     = useState(false);
          const [marketSearch, setMarketSearch] = useState('');
          const [marketOpen,   setMarketOpen]   = useState(false);
          // Separate refs: scrollRef = scrollbar track below, innerScrollRef = hidden right panel
          const innerScrollRef = useRef(null);
          const syncFromTrack = (e) => { if (innerScrollRef.current) innerScrollRef.current.scrollLeft = e.target.scrollLeft; };
          const uniqBP = (fn) => [...new Set(rows.map(fn))].sort();
          const bpActiveCount = Object.values(bpFilters).filter(v => v !== '').length;
          const bpApply  = () => { setBpFilters(bpPending); setBpFilterOpen(false); setAbbrSearch(''); setAbbrOpen(false); setMarketSearch(''); setMarketOpen(false); };
          const bpCancel = () => { setBpPending(bpFilters); setBpFilterOpen(false); setAbbrSearch(''); setAbbrOpen(false); setMarketSearch(''); setMarketOpen(false); };
          const bpClear  = () => { const c = { bpNumber:'', mbu:'', market:'', abbr:'', freq:'', metricType:'', costCat:'' }; setBpFilters(c); setBpPending(c); setSearch(''); setAbbrSearch(''); setAbbrOpen(false); setMarketSearch(''); setMarketOpen(false); setBpFilterOpen(false); };
          const safe = (v) => (v ?? '').toLowerCase();
          const filteredAbbrs    = uniqBP(r => r.abbr ?? '').filter(a => a !== '' && safe(a).includes(abbrSearch.toLowerCase()));
          const filteredMarkets  = uniqBP(r => r.market ?? '').filter(m => m !== '' && safe(m).includes(marketSearch.toLowerCase()));
          const filtered = rows.filter(r => {
            if (search.trim()) {
              const q = search.trim().toLowerCase();
              const hit = safe(r.number).includes(q) || safe(r.lob).includes(q) ||
                safe(r.mbu).includes(q) || safe(r.market).includes(q) ||
                safe(r.abbr).includes(q) || safe(r.freq).includes(q) ||
                safe(r.metricType).includes(q) || safe(r.metricDesc).includes(q) ||
                safe(r.costCat).includes(q);
              if (!hit) return false;
            }
            if (bpFilters.bpNumber   && !safe(r.number).includes(bpFilters.bpNumber.toLowerCase())) return false;
            if (bpFilters.mbu        && r.mbu        !== bpFilters.mbu)        return false;
            if (bpFilters.market     && r.market     !== bpFilters.market)     return false;
            if (bpFilters.abbr       && r.abbr       !== bpFilters.abbr)       return false;
            if (bpFilters.freq       && r.freq       !== bpFilters.freq)       return false;
            if (bpFilters.metricType && r.metricType !== bpFilters.metricType) return false;
            if (bpFilters.costCat    && r.costCat    !== bpFilters.costCat)    return false;
            return true;
          });
          const scrollRef = useRef(null);
          return (
            <div className="card overflow-hidden">
              <div
                className="card-header cursor-pointer select-none hover:bg-gray-50/60 transition"
                onClick={() => setCollapsed(v => !v)}
              >
                <div className="flex items-center gap-2">
                  <span className={`text-gray-400 transition-transform duration-200 ${collapsed ? '-rotate-90' : ''}`}>▾</span>
                  <div className="card-title">{title}</div>
                  <span className="text-[10px] text-gray-400 font-normal normal-case tracking-normal">
                    {filtered.length} plan{filtered.length !== 1 ? 's' : ''}
                    {search ? ` (filtered from ${rows.length})` : ''}
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0" onClick={e => e.stopPropagation()}>
                  <div style={{ position:'relative' }}>
                    <Search size={11} style={{ position:'absolute', left:7, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                    <input type="text" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} style={{ paddingLeft:22, paddingRight: search ? 20 : 7, paddingTop:4, paddingBottom:4, fontSize:11, border:'1px solid #d1d5db', borderRadius:999, outline:'none', width:160 }} />
                    {search && <button onClick={() => setSearch('')} style={{ position:'absolute', right:5, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#9ca3af', display:'flex', padding:0 }}><X size={10} /></button>}
                  </div>
                  <button onClick={() => { setBpPending(bpFilters); setBpFilterOpen(true); }} style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'4px 10px', cursor:'pointer', position:'relative' }}>
                    <Filter size={11} />
                    {bpActiveCount > 0 && <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:9, fontWeight:700, borderRadius:999, padding:'2px 4px', minWidth:16, textAlign:'center', lineHeight:'12px', display:'inline-block' }}>{bpActiveCount}</span>}
                  </button>
                  {(bpActiveCount > 0 || search) && <button onClick={bpClear} style={{ display:'inline-flex', alignItems:'center', gap:3, fontSize:10, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'3px 8px', cursor:'pointer' }}><X size={9} /> Clear All</button>}
                </div>
              </div>
              {bpFilterOpen && (
                <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }} onClick={bpCancel}>
                  <div style={{ background:'#fff', borderRadius:12, maxWidth:500, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }} onClick={e => e.stopPropagation()}>
                    <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673', borderRadius:'12px 12px 0 0' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={18} color="#fff" /><h3 style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Filter — {title}</h3></div>
                      <button onClick={bpCancel} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}><X size={18} /></button>
                    </div>
                    <div style={{ padding:24, display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
                      <div><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>BP Number</label>
                        <input type="text" value={bpPending.bpNumber} onChange={e => setBpPending(p => ({ ...p, bpNumber: e.target.value }))} placeholder="e.g. BPLN027..." style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff', boxSizing:'border-box' }} /></div>
                      <div><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>MBU</label>
                        <select value={bpPending.mbu} onChange={e => setBpPending(p => ({ ...p, mbu: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>{uniqBP(r=>r.mbu).map(o => <option key={o} value={o}>{o}</option>)}
                        </select></div>
                      <div style={{ position:'relative' }}><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Market</label>
                        <button type="button" onClick={() => setMarketOpen(v => !v)} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', color: bpPending.market ? '#1A3673' : '#6b7280' }}>
                          <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:'85%', textAlign:'left' }}>{bpPending.market || 'All'}</span>
                          <span style={{ fontSize:10, color:'#9ca3af', flexShrink:0 }}>{marketOpen ? '▲' : '▼'}</span>
                        </button>
                        {marketOpen && (
                          <div style={{ position:'absolute', top:'100%', left:0, right:0, zIndex:100, background:'#fff', border:'1px solid #d1d5db', borderRadius:6, boxShadow:'0 8px 24px rgba(0,0,0,0.12)', marginTop:2 }}>
                            <div style={{ position:'relative', borderBottom:'1px solid #e5e7eb', padding:'6px 8px' }}>
                              <Search size={11} style={{ position:'absolute', left:16, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                              <input autoFocus type="text" value={marketSearch} onChange={e => setMarketSearch(e.target.value)} placeholder="Search..." style={{ width:'100%', padding:'5px 8px 5px 24px', fontSize:12, border:'1px solid #e5e7eb', borderRadius:4, outline:'none', background:'#f9fafb', boxSizing:'border-box' }} />
                            </div>
                            <div style={{ maxHeight:160, overflowY:'auto' }}>
                              {[{ v:'', l:'All', k:'__all__' }, ...filteredMarkets.map(m => ({ v:m, l:m, k:m }))].map(({ v, l, k }) => (
                                <div key={k} onClick={() => { setBpPending(p => ({ ...p, market: v })); setMarketOpen(false); setMarketSearch(''); }} style={{ padding:'7px 12px', fontSize:13, cursor:'pointer', background: bpPending.market === v ? '#EFF6FF' : 'transparent', color: bpPending.market === v ? '#1A3673' : '#374151', fontWeight: bpPending.market === v ? 600 : 400, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                                  <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{l}</span>
                                  {bpPending.market === v && <span style={{ color:'#1A3673', fontSize:11, flexShrink:0 }}>✓</span>}
                                </div>
                              ))}
                              {filteredMarkets.length === 0 && <div style={{ padding:'8px 12px', fontSize:12, color:'#9ca3af' }}>No results</div>}
                            </div>
                          </div>
                        )}
                      </div>
                      <div style={{ position:'relative' }}><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Abbr</label>
                        <button type="button" onClick={() => setAbbrOpen(v => !v)} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', color: bpPending.abbr ? '#1A3673' : '#6b7280' }}>
                          <span>{bpPending.abbr || 'All'}</span>
                          <span style={{ fontSize:10, color:'#9ca3af' }}>{abbrOpen ? '▲' : '▼'}</span>
                        </button>
                        {abbrOpen && (
                          <div style={{ position:'absolute', top:'100%', left:0, right:0, zIndex:100, background:'#fff', border:'1px solid #d1d5db', borderRadius:6, boxShadow:'0 8px 24px rgba(0,0,0,0.12)', marginTop:2 }}>
                            <div style={{ position:'relative', borderBottom:'1px solid #e5e7eb', padding:'6px 8px' }}>
                              <Search size={11} style={{ position:'absolute', left:16, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                              <input autoFocus type="text" value={abbrSearch} onChange={e => setAbbrSearch(e.target.value)} placeholder="Search..." style={{ width:'100%', padding:'5px 8px 5px 24px', fontSize:12, border:'1px solid #e5e7eb', borderRadius:4, outline:'none', background:'#f9fafb', boxSizing:'border-box' }} />
                            </div>
                            <div style={{ maxHeight:160, overflowY:'auto' }}>
                              {[{ v:'', l:'All', k:'__all__' }, ...filteredAbbrs.map(a => ({ v:a, l:a, k:a }))].map(({ v, l, k }) => (
                                <div key={k} onClick={() => { setBpPending(p => ({ ...p, abbr: v })); setAbbrOpen(false); setAbbrSearch(''); }} style={{ padding:'7px 12px', fontSize:13, cursor:'pointer', background: bpPending.abbr === v ? '#EFF6FF' : 'transparent', color: bpPending.abbr === v ? '#1A3673' : '#374151', fontWeight: bpPending.abbr === v ? 600 : 400, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                                  <span>{l}</span>
                                  {bpPending.abbr === v && <span style={{ color:'#1A3673', fontSize:11 }}>✓</span>}
                                </div>
                              ))}
                              {filteredAbbrs.length === 0 && <div style={{ padding:'8px 12px', fontSize:12, color:'#9ca3af' }}>No results</div>}
                            </div>
                          </div>
                        )}
                      </div>
                      <div><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Frequency</label>
                        <select value={bpPending.freq} onChange={e => setBpPending(p => ({ ...p, freq: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>{uniqBP(r=>r.freq).map(o => <option key={o} value={o}>{o}</option>)}
                        </select></div>
                      <div><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Type</label>
                        <select value={bpPending.metricType} onChange={e => setBpPending(p => ({ ...p, metricType: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>{uniqBP(r=>r.metricType).map(o => <option key={o} value={o}>{o}</option>)}
                        </select></div>
                      <div><label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Category</label>
                        <select value={bpPending.costCat} onChange={e => setBpPending(p => ({ ...p, costCat: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>{uniqBP(r=>r.costCat).map(o => <option key={o} value={o}>{o}</option>)}
                        </select></div>
                    </div>
                    <div style={{ padding:'14px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
                      <button onClick={bpClear} style={{ padding:'7px 14px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                      <div style={{ display:'flex', gap:10 }}>
                        <button onClick={bpCancel} style={{ padding:'7px 18px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                        <button onClick={bpApply} style={{ padding:'7px 22px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {!collapsed && (
                <div>
                  {/* Three-panel table: LEFT fixed | MIDDLE-TOTAL fixed | RIGHT no-scrollbar */}
                  <div className="flex" style={{borderTop:'1px solid #e5e7eb',alignItems:'stretch',overflow:'hidden'}}>
                    {/* LEFT: Plan Identification — fixed */}
                    <div className="flex-shrink-0" style={{boxShadow:'2px 0 5px rgba(0,0,0,0.07)',zIndex:2,overflow:'hidden'}}>
                      <table className="text-xs" style={{borderCollapse:'collapse',height:'100%'}}>
                        <thead>
                          <tr style={{height:28}}><th colSpan={7} style={{padding:'0 12px',fontSize:10,fontWeight:700,color:'#fff',background:'#1A3673',textAlign:'center',whiteSpace:'nowrap'}}>Plan Identification</th></tr>
                          <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>BP Number</th>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>MBU</th>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Market</th>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Abbr</th>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Frequency</th>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Metric Type</th>
                            <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Cost Category</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.length===0
                            ? <tr style={{height:36}}><td colSpan={7} style={{padding:'0 12px',textAlign:'center',color:'#9ca3af',fontSize:10}}>No results match your filters. <button onClick={bpClear} style={{color:'#1A3673',fontWeight:600,textDecoration:'underline',background:'none',border:'none',cursor:'pointer',fontSize:'inherit'}}>Clear filters</button></td></tr>
                            : filtered.map((bp,i)=>{
                              const bg = i%2===0?'#ffffff':'#EFF6FF';
                              return <tr key={bp.number} style={{height:36,background:bg,borderBottom:'1px solid #e5e7eb'}}>
                                <td style={{padding:'0 10px',fontFamily:'monospace',fontSize:10,color:'#1A3673',whiteSpace:'nowrap'}}>{bp.number}</td>
                                <td style={{padding:'0 10px',color:'#4b5563',whiteSpace:'nowrap',maxWidth:140}}><span style={{display:'block',overflow:'hidden',textOverflow:'ellipsis'}} title={bp.mbu}>{bp.mbu}</span></td>
                                <td style={{padding:'0 10px',whiteSpace:'nowrap'}}>{bp.market}</td>
                                <td style={{padding:'0 10px',fontFamily:'monospace',fontSize:10,color:'#6b7280',whiteSpace:'nowrap'}}>{bp.abbr}</td>
                                <td style={{padding:'0 10px',whiteSpace:'nowrap'}}>{bp.freq}</td>
                                <td style={{padding:'0 10px',whiteSpace:'nowrap'}}>{bp.metricType}</td>
                                <td style={{padding:'0 10px',whiteSpace:'nowrap'}}>{bp.costCat}</td>
                              </tr>;
                            })}
                        </tbody>
                        <tfoot>
                          <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                            <td colSpan={8} style={{padding:'0 10px',fontSize:12,fontWeight:700,color:'#1A3673'}}>Total ({rows.length} plan{rows.length!==1?'s':''})</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                    {/* MIDDLE-LEFT: Total — fixed */}
                    <div className="flex-shrink-0" style={{boxShadow:'2px 0 3px rgba(0,0,0,0.04)',zIndex:1,borderLeft:'1px solid #e5e7eb',overflow:'hidden'}}>
                      <table className="text-xs" style={{borderCollapse:'collapse',height:'100%'}}>
                        <thead>
                          <tr style={{height:28}}><th style={{padding:'0 14px',fontSize:10,fontWeight:700,color:'#fff',background:'#1A3673',textAlign:'center',whiteSpace:'nowrap'}}>Total</th></tr>
                          <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                            <th style={{padding:'0 14px',fontSize:10,fontWeight:600,color:'#1A3673',textAlign:'right',background:'rgba(26,54,115,0.05)',whiteSpace:'nowrap'}}>Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.length===0
                            ? <tr style={{height:36}}><td style={{padding:'0 14px'}}></td></tr>
                            : filtered.map((bp,i)=>(
                            <tr key={bp.number} style={{height:36,background:i%2===0?'#ffffff':'#EFF6FF',borderBottom:'1px solid #e5e7eb'}}>
                              <td style={{padding:'0 14px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,whiteSpace:'nowrap',color:'#E3725F'}}>{fmtAmt(bp.total)}</td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                            <td style={{padding:'0 14px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,color:'#E3725F',whiteSpace:'nowrap'}}>{fmtAmt(sumTotal(rows))}</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                    {/* RIGHT: Monthly columns — scrollbar hidden, driven by track below */}
                    <div ref={innerScrollRef} className="scrollbar-none flex-1" style={{borderLeft:'1px solid #e5e7eb',overflowX:'scroll',overflowY:'hidden'}}>
                      <table className="text-xs" style={{borderCollapse:'collapse',minWidth:'max-content',width:'100%'}}>
                        <thead>
                          <tr style={{height:28}}><th colSpan={MONTH_LABELS.length} style={{padding:'0 12px',fontSize:10,fontWeight:700,color:'#fff',background:'#E3725F',textAlign:'center',whiteSpace:'nowrap'}}>{period.mode} Savings</th></tr>
                          <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                            {MONTH_LABELS.map(m=>(
                              <th key={m} style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',textAlign:'right',whiteSpace:'nowrap'}}>{m}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.length===0
                            ? <tr style={{height:36}}><td colSpan={MONTH_LABELS.length}></td></tr>
                            : filtered.map((bp,i)=>(
                            <tr key={bp.number} style={{height:36,background:i%2===0?'#ffffff':'#EFF6FF',borderBottom:'1px solid #e5e7eb'}}>
                              {aggregateM(bp).map((v,idx)=>(
                                <td key={idx} style={{padding:'0 10px',textAlign:'right',fontFamily:'monospace',fontSize:10,whiteSpace:'nowrap'}}>{fmtAmt(v)}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                            {MONTH_LABELS.map((label,idx)=>(
                              <td key={label} style={{padding:'0 10px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,color:'#1A3673',whiteSpace:'nowrap'}}>{fmtAmt(rows.reduce((s,r)=>s+(aggregateM(r)[idx]??0),0))}</td>
                            ))}
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                  {/* Scrollbar track — lives BELOW all panels, drives innerScrollRef */}
                  <div ref={scrollRef} onScroll={syncFromTrack} style={{overflowX:'auto',overflowY:'hidden',borderTop:'1px solid #e5e7eb'}}>
                    {/* Phantom row — same padding/font as monthly cells so scrollable width matches exactly */}
                    <table className="text-xs" style={{borderCollapse:'collapse',minWidth:'max-content',tableLayout:'auto',visibility:'hidden',height:0,overflow:'hidden'}}>
                      <tbody><tr>{MONTH_LABELS.map(m=><td key={m} style={{padding:'0 10px',whiteSpace:'nowrap',fontSize:10}}>{m}</td>)}</tr></tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          );
        };

        const nonSnpTotal = hasSnpSplit ? sumTotal(NON_SNP) : 0;
        const snpTotal    = hasSnpSplit ? sumTotal(SNP)     : 0;
        const grandTotal  = hasSnpSplit ? nonSnpTotal + snpTotal : sumTotal(allBP);

        if (tabLoading && !tabData) return <div className="flex items-center justify-center py-16 gap-2 text-gray-400"><Loader2 size={18} className="animate-spin" /><span className="text-sm">Loading benefit plan data…</span></div>;
        if (tabError && !tabData)   return <div className="card p-6 text-center text-sm text-[#E3725F]"><AlertTriangle size={14} className="inline mr-1" />{tabError}</div>;

        return (
          <div className="space-y-4">
            {/* KPI strip — always 4 tiles; show 0 when no data */}
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: 'Total Benefit Plans', value: String(hasSnpSplit ? NON_SNP.length + SNP.length : allBP.length || 0), color: 'text-[#1A3673]', bg: 'bg-white' },
                { label: 'Non-SNP Plans',        value: String(hasSnpSplit ? NON_SNP.length : 0),                               color: 'text-[#2861BB]', bg: 'bg-[#E1EDFF]' },
                { label: 'SNP Plans',            value: String(hasSnpSplit ? SNP.length : 0),                                   color: 'text-[#00BBBA]', bg: 'bg-teal-50' },
                { label: 'Grand Total Savings',  value: '$' + grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }), color: 'text-green-700', bg: 'bg-green-50' },
              ].map(k => (
                <div key={k.label} className={`${k.bg} rounded-lg border border-gray-100 p-3`}>
                  <p className="text-[10px] text-gray-500 mb-1">{k.label}</p>
                  <p className={`text-sm font-bold ${k.color}`}>{k.value}</p>
                </div>
              ))}
            </div>

            {hasSnpSplit ? (
              <>
                <BPTable rows={SNP}     title={`${lobDisplay} — Special Needs Plans`} />
                <BPTable rows={NON_SNP} title={`${lobDisplay} — Non-Special Needs Plans`} />
              </>
            ) : (
              <BPTable rows={allBP} title={lobDisplay} />
            )}

            <div className="px-4 py-2 bg-amber-50 border-t border-amber-100 flex items-start gap-2">
              <AlertTriangle size={12} className="text-amber-500 mt-0.5 flex-shrink-0" />
              <p className="text-[11px] text-amber-700"><span className="font-semibold">WARNING:</span> Check Benefit Plan rows with negative totals. Only offsetting benefit expense costs should have negative values. If the sum across a Market is negative, refer to Negative Savings Guidance.</p>
            </div>
          </div>
        );
      })()}

      {/* ── Cost Plan ── */}
      {activeSection === 'cost' && (() => {
        // API provides pre-aggregated columns per view; filter by selectedKey if not 'All'
        const apiCols = tabData?.columns ?? [];
        const cpColLabels = period.selectedKey === 'All'
          ? apiCols.map(c => c.label)
          : [apiCols.find(c => c.key === period.selectedKey)?.label ?? period.selectedKey];
        const cpAggregateMonths = (cpRow) => {
          const rowCols = cpRow.columns ?? [];
          if (period.selectedKey === 'All') return apiCols.map(c => ({ label: c.label, val: rowCols.find(rc => rc.key === c.key)?.amount ?? 0 }));
          return [{ label: cpColLabels[0], val: rowCols.find(rc => rc.key === period.selectedKey)?.amount ?? 0 }];
        };
        const CP_DATA = tabData?.cost_plans ?? [];
        const fmt = (n) => n === 0 ? '—' : `$${n.toLocaleString()}`;
        if (tabLoading && !tabData) return <div className="flex items-center justify-center py-16 gap-2 text-gray-400"><Loader2 size={18} className="animate-spin" /><span className="text-sm">Loading cost plan data…</span></div>;
        if (tabError && !tabData)   return <div className="card p-6 text-center text-sm text-[#E3725F]"><AlertTriangle size={14} className="inline mr-1" />{tabError}</div>;
        return (
          <div className="space-y-4">
            {/* Summary KPIs */}
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: 'Total Cost Plans',      value: String(CP_DATA.length),  color: 'text-[#1A3673]', bg: 'bg-white' },
                { label: 'Business Expense Plans', value: String(CP_DATA.filter(c => c.costType === 'Business Expense').length), color: 'text-[#2861BB]', bg: 'bg-[#E1EDFF]' },
                { label: 'Recurring Plans',        value: String(CP_DATA.filter(c => c.frequency === 'Recurring').length), color: 'text-[#00BBBA]', bg: 'bg-teal-50' },
                { label: 'Total Cost',             value: `$${CP_DATA.reduce((s, c) => s + c.total, 0).toLocaleString()}`, color: 'text-[#E3725F]', bg: 'bg-red-50' },
              ].map(k => (
                <div key={k.label} className={`${k.bg} rounded-lg border border-gray-100 p-3`}>
                  <p className="text-[10px] text-gray-500 mb-1">{k.label}</p>
                  <p className={`text-sm font-bold ${k.color}`}>{k.value}</p>
                </div>
              ))}
            </div>

            {/* Cost Plan table */}
            {(() => {
              const cpActiveCount = Object.values(cpFilters).filter(v => v !== '').length;
              const cpApply  = () => { setCpFilters(cpPending); setCpFilterOpen(false); };
              const cpCancel = () => { setCpPending(cpFilters); setCpFilterOpen(false); };
              const cpClear  = () => { const c = { cpNumber:'', costType:'', frequency:'', metricType:'', metricDesc:'', description:'' }; setCpFilters(c); setCpPending(c); setCpGlobalSearch(''); setCpFilterOpen(false); };
              const cpAllCostTypes   = [...new Set(CP_DATA.map(c => c.costType))].sort();
              const cpAllFrequencies = [...new Set(CP_DATA.map(c => c.frequency))].sort();
              const cpAllMetricTypes = [...new Set(CP_DATA.map(c => c.metricType))].sort();
              const cpAllMetricDescs = [...new Set(CP_DATA.map(c => c.metricDesc))].sort();
              const cpFiltered = CP_DATA.filter(cp => {
                if (cpGlobalSearch.trim()) {
                  const q = cpGlobalSearch.trim().toLowerCase();
                  if (![cp.number,cp.costType,cp.frequency,cp.metricType,cp.metricDesc,cp.description].some(v => v.toLowerCase().includes(q))) return false;
                }
                if (cpFilters.cpNumber   && !cp.number.toLowerCase().includes(cpFilters.cpNumber.toLowerCase()))       return false;
                if (cpFilters.costType   && cp.costType   !== cpFilters.costType)   return false;
                if (cpFilters.frequency  && cp.frequency  !== cpFilters.frequency)  return false;
                if (cpFilters.metricType && cp.metricType !== cpFilters.metricType) return false;
                if (cpFilters.metricDesc && cp.metricDesc !== cpFilters.metricDesc) return false;
                if (cpFilters.description && !cp.description.toLowerCase().includes(cpFilters.description.toLowerCase())) return false;
                return true;
              });
              return (
            <div className="card overflow-hidden">
              <div className="card-header">
                <div className="card-title">Cost Plan Detail</div>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <div style={{ position:'relative' }}>
                    <Search size={12} style={{ position:'absolute', left:8, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                    <input type="text" value={cpGlobalSearch} onChange={e => setCpGlobalSearch(e.target.value)} placeholder="Search..." style={{ paddingLeft:26, paddingRight: cpGlobalSearch ? 24 : 8, paddingTop:5, paddingBottom:5, fontSize:12, border:'1px solid #d1d5db', borderRadius:999, outline:'none', width:200 }} />
                    {cpGlobalSearch && <button onClick={() => setCpGlobalSearch('')} style={{ position:'absolute', right:6, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#9ca3af', display:'flex', padding:0 }}><X size={11} /></button>}
                  </div>
                  <button onClick={() => { setCpPending(cpFilters); setCpFilterOpen(true); }} style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'5px 12px', cursor:'pointer', position:'relative' }}>
                    <Filter size={12} />
                    {cpActiveCount > 0 && <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 5px', minWidth:18, textAlign:'center', lineHeight:'14px', display:'inline-block' }}>{cpActiveCount}</span>}
                  </button>
                  {(cpActiveCount > 0 || cpGlobalSearch) && <button onClick={cpClear} style={{ display:'inline-flex', alignItems:'center', gap:3, fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'4px 10px', cursor:'pointer' }}><X size={10} /> Clear All</button>}
                </div>
              </div>
              {cpFilterOpen && (
                <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }} onClick={cpCancel}>
                  <div style={{ background:'#fff', borderRadius:12, maxWidth:480, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }} onClick={e => e.stopPropagation()}>
                    <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673', borderRadius:'12px 12px 0 0' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={18} color="#fff" /><h3 style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Filter — Cost Plan</h3></div>
                      <button onClick={cpCancel} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}><X size={18} /></button>
                    </div>
                    <div style={{ padding:24, display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>CP Number</label>
                        <input type="text" value={cpPending.cpNumber} onChange={e => setCpPending(p => ({ ...p, cpNumber: e.target.value }))} placeholder="e.g. CPLN053..." style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff', boxSizing:'border-box' }} />
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Cost Type</label>
                        <select value={cpPending.costType} onChange={e => setCpPending(p => ({ ...p, costType: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {cpAllCostTypes.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Frequency</label>
                        <select value={cpPending.frequency} onChange={e => setCpPending(p => ({ ...p, frequency: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {cpAllFrequencies.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Type</label>
                        <select value={cpPending.metricType} onChange={e => setCpPending(p => ({ ...p, metricType: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {cpAllMetricTypes.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Metric Desc</label>
                        <select value={cpPending.metricDesc} onChange={e => setCpPending(p => ({ ...p, metricDesc: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {cpAllMetricDescs.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Plan Description</label>
                        <input type="text" value={cpPending.description} onChange={e => setCpPending(p => ({ ...p, description: e.target.value }))} placeholder="Search description..." style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff', boxSizing:'border-box' }} />
                      </div>
                    </div>
                    <div style={{ padding:'14px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
                      <button onClick={cpClear} style={{ padding:'7px 14px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                      <div style={{ display:'flex', gap:10 }}>
                        <button onClick={cpCancel} style={{ padding:'7px 18px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                        <button onClick={cpApply} style={{ padding:'7px 22px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div>
                <div className="flex" style={{borderTop:'1px solid #e5e7eb',alignItems:'stretch',overflow:'hidden'}}>
                  {/* LEFT: Plan Identification — fixed */}
                  <div className="flex-shrink-0" style={{boxShadow:'2px 0 5px rgba(0,0,0,0.07)',zIndex:2,overflow:'hidden'}}>
                    <table className="text-xs" style={{borderCollapse:'collapse',height:'100%'}}>
                      <thead>
                        <tr style={{height:28}}><th colSpan={6} style={{padding:'0 12px',fontSize:10,fontWeight:700,color:'#fff',background:'#1A3673',textAlign:'center',whiteSpace:'nowrap'}}>Plan Identification</th></tr>
                        <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>CP Number</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Cost Type</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Frequency</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Metric Type</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Metric Desc</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Plan Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        {cpFiltered.map((cp,i)=>(
                          <tr key={cp.number} style={{height:36,background:i%2===0?'#ffffff':'#EFF6FF',borderBottom:'1px solid #e5e7eb'}}>
                            <td style={{padding:'0 10px',fontFamily:'monospace',fontSize:10,color:'#1A3673',whiteSpace:'nowrap'}}>{cp.number}</td>
                            <td style={{padding:'0 10px'}}><span style={{fontSize:10,fontWeight:600,padding:'1px 8px',borderRadius:999,border:'1px solid #6A97DF',background:'#E1EDFF',color:'#2861BB',whiteSpace:'nowrap'}}>{cp.costType}</span></td>
                            <td style={{padding:'0 10px'}}><span style={{fontSize:10,fontWeight:600,padding:'1px 8px',borderRadius:999,border:'1px solid #66D6D6',background:'#f0fdfa',color:'#00BBBA',whiteSpace:'nowrap'}}>{cp.frequency}</span></td>
                            <td style={{padding:'0 10px',whiteSpace:'nowrap'}}>{cp.metricType}</td>
                            <td style={{padding:'0 10px',whiteSpace:'nowrap'}}>{cp.metricDesc}</td>
                            <td style={{padding:'0 10px',width:280,maxWidth:280,color:'#4b5563',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}} title={cp.description}>{cp.description}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                          <td colSpan={6} style={{padding:'0 10px',fontSize:12,fontWeight:700,color:'#1A3673'}}>Total ({cpFiltered.length} plan{cpFiltered.length!==1?'s':''})</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                  {/* MIDDLE-LEFT: Total — fixed */}
                  <div className="flex-shrink-0" style={{borderLeft:'1px solid #e5e7eb',zIndex:1,overflow:'hidden'}}>
                    <table className="text-xs" style={{borderCollapse:'collapse',height:'100%'}}>
                      <thead>
                        <tr style={{height:28}}><th style={{padding:'0 14px',fontSize:10,fontWeight:700,color:'#fff',background:'#1A3673',textAlign:'center',whiteSpace:'nowrap'}}>Total</th></tr>
                        <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                          <th style={{padding:'0 14px',fontSize:10,fontWeight:600,color:'#1A3673',textAlign:'right',background:'rgba(26,54,115,0.05)',whiteSpace:'nowrap'}}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {cpFiltered.map((cp,i)=>(
                          <tr key={cp.number} style={{height:36,background:i%2===0?'#ffffff':'#EFF6FF',borderBottom:'1px solid #e5e7eb'}}>
                            <td style={{padding:'0 14px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,color:'#E3725F',whiteSpace:'nowrap'}}>{fmt(cp.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                          <td style={{padding:'0 14px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,color:'#E3725F',whiteSpace:'nowrap'}}>{fmt(cpFiltered.reduce((s,c)=>s+c.total,0))}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                  {/* RIGHT: Monthly columns — scrollbar hidden, driven by track below */}
                  <div ref={cpScrollInnerRef} className="scrollbar-none flex-1" style={{borderLeft:'1px solid #e5e7eb',overflowX:'scroll',overflowY:'hidden'}}>
                    <table className="text-xs" style={{borderCollapse:'collapse',minWidth:'max-content',width:'100%'}}>
                      <thead>
                        <tr style={{height:28}}><th colSpan={cpColLabels.length} style={{padding:'0 12px',fontSize:10,fontWeight:700,color:'#fff',background:'#E3725F',textAlign:'center',whiteSpace:'nowrap'}}>{period.selectedKey === 'All' ? (period.mode === 'Monthly' ? 'All Months' : period.mode === 'Quarterly' ? 'All Quarters' : 'All Years') : cpColLabels[0]}</th></tr>
                        <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                          {cpColLabels.map(lbl=>(
                            <th key={lbl} style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',textAlign:'right',whiteSpace:'nowrap'}}>{lbl}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {cpFiltered.map((cp,i)=>(
                          <tr key={cp.number} style={{height:36,background:i%2===0?'#ffffff':'#EFF6FF',borderBottom:'1px solid #e5e7eb'}}>
                            {cpAggregateMonths(cp).map(m=>(
                              <td key={m.label} style={{padding:'0 10px',textAlign:'right',fontFamily:'monospace',fontSize:10,color:'#374151',whiteSpace:'nowrap'}}>{fmt(m.val)}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                          {cpColLabels.map(lbl=>(
                            <td key={lbl} style={{padding:'0 10px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,color:'#1A3673',whiteSpace:'nowrap'}}>
                              {fmt(CP_DATA.reduce((s,c)=>s+(cpAggregateMonths(c).find(x=>x.label===lbl)?.val??0),0))}
                            </td>
                          ))}
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
                {/* Scrollbar track below all panels */}
                <div ref={cpScrollTrackRef} onScroll={cpSyncFromTrack} style={{overflowX:'auto',overflowY:'hidden',borderTop:'1px solid #e5e7eb'}}>
                  <table className="text-xs" style={{borderCollapse:'collapse',minWidth:'max-content',tableLayout:'auto',visibility:'hidden',height:0,overflow:'hidden'}}>
                    <tbody><tr>{cpColLabels.map(lbl=><td key={lbl} style={{padding:'0 10px',whiteSpace:'nowrap',fontSize:10}}>{lbl}</td>)}</tr></tbody>
                  </table>
                </div>
              </div>
            </div>
              );
            })()}
          </div>
        );
      })()}

      {/* ── ROI ── */}
      {activeSection === 'roi' && (() => {
        // API provides pre-aggregated columns; filter by selectedKey if not 'All'
        const apiCols = tabData?.columns ?? [];
        const MONTHS = period.selectedKey === 'All'
          ? apiCols.map(c => c.label)
          : [apiCols.find(c => c.key === period.selectedKey)?.label ?? period.selectedKey];
        const roiAggregateM = (row) => {
          const rowCols = row.columns ?? [];
          if (period.selectedKey === 'All') return apiCols.map(c => rowCols.find(rc => rc.key === c.key)?.amount ?? 0);
          return [rowCols.find(rc => rc.key === period.selectedKey)?.amount ?? 0];
        };

        const ROI_ROWS   = tabData?.roi?.rows ?? [];
        const netImpact  = tabData?.roi?.net_impact ?? { total: 0, columns: [] };
        const roiSummary = tabData?.roi?.summary ?? {};
        const roiWarnings = tabData?.roi?.warnings ?? [];

        const NET_IMPACT_TOTAL  = netImpact.total ?? 0;
        const totalBenefitSavings = roiSummary.total_benefit_savings ?? 0;
        const totalCost           = roiSummary.total_program_cost ?? 0;
        const inYearROI           = roiSummary.in_year_roi_display ?? 'N/A';
        const threeYearROI        = roiSummary.three_year_roi_display ?? 'N/A';
        const roiYear             = roiSummary.roi_year ?? '';

        const fmtR = (n, pos) => {
          const abs = Math.abs(n);
          const str = abs === 0 ? '—' : `$${abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
          if (abs === 0) return <span className="text-gray-300">—</span>;
          if (!pos || n < 0) return <span className="text-[#E3725F] font-mono text-[10px]">({`$${abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`})</span>;
          return <span className="font-mono text-[10px]">{str}</span>;
        };
        const fmtNet = (n) => {
          const abs = Math.abs(n);
          if (abs === 0) return <span className="text-gray-300">—</span>;
          if (n < 0) return <span className="text-[#E3725F] font-mono text-[10px] font-bold">({`$${abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`})</span>;
          return <span className="text-green-700 font-mono text-[10px] font-bold">{`$${abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</span>;
        };
        // Net impact per-column amounts (for the footer row)
        const netImpactAggregated = (() => {
          const niCols = netImpact.columns ?? [];
          if (period.selectedKey === 'All') return apiCols.map(c => niCols.find(rc => rc.key === c.key)?.amount ?? 0);
          return [niCols.find(rc => rc.key === period.selectedKey)?.amount ?? 0];
        })();

        if (tabLoading && !tabData) return <div className="flex items-center justify-center py-16 gap-2 text-gray-400"><Loader2 size={18} className="animate-spin" /><span className="text-sm">Loading ROI data…</span></div>;
        if (tabError && !tabData)   return <div className="card p-6 text-center text-sm text-[#E3725F]"><AlertTriangle size={14} className="inline mr-1" />{tabError}</div>;

        return (
          <div className="space-y-4">
            {/* KPI Cards */}
            <div className="grid grid-cols-4 gap-3">
              <div className="bg-white rounded-lg border border-gray-100 p-3">
                <p className="text-[10px] text-gray-500 mb-1">Total Benefit Savings</p>
                <p className="text-sm font-bold text-green-700">${totalBenefitSavings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
              </div>
              <div className="bg-[#FBEAE7] rounded-lg border border-gray-100 p-3">
                <p className="text-[10px] text-gray-500 mb-1">Total Program Cost</p>
                <p className="text-sm font-bold text-[#E3725F]">${totalCost.toLocaleString()}</p>
              </div>
              <div className="bg-[#E1EDFF] rounded-lg border border-gray-100 p-3">
                <p className="text-[10px] text-gray-500 mb-1">In-Year Net ROI ({roiYear})</p>
                <p className="text-sm font-bold text-[#2861BB]">{inYearROI}</p>
              </div>
              <div className="bg-teal-50 rounded-lg border border-gray-100 p-3">
                <p className="text-[10px] text-gray-500 mb-1">3-Year Net ROI</p>
                <p className="text-sm font-bold text-[#00BBBA]">{threeYearROI}</p>
              </div>
            </div>

            {/* Net Impact KPI */}
            <div className="bg-[#1A3673] rounded-lg p-4 flex items-center justify-between">
              <div>
                <p className="text-[10px] text-[#8FD4F8] mb-0.5">Net Impact (excl. Non-CoC)</p>
                <p className="text-xl font-bold text-white">${NET_IMPACT_TOTAL.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-[#8FD4F8] mb-0.5">Calculation</p>
                <p className="text-xs text-white font-mono">Savings − Costs = Net Impact</p>
                <p className="text-[10px] text-[#8FD4F8] mt-1">
                  ${totalBenefitSavings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} − ${totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} = ${NET_IMPACT_TOTAL.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>

            {/* Summary breakdown table */}
            {(() => {
              const roiActiveCount = Object.values(roiFilters).filter(v => v !== '').length;
              const roiApply  = () => { setRoiFilters(roiPending); setRoiFilterOpen(false); };
              const roiCancel = () => { setRoiPending(roiFilters); setRoiFilterOpen(false); };
              const roiClear  = () => { const c = { cat:'', freq:'', type:'' }; setRoiFilters(c); setRoiPending(c); setRoiGlobalSearch(''); setRoiFilterOpen(false); };
              const roiAllCats  = [...new Set(ROI_ROWS.map(r => r.cat).filter(v => v !== '—'))].sort();
              const roiAllFreqs = [...new Set(ROI_ROWS.map(r => r.freq).filter(v => v !== '—'))].sort();
              const roiAllTypes = [...new Set(ROI_ROWS.map(r => r.type).filter(v => v !== '—'))].sort();
              const roiFiltered = ROI_ROWS.filter(r => {
                if (roiGlobalSearch.trim()) {
                  const q = roiGlobalSearch.trim().toLowerCase();
                  if (![r.label,r.cat,r.freq,r.type].some(v => (v ?? '').toLowerCase().includes(q))) return false;
                }
                if (roiFilters.cat  && r.cat  !== roiFilters.cat)  return false;
                if (roiFilters.freq && r.freq !== roiFilters.freq) return false;
                if (roiFilters.type && r.type !== roiFilters.type) return false;
                return true;
              });
              return (
            <div className="card overflow-hidden">
              <div className="card-header">
                <div className="card-title">ROI Summary — Impact Breakdown</div>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <div style={{ position:'relative' }}>
                    <Search size={12} style={{ position:'absolute', left:8, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                    <input type="text" value={roiGlobalSearch} onChange={e => setRoiGlobalSearch(e.target.value)} placeholder="Search..." style={{ paddingLeft:26, paddingRight: roiGlobalSearch ? 24 : 8, paddingTop:5, paddingBottom:5, fontSize:12, border:'1px solid #d1d5db', borderRadius:999, outline:'none', width:200 }} />
                    {roiGlobalSearch && <button onClick={() => setRoiGlobalSearch('')} style={{ position:'absolute', right:6, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#9ca3af', display:'flex', padding:0 }}><X size={11} /></button>}
                  </div>
                  <button onClick={() => { setRoiPending(roiFilters); setRoiFilterOpen(true); }} style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'5px 12px', cursor:'pointer', position:'relative' }}>
                    <Filter size={12} />
                    {roiActiveCount > 0 && <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 5px', minWidth:18, textAlign:'center', lineHeight:'14px', display:'inline-block' }}>{roiActiveCount}</span>}
                  </button>
                  {(roiActiveCount > 0 || roiGlobalSearch) && <button onClick={roiClear} style={{ display:'inline-flex', alignItems:'center', gap:3, fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'4px 10px', cursor:'pointer' }}><X size={10} /> Clear All</button>}
                </div>
              </div>
              {roiFilterOpen && (
                <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }} onClick={roiCancel}>
                  <div style={{ background:'#fff', borderRadius:12, maxWidth:480, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }} onClick={e => e.stopPropagation()}>
                    <div style={{ padding:'14px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673', borderRadius:'12px 12px 0 0' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={18} color="#fff" /><h3 style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Filter — ROI</h3></div>
                      <button onClick={roiCancel} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}><X size={18} /></button>
                    </div>
                    <div style={{ padding:24, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:16 }}>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Category</label>
                        <select value={roiPending.cat} onChange={e => setRoiPending(p => ({ ...p, cat: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {roiAllCats.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Frequency</label>
                        <select value={roiPending.freq} onChange={e => setRoiPending(p => ({ ...p, freq: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {roiAllFreqs.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Type</label>
                        <select value={roiPending.type} onChange={e => setRoiPending(p => ({ ...p, type: e.target.value }))} style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                          <option value="">All</option>
                          {roiAllTypes.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    </div>
                    <div style={{ padding:'14px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
                      <button onClick={roiClear} style={{ padding:'7px 14px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                      <div style={{ display:'flex', gap:10 }}>
                        <button onClick={roiCancel} style={{ padding:'7px 18px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                        <button onClick={roiApply} style={{ padding:'7px 22px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div>
                {/* Three-panel layout: LEFT fixed | MIDDLE total fixed | RIGHT hidden-scroll */}
                <div className="flex" style={{borderTop:'1px solid #e5e7eb',alignItems:'stretch',overflow:'hidden'}}>
                  {/* LEFT: Line item identification — fixed */}
                  <div className="flex-shrink-0" style={{boxShadow:'2px 0 5px rgba(0,0,0,0.07)',zIndex:2,overflow:'hidden'}}>
                    <table className="text-xs" style={{borderCollapse:'collapse',height:'100%'}}>
                      <thead>
                        <tr style={{height:28}}><th colSpan={4} style={{padding:'0 12px',fontSize:10,fontWeight:700,color:'#fff',background:'#1A3673',textAlign:'center',whiteSpace:'nowrap'}}>Line Item</th></tr>
                        <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',textAlign:'left',background:'#f9fafb',minWidth:220}}>Description</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Category</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb'}}>Frequency</th>
                          <th style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',whiteSpace:'nowrap',background:'#f9fafb',borderRight:'2px solid #e5e7eb'}}>Type</th>
                        </tr>
                      </thead>
                      <tbody>
                        {roiFiltered.map((r,i)=>{
                          const rowBg = i%2===0?'#ffffff':'#EFF6FF';
                          return (
                            <tr key={r.label} style={{height:36,background:rowBg,borderBottom:'1px solid #e5e7eb'}}>
                              <td style={{padding:'0 10px',fontWeight:500,color:'#374151',whiteSpace:'nowrap'}}>{r.label}</td>
                              <td style={{padding:'0 10px'}}>
                                <span style={{fontSize:10,fontWeight:600,padding:'1px 8px',borderRadius:999,border:'1px solid',whiteSpace:'nowrap',
                                  background:r.cat==='Benefit'?'#f0fdfa':r.cat==='Cost'?'#FBEAE7':'#f3f4f6',
                                  color:r.cat==='Benefit'?'#00BBBA':r.cat==='Cost'?'#E3725F':'#9ca3af',
                                  borderColor:r.cat==='Benefit'?'#66D6D6':r.cat==='Cost'?'#EEAA9F':'#e5e7eb'
                                }}>{r.cat}</span>
                              </td>
                              <td style={{padding:'0 10px',color:'#6b7280',whiteSpace:'nowrap'}}>{r.freq}</td>
                              <td style={{padding:'0 10px',color:'#6b7280',whiteSpace:'nowrap',borderRight:'2px solid #e5e7eb'}}>{r.type}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                          <td colSpan={4} style={{padding:'0 10px',fontSize:12,fontWeight:700,color:'#1A3673',borderRight:'2px solid #e5e7eb'}}>Net Impact (excl. Non-CoC)</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                  {/* MIDDLE: Total — fixed */}
                  <div className="flex-shrink-0" style={{boxShadow:'2px 0 3px rgba(0,0,0,0.04)',zIndex:1,borderLeft:'1px solid #e5e7eb',overflow:'hidden'}}>
                    <table className="text-xs" style={{borderCollapse:'collapse',height:'100%'}}>
                      <thead>
                        <tr style={{height:28}}><th style={{padding:'0 14px',fontSize:10,fontWeight:700,color:'#fff',background:'#1A3673',textAlign:'center',whiteSpace:'nowrap'}}>Total</th></tr>
                        <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                          <th style={{padding:'0 14px',fontSize:10,fontWeight:600,color:'#1A3673',textAlign:'right',background:'rgba(26,54,115,0.05)',whiteSpace:'nowrap',minWidth:90}}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {roiFiltered.map((r,i)=>{
                          const rowBg = i%2===0?'#ffffff':'#EFF6FF';
                          return (
                            <tr key={r.label} style={{height:36,background:rowBg,borderBottom:'1px solid #e5e7eb'}}>
                              <td style={{padding:'0 14px',textAlign:'right',fontFamily:'monospace',fontSize:10,fontWeight:700,whiteSpace:'nowrap',background:rowBg==='#ffffff'?'rgba(26,54,115,0.03)':'rgba(26,54,115,0.06)'}}>{fmtR(r.total,r.positive)}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                          <td style={{padding:'0 14px',textAlign:'right',whiteSpace:'nowrap',background:'rgba(26,54,115,0.08)'}}>{fmtNet(NET_IMPACT_TOTAL)}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                  {/* RIGHT: Monthly columns — scrollbar hidden, driven by track below */}
                  <div ref={roiScrollInnerRef} className="scrollbar-none flex-1" style={{borderLeft:'1px solid #e5e7eb',overflowX:'scroll',overflowY:'hidden'}}>
                    <table className="text-xs" style={{borderCollapse:'collapse',minWidth:'max-content',width:'100%'}}>
                      <thead>
                        <tr style={{height:28}}><th colSpan={MONTHS.length} style={{padding:'0 12px',fontSize:10,fontWeight:700,color:'#fff',background:'#E3725F',textAlign:'center',whiteSpace:'nowrap'}}>{period.mode} {period.selectedKey === 'All' ? 'View' : tabData?.columns?.find(c => c.key === period.selectedKey)?.label ?? ''}</th></tr>
                        <tr style={{height:34,background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                          {MONTHS.map(m=>(
                            <th key={m} style={{padding:'0 10px',fontSize:10,fontWeight:600,color:'#374151',textAlign:'right',whiteSpace:'nowrap',minWidth:80}}>{m}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {roiFiltered.map((r,i)=>{
                          const rowBg = i%2===0?'#ffffff':'#EFF6FF';
                          return (
                            <tr key={r.label} style={{height:36,background:rowBg,borderBottom:'1px solid #e5e7eb'}}>
                              {roiAggregateM(r).map((v,idx)=>(
                                <td key={idx} style={{padding:'0 10px',textAlign:'right',whiteSpace:'nowrap'}}>{fmtR(v,r.positive)}</td>
                              ))}
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr style={{height:36,background:'rgba(26,54,115,0.05)',borderTop:'2px solid rgba(26,54,115,0.2)'}}>
                          {netImpactAggregated.map((v,idx)=>(
                            <td key={idx} style={{padding:'0 10px',textAlign:'right',whiteSpace:'nowrap'}}>{fmtNet(v)}</td>
                          ))}
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
                {/* Scrollbar track — below all panels, drives roiScrollInnerRef */}
                <div ref={roiScrollTrackRef} onScroll={roiSyncFromTrack} style={{overflowX:'auto',overflowY:'hidden',borderTop:'1px solid #e5e7eb'}}>
                  <table className="text-xs" style={{borderCollapse:'collapse',minWidth:'max-content',tableLayout:'auto',visibility:'hidden',height:0,overflow:'hidden'}}>
                    <tbody><tr>{MONTHS.map(m=><td key={m} style={{padding:'0 10px',whiteSpace:'nowrap',fontSize:10,minWidth:80}}>{m}</td>)}</tr></tbody>
                  </table>
                </div>
              </div>
            </div>
              );
            })()}

            {/* API warnings */}
            {roiWarnings.length > 0 && roiWarnings.map((w, i) => (
              <div key={i} className="px-4 py-2 bg-amber-50 border-t border-amber-100 flex items-start gap-2">
                <AlertTriangle size={12} className="text-amber-500 mt-0.5 flex-shrink-0" />
                <p className="text-[11px] text-amber-700">{w}</p>
              </div>
            ))}
            {/* ROI note */}
            <div className="px-4 py-2 bg-blue-50 border-t border-blue-100 flex items-start gap-2">
              <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#2861BB" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
              <p className="text-[11px] text-[#2861BB]"><span className="font-semibold">ROI Methodology:</span> Net ROI = Total Benefit Savings ÷ Total Program Costs. In-Year ROI uses {roiYear} actuals only. 3-Year ROI projects savings over a 36-month horizon. One-time IT costs must be entered in Section 3 for accurate ROI calculations.</p>
            </div>
          </div>
        );
      })()}

      </div>{/* /content */}
    </div>
  );
}
