import { useState, useEffect, memo, useMemo } from 'react';
import { FileText, Eye, RefreshCw, X, Pencil, Code2, Table2, Filter, Search, Loader2, ShieldOff } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useGlobalSearch } from '../../hooks/useGlobalSearch';
import { useTableSort } from '../../hooks/useTableSort';
import { uploadApi } from '../../config/apiConfig';
const CATEGORY_META = {
  data:               { icon: <Table2 size={12} />,   label: 'Data',               color: 'text-[#1A3673]', bg: 'bg-[#E3F4FD]' },
  query:              { icon: <Code2 size={12} />,    label: 'Query',              color: 'text-[#2861BB]', bg: 'bg-blue-50' },
  provider_exclusion: { icon: <ShieldOff size={12} />, label: 'Provider Exclusion', color: 'text-[#E3725F]', bg: 'bg-[#FBEAE7]' },
};

const classifyFile = (name, ext) => {
  const n = (name || '').toLowerCase();
  const e = (ext || '').toLowerCase();
  if (e === 'sql' || n.includes('query') || n.includes('queries')) return 'query';
  if (n.includes('provider exclusion') || n.includes('provider_exclusion') || n.includes('providerexclusion')) return 'provider_exclusion';
  return 'data';
};

const stripPrefix = (name) => {
  if (!name) return name;
  const idx = name.indexOf('_');
  if (idx <= 0) return name;
  const prefix = name.slice(0, idx);
  if (/^CVR(-[A-Z0-9]+)+$/i.test(prefix)) return name.slice(idx + 1);
  return name;
};

const splitName = (fileName) => {
  if (!fileName) return { base: '', ext: '' };
  const dot = fileName.lastIndexOf('.');
  if (dot <= 0) return { base: fileName, ext: '' };
  return { base: fileName.slice(0, dot), ext: fileName.slice(dot + 1).toLowerCase() };
};

const EXT_STYLE = {
  xlsx: { bg: 'bg-[#E3F4FD]', color: 'text-[#1A3673]'  },
  xls:  { bg: 'bg-[#E3F4FD]', color: 'text-[#1A3673]'  },
  csv:  { bg: 'bg-green-50',  color: 'text-green-700'   },
  pdf:  { bg: 'bg-red-50',    color: 'text-red-600'     },
  docx: { bg: 'bg-blue-50',   color: 'text-blue-700'    },
  sql:  { bg: 'bg-purple-50', color: 'text-purple-700'  },
  txt:  { bg: 'bg-gray-100',  color: 'text-gray-500'    },
  png:  { bg: 'bg-pink-50',   color: 'text-pink-600'    },
  jpg:  { bg: 'bg-pink-50',   color: 'text-pink-600'    },
  jpeg: { bg: 'bg-pink-50',   color: 'text-pink-600'    },
  gif:  { bg: 'bg-fuchsia-50',color: 'text-fuchsia-600' },
  bmp:  { bg: 'bg-fuchsia-50',color: 'text-fuchsia-600' },
  webp: { bg: 'bg-fuchsia-50',color: 'text-fuchsia-600' },
  svg:  { bg: 'bg-orange-50', color: 'text-orange-600'  },
  py:   { bg: 'bg-yellow-50', color: 'text-yellow-700'  },
  json: { bg: 'bg-orange-50', color: 'text-orange-600'  },
};
const extStyle = (ext) => EXT_STYLE[ext] || { bg: 'bg-gray-100', color: 'text-gray-500' };

const formatFileSize = (bytes) => {
  if (!bytes) return '—';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const IMG_EXTS = new Set(['png','jpg','jpeg','gif','bmp','webp','svg']);
const TABLE_TYPES = new Set(['csv','excel','xlsx','xls']);
const TEXT_TYPES  = new Set(['txt','text','sql','docx','doc']);

const GENERIC_TYPE_MAP = { image: true, text: true, document: true };

const FilePreviewContent = memo(function FilePreviewContent({ pdata, fileName }) {
  const ext  = (fileName?.split('.').pop() ?? '').toLowerCase();
  const apiType = pdata?.type?.toLowerCase() ?? '';
  // Always prefer the real file extension; only fall back to API type if it's specific
  const resolvedType = ext || (GENERIC_TYPE_MAP[apiType] ? '' : apiType) || apiType;
  const imgSrc = useMemo(() => {
    const isImg = IMG_EXTS.has(resolvedType) || apiType === 'image' || apiType.startsWith('image/');
    if (!isImg) return null;
    const raw = pdata.image_data ?? pdata.content ?? pdata.url ?? pdata.image_url ?? '';
    if (!raw) return null;
    if (raw.startsWith('http') || raw.startsWith('data:') || raw.startsWith('/') || raw.startsWith('blob:')) return raw;
    // Detect actual format from base64 magic bytes (server may return PNG for SVG files)
    let detectedMime = pdata.mime_type || `image/${resolvedType || 'png'}`;
    if (raw.startsWith('iVBORw0')) detectedMime = 'image/png';
    else if (raw.startsWith('/9j/')) detectedMime = 'image/jpeg';
    else if (raw.startsWith('R0lGOD')) detectedMime = 'image/gif';
    else if (raw.startsWith('UklGR')) detectedMime = 'image/webp';
    return `data:${detectedMime};base64,${raw}`;
  }, [pdata, resolvedType, apiType]);

  const pdfSrc = useMemo(() => {
    if (resolvedType !== 'pdf' && apiType !== 'pdf') return null;
    const raw = pdata.content ?? pdata.pdf_content ?? '';
    if (!raw) return null;
    if (raw.startsWith('http') || raw.startsWith('/') || raw.startsWith('blob:')) return raw;
    if (raw.startsWith('data:')) return raw;
    try {
      const bytes = atob(raw);
      const arr   = new Uint8Array(bytes.length);
      for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
      return URL.createObjectURL(new Blob([arr], { type: 'application/pdf' }));
    } catch { return null; }
  }, [pdata, resolvedType, apiType]);

  const isTable = TABLE_TYPES.has(resolvedType) || (TABLE_TYPES.has(apiType) && !resolvedType);
  if (isTable && pdata.headers && pdata.rows) {
    /* Convert column index to Excel-style letter(s): 0→A, 25→Z, 26→AA */
    const colLetter = (i) => {
      let s = '', n = i;
      do { s = String.fromCharCode(65 + (n % 26)) + s; n = Math.floor(n / 26) - 1; } while (n >= 0);
      return s;
    };
    const sheetName = pdata.sheet_name || 'Sheet1';
    const totalRows = pdata.total_rows ?? pdata.rows.length;
    const shownRows = pdata.rows.length;
    /* Excel colour palette */
    const XL = {
      toolbar:    '#217346',   /* Excel green */
      headerBg:   '#E8E8E8',
      headerBorder:'#B0B0B0',
      rowNumBg:   '#F2F2F2',
      rowNumColor:'#666',
      gridLine:   '#D0D7DE',
      cellBg:     '#fff',
      altBg:      '#F9FBFF',
      selBg:      '#E8F4FE',
      tabBg:      '#217346',
      tabText:    '#fff',
      infoBar:    '#F3F3F3',
    };
    return (
      <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0, fontFamily:'"Calibri","Segoe UI",Arial,sans-serif', background:'#fff' }}>
        {/* ── Excel-style toolbar strip ── */}
        <div style={{ background:XL.toolbar, padding:'5px 12px', display:'flex', alignItems:'center', gap:12, flexShrink:0 }}>
          <span style={{ fontSize:12, fontWeight:700, color:'#fff', letterSpacing:0.2 }}>Spreadsheet Preview</span>
          <span style={{ fontSize:11, color:'#a7f3d0', marginLeft:'auto' }}>
            Showing {shownRows.toLocaleString()} of {totalRows.toLocaleString()} rows · {pdata.headers.length} columns
          </span>
        </div>
        {/* ── Formula bar ── */}
        <div style={{ background:XL.infoBar, borderBottom:`1px solid ${XL.gridLine}`, padding:'3px 10px', display:'flex', alignItems:'center', gap:8, flexShrink:0 }}>
          <span style={{ fontSize:11, color:'#555', fontWeight:600, minWidth:28, textAlign:'center', border:`1px solid ${XL.headerBorder}`, borderRadius:2, padding:'1px 4px', background:'#fff' }}>A1</span>
          <span style={{ fontSize:11, color:'#888', marginLeft:2 }}>fx</span>
          <span style={{ fontSize:11, color:'#333', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {pdata.rows[0]?.[0] ?? ''}
          </span>
        </div>
        {/* ── Grid ── */}
        <div style={{ flex:1, overflow:'auto', minHeight:0, position:'relative' }}>
          <table style={{ borderCollapse:'collapse', fontSize:12, tableLayout:'auto', minWidth:'max-content', width:'100%' }}>
            <thead style={{ position:'sticky', top:0, zIndex:3 }}>
              {/* Column-letter row (like Excel A B C …) */}
              <tr>
                {/* corner cell */}
                <th style={{ minWidth:46, width:46, background:XL.headerBg, border:`1px solid ${XL.headerBorder}`, padding:0 }} />
                {pdata.headers.map((_, i) => (
                  <th key={i} style={{
                    background: XL.headerBg, border:`1px solid ${XL.headerBorder}`,
                    padding:'3px 8px', fontSize:11, fontWeight:700, color:'#333',
                    textAlign:'center', whiteSpace:'nowrap', minWidth:80, userSelect:'none',
                  }}>
                    {colLetter(i)}
                  </th>
                ))}
              </tr>
              {/* Header name row */}
              <tr>
                {/* row-number corner */}
                <th style={{ minWidth:46, width:46, background:XL.headerBg, border:`1px solid ${XL.headerBorder}`, fontSize:11, fontWeight:700, color:XL.rowNumColor, textAlign:'center', userSelect:'none' }}>
                  #
                </th>
                {pdata.headers.map((h, i) => (
                  <th key={i} style={{
                    background: '#DEEAF1', border:`1px solid ${XL.headerBorder}`,
                    padding:'5px 10px', fontSize:12, fontWeight:700, color:'#1A3673',
                    textAlign:'left', whiteSpace:'nowrap', minWidth:80,
                    borderBottom:`2px solid #1A3673`,
                  }}>
                    {h ?? ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pdata.rows.map((row, ri) => (
                <tr key={ri}
                  style={{ background: ri % 2 === 0 ? XL.cellBg : XL.altBg }}
                  onMouseEnter={e => { e.currentTarget.style.background = XL.selBg; }}
                  onMouseLeave={e => { e.currentTarget.style.background = ri % 2 === 0 ? XL.cellBg : XL.altBg; }}
                >
                  {/* Row number gutter */}
                  <td style={{
                    background: XL.rowNumBg, border:`1px solid ${XL.headerBorder}`,
                    padding:'3px 8px', fontSize:11, color:XL.rowNumColor,
                    textAlign:'center', fontWeight:500, userSelect:'none', minWidth:46, width:46,
                  }}>
                    {ri + 1}
                  </td>
                  {pdata.headers.map((_, ci) => (
                    <td key={ci} style={{
                      border:`1px solid ${XL.gridLine}`,
                      padding:'4px 10px', whiteSpace:'nowrap', color:'#1f2937',
                      fontSize:12, maxWidth:260, overflow:'hidden', textOverflow:'ellipsis',
                    }}>
                      {row[ci] ?? ''}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* ── Sheet tab bar ── */}
        <div style={{ background:'#EDEDED', borderTop:`1px solid ${XL.gridLine}`, display:'flex', alignItems:'stretch', flexShrink:0, height:26 }}>
          <div style={{
            display:'flex', alignItems:'center', padding:'0 16px',
            background:XL.tabBg, color:XL.tabText,
            fontSize:11, fontWeight:700, borderRight:`2px solid #155e3a`,
            cursor:'default', userSelect:'none',
          }}>
            {sheetName}
          </div>
          <div style={{ flex:1 }} />
          {totalRows > shownRows && (
            <span style={{ fontSize:10, color:'#888', padding:'0 10px', display:'flex', alignItems:'center' }}>
              {totalRows - shownRows} more rows not shown
            </span>
          )}
        </div>
      </div>
    );
  }

  if (TEXT_TYPES.has(resolvedType) || (apiType === 'text' && !ext)) {
    const content = pdata.content ?? (Array.isArray(pdata.rows) ? pdata.rows.join('\n') : '');
    const isSqlType = resolvedType === 'sql';
    return (
      <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0 }}>
        <div style={{ padding:'8px 16px', background: isSqlType ? '#eff6ff' : '#f9fafb', borderBottom:`2px solid ${isSqlType ? '#bfdbfe' : '#e5e7eb'}`, display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
          <span style={{ fontSize:12, fontWeight:700, color: isSqlType ? '#1d4ed8' : '#374151' }}>{isSqlType ? 'SQL Preview' : resolvedType === 'docx' ? 'Document Preview' : 'Text Preview'}</span>
        </div>
        <div style={{ overflowX:'auto', overflowY:'auto', flex:1, minHeight:0 }}>
          <pre style={{ margin:0, padding:16, fontSize:12, fontFamily:'"Fira Mono","Consolas",monospace', color: isSqlType ? '#1e40af' : '#1f2937', background: isSqlType ? '#eff6ff' : '#fff', whiteSpace:'pre-wrap', lineHeight:1.8 }}>{content}</pre>
        </div>
      </div>
    );
  }

  if (resolvedType === 'pdf' || apiType === 'pdf') {
    if (pdfSrc) {
      return (
        <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0 }}>
          <div style={{ padding:'8px 16px', background:'#f0f4fa', borderBottom:'2px solid #fecaca', display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
            <span style={{ fontSize:12, fontWeight:700, color:'#b91c1c' }}>PDF Preview</span>
            {pdata.total_pages != null && <span style={{ fontSize:11, color:'#6b7280' }}>{pdata.total_pages} page{pdata.total_pages !== 1 ? 's' : ''}</span>}
          </div>
          <iframe src={pdfSrc} title="PDF Preview" style={{ width:'100%', flex:1, border:'none', display:'block', minHeight:0 }} />
        </div>
      );
    }
    const textContent = pdata.text_content ?? pdata.content ?? '';
    if (textContent) {
      return (
        <div style={{ display:'flex', flexDirection:'column', flex:1, minHeight:0 }}>
          <div style={{ padding:'8px 16px', background:'#f0f4fa', borderBottom:'2px solid #fecaca', display:'flex', justifyContent:'space-between', alignItems:'center', flexShrink:0 }}>
            <span style={{ fontSize:12, fontWeight:700, color:'#b91c1c' }}>PDF Text Preview</span>
            <span style={{ fontSize:11, color:'#6b7280' }}>Page {pdata.preview_pages ?? 1} of {pdata.total_pages ?? 1}</span>
          </div>
          <div style={{ overflow:'auto', flex:1, minHeight:0 }}>
            <pre style={{ margin:0, padding:16, fontSize:12, fontFamily:'inherit', color:'#1f2937', background:'#fff', whiteSpace:'pre-wrap', lineHeight:1.8 }}>{textContent}</pre>
          </div>
        </div>
      );
    }
    return <div style={{ padding:48, textAlign:'center', color:'#6b7280', fontSize:13 }}>PDF preview unavailable. Download the file to view.</div>;
  }

  if (imgSrc) {
    return (
      <div style={{ flex:1, overflow:'auto', background:'#f9fafb', padding:24, display:'flex', justifyContent:'center', alignItems:'flex-start' }}>
        <img src={imgSrc} alt={fileName} loading="lazy"
          style={{ maxWidth:'100%', borderRadius:6, objectFit:'contain', boxShadow:'0 2px 12px rgba(0,0,0,0.10)', display:'block' }} />
      </div>
    );
  }

  return <div style={{ padding:32, textAlign:'center', color:'#6b7280', fontSize:13 }}>Preview not available for this file type ({ext || resolvedType || 'unknown'}).</div>;
});

const mapDoc = (doc) => {
  const uploadTs  = doc.upload_date ? new Date(doc.upload_date).getTime() : 0;
  const updatedTs = doc.updated_at  ? new Date(doc.updated_at).getTime()  : uploadTs;
  const fmt = (ts) => ts
    ? new Date(ts).toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
    : '—';
  return {
    id: doc.file_id,
    name: doc.file_name,
    ...(() => { const s = splitName(doc.file_name); return { baseName: s.base, ext: s.ext }; })(),
    originalName: doc.original_file_name || doc.file_name,
    ...(() => { const s = splitName(doc.original_file_name || doc.file_name); return { originalBaseName: s.base }; })(),
    size: formatFileSize(doc.file_size),
    sizeBytes: doc.file_size || 0,
    uploadedBy: doc.uploaded_by || doc.owner_name || '—',
    uploadedAt: fmt(uploadTs),
    _uploadedTs: uploadTs,           // raw ms for sort
    uploadDate: uploadTs ? new Date(uploadTs).toISOString().slice(0, 10) : '',
    updatedAt: fmt(updatedTs),
    _updatedTs: updatedTs,           // raw ms for sort
    category: doc.category,
    sheet: doc.sheet_name || '—',
  };
};

const sortByUpdated = (arr) => [...arr].sort((a, b) => b._updatedTs - a._updatedTs);

export default function DataUploadTab({ coversheet, onEdit }) {
  const { can } = useAuth();
  const { showToast } = useToast();
  const canEdit = can('edit_cost_plan');

  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchFiles = () => {
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    if (!cvrsht_id) return;
    setLoading(true);
    setApiError(null);
    uploadApi.fetchDocuments(cvrsht_id)
      .then(data => {
        if (data.success && Array.isArray(data.documents)) {
          setFiles(sortByUpdated(data.documents.filter(doc => doc.category === 'data').map(mapDoc)));
        }
      })
      .catch(err => setApiError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchFiles(); }, [coversheet?.cvrsht_id, coversheet?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const [previewModal, setPreviewModal] = useState(null); // { file, data } | null
  const [previewData, setPreviewData] = useState({});
  const [previewLoading, setPreviewLoading] = useState({});
  const [openPreview, setOpenPreview] = useState(null); // kept for Eye icon toggle state

  const [renameFile,   setRenameFile]   = useState(null);
  const [renameName,   setRenameName]   = useState('');
  const [renaming,     setRenaming]     = useState(false);

  const [fName, setFName] = useState('');
  const [fBy,   setFBy]   = useState('');
  const [fDate, setFDate] = useState('');
  const [fExt,  setFExt]  = useState('');

  const [isFilterOpen, setIsFilterOpen]     = useState(false);
  const [pendingName,  setPendingName]       = useState('');
  const [pendingDate,  setPendingDate]       = useState('');
  const [pendingBy,    setPendingBy]         = useState('');
  const [pendingExt,   setPendingExt]        = useState('');

  const applyFilterModal = () => {
    setFName(pendingName);
    setFDate(pendingDate);
    setFBy(pendingBy);
    setFExt(pendingExt);
    setIsFilterOpen(false);
  };
  const clearFilterModal = () => {
    setPendingName('');
    setPendingDate('');
    setPendingBy('');
    setPendingExt('');
  };
  const cancelFilterModal = () => {
    setPendingName(fName);
    setPendingDate(fDate);
    setPendingBy(fBy);
    setPendingExt(fExt);
    setIsFilterOpen(false);
  };
  const openFilterModal = () => {
    setPendingName(fName); setPendingDate(fDate); setPendingBy(fBy); setPendingExt(fExt);
    setIsFilterOpen(true);
  };

  const activeFilterCount = [fName, fDate, fBy, fExt].filter(Boolean).length;

  const filteredFiles = files.filter(f =>
    (!fName || f.baseName.toLowerCase().includes(fName.toLowerCase())) &&
    (!fBy   || f.uploadedBy.toLowerCase().includes(fBy.toLowerCase())) &&
    (!fDate || f.uploadDate === fDate) &&
    (!fExt  || f.ext === fExt)
  );

  const openPreviewModal = async (file) => {
    console.log('[Preview] clicked:', file.id, file.name, file.ext);
    setOpenPreview(file.id);
    const cached = previewData[file.id];
    if (cached && Object.keys(cached).length > 0) {
      console.log('[Preview] using cached data');
      setPreviewModal({ file, data: cached }); return;
    }
    setPreviewLoading(prev => ({ ...prev, [file.id]: true }));
    try {
      console.log('[Preview] calling API for', file.id);
      const data = await uploadApi.previewDocument(file.id);
      console.log('[Preview] API response:', data);
      setPreviewData(prev => ({ ...prev, [file.id]: data }));
      setPreviewModal({ file, data });
    } catch (err) {
      console.error('[Preview] API error:', err);
      showToast(`Preview failed: ${err.message}`, 'error');
      setOpenPreview(null);
    } finally {
      setPreviewLoading(prev => ({ ...prev, [file.id]: false }));
    }
  };
  const closePreviewModal = () => { setPreviewModal(null); setOpenPreview(null); };

  const openRenameModal = (f) => { setRenameFile(f); setRenameName(stripPrefix(f.baseName)); };
  const closeRenameModal = () => { setRenameFile(null); setRenameName(''); };

  const commitRename = () => {
    const trimmed = renameName.trim();
    if (!trimmed || !renameFile) return;
    const newFullName = renameFile.ext ? `${trimmed}.${renameFile.ext}` : trimmed;
    setRenaming(true);
    uploadApi.updateFileName(renameFile.id, newFullName)
      .then(() => {
        setFiles(prev => prev.map(f => f.id === renameFile.id ? { ...f, name: newFullName, baseName: trimmed } : f));
        showToast('File name updated', 'success');
        closeRenameModal();
        onEdit();
      })
      .catch(err => showToast(err.message, 'error'))
      .finally(() => setRenaming(false));
  };


  const handleRefresh = () => {
    setRefreshing(true);
    const cvrsht_id = coversheet?.cvrsht_id || coversheet?.id;
    if (!cvrsht_id) { setRefreshing(false); return; }
    uploadApi.fetchDocuments(cvrsht_id)
      .then(data => {
        if (data.success && Array.isArray(data.documents)) {
          setFiles(sortByUpdated(data.documents.filter(doc => doc.category === 'data').map(mapDoc)));
          showToast('Data refreshed', 'success');
        }
      })
      .catch(err => showToast(err.message, 'error'))
      .finally(() => setRefreshing(false));
  };

  const { searchTerm: globalSearch, setSearchTerm: setGlobalSearch, searchedData: searchedFiles } = useGlobalSearch(filteredFiles);
  const { sortField, sortDir, handleSort, sortedData: sortedFiles } = useTableSort(searchedFiles, '_updatedTs', 'desc');

  const clearAllFilters = () => {
    setFName(''); setFDate(''); setFBy(''); setFExt('');
    setPendingName(''); setPendingDate(''); setPendingBy(''); setPendingExt('');
    setGlobalSearch('');
  };

  return (
    <div className="space-y-4">

      {/* Files from Excel — known sheets */}
      <div className="card">
        <div style={{ padding:'10px 14px', borderBottom:'1px solid #e5e7eb', background:'#fafafa', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, flexWrap:'wrap' }}>
          {/* Left: title */}
          <p style={{ margin:0, fontSize:13, fontWeight:600, color:'#374151', whiteSpace:'nowrap' }}>
            <FileText size={14} style={{ display:'inline', marginRight:5, verticalAlign:'middle' }} />
            Data Files ({searchedFiles.length})
          </p>
          {/* Right: search + filter + refresh */}
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ position:'relative', flex:'0 1 280px' }}>
              <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
              <input
                type="text"
                value={globalSearch}
                onChange={e => setGlobalSearch(e.target.value)}
                placeholder="Search files..."
                style={{ width:'100%', paddingLeft:32, paddingRight: globalSearch ? 28 : 10, paddingTop:6, paddingBottom:6, fontSize:13, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
                onFocus={e => e.target.style.borderColor = '#1A3673'}
                onBlur={e => e.target.style.borderColor = '#d1d5db'}
              />
              {globalSearch && (
                <button onClick={() => setGlobalSearch('')}
                  style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                  <X size={13} />
                </button>
              )}
            </div>
            <button
              onClick={openFilterModal}
              title="Filter files"
              style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:13, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'6px 14px', cursor:'pointer', position:'relative' }}>
              <Filter size={13} />
              {activeFilterCount > 0 && (
                <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 6px', minWidth:18, textAlign:'center' }}>
                  {activeFilterCount}
                </span>
              )}
            </button>
            {(activeFilterCount > 0 || globalSearch) && (
              <button onClick={clearAllFilters}
                style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'5px 12px', cursor:'pointer', whiteSpace:'nowrap', flexShrink:0 }}>
                <X size={11} /> Clear All
              </button>
            )}
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              title="Refresh data"
              style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:13, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'6px 14px', cursor:'pointer', opacity: refreshing ? 0.6 : 1 }}>
              <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} />
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr style={{ background:'#1A3673' }}>
                {[['baseName','File Name'],['ext','Type'],['sizeBytes','Size'],['uploadedBy','Uploaded By'],['_uploadedTs','Uploaded At'],['_updatedTs','Updated At']].map(([field, label]) => (
                  <th key={field} onClick={() => handleSort(field)}
                    style={{ padding:'0 10px', height:36, color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none', textAlign:'left' }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      {label} <span style={{ opacity: sortField === field ? 1 : 0.3 }}>{sortField === field && sortDir === 'asc' ? '▲' : '▼'}</span>
                    </div>
                  </th>
                ))}
                <th style={{ padding:'0 10px', height:36, color:'#fff', fontWeight:600, fontSize:12, textAlign:'center', whiteSpace:'nowrap' }}>Preview</th>
                {canEdit && <th style={{ padding:'0 10px', height:36, color:'#fff', fontWeight:600, fontSize:12, textAlign:'center', whiteSpace:'nowrap' }}>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={canEdit ? 8 : 7} style={{ padding:'32px 10px', textAlign:'center', color:'#9ca3af', fontSize:13 }}>Loading...</td></tr>
              ) : apiError ? (
                <tr><td colSpan={canEdit ? 8 : 7} style={{ padding:'32px 10px', textAlign:'center', color:'#f87171', fontSize:13 }}>{apiError}</td></tr>
              ) : sortedFiles.length === 0 ? (
                <tr><td colSpan={canEdit ? 8 : 7} style={{ padding:'32px 10px', textAlign:'center', color:'#9ca3af', fontSize:13 }}>
                  {files.length > 0
                    ? <span>No files match your filters. <button onClick={clearAllFilters} style={{ color:'#1A3673', fontWeight:600, textDecoration:'underline', background:'none', border:'none', cursor:'pointer', fontSize:'inherit' }}>Clear filters</button></span>
                    : 'No data files found.'}
                </td></tr>
              ) : sortedFiles.map((f, i) => {
                const cat = CATEGORY_META[f.category];
                return (
                  <tr key={f.id} style={{ height:34, background: i%2===0 ? '#fff' : '#EFF6FF', borderBottom:'1px solid #f3f4f6' }}>
                    <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:6 }} title={f.baseName}>
                        <span style={{ fontWeight:500, color:'#374151' }}>{stripPrefix(f.baseName)}{f.ext ? `.${f.ext}` : ''}</span>
                      </div>
                    </td>
                    <td style={{ padding:'0 10px', whiteSpace:'nowrap' }}>
                      {(() => { const c = CATEGORY_META[classifyFile(f.baseName, f.ext)]; return c ? <span className={`inline-flex items-center gap-1 text-[11px] font-semibold ${c.color} ${c.bg} px-2 py-0.5 rounded`}>{c.icon}{c.label}</span> : null; })()}
                    </td>
                    <td style={{ padding:'0 10px', color:'#9ca3af', whiteSpace:'nowrap' }}>{f.size}</td>
                    <td style={{ padding:'0 10px', color:'#6b7280', whiteSpace:'nowrap' }}>{f.uploadedBy}</td>
                    <td style={{ padding:'0 10px', color:'#9ca3af', whiteSpace:'nowrap' }}>{f.uploadedAt}</td>
                    <td style={{ padding:'0 10px', color:'#9ca3af', whiteSpace:'nowrap' }}>{f.updatedAt}</td>
                    <td style={{ padding:'0 10px', textAlign:'center' }}>
                      <button
                        onClick={() => openPreviewModal(f)}
                        disabled={previewLoading[f.id]}
                        title="Preview file"
                        style={{ background:'#f3f4f6', border:'none', borderRadius:6, cursor:'pointer', color:'#1A3673', padding:'3px 8px', display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, opacity: previewLoading[f.id] ? 0.6 : 1, transition:'background 0.15s' }}
                        onMouseEnter={e => { if (!previewLoading[f.id]) e.currentTarget.style.background='#dbeafe'; }}
                        onMouseLeave={e => e.currentTarget.style.background='#f3f4f6'}
                      >
                        {previewLoading[f.id] ? <Loader2 size={13} className="animate-spin" /> : <Eye size={13} />}
                      </button>
                    </td>
                    {canEdit && (
                      <td style={{ padding:'0 10px', textAlign:'center', width:32 }}>
                        <button
                          onClick={() => openRenameModal(f)}
                          title="Edit file name"
                          style={{ background:'none', border:'none', cursor:'pointer', color:'#9ca3af', display:'flex', alignItems:'center', justifyContent:'center', transition:'color 0.15s' }}
                          onMouseEnter={e => e.currentTarget.style.color='#1A3673'}
                          onMouseLeave={e => e.currentTarget.style.color='#9ca3af'}
                        >
                          <Pencil size={13} />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Filter Modal */}
      {isFilterOpen && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={cancelFilterModal}>
          <div style={{ background:'#fff', borderRadius:12, maxWidth:620, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding:'16px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673', borderRadius:'12px 12px 0 0' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <Filter size={18} color="#fff" />
                <span style={{ margin:0, fontSize:15, fontWeight:700, color:'#fff' }}>Filter Files</span>
              </div>
              <button onClick={cancelFilterModal} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}>
                <X size={18} />
              </button>
            </div>
            <div style={{ padding:24 }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(180px, 1fr))', gap:16 }}>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>File Name</label>
                  <input type="text" value={pendingName} onChange={e => setPendingName(e.target.value)}
                    placeholder="Search file name..."
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }}
                    onFocus={e => e.target.style.borderColor = '#1A3673'}
                    onBlur={e => e.target.style.borderColor = '#d1d5db'} />
                </div>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Type</label>
                  <select value={pendingExt} onChange={e => setPendingExt(e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {[...new Set(files.map(f => f.ext).filter(Boolean))].sort().map(ext => (
                      <option key={ext} value={ext}>{ext.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Uploaded By</label>
                  <input type="text" value={pendingBy} onChange={e => setPendingBy(e.target.value)}
                    placeholder="Search uploader..."
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }}
                    onFocus={e => e.target.style.borderColor = '#1A3673'}
                    onBlur={e => e.target.style.borderColor = '#d1d5db'} />
                </div>
                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Uploaded At</label>
                  <input type="date" value={pendingDate} onChange={e => setPendingDate(e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }}
                    onFocus={e => e.target.style.borderColor = '#1A3673'}
                    onBlur={e => e.target.style.borderColor = '#d1d5db'} />
                </div>
              </div>
            </div>
            <div style={{ padding:'16px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
              <button onClick={clearFilterModal}
                style={{ padding:'8px 16px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>
                Clear All
              </button>
              <div style={{ display:'flex', gap:10 }}>
                <button onClick={cancelFilterModal}
                  style={{ padding:'8px 20px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>
                  Cancel
                </button>
                <button onClick={applyFilterModal}
                  style={{ padding:'8px 24px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {renameFile && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={closeRenameModal}>
          <div style={{ background:'#fff', borderRadius:12, width:420, maxWidth:'95vw', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding:'14px 20px', borderBottom:'1px solid #e5e7eb', background:'#1A3673', borderRadius:'12px 12px 0 0', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <span style={{ fontSize:15, fontWeight:700, color:'#fff' }}>Edit File Name</span>
              <button onClick={closeRenameModal} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}><X size={18} /></button>
            </div>
            <div style={{ padding:24 }}>
              <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>File Name</label>
              <div style={{ display:'flex', alignItems:'stretch', border:'1.5px solid #d1d5db', borderRadius:6, overflow:'hidden', transition:'border-color 0.15s' }}
                onFocusCapture={e => e.currentTarget.style.borderColor='#1A3673'}
                onBlurCapture={e => e.currentTarget.style.borderColor='#d1d5db'}>
                <input
                  autoFocus
                  type="text"
                  value={renameName}
                  onChange={e => setRenameName(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') commitRename(); if (e.key === 'Escape') closeRenameModal(); }}
                  style={{ flex:1, padding:'9px 12px', fontSize:13, border:'none', outline:'none', minWidth:0 }}
                />
                {renameFile?.ext && (
                  <span style={{ padding:'9px 12px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#f3f4f6', borderLeft:'1px solid #e5e7eb', whiteSpace:'nowrap', userSelect:'none' }}>
                    .{renameFile.ext}
                  </span>
                )}
              </div>
              <p style={{ margin:'6px 0 0', fontSize:11, color:'#9ca3af' }}>File extension cannot be changed.</p>
            </div>
            <div style={{ padding:'14px 20px', borderTop:'1px solid #e5e7eb', display:'flex', justifyContent:'flex-end', gap:10, background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
              <button onClick={closeRenameModal}
                style={{ padding:'8px 20px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>
                Cancel
              </button>
              <button onClick={commitRename} disabled={renaming || !renameName.trim()}
                style={{ padding:'8px 24px', fontSize:13, fontWeight:600, color:'#fff', background: renaming || !renameName.trim() ? '#93aad4' : '#1A3673', border:'none', borderRadius:6, cursor: renaming || !renameName.trim() ? 'not-allowed' : 'pointer' }}>
                {renaming ? 'Updating...' : 'Update'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Preview modal */}
      {previewModal && (
        <div
          onClick={e => { if (e.target === e.currentTarget) closePreviewModal(); }}
          style={{ position:'fixed', inset:0, zIndex:10000, background:'rgba(0,0,0,0.65)', display:'flex', alignItems:'center', justifyContent:'center', padding:32 }}
        >
          <div style={{ background:'#fff', borderRadius:12, boxShadow:'0 8px 48px rgba(0,0,0,0.30)', width:'calc(100vw - 64px)', height:'calc(100vh - 64px)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
            {/* Header */}
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 18px', borderBottom:'1px solid #e5e7eb', background:'#1A3673', borderRadius:'12px 12px 0 0', flexShrink:0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, minWidth:0 }}>
                <FileText size={15} style={{ color:'#93c5fd', flexShrink:0 }} />
                <span style={{ fontWeight:700, fontSize:14, color:'#fff', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{previewModal.file.name}</span>
                {previewModal.file.ext && (
                  <span style={{ fontSize:11, fontWeight:600, padding:'2px 8px', borderRadius:4, background:'rgba(255,255,255,0.15)', color:'#e0f2fe', flexShrink:0 }}>{previewModal.file.ext.toUpperCase()}</span>
                )}
              </div>
              <button onClick={closePreviewModal}
                style={{ background:'rgba(255,255,255,0.15)', border:'none', borderRadius:6, cursor:'pointer', color:'#fff', display:'flex', alignItems:'center', padding:6 }}
                onMouseEnter={e => e.currentTarget.style.background='rgba(255,255,255,0.25)'}
                onMouseLeave={e => e.currentTarget.style.background='rgba(255,255,255,0.15)'}
              >
                <X size={18} />
              </button>
            </div>
            {/* Body — flex:1 fills remaining height; inner component handles its own scroll */}
            <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'auto', minHeight:0 }}>
              <FilePreviewContent pdata={previewModal.data} fileName={previewModal.file.name} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
