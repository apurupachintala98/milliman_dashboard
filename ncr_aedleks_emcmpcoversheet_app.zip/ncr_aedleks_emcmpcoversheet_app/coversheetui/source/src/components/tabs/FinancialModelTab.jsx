import { useState, useCallback, useEffect, useRef } from 'react';
import { ChevronDown, ChevronRight, Info, CheckCircle, XCircle, MinusCircle, TrendingUp, Search, Filter, X, Loader2, AlertCircle, Cpu } from 'lucide-react';
import { financialModelApi, subscribeToFmGenerationStream } from '../../config/apiConfig';


const fmtD = (n) => `$${n.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
const fmtN = (n, dec = 1) => n.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec });
const pct = (n) => `${(n * 100).toFixed(0)}%`;

const GL_BADGE = {
  'In Scope':     { icon: <CheckCircle size={10} />, cls: 'bg-teal-50 text-[#00BBBA] border border-teal-200' },
  'Opted Out':    { icon: <XCircle size={10} />,     cls: 'bg-red-50 text-[#E3725F] border border-red-200' },
  'Not in Scope': { icon: <MinusCircle size={10} />, cls: 'bg-gray-100 text-gray-400 border border-gray-200' },
};

const LOB_COLORS = {
  CSBD: 'bg-[#C8860A] text-white',
  COM:  'bg-[#44B8F3] text-white',
  MCR:  'bg-[#1A3673] text-white',
  GRS:  'bg-[#2861BB] text-white',
  MCD:  'bg-[#00BBBA] text-white',
  MMP:  'bg-purple-600 text-white',
};
const LOB_INACTIVE = 'bg-white border border-gray-200 text-gray-500 hover:border-[#1A3673] hover:text-[#1A3673]';

// Normalize green-light status from API to the labels used in the component
function normalizeGlStatus(s) {
  if (!s) return 'Not in Scope';
  const v = s.trim().toLowerCase();
  if (v === 'in-scope' || v === 'in scope') return 'In Scope';
  if (v === 'opted out')                    return 'Opted Out';
  return 'Not in Scope';
}

// Map API response (concepts, actuals, green_light) into component shape.
// Map API response (concepts, actuals, green_light) into the shape the component uses.
function mapApiToSourceData(apiData) {
  const { concepts = [], actuals = [], green_light = [] } = apiData;
  if (!concepts.length && !actuals.length) return null;

  const glLookup = {};
  green_light.forEach(gl => {
    const key = gl.cncpt_nm + '|' + gl.lob_nm + '|' + (gl.mrkt_nm ?? '');
    if (!glLookup[key]) glLookup[key] = gl;
  });

  const actualsMap = {};
  actuals.forEach(a => {
    const type = a.fncl_mdl_type_nm ?? 'Cost of Care';
    const key  = type + '|' + a.cncpt_nm + '|' + a.lob_nm;
    if (!actualsMap[key]) actualsMap[key] = [];
    actualsMap[key].push(a);
  });

  const LOB_CODE_MAP = {
    commercial: 'CSBD',
    medicare: 'MCR',
    grs: 'GRS',
    groupretireesolutions: 'GRS',
    medicaid: 'MCD',
    mmp: 'MMP',
    commercialsmallbusinessdivision: 'CSBD',
  };
  const toLobCode = (lobNm) => {
    const key = (lobNm ?? '').toLowerCase().replace(/[^a-z]/g, '');
    return LOB_CODE_MAP[key] ?? (lobNm ? lobNm.toUpperCase().slice(0, 4) : 'UNK');
  };

  const result = [];
  const types = [...new Set(concepts.map(c => c.fncl_mdl_type_nm ?? 'Cost of Care'))];

  types.forEach(type => {
    const cncptNames = [...new Set(
      concepts.filter(c => (c.fncl_mdl_type_nm ?? 'Cost of Care') === type).map(c => c.cncpt_nm)
    )];

    const builtConcepts = cncptNames.map(cncptNm => {
      const lobsForCncpt = concepts.filter(
        c => (c.fncl_mdl_type_nm ?? 'Cost of Care') === type && c.cncpt_nm === cncptNm
      );

      const lobs = lobsForCncpt.map(c => {
        const lobNm          = c.lob_nm;
        const lobCode        = toLobCode(lobNm);
        const discnt         = c.cncpt_dscnt_txt ?? {};
        const initDiscount   = discnt['Initial Discount']  ?? 0;
        const rebillDiscount = discnt['Re-Bill Discount']  ?? 0;
        const overturnRate   = discnt['Overturn Rate']     ?? 0;

        const actualsKey = type + '|' + cncptNm + '|' + lobNm;
        const rows = (actualsMap[actualsKey] ?? []).map(a => {
          const glKey   = cncptNm + '|' + lobNm + '|' + (a.mrkt_nm ?? '');
          const glEntry = glLookup[glKey];
          return {
            state:            a.mrkt_nm ?? 'National',
            claims:           parseFloat(a.clms_cnt)                         || 0,
            paidAmount:       parseFloat(a.actl_svng_amt)                    || 0,
            adjClaimsInitial: parseFloat(a.init_dscnt_adjstd_clm_cnt)        || 0,
            adjClaimsRebill:  parseFloat(a.init_rebill_dscnt_adjstd_clm_cnt) || 0,
            savings:          parseFloat(a.ptntl_svng_amt)                   || 0,
            gl:               normalizeGlStatus(glEntry ? glEntry.grn_lght_stts_nm : null),
            notes:            glEntry ? (glEntry.grn_lght_stts_nm_note_txt ?? '') : '',
          };
        });

        return { lob: lobNm, lobCode, initDiscount, rebillDiscount, overturnRate, criteria: [], additionalFields: [], rows };
      });

      const firstLob = lobsForCncpt[0] ?? {};
      const discnt   = firstLob.cncpt_dscnt_txt ?? {};
      const config = {
        conceptNumber:    cncptNm,
        conceptName:      'Concept ' + cncptNm,
        initReduction:    discnt['Initial Discount'] ?? 0,
        rebillDiscount:   discnt['Re-Bill Discount'] ?? 0,
        quantumData:      discnt['Quantum Data']     ?? 0,
        additionalFields: [],
      };

      return { id: cncptNm, label: cncptNm, description: firstLob.cncpt_desc ?? '', config, lobs };
    });

    result.push({ type, concepts: builtConcepts });
  });

  return result;
}

function buildInitialConfigs() { return {}; }


export default function FinancialModelTab({ coversheet, onEdit: _onEdit }) {
  const [activeCOC, setActiveCOC] = useState(null);
  const [openConcepts, setOpenConcepts] = useState(new Set());
  const [activeLOB, setActiveLOB] = useState({});
  const [configs, setConfigs] = useState(buildInitialConfigs);
  const [openSettings, setOpenSettings] = useState(new Set());

  const [fmApiData,   setFmApiData]   = useState(null);
  const [fmLoading,   setFmLoading]   = useState(true);
  const [fmError,     setFmError]     = useState(null);

  // SSE live-stream state
  const [sseStatus,   setSseStatus]   = useState(null);   // latest parsed SSE message object
  const [ssePhase,    setSsePhase]    = useState('connecting'); // 'connecting' | 'streaming' | 'done' | 'error'
  const sseCleanupRef = useRef(null);

  // Helper: load FM data after SSE confirms completed/not_started
  const loadFmData = useCallback((cvrsht_id) => {
    financialModelApi.get(cvrsht_id)
      .then(data => {
        const mapped = mapApiToSourceData(data);
        if (mapped) {
          setFmApiData(mapped);
          setActiveCOC(mapped[0]?.type ?? null);
          const newCfgs = {};
          mapped.forEach(grp => grp.concepts.forEach(c => { newCfgs[c.id] = { ...c.config }; }));
          setConfigs(prev => ({ ...prev, ...newCfgs }));
        }
      })
      .catch(err => {
        console.warn('[FinancialModel] API fetch failed:', err.message);
        setFmError(err.message);
      })
      .finally(() => setFmLoading(false));
  }, []);

  useEffect(() => {
    const cvrsht_id = coversheet?.id;
    if (!cvrsht_id) return;

    // Reset state
    setFmLoading(true);
    setFmError(null);
    setSseStatus(null);
    setSsePhase('connecting');

    // Clean up any previous SSE subscription
    if (sseCleanupRef.current) { sseCleanupRef.current(); sseCleanupRef.current = null; }

    // Subscribe to SSE stream — shows live status while FM generates
    const cleanup = subscribeToFmGenerationStream(cvrsht_id, {
      onMessage: (msg) => {
        setSseStatus(msg);
        setSsePhase('streaming');
        // If terminal state received, stream is done — load the actual FM data
        if (msg.status === 'completed' || msg.status === 'not_started') {
          loadFmData(cvrsht_id);
        } else if (msg.status === 'failed') {
          setFmError('Financial model generation failed. Please try again.');
          setFmLoading(false);
          setSsePhase('error');
        }
      },
      onDone: () => {
        setSsePhase('done');
        // If no terminal status was received yet, still load data
        setSseStatus(prev => {
          const lastStatus = prev?.status;
          if (!lastStatus || (lastStatus !== 'completed' && lastStatus !== 'failed' && lastStatus !== 'not_started')) {
            loadFmData(cvrsht_id);
          }
          return prev;
        });
      },
      onError: (err) => {
        console.warn('[FinancialModel] SSE error:', err.message);
        // SSE failed — fall back to direct FM data fetch
        setSsePhase('error');
        loadFmData(cvrsht_id);
      },
    });
    sseCleanupRef.current = cleanup;

    return () => {
      if (sseCleanupRef.current) { sseCleanupRef.current(); sseCleanupRef.current = null; }
    };
  }, [coversheet?.id, loadFmData]);

  const activeSourceData = fmApiData ?? [];

  // Keys are concept.id strings; values are the toolbar/filter state for that concept's table
  const FM_BLANK_F = { state: '', gl: '' };
  const [fmSearch,      setFmSearch]      = useState({});  // { [conceptId]: string }
  const [fmFilterOpen,  setFmFilterOpen]  = useState({});  // { [conceptId]: bool }
  const [fmPending,     setFmPending]     = useState({});  // { [conceptId]: { state, gl } }
  const [fmActive,      setFmActive]      = useState({});  // { [conceptId]: { state, gl } }

  const getFmSearch  = (id) => fmSearch[id]  ?? '';
  const getFmOpen    = (id) => fmFilterOpen[id] ?? false;
  const getFmPending = (id) => fmPending[id] ?? FM_BLANK_F;
  const getFmActive  = (id) => fmActive[id]  ?? FM_BLANK_F;
  const setFmSearchId  = (id, v) => setFmSearch(p  => ({ ...p, [id]: v }));
  const setFmOpenId    = (id, v) => setFmFilterOpen(p => ({ ...p, [id]: v }));
  const setFmPendingId = (id, v) => setFmPending(p => ({ ...p, [id]: typeof v === 'function' ? v(p[id] ?? FM_BLANK_F) : v }));
  const setFmActiveId  = (id, v) => setFmActive(p  => ({ ...p, [id]: typeof v === 'function' ? v(p[id] ?? FM_BLANK_F) : v }));

  const toggleSettings = (id) => setOpenSettings(prev => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const cocGroup = activeSourceData.find(g => g.type === activeCOC) ?? activeSourceData[0] ?? { type: '', concepts: [] };

  const toggleConcept = (id) => {
    setOpenConcepts(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const updateConfig = useCallback((id, patch) => {
    setConfigs(prev => ({ ...prev, [id]: { ...prev[id], ...patch } }));
  }, []);

  const updateAdditionalField = useCallback((id, idx, patch) => {
    setConfigs(prev => {
      const fields = [...prev[id].additionalFields];
      fields[idx] = { ...fields[idx], ...patch };
      return { ...prev, [id]: { ...prev[id], additionalFields: fields } };
    });
  }, []);

  const addAdditionalField = useCallback((id) => {
    setConfigs(prev => ({
      ...prev,
      [id]: { ...prev[id], additionalFields: [...prev[id].additionalFields, { label: '', value: '' }] },
    }));
  }, []);

  const removeAdditionalField = useCallback((id, idx) => {
    setConfigs(prev => {
      const fields = prev[id].additionalFields.filter((_, i) => i !== idx);
      return { ...prev, [id]: { ...prev[id], additionalFields: fields } };
    });
  }, []);

  // Grand total across all concepts x active LOB
  const grandTotalSavings = cocGroup.concepts.reduce((sum, concept) => {
    const lobCode = activeLOB[concept.id] ?? concept.lobs[0]?.lobCode;
    const lobSec = concept.lobs.find(l => l.lobCode === lobCode);
    return sum + (lobSec?.rows.filter(r => r.gl === 'In Scope').reduce((s, r) => s + r.savings, 0) ?? 0);
  }, 0);

  const grandTotalClaims = cocGroup.concepts.reduce((sum, concept) => {
    const lobCode = activeLOB[concept.id] ?? concept.lobs[0]?.lobCode;
    const lobSec = concept.lobs.find(l => l.lobCode === lobCode);
    return sum + (lobSec?.rows.filter(r => r.gl === 'In Scope').reduce((s, r) => s + r.claims, 0) ?? 0);
  }, 0);

  if (fmLoading) {
    const sseMsg      = sseStatus;
    const statusLabel = sseMsg?.status ?? 'connecting';

    // FIX 1: 'processing' is the actual API status for active generation
    const isGenerating = ['processing', 'in_progress', 'running', 'pending'].includes(statusLabel);
    const isConnecting = ssePhase === 'connecting' || ssePhase === 'error' || !sseMsg;

    const STATUS_LABEL = {
      connecting:  'Connecting to server…',
      processing:  'Generating financial model…',   // FIX 1: actual API status
      in_progress: 'Generating financial model…',
      running:     'Generating financial model…',
      pending:     'Financial model generation queued…',
      completed:   'Generation complete, loading data…',
      not_started: 'Loading financial model data…',
      failed:      'Generation failed',
    };
    const displayLabel = STATUS_LABEL[statusLabel] ?? 'Loading financial model data…';

    // FIX 2: use progress_pct from API (0–100)
    const progressPct = sseMsg?.progress_pct ?? null;

    // FIX 3: derive elapsed from attempt/max_attempts since API has no elapsed_seconds
    const attempt     = sseMsg?.attempt     ?? null;
    const maxAttempts = sseMsg?.max_attempts ?? null;

    return (
      <div className="flex items-center justify-center py-24">
        <div className="text-center" style={{ maxWidth: 420, width: '100%', padding: '0 24px' }}>
          {/* Spinner icon */}
          <div className="flex items-center justify-center mb-4">
            <div style={{ position: 'relative', width: 56, height: 56 }}>
              <div style={{
                position: 'absolute', inset: 0, borderRadius: '50%',
                border: '3px solid #e5e7eb',
                borderTopColor: '#1A3673',
                animation: 'spin 1s linear infinite',
              }} />
              <div style={{
                position: 'absolute', inset: 8,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#1A3673',
              }}>
                {isConnecting ? <Loader2 size={20} className="animate-spin" /> : <Cpu size={20} />}
              </div>
            </div>
          </div>

          {/* Status label */}
          <p style={{ fontSize: 13, fontWeight: 600, color: '#1A3673', marginBottom: 6 }}>
            {displayLabel}
          </p>

          {/* Live status badge */}
          {sseMsg && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, marginBottom: 12,
              background: isGenerating ? '#EFF6FF' : '#F0FDF4',
              border: `1px solid ${isGenerating ? '#BFDBFE' : '#BBF7D0'}`,
              borderRadius: 999, padding: '3px 10px' }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%',
                background: isGenerating ? '#3B82F6' : '#22C55E',
                display: 'inline-block',
                ...(isGenerating && { animation: 'pulse 1.5s infinite' }) }} />
              <span style={{ fontSize: 10, fontWeight: 600,
                color: isGenerating ? '#1D4ED8' : '#15803D',
                textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {statusLabel}
              </span>
            </div>
          )}

          {/* FIX 2: progress_pct progress bar */}
          {progressPct != null && (
            <div style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 10, color: '#6b7280' }}>Progress</span>
                <span style={{ fontSize: 10, fontWeight: 700, color: '#1A3673' }}>{progressPct}%</span>
              </div>
              <div style={{ width: '100%', height: 6, background: '#e5e7eb', borderRadius: 999, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${progressPct}%`,
                  background: 'linear-gradient(90deg, #1A3673, #3B82F6)',
                  borderRadius: 999,
                  transition: 'width 0.4s ease',
                }} />
              </div>
            </div>
          )}

          {/* FIX 3: attempt/max_attempts instead of missing elapsed_seconds */}
          {attempt != null && maxAttempts != null && (
            <p style={{ fontSize: 11, color: '#9ca3af', marginBottom: 6 }}>
              Step {attempt} of {maxAttempts}
            </p>
          )}

          {/* Generation ID */}
          {sseMsg?.generation_id && (
            <p style={{ fontSize: 10, color: '#d1d5db', fontFamily: 'monospace', marginTop: 4 }}>
              {sseMsg.generation_id}
            </p>
          )}
        </div>
      </div>
    );
  }

  if (fmError) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="text-center max-w-sm">
          <p className="text-sm text-red-500 mb-2">Failed to load financial model data.</p>
          <p className="text-xs text-gray-400">{fmError}</p>
        </div>
      </div>
    );
  }

  if (!fmApiData) {
    return (
      <div className="flex items-center justify-center py-24">
        <p className="text-sm text-gray-400">No financial model data available for this coversheet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">

      {/* ── KPI Header ─────────────────────────────────────────────────────── */}
      <div className="card p-4 flex flex-wrap items-center gap-6">
        <div className="flex items-center gap-2">
          <div>
            <p className="text-[10px] text-gray-400 uppercase tracking-wider">Total In-Scope Savings</p>
            <p className="text-xl font-bold text-[#1A3673]">{fmtD(grandTotalSavings)}</p>
          </div>
        </div>
        <div className="h-8 w-px bg-gray-100" />
        <div>
          <p className="text-[10px] text-gray-400 uppercase tracking-wider">In-Scope Claims</p>
          <p className="text-sm font-semibold text-[#231E33]">{grandTotalClaims.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-[10px] text-gray-400 uppercase tracking-wider">COC Type</p>
          <p className="text-sm font-semibold text-[#231E33]">{activeCOC}</p>
        </div>
        <div>
          <p className="text-[10px] text-gray-400 uppercase tracking-wider">Concepts</p>
          <p className="text-sm font-semibold text-[#231E33]">{cocGroup.concepts.length}</p>
        </div>
        <div className="ml-auto flex items-center gap-1.5 text-[10px] text-gray-400">
          <TrendingUp size={11} />
          <span>Source: Financial Model API</span>
        </div>
      </div>

      {/* ── COC Type Selector — tabs built dynamically from API types ──────── */}
      <div className="card overflow-hidden">
        <div className={`grid grid-cols-${activeSourceData.length || 1} divide-x divide-gray-200 border-b border-gray-200`}>
          {activeSourceData.map(g => (
            <button
              key={g.type}
              onClick={() => { setActiveCOC(g.type); setOpenConcepts(new Set()); }}
              className={`px-4 py-3 text-sm font-semibold text-center transition
                ${activeCOC === g.type
                  ? 'bg-[#1A3673] text-white'
                  : 'bg-gray-50 text-gray-500 hover:bg-gray-100 hover:text-[#1A3673]'}`}
            >
              {g.type}
            </button>
          ))}
        </div>

        {/* ── Concept list with arrows (like the diagram) ────────────────── */}
        {cocGroup.concepts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-300 gap-3">
            <MinusCircle size={32} />
            <p className="text-sm">No concepts configured for {activeCOC}</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {cocGroup.concepts.map(concept => {
              const isOpen = openConcepts.has(concept.id);
              const lobCode = activeLOB[concept.id] ?? concept.lobs[0]?.lobCode;
              const lobSec = concept.lobs.find(l => l.lobCode === lobCode);
              const inScopeRows = lobSec?.rows.filter(r => r.gl === 'In Scope') ?? [];
              const totalClaims = inScopeRows.reduce((s, r) => s + r.claims, 0);
              const totalSavings = inScopeRows.reduce((s, r) => s + r.savings, 0);

              return (
                <div key={concept.id}>
                  {/* ── Concept accordion header ────────────────────────── */}
                  <div
                    role="button"
                    tabIndex={0}
                    aria-expanded={isOpen}
                    className="w-full flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition cursor-pointer"
                    onClick={() => toggleConcept(concept.id)}
                    onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleConcept(concept.id); } }}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {isOpen
                        ? <ChevronDown size={14} className="text-[#1A3673] flex-shrink-0" />
                        : <ChevronRight size={14} className="text-gray-400 flex-shrink-0" />}
                      {/* Arrow connector like the image */}
                      {(() => {
                        const hcfg = configs[concept.id] ?? concept.config;
                        const stop = (e) => e.stopPropagation();
                        return (
                          <span className="inline-flex items-center gap-2">
                            <input
                              type="text"
                              value={hcfg.conceptNumber}
                              onChange={e => updateConfig(concept.id, { conceptNumber: e.target.value })}
                              onClick={stop} onKeyDown={stop}
                              size={Math.max(2, hcfg.conceptNumber.length)}
                              title="Click to edit concept #"
                              placeholder="#"
                              className="px-2 py-0.5 rounded bg-[#E1EDFF] text-[#1A3673] text-xs font-bold border border-transparent hover:border-[#2861BB]/40 focus:border-[#2861BB] focus:outline-none text-center"
                            />
                            <input
                              type="text"
                              value={hcfg.conceptName}
                              onChange={e => updateConfig(concept.id, { conceptName: e.target.value })}
                              onClick={stop} onKeyDown={stop}
                              size={Math.max(8, hcfg.conceptName.length)}
                              title="Click to edit concept name"
                              placeholder="Concept name"
                              className="px-1 py-0.5 rounded bg-transparent text-sm font-semibold text-[#231E33] border border-transparent hover:border-gray-300 focus:border-[#2861BB] focus:bg-white focus:outline-none"
                            />
                          </span>
                        );
                      })()}
                      <span className="hidden md:block text-[11px] text-gray-400">
                        {concept.description}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 flex-shrink-0 ml-4">
                      <span className="text-[11px] text-gray-400">{totalClaims.toLocaleString()} claims</span>
                      <span className="text-sm font-bold text-[#00BBBA]">{fmtD(totalSavings)}</span>
                    </div>
                  </div>

                  {isOpen && (() => {
                    const cfg = configs[concept.id] ?? concept.config;
                    return (
                    <div className="bg-[#FAFBFF]">
                      {/* ── Concept description banner ───────────────────── */}
                      <div className="mx-5 mb-3 mt-2 rounded-lg border border-blue-100 bg-blue-50 px-4 py-2.5 flex items-start gap-2">
                        <Info size={12} className="text-[#2861BB] mt-0.5 flex-shrink-0" />
                        <p className="text-[11px] text-[#2861BB] leading-relaxed">{concept.description}</p>
                      </div>

                      {/* ── LOB tabs (cascade from concept) ─────────────── */}
                      <div className="px-5 pb-2 flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] text-gray-400 uppercase tracking-wider font-medium mr-1">LOB</span>
                        {[...concept.lobs].filter(l => l.rows.length > 0).sort((a, b) => {
                          const order = ['CSBD', 'COM', 'MCR', 'GRS', 'MCD', 'MMP'];
                          return (order.indexOf(a.lobCode) + 99) % 99 - (order.indexOf(b.lobCode) + 99) % 99;
                        }).map(l => (
                          <button
                            key={l.lobCode}
                            onClick={() => setActiveLOB(prev => ({ ...prev, [concept.id]: l.lobCode }))}
                            className={`px-3 py-1 rounded-full text-[11px] font-semibold transition
                              ${lobCode === l.lobCode
                                ? (LOB_COLORS[l.lobCode] ?? 'bg-gray-700 text-white')
                                : LOB_INACTIVE}`}
                          >
                            {l.lob}
                          </button>
                        ))}
                      </div>

                      {/* ── Data Criteria (read-only, from source pivot) ───── */}
                      {lobSec && (
                        <div className="mx-5 mb-3 rounded-lg border border-gray-200 bg-white shadow-sm overflow-hidden">
                          <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b border-gray-200">
                            <span className="text-[11px] font-bold text-[#1A3673] uppercase tracking-wider">Data Criteria — {lobSec.lob}</span>
                            <span className="text-[10px] text-gray-400 italic">View only · from source pivot</span>
                          </div>
                          {lobSec.criteria.length === 0 ? (
                            <p className="px-4 py-3 text-[11px] text-gray-400 italic">No data criteria provided for {lobSec.lob}.</p>
                          ) : (
                            <table className="w-full text-xs">
                              <tbody>
                                {lobSec.criteria.map(c => (
                                  <tr key={c.field} className="border-b border-gray-100 last:border-0">
                                    <td className="px-4 py-1.5 font-mono text-[11px] text-gray-700 whitespace-nowrap w-64">{c.field}</td>
                                    <td className="px-2 py-1.5 whitespace-nowrap w-40">
                                      <span className={`px-1.5 py-0.5 rounded text-[11px] ${c.isValueHighlighted ? 'bg-yellow-200 text-gray-900 font-semibold' : c.isMultiple ? 'text-gray-500 italic' : 'text-gray-800'}`}>{c.value}</span>
                                    </td>
                                    <td className={`px-2 py-1.5 text-[11px] ${c.isHighlighted ? 'text-red-600' : 'text-gray-600'}`}>{c.note ?? ''}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          )}
                        </div>
                      )}

                      {/* ── Concept-level Config Panel ───────────────────── */}
                      <div className="mx-5 mb-4 rounded-lg border border-gray-200 bg-white shadow-sm overflow-hidden">
                        <button type="button" onClick={() => toggleSettings(concept.id)} aria-expanded={openSettings.has(concept.id)}
                          className="w-full flex items-center justify-between px-4 py-2.5 bg-gray-50 hover:bg-gray-100 transition">
                          <span className="flex items-center gap-2 text-[11px] font-bold text-[#1A3673] uppercase tracking-wider">
                            {openSettings.has(concept.id) ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                            Rates &amp; Additional Data Model Details
                          </span>
                          <span className="text-[10px] text-gray-500">
                            Initial {Math.round(cfg.initReduction * 100)}% · Re-Bill {Math.round(cfg.rebillDiscount * 100)}% · Quantum {Math.round(cfg.quantumData * 100)}%
                            {cfg.additionalFields.length > 0 && ` · ${cfg.additionalFields.length} field${cfg.additionalFields.length !== 1 ? 's' : ''}`}
                          </span>
                        </button>
                        {openSettings.has(concept.id) && (
                        <div className="divide-y divide-gray-100 border-t border-gray-200">
                          {/* ── Group: Rates ── */}
                          <div className="p-4">
                          <p className="text-[10px] font-bold text-[#1A3673] uppercase tracking-wider mb-2">Rates</p>
                          <div className="space-y-3">
                          {/* Initial Discount % */}
                          <div>
                            <label className="form-label">Initial Discount %</label>
                            <div className="relative">
                              <input
                                type="number"
                                min={0} max={100} step={1}
                                value={Math.round(cfg.initReduction * 100)}
                                onChange={e => updateConfig(concept.id, { initReduction: Number(e.target.value) / 100 })}
                                className="form-input text-xs py-1 pr-6"
                              />
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none">%</span>
                            </div>
                          </div>
                          {/* Re-Bill Discount % */}
                          <div>
                            <label className="form-label">Re-Bill Discount %</label>
                            <div className="relative">
                              <input
                                type="number"
                                min={0} max={100} step={1}
                                value={Math.round(cfg.rebillDiscount * 100)}
                                onChange={e => updateConfig(concept.id, { rebillDiscount: Number(e.target.value) / 100 })}
                                className="form-input text-xs py-1 pr-6"
                              />
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none">%</span>
                            </div>
                          </div>
                          {/* Quantum Data % */}
                          <div>
                            <label className="form-label">Quantum Data %</label>
                            <div className="relative">
                              <input
                                type="number"
                                min={0} max={100} step={1}
                                value={Math.round(cfg.quantumData * 100)}
                                onChange={e => updateConfig(concept.id, { quantumData: Number(e.target.value) / 100 })}
                                className="form-input text-xs py-1 pr-6"
                              />
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none">%</span>
                            </div>
                          </div>
                          </div>
                          </div>
                          {/* Additional Fields — dynamic, user-defined label + value */}
                          <div className="p-4 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-[#1A3673] uppercase tracking-wider">Additional Data Model Details</span>
                              <button
                                type="button"
                                onClick={() => addAdditionalField(concept.id)}
                                className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold text-[#1A3673] border border-[#1A3673] hover:bg-[#E1EDFF] transition"
                              >
                                + Add Field
                              </button>
                            </div>
                            {cfg.additionalFields.length === 0 && (
                              <p className="text-[11px] text-gray-400 italic">No fields added. Click "+ Add Field" to add one.</p>
                            )}
                            {cfg.additionalFields.map((f, idx) => (
                              <div key={idx} className="flex items-center gap-2">
                                <input
                                  type="text"
                                  value={f.label}
                                  onChange={e => updateAdditionalField(concept.id, idx, { label: e.target.value })}
                                  className="form-input text-xs py-1 w-48 flex-shrink-0"
                                  placeholder="Field name"
                                />
                                <input
                                  type="text"
                                  value={f.value}
                                  onChange={e => updateAdditionalField(concept.id, idx, { value: e.target.value })}
                                  className="form-input text-xs py-1 flex-1"
                                  placeholder="Field value"
                                />
                                <button
                                  type="button"
                                  onClick={() => removeAdditionalField(concept.id, idx)}
                                  className="flex-shrink-0 text-gray-300 hover:text-red-400 transition text-base leading-none px-1"
                                  title="Remove field"
                                >
                                  ×
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                        )}
                      </div>

                      {/* ── Per-concept filter modal ─────────────────────── */}
                      {getFmOpen(concept.id) && (
                        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
                          onClick={() => { setFmPendingId(concept.id, getFmActive(concept.id)); setFmOpenId(concept.id, false); }}>
                          <div style={{ background:'#fff', borderRadius:12, maxWidth:480, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
                            onClick={e => e.stopPropagation()}>
                            <div style={{ padding:'14px 18px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
                              <div style={{ display:'flex', alignItems:'center', gap:8 }}><Filter size={16} color="#fff" /><span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>Filter — {concept.label}</span></div>
                              <button onClick={() => { setFmPendingId(concept.id, getFmActive(concept.id)); setFmOpenId(concept.id, false); }} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}><X size={18} /></button>
                            </div>
                            <div style={{ padding:20, display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
                              <div>
                                <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>State</label>
                                <select value={getFmPending(concept.id).state}
                                  onChange={e => setFmPendingId(concept.id, p => ({ ...p, state: e.target.value }))}
                                  style={{ width:'100%', padding:'7px 10px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                                  <option value="">All</option>
                                  {[...new Set(lobSec?.rows.map(r => r.state).filter(Boolean))].sort().map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                              </div>
                              <div>
                                <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>GL Status</label>
                                <select value={getFmPending(concept.id).gl}
                                  onChange={e => setFmPendingId(concept.id, p => ({ ...p, gl: e.target.value }))}
                                  style={{ width:'100%', padding:'7px 10px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                                  <option value="">All</option>
                                  <option value="In Scope">In Scope</option>
                                  <option value="Opted Out">Opted Out</option>
                                  <option value="Not in Scope">Not in Scope</option>
                                </select>
                              </div>
                            </div>
                            <div style={{ padding:'12px 20px', borderTop:'1px solid #e5e7eb', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                              <button onClick={() => { setFmPendingId(concept.id, { state:'', gl:'' }); setFmActiveId(concept.id, { state:'', gl:'' }); setFmOpenId(concept.id, false); }}
                                style={{ padding:'7px 14px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>Clear All</button>
                              <div style={{ display:'flex', gap:8 }}>
                                <button onClick={() => { setFmPendingId(concept.id, getFmActive(concept.id)); setFmOpenId(concept.id, false); }}
                                  style={{ padding:'7px 16px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>Cancel</button>
                                <button onClick={() => { setFmActiveId(concept.id, getFmPending(concept.id)); setFmOpenId(concept.id, false); }}
                                  style={{ padding:'7px 20px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>Apply Filters</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* ── Search + Filter toolbar ───────────────────────── */}
                      {lobSec && lobSec.rows.length > 0 && (() => {
                        const srch    = getFmSearch(concept.id);
                        const act     = getFmActive(concept.id);
                        const actCnt  = Object.values(act).filter(v => v !== '').length;
                        return (
                          <div style={{ margin:'0 20px 10px', padding:'8px 12px', background:'#fafafa', border:'1px solid #e5e7eb', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'space-between', gap:8 }}>
                            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                              <div style={{ position:'relative', flex:'0 1 280px' }}>
                                <Search size={13} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
                                <input type="text" value={srch} onChange={e => setFmSearchId(concept.id, e.target.value)}
                                  placeholder="Search states, GL status, notes…"
                                  style={{ width:'100%', paddingLeft:28, paddingRight: srch ? 26 : 10, paddingTop:5, paddingBottom:5, fontSize:12, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
                                  onFocus={e => e.target.style.borderColor='#1A3673'} onBlur={e => e.target.style.borderColor='#d1d5db'} />
                                {srch && <button onClick={() => setFmSearchId(concept.id, '')} style={{ position:'absolute', right:7, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}><X size={12} /></button>}
                              </div>
                              <button onClick={() => { setFmPendingId(concept.id, act); setFmOpenId(concept.id, true); }}
                                style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'5px 12px', cursor:'pointer', position:'relative' }}>
                                <Filter size={12} />
                                {actCnt > 0 && <span style={{ position:'absolute', top:-5, right:-5, background:'#E3725F', color:'#fff', fontSize:9, fontWeight:700, borderRadius:999, padding:'2px 6px', minWidth:18, textAlign:'center' }}>{actCnt}</span>}
                              </button>
                            </div>
                            {actCnt > 0 && (
                              <button onClick={() => { setFmActiveId(concept.id, { state:'', gl:'' }); setFmPendingId(concept.id, { state:'', gl:'' }); }}
                                style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'4px 10px', cursor:'pointer' }}>
                                <X size={10} /> Clear All
                              </button>
                            )}
                          </div>
                        );
                      })()}

                      {/* ── Combined Raw + Calculation Table ─────────────── */}
                      <div className="mx-5 mb-5 rounded-lg overflow-hidden border border-gray-200 shadow-sm">
                        {!lobSec || lobSec.rows.length === 0 ? (
                          <div className="py-8 text-center text-gray-300 text-xs">No data for {lobCode}</div>
                        ) : (() => {
                          const cfg = configs[concept.id] ?? concept.config;
                          const extraFields = cfg.additionalFields.filter(f => f.label.trim());
                          return (
                          <div className="overflow-x-auto">
                            <table className="w-full text-xs border-collapse">
                              <thead>
                                {/* ── Row 1: group labels ── */}
                                <tr>
                                  {/* frozen left: no group label */}
                                  <th colSpan={1} className="bg-[#1A3673]" />
                                  {/* Raw group */}
                                  <th
                                    colSpan={5 + extraFields.length}
                                    className="px-4 py-2 text-center text-[11px] font-bold text-[#1A3673] bg-gray-100 border-x border-gray-300 tracking-wide uppercase"
                                  >
                                    Raw Data
                                  </th>
                                  {/* Calculation group */}
                                  <th
                                    colSpan={6}
                                    className="px-4 py-2 text-center text-[11px] font-bold text-[#1A3673] bg-[#E8F0FF] border-r border-gray-300 tracking-wide uppercase"
                                  >
                                    Calculations
                                  </th>
                                </tr>
                                {/* ── Row 2: column headers ── */}
                                <tr className="bg-[#1A3673] text-white">
                                  {/* frozen */}
                                  <th className="px-3 py-2.5 text-left text-[11px] font-semibold whitespace-nowrap">State</th>
                                  {/* Raw columns */}
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-gray-200 text-[#1A3673] border-l border-gray-300">
                                    Claims Volume
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-gray-200 text-[#1A3673]">
                                    Sum of PAID$
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-gray-200 text-[#1A3673]">
                                    Initial Discount
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-gray-200 text-[#1A3673]">
                                    Re-Bill Discount
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-gray-200 text-[#1A3673] border-r border-gray-300">
                                    Overturn Rate
                                  </th>
                                  {extraFields.map((f, i) => (
                                    <th key={i} className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-gray-200 text-[#1A3673] border-r border-gray-300">
                                      {f.label}
                                    </th>
                                  ))}
                                  {/* Calculation columns */}
                                  <th className="px-3 py-2.5 text-left text-[11px] font-semibold whitespace-nowrap bg-[#2149A0] border-l border-[#3A5FC0]">
                                    Sub-type<br/>
                                    <span className="text-[9px] font-normal text-blue-200">(e.g. HMO / PPO)</span>
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-[#2149A0]">
                                    Adj. Claims Vol.<br/>
                                    <span className="text-[9px] font-normal text-blue-200">(CCCR &amp; G&amp;A)</span>
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-[#2149A0]">
                                    Adj. Claims Vol.<br/>
                                    <span className="text-[9px] font-normal text-blue-200">(Claims Ops)</span>
                                  </th>
                                  <th className="px-3 py-2.5 text-right text-[11px] font-semibold whitespace-nowrap bg-[#2149A0]">
                                    Unscaled<br/>
                                    <span className="text-[9px] font-normal text-blue-200">Potential Savings</span>
                                  </th>
                                  <th className="px-3 py-2.5 text-center text-[11px] font-semibold whitespace-nowrap bg-[#2149A0]">
                                    GL Status
                                  </th>
                                  <th className="px-3 py-2.5 text-left text-[11px] font-semibold whitespace-nowrap bg-[#2149A0] border-r border-[#3A5FC0]">
                                    Notes
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                {(() => {
                                  // Group rows by state key (ignoring subLabel) so states
                                  // with HMO/PPO splits show ONE raw row but multiple calc rows.
                                  const groups = [];
                                  const seen = new Map();
                                  const visibleRows = lobSec.rows.filter(r => {
                                    const q = getFmSearch(concept.id).trim().toLowerCase();
                                    const act = getFmActive(concept.id);
                                    const matchSearch = !q || r.state.toLowerCase().includes(q) || (r.subLabel || '').toLowerCase().includes(q) || r.gl.toLowerCase().includes(q) || (r.notes || '').toLowerCase().includes(q);
                                    const matchState = !act.state || r.state === act.state;
                                    const matchGl    = !act.gl    || r.gl    === act.gl;
                                    return matchSearch && matchState && matchGl;
                                  });
                                  visibleRows.forEach(r => {
                                    const key = r.isNational ? `nat-${r.notes}` : r.state;
                                    if (!seen.has(key)) {
                                      const g = { stateKey: key, rawRows: [], subRows: [], isNational: !!r.isNational };
                                      seen.set(key, g);
                                      groups.push(g);
                                    }
                                    const g = seen.get(key);
                                    if (r.subLabel) {
                                      g.subRows.push(r);          // split calc rows
                                    } else {
                                      g.rawRows.push(r);          // single raw row (also used for calc if no subLabel)
                                    }
                                  });

                                  let rowIdx = 0;
                                  return groups.map(g => {
                                    // Raw data: aggregate all rawRows for this state
                                    const raw = g.rawRows[0] ?? g.subRows[0]; // fallback to first sub if no raw
                                    const aggClaims    = g.rawRows.reduce((s, r) => s + r.claims, 0);
                                    const aggPaid      = g.rawRows.reduce((s, r) => s + r.paidAmount, 0);
                                    // Calc rows: subRows if split, else rawRows
                                    const calcRows = g.subRows.length > 0 ? g.subRows : g.rawRows;
                                    const calcCount = calcRows.length;
                                    const isNat = g.isNational;
                                    const stripe = rowIdx++ % 2 === 0;
                                    const rowBg = isNat ? 'bg-[#FFFDE7]' : (stripe ? 'bg-white' : 'bg-[#F8FAFF]');
                                    const rawDimmed = !isNat && raw.gl !== 'In Scope' && g.subRows.length === 0;

                                    return calcRows.map((cr, ci) => {
                                      const gl = GL_BADGE[cr.gl] ?? GL_BADGE['Not in Scope'];
                                      const calcDimmed = !isNat && cr.gl !== 'In Scope';
                                      const isFirstCalcRow = ci === 0;
                                      const stateDisplay = isNat ? raw.state : raw.state;
                                      const subDisplay = cr.subLabel ? `${cr.state} ${cr.subLabel}` : cr.state;

                                      return (
                                        <tr
                                          key={`${g.stateKey}-${ci}`}
                                          className={[
                                            rowBg,
                                            isNat ? 'border-t border-yellow-200' : 'border-b border-gray-100',
                                          ].join(' ')}
                                        >
                                          {/* State — raw section: only show on first calc sub-row, span the rest */}
                                          {isFirstCalcRow ? (
                                            <td
                                              className={`px-3 py-2 whitespace-nowrap text-center align-middle ${isNat ? 'text-[#7A5700] italic text-[11px]' : 'font-bold text-[#1A3673]'} ${rawDimmed ? 'opacity-60' : ''}`}
                                              rowSpan={calcCount}
                                            >
                                              {stateDisplay}
                                            </td>
                                          ) : null}
                                          {/* Raw cols — only on first sub-row, span all calc sub-rows */}
                                          {isFirstCalcRow ? (
                                            <>
                                              <td className={`px-3 py-2 text-right border-l border-gray-200 bg-gray-50 text-[#374151] font-medium align-middle ${rawDimmed ? 'opacity-60' : ''}`} rowSpan={calcCount}>
                                                {aggClaims === 0 ? '—' : aggClaims.toLocaleString()}
                                              </td>
                                              <td className={`px-3 py-2 text-right bg-gray-50 text-[#374151] font-medium align-middle ${rawDimmed ? 'opacity-60' : ''}`} rowSpan={calcCount}>
                                                {aggPaid === 0 ? '—' : fmtD(aggPaid)}
                                              </td>
                                              <td className={`px-3 py-2 text-right bg-gray-50 text-[#374151] font-medium align-middle ${rawDimmed ? 'opacity-60' : ''}`} rowSpan={calcCount}>
                                                {pct(cfg.initReduction)}
                                              </td>
                                              <td className={`px-3 py-2 text-right bg-gray-50 text-[#374151] font-medium align-middle ${rawDimmed ? 'opacity-60' : ''}`} rowSpan={calcCount}>
                                                {pct(cfg.rebillDiscount)}
                                              </td>
                                              <td className={`px-3 py-2 text-right bg-gray-50 text-[#374151] font-medium border-r border-gray-200 align-middle ${rawDimmed ? 'opacity-60' : ''}`} rowSpan={calcCount}>
                                                {pct(cfg.quantumData)}
                                              </td>
                                              {extraFields.map((f, i) => (
                                                <td key={i} className={`px-3 py-2 text-right bg-gray-50 text-[#374151] font-medium border-r border-gray-200 align-middle ${rawDimmed ? 'opacity-60' : ''}`} rowSpan={calcCount}>
                                                  {f.value || '—'}
                                                </td>
                                              ))}
                                            </>
                                          ) : null}
                                          {/* Calc cols — one row per sub-label */}
                                          {g.subRows.length > 0 ? (
                                            <td className={`px-3 py-2 text-left text-[11px] font-semibold text-[#2149A0] border-l border-[#C5D5F0] ${calcDimmed ? 'opacity-60' : ''}`}>
                                              {subDisplay}
                                            </td>
                                          ) : (
                                            <td className="px-3 py-2 border-l border-[#C5D5F0]" />
                                          )}
                                          <td className={`px-3 py-2 text-right text-[#1A3673] font-medium ${calcDimmed ? 'opacity-60' : ''}`}>
                                            {cr.adjClaimsInitial === 0 ? '—' : fmtN(cr.adjClaimsInitial)}
                                          </td>
                                          <td className={`px-3 py-2 text-right text-[#0D6EAA] font-medium ${calcDimmed ? 'opacity-60' : ''}`}>
                                            {cr.adjClaimsRebill === 0 ? '—' : fmtN(cr.adjClaimsRebill)}
                                          </td>
                                          <td className={`px-3 py-2 text-right font-semibold text-[#00BBBA] ${calcDimmed ? 'opacity-60' : ''}`}>
                                            {cr.savings === 0 ? '—' : fmtD(cr.savings)}
                                          </td>
                                          <td className={`px-3 py-2 text-center ${calcDimmed ? 'opacity-60' : ''}`}>
                                            <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium ${gl.cls}`}>
                                              {gl.icon}{cr.gl}
                                            </span>
                                          </td>
                                          <td className="px-3 py-2 text-[10px] text-[#374151] border-r border-[#C5D5F0] min-w-[180px]"
                                              style={{ color: isNat ? '#7A5700' : undefined }}>
                                            {cr.notes || '—'}
                                          </td>
                                        </tr>
                                      );
                                    });
                                  });
                                })()}
                              </tbody>
                              <tfoot>
                                {/* Grand total */}
                                <tr className="bg-[#1A3673] text-white font-bold border-t-2 border-[#0F2550]">
                                  <td className="px-3 py-2 text-xs">Grand Total</td>
                                  <td className="px-3 py-2 text-right border-l border-[#2861BB]">
                                    {lobSec.rows.reduce((s, r) => s + r.claims, 0).toLocaleString()}
                                  </td>
                                  <td className="px-3 py-2 text-right">
                                    {fmtD(lobSec.rows.reduce((s, r) => s + r.paidAmount, 0))}
                                  </td>
                                  <td className="px-3 py-2 text-right">{pct(cfg.initReduction)}</td>
                                  <td className="px-3 py-2 text-right">{pct(cfg.rebillDiscount)}</td>
                                  <td className="px-3 py-2 text-right border-r border-[#2861BB]">{pct(cfg.quantumData)}</td>
                                  {extraFields.map((f, i) => (
                                    <td key={i} className="px-3 py-2 text-right border-r border-[#2861BB]">{f.value || '—'}</td>
                                  ))}
                                  <td className="px-3 py-2 border-l border-[#3A5FC0]" />
                                  <td className="px-3 py-2 text-right">
                                    {fmtN(lobSec.rows.reduce((s, r) => s + r.adjClaimsInitial, 0))}
                                  </td>
                                  <td className="px-3 py-2 text-right">
                                    {fmtN(lobSec.rows.reduce((s, r) => s + r.adjClaimsRebill, 0))}
                                  </td>
                                  <td className="px-3 py-2 text-right">
                                    {fmtD(lobSec.rows.reduce((s, r) => s + r.savings, 0))}
                                  </td>
                                  <td className="px-3 py-2 text-[11px]" colSpan={2}>
                                    {inScopeRows.length} of {lobSec.rows.length} states in-scope
                                  </td>
                                </tr>

                              </tfoot>
                            </table>
                          </div>
                          );
                        })()}
                      </div>
                    </div>
                    );
                  })()}
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
