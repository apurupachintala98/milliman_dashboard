import { useState, useMemo } from 'react';
import { ChevronDown, ChevronRight, Download, Search } from 'lucide-react';
const SOURCE_PIVOT_DATA = [
  { lob: 'CSBD', market: 'CA HMO', claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'CA PPO', claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'CO',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'CT',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'FL',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'GA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'IN',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'KY',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'MD',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'ME',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'MO',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'NH',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'NV',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'NY',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'OH',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'TX',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'VA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'WA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'CSBD', market: 'WI',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'AZ',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'FL',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'GA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'IN',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'LA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'MD',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'MO',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'NC',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'NJ',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'NV',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'NY',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'OH',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'TN',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'TX',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'VA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'WA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'WI',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'WNY',    claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCD',  market: 'WV',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'CA',     claimsVol: 17,  adjInitial: 13.6,   adjRebill: 1.36,  savings: 8825.99,    greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'CO',     claimsVol: 1,   adjInitial: 0.8,    adjRebill: 0.08,  savings: 489.60,     greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'CT',     claimsVol: 2,   adjInitial: 1.6,    adjRebill: 0.16,  savings: 11.96,      greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'FL',     claimsVol: 249, adjInitial: 199.2,  adjRebill: 19.92, savings: 283078.96,  greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'GA',     claimsVol: 28,  adjInitial: 22.4,   adjRebill: 2.24,  savings: 52902.80,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'IN',     claimsVol: 60,  adjInitial: 48.0,   adjRebill: 4.80,  savings: 57805.39,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'IA',     claimsVol: 49,  adjInitial: 39.2,   adjRebill: 3.92,  savings: 75018.39,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'KY',     claimsVol: 80,  adjInitial: 64.0,   adjRebill: 6.40,  savings: 80980.57,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'LA',     claimsVol: 14,  adjInitial: 11.2,   adjRebill: 1.12,  savings: 454.20,     greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'ME',     claimsVol: 27,  adjInitial: 21.6,   adjRebill: 2.16,  savings: 36649.91,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'MO',     claimsVol: 54,  adjInitial: 43.2,   adjRebill: 4.32,  savings: 54589.76,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'NV',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'NH',     claimsVol: 4,   adjInitial: 3.2,    adjRebill: 0.32,  savings: 3655.60,    greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'NJ',     claimsVol: 19,  adjInitial: 15.2,   adjRebill: 1.52,  savings: 13246.83,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'NY',     claimsVol: 421, adjInitial: 336.8,  adjRebill: 33.68, savings: 144077.26,  greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'NC',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'OH',     claimsVol: 43,  adjInitial: 34.4,   adjRebill: 3.44,  savings: 65525.93,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'TN',     claimsVol: 284, adjInitial: 227.2,  adjRebill: 22.72, savings: 62759.87,   greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'TX',     claimsVol: 238, adjInitial: 190.4,  adjRebill: 19.04, savings: 135201.44,  greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'VA',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'WA',     claimsVol: 4,   adjInitial: 3.2,    adjRebill: 0.32,  savings: 1684.57,    greenlight: '', notes: '' },
  { lob: 'MCR',  market: 'WI',     claimsVol: 120, adjInitial: 96.0,   adjRebill: 9.60,  savings: 199219.79,  greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'CA',     claimsVol: 90,  adjInitial: 72.0,   adjRebill: 7.20,  savings: 32952.22,   greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'CT',     claimsVol: 2,   adjInitial: 1.6,    adjRebill: 0.16,  savings: 2347.32,    greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'GA',     claimsVol: 5,   adjInitial: 4.0,    adjRebill: 0.40,  savings: 6963.93,    greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'IN',     claimsVol: 1,   adjInitial: 0.8,    adjRebill: 0.08,  savings: 148.90,     greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'KY',     claimsVol: 1,   adjInitial: 0.8,    adjRebill: 0.08,  savings: 78.50,      greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'ME',     claimsVol: 9,   adjInitial: 7.2,    adjRebill: 0.72,  savings: 25911.03,   greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'MO',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'NH',     claimsVol: 9,   adjInitial: 7.2,    adjRebill: 0.72,  savings: 21848.65,   greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'NV',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'NY',     claimsVol: 12,  adjInitial: 9.6,    adjRebill: 0.96,  savings: 5168.29,    greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'OH',     claimsVol: 3,   adjInitial: 2.4,    adjRebill: 0.24,  savings: 4872.58,    greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'PA',     claimsVol: 3,   adjInitial: 2.4,    adjRebill: 0.24,  savings: 606.67,     greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'VA',     claimsVol: 1,   adjInitial: 0.8,    adjRebill: 0.08,  savings: 1902.90,    greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'WI',     claimsVol: 14,  adjInitial: 11.2,   adjRebill: 1.12,  savings: 19046.46,   greenlight: '', notes: '' },
  { lob: 'GRS',  market: 'National', claimsVol: 0, adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: 'National - In-Scope Markets' },
  { lob: 'MMP',  market: 'TX',     claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
  { lob: 'INN_CD', market: 'IN',   claimsVol: 0,   adjInitial: 0,      adjRebill: 0,     savings: 0,          greenlight: '', notes: '' },
];

const LOB_ORDER = ['MCR', 'GRS', 'MCD', 'CSBD', 'MMP', 'INN_CD'];
const LOB_LABELS = {
  MCR: 'Medicare (MCR)', GRS: 'Group Senior (GRS)', MCD: 'Medicaid (MCD)',
  CSBD: 'Commercial CSBD', MMP: 'Medicare-Medicaid Plan (MMP)', INN_CD: 'INN_CD',
};

const fmt  = (n) => n === 0 ? '—' : n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
const fmtD = (n) => n === 0 ? '—' : '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtF = (n) => n === 0 ? '—' : n.toFixed(2);

export default function SourcePivotTab({ coversheet: _coversheet }) {
  const [search, setSearch]           = useState('');
  const [filterLob, setFilterLob]     = useState([]);
  const [filterMarket] = useState([]);
  const [collapsed, setCollapsed]     = useState({});
  const [flatView, setFlatView]       = useState(false);

  const allLobs    = [...new Set(SOURCE_PIVOT_DATA.map(r => r.lob))];

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return SOURCE_PIVOT_DATA.filter(r => {
      if (filterLob.length    && !filterLob.includes(r.lob))       return false;
      if (filterMarket.length && !filterMarket.includes(r.market)) return false;
      if (q && !r.lob.toLowerCase().includes(q) && !r.market.toLowerCase().includes(q) && !r.notes.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [search, filterLob, filterMarket]);

  const grouped = useMemo(() => {
    const map = {};
    for (const r of filtered) {
      if (!map[r.lob]) map[r.lob] = [];
      map[r.lob].push(r);
    }
    return map;
  }, [filtered]);

  const grandTotals = useMemo(() => ({
    claimsVol:  filtered.reduce((s, r) => s + r.claimsVol, 0),
    adjInitial: filtered.reduce((s, r) => s + r.adjInitial, 0),
    adjRebill:  filtered.reduce((s, r) => s + r.adjRebill, 0),
    savings:    filtered.reduce((s, r) => s + r.savings, 0),
  }), [filtered]);

  const toggle = (lob) => setCollapsed(p => ({ ...p, [lob]: !p[lob] }));

  const exportCSV = () => {
    const hdr = ['LOB', 'Market', 'Claims Volume (No Disc.)', 'Adj. Claims Vol (Initial)', 'Adj. Claims Vol (Re-Bill)', 'Unscaled Potential Savings', 'Greenlighting Status', 'Notes'];
    const rows = filtered.map(r => [r.lob, r.market, r.claimsVol, r.adjInitial, r.adjRebill, r.savings, r.greenlight, r.notes].join(','));
    const blob = new Blob([[hdr.join(','), ...rows].join('\n')], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = Object.assign(document.createElement('a'), { href: url, download: 'source-pivot-coc.csv' });
    a.click(); URL.revokeObjectURL(url);
  };

  const ColHdr = ({ children, right }) => (
    <th className={`px-3 py-2 text-white text-xs font-semibold whitespace-nowrap ${right ? 'text-right' : 'text-left'}`}>{children}</th>
  );

  const renderTableBody = () => {
    if (flatView) {
      return (
        <tbody>
          {filtered.map((r, i) => (
            <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'}>
              <td className="px-3 py-1.5 text-xs">
                <span className="inline-block px-2 py-0.5 rounded-full text-white text-[10px] font-semibold" style={{ background: LOB_COLORS[r.lob] ?? '#6b7280' }}>{r.lob}</span>
              </td>
              <td className="px-3 py-1.5 text-xs text-gray-700 font-medium">{r.market || '—'}</td>
              <td className="px-3 py-1.5 text-xs text-right text-gray-700">{fmt(r.claimsVol)}</td>
              <td className="px-3 py-1.5 text-xs text-right text-gray-700">{fmtF(r.adjInitial)}</td>
              <td className="px-3 py-1.5 text-xs text-right text-gray-700">{fmtF(r.adjRebill)}</td>
              <td className="px-3 py-1.5 text-xs text-right font-semibold" style={{ color: r.savings > 0 ? '#059669' : '#9ca3af' }}>{fmtD(r.savings)}</td>
              <td className="px-3 py-1.5 text-xs text-gray-500">{r.greenlight || '—'}</td>
              <td className="px-3 py-1.5 text-xs text-gray-500 max-w-[200px] truncate" title={r.notes}>{r.notes || '—'}</td>
            </tr>
          ))}
          <GrandTotalRow />
        </tbody>
      );
    }

    const lobKeys = LOB_ORDER.filter(l => grouped[l]);
    return (
      <tbody>
        {lobKeys.map(lob => {
          const rows      = grouped[lob];
          const isCollapsed = collapsed[lob];
          const subtotals = {
            claimsVol:  rows.reduce((s, r) => s + r.claimsVol, 0),
            adjInitial: rows.reduce((s, r) => s + r.adjInitial, 0),
            adjRebill:  rows.reduce((s, r) => s + r.adjRebill, 0),
            savings:    rows.reduce((s, r) => s + r.savings, 0),
          };
          return (
            <>
              {/* LOB group header */}
              <tr key={`grp-${lob}`} className="cursor-pointer select-none" style={{ background: '#1A3673' }} onClick={() => toggle(lob)}>
                <td colSpan={2} className="px-3 py-2 text-white text-xs font-bold">
                  <span className="flex items-center gap-1.5">
                    {isCollapsed ? <ChevronRight size={13} /> : <ChevronDown size={13} />}
                    <span className="inline-block px-2 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-bold mr-1">{lob}</span>
                    {LOB_LABELS[lob] ?? lob}
                    <span className="ml-2 text-white/60 font-normal text-[10px]">({rows.length} markets)</span>
                  </span>
                </td>
                <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmt(subtotals.claimsVol)}</td>
                <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmtF(subtotals.adjInitial)}</td>
                <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmtF(subtotals.adjRebill)}</td>
                <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmtD(subtotals.savings)}</td>
                <td className="px-3 py-2 text-white text-xs" />
                <td className="px-3 py-2 text-white text-xs" />
              </tr>
              {/* Market rows */}
              {!isCollapsed && rows.map((r, i) => (
                <tr key={`${lob}-${i}`} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'}>
                  <td className="px-3 py-1.5 text-xs text-gray-400 pl-8">{lob}</td>
                  <td className="px-3 py-1.5 text-xs text-gray-700 font-medium">{r.market || '—'}</td>
                  <td className="px-3 py-1.5 text-xs text-right text-gray-700">{fmt(r.claimsVol)}</td>
                  <td className="px-3 py-1.5 text-xs text-right text-gray-700">{fmtF(r.adjInitial)}</td>
                  <td className="px-3 py-1.5 text-xs text-right text-gray-700">{fmtF(r.adjRebill)}</td>
                  <td className="px-3 py-1.5 text-xs text-right font-semibold" style={{ color: r.savings > 0 ? '#059669' : '#9ca3af' }}>{fmtD(r.savings)}</td>
                  <td className="px-3 py-1.5 text-xs text-gray-500">{r.greenlight || '—'}</td>
                  <td className="px-3 py-1.5 text-xs text-gray-500 max-w-[200px] truncate" title={r.notes}>{r.notes || '—'}</td>
                </tr>
              ))}
            </>
          );
        })}
        <GrandTotalRow />
      </tbody>
    );
  };

  const GrandTotalRow = () => (
    <tr style={{ background: '#00BBBA' }}>
      <td colSpan={2} className="px-3 py-2 text-white text-xs font-bold">Grand Total</td>
      <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmt(grandTotals.claimsVol)}</td>
      <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmtF(grandTotals.adjInitial)}</td>
      <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmtF(grandTotals.adjRebill)}</td>
      <td className="px-3 py-2 text-right text-white text-xs font-bold">{fmtD(grandTotals.savings)}</td>
      <td className="px-3 py-2 text-white text-xs" />
      <td className="px-3 py-2 text-white text-xs" />
    </tr>
  );

  return (
    <div className="space-y-4">
      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Markets',              value: filtered.length.toString(),   color: 'text-[#1A3673]', bg: 'bg-[#E3F4FD]' },
          { label: 'Claims Volume',              value: fmt(grandTotals.claimsVol),   color: 'text-[#2861BB]', bg: 'bg-blue-50' },
          { label: 'Adj. Claims (Re-Bill)',       value: fmtF(grandTotals.adjRebill),  color: 'text-[#E3725F]', bg: 'bg-red-50' },
          { label: 'Unscaled Potential Savings', value: fmtD(grandTotals.savings),    color: 'text-[#00BBBA]', bg: 'bg-teal-50' },
        ].map(kpi => (
          <div key={kpi.label} className={`${kpi.bg} rounded-lg p-3 text-center`}>
            <p className={`text-xl font-bold ${kpi.color}`}>{kpi.value}</p>
            <p className="text-[10px] text-gray-500 mt-0.5 leading-snug">{kpi.label}</p>
          </div>
        ))}
      </div>

      {/* Main table card */}
      <div className="card overflow-visible">
        {/* Top bar */}
        <div style={{ padding: '10px 14px', borderBottom: '1px solid #e5e7eb', background: '#fafafa', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: '#1A3673', letterSpacing: '0.04em', textTransform: 'uppercase' }}>Source Pivot — CoC</span>
          <span style={{ fontSize: 10, color: '#6b7280' }}>CIN0024932 · Jan 2026 – Mar 2026</span>

          {/* Search */}
          <div className="relative" style={{ marginLeft: 8 }}>
            <Search size={12} style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af', pointerEvents: 'none' }} />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search LOB, market, notes…"
              style={{ paddingLeft: 26, paddingRight: search ? 26 : 10, paddingTop: 5, paddingBottom: 5, fontSize: 11, border: '1px solid #d1d5db', borderRadius: 8, outline: 'none', width: 190, background: '#fff', color: '#374151' }} />
            {search && <button onClick={() => setSearch('')} style={{ position: 'absolute', right: 7, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 14 }}>×</button>}
          </div>

          {/* LOB filter */}
          <div className="flex items-center gap-1 flex-wrap">
            {allLobs.map(l => (
              <button key={l} onClick={() => setFilterLob(prev => prev.includes(l) ? prev.filter(x => x !== l) : [...prev, l])}
                className="text-[10px] px-2 py-0.5 rounded-full border font-semibold transition"
                style={filterLob.includes(l) ? { background: '#1A3673', color: '#fff', borderColor: '#1A3673' } : { background: '#f3f4f6', color: '#6b7280', borderColor: '#e5e7eb' }}>
                {l}
              </button>
            ))}
            {filterLob.length > 0 && <button onClick={() => setFilterLob([])} className="text-[10px] text-red-400 underline ml-1">clear</button>}
          </div>

          {/* Flat / Grouped toggle */}
          <div className="ml-auto flex items-center gap-2">
            <div className="flex rounded-lg border border-gray-200 overflow-hidden text-[10px]">
              <button onClick={() => setFlatView(false)} className="px-3 py-1 font-semibold transition" style={!flatView ? { background: '#1A3673', color: '#fff' } : { background: '#fff', color: '#6b7280' }}>Grouped</button>
              <button onClick={() => setFlatView(true)}  className="px-3 py-1 font-semibold transition" style={flatView  ? { background: '#1A3673', color: '#fff' } : { background: '#fff', color: '#6b7280' }}>Flat</button>
            </div>
            <button onClick={exportCSV} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 10, fontWeight: 600, background: '#f3f4f6', color: '#374151', border: '1px solid #e5e7eb', borderRadius: 999, padding: '4px 10px', cursor: 'pointer' }}>
              <Download size={10} /> Export CSV
            </button>
          </div>
        </div>

        {/* Table */}
        <div style={{ overflowX: 'auto', maxHeight: 540 }}>
          <table className="w-full text-xs" style={{ borderCollapse: 'collapse', minWidth: 700 }}>
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ background: '#1A3673' }}>
                <ColHdr>LOB</ColHdr>
                <ColHdr>Market / State</ColHdr>
                <ColHdr right>Claims Volume (No Disc.)</ColHdr>
                <ColHdr right>Adj. Claims Vol (Initial)</ColHdr>
                <ColHdr right>Adj. Claims Vol (Re-Bill)</ColHdr>
                <ColHdr right>Unscaled Potential Savings</ColHdr>
                <ColHdr>Greenlighting Status</ColHdr>
                <ColHdr>Notes</ColHdr>
              </tr>
            </thead>
            {renderTableBody()}
          </table>
          {filtered.length === 0 && (
            <div className="py-16 text-center text-gray-400 text-sm">No data matches your filters.</div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '8px 14px', borderTop: '1px solid #e5e7eb', background: '#fafafa', display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 10, color: '#9ca3af' }}>Showing {filtered.length} of {SOURCE_PIVOT_DATA.length} rows</span>
          <span style={{ fontSize: 10, color: '#9ca3af' }}>Source: Source Pivots-CoC · MVA Financial Impacts CIN0024932 Jan26-Mar26.xlsx</span>
        </div>
      </div>
    </div>
  );
}

const LOB_COLORS = {
  MCR: '#1A3673', GRS: '#00BBBA', MCD: '#2861BB', CSBD: '#E3725F', MMP: '#6A97DF', INN_CD: '#44B8F3',
};
