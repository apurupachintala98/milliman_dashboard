import { useState, useCallback } from 'react';
import { ChevronDown, Eye } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function TabFlagsToggle({ coversheet, coversheetConfig, onConfigChange }) {
  const { showToast } = useToast();
  const { activeRole } = useAuth();
  const [saving, setSaving] = useState(null);
  const [open, setOpen] = useState(false);
  const isReadOnly = activeRole === 'Read-Only';

  const flags = coversheetConfig?.flags ?? {};
  const scalingOn = flags.scaling_applicable_flag?.value?.toUpperCase() === 'YES';
  const costOn    = flags.cost_plan_applicable_flag?.value?.toUpperCase() === 'YES';

  const handleToggle = useCallback(async (flagKey, currentValue) => {
    if (!coversheetConfig || !coversheet?.cin || coversheet.cin === '—') return;
    const newValue = currentValue ? 'NO' : 'YES';
    const updatedConfig = {
      ...coversheetConfig,
      flags: {
        ...coversheetConfig.flags,
        [flagKey]: { ...coversheetConfig.flags[flagKey], value: newValue },
      },
    };
    onConfigChange(updatedConfig);
    setSaving(flagKey);
    try {
      const { configApi } = await import('../config/apiConfig');
      await configApi.updateConfig(coversheet.cin, updatedConfig);
      showToast(`${flagKey === 'scaling_applicable_flag' ? 'Membership Scaling' : 'Costs'} tab ${newValue === 'YES' ? 'enabled' : 'disabled'}`, 'success');
    } catch (err) {
      onConfigChange(coversheetConfig);
      showToast(`Failed to update flag: ${err.message}`, 'error');
    } finally {
      setSaving(null);
    }
  }, [coversheetConfig, coversheet, onConfigChange, showToast]);

  if (!coversheetConfig) return null;

  const Toggle = ({ label, flagKey, enabled }) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <p style={{ fontSize: 12, fontWeight: 600, color: '#374151', margin: 0, whiteSpace: 'nowrap' }}>{label}</p>
      <button
        onClick={() => handleToggle(flagKey, enabled)}
        disabled={saving === flagKey || isReadOnly}
        title={isReadOnly ? 'Read-Only role cannot change tab visibility' : enabled ? 'Click to hide tab' : 'Click to show tab'}
        style={{
          width: 36, height: 20, borderRadius: 999, border: 'none',
          cursor: (saving === flagKey || isReadOnly) ? 'not-allowed' : 'pointer',
          background: enabled ? '#1A3673' : '#d1d5db',
          position: 'relative', transition: 'background 0.2s', flexShrink: 0,
          opacity: (saving === flagKey || isReadOnly) ? 0.4 : 1,
        }}
      >
        <span style={{
          position: 'absolute', top: 2, left: enabled ? 18 : 2,
          width: 16, height: 16, borderRadius: '50%', background: '#fff',
          transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }} />
      </button>
    </div>
  );

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(o => !o)}
        title="Tab Visibility"
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          fontSize: 12, fontWeight: 600, color: '#1A3673',
          background: open ? '#EEF3FB' : 'transparent',
          border: '1px solid', borderColor: open ? '#1A3673' : '#d1d5db',
          borderRadius: 6, padding: '4px 10px', cursor: 'pointer',
          transition: 'all 0.15s',
        }}
      >
        <Eye size={13} />
        Tab Visibility
        <ChevronDown size={11} style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 6px)', right: 0,
          background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8,
          boxShadow: '0 8px 24px rgba(0,0,0,0.12)', padding: '12px 16px',
          zIndex: 50, minWidth: 240,
        }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', margin: '0 0 10px' }}>Tab Visibility</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Toggle label="Membership Scaling" flagKey="scaling_applicable_flag" enabled={scalingOn} />
            <Toggle label="Costs"              flagKey="cost_plan_applicable_flag" enabled={costOn} />
          </div>
          {isReadOnly && (
            <p style={{ fontSize: 10, color: '#9ca3af', marginTop: 10, marginBottom: 0 }}>Read-Only users cannot change tab visibility.</p>
          )}
        </div>
      )}
    </div>
  );
}
