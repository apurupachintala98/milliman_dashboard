import { useState, useRef, useEffect } from 'react';
import { ChevronDown, X, Search } from 'lucide-react';

/**
 * ColFilter — inline column-header filter widget.
 * Renders as: [Label] [chevron icon]
 * Clicking opens a floating panel with:
 *   - A search bar to filter the options list
 *   - Multi-select checkboxes (new, via values + onChangeMulti props)
 *   - OR legacy single-select (value + onChange props)
 *   - OR free-text input (type="text")
 *
 * Props:
 *   label          — column header text
 *   value          — current single-filter value ('' = no filter) [single-select mode]
 *   onChange       — setter for single-select mode
 *   values         — selected values array [multi-select mode]
 *   onChangeMulti  — setter for multi-select mode
 *   options        — list of choices when type="select"
 *   type           — "text" | "select"  default: "select"
 *   align          — "left" | "right"   default: "left"
 *   dark           — true = white label text (navy bg)  default: true
 */
export function ColFilter({
  label, value = '', onChange, values, onChangeMulti,
  options, type = 'select', align = 'left', dark = true,
}) {
  const [open, setOpen]     = useState(false);
  const [search, setSearch] = useState('');
  const ref                 = useRef(null);
  const searchRef           = useRef(null);

  const isMulti  = values !== undefined && onChangeMulti !== undefined;
  const active   = isMulti ? (values.length > 0) : (value !== '');

  useEffect(() => {
    if (!open) { setSearch(''); return; }
    setTimeout(() => searchRef.current?.focus(), 0);
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [open]);

  const filteredOpts = (options ?? []).filter(o =>
    search.trim() === '' || o.toLowerCase().includes(search.trim().toLowerCase())
  );

  const toggleMulti = (opt) => {
    if (!onChangeMulti || !values) return;
    onChangeMulti(values.includes(opt) ? values.filter(v => v !== opt) : [...values, opt]);
  };

  const labelCls = dark
    ? 'text-white font-semibold text-xs whitespace-nowrap'
    : 'text-gray-700 font-semibold text-xs whitespace-nowrap';

  const activeLabel = isMulti && values.length > 0
    ? `${values.length} selected`
    : active ? value : undefined;

  return (
    <div ref={ref} className="relative inline-flex items-center gap-0.5">
      <span className={labelCls}>{label}</span>
      <button
        onClick={e => { e.stopPropagation(); setOpen(o => !o); }}
        className={`ml-0.5 relative flex items-center justify-center rounded transition ${active ? 'text-[#00BBBA]' : dark ? 'text-white/50 hover:text-white' : 'text-gray-400 hover:text-gray-700'}`}
        title={active ? `Filtered: ${activeLabel}` : 'Filter'}
      >
        <ChevronDown size={11} />
        {active && <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-[#00BBBA]" />}
      </button>

      {open && (
        <div
          onClick={e => e.stopPropagation()}
          className="absolute top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-xl z-50 overflow-hidden"
          style={{ minWidth: 200, ...(align === 'right' ? { right: 0 } : { left: 0 }) }}
        >
          {/* Header */}
          <div className="px-3 py-2 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{label}</span>
            {active && (
              <button
                onClick={() => {
                  if (isMulti) onChangeMulti([]);
                  else onChange?.('');
                  setOpen(false);
                }}
                className="text-[10px] text-[#E3725F] hover:underline flex items-center gap-0.5">
                <X size={8} /> Clear
              </button>
            )}
          </div>

          {type === 'text' ? (
            <div className="p-2">
              <input
                ref={searchRef}
                autoFocus
                type="text"
                value={value}
                onChange={e => onChange?.(e.target.value)}
                placeholder={`Search ${label}…`}
                className="w-full px-2 py-1 text-xs border border-gray-200 rounded focus:border-[#1A3673] focus:outline-none text-gray-700"
              />
              {value && (
                <button onClick={() => { onChange?.(''); setOpen(false); }}
                  className="mt-1 text-[10px] text-gray-400 hover:text-[#E3725F] flex items-center gap-0.5">
                  <X size={8} /> Clear
                </button>
              )}
            </div>
          ) : (
            <>
              {/* Search bar */}
              {(options ?? []).length > 4 && (
                <div className="px-2 pt-2 pb-1 border-b border-gray-100">
                  <div className="flex items-center gap-1.5 px-2 py-1 border border-gray-200 rounded-md bg-white">
                    <Search size={10} className="text-gray-400 flex-shrink-0" />
                    <input
                      ref={searchRef}
                      type="text"
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      placeholder={`Search…`}
                      className="flex-1 text-xs border-none outline-none text-gray-700 bg-transparent"
                    />
                    {search && (
                      <button onClick={() => setSearch('')} className="text-gray-400 hover:text-gray-600">
                        <X size={9} />
                      </button>
                    )}
                  </div>
                </div>
              )}

              <div className="max-h-52 overflow-y-auto py-1">
                {isMulti ? (
                  <>
                    {/* All / Clear All row */}
                    <button
                      onClick={() => onChangeMulti(values.length === options.length ? [] : [...(options ?? [])])}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-gray-50 transition ${values.length === 0 ? 'text-[#1A3673] font-semibold' : 'text-gray-500'}`}>
                      <span className={`w-3.5 h-3.5 rounded flex-shrink-0 border flex items-center justify-center transition ${values.length === (options ?? []).length ? 'bg-[#1A3673] border-[#1A3673]' : 'border-gray-300'}`}>
                        {values.length === (options ?? []).length && <span className="text-white text-[8px] font-bold">✓</span>}
                      </span>
                      All
                    </button>
                    {filteredOpts.length === 0 && (
                      <div className="px-3 py-2 text-xs text-gray-400 text-center">No matches</div>
                    )}
                    {filteredOpts.map(opt => {
                      const checked = values.includes(opt);
                      return (
                        <button key={opt}
                          onClick={() => toggleMulti(opt)}
                          className={`w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-gray-50 transition ${checked ? 'text-[#1A3673] font-semibold bg-[#E3F4FD]/50' : 'text-gray-700'}`}>
                          <span className={`w-3.5 h-3.5 rounded flex-shrink-0 border flex items-center justify-center transition ${checked ? 'bg-[#1A3673] border-[#1A3673]' : 'border-gray-300'}`}>
                            {checked && <span className="text-white text-[8px] font-bold">✓</span>}
                          </span>
                          {opt}
                        </button>
                      );
                    })}
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => { onChange?.(''); setOpen(false); }}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-gray-50 transition ${!value ? 'text-[#1A3673] font-semibold' : 'text-gray-500'}`}>
                      All {!value && <span className="text-[#00BBBA]">✓</span>}
                    </button>
                    {filteredOpts.length === 0 && (
                      <div className="px-3 py-2 text-xs text-gray-400 text-center">No matches</div>
                    )}
                    {filteredOpts.map(opt => (
                      <button key={opt}
                        onClick={() => { onChange?.(opt); setOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-gray-50 transition ${value === opt ? 'text-[#1A3673] font-semibold bg-[#E3F4FD]/60' : 'text-gray-700'}`}>
                        {opt} {value === opt && <span className="text-[#00BBBA]">✓</span>}
                      </button>
                    ))}
                  </>
                )}
              </div>

              {/* Footer: show selected count for multi */}
              {isMulti && values.length > 0 && (
                <div className="px-3 py-1.5 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
                  <span className="text-[10px] text-[#1A3673] font-semibold">{values.length} selected</span>
                  <button onClick={() => onChangeMulti([])} className="text-[10px] text-[#E3725F] hover:underline flex items-center gap-0.5">
                    <X size={8} /> Clear All
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
