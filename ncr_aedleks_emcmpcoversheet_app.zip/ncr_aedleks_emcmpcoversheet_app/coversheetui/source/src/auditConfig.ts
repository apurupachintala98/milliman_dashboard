import type { AuditChangeType } from './types';

export const CHANGE_TYPES: AuditChangeType[] = ['Field Update', 'Status Change', 'Added', 'Removed', 'Upload', 'Workflow'];

export const SOURCE_COLOR: Record<string, string> = {
  'Overview':           'bg-[#E3F4FD] text-[#1A3673]',
  'Coversheet':         'bg-[#E1EDFF] text-[#2861BB]',
  'Membership Scaling': 'bg-[#D9F5F5] text-[#007F7E]',
  'Model':              'bg-purple-50 text-purple-700',
  'Costs':              'bg-amber-50 text-amber-700',
  'Data':               'bg-sky-50 text-sky-700',
  'Upload Document':    'bg-sky-50 text-sky-700',
  'ServiceNow':         'bg-indigo-50 text-indigo-700',
  'System':             'bg-gray-100 text-gray-600',
};

export const sourceColor = (s: string) => SOURCE_COLOR[s] ?? 'bg-gray-100 text-gray-600';

export const CHANGE_DOT: Record<AuditChangeType, string> = {
  'Field Update':  'bg-[#2861BB]',
  'Status Change': 'bg-amber-400',
  'Added':         'bg-[#00BBBA]',
  'Removed':       'bg-[#E3725F]',
  'Upload':        'bg-purple-500',
  'Workflow':      'bg-gray-400',
};

export const isEmptyValue = (v?: string) => !v || v === '—';
