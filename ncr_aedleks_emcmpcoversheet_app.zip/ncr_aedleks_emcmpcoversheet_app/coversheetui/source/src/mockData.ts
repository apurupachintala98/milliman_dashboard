import type { User, Coversheet, AuditEntry, Notification, ScalingFactor, FinancialModelOutput, CostLineItem } from './types';

export const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Sarah Johnson', email: 'sarah.johnson@elevancehealth.com', employeeId: 'AH40101', roles: ['Demand Manager'], cinAccess: ['ALL'], avatar: 'SJ' },
  { id: 'u2', name: 'Michael Chen', email: 'michael.chen@elevancehealth.com', employeeId: 'AH40102', roles: ['Financial Analyst'], cinAccess: ['CIN0013697', 'CIN0013698', 'CIN0013700'], avatar: 'MC' },
  { id: 'u3', name: 'Patricia Williams', email: 'patricia.williams@elevancehealth.com', employeeId: 'AH40103', roles: ['Governance'], cinAccess: ['ALL'], avatar: 'PW' },
  { id: 'u4', name: 'David Martinez', email: 'david.martinez@elevancehealth.com', employeeId: 'AH40104', roles: ['Read-Only'], cinAccess: ['CIN0013697', 'CIN0013698'], avatar: 'DM' },
  { id: 'u5', name: 'Lisa Thompson', email: 'lisa.thompson@elevancehealth.com', employeeId: 'AH40105', roles: ['Read-Only'], cinAccess: ['CIN0013698', 'CIN0013700'], avatar: 'LT' },
  { id: 'u6', name: 'Robert Kim', email: 'robert.kim@elevancehealth.com', employeeId: 'AH40106', roles: ['Admin'], cinAccess: ['ALL'], avatar: 'RK' },
  { id: 'u7', name: 'Amanda Foster', email: 'amanda.foster@elevancehealth.com', employeeId: 'AF40130', roles: ['Financial Analyst', 'Governance'], cinAccess: ['ALL'], avatar: 'AF' },
];

export const PORTFOLIO_GROUPS: Record<string, string[]> = {
  'Medical Management': ['PI – Medical Edits', 'Utilization Management', 'Case Management', 'Care Management'],
  'Pharmacy': ['Rx Cost Management', 'Specialty Drug Mgmt'],
  'Network': ['Network Optimization', 'Value-Based Care', 'Provider Contracting'],
  'Quality': ['HEDIS Improvement', 'Stars Program', 'Clinical Quality'],
};

export const MOCK_COVERSHEETS: Coversheet[] = [
  { id: 'cs21', cin: 'CIN0013717', snowCardId: 'SNOW-89516', name: 'Preventive Care Gap Closing FY2023',     type: 'Closing',   portfolioGroup: 'Quality',             portfolio: 'HEDIS Improvement',        status: 'Approved',    createdDate: '2023-09-20', lastModified: '2024-01-08', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  {
    id: 'cs6', cin: 'CIN0013702', snowCardId: 'SNOW-76211', name: 'Case Management Screening 2023',
    type: 'Screening', portfolioGroup: 'Medical Management', portfolio: 'Case Management',
    status: 'Inactive', createdDate: '2023-09-15', lastModified: '2023-11-30',
    createdBy: 'Amanda Foster', demandManager: 'Amanda Foster', financialAnalyst: 'Michael Chen',
    backupDM: 'Patricia Williams', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  { id: 'cs11', cin: 'CIN0013707', snowCardId: 'SNOW-88506', name: 'Care Management Closing FY2023',         type: 'Closing',   portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'Approved',    createdDate: '2023-09-05', lastModified: '2024-01-02', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Michael Chen',      backupDM: 'Sarah Johnson',      backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs31', cin: 'CIN0013703', snowCardId: 'SNOW-91101', name: 'Clinical Quality Closing FY2023', type: 'Closing', portfolioGroup: 'Quality', portfolio: 'Clinical Quality', status: 'Approved', createdDate: '2023-10-12', lastModified: '2024-01-18', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson', backupDM: 'Michael Chen', backupFA: 'Amanda Foster', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  {
    id: 'cs2c', cin: 'CIN0013698', snowCardId: 'SNOW-87430', name: 'Rx Cost Mgmt MVA Nov 2023',
    type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Inactive', createdDate: '2023-10-05', lastModified: '2023-11-01',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: false, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs9', cin: 'CIN0013700', snowCardId: 'SNOW-87700', name: 'HEDIS Improvement Screening 2023',
    type: 'Screening', portfolioGroup: 'Quality', portfolio: 'HEDIS Improvement',
    status: 'Approved', createdDate: '2023-10-01', lastModified: '2023-11-15',
    createdBy: 'Michael Chen', demandManager: 'Amanda Foster', financialAnalyst: 'Michael Chen',
    backupDM: 'Sarah Johnson', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs5c', cin: 'CIN0013701', snowCardId: 'SNOW-87812', name: 'Utilization Management MVA Dec 2023',
    type: 'MVA', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'Approved', createdDate: '2023-11-20', lastModified: '2023-12-10',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: false, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs2b', cin: 'CIN0013698', snowCardId: 'SNOW-87462', name: 'Rx Cost Mgmt MVA Dec 2023',
    type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Approved', createdDate: '2023-11-10', lastModified: '2023-12-01',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  { id: 'cs18', cin: 'CIN0013714', snowCardId: 'SNOW-89213', name: 'Diabetes Management Closing FY2023',     type: 'Closing',   portfolioGroup: 'Quality',             portfolio: 'Clinical Quality',         status: 'Approved',    createdDate: '2023-11-01', lastModified: '2024-01-15', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs29', cin: 'CIN0013725', snowCardId: 'SNOW-90324', name: 'Outpatient Cost Control MVA Apr 2024',   type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'PI – Medical Edits',       status: 'Draft',       createdDate: '2024-03-20', lastModified: '2024-03-20', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs28', cin: 'CIN0013724', snowCardId: 'SNOW-90223', name: 'Specialty Pharmacy Screening Q2 2024',   type: 'Screening', portfolioGroup: 'Pharmacy',            portfolio: 'Specialty Drug Mgmt',      status: 'In Review',   createdDate: '2024-03-15', lastModified: '2024-03-22', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs26', cin: 'CIN0013722', snowCardId: 'SNOW-90021', name: 'Long-Term Care MVA Q2 2024',             type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'In Progress', createdDate: '2024-03-12', lastModified: '2024-03-18', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs25', cin: 'CIN0013721', snowCardId: 'SNOW-89920', name: 'Prior Authorization Screening 2024',     type: 'Screening', portfolioGroup: 'Medical Management',  portfolio: 'Utilization Management',   status: 'Draft',       createdDate: '2024-03-08', lastModified: '2024-03-08', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs23', cin: 'CIN0013719', snowCardId: 'SNOW-89718', name: 'Mail Order Pharmacy MVA Apr 2024',       type: 'MVA',       portfolioGroup: 'Pharmacy',            portfolio: 'Specialty Drug Mgmt',      status: 'In Review',   createdDate: '2024-03-05', lastModified: '2024-03-10', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs24', cin: 'CIN0013720', snowCardId: 'SNOW-89819', name: 'ER Diversion Closing FY2023',            type: 'Closing',   portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'Inactive',    createdDate: '2023-07-10', lastModified: '2023-11-30', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  {
    id: 'cs5', cin: 'CIN0013701', snowCardId: 'SNOW-87890', name: 'Utilization Management MVA Feb 2024',
    type: 'MVA', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'In Progress', createdDate: '2024-01-30', lastModified: '2024-02-02',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: true, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp7', number: 'BP-2024-005-A', fiscalPeriod: 'FY2024', market: 'New York', lob: 'Commercial', mbu: 'MBU-NY-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'UM Savings NY Commercial', currency: 'USD' },
      { id: 'bp8', number: 'BP-2024-005-B', fiscalPeriod: 'FY2024', market: 'New Jersey', lob: 'Medicaid', mbu: 'MBU-NJ-MCD', sbu: 'SBU-MCD', metric: 'Savings', metricType: 'COC-FI', metricFrequency: 'Monthly', description: 'UM Medicaid NJ', currency: 'USD' },
    ],
    costPlans: [
      { id: 'cp4', number: 'CP-2024-005-A', description: 'Clinical Staff FTE x3', costType: 'FTE Request', metric: 'Cost', metricType: 'Ongoing', metricFrequency: 'Monthly' },
    ],
  },
  { id: 'cs17', cin: 'CIN0013713', snowCardId: 'SNOW-89112', name: 'Behavioral Health MVA Q1 2024',          type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'Utilization Management',   status: 'In Progress', createdDate: '2024-01-28', lastModified: '2024-02-15', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Amanda Foster',      backupFA: 'Michael Chen',   hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs12', cin: 'CIN0013708', snowCardId: 'SNOW-88607', name: 'PI-Coding Accuracy MVA Q1 2024',         type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'PI – Medical Edits',       status: 'In Progress', createdDate: '2024-01-25', lastModified: '2024-02-08', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',  backupFA: 'Patricia Williams',  hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  {
    id: 'cs3', cin: 'CIN0013699', snowCardId: 'SNOW-87612', name: 'Network Optimization Screening 2024',
    type: 'Screening', portfolioGroup: 'Network', portfolio: 'Network Optimization',
    status: 'Draft', createdDate: '2024-01-22', lastModified: '2024-01-22',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: false, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp5', number: 'BP-2024-003-A', fiscalPeriod: 'FY2024', market: 'Georgia', lob: 'Commercial', mbu: 'MBU-GA-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Quarterly', description: 'Network Savings Georgia', currency: 'USD' },
    ],
    costPlans: [
      { id: 'cp3', number: 'CP-2024-003-A', description: 'Analytics Platform License', costType: 'IT Expense', metric: 'Cost', metricType: 'Ongoing', metricFrequency: 'Annual' },
    ],
  },
  { id: 'cs32', cin: 'CIN0013704', snowCardId: 'SNOW-91202', name: 'HEDIS Screening Q1 2024', type: 'Screening', portfolioGroup: 'Quality', portfolio: 'HEDIS Improvement', status: 'In Progress', createdDate: '2024-01-18', lastModified: '2024-02-01', createdBy: 'Michael Chen', demandManager: 'Michael Chen', financialAnalyst: 'Amanda Foster', backupDM: 'Sarah Johnson', backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  {
    id: 'cs1', cin: 'CIN0013697', snowCardId: 'SNOW-87423', name: 'PI-Medical Edits Q1 Screening 2024',
    type: 'Screening', portfolioGroup: 'Medical Management', portfolio: 'PI – Medical Edits',
    status: 'In Review', createdDate: '2024-01-15', lastModified: '2024-01-28',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp1', number: 'BP-2024-001-A', fiscalPeriod: 'FY2024', market: 'Ohio', lob: 'Commercial', mbu: 'MBU-OH-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'Commercial HMO Ohio Savings', currency: 'USD' },
      { id: 'bp2', number: 'BP-2024-001-B', fiscalPeriod: 'FY2024', market: 'Indiana', lob: 'Medicare', mbu: 'MBU-IN-MED', sbu: 'SBU-MED', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'Medicare Advantage Indiana Savings', currency: 'USD' },
      { id: 'bp3', number: 'BP-2024-001-C', fiscalPeriod: 'FY2024', market: 'Virginia', lob: 'Medicaid', mbu: 'MBU-VA-MCD', sbu: 'SBU-MCD', metric: 'Savings', metricType: 'COC-FI', metricFrequency: 'Monthly', description: 'Medicaid Virginia Savings', currency: 'USD' },
    ],
    costPlans: [
      { id: 'cp1', number: 'CP-2024-001-A', description: 'IT Infrastructure Setup', costType: 'IT Expense', metric: 'Cost', metricType: 'Implementation', metricFrequency: 'One-time' },
      { id: 'cp2', number: 'CP-2024-001-B', description: 'Project Manager FTE', costType: 'FTE Request', metric: 'Cost', metricType: 'Ongoing', metricFrequency: 'Monthly' },
    ],
  },
  {
    id: 'cs7', cin: 'CIN0013701', snowCardId: 'SNOW-87800', name: 'Utilization Management Screening 2024',
    type: 'Screening', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'Approved', createdDate: '2024-01-10', lastModified: '2024-01-20',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: true, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs2', cin: 'CIN0013698', snowCardId: 'SNOW-87501', name: 'Rx Cost Mgmt MVA Jan 2024',
    type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Approved', createdDate: '2024-01-08', lastModified: '2024-01-25',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: true,
    benefitPlans: [
      { id: 'bp4', number: 'BP-2024-002-A', fiscalPeriod: 'FY2024', market: 'Texas', lob: 'Commercial', mbu: 'MBU-TX-COM', sbu: 'SBU-COM', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Monthly', description: 'Rx Savings Texas Commercial', currency: 'USD' },
    ],
    costPlans: [],
  },
  { id: 'cs27', cin: 'CIN0013723', snowCardId: 'SNOW-90122', name: 'Biosimilar Adoption Closing FY2024',     type: 'Closing',   portfolioGroup: 'Pharmacy',            portfolio: 'Rx Cost Management',       status: 'Approved',    createdDate: '2024-01-05', lastModified: '2024-03-20', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs22', cin: 'CIN0013718', snowCardId: 'SNOW-89617', name: 'Ambulatory Surgery Screening Q2',        type: 'Screening', portfolioGroup: 'Medical Management',  portfolio: 'Utilization Management',   status: 'In Progress', createdDate: '2024-02-28', lastModified: '2024-03-01', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs20', cin: 'CIN0013716', snowCardId: 'SNOW-89415', name: 'Inpatient Readmissions MVA Mar 2024',    type: 'MVA',       portfolioGroup: 'Medical Management',  portfolio: 'PI – Medical Edits',       status: 'Draft',       createdDate: '2024-02-25', lastModified: '2024-02-25', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs16', cin: 'CIN0013712', snowCardId: 'SNOW-89011', name: 'Telehealth Expansion Screening',         type: 'Screening', portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'Draft',       createdDate: '2024-02-22', lastModified: '2024-02-22', createdBy: 'Michael Chen',     demandManager: 'Michael Chen',     financialAnalyst: 'Amanda Foster',     backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs30', cin: 'CIN0013726', snowCardId: 'SNOW-90425', name: 'Home Health Optimization Closing FY24',  type: 'Closing',   portfolioGroup: 'Medical Management',  portfolio: 'Care Management',          status: 'In Progress', createdDate: '2024-02-20', lastModified: '2024-03-25', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Patricia Williams',  backupFA: 'Sarah Johnson',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs13', cin: 'CIN0013709', snowCardId: 'SNOW-88708', name: 'Network Adequacy Screening 2024',        type: 'Screening', portfolioGroup: 'Network',             portfolio: 'Network Optimization',     status: 'Draft',       createdDate: '2024-02-18', lastModified: '2024-02-18', createdBy: 'Sarah Johnson',    demandManager: 'Sarah Johnson',    financialAnalyst: 'Patricia Williams', backupDM: 'Patricia Williams',      backupFA: 'Michael Chen',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs10', cin: 'CIN0013706', snowCardId: 'SNOW-88405', name: 'Specialty Drug Management Screening',    type: 'Screening', portfolioGroup: 'Pharmacy',            portfolio: 'Specialty Drug Mgmt',      status: 'Draft',       createdDate: '2024-02-14', lastModified: '2024-02-14', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Sarah Johnson',     backupDM: 'Patricia Williams',  backupFA: 'Amanda Foster',   hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs33', cin: 'CIN0013705', snowCardId: 'SNOW-91303', name: 'Pharmacy Formulary MVA Mar 2024', type: 'MVA', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management', status: 'In Review', createdDate: '2024-02-10', lastModified: '2024-02-20', createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen', backupDM: 'Amanda Foster', backupFA: 'Patricia Williams', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs19', cin: 'CIN0013715', snowCardId: 'SNOW-89314', name: 'Generic Drug Substitution Screening',    type: 'Screening', portfolioGroup: 'Pharmacy',            portfolio: 'Rx Cost Management',       status: 'In Review',   createdDate: '2024-02-08', lastModified: '2024-02-25', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs34', cin: 'CIN0013702', snowCardId: 'SNOW-91404', name: 'Stars Program Screening Q2 2024', type: 'Screening', portfolioGroup: 'Quality', portfolio: 'Stars Program', status: 'Draft', createdDate: '2024-02-05', lastModified: '2024-02-05', createdBy: 'Amanda Foster', demandManager: 'Amanda Foster', financialAnalyst: 'Patricia Williams', backupDM: 'Sarah Johnson', backupFA: 'Michael Chen', hasFinancialModel: false, hasScaling: false, hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  { id: 'cs15', cin: 'CIN0013711', snowCardId: 'SNOW-88910', name: 'Value-Based Care MVA Feb 2024',          type: 'MVA',       portfolioGroup: 'Network',             portfolio: 'Value-Based Care',         status: 'In Review',   createdDate: '2024-02-01', lastModified: '2024-02-22', createdBy: 'Patricia Williams', demandManager: 'Patricia Williams', financialAnalyst: 'Sarah Johnson',     backupDM: 'Michael Chen',       backupFA: 'Amanda Foster',  hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
  {
    id: 'cs8', cin: 'CIN0013698', snowCardId: 'SNOW-87420', name: 'Rx Cost Management Screening 2024',
    type: 'Screening', portfolioGroup: 'Pharmacy', portfolio: 'Rx Cost Management',
    status: 'Approved', createdDate: '2023-12-20', lastModified: '2024-01-05',
    createdBy: 'Michael Chen', demandManager: 'Sarah Johnson', financialAnalyst: 'Michael Chen',
    backupDM: 'Amanda Foster', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs5b', cin: 'CIN0013701', snowCardId: 'SNOW-87851', name: 'Utilization Management MVA Jan 2024',
    type: 'MVA', portfolioGroup: 'Medical Management', portfolio: 'Utilization Management',
    status: 'Approved', createdDate: '2023-12-15', lastModified: '2024-01-05',
    createdBy: 'Sarah Johnson', demandManager: 'Sarah Johnson', financialAnalyst: 'Amanda Foster',
    backupDM: 'Patricia Williams', backupFA: 'Michael Chen',
    hasFinancialModel: true, hasScaling: false, hasReconciliationError: false,
    benefitPlans: [], costPlans: [],
  },
  {
    id: 'cs4', cin: 'CIN0013700', snowCardId: 'SNOW-87734', name: 'HEDIS Improvement Closing 2023',
    type: 'Closing', portfolioGroup: 'Quality', portfolio: 'HEDIS Improvement',
    status: 'Approved', createdDate: '2023-12-01', lastModified: '2024-01-10',
    createdBy: 'Michael Chen', demandManager: 'Amanda Foster', financialAnalyst: 'Michael Chen',
    backupDM: 'Sarah Johnson', backupFA: 'Amanda Foster',
    hasFinancialModel: true, hasScaling: true, hasReconciliationError: false,
    benefitPlans: [
      { id: 'bp6', number: 'BP-2023-004-A', fiscalPeriod: 'FY2023', market: 'California', lob: 'Medicare', mbu: 'MBU-CA-MED', sbu: 'SBU-MED', metric: 'Savings', metricType: 'Hard Savings', metricFrequency: 'Annual', description: 'Stars Quality Savings CA', currency: 'USD' },
    ],
    costPlans: [],
  },
  { id: 'cs14', cin: 'CIN0013710', snowCardId: 'SNOW-88809', name: 'Provider Contracting Closing FY2023',    type: 'Closing',   portfolioGroup: 'Network',             portfolio: 'Provider Contracting',     status: 'Inactive',    createdDate: '2023-08-15', lastModified: '2023-12-20', createdBy: 'Amanda Foster',    demandManager: 'Amanda Foster',    financialAnalyst: 'Michael Chen',      backupDM: 'Sarah Johnson',      backupFA: 'Patricia Williams', hasFinancialModel: true,  hasScaling: true,  hasReconciliationError: false, benefitPlans: [], costPlans: [] },
];

// Sample field-level audit history, seeded for every coversheet. Day offsets are relative to the coversheet's last-modified date.
type AuditSeed = [dayOffset: number, time: string, who: 'dm' | 'fa' | 'gov', action: string, changeType: AuditEntry['changeType'], section: string, field: string, oldValue: string, newValue: string, details: string];

const AUDIT_SEEDS: AuditSeed[] = [
  [0,  '16:06:40', 'dm',  'SNOW Sync Confirmed','Workflow',    'ServiceNow',         'SNOW Sync Status',          'Pending',             'Confirmed',                 'ServiceNow acknowledged {snow}'],
  [0,  '16:05:12', 'dm',  'Pushed to SNOW',   'Workflow',      'ServiceNow',         'ServiceNow Submission',     'Not submitted',       'Submitted to {snow}',       'Excel export attached'],
  [0,  '15:41:30', 'gov', 'Approved',         'Status Change', 'Overview',           'Status',                    'In Review',           'Approved',                  'Governance approval for SNOW push'],
  [0,  '14:32:15', 'dm',  'Status Changed',   'Status Change', 'Overview',           'Status',                    'In Progress',         'In Review',                 'Submitted for governance review'],
  [0,  '14:28:02', 'fa',  'Field Updated',    'Field Update',  'Coversheet',         'Year 1 Net Savings',        '$1,180,000',          '$1,245,000',                'Updated after scaling refresh'],
  [0,  '14:27:40', 'fa',  'Field Updated',    'Field Update',  'Coversheet',         'Savings Confidence',        'Medium',              'High',                      ''],
  [0,  '11:09:51', 'fa',  'Field Updated',    'Field Update',  'Costs',              'IT Expense — FY2024 Q2',    '$85,000',             '$92,500',                   'Vendor quote revised'],
  [0,  '10:58:13', 'fa',  'Row Added',        'Added',         'Costs',              'FTE Request — Data Analyst','—',                   '1.0 FTE · $118,000',        'New cost line item'],
  [-1, '16:44:19', 'fa',  'Field Updated',    'Field Update',  'Membership Scaling', 'Scaling Factor — MBU-OH-COM','1.102',              '1.124',                     'Retrieved from Medical_Scaling_Tool_2024.xlsx'],
  [-1, '16:44:19', 'fa',  'Field Updated',    'Field Update',  'Membership Scaling', 'Membership — MBU-OH-COM',   '241,300',             '245,800',                   'Retrieved from Medical_Scaling_Tool_2024.xlsx'],
  [-1, '16:40:02', 'fa',  'Field Updated',    'Field Update',  'Membership Scaling', 'Scaling Source',            'Manual',              'SharePoint',                ''],
  [-1, '11:15:42', 'fa',  'Model Uploaded',   'Upload',        'Model',              'Financial Model File',      'PI_Model_v2.xlsx',    'PI_Model_v3.xlsx',          'Manual model type selected'],
  [-1, '11:16:05', 'fa',  'Field Updated',    'Field Update',  'Model',              'Model Type',                'Automated',           'Manual',                    ''],
  [-1, '09:15:08', 'dm',  'Document Uploaded','Upload',        'Upload Document',    'Supporting Document',       '—',                   'Business_Case_v2.pdf',      '1.1 MB · Business Case'],
  [-2, '10:12:48', 'fa',  'Data Uploaded',    'Upload',        'Data',               'Membership Data File',      'Membership_Q4_2023.xlsx','Membership_Q1_2024.xlsx', '1.8 MB · tagged Membership / Supporting'],
  [-3, '16:20:05', 'fa',  'Document Uploaded','Upload',        'Upload Document',    'Supporting Document',       '—',                   'Cost_Assumptions.docx',     '240 KB · Cost Assumptions'],
  [-3, '11:02:37', 'dm',  'Data Uploaded',    'Upload',        'Data',               'Baseline Data File',        '—',                   'Baseline_Claims_2023.csv',  '5.6 MB · tagged Claims / Baseline'],
  [-2, '10:05:33', 'fa',  'Data Uploaded',    'Upload',        'Data',               'Claims Data File',          '—',                   'Claims_Data_Q1_2024.xlsx',  '2.4 MB · tagged Claims / Primary'],
  [-2, '09:44:52', 'dm',  'Field Updated',    'Field Update',  'Overview',           'Effective Date',            '01/01/2026',          '02/01/2026',                ''],
  [-2, '09:40:11', 'dm',  'Field Updated',    'Field Update',  'Overview',           'Market',                    'Georgia',             'Virginia',                  ''],
  [-2, '09:47:20', 'dm',  'Field Updated',    'Field Update',  'Overview',           'Backup Financial Analyst',  'Michael Chen',        'Amanda Foster',             ''],
  [-3, '15:12:44', 'dm',  'Field Updated',    'Field Update',  'Coversheet',         'Initiative Description',    'Medical edits pilot', 'Medical edits — 4 markets', ''],
  [-3, '15:10:09', 'dm',  'Row Removed',      'Removed',       'Coversheet',         'Benefit Plan BP-1042',      'Georgia · Commercial','—',                         'Market out of scope'],
  [-4, '09:22:07', 'gov', 'Comment Added',    'Workflow',      'ServiceNow',         'Reconciliation Note',       '—',                   'Benefit plans verified',    ''],
  [-5, '13:30:00', 'dm',  'Status Changed',   'Status Change', 'Overview',           'Status',                    'Draft',               'In Progress',               ''],
  [-6, '13:00:00', 'dm',  'CoCVR Created',    'Workflow',      'System',             'Record',                    '—',                   'Created from SNOW trigger', ''],
];

const AUDIT_ROLES = { dm: 'Demand Manager', fa: 'Financial Analyst', gov: 'Governance' } as const;

function shiftDate(date: string, days: number) {
  const d = new Date(`${date}T00:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export const MOCK_AUDIT_ENTRIES: AuditEntry[] = MOCK_COVERSHEETS.flatMap(cs => {
  const names = { dm: cs.demandManager, fa: cs.financialAnalyst, gov: cs.demandManager === 'Patricia Williams' ? 'Amanda Foster' : 'Patricia Williams' };
  return AUDIT_SEEDS.map(([day, time, who, action, changeType, section, fieldName, previousValue, newValue, details], i) => {
    const userName = names[who];
    [newValue, details] = [newValue, details].map(v => v.replace('{snow}', cs.snowCardId));
    return {
      id: `${cs.id}-a${i}`, coversheetId: cs.id,
      timestamp: `${shiftDate(cs.lastModified, day)} ${time}`,
      userId: MOCK_USERS.find(u => u.name === userName)?.id ?? '',
      userName, userRole: AUDIT_ROLES[who],
      action, changeType, section, details, fieldName, previousValue, newValue,
    };
  });
});

export const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 'n1', message: 'CoCVR CIN-2024-001 is ready for your review', type: 'info', timestamp: '2024-01-28 14:32', read: false, coversheetId: 'cs1' },
  { id: 'n2', message: 'CIN-2024-002: SNOW reconciliation error — benefit plan mismatch detected', type: 'error', timestamp: '2024-01-27 09:15', read: false, coversheetId: 'cs2' },
  { id: 'n3', message: 'CIN-2024-002 has been approved by Patricia Williams', type: 'success', timestamp: '2024-01-25 15:30', read: true, coversheetId: 'cs2' },
  { id: 'n4', message: 'CIN-2024-003: New CoCVR created from SNOW trigger SNOW-87612', type: 'info', timestamp: '2024-01-22 13:00', read: true, coversheetId: 'cs3' },
  { id: 'n5', message: 'CIN-2024-005 status changed to In Progress', type: 'info', timestamp: '2024-02-02 10:45', read: false, coversheetId: 'cs5' },
];

export const MOCK_SCALING_FACTORS: ScalingFactor[] = [
  { market: 'Ohio', lob: 'Commercial', mbu: 'MBU-OH-COM', factor: 1.124, membershipCount: 245800 },
  { market: 'Ohio', lob: 'Medicare', mbu: 'MBU-OH-MED', factor: 0.987, membershipCount: 89200 },
  { market: 'Indiana', lob: 'Commercial', mbu: 'MBU-IN-COM', factor: 1.089, membershipCount: 178300 },
  { market: 'Indiana', lob: 'Medicare', mbu: 'MBU-IN-MED', factor: 1.203, membershipCount: 67400 },
  { market: 'Virginia', lob: 'Medicaid', mbu: 'MBU-VA-MCD', factor: 0.934, membershipCount: 312100 },
  { market: 'Virginia', lob: 'Commercial', mbu: 'MBU-VA-COM', factor: 1.056, membershipCount: 156700 },
  { market: 'Georgia', lob: 'Commercial', mbu: 'MBU-GA-COM', factor: 1.178, membershipCount: 201500 },
  { market: 'Texas', lob: 'Commercial', mbu: 'MBU-TX-COM', factor: 1.312, membershipCount: 489200 },
];

export const MOCK_FINANCIAL_OUTPUTS: FinancialModelOutput[] = [
  { state: 'Ohio', mbu: 'MBU-OH-COM', unscaledSavings: 1245000, scaledSavings: 1399530, scalingFactor: 1.124 },
  { state: 'Ohio', mbu: 'MBU-OH-MED', unscaledSavings: 678000, scaledSavings: 669186, scalingFactor: 0.987 },
  { state: 'Indiana', mbu: 'MBU-IN-COM', unscaledSavings: 892000, scaledSavings: 971388, scalingFactor: 1.089 },
  { state: 'Indiana', mbu: 'MBU-IN-MED', unscaledSavings: 445000, scaledSavings: 535335, scalingFactor: 1.203 },
  { state: 'Virginia', mbu: 'MBU-VA-MCD', unscaledSavings: 1123000, scaledSavings: 1048942, scalingFactor: 0.934 },
  { state: 'Virginia', mbu: 'MBU-VA-COM', unscaledSavings: 567000, scaledSavings: 598752, scalingFactor: 1.056 },
];

export const MEMBERSHIP_MARKETS = ['CA','CA/HMO','CA/PPO','CO','CT','GA','IN','KY','ME','MO','NC','NH','NV','NY','OH','VA','WI','National'] as const;
export type MembershipMarket = typeof MEMBERSHIP_MARKETS[number];

export interface MembershipRow {
  mbu: string;
  period: 'Plan' | 'Actual';
  values: Record<MembershipMarket, number>;
}

export const MOCK_MEMBERSHIP_SUMMARY: MembershipRow[] = [
  { mbu: 'CSBO National Accounts',                           period: 'Plan',   values: { CA:42187,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5888,  KY:12284,  ME:0,      MO:0,      NC:508764, NH:228,    NV:0,      NY:1604334, OH:148304, VA:316,    WI:0,      National:622022  } },
  { mbu: 'CSBO National Accounts',                           period: 'Actual', values: { CA:39842,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5102,  KY:11897,  ME:0,      MO:0,      NC:492381, NH:204,    NV:0,      NY:1588210, OH:141892, VA:298,    WI:0,      National:599662  } },
  { mbu: 'CSBO Local Large Group',                           period: 'Plan',   values: { CA:2168894,'CA/HMO':0,    'CA/PPO':0,    CO:179131, CT:476325, GA:1876486,IN:1827185,KY:857165, ME:241383, MO:488371, NC:0,      NH:401551, NV:0,      NY:0,      OH:2716008,VA:5177399,WI:1681732,National:18016630} },
  { mbu: 'CSBO Local Large Group',                           period: 'Actual', values: { CA:2104211,'CA/HMO':0,    'CA/PPO':0,    CO:165842, CT:451203, GA:1798423,IN:1762041,KY:831492, ME:228761, MO:469834, NC:0,      NH:388214, NV:0,      NY:0,      OH:2634917,VA:5023841,WI:1598204,National:17477983} },
  { mbu: 'CSBO Small Group',                                 period: 'Plan',   values: { CA:218570, 'CA/HMO':0,    'CA/PPO':0,    CO:44921,  CT:100413, GA:434016, IN:389145, KY:183241, ME:58912,  MO:104823, NC:0,      NH:88412,  NV:0,      NY:0,      OH:614231, VA:1183421,WI:382145, National:3824250 } },
  { mbu: 'CSBO Small Group',                                 period: 'Actual', values: { CA:211384, 'CA/HMO':0,    'CA/PPO':0,    CO:42183,  CT:96814,  GA:418423, IN:374812, KY:178234, ME:56123,  MO:101234, NC:0,      NH:85412,  NV:0,      NY:0,      OH:591823, VA:1142384,WI:368241, National:3707067 } },
  { mbu: 'GBD Medicare Advantage All',                       period: 'Plan',   values: { CA:103651, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:522022, WI:79842,  National:822522  } },
  { mbu: 'GBD Medicare Advantage Non-Special Needs Plans',   period: 'Plan',   values: { CA:0,      'CA/HMO':83250,'CA/PPO':20401,CO:0,      CT:29245,  GA:0,      IN:1079557,KY:1463408,ME:0,      MO:233457, NC:0,      NH:0,      NV:0,      NY:3888271,OH:1150430,VA:0,      WI:0,      National:852151  } },
  { mbu: 'GBD Medicare Advantage Non-Special Needs Plans',   period: 'Actual', values: { CA:0,      'CA/HMO':80142,'CA/PPO':18923,CO:0,      CT:27831,  GA:0,      IN:1042381,KY:1411234,ME:0,      MO:221834, NC:0,      NH:0,      NV:0,      NY:3741823,OH:1108412,VA:0,      WI:0,      National:812151  } },
  { mbu: 'GBD Medicare Advantage SNP MMP',                   period: 'Plan',   values: { CA:117161, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:852512  } },
  { mbu: 'GBD Medicare Advantage SNP MMP',                   period: 'Actual', values: { CA:110234, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:810342  } },
  { mbu: 'GBD Medicare Advantage SNP D-SNP',                 period: 'Plan',   values: { CA:551054, 'CA/HMO':0,    'CA/PPO':0,    CO:124252, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:812511  } },
  { mbu: 'GBD Medicare Advantage SNP D-SNP',                 period: 'Actual', values: { CA:528431, 'CA/HMO':0,    'CA/PPO':0,    CO:118423, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:781234  } },
  { mbu: 'GBD Medicaid Dual',                                period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4919024,GA:6894250,IN:889122, KY:0,      ME:3404528,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3239812,WI:0,      National:24710536} },
  { mbu: 'GBD Medicaid Dual',                                period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4712341,GA:6634812,IN:852341, KY:0,      ME:3281234,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3108423,WI:0,      National:23812341} },
  { mbu: 'GBD Medicaid Plan',                                period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4919024,GA:6894250,IN:889122, KY:0,      ME:3404528,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3239812,WI:0,      National:24710536} },
  { mbu: 'GBD Medicaid Plan',                                period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4712341,GA:6634812,IN:852341, KY:0,      ME:3281234,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3108423,WI:0,      National:23812341} },
];

export interface MembershipAdjSummaryRow {
  metric: string;
  values: Partial<Record<MembershipMarket, number>>;
}

export const MEMBERSHIP_ADJ_SUMMARY_MARKETS: MembershipMarket[] = ['CA','CA/HMO','CA/PPO','CO','CT','GA','IN','KY','ME','MO','NV','NH','NY','OH','VA','WI','National'];

export const MOCK_MEMBERSHIP_ADJ_SUMMARY: MembershipAdjSummaryRow[] = [
  { metric: 'National as a % of CSBD Market',      values: { 'CA/HMO':1.64, 'CA/PPO':1.25, CO:0, CT:1.80, GA:19.97, IN:1.00, KY:5.67, ME:0, MO:0.96, NV:0, NH:1.14, NY:4.11, OH:2.83, VA:0.58, WI:0.01 } },
  { metric: 'CA HMO vs. CA PPO as a % of CA Market', values: { 'CA/HMO':25.95, 'CA/PPO':74.05 } },
  { metric: 'National GRS % (IN)',                 values: { IN:47.47, National:52.53 } },
  { metric: 'GRS vs MCR Adv as a % of Market',     values: { CA:42.24, CO:20.33, CT:25.50, GA:89.81, IN:4.36, KY:3.97, ME:45.96, MO:31.98, NV:68.35, NH:100, NY:29.42, OH:18.61, VA:4.41, WI:25.13 } },
  { metric: 'National %s',                         values: { 'CA/HMO':5.87, 'CA/PPO':12.67, CO:0, CT:3.09, GA:41.24, IN:1.95, KY:11.73, ME:0, MO:1.07, NV:0, NH:1.36, NY:9.43, OH:8.21, VA:2.05, WI:0.01, National:1.32 } },
];

export const MOCK_MEMBERSHIP_BY_YEAR: Record<string, MembershipRow[]> = {
  '2022': [
    { mbu: 'CSBO National Accounts',                         period: 'Plan',   values: { CA:38200, 'CA/HMO':0,     'CA/PPO':0,     CO:0,      CT:0,      GA:0,      IN:5200,  KY:11100,  ME:0,      MO:0,      NC:476000, NH:198,    NV:0,      NY:1512000, OH:132000, VA:280,    WI:0,      National:572000  } },
    { mbu: 'CSBO National Accounts',                         period: 'Actual', values: { CA:36800, 'CA/HMO':0,     'CA/PPO':0,     CO:0,      CT:0,      GA:0,      IN:4980,  KY:10720,  ME:0,      MO:0,      NC:458000, NH:182,    NV:0,      NY:1488000, OH:127000, VA:261,    WI:0,      National:548000  } },
    { mbu: 'CSBO Local Large Group',                         period: 'Plan',   values: { CA:1980000,'CA/HMO':0,    'CA/PPO':0,     CO:158000, CT:432000, GA:1720000,IN:1680000,KY:790000, ME:218000, MO:452000, NC:0,      NH:368000, NV:0,      NY:0,      OH:2480000,VA:4760000,WI:1540000,National:16428000} },
    { mbu: 'CSBO Local Large Group',                         period: 'Actual', values: { CA:1910000,'CA/HMO':0,    'CA/PPO':0,     CO:148000, CT:410000, GA:1648000,IN:1612000,KY:762000, ME:204000, MO:430000, NC:0,      NH:350000, NV:0,      NY:0,      OH:2380000,VA:4580000,WI:1458000,National:15702000} },
    { mbu: 'CSBO Small Group',                               period: 'Plan',   values: { CA:196000, 'CA/HMO':0,    'CA/PPO':0,     CO:40200,  CT:89800,  GA:398000, IN:355000, KY:166000, ME:52000,  MO:95200,  NC:0,      NH:80000,  NV:0,      NY:0,      OH:558000, VA:1082000,WI:348000, National:3492000 } },
    { mbu: 'CSBO Small Group',                               period: 'Actual', values: { CA:188000, 'CA/HMO':0,    'CA/PPO':0,     CO:38200,  CT:85400,  GA:378000, IN:338000, KY:158000, ME:49200,  MO:90800,  NC:0,      NH:76200,  NV:0,      NY:0,      OH:530000, VA:1028000,WI:328000, National:3322000 } },
    { mbu: 'GBD Medicare Advantage All',                     period: 'Plan',   values: { CA:92000,  'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:478000, WI:70000,  National:748000  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Plan',   values: { CA:0,      'CA/HMO':74000,'CA/PPO':17800, CO:0,      CT:25800,  GA:0,      IN:980000, KY:1328000,ME:0,      MO:210000, NC:0,      NH:0,      NV:0,      NY:3540000,OH:1042000,VA:0,      WI:0,      National:772000  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Actual', values: { CA:0,      'CA/HMO':70800,'CA/PPO':16200, CO:0,      CT:24200,  GA:0,      IN:942000, KY:1280000,ME:0,      MO:198000, NC:0,      NH:0,      NV:0,      NY:3380000,OH:998000, VA:0,      WI:0,      National:738000  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Plan',   values: { CA:104000, 'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:778000  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Actual', values: { CA:98000,  'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:742000  } },
    { mbu: 'GBD Medicaid Dual',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:4480000,GA:6280000,IN:808000, KY:0,      ME:3108000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:2952000,WI:0,      National:22520000} },
    { mbu: 'GBD Medicaid Dual',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:4282000,GA:6022000,IN:772000, KY:0,      ME:2980000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:2820000,WI:0,      National:21618000} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:4480000,GA:6280000,IN:808000, KY:0,      ME:3108000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:2952000,WI:0,      National:22520000} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,     CO:0,      CT:4282000,GA:6022000,IN:772000, KY:0,      ME:2980000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:2820000,WI:0,      National:21618000} },
  ],
  '2023': [
    { mbu: 'CSBO National Accounts',                         period: 'Plan',   values: { CA:42187,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5888,  KY:12284,  ME:0,      MO:0,      NC:508764, NH:228,    NV:0,      NY:1604334, OH:148304, VA:316,    WI:0,      National:622022  } },
    { mbu: 'CSBO National Accounts',                         period: 'Actual', values: { CA:39842,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5102,  KY:11897,  ME:0,      MO:0,      NC:492381, NH:204,    NV:0,      NY:1588210, OH:141892, VA:298,    WI:0,      National:599662  } },
    { mbu: 'CSBO Local Large Group',                         period: 'Plan',   values: { CA:2168894,'CA/HMO':0,    'CA/PPO':0,    CO:179131, CT:476325, GA:1876486,IN:1827185,KY:857165, ME:241383, MO:488371, NC:0,      NH:401551, NV:0,      NY:0,      OH:2716008,VA:5177399,WI:1681732,National:18016630} },
    { mbu: 'CSBO Local Large Group',                         period: 'Actual', values: { CA:2104211,'CA/HMO':0,    'CA/PPO':0,    CO:165842, CT:451203, GA:1798423,IN:1762041,KY:831492, ME:228761, MO:469834, NC:0,      NH:388214, NV:0,      NY:0,      OH:2634917,VA:5023841,WI:1598204,National:17477983} },
    { mbu: 'CSBO Small Group',                               period: 'Plan',   values: { CA:218570, 'CA/HMO':0,    'CA/PPO':0,    CO:44921,  CT:100413, GA:434016, IN:389145, KY:183241, ME:58912,  MO:104823, NC:0,      NH:88412,  NV:0,      NY:0,      OH:614231, VA:1183421,WI:382145, National:3824250 } },
    { mbu: 'CSBO Small Group',                               period: 'Actual', values: { CA:211384, 'CA/HMO':0,    'CA/PPO':0,    CO:42183,  CT:96814,  GA:418423, IN:374812, KY:178234, ME:56123,  MO:101234, NC:0,      NH:85412,  NV:0,      NY:0,      OH:591823, VA:1142384,WI:368241, National:3707067 } },
    { mbu: 'GBD Medicare Advantage All',                     period: 'Plan',   values: { CA:103651, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:522022, WI:79842,  National:822522  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Plan',   values: { CA:0,      'CA/HMO':83250,'CA/PPO':20401,CO:0,      CT:29245,  GA:0,      IN:1079557,KY:1463408,ME:0,      MO:233457, NC:0,      NH:0,      NV:0,      NY:3888271,OH:1150430,VA:0,      WI:0,      National:852151  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Actual', values: { CA:0,      'CA/HMO':80142,'CA/PPO':18923,CO:0,      CT:27831,  GA:0,      IN:1042381,KY:1411234,ME:0,      MO:221834, NC:0,      NH:0,      NV:0,      NY:3741823,OH:1108412,VA:0,      WI:0,      National:812151  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Plan',   values: { CA:117161, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:852512  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Actual', values: { CA:110234, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:810342  } },
    { mbu: 'GBD Medicare Advantage SNP D-SNP',               period: 'Plan',   values: { CA:551054, 'CA/HMO':0,    'CA/PPO':0,    CO:124252, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:812511  } },
    { mbu: 'GBD Medicare Advantage SNP D-SNP',               period: 'Actual', values: { CA:528431, 'CA/HMO':0,    'CA/PPO':0,    CO:118423, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:781234  } },
    { mbu: 'GBD Medicaid Dual',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4919024,GA:6894250,IN:889122, KY:0,      ME:3404528,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3239812,WI:0,      National:24710536} },
    { mbu: 'GBD Medicaid Dual',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4712341,GA:6634812,IN:852341, KY:0,      ME:3281234,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3108423,WI:0,      National:23812341} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4919024,GA:6894250,IN:889122, KY:0,      ME:3404528,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3239812,WI:0,      National:24710536} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4712341,GA:6634812,IN:852341, KY:0,      ME:3281234,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3108423,WI:0,      National:23812341} },
  ],
  '2024': [
    { mbu: 'CSBO National Accounts',                         period: 'Plan',   values: { CA:45800,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:6420,  KY:13100,  ME:0,      MO:0,      NC:534000, NH:248,    NV:0,      NY:1682000, OH:158000, VA:342,    WI:0,      National:652000  } },
    { mbu: 'CSBO National Accounts',                         period: 'Actual', values: { CA:43200,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:5980,  KY:12480,  ME:0,      MO:0,      NC:518000, NH:226,    NV:0,      NY:1648000, OH:150000, VA:318,    WI:0,      National:628000  } },
    { mbu: 'CSBO Local Large Group',                         period: 'Plan',   values: { CA:2280000,'CA/HMO':0,    'CA/PPO':0,    CO:192000, CT:498000, GA:1968000,IN:1920000,KY:898000, ME:254000, MO:512000, NC:0,      NH:422000, NV:0,      NY:0,      OH:2852000,VA:5438000,WI:1762000,National:18900000} },
    { mbu: 'CSBO Local Large Group',                         period: 'Actual', values: { CA:2198000,'CA/HMO':0,    'CA/PPO':0,    CO:180000, CT:472000, GA:1882000,IN:1848000,KY:864000, ME:240000, MO:490000, NC:0,      NH:402000, NV:0,      NY:0,      OH:2762000,VA:5248000,WI:1678000,National:18264000} },
    { mbu: 'CSBO Small Group',                               period: 'Plan',   values: { CA:232000, 'CA/HMO':0,    'CA/PPO':0,    CO:48200,  CT:106000, GA:458000, IN:412000, KY:194000, ME:62000,  MO:110000, NC:0,      NH:93000,  NV:0,      NY:0,      OH:642000, VA:1242000,WI:402000, National:4012000 } },
    { mbu: 'CSBO Small Group',                               period: 'Actual', values: { CA:224000, 'CA/HMO':0,    'CA/PPO':0,    CO:45800,  CT:102000, GA:440000, IN:396000, KY:186000, ME:59200,  MO:106000, NC:0,      NH:89200,  NV:0,      NY:0,      OH:618000, VA:1196000,WI:384000, National:3862000 } },
    { mbu: 'GBD Medicare Advantage All',                     period: 'Plan',   values: { CA:112000, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:562000, WI:86200,  National:888000  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Plan',   values: { CA:0,      'CA/HMO':90200,'CA/PPO':22400,CO:0,      CT:31800,  GA:0,      IN:1138000,KY:1542000,ME:0,      MO:248000, NC:0,      NH:0,      NV:0,      NY:4102000,OH:1212000,VA:0,      WI:0,      National:898000  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Actual', values: { CA:0,      'CA/HMO':86800,'CA/PPO':20800,CO:0,      CT:30200,  GA:0,      IN:1098000,KY:1488000,ME:0,      MO:236000, NC:0,      NH:0,      NV:0,      NY:3962000,OH:1168000,VA:0,      WI:0,      National:858000  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Plan',   values: { CA:126000, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:898000  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Actual', values: { CA:118000, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:858000  } },
    { mbu: 'GBD Medicare Advantage SNP D-SNP',               period: 'Plan',   values: { CA:582000, 'CA/HMO':0,    'CA/PPO':0,    CO:132000, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:856000  } },
    { mbu: 'GBD Medicare Advantage SNP D-SNP',               period: 'Actual', values: { CA:558000, 'CA/HMO':0,    'CA/PPO':0,    CO:125000, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:822000  } },
    { mbu: 'GBD Medicaid Dual',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:5188000,GA:7262000,IN:938000, KY:0,      ME:3588000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3412000,WI:0,      National:26022000} },
    { mbu: 'GBD Medicaid Dual',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4968000,GA:6982000,IN:898000, KY:0,      ME:3448000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3278000,WI:0,      National:25012000} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:5188000,GA:7262000,IN:938000, KY:0,      ME:3588000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3412000,WI:0,      National:26022000} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:4968000,GA:6982000,IN:898000, KY:0,      ME:3448000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3278000,WI:0,      National:25012000} },
  ],
  '2025': [
    { mbu: 'CSBO National Accounts',                         period: 'Plan',   values: { CA:49200,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:6880,  KY:14020,  ME:0,      MO:0,      NC:562000, NH:268,    NV:0,      NY:1768000, OH:168000, VA:368,    WI:0,      National:688000  } },
    { mbu: 'CSBO National Accounts',                         period: 'Actual', values: { CA:46400,  'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:6420,  KY:13280,  ME:0,      MO:0,      NC:544000, NH:244,    NV:0,      NY:1724000, OH:159000, VA:342,    WI:0,      National:662000  } },
    { mbu: 'CSBO Local Large Group',                         period: 'Plan',   values: { CA:2398000,'CA/HMO':0,    'CA/PPO':0,    CO:204000, CT:522000, GA:2062000,IN:2012000,KY:942000, ME:268000, MO:538000, NC:0,      NH:442000, NV:0,      NY:0,      OH:2988000,VA:5702000,WI:1848000,National:19822000} },
    { mbu: 'CSBO Local Large Group',                         period: 'Actual', values: { CA:2302000,'CA/HMO':0,    'CA/PPO':0,    CO:192000, CT:494000, GA:1972000,IN:1932000,KY:904000, ME:252000, MO:514000, NC:0,      NH:420000, NV:0,      NY:0,      OH:2882000,VA:5488000,WI:1762000,National:19062000} },
    { mbu: 'CSBO Small Group',                               period: 'Plan',   values: { CA:248000, 'CA/HMO':0,    'CA/PPO':0,    CO:52000,  CT:112000, GA:482000, IN:432000, KY:205000, ME:66000,  MO:116000, NC:0,      NH:98000,  NV:0,      NY:0,      OH:672000, VA:1302000,WI:424000, National:4218000 } },
    { mbu: 'CSBO Small Group',                               period: 'Actual', values: { CA:238000, 'CA/HMO':0,    'CA/PPO':0,    CO:49400,  CT:108000, GA:462000, IN:414000, KY:196000, ME:62800,  MO:110000, NC:0,      NH:93800,  NV:0,      NY:0,      OH:644000, VA:1252000,WI:404000, National:4052000 } },
    { mbu: 'GBD Medicare Advantage All',                     period: 'Plan',   values: { CA:121000, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:602000, WI:92800,  National:942000  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Plan',   values: { CA:0,      'CA/HMO':97800,'CA/PPO':24200,CO:0,      CT:34200,  GA:0,      IN:1198000,KY:1622000,ME:0,      MO:262000, NC:0,      NH:0,      NV:0,      NY:4318000,OH:1278000,VA:0,      WI:0,      National:948000  } },
    { mbu: 'GBD Medicare Advantage Non-Special Needs Plans', period: 'Actual', values: { CA:0,      'CA/HMO':93800,'CA/PPO':22600,CO:0,      CT:32400,  GA:0,      IN:1154000,KY:1562000,ME:0,      MO:248000, NC:0,      NH:0,      NV:0,      NY:4162000,OH:1232000,VA:0,      WI:0,      National:908000  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Plan',   values: { CA:136000, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:948000  } },
    { mbu: 'GBD Medicare Advantage SNP MMP',                 period: 'Actual', values: { CA:128000, 'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:908000  } },
    { mbu: 'GBD Medicare Advantage SNP D-SNP',               period: 'Plan',   values: { CA:614000, 'CA/HMO':0,    'CA/PPO':0,    CO:140000, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:902000  } },
    { mbu: 'GBD Medicare Advantage SNP D-SNP',               period: 'Actual', values: { CA:588000, 'CA/HMO':0,    'CA/PPO':0,    CO:132000, CT:0,      GA:0,      IN:0,     KY:0,      ME:0,      MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:0,      WI:0,      National:864000  } },
    { mbu: 'GBD Medicaid Dual',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:5462000,GA:7642000,IN:988000, KY:0,      ME:3778000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3588000,WI:0,      National:27382000} },
    { mbu: 'GBD Medicaid Dual',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:5228000,GA:7342000,IN:946000, KY:0,      ME:3624000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3448000,WI:0,      National:26302000} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Plan',   values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:5462000,GA:7642000,IN:988000, KY:0,      ME:3778000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3588000,WI:0,      National:27382000} },
    { mbu: 'GBD Medicaid Plan',                              period: 'Actual', values: { CA:0,      'CA/HMO':0,    'CA/PPO':0,    CO:0,      CT:5228000,GA:7342000,IN:946000, KY:0,      ME:3624000,MO:0,      NC:0,      NH:0,      NV:0,      NY:0,      OH:0,      VA:3448000,WI:0,      National:26302000} },
  ],
};

export const MOCK_COST_LINE_ITEMS: CostLineItem[] = [
  { id: 'cl1', costType: 'IT Expense', description: 'Server Infrastructure Upgrade', amount: 125000, period: 'Q1 2024', source: 'Uploaded' },
  { id: 'cl2', costType: 'IT Expense', description: 'Software Licensing – Analytics Platform', amount: 48000, period: 'Annual', source: 'Uploaded' },
  { id: 'cl3', costType: 'FTE Request', description: 'Project Manager (1.0 FTE)', amount: 95000, period: 'Annual', source: 'Uploaded' },
  { id: 'cl4', costType: 'FTE Request', description: 'Clinical Analyst (0.5 FTE)', amount: 52500, period: 'Annual', source: 'Manual' },
  { id: 'cl5', costType: 'Other', description: 'Vendor Consulting Fees', amount: 35000, period: 'Q1–Q2 2024', source: 'Manual' },
];

export const MOCK_UPLOADED_FILES = [
  { id: 'f1', name: 'Claims_Data_Q1_2024.xlsx', size: '2.4 MB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 10:05' },
  { id: 'f2', name: 'Membership_Summary_2024.xlsx', size: '1.1 MB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 10:07' },
  { id: 'f3', name: 'PI_Medical_Edits_Model_v3.xlsx', size: '3.8 MB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 11:15' },
  { id: 'f4', name: 'SQL_Query_Claims_Extract.sql', size: '4 KB', uploadedBy: 'Michael Chen', uploadedAt: '2024-01-27 10:06' },
];

export const PREVIEW_TABLE_DATA = Array.from({ length: 25 }, (_, i) => ({
  claimId: `CLM-${(100000 + i).toString()}`,
  memberId: `MEM-${(200000 + i * 17).toString()}`,
  dateOfService: `2024-01-${(i % 28 + 1).toString().padStart(2, '0')}`,
  paidAmount: (Math.random() * 5000 + 200).toFixed(2),
  market: ['Ohio', 'Indiana', 'Virginia'][i % 3],
  lob: ['Commercial', 'Medicare', 'Medicaid'][i % 3],
  diagnosisCode: ['Z79.4', 'I10', 'E11.9', 'J45.50', 'M54.5'][i % 5],
}));
