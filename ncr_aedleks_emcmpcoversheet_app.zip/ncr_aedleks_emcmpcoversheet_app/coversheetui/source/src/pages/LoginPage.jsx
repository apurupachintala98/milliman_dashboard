import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import elevanceLogo from '../assets/Elevance_Health_logo.png';
import { LDAP_VALIDATE_URL } from '../config/apiConfig';
import { useToast } from '../context/ToastContext';

// ── Constants ─────────────────────────────────────────────────────────────────
const APPLICATION_CODE = 'emcmp';
const NAVIGATION_DELAY = 1200; // ms before redirecting after successful login

// Known role definitions — code substring matched against role strings
const KNOWN_ROLES = [

  { code: 'governance',        value: 'Governance',         label: 'Governance' },
  { code: 'demand_manager',    value: 'Demand Manager',     label: 'Demand Manager' },
  { code: 'demand manager',    value: 'Demand Manager',     label: 'Demand Manager' },
  { code: 'financial_analyst', value: 'Financial Analyst',  label: 'Financial Analyst' },
  { code: 'financial analyst', value: 'Financial Analyst',  label: 'Financial Analyst' },
  { code: 'read_only',         value: 'Read-Only',          label: 'Read-Only' },
  { code: 'read only',         value: 'Read-Only',          label: 'Read-Only' },
  { code: 'read-only',         value: 'Read-Only',          label: 'Read-Only' },
  { code: 'user',              value: 'Read-Only',          label: 'Read-Only' },
];

function normalizeRoles(rawRoles) {
  if (!Array.isArray(rawRoles) || rawRoles.length === 0) return [];

  const seen = new Map();

  rawRoles.forEach(entry => {
    const raw = typeof entry === 'string' ? entry : (entry.role_cd ?? entry.value ?? entry.code ?? JSON.stringify(entry));
    const lower = raw.toLowerCase();

    // Try to match a known role definition
    const matched = KNOWN_ROLES.find(r => lower.includes(r.code));
    const normalized = matched
      ? { value: matched.value, label: matched.label, code: raw }
      : { value: raw, label: raw, code: raw };

    if (!seen.has(normalized.value)) {
      seen.set(normalized.value, normalized);
    }
  });

  return Array.from(seen.values());
}

export default function LoginPage() {
  const navigate = useNavigate();
  const { showToast } = useToast();

  // ── State ──────────────────────────────────────────────────────────────────
  const [userId, setUserId]       = useState('');
  const [password, setPassword]   = useState('');
  const [error, setError]         = useState('');
  const [loading, setLoading]     = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);

  // ── On mount: skip login if already authenticated ─────────────────────────
  useEffect(() => {
    const stored = sessionStorage.getItem('user');
    if (stored) {
      try { JSON.parse(stored); navigate('/dashboard', { replace: true }); } catch { /* bad data */ }
    }
  }, [navigate]);

  // ── Validate credentials via LDAP and navigate to dashboard ─────────────
  const validateCredentials = async () => {
    setError('');
    setLoading(true);

    try {
      const response = await fetch(LDAP_VALIDATE_URL, {
        method: 'POST',
        headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId, password, aplctn_cd: APPLICATION_CODE }),
      });

      const responseBody = await response.json();

      if (!response.ok || responseBody.success === false) {
        throw new Error(
          responseBody.detail ?? responseBody.message ?? responseBody.error ??
          `Validation failed (${response.status})`
        );
      }

      // Extract roles — API may return user_roles, userRoles, or nested user.roles
      const rawRoles =
        responseBody.user_roles ??
        responseBody.userRoles ??
        responseBody.user?.roles ??
        [];

      const normalized = normalizeRoles(rawRoles);
      const roleObj = normalized[0] ?? { value: 'Read-Only', label: 'Read-Only', code: 'user' };

      if (responseBody.access_token) {
        localStorage.setItem('jwt_token', responseBody.access_token);
      }

      const userInfo = {
        ...(responseBody.user_info ?? responseBody.user ?? {}),
        userId:      responseBody.user?.user_id    ?? userId,
        displayName: responseBody.user?.display_name ?? userId,
        email:       responseBody.user?.email ?? '',
        role:        roleObj.value,
        roleLabel:   roleObj.label,
        roleCode:    roleObj.code,
        roles:       normalized.map(r => r.value),
        aplctnCd:    APPLICATION_CODE,
      };

      sessionStorage.setItem('user', JSON.stringify(userInfo));
      sessionStorage.setItem('auth', JSON.stringify({ userId, password }));

      window.dispatchEvent(new Event('userLoggedIn'));

      setIsNavigating(true);
      showToast('Login successful! Redirecting...', 'success');
      setTimeout(() => navigate('/dashboard', { replace: true }), NAVIGATION_DELAY);
    } catch (err) {
      const msg = err.message || 'Validation failed. Please try again.';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  // ── Form submit handler ───────────────────────────────────────────────────
  const handleLogin = (e) => {
    e.preventDefault();
    setError('');
    if (!userId.trim())   { setError('Please enter your User ID.');  return; }
    if (!password.trim()) { setError('Please enter your password.'); return; }
    validateCredentials();
  };

  // ── Derived UI state ───────────────────────────────────────────────────────
  const validateDisabled = loading || isNavigating || !userId.trim() || !password.trim();
  const validateLabel    = loading ? 'Validating…' : 'Validate';

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      {/* Top bar */}
      <div className="bg-[#1A3673] px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={elevanceLogo} alt="Elevance Health" className="h-10 w-auto" />
          <span className="text-white text-2xl font-light">|</span>
          <span className="text-white font-semibold text-lg tracking-wide">Medical Cost Management : Cost of Care Value Realization (CoCVR)</span>
        </div>
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Elevance_Health_logo.svg/320px-Elevance_Health_logo.svg.png"
          alt="Elevance Health"
          className="h-7 brightness-0 invert"
          onError={e => { e.target.style.display = 'none'; }}
        />
      </div>

      {/* Hero section */}
      <div className="flex-1 flex items-center justify-center px-8">
        <div className="w-full max-w-4xl flex gap-12 items-center">

          {/* Left: branding */}
          <div className="flex-1">
            <h1 className="text-5xl font-light text-[#1A3673] leading-tight mb-4">
              Cost of Care <span className="font-bold">Value Realization (CoCVR)</span>
            </h1>
            <p className="text-gray-500 text-base leading-relaxed mb-6 max-w-sm">
              Centralized platform for managing Cost of Care financial impact analysis — from initial
              screening through monthly tracking to final closing.
            </p>
            <div className="flex flex-col gap-2">
              {[
                { icon: '⚡', label: 'Faster coversheet creation' },
                { icon: '✓',  label: 'Audit compliance & traceability' },
                { icon: '🔒', label: 'Role-based access control' },
              ].map(item => (
                <div key={item.label} className="flex items-center gap-2 text-base text-gray-600">
                  <span className="text-[#00BBBA]">{item.icon}</span>
                  {item.label}
                </div>
              ))}
            </div>
            {/* Decorative chevrons */}
            <div className="mt-8 opacity-10">
              <svg width="200" height="80" viewBox="0 0 200 80">
                <polyline points="20,10 60,40 20,70"   fill="none" stroke="#1A3673" strokeWidth="3"/>
                <polyline points="60,10 100,40 60,70"  fill="none" stroke="#1A3673" strokeWidth="3"/>
                <polyline points="100,10 140,40 100,70" fill="none" stroke="#1A3673" strokeWidth="3"/>
                <polyline points="140,10 180,40 140,70" fill="none" stroke="#1A3673" strokeWidth="3"/>
              </svg>
            </div>
          </div>

          {/* Right: login card */}
          <div className="w-[450px] bg-white rounded-xl shadow-lg p-12 ml-30">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-[#1A3673] mb-2">Sign in</h2>
              <p className="text-base text-gray-500">Enter your Elevance Health credentials</p>
            </div>

            <form onSubmit={handleLogin} noValidate>

              {/* ── Phase 1: credentials ── */}
              <div className="mb-5">
                <label className="form-label text-sm font-semibold">User ID</label>
                <input
                  className={`form-input text-base tracking-widest uppercase py-3 ${error && !userId.trim() ? 'border-[#E3725F] focus:ring-[#E3725F]/20' : ''}`}
                  placeholder=""
                  value={userId}
                  onChange={e => { setUserId(e.target.value); setError(''); }}
                  disabled={loading || isNavigating}
                  autoFocus
                  maxLength={10}
                />
              </div>

              <div className="mb-5">
                <label className="form-label text-sm font-semibold">Password</label>
                <input
                  type="password"
                  className={`form-input text-base py-3 ${error && !password.trim() ? 'border-[#E3725F] focus:ring-[#E3725F]/20' : ''}`}
                  placeholder=""
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  disabled={loading || isNavigating}
                />
              </div>

              {/* Error message */}
              {error && (
                <p className="text-xs text-[#E3725F] mb-4">{error}</p>
              )}

              {/* ── Submit button ── */}
              <button
                type="submit"
                disabled={validateDisabled}
                className="btn-primary w-full justify-center py-2.5 text-sm mb-4"
              >
                {validateLabel}
              </button>
            </form>

            <div className="mt-6 flex items-center gap-2">
              <div className="flex-1 h-px bg-gray-100" />
              <span className="text-xs text-gray-400">Elevance Health LDAP</span>
              <div className="flex-1 h-px bg-gray-100" />
            </div>
            <p className="text-center text-xs text-gray-400 mt-3">
              Protected by enterprise LDAP. Contact IT for access issues.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
