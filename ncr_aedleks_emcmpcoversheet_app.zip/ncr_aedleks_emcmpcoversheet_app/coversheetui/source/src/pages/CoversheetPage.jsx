import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronDown, LayoutDashboard, FileText, GitBranch, BarChart2, Users, DollarSign, ScrollText, TrendingUp, Upload, X, Send, ThumbsUp, ThumbsDown, ArrowUpCircle } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';
import { coversheetApi, configApi } from '../config/apiConfig';
import OverviewTab from '../components/tabs/OverviewTab';
import DataUploadTab from '../components/tabs/DataUploadTab';
import FinancialModelTab from '../components/tabs/FinancialModelTab';
import ScalingTab from '../components/tabs/ScalingTab';
import FinancialSummaryTab from '../components/tabs/FinancialSummaryTab';
import CostPlanTab from '../components/tabs/CostPlanTab';
import AuditTrailTab from '../components/tabs/AuditTrailTab';
import CoversheetTab from '../components/tabs/CoversheetTab';
import ServiceNowTab from '../components/tabs/ServiceNowTab';
import UploadDocumentTab from '../components/tabs/UploadDocumentTab';
// import SourcePivotTab from '../components/tabs/SourcePivotTab';

const TABS = [
  { id: 'overview',   label: 'Overview',            icon: LayoutDashboard },
  { id: 'coversheet', label: 'Coversheet',           icon: FileText },
  { id: 'snow',       label: 'ServiceNow',           icon: GitBranch },
  { id: 'summary',    label: 'Financial Summary',    icon: TrendingUp },
  { id: 'scaling',    label: 'Membership Scaling',   icon: Users },
  { id: 'model',      label: 'Model',                icon: BarChart2 },
  // { id: 'sourcepivot', label: 'Source Pivot',         icon: TrendingUp },
  { id: 'costs',      label: 'Costs',                icon: DollarSign },
  { id: 'data',       label: 'Data',                 icon: FileText },
  { id: 'audit',      label: 'Audit Trail',          icon: ScrollText },
  { id: 'upload',     label: 'Upload Document',      icon: Upload },
];

// Ordered workflow — read-only view, highlights active status from API
const WORKFLOW_STAGES = [
  { key: 'pending_coversheet_parameters_selection',          label: 'Pending Coversheet Parameters Selection' },
  { key: 'pending_membership_scaling_parameters_selection',  label: 'Pending Membership Scaling Parameters Selection' },
  { key: 'pending_data_upload',                              label: 'Pending Data Upload' },
  { key: 'pending_financial_model_upload',                   label: 'Pending Financial Model Upload' },
  { key: 'pending_financial_model_parameters_selection',     label: 'Pending Financial Model Parameters Selection' },
  { key: 'pending_cost_model_upload',                        label: 'Pending Cost Model Upload' },
  { key: 'pending_business_review',                          label: 'Pending Business Review' },
  { key: 'submitted_to_servicenow',                          label: 'Submitted to ServiceNow' },
];

const formatStatusLabel = (s) => {
  const stage = WORKFLOW_STAGES.find(w => w.key === s);
  if (stage) return stage.label;
  return s ? s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : '';
};

const normalizeStatus = (s) => s ?? '';

// Which tab(s) to highlight for each workflow status (from API)
const STATUS_TAB_HIGHLIGHT = {
  pending_coversheet_parameters_selection:         ['coversheet'],
  pending_membership_scaling_parameters_selection: ['scaling'],
  pending_data_upload:                             ['upload'],
  pending_financial_model_upload:                  ['model'],
  pending_cost_model_upload:                       ['costs'],
};

export default function CoversheetPage() {
  const { id } = useParams();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const { resolvePhaseRole, switchRole, activeRole, setRoles, can } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [coversheet, setCoversheet] = useState(null);
  const [csLoading, setCsLoading] = useState(true);
  const [csError, setCsError] = useState(null);
  const [showMvaHistory, setShowMvaHistory] = useState(false);
  const [coversheetConfig, setCoversheetConfig] = useState(null);
  const [configLoading, setConfigLoading] = useState(true);
  const [configFailed, setConfigFailed] = useState(false);
  // Phase switcher
  const [selectedPhaseId, setSelectedPhaseId] = useState(id);
  const [phaseOpen, setPhaseOpen] = useState(false);
  const phaseDropdownRef = useRef(null);


  useEffect(() => {
    setCsLoading(true);
    setCsError(null);
    setCoversheet(null);
    coversheetApi.getCoversheet(id)
      .then(data => {
        const cs = data.coversheet ?? data;
        setCoversheet({
          id: cs.cvrsht_id,
          cin: cs.u_cin ?? '—',
          name: cs.recommended_model_name ?? '—',
          type: cs.project_phase ?? '',
          status: normalizeStatus(cs.cvrsht_stts_cd),
          rawSttscd: cs.cvrsht_stts_cd ?? '',
          portfolio: cs.primary_portfolio_name ?? '—',
          portfolioGroup: cs.primary_portfolio_u_portfolio_group ?? '—',
          demandManager: cs.demand_manager_name ?? '—',
          demandManagerEmail: cs.demand_manager_email ?? '',
          backupDM: cs.u_demand_manager_backup_name ?? null,
          financialAnalyst: cs.u_financial_analyst_name ?? '—',
          financialAnalystEmail: cs.u_financial_analyst_email ?? '',
          backupFA: cs.u_backup_financial_analyst_name ?? null,
          phaseStart: cs.proj_phase_strt_year_mnth_nbr ?? '',
          phaseEnd: cs.proj_phase_end_year_mnth_nbr ?? '',
          createdBy: cs.creatd_by_user_id ?? '—',
          coverSheetVersion: cs.vrsn_nbr ?? '—',
          recommended_model_name: cs.recommended_model_name ?? '—',
          snowCardId: cs.sys_id ?? '—',
          createdDate: cs.creatd_dtm ? cs.creatd_dtm.slice(0, 10) : '—',
          lastModified: cs.updtd_dtm ? cs.updtd_dtm.slice(0, 10) : '—',
          totalBenefitPlans: cs.totl_bnft_plans_cnt ?? 0,
          totalCostPlans: cs.totl_cost_plans_cnt ?? 0,
          totalActualBenefit: cs.totl_actl_bnft_amt ?? 0,
          totalEnteredBenefit: cs.totl_entrd_bnft_amt ?? 0,
          totalActualCost: cs.totl_actl_cost_amt ?? 0,
          dmndNbr: cs.demand_number ?? '',
          sysId: cs.sys_id ?? '',
          mvaFrequency: cs.u_mva_frequency_display ?? '',
          demandStatus: cs.demand_state_display ?? '',
          scalingApplicable: cs.u_membership_scaling_applicable ?? '',
          benefitPlans: data.benefit_plans ?? [],
          costPlans: data.cost_plans ?? [],
          hasReconciliationError: false,
        });
        const cin = cs.u_cin;
        if (cin && cin !== '—') {
          return configApi.getConfig(cin)
            .then(cfg => { setCoversheetConfig(cfg); setConfigFailed(false); })
            .catch(err => { setConfigFailed(true); console.warn('[Config API] Failed to load config for CIN', cin, err.message); });
        } else {
          setConfigFailed(true);
        }
      })
      .catch(err => setCsError(err.message))
      .finally(() => { setCsLoading(false); setConfigLoading(false); });
  }, [id]);

  const handleEdit = () => {
    if (!coversheet) return;
    if (coversheet.status === 'Approved' || coversheet.status === 'In Review') {
      setCoversheet({ ...coversheet, status: 'In Progress' });
      showToast('Status reset to "In Progress" due to edit', 'info');
    }
  };

  // Shared config refetch — call after any action that may affect flags/phases
  const refetchConfig = useCallback(() => {
    const cin = coversheet?.cin;
    if (!cin || cin === '—') return;
    configApi.getConfig(cin)
      .then(cfg => setCoversheetConfig(cfg))
      .catch(err => console.warn('[Config API] Re-fetch failed:', err.message));
  }, [coversheet?.cin]);

  // Keep alias for backward compat with onModelingSaved prop
  const handleModelingSaved = refetchConfig;

  // Tab visibility — restrict scaling and costs based on config flags
  const getVisibleTabs = () => {
    const flags = coversheetConfig?.flags ?? {};
    const scalingOn = flags.scaling_applicable_flag?.value?.toUpperCase() === 'YES';
    const costOn    = flags.cost_plan_applicable_flag?.value?.toUpperCase() === 'YES';
    return TABS.filter(t => {
      if (t.id === 'scaling') return scalingOn;
      if (t.id === 'costs')   return costOn;
      return true;
    });
  };

  const [statusOpen, setStatusOpen] = useState(false);
  const statusDropdownRef = useRef(null);

  useEffect(() => {
    if (!statusOpen) return;
    const handleClickOutside = (e) => {
      if (statusDropdownRef.current && !statusDropdownRef.current.contains(e.target)) {
        setStatusOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [statusOpen]);

  // Reset selectedPhaseId when navigating to a new coversheet
  useEffect(() => { setSelectedPhaseId(id); }, [id]);

  const [phaseLoading, setPhaseLoading] = useState(false);

  const handlePhaseChange = async (newPhaseId) => {
    if (newPhaseId === selectedPhaseId) return;
    setSelectedPhaseId(newPhaseId);
    setPhaseOpen(false);
    setPhaseLoading(true);
    try {
      // Fetch coversheet + config in parallel for the selected phase
      const cin = coversheet.cin;
      const [freshData, freshConfig] = await Promise.all([
        coversheetApi.getCoversheet(newPhaseId),
        cin && cin !== '—' ? configApi.getConfig(cin) : Promise.resolve(null),
      ]);

      // Update coversheet fields (mapped from coversheet API)
      const cs = freshData.coversheet ?? freshData;
      setCoversheet(prev => ({
        ...prev,
        id: cs.cvrsht_id,
        status: normalizeStatus(cs.cvrsht_stts_cd),
        rawSttscd: cs.cvrsht_stts_cd ?? '',
        type: cs.project_phase ?? prev.type,
        phaseStart: cs.proj_phase_strt_year_mnth_nbr ?? prev.phaseStart,
        phaseEnd: cs.proj_phase_end_year_mnth_nbr ?? prev.phaseEnd,
        demandManager: cs.demand_manager_name ?? prev.demandManager,
        demandManagerEmail: cs.demand_manager_email ?? prev.demandManagerEmail,
        backupDM: cs.u_demand_manager_backup_name ?? prev.backupDM,
        financialAnalyst: cs.u_financial_analyst_name ?? prev.financialAnalyst,
        financialAnalystEmail: cs.u_financial_analyst_email ?? prev.financialAnalystEmail,
        backupFA: cs.u_backup_financial_analyst_name ?? prev.backupFA,
        coverSheetVersion: cs.vrsn_nbr ?? prev.coverSheetVersion,
        snowCardId: cs.sys_id ?? prev.snowCardId,
        createdDate: cs.creatd_dtm ? cs.creatd_dtm.slice(0, 10) : prev.createdDate,
        lastModified: cs.updtd_dtm ? cs.updtd_dtm.slice(0, 10) : prev.lastModified,
        mvaFrequency: cs.u_mva_frequency_display ?? prev.mvaFrequency,
        demandStatus: cs.demand_state_display ?? prev.demandStatus,
        scalingApplicable: cs.u_membership_scaling_applicable ?? prev.scalingApplicable,
        totalBenefitPlans: cs.totl_bnft_plans_cnt ?? prev.totalBenefitPlans,
        totalCostPlans: cs.totl_cost_plans_cnt ?? prev.totalCostPlans,
        totalActualBenefit: cs.totl_actl_bnft_amt ?? prev.totalActualBenefit,
        totalEnteredBenefit: cs.totl_entrd_bnft_amt ?? prev.totalEnteredBenefit,
        totalActualCost: cs.totl_actl_cost_amt ?? prev.totalActualCost,
        benefitPlans: freshData.benefit_plans ?? prev.benefitPlans,
        costPlans: freshData.cost_plans ?? prev.costPlans,
      }));

      // Update config (mapped from config API — flags, phase statuses, access control, etc.)
      if (freshConfig) setCoversheetConfig(freshConfig);

    } catch (err) {
      showToast(`Failed to load phase data: ${err.message}`, 'error');
      console.error('[Phase Switch] failed:', err.message);
    } finally {
      setPhaseLoading(false);
    }
  };

  // Synchronously compute the resolved role so child components never see stale permissions
  const resolvedRoles = useMemo(() => {
    if (!coversheetConfig) return { defaultRole: 'Read-Only', availableRoles: ['Read-Only'] };
    const phases = coversheetConfig.coversheet_phases ?? [];
    const activePhase = phases.find(p => p.cvrsht_id === selectedPhaseId) ?? phases[0];
    return resolvePhaseRole(activePhase?.access_control ?? null);
  }, [selectedPhaseId, coversheetConfig, resolvePhaseRole]);

  // Keep AuthContext in sync (for Layout badge / other consumers)
  useEffect(() => {
    switchRole(resolvedRoles.defaultRole);
    setRoles(resolvedRoles.availableRoles);
  }, [resolvedRoles, switchRole, setRoles]);



  useEffect(() => {
    if (!phaseOpen) return;
    const handleClickOutside = (e) => {
      if (phaseDropdownRef.current && !phaseDropdownRef.current.contains(e.target)) {
        setPhaseOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [phaseOpen]);

  if (csLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#1A3673] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500 text-sm">Loading coversheet...</p>
        </div>
      </div>
    );
  }

  if (csError || !coversheet) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center max-w-sm">
          <div className="w-14 h-14 rounded-full bg-[#FBEAE7] flex items-center justify-center mx-auto mb-4 text-2xl">📄</div>
          <h2 className="text-base font-semibold text-[#1A3673] mb-1">Coversheet Not Found</h2>
          <p className="text-gray-500 text-sm mb-4">{csError ?? 'The requested coversheet could not be loaded.'}</p>
          <button onClick={() => navigate('/')} className="px-4 py-2 bg-[#1A3673] text-white text-sm rounded-lg hover:bg-[#2861BB] transition">Back to Dashboard</button>
        </div>
      </div>
    );
  }

  return (
    <>
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 flex-shrink-0">

        {/* Top bar: breadcrumb + actions */}
        <div className="px-6 pt-3 pb-2 flex items-center justify-between gap-4">

          {/* Left: back + title block */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-full bg-gray-100 hover:bg-[#E1EDFF] hover:text-[#1A3673] text-gray-400 transition"
              title="Back to Dashboard"
            >
              <ChevronLeft size={16} />
            </button>
            <div className="min-w-0">
              {/* Title row */}
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-[#1A3673] leading-tight">{coversheet.name}</h2>
              </div>


            </div>
          </div>

        </div>

        {/* ── Tiles bar: CIN · Phase · Status · Role · Tab Visibility ── */}
        <div className="px-6 py-2 border-t border-gray-100 bg-gray-50 flex items-center justify-between gap-3 flex-wrap">
          {/* Left: four tiles */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* CIN */}
            <span className="text-xs font-bold text-gray-700 bg-gray-200 rounded-full px-2.5 py-0.5">{coversheet.cin}</span>

            {/* Phase tile */}
            {!configLoading && !configFailed && (() => {
              const phases = coversheetConfig?.coversheet_phases ?? [];
              const activePhase = phases.find(p => p.cvrsht_id === selectedPhaseId) ?? phases[0];
              if (!activePhase) return null;
              const phaseName = activePhase.phase_name ?? activePhase.coversheet_phase ?? '';
              const phaseUpper = phaseName.toUpperCase();
              const phaseClass = phaseUpper === 'MVA' ? 'badge-mva'
                : (phaseUpper === 'SCRN' || phaseUpper === 'SCREENING') ? 'badge-screening'
                : phaseUpper === 'CLOSING' ? 'badge-closing'
                : 'badge-draft';
              const hasMultiple = phases.length > 1;
              return (
                <div className="relative" ref={phaseDropdownRef}>
                  <button
                    onClick={() => { if (hasMultiple) setPhaseOpen(v => !v); }}
                    className={`badge ${phaseClass} flex items-center gap-1 ${hasMultiple ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                    title={hasMultiple ? 'Click to switch phase' : phaseName}
                  >
                    <span className="text-xs font-bold">{phaseName}</span>
                    {hasMultiple && <ChevronDown size={9} />}
                  </button>
                  {phaseOpen && hasMultiple && (
                    <div className="absolute left-0 top-6 z-50 bg-white rounded-lg shadow-xl border border-gray-100 py-1 min-w-[150px]">
                      {phases.map(p => {
                        const pName = p.phase_name ?? p.coversheet_phase ?? '';
                        const pU = pName.toUpperCase();
                        const pCls = pU === 'MVA' ? 'badge-mva'
                          : (pU === 'SCRN' || pU === 'SCREENING') ? 'badge-screening'
                          : pU === 'CLOSING' ? 'badge-closing'
                          : 'badge-draft';
                        const isSelected = p.cvrsht_id === selectedPhaseId;
                        return (
                          <button
                            key={p.cvrsht_id}
                            onClick={() => handlePhaseChange(p.cvrsht_id)}
                            className={`w-full text-left px-3 py-1.5 text-xs hover:bg-gray-50 flex items-center gap-2 ${isSelected ? 'font-semibold text-[#1A3673]' : 'text-gray-600'}`}
                          >
                            <span className={`badge ${pCls} text-[9px]`}>{pName}</span>
                            <span className="truncate">{p.cvrsht_id}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Status tile — read-only, highlights active status from API */}
            {!configLoading && !configFailed && (() => {
              const phases = coversheetConfig?.coversheet_phases ?? [];
              const activePhase = phases.find(p => p.cvrsht_id === selectedPhaseId) ?? phases[0];
              if (!activePhase) return null;
              const phaseStatus = activePhase.cvrsht_actn_stts_cd ?? '';
              const currentIdx  = WORKFLOW_STAGES.findIndex(w => w.key === phaseStatus);
              return (
                <div className="relative" ref={statusDropdownRef}>
                  <button
                    onClick={() => setStatusOpen(v => !v)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold bg-[#EEF3FB] text-[#1A3673] border-[#1A3673]/20 cursor-pointer"
                    title="View workflow status"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#1A3673] flex-shrink-0" />
                    {phaseStatus ? formatStatusLabel(phaseStatus) : 'No Status'}
                    <ChevronDown size={9} style={{ transform: statusOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
                  </button>
                  {statusOpen && (
                    <div className="absolute left-0 top-7 z-50 bg-white rounded-lg shadow-xl border border-gray-100 py-2 min-w-[300px]">
                      <p className="px-3 pt-1 pb-2 text-[9px] font-semibold text-gray-400 uppercase tracking-wider">Workflow Status</p>
                      {WORKFLOW_STAGES.map((stage, idx) => {
                        const isCurrent = stage.key === phaseStatus;
                        const isPast    = currentIdx >= 0 && idx < currentIdx;
                        const isDone    = isCurrent || isPast;
                        return (
                          <div
                            key={stage.key}
                            className={`flex items-center gap-2.5 px-3 py-1.5 text-xs
                              ${isCurrent ? 'bg-[#E1EDFF]/70 font-semibold text-[#1A3673]' : isPast ? 'text-gray-400' : 'text-gray-500'}`}
                          >
                            {/* Dot */}
                            <div style={{
                              width: 8, height: 8, borderRadius: '50%', flexShrink: 0,
                              background: isDone ? '#1A3673' : '#e5e7eb',
                              border: `2px solid ${isDone ? '#1A3673' : '#d1d5db'}`,
                            }} />
                            <span className="flex-1">{stage.label}</span>
                            {isPast && <span className="text-[#1A3673] font-bold text-sm leading-none">✓</span>}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}


          </div>

          {/* Right: Tab-contextual Action buttons + Tab Visibility */}
          <div className="flex items-center gap-2 flex-wrap">

            {/* Coversheet tab → Submit to ServiceNow (requires submit_review + status = pending_business_review) */}
            {activeTab === 'coversheet' && (() => {
              const hasPerm = can('submit_review');
              const phases = coversheetConfig?.coversheet_phases ?? [];
              const activePhase = phases.find(p => p.cvrsht_id === selectedPhaseId) ?? phases[0];
              const currentStatus = activePhase?.cvrsht_actn_stts_cd ?? '';
              const isPendingBusinessReview = currentStatus === 'pending_business_review';
              const allowed = hasPerm && isPendingBusinessReview;
              const title = !hasPerm
                ? 'You do not have permission to submit'
                : !isPendingBusinessReview
                  ? 'Only available when status is Pending Business Review'
                  : '';
              return (
                <button
                  onClick={() => allowed && showToast('Submit to ServiceNow triggered', 'info')}
                  disabled={!allowed}
                  title={title}
                  className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition
                    ${allowed ? 'text-white bg-[#1A3673] hover:bg-[#2861BB] cursor-pointer' : 'text-gray-400 bg-gray-100 border border-gray-200 cursor-not-allowed opacity-60'}`}
                >
                  <Send size={11} /> Submit to ServiceNow
                </button>
              );
            })()}

            {/* Overview tab → Approve + Reject (requires approve_reject) */}
            {activeTab === 'overview' && (() => {
              const allowed = can('approve_reject');
              return (
                <>
                  <button
                    onClick={() => allowed && showToast('Approved', 'success')}
                    disabled={!allowed}
                    title={!allowed ? 'You do not have permission to approve' : ''}
                    className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition
                      ${allowed ? 'text-white bg-[#00BBBA] hover:opacity-80 cursor-pointer' : 'text-gray-400 bg-gray-100 border border-gray-200 cursor-not-allowed opacity-60'}`}
                  >
                    <ThumbsUp size={11} /> Approve
                  </button>
                  <button
                    onClick={() => allowed && showToast('Rejected', 'error')}
                    disabled={!allowed}
                    title={!allowed ? 'You do not have permission to reject' : ''}
                    className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition
                      ${allowed ? 'text-white bg-[#E3725F] hover:opacity-80 cursor-pointer' : 'text-gray-400 bg-gray-100 border border-gray-200 cursor-not-allowed opacity-60'}`}
                  >
                    <ThumbsDown size={11} /> Reject
                  </button>
                </>
              );
            })()}




          </div>
        </div>

        {/* Tab nav */}
        {(() => {
          const phases = coversheetConfig?.coversheet_phases ?? [];
          const activePhase = phases.find(p => p.cvrsht_id === selectedPhaseId) ?? phases[0];
          const phaseStatus = activePhase?.cvrsht_actn_stts_cd ?? '';
          const highlightedTabs = new Set(STATUS_TAB_HIGHLIGHT[phaseStatus] ?? []);
          return (
          <div className="px-6 flex items-center gap-0 overflow-x-auto border-t border-gray-100">
            {/* Main tabs */}
            {getVisibleTabs().filter(t => t.id !== 'upload').map(tab => {
              const isActive = activeTab === tab.id;
              const isHighlighted = !isActive && highlightedTabs.has(tab.id);
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-all ${
                    isActive
                      ? 'border-[#1A3673] text-[#1A3673] font-semibold'
                      : isHighlighted
                        ? 'border-transparent text-[#B45309] font-semibold'
                        : 'border-transparent text-gray-500 hover:text-[#1A3673] hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                  {isHighlighted && (
                    <span className="absolute top-1.5 right-1 w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                  )}
                </button>
              );
            })}
            {/* Upload Document tab pushed to far right */}
            <div className="ml-auto">
              {(() => {
                const uploadTab = getVisibleTabs().find(t => t.id === 'upload');
                if (!uploadTab) return null;
                const isActive = activeTab === 'upload';
                const isHighlighted = !isActive && highlightedTabs.has('upload');
                return (
                  <button
                    onClick={() => setActiveTab('upload')}
                    className={`relative flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-all ${
                      isActive
                        ? 'border-[#1A3673] text-[#1A3673] font-semibold'
                        : isHighlighted
                          ? 'border-transparent text-[#B45309] font-semibold'
                          : 'border-transparent text-gray-500 hover:text-[#1A3673] hover:border-gray-300'
                    }`}
                  >
                    <Upload size={12} /> {uploadTab.label}
                    {isHighlighted && (
                      <span className="absolute top-1.5 right-1 w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                    )}
                  </button>
                );
              })()}
            </div>
          </div>
          );
        })()}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden px-6 pb-6">
        {activeTab === 'overview' && (
          <div className="pt-6"><OverviewTab
              coversheet={coversheet}
              onEdit={handleEdit}
              coversheetConfig={coversheetConfig}
              onConfigChange={setCoversheetConfig}
              selectedPhaseId={selectedPhaseId}
              onPhaseChange={setSelectedPhaseId}
              phaseOpen={phaseOpen}
              setPhaseOpen={setPhaseOpen}
              phaseDropdownRef={phaseDropdownRef}
              statusOpen={statusOpen}
              setStatusOpen={setStatusOpen}
              statusDropdownRef={statusDropdownRef}
              resolvedRole={resolvedRoles.defaultRole}
            /></div>
        )}
        {activeTab === 'coversheet' && (
          <CoversheetTab
            coversheet={coversheet}
            onEdit={handleEdit}
            coversheetConfig={coversheetConfig}
            onConfigChange={setCoversheetConfig}
            onModelingSaved={handleModelingSaved}
            phaseStatus={(coversheetConfig?.coversheet_phases?.find(p => p.cvrsht_id === selectedPhaseId) ?? coversheetConfig?.coversheet_phases?.[0])?.cvrsht_actn_stts_cd ?? ''}
          />
        )}
        {activeTab === 'data' && (
          <div className="pt-6"><DataUploadTab coversheet={coversheet} onEdit={handleEdit} /></div>
        )}
        {activeTab === 'model' && (
          <div className="pt-6"><FinancialModelTab coversheet={coversheet} onEdit={handleEdit} /></div>
        )}
        {/* activeTab === 'sourcepivot' && (
          <div className="pt-6"><SourcePivotTab coversheet={coversheet} /></div>
        ) */}
        {activeTab === 'scaling' && (
          <div className="pt-6"><ScalingTab coversheet={coversheet} onEdit={handleEdit} onRefetchConfig={refetchConfig} /></div>
        )}
        {activeTab === 'summary' && (
          <div className="pt-6"><FinancialSummaryTab coversheet={coversheet} /></div>
        )}
        {activeTab === 'costs' && (
          <div className="pt-6"><CostPlanTab coversheet={coversheet} onEdit={handleEdit} /></div>
        )}
        {activeTab === 'snow' && (
          <div className="pt-6"><ServiceNowTab coversheet={coversheet} /></div>
        )}
        {activeTab === 'audit' && (
          <div className="pt-6"><AuditTrailTab coversheetId={coversheet.id} /></div>
        )}
        {activeTab === 'upload' && (
          <div className="pt-6"><UploadDocumentTab coversheet={coversheet} onRefetchConfig={refetchConfig} /></div>
        )}
      </div>
    </div>

      {/* MVA History Panel */}
      {showMvaHistory && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/30" onClick={() => setShowMvaHistory(false)} />
          <div className="relative bg-white w-full max-w-lg h-full shadow-2xl flex flex-col overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 bg-[#1A3673]">
              <div>
                <p className="text-sm font-bold text-white">MVA Historical Data</p>
                <p className="text-[11px] text-blue-200 mt-0.5">{coversheet.cin} · {coversheet.name}</p>
              </div>
              <button onClick={() => setShowMvaHistory(false)} className="text-white/70 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-5 space-y-5">
              {/* Summary KPIs */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'MVA Versions', value: '3',        color: 'text-[#1A3673]', bg: 'bg-[#E3F4FD]' },
                  { label: 'Last Refresh', value: 'Feb 2024', color: 'text-[#2861BB]', bg: 'bg-blue-50' },
                ].map(k => (
                  <div key={k.label} className={`rounded-lg p-3 ${k.bg}`}>
                    <p className={`text-xs font-bold ${k.color}`}>{k.value}</p>
                    <p className="text-[10px] text-gray-500 mt-0.5">{k.label}</p>
                  </div>
                ))}
              </div>

              {/* Version history table — real MVA coversheets with same CIN */}
              {(() => {
                const mvaVersions = MOCK_COVERSHEETS
                  .filter(c => c.cin === coversheet.cin && c.type === 'MVA')
                  .sort((a, b) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime());
                return (
              <div className="card overflow-hidden">
                <div className="card-header">
                  <p className="card-title">Version History</p>
                  <span className="text-[10px] text-gray-400">{mvaVersions.length} MVA record{mvaVersions.length !== 1 ? 's' : ''} · click to open</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr>
                        <th className="table-th">Name</th>
                        <th className="table-th">Status</th>
                        <th className="table-th">Created</th>
                        <th className="table-th">Last Modified</th>
                        <th className="table-th">DM</th>
                        <th className="table-th text-center w-8"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {mvaVersions.length === 0 ? (
                        <tr><td colSpan={6} className="table-td text-center text-gray-400 py-4">No other MVA versions found for this CIN</td></tr>
                      ) : mvaVersions.map((mv, i) => {
                        const isCurrent = mv.id === coversheet.id;
                        return (
                          <tr
                            key={mv.id}
                            className={`${i % 2 === 0 ? 'table-row-even' : 'table-row-odd'} ${!isCurrent ? 'cursor-pointer hover:bg-[#E3F4FD] transition' : ''}`}
                            onClick={() => { if (!isCurrent) { setShowMvaHistory(false); navigate(`/coversheet/${mv.id}`); } }}
                          >
                            <td className="table-td font-medium text-[#1A3673]">
                              {mv.name}
                              {isCurrent && <span className="ml-1.5 text-[9px] font-semibold bg-[#1A3673] text-white rounded-full px-1.5 py-0.5">Current</span>}
                            </td>
                            <td className="table-td">
                              <span className={`badge text-[9px] ${mv.status === 'Approved' ? 'badge-approved' : mv.status === 'In Progress' ? 'badge-progress' : mv.status === 'In Review' ? 'badge-review' : mv.status === 'Draft' ? 'badge-draft' : 'badge-inactive'}`}>
                                {mv.status}
                              </span>
                            </td>
                            <td className="table-td text-gray-500">{mv.createdDate}</td>
                            <td className="table-td text-gray-400">{mv.lastModified}</td>
                            <td className="table-td text-gray-500">{mv.demandManager}</td>
                            <td className="table-td text-center">
                              {!isCurrent && (
                                <button
                                  onClick={e => { e.stopPropagation(); setShowMvaHistory(false); navigate(`/coversheet/${mv.id}`); }}
                                  className="inline-flex items-center gap-1 text-[#44B8F3] hover:text-[#1A3673] transition"
                                  title="Open this MVA"
                                >
                                  <ExternalLink size={12} />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
                );
              })()}

            </div>
          </div>
        </div>
      )}
    </>
  );
}
