import { useState } from 'react';
import { Plus, Trash2, Save, RefreshCw, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { MOCK_USERS, PORTFOLIO_GROUPS } from '../data/mockData';

export default function AdminPage() {
  const { can } = useAuth();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState('dropdown');

  if (!can('access_admin')) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4 text-3xl">🔒</div>
          <h2 className="text-lg font-semibold text-[#1A3673] mb-2">Access Restricted</h2>
          <p className="text-gray-500 text-sm">Admin panel is only accessible to users with the Governance role.</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'dropdown', label: 'Dropdown Config' },
    { id: 'users', label: 'User Management' },
    { id: 'integration', label: 'Integration Config' },
    { id: 'status', label: 'Integration Status' },
  ];

  return (
    <div className="p-6 max-w-6xl">
      <div className="mb-5">
        <h1 className="text-2xl font-light text-[#1A3673]">Admin <span className="font-bold">Panel</span></h1>
        <p className="text-xs text-gray-500 mt-0.5">Manage dropdowns, users, and integration settings</p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-6 border-b border-gray-200 mb-6">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={activeTab === t.id ? 'tab-active' : 'tab-inactive'}>
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'dropdown' && <DropdownConfigTab showToast={showToast} />}
      {activeTab === 'users' && <UserManagementTab showToast={showToast} />}
      {activeTab === 'integration' && <IntegrationConfigTab showToast={showToast} />}
      {activeTab === 'status' && <IntegrationStatusTab />}
    </div>
  );
}

function DropdownConfigTab({ showToast }) {
  const [groups, setGroups] = useState(Object.keys(PORTFOLIO_GROUPS));
  const [portfolios, setPortfolios] = useState(
    Object.fromEntries(Object.entries(PORTFOLIO_GROUPS))
  );
  const [newGroup, setNewGroup] = useState('');
  const [selectedGroup, setSelectedGroup] = useState(groups[0]);
  const [newPortfolio, setNewPortfolio] = useState('');

  const statuses = ['Draft', 'In Progress', 'In Review', 'Approved', 'Inactive'];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      {/* Portfolio Groups */}
      <div className="card">
        <div className="card-header"><div className="card-title">Portfolio Groups</div></div>
        <div className="p-4 space-y-3">
          {groups.map(g => (
            <div key={g} className="flex items-center gap-2">
              <span className="flex-1 text-sm text-gray-800 bg-gray-50 rounded px-3 py-1.5 border border-gray-100">{g}</span>
              <button onClick={() => { setGroups(p => p.filter(x => x !== g)); showToast(`Removed "${g}"`, 'info'); }}
                className="text-[#E3725F] hover:opacity-70"><Trash2 size={14} /></button>
            </div>
          ))}
          <div className="flex gap-2 mt-2">
            <input className="form-input text-xs flex-1" placeholder="New portfolio group name"
              value={newGroup} onChange={e => setNewGroup(e.target.value)} />
            <button className="btn-primary text-xs py-1 px-3" onClick={() => {
              if (newGroup.trim()) { setGroups(p => [...p, newGroup.trim()]); setPortfolios(p => ({ ...p, [newGroup.trim()]: [] })); setNewGroup(''); showToast('Group added', 'success'); }
            }}><Plus size={12} /></button>
          </div>
        </div>
      </div>

      {/* Portfolios */}
      <div className="card">
        <div className="card-header"><div className="card-title">Portfolios</div></div>
        <div className="p-4 space-y-3">
          <div>
            <label className="form-label">Portfolio Group</label>
            <select className="form-select text-xs" value={selectedGroup} onChange={e => setSelectedGroup(e.target.value)}>
              {groups.map(g => <option key={g}>{g}</option>)}
            </select>
          </div>
          {(portfolios[selectedGroup] ?? []).map(p => (
            <div key={p} className="flex items-center gap-2">
              <span className="flex-1 text-sm text-gray-800 bg-gray-50 rounded px-3 py-1.5 border border-gray-100">{p}</span>
              <button onClick={() => { setPortfolios(prev => ({ ...prev, [selectedGroup]: prev[selectedGroup].filter(x => x !== p) })); showToast(`Removed "${p}"`, 'info'); }}
                className="text-[#E3725F] hover:opacity-70"><Trash2 size={14} /></button>
            </div>
          ))}
          <div className="flex gap-2 mt-2">
            <input className="form-input text-xs flex-1" placeholder="New portfolio name"
              value={newPortfolio} onChange={e => setNewPortfolio(e.target.value)} />
            <button className="btn-primary text-xs py-1 px-3" onClick={() => {
              if (newPortfolio.trim()) { setPortfolios(prev => ({ ...prev, [selectedGroup]: [...(prev[selectedGroup] ?? []), newPortfolio.trim()] })); setNewPortfolio(''); showToast('Portfolio added', 'success'); }
            }}><Plus size={12} /></button>
          </div>
        </div>
      </div>

      {/* Status Values */}
      <div className="card">
        <div className="card-header"><div className="card-title">Status Values</div></div>
        <div className="p-4 space-y-2">
          {statuses.map(s => (
            <div key={s} className="flex items-center gap-2">
              <span className={`badge flex-shrink-0 ${s === 'Draft' ? 'badge-draft' : s === 'In Progress' ? 'badge-progress' : s === 'In Review' ? 'badge-review' : s === 'Approved' ? 'badge-approved' : 'badge-inactive'}`}>{s}</span>
              <span className="flex-1 text-xs text-gray-500">System-defined status</span>
              <span className="text-xs text-gray-300">Read-only</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function UserManagementTab({ showToast }) {
  const [users] = useState(MOCK_USERS);

  return (
    <div className="card overflow-hidden">
      <div className="card-header"><div className="card-title">Users & Role Assignments ({users.length})</div></div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr>
              <th className="table-th">User</th>
              <th className="table-th">Email</th>
              <th className="table-th">Assigned Roles</th>
              <th className="table-th">CIN Access</th>
              <th className="table-th">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={u.id} className={i % 2 === 0 ? 'table-row-even' : 'table-row-odd'}>
                <td className="table-td">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-[#1A3673] text-white text-xs font-bold flex items-center justify-center flex-shrink-0">{u.avatar}</div>
                    <span className="font-medium text-sm text-[#1A3673]">{u.name}</span>
                  </div>
                </td>
                <td className="table-td text-xs text-gray-500">{u.email}</td>
                <td className="table-td">
                  <div className="flex flex-wrap gap-1">
                    {u.roles.map(r => (
                      <span key={r} className="badge badge-progress text-[10px]">{r}</span>
                    ))}
                  </div>
                </td>
                <td className="table-td text-xs">
                  {u.cinAccess.includes('ALL') ? <span className="badge badge-approved text-[10px]">All CINs</span> : <span className="text-gray-500">{u.cinAccess.length} CINs</span>}
                </td>
                <td className="table-td">
                  <button className="btn-text text-xs text-[#44B8F3]" onClick={() => showToast(`Edit user ${u.name} (coming soon)`, 'info')}>Edit Roles</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function IntegrationConfigTab({ showToast }) {
  const [config, setConfig] = useState({
    snowUrl: 'https://elevancehealth.service-now.com/api/now/table',
    snowApiKey: '••••••••••••••••••••••••••••••••',
    spMedicalUrl: 'https://elevancehealth.sharepoint.com/sites/mcm/Shared%20Documents/Medical_Scaling',
    spRxUrl: 'https://elevancehealth.sharepoint.com/sites/mcm/Shared%20Documents/Rx_Scaling',
    syncInterval: '15',
  });

  const handleSave = () => showToast('Integration configuration saved', 'success');

  return (
    <div className="card max-w-2xl">
      <div className="card-header"><div className="card-title">Integration Configuration</div></div>
      <div className="p-5 space-y-4">
        <div>
          <p className="section-header">ServiceNow (SNOW)</p>
          <div className="space-y-3">
            <div>
              <label className="form-label">SNOW API Endpoint URL</label>
              <input className="form-input text-xs" value={config.snowUrl} onChange={e => setConfig(p => ({ ...p, snowUrl: e.target.value }))} />
            </div>
            <div>
              <label className="form-label">API Key / Token</label>
              <input className="form-input text-xs font-mono" value={config.snowApiKey} onChange={e => setConfig(p => ({ ...p, snowApiKey: e.target.value }))} type="password" />
            </div>
          </div>
        </div>
        <div>
          <p className="section-header">SharePoint Scaling Tools</p>
          <div className="space-y-3">
            <div>
              <label className="form-label">Medical Scaling Tool URL</label>
              <input className="form-input text-xs" value={config.spMedicalUrl} onChange={e => setConfig(p => ({ ...p, spMedicalUrl: e.target.value }))} />
            </div>
            <div>
              <label className="form-label">Rx Scaling Tool URL</label>
              <input className="form-input text-xs" value={config.spRxUrl} onChange={e => setConfig(p => ({ ...p, spRxUrl: e.target.value }))} />
            </div>
          </div>
        </div>
        <div>
          <label className="form-label">Reconciliation Sync Interval (minutes)</label>
          <input className="form-input text-xs w-24" type="number" value={config.syncInterval}
            onChange={e => setConfig(p => ({ ...p, syncInterval: e.target.value }))} />
        </div>
        <button className="btn-primary flex items-center gap-1.5" onClick={handleSave}>
          <Save size={13} /> Save Configuration
        </button>
      </div>
    </div>
  );
}

function IntegrationStatusTab() {
  const [syncing, setSyncing] = useState(false);

  const reconErrors = [
    { cin: 'CIN-2024-002', type: 'Benefit Plan Mismatch', detail: 'BP-2024-002-A not found in SNOW record SNOW-87501', severity: 'error' },
    { cin: 'CIN-2024-002', type: 'Updated Field', detail: 'metric_type changed in SNOW from "Hard Savings" to "COC-FI"', severity: 'warning' },
  ];

  return (
    <div className="space-y-5 max-w-4xl">
      {/* Status cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="card p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="card-title text-sm">ServiceNow Connection</p>
            <span className="flex items-center gap-1.5 text-xs text-[#00BBBA] font-medium"><CheckCircle size={13} /> Connected</span>
          </div>
          <div className="space-y-2 text-xs text-gray-600">
            <div className="flex justify-between"><span>Instance:</span><span className="font-medium">elevancehealth.service-now.com</span></div>
            <div className="flex justify-between"><span>Last Reconciliation:</span><span className="font-medium">2024-01-28 14:00 UTC</span></div>
            <div className="flex justify-between"><span>Next Run:</span><span className="font-medium">2024-01-28 14:15 UTC</span></div>
            <div className="flex justify-between"><span>Records Synced:</span><span className="font-medium">247</span></div>
            <div className="flex justify-between text-[#E3725F]"><span>Errors:</span><span className="font-bold">2</span></div>
          </div>
        </div>

        <div className="card p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="card-title text-sm">SharePoint Sync</p>
            <span className="flex items-center gap-1.5 text-xs text-[#00BBBA] font-medium"><CheckCircle size={13} /> Connected</span>
          </div>
          <div className="space-y-2 text-xs text-gray-600">
            <div className="flex justify-between"><span>Site:</span><span className="font-medium">elevancehealth.sharepoint.com/mcm</span></div>
            <div className="flex justify-between"><span>Medical Scaling:</span><span className="font-medium text-[#00BBBA]">✓ Available</span></div>
            <div className="flex justify-between"><span>Rx Scaling:</span><span className="font-medium text-[#00BBBA]">✓ Available</span></div>
            <div className="flex justify-between"><span>Last Sync:</span><span className="font-medium">2024-01-28 12:00 UTC</span></div>
          </div>
        </div>
      </div>

      {/* Reconciliation errors */}
      <div className="card">
        <div className="card-header">
          <div className="card-title flex items-center gap-2">
            <AlertTriangle size={14} className="text-[#E3725F]" />
            Reconciliation Errors ({reconErrors.length})
          </div>
          <button className="btn-outline text-xs flex items-center gap-1.5 py-1" onClick={() => { setSyncing(true); setTimeout(() => { setSyncing(false); }, 2000); }}>
            <RefreshCw size={11} className={syncing ? 'animate-spin' : ''} /> Re-run Reconciliation
          </button>
        </div>
        <div className="divide-y divide-gray-50">
          {reconErrors.map((err, i) => (
            <div key={i} className="px-4 py-3 flex items-start gap-3">
              {err.severity === 'error'
                ? <XCircle size={16} className="text-[#E3725F] flex-shrink-0 mt-0.5" />
                : <AlertTriangle size={16} className="text-orange-500 flex-shrink-0 mt-0.5" />}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-semibold text-[#1A3673]">{err.type}</span>
                  <span className="font-mono text-xs text-[#44B8F3]">{err.cin}</span>
                  <span className={`badge text-[10px] ${err.severity === 'error' ? 'badge-review' : 'bg-orange-100 text-orange-600'}`}>
                    {err.severity}
                  </span>
                </div>
                <p className="text-xs text-gray-600">{err.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
