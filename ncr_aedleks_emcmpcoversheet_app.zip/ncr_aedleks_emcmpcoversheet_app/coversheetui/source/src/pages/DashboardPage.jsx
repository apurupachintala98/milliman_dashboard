import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, X, Search, Filter, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Loader2 } from 'lucide-react';
import { coversheetApi } from '../config/apiConfig';
import { useTableFilter } from '../hooks/useTableFilter';
import { useTableSort } from '../hooks/useTableSort';
import { useGlobalSearch } from '../hooks/useGlobalSearch';

function StatusBadge({ status }) {
  const map = {
    'Draft':       'badge-draft',
    'Submitted':   'badge-progress',
    'Awaiting FM': 'badge-awaiting',
    'In Review':   'badge-review',
    'Approved':    'badge-approved',
    'Inactive':    'badge-inactive',
  };

  return (
    <span className={map[status] || 'badge-draft'}>
      {status}
    </span>
  );
}

function TypeBadge({ type }) {
  const map = {
    'Screening': 'badge-screening', 'MVA': 'badge-mva', 'Closing': 'badge-closing',
  };
  const cls = map[type] || 'badge-draft';
  return <span className={cls}>{type || '—'}</span>;
}

const normalizeStatus = (s) => {
  if (!s) return 'Draft';
  const map = {
    'draft':       'Draft',
    'submitted':   'Submitted',
    'awaiting fm': 'Awaiting FM',
    'awaitingfm':  'Awaiting FM',
    'in review':   'In Review',
    'inreview':    'In Review',
    'approved':    'Approved',
    'inactive':    'Inactive',
    'in progress': 'In Progress',
  };
  return map[s.toLowerCase().trim()] ?? (s.charAt(0).toUpperCase() + s.slice(1));
};

const mapApiItem = (item) => ({
  id: item.cvrsht_id,
  cin: item.u_cin ?? '—',
  name: item.short_description ?? '—',
  type: item.coversheet_phase ?? null,
  status: item.cvrsht_actn_stts_cd ? normalizeStatus(item.cvrsht_actn_stts_cd) : '—',
  createdDate: item.creatd_dtm ? new Date(item.creatd_dtm).toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }) : '—',
  lastModified: item.updtd_dtm ? new Date(item.updtd_dtm).toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }) : '—',
  portfolio: item.primary_portfolio_name ?? '—',
  portfolioGroup: item.primary_portfolio_u_portfolio_group ?? '—',
  demandManager: item.demand_manager_name ?? '—',
  backupDM: item.u_demand_manager_backup_name ?? null,
  financialAnalyst: item.u_financial_analyst_name ?? '—',
  backupFA: item.u_backup_financial_analyst_name ?? null,
  hasReconciliationError: false,
  totalBenefitPlans: item.totl_bnft_plans_cnt ?? 0,
  totalCostPlans: item.totl_cost_plans_cnt ?? 0,
});

export default function DashboardPage() {
  const navigate = useNavigate();

  const [coversheets, setCoversheets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setApiError(null);
    coversheetApi.listCoversheets({ page: 1, page_size: 100, sort_by: 'creatd_dtm', sort_order: 'desc' })
      .then(data => {
        const rows = Array.isArray(data) ? data
          : (data.items ?? data.coversheets ?? data.data ?? data.results ?? []);
        setCoversheets(rows.map(mapApiItem));
      })
      .catch(err => setApiError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const allCoversheets = coversheets;
  const hasReconError = false;

  const allDMs       = [...new Set(allCoversheets.map(c => c.demandManager).filter(v => v && v !== '—'))];
  const allFAs       = [...new Set(allCoversheets.map(c => c.financialAnalyst).filter(v => v && v !== '—'))];
  const allBackupDMs = [...new Set(allCoversheets.map(c => c.backupDM).filter(Boolean))];
  const allBackupFAs = [...new Set(allCoversheets.map(c => c.backupFA).filter(Boolean))];

  // ── Filter hook (text-based fields: cin, name) ──────────────────────────
  const {
    pendingFilters,
    isFilterOpen,
    setIsFilterOpen,
    updatePendingFilter,
    applyFilters,
    clearPendingFilters,
    clearAllFilters,
    cancelFilters,
    activeFilterCount,
    filteredData,
  } = useTableFilter(allCoversheets, {
    cin: '',
    name: '',
    type: '',
    portfolioGroup: '',
    portfolio: '',
    status: '',
    demandManager: '',
    backupDM: '',
    financialAnalyst: '',
    backupFA: '',
  });

  // ── Global search hook ───────────────────────────────────────────────────
  const { searchTerm: globalSearch, setSearchTerm: setGlobalSearch, searchedData } = useGlobalSearch(filteredData);

  // ── Sort hook ────────────────────────────────────────────────────────────
  const { sortField, sortDir, handleSort, sortedData } = useTableSort(searchedData, 'createdDate', 'desc');

  // ── Pagination ───────────────────────────────────────────────────────────
  const [pageSize, setPageSize] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.max(1, Math.ceil(sortedData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const pagedData = sortedData.slice((safePage - 1) * pageSize, safePage * pageSize);

  const handleSearch = (val) => { setGlobalSearch(val); setCurrentPage(1); };
  const handleApplyFilters = () => { applyFilters(); setCurrentPage(1); };
  const handleClearAllFilters = () => { clearAllFilters(); setGlobalSearch(''); setCurrentPage(1); };

  const allTypes     = [...new Set(allCoversheets.map(c => c.type).filter(Boolean))];
  const allStatuses  = [...new Set(allCoversheets.map(c => c.status).filter(Boolean))];
  const allPortfolioGroups = [...new Set(allCoversheets.map(c => c.portfolioGroup).filter(v => v && v !== '—'))];
  const availablePortfolios = pendingFilters.portfolioGroup
    ? [...new Set(allCoversheets.filter(c => c.portfolioGroup === pendingFilters.portfolioGroup).map(c => c.portfolio).filter(v => v && v !== '—'))]
    : [...new Set(allCoversheets.map(c => c.portfolio).filter(v => v && v !== '—'))];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Loader2 size={32} className="animate-spin text-[#1A3673] mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Loading coversheets...</p>
        </div>
      </div>
    );
  }

  if (apiError) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center max-w-md">
          <AlertTriangle size={32} className="text-[#E3725F] mx-auto mb-3" />
          <h2 className="text-base font-semibold text-[#1A3673] mb-1">Failed to load coversheets</h2>
          <p className="text-gray-500 text-sm mb-4">{apiError}</p>
          <button onClick={() => window.location.reload()} className="px-4 py-2 bg-[#1A3673] text-white text-sm rounded-lg hover:bg-[#2861BB] transition">Retry</button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Reconciliation error banner */}
      {hasReconError && (
        <div className="mb-4 flex items-center gap-3 bg-[#FBEAE7] border border-[#E3725F]/30 text-[#E3725F] rounded-lg px-4 py-3 text-sm">
          <AlertTriangle size={16} className="flex-shrink-0" />
          <span className="flex-1">SNOW reconciliation error detected — one or more coversheets have benefit plan mismatches.</span>
          <button onClick={() => navigate('/admin')} className="underline text-xs font-medium">View in Admin →</button>
        </div>
      )}

      {/* Page header */}
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-light text-[#1A3673]">Cost of Care Value Realization (CoCVR) <span className="font-bold">Coversheets</span></h1>
      </div>

      {/* Filter Popup Modal */}
      {isFilterOpen && (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={cancelFilters}>
          <div style={{ background:'#fff', borderRadius:12, maxWidth:900, width:'100%', maxHeight:'90vh', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}
            onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div style={{ padding:'16px 20px', borderBottom:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#1A3673' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <Filter size={20} color="#fff" />
                <h3 style={{ margin:0, fontSize:16, fontWeight:700, color:'#fff' }}>Filter Coversheets</h3>
              </div>
              <button onClick={cancelFilters} style={{ background:'none', border:'none', cursor:'pointer', color:'#fff', padding:4 }}>
                <X size={20} />
              </button>
            </div>

            {/* Body */}
            <div style={{ padding:24, maxHeight:'calc(90vh - 180px)', overflowY:'auto' }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(260px, 1fr))', gap:16 }}>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>CIN</label>
                  <div style={{ display:'flex', border:'1px solid #d1d5db', borderRadius:6, overflow:'hidden', boxSizing:'border-box' }}
                    onFocus={() => {}} // focus handled per child
                  >
                    {/* Locked prefix */}
                    <span style={{ display:'flex', alignItems:'center', padding:'8px 10px', background:'#f3f4f6', fontSize:13, fontWeight:700, color:'#1A3673', borderRight:'1px solid #d1d5db', whiteSpace:'nowrap', userSelect:'none' }}>
                      CIN
                    </span>
                    {/* Number entry only */}
                    <input
                      type="text"
                      value={pendingFilters.cin.replace(/^CIN/i, '')}
                      onChange={e => updatePendingFilter('cin', e.target.value ? `CIN${e.target.value}` : '')}
                      placeholder="Enter number..."
                      style={{ flex:1, padding:'8px 10px', fontSize:13, border:'none', outline:'none', minWidth:0, background:'#fff' }}
                      onFocus={e => e.closest('div').style.borderColor = '#1A3673'}
                      onBlur={e => e.closest('div').style.borderColor = '#d1d5db'}
                    />
                  </div>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Initiative Name</label>
                  <input type="text" value={pendingFilters.name} onChange={e => updatePendingFilter('name', e.target.value)}
                    placeholder="Search name..."
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', boxSizing:'border-box' }}
                    onFocus={e => e.target.style.borderColor = '#1A3673'}
                    onBlur={e => e.target.style.borderColor = '#d1d5db'} />
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Phase</label>
                  <select value={pendingFilters.type} onChange={e => updatePendingFilter('type', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allTypes.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Portfolio Group</label>
                  <select value={pendingFilters.portfolioGroup} onChange={e => { updatePendingFilter('portfolioGroup', e.target.value); updatePendingFilter('portfolio', ''); }}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allPortfolioGroups.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Portfolio</label>
                  <select value={pendingFilters.portfolio} onChange={e => updatePendingFilter('portfolio', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {availablePortfolios.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Status</label>
                  <select value={pendingFilters.status} onChange={e => updatePendingFilter('status', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allStatuses.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Demand Manager</label>
                  <select value={pendingFilters.demandManager} onChange={e => updatePendingFilter('demandManager', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allDMs.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Backup Demand Manager</label>
                  <select value={pendingFilters.backupDM} onChange={e => updatePendingFilter('backupDM', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allBackupDMs.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Financial Analyst</label>
                  <select value={pendingFilters.financialAnalyst} onChange={e => updatePendingFilter('financialAnalyst', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allFAs.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:11, fontWeight:600, color:'#374151', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.5px' }}>Backup Financial Analyst</label>
                  <select value={pendingFilters.backupFA} onChange={e => updatePendingFilter('backupFA', e.target.value)}
                    style={{ width:'100%', padding:'8px 12px', fontSize:13, border:'1px solid #d1d5db', borderRadius:6, outline:'none', background:'#fff' }}>
                    <option value="">All</option>
                    {allBackupFAs.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

              </div>
            </div>

            {/* Footer */}
            <div style={{ padding:'16px 20px', borderTop:'2px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between', background:'#fafafa' }}>
              <button onClick={clearPendingFilters}
                style={{ padding:'8px 16px', fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:6, cursor:'pointer' }}>
                Clear All
              </button>
              <div style={{ display:'flex', gap:10 }}>
                <button onClick={cancelFilters}
                  style={{ padding:'8px 20px', fontSize:13, fontWeight:600, color:'#6b7280', background:'#fff', border:'1px solid #d1d5db', borderRadius:6, cursor:'pointer' }}>
                  Cancel
                </button>
                <button onClick={handleApplyFilters}
                  style={{ padding:'8px 24px', fontSize:13, fontWeight:600, color:'#fff', background:'#1A3673', border:'none', borderRadius:6, cursor:'pointer' }}>
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="card overflow-hidden">

        {/* ── Top bar ── */}
        <div style={{ padding:'10px 14px', borderBottom:'1px solid #e5e7eb', background:'#fafafa', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8 }}>
          {/* Global search with filter – left side */}
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ position:'relative', flex:'0 1 320px' }}>
              <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af', pointerEvents:'none' }} />
              <input
                type="text"
                value={globalSearch}
                onChange={e => handleSearch(e.target.value)}
                placeholder="Search coversheets..."
                style={{ width:'100%', paddingLeft:32, paddingRight: globalSearch ? 28 : 10, paddingTop:6, paddingBottom:6, fontSize:13, border:'1px solid #d1d5db', borderRadius:999, outline:'none', background:'#fff', boxSizing:'border-box' }}
                onFocus={e => e.target.style.borderColor = '#1A3673'}
                onBlur={e => e.target.style.borderColor = '#d1d5db'}
              />
              {globalSearch && (
                <button onClick={() => handleSearch('')}
                  style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', padding:0, color:'#9ca3af', display:'flex', alignItems:'center' }}>
                  <X size={13} />
                </button>
              )}
            </div>
            <button
              onClick={() => setIsFilterOpen(true)}
              onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
              onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
              title="Apply filters"
              style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600, background:'#1A3673', color:'#fff', border:'none', borderRadius:999, padding:'6px 14px', cursor:'pointer', transition:'transform 0.1s ease', position:'relative' }}>
              <Filter size={13} />
              {activeFilterCount > 0 && (
                <span style={{ position:'absolute', top:-6, right:-6, background:'#E3725F', color:'#fff', fontSize:10, fontWeight:700, borderRadius:999, padding:'2px 7px', minWidth:20, textAlign:'center' }}>
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>

          {/* Clear All button – right side */}
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            {activeFilterCount > 0 && (
              <button onClick={handleClearAllFilters}
                style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#E3725F', background:'#FBEAE7', border:'1px solid #EEAA9F', borderRadius:999, padding:'5px 12px', cursor:'pointer' }}>
                <X size={11} /> Clear All
              </button>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#1A3673]">
                {[
                  { label: 'CIN',               field: 'cin' },
                  { label: 'Initiative Name',   field: 'name' },
                  { label: 'Phase',             field: 'type' },
                  { label: 'Portfolio Group',   field: 'portfolioGroup' },
                  { label: 'Portfolio',         field: 'portfolio' },
                  { label: 'Status',            field: 'status' },
                  { label: 'Created',           field: 'createdDate' },
                  { label: 'Last Modified',     field: 'lastModified' },
                  { label: 'Demand Manager',    field: 'demandManager' },
                  { label: 'Backup Demand Manager', field: 'backupDM' },
                  { label: 'Financial Analyst', field: 'financialAnalyst' },
                  { label: 'Backup Financial Analyst', field: 'backupFA' },
                ].map(({ label, field }) => (
                  <th key={label}
                    onClick={() => handleSort(field)}
                    style={{ padding:'0 12px', color:'#fff', fontWeight:600, fontSize:12, whiteSpace:'nowrap', cursor:'pointer', userSelect:'none', height:38 }}>
                    <div style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
                      {label}
                      <span style={{ opacity: sortField === field ? 1 : 0.3 }}>
                        {sortField === field && sortDir === 'asc' ? '▲' : '▼'}
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedData.length === 0 && (
                <tr>
                  <td colSpan={12} className="text-center py-12 text-gray-400 text-sm">
                    <Search size={28} className="mx-auto mb-2 text-gray-300" />
                    No coversheets found matching your filters.
                    {activeFilterCount > 0 && <button onClick={handleClearAllFilters} className="ml-2 text-[#1A3673] underline text-xs">Clear filters</button>}
                  </td>
                </tr>
              )}
              {pagedData.map((cs, i) => (
                <tr key={cs.id}
                  className={`${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'} hover:bg-[#E3F4FD]/40 cursor-pointer transition`}
                  onClick={() => navigate(`/coversheet/${cs.id}`)}>
                  <td className="table-td">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-xs text-[#1A3673] font-semibold">{cs.cin}</span>
                      {cs.hasReconciliationError && <span title="SNOW reconciliation error"><AlertTriangle size={11} className="text-[#E3725F]" /></span>}
                    </div>
                  </td>
                  <td className="table-td">
                    <span className="text-[#1A3673] font-medium text-xs leading-snug">{cs.name}</span>
                  </td>
                  <td className="table-td"><TypeBadge type={cs.type} /></td>
                  <td className="table-td text-xs">{cs.portfolioGroup}</td>
                  <td className="table-td text-xs">{cs.portfolio}</td>
                  <td className="table-td"><StatusBadge status={cs.status} /></td>
                  <td className="table-td text-xs text-gray-500">{cs.createdDate}</td>
                  <td className="table-td text-xs text-gray-500">{cs.lastModified}</td>
                  <td className="table-td text-xs">{cs.demandManager}</td>
                  <td className="table-td text-xs text-gray-500">{cs.backupDM ?? '—'}</td>
                  <td className="table-td text-xs">{cs.financialAnalyst}</td>
                  <td className="table-td text-xs text-gray-500">{cs.backupFA ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      {/* Pagination footer */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', borderTop:'1px solid #e5e7eb', background:'#fafafa', flexWrap:'wrap', gap:8 }}>
        {/* Left: rows per page */}
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span style={{ fontSize:12, color:'#6b7280' }}>Rows per page:</span>
          <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
            style={{ fontSize:12, fontWeight:600, color:'#374151', border:'1px solid #d1d5db', borderRadius:6, padding:'3px 8px', background:'#fff', cursor:'pointer', outline:'none' }}>
            {[10, 25, 50, 100].map(n => <option key={n} value={n}>{n}</option>)}
          </select>
          <span style={{ fontSize:12, color:'#9ca3af', marginLeft:4 }}>
            {sortedData.length === 0 ? '0' : `${(safePage - 1) * pageSize + 1}–${Math.min(safePage * pageSize, sortedData.length)}`} of {sortedData.length}
            {sortedData.length !== allCoversheets.length && ` (filtered from ${allCoversheets.length})`}
          </span>
        </div>

        {/* Right: page navigation */}
        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          <button onClick={() => setCurrentPage(1)} disabled={safePage === 1}
            style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===1 ? 'not-allowed' : 'pointer', color: safePage===1 ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
            <ChevronsLeft size={14} />
          </button>
          <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={safePage === 1}
            style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===1 ? 'not-allowed' : 'pointer', color: safePage===1 ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
            <ChevronLeft size={14} />
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .filter(p => p === 1 || p === totalPages || Math.abs(p - safePage) <= 1)
            .reduce((acc, p, idx, arr) => {
              if (idx > 0 && p - arr[idx - 1] > 1) acc.push('...');
              acc.push(p);
              return acc;
            }, [])
            .map((p, idx) => p === '...' ? (
              <span key={`ellipsis-${idx}`} style={{ padding:'4px 6px', fontSize:12, color:'#9ca3af' }}>…</span>
            ) : (
              <button key={p} onClick={() => setCurrentPage(p)}
                style={{ padding:'4px 10px', borderRadius:6, border:'1px solid', fontSize:12, fontWeight:600, cursor:'pointer', transition:'all .15s',
                  background: safePage === p ? '#1A3673' : '#fff',
                  color:      safePage === p ? '#fff'    : '#374151',
                  borderColor: safePage === p ? '#1A3673' : '#d1d5db' }}>
                {p}
              </button>
            ))}
          <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={safePage === totalPages}
            style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===totalPages ? 'not-allowed' : 'pointer', color: safePage===totalPages ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
            <ChevronRight size={14} />
          </button>
          <button onClick={() => setCurrentPage(totalPages)} disabled={safePage === totalPages}
            style={{ padding:'4px 8px', borderRadius:6, border:'1px solid #d1d5db', background:'#fff', cursor: safePage===totalPages ? 'not-allowed' : 'pointer', color: safePage===totalPages ? '#d1d5db' : '#374151', display:'flex', alignItems:'center' }}>
            <ChevronsRight size={14} />
          </button>
        </div>
      </div>
      </div>
    </div>
  );
}
