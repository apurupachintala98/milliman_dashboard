import { getApiErrorMessage } from '../utils/apiErrorHandler';

const getApiBaseUrl = () => {
  const hostname = window.location.hostname;
  console.log('[API Config] Current hostname:', hostname);

   // If running on localhost, use dev environment
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    const apiUrl = 'https://universalcoversheet-api.edagenaidev.awsdns.internal.das';
    console.log('[API Config] Environment: LOCALHOST → API URL:', apiUrl);
    return apiUrl;
  }

    // Check if hostname contains dev, preprod, or prod
  if (hostname.includes('preprod')) {
    const apiUrl = 'https://universalcoversheet-api.edagenaipreprod.awsdns.internal.das';
    console.log('[API Config] Environment: PREPROD → API URL:', apiUrl);
    return apiUrl;
  }

  if (hostname === 'universalcoversheet.elevancehealth.com') {
    const apiUrl = 'https://universalcoversheet-api.edagenaiprod.awsdns.internal.das';
    console.log('[API Config] Environment: PROD → API URL:', apiUrl);
    return apiUrl;
  }

  if (hostname.includes('dev')) {
    const apiUrl = 'https://universalcoversheet-api.edagenaidev.awsdns.internal.das';
    console.log('[API Config] Environment: DEV → API URL:', apiUrl);
    return apiUrl;
  }

  // Default to dev if environment cannot be determined
  const apiUrl = 'https://universalcoversheet-api.edagenaidev.awsdns.internal.das';
  console.log('[API Config] Environment: DEFAULT (DEV) → API URL:', apiUrl);
  return apiUrl;
};

export const API_BASE_URL = getApiBaseUrl();

// ── LDAP / Auth Endpoints ─────────────────────────────────────────────────────
export const LDAP_VALIDATE_URL = `${API_BASE_URL}/ldap/validate`;

// ── Token refresh deduplication guard ────────────────────────────────────────
let isRefreshingToken = false;
let refreshPromise = null;

async function refreshAuthToken() {
  // Return the in-flight promise if a refresh is already underway
  if (isRefreshingToken && refreshPromise) return refreshPromise;

  isRefreshingToken = true;
  refreshPromise = (async () => {
    try {
      const authRaw = sessionStorage.getItem('auth');
      const userRaw = sessionStorage.getItem('user');
      if (!authRaw) return null;

      const { userId, password } = JSON.parse(authRaw);
      const aplctnCd = userRaw ? (JSON.parse(userRaw).aplctnCd ?? 'emcmp') : 'emcmp';

      const response = await fetch(LDAP_VALIDATE_URL, {
        method: 'POST',
        headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId, password, aplctn_cd: aplctnCd }),
      });

      if (!response.ok) return null;

      const data = await response.json();
      if (data.access_token) {
        localStorage.setItem('jwt_token', data.access_token);
        return data.access_token;
      }
      return null;
    } catch {
      return null;
    } finally {
      isRefreshingToken = false;
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

// ── Upload API Endpoints ───────────────────────────────────────────────────────
export const GET_DOCUMENTS_URL = (cvrsht_id, { file_type, category, include_deleted = false } = {}) => {
  const params = new URLSearchParams();
  if (cvrsht_id)  params.append('cvrsht_id', cvrsht_id);
  if (file_type)  params.append('file_type', file_type);
  if (category)   params.append('category', category);
  params.append('include_deleted', include_deleted);
  return `${API_BASE_URL}/api/v1/document/?${params.toString()}`;
};

export const UPLOAD_DOCUMENT_URL = (category, cvrsht_id) => {
  const params = new URLSearchParams();
  if (category != null) params.append('category', category);
  if (cvrsht_id)        params.append('cvrsht_id', cvrsht_id);
  return `${API_BASE_URL}/api/v1/document/upload?${params.toString()}`;
};

export const DELETE_DOCUMENT_URL = (file_id, permanent = false) =>
  `${API_BASE_URL}/api/v1/document/${file_id}?permanent=${permanent}`;

export const UPDATE_DOCUMENT_URL = (file_id, file_name) =>
  `${API_BASE_URL}/api/v1/document/documents/${file_id}?file_id=${encodeURIComponent(file_id)}&file_name=${encodeURIComponent(file_name)}`;

export const PREVIEW_DOCUMENT_URL = (file_id) =>
  `${API_BASE_URL}/api/v1/document/${file_id}/preview`;

// ── Shared fetch helper ───────────────────────────────────────────────────────
export async function apiFetch(url, options = {}) {
  const token = localStorage.getItem('jwt_token');
  const headers = {
    'accept': 'application/json',
    ...(options.body && !(options.body instanceof FormData) && { 'Content-Type': 'application/json' }),
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(url, { ...options, headers });

  if (response.status === 401) {
    const newToken = await refreshAuthToken();
    if (newToken) {
      const retryHeaders = { ...headers, 'Authorization': `Bearer ${newToken}` };
      return fetch(url, { ...options, headers: retryHeaders });
    }
    // Refresh failed — force logout
    localStorage.removeItem('jwt_token');
    sessionStorage.clear();
    window.location.href = '/';
    return response; // unreachable but satisfies linters
  }

  return response;
}

// ── Upload API helpers ────────────────────────────────────────────────────────
export const uploadApi = {
  fetchDocuments: async (cvrsht_id, options) => {
    const response = await apiFetch(GET_DOCUMENTS_URL(cvrsht_id, options));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('Server returned non-JSON response. Check API availability.');
    return response.json();
  },

  uploadFile: async (file, category, cvrsht_id) => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await apiFetch(UPLOAD_DOCUMENT_URL(category, cvrsht_id), {
      method: 'POST',
      body: formData,
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },

  deleteDocument: async (file_id, permanent = false) => {
    const response = await apiFetch(DELETE_DOCUMENT_URL(file_id, permanent), {
      method: 'DELETE',
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json().catch(() => ({ success: true }));
  },

  updateFileName: async (file_id, file_name) => {
    const response = await apiFetch(UPDATE_DOCUMENT_URL(file_id, file_name), {
      method: 'PUT',
      headers: { 'accept': 'application/json' },
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json().catch(() => ({ success: true }));
  },

  previewDocument: async (file_id) => {
    const response = await apiFetch(PREVIEW_DOCUMENT_URL(file_id), {
      headers: { 'accept': '*/*' },
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (contentType.startsWith('image/')) {
      const blob = await response.blob();
      const base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
      return { type: contentType, image_data: base64, mime_type: contentType };
    }
    return response.json();
  },
};

// ── Modeling Considerations API Endpoints ────────────────────────────────────
export const MODELING_CONSIDERATIONS_URL = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/modeling-considerations/${cvrsht_id}`;

export const modelingApi = {
  get: async (cvrsht_id) => {
    const response = await apiFetch(MODELING_CONSIDERATIONS_URL(cvrsht_id));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },

  update: async (cvrsht_id, payload) => {
    const response = await apiFetch(MODELING_CONSIDERATIONS_URL(cvrsht_id), {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },
};

// ── ServiceNow API Endpoints ──────────────────────────────────────────────────
export const BENEFIT_PLANS_URL = (cvrsht_id, page = 1, page_size = 100, direction = 'to_snow') =>
  `${API_BASE_URL}/api/v1/coversheets/${cvrsht_id}/benefit-plans?page=${page}&page_size=${page_size}&direction=${direction}`;

export const COST_PLANS_URL = (cvrsht_id, page = 1, page_size = 100, direction = 'to_snow') =>
  `${API_BASE_URL}/api/v1/coversheets/${cvrsht_id}/cost-plans?page=${page}&page_size=${page_size}&direction=${direction}`;

export const PUSH_TO_SNOW_URL = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/snow/export/${cvrsht_id}/push-to-snow`;

// ── ServiceNow API helpers ────────────────────────────────────────────────────
export const snowApi = {
  fetchBenefitPlans: async (cvrsht_id, page = 1, page_size = 100, direction = 'to_snow') => {
    const response = await apiFetch(BENEFIT_PLANS_URL(cvrsht_id, page, page_size, direction));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },

  fetchCostPlans: async (cvrsht_id, page = 1, page_size = 100, direction = 'to_snow') => {
    const response = await apiFetch(COST_PLANS_URL(cvrsht_id, page, page_size, direction));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },

  pushToSnow: async (cvrsht_id, payload = {}) => {
    const response = await apiFetch(PUSH_TO_SNOW_URL(cvrsht_id), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        export_format: 'excel',
        include_plans: true,
        snow_target_sys_id: '',
        ...payload,
      }),
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },
};

// ── Coversheet API Endpoints listings ──────────────────────────────────────────────────
export const GET_COVERSHEETS_URL = ({ page = 1, page_size = 20, status, portfolio, market, lob, created_after, created_before, sort_by = 'creatd_dtm', sort_order = 'desc' } = {}) => {
  const params = new URLSearchParams();
  params.append('page', page);
  params.append('page_size', page_size);
  params.append('sort_by', sort_by);
  params.append('sort_order', sort_order);
  if (status)         params.append('status', status);
  if (portfolio)      params.append('portfolio', portfolio);
  if (market)         params.append('market', market);
  if (lob)            params.append('lob', lob);
  if (created_after)  params.append('created_after', created_after);
  if (created_before) params.append('created_before', created_before);
  return `${API_BASE_URL}/api/v1/coversheets?${params.toString()}`;
};

export const GET_RECENT_COVERSHEETS_URL = (limit = 20) =>
  `${API_BASE_URL}/api/v1/coversheets/recent?limit=${limit}`;

export const GET_COVERSHEET_URL = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/coversheets/${encodeURIComponent(cvrsht_id)}`;

export const UPDATE_COVERSHEET_STATUS_URL = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/coversheets/${encodeURIComponent(cvrsht_id)}/status`;

export const DOWNLOAD_COVERSHEET_URL = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/coversheets/${encodeURIComponent(cvrsht_id)}/download-coversheet`;

// ── Coversheet API helpers  ────────────────────────────────────────────────────
export const coversheetApi = {
  listCoversheets: async (params = {}) => {
    const response = await apiFetch(GET_COVERSHEETS_URL(params));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('Server returned non-JSON response. Check API availability.');
    return response.json();
  },

  getRecentCoversheets: async (limit = 20) => {
    const response = await apiFetch(GET_RECENT_COVERSHEETS_URL(limit));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },

  getCoversheet: async (cvrsht_id) => {
    const response = await apiFetch(GET_COVERSHEET_URL(cvrsht_id));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('Server returned non-JSON response. Check API availability.');
    return response.json();
  },

  updateStatus: async (cvrsht_id, sttscd, actnStatus) => {
    const response = await apiFetch(UPDATE_COVERSHEET_STATUS_URL(cvrsht_id), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cvrsht_stts_cd: sttscd ?? null, cvrsht_actn_stts_cd: actnStatus }),
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json().catch(() => ({ success: true }));
  },

  downloadCoversheet: async (cvrsht_id) => {
    const response = await apiFetch(DOWNLOAD_COVERSHEET_URL(cvrsht_id), {
      headers: { 'accept': 'application/octet-stream' },
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const blob = await response.blob();
    const disposition = response.headers.get('Content-Disposition') || '';
    const match = disposition.match(/filename="?([^"]+)"?/);
    const filename = match ? match[1] : `${cvrsht_id}-coversheet.xlsx`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  },
};

// ── FM Generation Status SSE Endpoints ───────────────────────────────────────
export const FM_GENERATION_STATUS_URL    = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/fm-generation/status?cvrsht_id=${encodeURIComponent(cvrsht_id)}`;

export const FM_GENERATION_STREAM_URL    = (cvrsht_id) =>
  `${API_BASE_URL}/api/v1/fm-generation/status/stream?cvrsht_id=${encodeURIComponent(cvrsht_id)}`;

// SSE helper — returns a cleanup function; calls onMessage(data) for each event,
// onDone() when stream closes naturally, onError(err) on connection failure.
// Uses fetch + ReadableStream (not EventSource) so Authorization header can be sent securely.
// Terminal states: completed | failed | not_started — stream auto-closes on these.
export function subscribeToFmGenerationStream(cvrsht_id, { onMessage, onDone, onError } = {}) {
  const token = localStorage.getItem('jwt_token');
  const url   = FM_GENERATION_STREAM_URL(cvrsht_id); // token NEVER in URL — sent via header only

  let cancelled = false;
  const TERMINAL = new Set(['completed', 'failed', 'not_started']);

  (async () => {
    try {
      const response = await fetch(url, {
        headers: {
          'Accept': 'text/event-stream',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      if (!response.ok || !response.body) {
        onError?.(new Error(`SSE connect failed: ${response.status}`));
        return;
      }
      const reader  = response.body.getReader();
      const decoder = new TextDecoder();
      let   buffer  = '';

      while (!cancelled) {
        const { value, done } = await reader.read();
        if (done) { onDone?.(); break; }
        buffer += decoder.decode(value, { stream: true });
        // SSE events are separated by double newline
        const parts = buffer.split(/\n\n/);
        buffer = parts.pop(); // keep incomplete tail
        for (const part of parts) {
          const dataLine = part.split('\n').find(l => l.startsWith('data:'));
          if (!dataLine) continue;
          try {
            const parsed = JSON.parse(dataLine.slice(5).trim());
            onMessage?.(parsed);
            if (TERMINAL.has(parsed.status)) { onDone?.(); return; }
          } catch { /* ignore malformed events */ }
        }
      }
    } catch (err) {
      if (!cancelled) onError?.(err);
    }
  })();

  // Return cleanup — call to cancel the stream
  return () => { cancelled = true; };
}

// ── Financial Model API Endpoint ─────────────────────────────────────────────
export const FINANCIAL_MODEL_URL = (cvrsht_id, params = {}) => {
  const qs = new URLSearchParams();
  if (params.fncl_mdl_type_nm) qs.append('fncl_mdl_type_nm', params.fncl_mdl_type_nm);
  if (params.lob_nm)           qs.append('lob_nm',           params.lob_nm);
  if (params.cncpt_nm)         qs.append('cncpt_nm',         params.cncpt_nm);
  if (params.mrkt_nm)          qs.append('mrkt_nm',          params.mrkt_nm);
  if (params.mrkt_splt_nm)     qs.append('mrkt_splt_nm',     params.mrkt_splt_nm);
  if (params.grn_lght_stts_nm) qs.append('grn_lght_stts_nm', params.grn_lght_stts_nm);
  if (params.year_mnth_nbr)    qs.append('year_mnth_nbr',    params.year_mnth_nbr);
  const query = qs.toString();
  return `${API_BASE_URL}/api/v1/coversheets/${encodeURIComponent(cvrsht_id)}/financial-model${query ? `?${query}` : ''}`;
};

export const financialModelApi = {
  get: async (cvrsht_id, params = {}) => {
    const response = await apiFetch(FINANCIAL_MODEL_URL(cvrsht_id, params));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('Server returned non-JSON response for financial model. Check API availability.');
    return response.json();
  },
};

// ── Membership Scaling API Endpoints ─────────────────────────────────────────
export const MEMBERSHIP_SCALING_APPLY_FCTR_URL = `${API_BASE_URL}/api/v1/membership-scaling/apply-fctr`;
export const MEMBERSHIP_SCALING_PARMS_URL      = `${API_BASE_URL}/api/v1/membership-scaling/parms`;
export const membershipScalingApi = {
  // POST /apply-fctr — smart upsert: calculate + persist to DB
  applyFactor: async (payload) => {
    const response = await apiFetch(MEMBERSHIP_SCALING_APPLY_FCTR_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },

  // GET /parms?cvrsht_id=... — load saved params + results from DB
  getParms: async (cvrsht_id) => {
    const url = `${MEMBERSHIP_SCALING_PARMS_URL}?cvrsht_id=${encodeURIComponent(cvrsht_id)}`;
    const response = await apiFetch(url);
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },
};

// ── Financial Summary API ─────────────────────────────────────────────────────
export const FINANCIAL_SUMMARY_URL = `${API_BASE_URL}/api/v1/financial-summary/calculate`;

export const financialSummaryApi = {
  calculate: async (cvrsht_id) => {
    const response = await apiFetch(FINANCIAL_SUMMARY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cvrsht_id }),
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json();
  },
};

// ── Coversheet Tab Financial Data API ────────────────────────────────────────
export const COVERSHEET_TAB_URL = (cvrsht_id, { view = 'monthly', basis = 'auto' } = {}) => {
  const params = new URLSearchParams();
  params.append('view',  view);
  params.append('basis', basis);
  return `${API_BASE_URL}/api/v1/coversheets/${encodeURIComponent(cvrsht_id)}/coversheet-tab?${params.toString()}`;
};

export const coversheetTabApi = {
  get: async (cvrsht_id, { view = 'monthly', basis = 'auto' } = {}) => {
    const response = await apiFetch(COVERSHEET_TAB_URL(cvrsht_id, { view, basis }));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('Server returned non-JSON response for coversheet tab. Check API availability.');
    return response.json();
  },
};

// ── Config API Endpoint ───────────────────────────────────────────────────────
export const GET_CONFIG_URL = (cin) =>
  `${API_BASE_URL}/api/v1/config/${encodeURIComponent(cin)}`;

// ── Config API helpers ────────────────────────────────────────────────────────
export const configApi = {
  getConfig: async (cin) => {
    const response = await apiFetch(GET_CONFIG_URL(cin));
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('Server returned non-JSON response for config. Check API availability.');
    return response.json();
  },

  updateConfig: async (cin, payload) => {
    const response = await apiFetch(GET_CONFIG_URL(cin), {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const msg = await getApiErrorMessage(response);
      throw new Error(msg);
    }
    return response.json().catch(() => ({ success: true }));
  },
};

export default API_BASE_URL;
