/**
 * Extracts a human-readable error message from an API response.
 * Supports multiple error response formats:
 *   { "detail": "..." }        — FastAPI style
 *   { "error": "..." }         — Generic format
 *   { "message": "..." }       — Common format
 *   { "errors": [...] }        — Array of errors
 *   { "msg": "..." }           — Alternative format
 *   Plain text responses
 */
export const getApiErrorMessage = async (response) => {
  const contentType = response.headers.get('content-type') || '';

  if (contentType.includes('application/json')) {
    try {
      const body = await response.json();

      if (typeof body === 'string') return body;

      if (body.detail) {
        if (Array.isArray(body.detail)) {
          return body.detail.map(d => d.msg || d.message || JSON.stringify(d)).join('; ');
        }
        return String(body.detail);
      }

      if (body.error)   return String(body.error);
      if (body.message) return String(body.message);
      if (body.msg)     return String(body.msg);

      if (Array.isArray(body.errors) && body.errors.length > 0) {
        return body.errors.map(e => e.msg || e.message || String(e)).join('; ');
      }

      return `Request failed: ${response.status} ${response.statusText}`;
    } catch {
      return `Request failed: ${response.status} ${response.statusText}`;
    }
  }

  if (contentType.includes('text/')) {
    try {
      const text = await response.text();
      return text.trim() || `Request failed: ${response.status} ${response.statusText}`;
    } catch {
      return `Request failed: ${response.status} ${response.statusText}`;
    }
  }

  return `Request failed: ${response.status} ${response.statusText}`;
};
