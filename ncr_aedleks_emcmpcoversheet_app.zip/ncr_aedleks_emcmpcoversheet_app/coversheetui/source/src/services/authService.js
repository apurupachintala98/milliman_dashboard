// ── JWT Auth Service (Placeholder) ───────────────────────────────────────────
// TODO: Enable when backend JWT config is ready.
// Integration guide: JWT_Quick_Integration_Guide.md
//
// Steps to enable:
//   1. Uncomment the login() implementation below
//   2. In apiConfig.js, uncomment the Authorization header in apiFetch()
//   3. Update LoginPage.jsx to collect password and call authService.login()
//   4. Update AuthContext.jsx to use authService instead of MOCK_USERS

const TOKEN_KEY = 'jwt_token';
const USER_KEY  = 'jwt_user';

const authService = {
  // TODO: Uncomment when JWT is ready
  // async login(userId, password, aplctn_cd = 'emcmp') {
  //   const base = API_BASE_URL.replace('/api/v1', '');
  //   const response = await fetch(`${base}/ldap/validate`, {
  //     method: 'POST',
  //     headers: { 'Content-Type': 'application/json' },
  //     body: JSON.stringify({ user_id: userId, password, aplctn_cd }),
  //   });
  //   if (!response.ok) {
  //     const err = await response.json().catch(() => ({}));
  //     throw new Error(err.detail || `Login failed: ${response.status}`);
  //   }
  //   const data = await response.json();
  //   localStorage.setItem(TOKEN_KEY, data.access_token);
  //   localStorage.setItem(USER_KEY, JSON.stringify(data.user));
  //   return data;
  // },

  logout() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },

  getToken() {
    return localStorage.getItem(TOKEN_KEY);
  },

  getUser() {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  },

  isAuthenticated() {
    return !!this.getToken();
  },
};

export default authService;
