/**
 * Theme configuration for Coversheet UI
 * Centralized design tokens for colors, typography, and spacing
 */

const theme = {
  colors: {
    // Primary brand colors
    primary: '#1A3673',
    primaryLight: 'rgba(26,54,115,0.03)',
    primaryBorder: 'rgba(26,54,115,0.1)',
    primaryBorderDark: 'rgba(26,54,115,0.15)',
    
    // Accent colors
    blue: '#44B8F3',
    blueLight: '#C7EAFB',
    blueBg: '#E3F4FD',
    blueRow: '#EFF6FF',
    
    // Status colors
    success: '#00BBBA',
    successBg: '#f0fdfa',
    successBorder: '#66D6D6',
    
    warning: '#d97706',
    warningBg: '#fef9ec',
    warningBorder: '#fde68a',
    
    error: '#E3725F',
    errorBg: '#FBEAE7',
    errorBorder: '#EEAA9F',
    errorLight: '#F9DDD8',
    
    info: '#2861BB',
    infoBg: '#E1EDFF',
    infoBorder: '#6A97DF',
    
    // Neutral colors
    white: '#fff',
    gray50: '#fafafa',
    gray100: '#f3f4f6',
    gray200: '#e5e7eb',
    gray300: '#d1d5db',
    gray400: '#9ca3af',
    gray500: '#6b7280',
    gray600: '#4b5563',
    gray700: '#374151',
    gray800: '#1f2937',
    
    // Text colors
    textPrimary: '#1A3673',
    textSecondary: '#6b7280',
    textTertiary: '#9ca3af',
    textDark: '#374151',
  },
  
  fontSize: {
    xs: '10px',
    sm: '11px',
    base: '12px',
    md: '13px',
    lg: '14px',
    xl: '15px',
    '2xl': '16px',
  },
  
  fontWeight: {
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
  },
  
  borderRadius: {
    sm: '6px',
    md: '8px',
    lg: '12px',
    pill: '999px',
  },
  
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '12px',
    lg: '16px',
    xl: '20px',
    '2xl': '24px',
  },
};

export default theme;
