export type UserRole = 'Demand Manager' | 'Financial Analyst' | 'Governance' | 'Read-Only' | 'Admin';
export type CoversheetStatus = 'Draft' | 'In Progress' | 'In Review' | 'Approved' | 'Inactive';
export type CoversheetType = 'Screening' | 'MVA' | 'Closing';

export interface User {
  id: string;
  name: string;
  email: string;
  employeeId: string;
  roles: UserRole[];
  cinAccess: string[]; // 'ALL' means all CINs
  avatar: string;
}

export interface BenefitPlan {
  id: string;
  number: string;
  fiscalPeriod: string;
  market: string;
  lob: string;
  mbu: string;
  sbu: string;
  metric: string;
  metricType: string;
  metricFrequency: string;
  description: string;
  currency: string;
}

export interface CostPlan {
  id: string;
  number: string;
  description: string;
  costType: string;
  metric: string;
  metricType: string;
  metricFrequency: string;
}

export interface Coversheet {
  id: string;
  cin: string;
  snowCardId: string;
  name: string;
  type: CoversheetType;
  portfolioGroup: string;
  portfolio: string;
  status: CoversheetStatus;
  createdDate: string;
  lastModified: string;
  createdBy: string;
  demandManager: string;
  financialAnalyst: string;
  backupDM: string;
  backupFA: string;
  benefitPlans: BenefitPlan[];
  costPlans: CostPlan[];
  hasReconciliationError?: boolean;
  hasFinancialModel?: boolean;
  hasScaling?: boolean;
}

export type AuditChangeType = 'Field Update' | 'Status Change' | 'Added' | 'Removed' | 'Upload' | 'Workflow';

export interface AuditEntry {
  id: string;
  coversheetId: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  changeType: AuditChangeType;
  section: string;
  details: string;
  fieldName?: string;
  previousValue?: string;
  newValue?: string;
}

export interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'warning';
  timestamp: string;
  read: boolean;
  coversheetId?: string;
}

export interface ScalingFactor {
  market: string;
  lob: string;
  mbu: string;
  factor: number;
  membershipCount: number;
}

export interface FinancialModelOutput {
  state: string;
  mbu: string;
  unscaledSavings: number;
  scaledSavings?: number;
  scalingFactor?: number;
}

export interface CostLineItem {
  id: string;
  costType: 'IT Expense' | 'FTE Request' | 'Other';
  description: string;
  amount: number;
  period: string;
  source: 'Uploaded' | 'Manual' | 'SNOW';
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadedBy: string;
  uploadedAt: string;
  topic: string;
  dataType: string;
}
