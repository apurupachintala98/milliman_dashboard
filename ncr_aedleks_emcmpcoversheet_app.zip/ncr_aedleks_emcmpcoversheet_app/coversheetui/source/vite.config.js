import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
        host: true,
        port: 3000, // Your desired port
        allowedHosts: [
          'universalcoversheet.dev.elevancehealth.com',
          'universalcoversheet.preprod.elevancehealth.com',
          'universalcoversheet.elevancehealth.com'
        ]
      },
  preview: {
    host: true,
    port: 3000, 
    allowedHosts: [
      'universalcoversheet.dev.elevancehealth.com',
      'universalcoversheet.preprod.elevancehealth.com',
      'universalcoversheet.elevancehealth.com'
    ]
  }
})
