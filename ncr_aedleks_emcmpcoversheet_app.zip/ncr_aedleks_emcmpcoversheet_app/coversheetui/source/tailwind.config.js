/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Open Sans"', 'sans-serif'],
      },
      colors: {
        brand: {
          navy: '#1A3673',
          'navy-dark': '#231E33',
          sky: '#44B8F3',
          teal: '#00BBBA',
          'teal-mid': '#66D6D6',
          'teal-light': '#B2EBEA',
          'teal-pale': '#D9F5F5',
          coral: '#E3725F',
          salmon: '#EEAA9F',
          blush: '#F7D5CF',
          'pink-pale': '#FBEAE7',
          royal: '#2861BB',
          periwinkle: '#6A97DF',
          lavender: '#E1EDFF',
          'sky-light': '#8FD4F8',
          'ice-blue': '#C7EAFB',
          'pale-blue': '#E3F4FD',
        },
      },
      fontSize: {
        'h1': ['25px', { lineHeight: '1.3', fontWeight: '300' }],
        'h2': ['16px', { lineHeight: '1.4', fontWeight: '700' }],
        'h3': ['14px', { lineHeight: '1.5', fontWeight: '400' }],
        'h4': ['13px', { lineHeight: '1.5', fontWeight: '400' }],
        'h5': ['11px', { lineHeight: '1.4', fontWeight: '300' }],
        'h6': ['10px', { lineHeight: '1.4', fontWeight: '400' }],
        'nav': ['11px', { lineHeight: '1.4', fontWeight: '400' }],
      },
    },
  },
  plugins: [],
}
