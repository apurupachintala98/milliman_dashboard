# Coversheet Application

A React application built with Vite for managing coversheet data.

## Getting Started

### Prerequisites
- Node.js 20.x or higher
- npm

### Installation

```bash
npm install --legacy-peer-deps
```

### Development

Run the development server:

```bash
npm run dev
```

The application will be available at `http://localhost:3000`

### Build

Build the application for production:

```bash
npm run build
```

### Preview

Preview the production build:

```bash
npm run preview
```

## Tech Stack

- **React 18** - UI Library
- **Material-UI (MUI)** - Component Library
- **Vite** - Build Tool
- **React Router** - Routing
- **Day.js** - Date Management
- **ExcelJS** - Excel File Generation
- **DnD Kit** - Drag and Drop

## Project Structure

```
source/
├── public/           # Static assets
├── src/
│   ├── assets/      # Images, icons
│   ├── components/  # React components
│   ├── config/      # Configuration files
│   ├── data/        # Static data
│   ├── utils/       # Utility functions
│   ├── App.jsx      # Main application component
│   ├── main.jsx     # Application entry point
│   └── index.css    # Global styles
└── package.json
```

## Docker

Build the Docker image:

```bash
docker build -t coversheet-app .
```

Run the container:

```bash
docker run -p 3000:3000 coversheet-app
```
