import { useState, useEffect, useRef } from "react";
import {
  SectionHeader,
  FooterButtons,
} from "../components/SharedComponents";
import { fetchToolsByScopes } from "../services/agents";
import { langgraphApi } from "../services/langgraph-api";
import { useNavigate } from "react-router-dom";

// --- Tool Card Icons ---
const MonitorIcon = ({ selected }) => (
  <div
    className="flex items-center justify-center rounded-lg"
    style={{ width: 36, height: 36, backgroundColor: selected ? "#EBF5FB" : "#F0F0F0" }}
  >
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="2" y="3" width="16" height="11" rx="1.5" stroke={selected ? "#0072C6" : "#90A4AE"} strokeWidth="1.5" fill="none" />
      <path d="M7 17H13" stroke={selected ? "#0072C6" : "#90A4AE"} strokeWidth="1.5" strokeLinecap="round" />
      <path d="M10 14V17" stroke={selected ? "#0072C6" : "#90A4AE"} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  </div>
);

const EnvelopeIcon = () => (
  <div className="flex items-center justify-center rounded-lg" style={{ width: 36, height: 36, backgroundColor: "#F0F0F0" }}>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="2" y="4" width="16" height="12" rx="1.5" stroke="#90A4AE" strokeWidth="1.5" fill="none" />
      <path d="M2 6L10 11L18 6" stroke="#90A4AE" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  </div>
);

const CheckFilled = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="11" fill="#0072C6" />
    <path d="M7 12.5L10 15.5L17 8.5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const CircleOutline = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="11" stroke="#B0BEC5" strokeWidth="1.5" fill="none" />
  </svg>
);

const UploadIcon = () => (
  <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
    <path d="M10 3V13M10 3L6 7M10 3L14 7" stroke="#0072C6" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M3 14V16C3 16.55 3.45 17 4 17H16C16.55 17 17 16.55 17 16V14" stroke="#0072C6" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
    <path d="M2 4H14M5 4V3C5 2.45 5.45 2 6 2H10C10.55 2 11 2.45 11 3V4M6.5 7V12M9.5 7V12M3.5 4L4.5 14C4.5 14.55 4.95 15 5.5 15H10.5C11.05 15 11.5 14.55 11.5 14L12.5 4" stroke="#D32F2F" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);


// --- Info Icon for viewing full description ---
const InfoIcon = () => (
  <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
    <circle cx="10" cy="10" r="9" stroke="#0072C6" strokeWidth="1.5" fill="none" />
    <text x="10" y="14.5" textAnchor="middle" fill="#0072C6" fontSize="12" fontWeight="600" fontFamily="sans-serif">i</text>
  </svg>
);

// --- Tool Card ---
function ToolCard({ name, description, selected, type = "monitor", onToggle }) {
  const [showFull, setShowFull] = useState(false);
  const maxChars = 80;
  const isLong = description && description.length > maxChars;
  const truncated = isLong ? description.slice(0, maxChars) + "..." : (description || "");
  return (
    <>
      <div
        className="rounded-xl p-4 cursor-pointer transition-all"
        style={{
          backgroundColor: "#FFFFFF",
          border: selected ? "2px solid #0072C6" : "1px solid #E0E0E0",
          boxShadow: selected ? "0 0 0 1px #0072C6" : "0 1px 3px rgba(0,0,0,0.04)",
          height: 150, display: "flex", flexDirection: "column",
          overflow: "hidden", position: "relative",
        }}
        onClick={onToggle}
      >
        <div className="flex items-start justify-between">
          {type === "monitor" ? <MonitorIcon selected={selected} /> : <EnvelopeIcon />}
          {selected ? <CheckFilled /> : <CircleOutline />}
        </div>
        <div className="mt-3" style={{ flex: 1, overflow: "hidden" }}>
          <p style={{ fontSize: 13, fontWeight: 600, color: selected ? "#1A1A1A" : "#546E7A", lineHeight: "18px", wordBreak: "break-word", margin: "0 0 4px 0" }}>{name}</p>
          <p style={{ fontSize: 11, color: "#90A4AE", lineHeight: "16px", margin: 0 }}>{truncated || "No description"}</p>
        </div>
        {isLong && (
          <button
            onClick={(e) => { e.stopPropagation(); setShowFull(true); }}
            style={{
              position: "absolute", bottom: 8, right: 8,
              background: "rgba(255,255,255,0.9)", border: "1px solid #E0E0E0",
              borderRadius: "50%", width: 26, height: 26,
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            }}
            title="View full description"
          >
            <InfoIcon />
          </button>
        )}
      </div>

      {/* Full description modal */}
      {showFull && (
        <div
          onClick={(e) => { e.stopPropagation(); setShowFull(false); }}
          style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            backgroundColor: "rgba(0,0,0,0.4)", zIndex: 9999,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: "#FFF", borderRadius: 12, padding: "24px 28px",
              maxWidth: 480, width: "90%", maxHeight: "60vh", overflowY: "auto",
              boxShadow: "0 12px 40px rgba(0,0,0,0.15)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
              <p style={{ fontSize: 15, fontWeight: 600, color: "#1A1A1A", margin: 0 }}>{name}</p>
              <button
                onClick={() => setShowFull(false)}
                style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18, color: "#90A4AE", padding: 4 }}
              >✕</button>
            </div>
            <p style={{ fontSize: 13, color: "#546E7A", lineHeight: 1.6, margin: 0 }}>{description}</p>
          </div>
        </div>
      )}
    </>
  );
}

// --- Tools Grid Section ---
function ToolsSection({ tools, toggleTool, selectAll, allSelected, searchTerm, setSearchTerm }) {
  const filteredTools = tools.filter(
    (tool) =>
      tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tool.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <SectionHeader>Tools</SectionHeader>
        <div className="flex items-center gap-3" style={{ flex: 1, maxWidth: 500, marginLeft: 24 }}>
          <span className="text-sm flex-shrink-0" style={{ color: "#78909C", fontWeight: 400, fontSize: 15, letterSpacing: 0.2 }}>Search</span>
          <input
            type="text"
            placeholder="Search tools..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="text-sm"
            style={{ flex: 1, width: 220, height: 36, backgroundColor: "#EDEEEE", border: "none", borderRadius: 8, padding: "0 12px", color: "#5b6770", outline: "none" }}
          />
        </div>
      </div>
      {/* Select All button + disclaimer */}
      {tools.length > 0 && (
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={selectAll}
            style={{
              padding: "6px 16px", borderRadius: 6, fontSize: 13, fontWeight: 600,
              color: allSelected ? "#546E7A" : "#0072C6",
              backgroundColor: allSelected ? "#F0F0F0" : "#EBF5FB",
              border: allSelected ? "1px solid #CFD8DC" : "1px solid #B3D9F2",
              cursor: "pointer",
            }}
          >
            {allSelected ? "Deselect All" : "Select All"}
          </button>
          {allSelected && (
            <span style={{ fontSize: 12, color: "#F57C00", fontWeight: 500, display: "flex", alignItems: "center", gap: 4 }}>
              <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="9" stroke="#F57C00" strokeWidth="1.5" fill="none" />
                <text x="10" y="14" textAnchor="middle" fill="#F57C00" fontSize="12" fontWeight="600">!</text>
              </svg>
              You have selected all tools available
            </span>
          )}
        </div>
      )}

      <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
        {filteredTools.map((tool) => (
          <ToolCard key={tool.id} name={tool.name} description={tool.description} selected={tool.selected} type={tool.type} onToggle={() => toggleTool(tool.id)} />
        ))}
        {filteredTools.length === 0 && (
          <div className="col-span-4 text-center text-gray-400 py-6">No tools found</div>
        )}
      </div>
    </div>
  );
}

// --- Orchestration Section ---
function OrchestrationSection({ value, onChange }) {
  return (
    <div className="rounded-lg bg-white" style={{ border: "1px solid #E0E0E0", boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
      <div className="px-5 py-5">
        <div className="flex items-start">
          <label className="text-sm flex-shrink-0 pr-3 pt-3" style={{ color: "#546E7A", fontWeight: 400 }}>Orchestration Instruction</label>
          <textarea
            className="flex-1 rounded-sm p-3 text-sm resize-none" rows={5}
            value={value} onChange={(e) => onChange(e.target.value)}
            style={{ backgroundColor: "#F5F7F8", border: "1px solid #ECEFF1", outline: "none", color: "#263238" }}
          />
        </div>
      </div>
    </div>
  );
}

// --- STDIO Custom Tool Form (LangGraph only) ---
function StdioToolForm({ onAddTool, agentUuid }) {
  const [toolName, setToolName] = useState("");
  const [toolDescription, setToolDescription] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [isAdding, setIsAdding] = useState(false);

  const inputStyle = { color: "#37474F", backgroundColor: "#F5F7F8", border: "1px solid #ECEFF1", outline: "none" };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) setSelectedFile(file);
  };

  const handleAdd = async () => {
    if (!toolName.trim()) return;
    setIsAdding(true);
    try {
      onAddTool({
        transport: "stdio",
        name: toolName.trim(),
        description: toolDescription.trim(),
        config: { command: "python", args: selectedFile?.name || "" },
        fileName: selectedFile?.name || null,
        file: selectedFile || null,
      });
      setToolName("");
      setToolDescription("");
      setSelectedFile(null);
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <div className="mt-4 pt-4" style={{ borderTop: "1px solid #ECEFF1" }}>
      {/* Tool Name */}
      <div className="mb-4">
        <label className="text-xs font-medium block mb-1.5" style={{ color: "#546E7A" }}>Tool Name</label>
        <input
          type="text" value={toolName} onChange={(e) => setToolName(e.target.value)}
          placeholder="Enter tool name"
          className="w-full px-3 py-2.5 text-sm rounded-sm" style={inputStyle}
        />
      </div>

      {/* Description */}
      <div className="mb-4">
        <label className="text-xs font-medium block mb-1.5" style={{ color: "#546E7A" }}>Description</label>
        <textarea
          value={toolDescription} onChange={(e) => setToolDescription(e.target.value)}
          placeholder="Describe what this tool does"
          className="w-full px-3 py-2.5 text-sm rounded-sm resize-none" rows={3} style={inputStyle}
        />
      </div>

      {/* File Upload */}
      <div className="mb-5">
        <label className="text-xs font-medium block mb-1.5" style={{ color: "#546E7A" }}>Upload .py File</label>
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-sm" style={{ backgroundColor: "#F5F7F8", border: "1px solid #ECEFF1" }}>
          <label
            className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer"
            style={{ color: "#0072C6", border: "1.5px solid #0072C6", backgroundColor: "transparent", flexShrink: 0 }}
          >
            <UploadIcon />
            Choose File
            <input type="file" accept=".py" onChange={handleFileChange} style={{ display: "none" }} />
          </label>
          <span className="text-sm truncate" style={{ color: selectedFile ? "#37474F" : "#90A4AE" }}>
            {selectedFile ? selectedFile.name : "No file selected"}
          </span>
        </div>
      </div>

      {/* Add Tool Button */}
      <div className="flex justify-end">
        <button
          onClick={handleAdd}
          disabled={!toolName.trim() || isAdding}
          className="px-5 py-2 rounded-full text-sm font-medium inline-flex items-center gap-2"
          style={{
            color: !toolName.trim() ? "#B0BEC5" : "#FFFFFF",
            backgroundColor: !toolName.trim() ? "#ECEFF1" : "#0072C6",
            border: "none",
            cursor: !toolName.trim() ? "not-allowed" : "pointer",
          }}
        >
          {isAdding ? "Adding..." : "+ Add Tool"}
        </button>
      </div>
    </div>
  );
}

// --- Added STDIO Tools List ---
function StdioToolsList({ stdioTools, onRemove }) {
  if (stdioTools.length === 0) return null;
  return (
    <div className="mt-4 pt-4" style={{ borderTop: "1px solid #ECEFF1" }}>
      <p className="text-xs font-semibold mb-2" style={{ color: "#546E7A" }}>Added Custom Tools ({stdioTools.length})</p>
      <div className="flex flex-col gap-2">
        {stdioTools.map((tool, i) => (
          <div
            key={i}
            className="flex items-center justify-between px-4 py-3 rounded-lg"
            style={{ backgroundColor: "#F5F7F8", border: "1px solid #ECEFF1" }}
          >
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center rounded-full" style={{ width: 28, height: 28, backgroundColor: "#EBF5FB" }}>
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                  <path d="M2 3H14M2 8H10M2 13H7" stroke="#0072C6" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-semibold" style={{ color: "#1A1A1A" }}>{tool.name}</p>
                <p className="text-xs" style={{ color: "#90A4AE" }}>
                  {tool.description || "No description"}{tool.fileName && <span> · {tool.fileName}</span>}
                </p>
              </div>
            </div>
            <button
              onClick={() => onRemove(i)}
              className="flex items-center justify-center rounded-full"
              style={{ width: 28, height: 28, backgroundColor: "#FFF5F5", border: "none", cursor: "pointer" }}
            >
              <TrashIcon />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// --- Main Page ---
export default function Tools({
  agentType = "Cortex",
  agentDetails,
  defaultConfig,
  savedData,
  onSaveAndContinue,
  onCreateAgent,
  onBack,
  onToolsByFetch,
}) {
  const navigate = useNavigate();
  const isLangGraph = agentType === "LangGraph";

  const [tools, setTools] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [orchestrationInstruction, setOrchestrationInstruction] = useState(
    savedData?.orchestration_instructions || ""
  );
  const [isSaving, setIsSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  // Cortex create agent status: "idle" | "creating" | "success" | "error"
  const [createStatus, setCreateStatus] = useState("idle");

  // LangGraph STDIO — restore from savedData
  const [showStdioForm, setShowStdioForm] = useState(false);
  const [stdioTools, setStdioTools] = useState(savedData?.stdio_mcp_tools || []);

  // Prefill orchestration from defaultConfig (details API) for LangGraph
  useEffect(() => {
    if (savedData?.orchestration_instructions) return;
    const defaultOrchestration = defaultConfig?.profile_config?.agent_instructions?.orchestration || "";
    if (defaultOrchestration && !orchestrationInstruction) {
      setOrchestrationInstruction(defaultOrchestration);
    }
  }, [defaultConfig]);

  // Prefill orchestration from specific API for Cortex
  useEffect(() => {
    if (isLangGraph) return;
    if (savedData?.orchestration_instructions) return;
    const cortexOrchestration = agentDetails?._agentInstructions?.orchestration || "";
    if (cortexOrchestration && !orchestrationInstruction) {
      setOrchestrationInstruction(cortexOrchestration);
    }
  }, [agentDetails]);

  const toolsFetched = useRef(false);

  useEffect(() => {
    if (!agentDetails) return;
    const scope = agentDetails.agnt_access_scope;
    if (!scope || scope === "null" || scope === "undefined") return;
    if (toolsFetched.current) return;
    toolsFetched.current = true;

    try {
      const parsedScope = JSON.parse(agentDetails.agnt_access_scope);
      const scopesArray = parsedScope?.scopes || [];
      if (scopesArray.length) loadTools(scopesArray);
    } catch (error) {
      console.error("Error parsing scope:", error);
    }
  }, [agentDetails]);

  // Auto-dismiss create agent toast after 4 seconds
  useEffect(() => {
    if (createStatus === "success" || createStatus === "error") {
      const timer = setTimeout(() => setCreateStatus("idle"), 4000);
      return () => clearTimeout(timer);
    }
  }, [createStatus]);

  const loadTools = async (scopesArray) => {
    try {
      setLoading(true);

      let formatted = [];
      const savedToolNames = (savedData?.tools || []).map((t) => t.name);

      if (isLangGraph) {
        // LangGraph: POST /api/common/mcp-servers/by-scopes
        // API expects scopes as a single comma-separated string in an array
        const scopesPayload = [scopesArray.join(",")];
        const response = await langgraphApi.getMcpServersByScopes(scopesPayload);
        const mcpServers = response?.mcp_servers || response?.data?.mcp_servers || response || [];

        if (!mcpServers || mcpServers.length === 0) { setTools([]); return; }

        formatted = mcpServers.map((server, index) => ({
          id: server.server_id || server.id || `mcp-${index}`,
          name: server.name || server.server_name || "",
          description: server.description || "",
          selected: savedToolNames.includes(server.name || server.server_name || ""),
          config: server.config || {},
          type: "monitor",
          original: server,
        }));

      } else {
        // Cortex: existing fetchToolsByScopes
        // Normalize scopesArray: if it's a single element with space-separated scopes, split it
        let normalizedScopes = scopesArray;
        if (scopesArray.length === 1 && typeof scopesArray[0] === 'string' && scopesArray[0].includes(' ')) {
          normalizedScopes = scopesArray[0].split(' ').filter(s => s.trim() !== '');
        }
        const response = await fetchToolsByScopes(normalizedScopes);
        const groupedTools = response?.data?.grouped_tools;
        if (!groupedTools || groupedTools.length === 0) { setTools([]); return; }

        formatted = groupedTools.flatMap((group) =>
          group.tools.map((tool) => ({
            id: tool.tool_id, name: tool.tool_nm, description: tool.tool_desc,
            selected: savedToolNames.includes(tool.tool_nm),
            type: "monitor", original: tool,
          }))
        );
      }

      setTools(formatted);
    } catch (error) {
      console.error("Failed to fetch tools:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleTool = (id) => {
    setTools((prev) => prev.map((t) => (t.id === id ? { ...t, selected: !t.selected } : t)));
  };

  const allSelected = tools.length > 0 && tools.every((t) => t.selected);

  const selectAll = () => {
    if (allSelected) {
      setTools((prev) => prev.map((t) => ({ ...t, selected: false })));
    } else {
      setTools((prev) => prev.map((t) => ({ ...t, selected: true })));
    }
  };


  const handleDiscard = () => { navigate("/dashboard"); };

  const handleAddStdioTool = (tool) => {
    setStdioTools((prev) => [...prev, tool]);
    setShowStdioForm(false);
  };

  const handleRemoveStdioTool = (index) => {
    setStdioTools((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSaveAndContinue = () => {
    const selectedTools = tools.filter((t) => t.selected);

    const formattedTools = selectedTools.map((tool) => ({
      type: tool.original?.tool_config?.type || "cortex_analyst_text_to_sql",
      name: tool.name, description: tool.description,
      db_name: tool.original?.tool_rsrc_config?.db_name || "Default",
      input_schema: tool.original?.tool_rsrc_config?.input_schema || "Default",
      config: tool.config || {},
    }));

    const formattedResources = {};
    selectedTools.forEach(tool => {
      const toolType = tool.original?.tool_config?.type || "cortex_analyst_text_to_sql"
      const rsrcConfig = tool.original?.tool_rsrc_config || {}

      // Build resource config based on tool type
      const resourceConfig = {
        db_name: rsrcConfig.db_name || "Default",
        input_schema: rsrcConfig.input_schema || "Default",
      }

      // Add fields based on tool type
      if (toolType === "cortex_analyst_text_to_sql") {
        // Support both semantic_view and semantic_model_file for Cortex Analyst
        if (rsrcConfig.semantic_view) {
          resourceConfig.semantic_view = rsrcConfig.semantic_view
        } else if (rsrcConfig.semantic_model_file) {
          resourceConfig.semantic_model_file = rsrcConfig.semantic_model_file
        }

        // Add execution environment for analyst tools
        if (rsrcConfig.execution_environment) {
          resourceConfig.execution_environment = rsrcConfig.execution_environment
        }
      } else if (toolType === "cortex_search") {
        // Add cortex_search specific fields
        if (rsrcConfig.search_service) {
          resourceConfig.search_service = rsrcConfig.search_service
        }
        if (rsrcConfig.title_column) {
          resourceConfig.title_column = rsrcConfig.title_column
        }
        if (rsrcConfig.id_column) {
          resourceConfig.id_column = rsrcConfig.id_column
        }
        if (rsrcConfig.filter) {
          resourceConfig.filter = rsrcConfig.filter
        }
      } else {
        // Generic fallback - include all available fields
        if (rsrcConfig.type === "procedure") {
          resourceConfig.type = "procedure"
          if (rsrcConfig.identifier) {
            resourceConfig.identifier = rsrcConfig.identifier
          }
          if (rsrcConfig.description) {
            resourceConfig.description = rsrcConfig.description
          }
          if (rsrcConfig.parameters) {
            resourceConfig.parameters = rsrcConfig.parameters
          }
        } else {
          // Other generic types - include all available fields
          if (rsrcConfig.semantic_model_file) {
            resourceConfig.semantic_model_file = rsrcConfig.semantic_model_file
          }
          if (rsrcConfig.semantic_view) {
            resourceConfig.semantic_view = rsrcConfig.semantic_view
          }
          if (rsrcConfig.execution_environment) {
            resourceConfig.execution_environment = rsrcConfig.execution_environment
          }
        }
      }

      formattedResources[tool.name] = resourceConfig
    })

    const toolData = {
      tool_choice: { type: "auto", name: [] },
      tools: formattedTools,
      tool_resources: formattedResources,
      orchestration_instructions: orchestrationInstruction,
      ...(isLangGraph && {
        // Normal tools (from scopes) -> streamable_http transport
        normal_mcp_tools: selectedTools.map((tool) => ({
          transport: tool.original?.transport || "streamable_http",
          name: tool.name,
          description: tool.description,
          config: {
            url: tool.original?.config?.url || tool.original?.tool_rsrc_config?.url || "",
            config: tool.original?.config?.config || tool.original?.tool_rsrc_config?.config || "",
          },
        })),
        // STDIO tools (manually added) -> stdio transport
        stdio_mcp_tools: stdioTools.map((t) => ({
          transport: "stdio",
          name: t.name,
          description: t.description,
          config: {
            command: t.config?.command || "python",
            args: t.config?.args || "",
          },
          file: t.file || null,
          fileName: t.fileName || null,
        })),
      }),
    };

    if (isLangGraph) {
      // LangGraph: go to next step (API & UI) — no Create Agent here
      onSaveAndContinue(toolData);
    } else {
      // Cortex: save then show Create Agent button
      onSaveAndContinue(toolData);
      setIsSaved(true);
    }
  };

  const handleCreateAgent = async () => {
    if (!onCreateAgent) return;
    setCreateStatus("creating");
    try {
      await onCreateAgent();
      setCreateStatus("success");
    } catch (error) {
      console.error("Agent creation failed:", error);
      setCreateStatus("error");
    }
  };

  // Footer buttons differ by agentType
  const getFooterButtons = () => {
    const buttons = [];
    if (onBack) buttons.push({ label: "Back", variant: "outline", onClick: onBack });
    buttons.push({ label: "Discard", variant: "outline", onClick: handleDiscard });

    if (isLangGraph) {
      // LangGraph: always Save & Continue (moves to API & UI)
      buttons.push({ label: "Save & Continue", variant: "primary", onClick: handleSaveAndContinue });
    } else {
      // Cortex: toggle between Save & Continue → Create Agent
      if (!isSaved) {
        buttons.push({ label: "Save & Continue", variant: "primary", onClick: handleSaveAndContinue });
      } else {
        const label = createStatus === "creating" ? "Creating Agent..."
          : createStatus === "success" ? "Agent Created Successfully"
            : createStatus === "error" ? "Retry Create Agent"
              : "Create Agent";
        const isDisabled = createStatus === "creating" || createStatus === "success";
        buttons.push({
          label,
          variant: isDisabled ? "disabled-primary" : "primary",
          onClick: isDisabled ? undefined : handleCreateAgent,
          disabled: isDisabled,
        });
      }
    }
    return buttons;
  };

  return (
    <>
      <div className="mt-5">
        <ToolsSection
          tools={tools.filter(
            (t) =>
              t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
              t.description?.toLowerCase().includes(searchTerm.toLowerCase())
          )}
          toggleTool={toggleTool}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          selectAll={selectAll}
          allSelected={allSelected}
        />
      </div>

      {/* LangGraph: STDIO Custom Tools Section */}
      {isLangGraph && (
        <div className="mt-7">
          <SectionHeader>Custom Tools (STDIO)</SectionHeader>
          <div
            className="rounded-lg bg-white p-5"
            style={{ border: "1px solid #E0E0E0", boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}
          >
            {/* Transport radio */}
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio" name="transport"
                  checked={showStdioForm}
                  onChange={() => setShowStdioForm(true)}
                  style={{ accentColor: "#0072C6", width: 16, height: 16 }}
                />
                <span className="text-sm font-medium" style={{ color: "#37474F" }}>STDIO</span>
              </label>
              <span className="text-xs" style={{ color: "#90A4AE" }}>
                Add custom tools using the STDIO transport protocol
              </span>
            </div>

            {/* STDIO Form - shown when radio selected */}
            {showStdioForm && (
              <StdioToolForm onAddTool={handleAddStdioTool} agentUuid={agentDetails?.agnt_id} />
            )}

            {/* List of added STDIO tools */}
            <StdioToolsList stdioTools={stdioTools} onRemove={handleRemoveStdioTool} />
          </div>
        </div>
      )}

      <div className="mt-7">
        <SectionHeader>Orchestration</SectionHeader>
        <OrchestrationSection value={orchestrationInstruction} onChange={setOrchestrationInstruction} />
      </div>

      <FooterButtons loading={isSaving || createStatus === "creating"} buttons={getFooterButtons()} />

      {/* Top-right toast notification for Cortex Create Agent */}
      {!isLangGraph && createStatus !== "idle" && (
        <div
          style={{
            position: "fixed",
            top: 24,
            right: 24,
            zIndex: 9999,
            minWidth: 340,
            maxWidth: 420,
            padding: "16px 20px",
            borderRadius: 12,
            backgroundColor: "#FFFFFF",
            border: `1px solid ${createStatus === "error" ? "#FEB2B2"
                : createStatus === "success" ? "#9AE6B4"
                  : "#D0E4F5"
              }`,
            boxShadow: "0 6px 20px rgba(0,0,0,0.1)",
            display: "flex",
            alignItems: "center",
            gap: 12,
          }}
        >
          {createStatus === "creating" && (
            <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#EBF5FB", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <div style={{ width: 16, height: 16, border: "2.5px solid #0072C6", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            </div>
          )}
          {createStatus === "success" && (
            <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#F0FFF4", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="9" fill="#2E8540" />
                <path d="M6 10.5L8.5 13L14 7.5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          )}
          {createStatus === "error" && (
            <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#FFF5F5", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="9" fill="#E53E3E" />
                <path d="M7 7L13 13M13 7L7 13" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
          )}
          <span style={{ fontSize: 14, fontWeight: 500, color: "#1A1A1A" }}>
            {createStatus === "creating" && "Agent creation is in progress..."}
            {createStatus === "success" && "Agent created successfully!"}
            {createStatus === "error" && "Agent creation failed. Please try again."}
          </span>
        </div>
      )}

      {createStatus === "creating" && (
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      )}
    </>
  );
}