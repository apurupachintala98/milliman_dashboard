import { useNavigate } from "react-router-dom";
import { fetchSpecificAgent } from "../services/agents";
import { v4 as uuidv4 } from "uuid";
import { agentApi } from "../services/api";
import { isDynamicAgentType } from "../config/AgentTypeConfig";

export default function AgentCard({ agent }) {
  const navigate = useNavigate();

  const handleEditClick = async () => {
    try {
      const sessionId = uuidv4();
      localStorage.setItem("session_Id", sessionId);
      localStorage.setItem("agentType", agent.agentType || "");
      localStorage.setItem("agentName", agent.name || "");
      localStorage.setItem("agentId", agent.id || "");
      const userId = localStorage.getItem("user_id");
      const appCode = localStorage.getItem("aplctn_cd");

      // Dynamic agent types — fetch details, store scopes, navigate
      if (isDynamicAgentType(agent.agentType)) {
        localStorage.setItem("agentUuid", agent.id);
        localStorage.setItem("agentId", agent.id);

        try {
          const { langgraphApi } = await import("../services/langgraph-api");
          const detailsRes = await langgraphApi.getAgentDetails(agent.id);
          const record = detailsRes?.data?.record || detailsRes?.record || {};
          localStorage.setItem("agentDetails", JSON.stringify(record));
          console.log(`[Deep Agent] Details loaded, scopes: ${record.agnt_access_scope}`);
        } catch (err) {
          console.warn("[Deep Agent] Details API failed:", err);
        }

        navigate(`/dynamic-agent/${encodeURIComponent(agent.agentType)}/${agent.id}`);
        return;
      }

      // Cortex and LangGraph — fetch agent details first
      const response = await fetchSpecificAgent(agent.id);
      const agentDetails = response?.data?.record;

      if (!agentDetails) {
        console.error("Agent details not found");
        return;
      }

      if (agent.agentType === "Cortex") {
        await agentApi.createAgent({
          agent_uuid: agent.id,
          sesn_id: sessionId,
          user_id: userId,
          aplctn_cd: appCode,
        });
        navigate(`/cortex-agent/${agent.id}`);
      } else if (agent.agentType === "LangGraph") {
        navigate(`/langraph-agent/${agent.id}`);
      } else {
        // Unknown type fallback — try dynamic builder
        navigate(`/dynamic-agent/${encodeURIComponent(agent.agentType)}/${agent.id}`);
      }
    } catch (error) {
      console.error("Failed to fetch specific agent:", error);
    }
  };

  return (
    <div
      onClick={handleEditClick}
      style={{
        width: "411px",
        height: "243px",
        borderRadius: "8px",
        background: "#FFF",
        boxShadow: "0 13px 19px -13px rgba(17, 17, 17, 0.30)",
        padding: "16px",
        display: "flex",
        flexDirection: "column",
        gap: "12px",
        cursor: "pointer",
      }}
    >
      {/* Icon and Status Container */}
      <div
        style={{
          display: "flex",
          width: "362.664px",
          height: "48px",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        {/* Icon */}
        <div
          style={{
            width: "48px",
            height: "48px",
            flexShrink: 0,
            aspectRatio: "1/1",
            borderRadius: "8px",
            background: "#0079C2",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "24px",
            color: "white",
          }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="24" r="24" fill="#0079C2" />
            <rect x="14.16" y="10.56" width="19.68" height="26.88" rx="1.344" stroke="white" strokeWidth="1.92" />
            <path d="M18 15H30" stroke="white" strokeWidth="1.92" strokeLinecap="round" />
            <path d="M18 18.6H30" stroke="white" strokeWidth="1.92" strokeLinecap="round" />
            <path d="M18 22.2H30" stroke="white" strokeWidth="1.92" strokeLinecap="round" />
            <path d="M18 25.8H24" stroke="white" strokeWidth="1.92" strokeLinecap="round" />
            <path d="M25.2 31.8H30" stroke="white" strokeWidth="1.92" strokeLinecap="round" />
            <path d="M27.6 29.4V34.2" stroke="white" strokeWidth="1.92" strokeLinecap="round" />
          </svg>
        </div>

        {/* Status Badge */}
        <div
          style={{
            display: "flex",
            padding: "2px 10px",
            justifyContent: "center",
            alignItems: "center",
            gap: "8px",
            borderRadius: "16px",
            background: agent.status === "Active" ? "#F1F9F7" : "#FEF8E7",
          }}
        >
          <span
            style={{
              color: agent.status === "Active" ? "#53B1A3" : "#F3C246",
              textAlign: "center",
              fontFamily: "Open Sans",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "500",
              lineHeight: "20px",
            }}
          >
            {agent.status}
          </span>
        </div>
      </div>

      {/* Agent Name */}
      <h3
        style={{
          color: "#5B6770",
          fontFamily: "Open Sans",
          fontSize: "18px",
          fontWeight: "600",
          lineHeight: "27px",
          margin: "0",
          marginTop: "4px",
        }}
      >
        {agent.name}
      </h3>

      {/* Description */}
      <p
        style={{
          width: "338px",
          color: "#5B6770",
          fontFamily: "Open Sans",
          fontSize: "13px",
          fontWeight: "300",
          lineHeight: "18px",
          margin: "0",
          marginBottom: "8px",
          maxHeight: "72px",
          overflowY: "auto",
        }}
      >
        {agent.description}
      </p>

      {/* Models Container */}
      <div
        style={{
          display: "flex",
          width: "362.664px",
          height: "36px",
          alignItems: "flex-start",
          gap: "8px",
          marginTop: "auto",
        }}
      >
        {/* Agent Type Box */}
        <div
          style={{
            display: "flex",
            padding: "9px 11px 10px 12px",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: "8px",
            border: "1px solid rgba(0, 121, 194, 0.20)",
            background: "rgba(0, 121, 194, 0.10)",
          }}
        >
          <span
            style={{
              color: "#0079C2",
              fontFamily: "Open Sans",
              fontSize: "11px",
              fontWeight: "600",
              lineHeight: "16.5px",
            }}
          >
            {agent.agentType}
          </span>
        </div>

        {/* Model Name Box */}
        {agent.modelName && (
          <div
            style={{
              display: "flex",
              padding: "9px 11px 10px 12px",
              justifyContent: "center",
              alignItems: "center",
              borderRadius: "8px",
              border: "1px solid #E2E8F0",
              background: "#F1F5F9",
            }}
          >
            <span
              style={{
                color: "#5B6770",
                fontFamily: "Open Sans",
                fontSize: "11px",
                fontWeight: "600",
                lineHeight: "16.5px",
              }}
            >
              {agent.modelName}
            </span>
          </div>
        )}

        {/* Chat Icon — only for Active agents */}
        {agent.status === "Active" && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            localStorage.setItem("agentName", agent.name || "");
            localStorage.setItem("agentId", agent.id || "");
            localStorage.setItem("agentType", agent.agentType || "");
            navigate("/chat");
          }}
          title="Chat"
          style={{
            display: "flex",
            width: "31px",
            height: "32px",
            padding: "6px",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: "16px",
            marginLeft: "auto",
            cursor: "pointer",
            transition: "transform 0.2s ease, background 0.2s ease",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "scale(1.2)";
            e.currentTarget.style.background = "rgba(0, 121, 194, 0.08)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "scale(1)";
            e.currentTarget.style.background = "transparent";
          }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
            stroke="#94A3B8" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
          >
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
        </div>
        )}
      </div>
    </div>
  );
}