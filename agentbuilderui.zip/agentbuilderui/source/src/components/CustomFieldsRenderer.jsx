import { useState, useEffect } from "react";

const STORAGE_KEY = "agent_studio_preferences";

/**
 * Reads saved preferences from localStorage for a given agent type and step.
 * Returns the custom fields array for that step.
 */
export function getCustomFields(agentType, stepId) {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const prefs = JSON.parse(raw);
    const layout = prefs[agentType];
    if (!layout?.steps) return [];
    const step = layout.steps.find((s) => s.id === stepId);
    return step?.fields || [];
  } catch {
    return [];
  }
}

/**
 * Hook to load and manage custom field values for a step.
 * Returns { customFields, customValues, setCustomValue }
 */
export function useCustomFields(agentType, stepId, savedCustomValues) {
  const [customFields, setCustomFields] = useState([]);
  const [customValues, setCustomValues] = useState(savedCustomValues || {});

  useEffect(() => {
    const fields = getCustomFields(agentType, stepId);
    setCustomFields(fields);
  }, [agentType, stepId]);

  const setCustomValue = (fieldId, value) => {
    setCustomValues((prev) => ({ ...prev, [fieldId]: value }));
  };

  return { customFields, customValues, setCustomValue };
}

/**
 * Renders a single custom field based on its type.
 */
function CustomField({ field, value, onChange }) {
  const labelStyle = {
    fontSize: 13,
    fontWeight: 500,
    color: "#37474F",
    marginBottom: 6,
    display: "block",
  };

  const inputStyle = {
    width: "100%",
    padding: "8px 12px",
    fontSize: 13,
    color: "#263238",
    backgroundColor: "#F5F7F8",
    border: "1px solid #ECEFF1",
    borderRadius: 4,
    outline: "none",
    boxSizing: "border-box",
  };

  const renderField = () => {
    switch (field.type) {
      case "text":
        return (
          <input
            type="text"
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            placeholder={field.placeholder || ""}
            style={inputStyle}
          />
        );

      case "textarea":
        return (
          <textarea
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            placeholder={field.placeholder || ""}
            rows={4}
            style={{ ...inputStyle, resize: "vertical" }}
          />
        );

      case "number":
        return (
          <input
            type="number"
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            placeholder={field.placeholder || ""}
            style={inputStyle}
          />
        );

      case "checkbox":
        return (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input
              type="checkbox"
              checked={!!value}
              onChange={(e) => onChange(e.target.checked)}
              style={{ width: 16, height: 16, accentColor: "#0072C6" }}
            />
            <span style={{ fontSize: 13, color: "#546E7A" }}>
              {field.placeholder || "Enable"}
            </span>
          </div>
        );

      case "toggle":
        return (
          <div
            onClick={() => onChange(!value)}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 10,
              cursor: "pointer",
            }}
          >
            <div
              style={{
                width: 40,
                height: 22,
                borderRadius: 11,
                backgroundColor: value ? "#0072C6" : "#CFD8DC",
                position: "relative",
                transition: "background-color 0.2s",
              }}
            >
              <div
                style={{
                  width: 18,
                  height: 18,
                  borderRadius: "50%",
                  backgroundColor: "#FFF",
                  position: "absolute",
                  top: 2,
                  left: value ? 20 : 2,
                  transition: "left 0.2s",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                }}
              />
            </div>
            <span style={{ fontSize: 13, color: "#546E7A" }}>
              {value ? "Enabled" : "Disabled"}
            </span>
          </div>
        );

      case "dropdown": {
        const options = field.options
          ? field.options.split(",").map((o) => o.trim()).filter(Boolean)
          : [];
        return (
          <select
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            style={{ ...inputStyle, cursor: "pointer", appearance: "auto" }}
          >
            <option value="">{field.placeholder || "Select..."}</option>
            {options.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        );
      }

      case "radio": {
        const options = field.options
          ? field.options.split(",").map((o) => o.trim()).filter(Boolean)
          : [];
        return (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {options.map((opt) => (
              <label
                key={opt}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  cursor: "pointer",
                  fontSize: 13,
                  color: "#546E7A",
                }}
              >
                <input
                  type="radio"
                  name={field.id}
                  checked={value === opt}
                  onChange={() => onChange(opt)}
                  style={{ accentColor: "#0072C6", width: 16, height: 16 }}
                />
                {opt}
              </label>
            ))}
          </div>
        );
      }

      default:
        return (
          <input
            type="text"
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            placeholder={field.placeholder || ""}
            style={inputStyle}
          />
        );
    }
  };

  return (
    <div style={{ marginBottom: 0 }}>
      <label style={labelStyle}>
        {field.label}
        {field.required && (
          <span style={{ color: "#E53E3E", marginLeft: 2 }}>*</span>
        )}
      </label>
      {renderField()}
    </div>
  );
}

/**
 * CustomFieldsSection — renders all custom fields for a given agent type + step.
 * Drop this into any step component:
 *
 *   <CustomFieldsSection
 *     agentType="LangGraph"
 *     stepId="step1"
 *     values={customValues}
 *     onChange={(fieldId, value) => setCustomValue(fieldId, value)}
 *   />
 */
export default function CustomFieldsSection({
  agentType,
  stepId,
  values = {},
  onChange,
}) {
  const [fields, setFields] = useState([]);

  useEffect(() => {
    setFields(getCustomFields(agentType, stepId));
  }, [agentType, stepId]);

  if (fields.length === 0) return null;

  return (
    <div
      style={{
        marginTop: 20,
        padding: "16px 20px",
        backgroundColor: "#FAFBFC",
        border: "1px solid #E2E8F0",
        borderRadius: 8,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          marginBottom: 16,
          paddingBottom: 10,
          borderBottom: "1px solid #E2E8F0",
        }}
      >
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#0072C6"
          strokeWidth="2"
        >
          <rect x="3" y="3" width="18" height="18" rx="2" />
          <path d="M9 12h6M12 9v6" />
        </svg>
        <span
          style={{
            fontSize: 12,
            fontWeight: 600,
            color: "#0072C6",
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Custom Fields
        </span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {fields.map((field) => (
          <CustomField
            key={field.id}
            field={field}
            value={values[field.id]}
            onChange={(val) => onChange(field.id, val)}
          />
        ))}
      </div>
    </div>
  );
}