import { useState } from "react";
import { SectionHeader } from "../components/SharedComponents";

/**
 * DynamicStepRenderer — v2
 *
 * Field types:
 *   text, textarea, json, number, toggle, checkbox, dropdown, radio, readonly
 *   repeater  — dynamic add/remove rows of sub-fields (for arrays of objects)
 *   chips     — multi-select tags sourced from another field's values
 */

const INPUT_STYLE = {
  width: "100%", padding: "10px 12px", fontSize: 14, color: "#37474F",
  backgroundColor: "#F5F7F8", border: "1px solid #ECEFF1", borderRadius: 4,
  outline: "none", boxSizing: "border-box", fontFamily: "'Segoe UI', sans-serif",
};

function ChevronDown() {
  return <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#90A4AE" strokeWidth="2"><polyline points="6 9 12 15 18 9" /></svg>;
}

// ─── SubRepeater — nested repeater for arrays within a repeater row ───
function SubRepeater({ subField, value, onChange }) {
  const rows = Array.isArray(value) ? value : [];

  const addRow = () => {
    const blank = {};
    (subField.subFields || []).forEach((f) => { blank[f.id] = ""; });
    onChange([...rows, blank]);
  };

  const removeRow = (idx) => onChange(rows.filter((_, i) => i !== idx));

  const updateRow = (idx, fieldId, val) => {
    onChange(rows.map((r, i) => i === idx ? { ...r, [fieldId]: val } : r));
  };

  return (
    <div>
      {rows.map((row, idx) => (
        <div key={idx} style={{
          display: "flex", gap: 10, alignItems: "center", marginBottom: 6,
          padding: "8px 12px", backgroundColor: "#FFF", border: "1px solid #ECEFF1", borderRadius: 6,
        }}>
          <span style={{ fontSize: 10, color: "#90A4AE", fontWeight: 700, flexShrink: 0 }}>{idx + 1}</span>
          {(subField.subFields || []).map((f) => (
            <div key={f.id} style={{ flex: f.flex || 1 }}>
              <input
                type="text"
                value={row[f.id] || ""}
                onChange={(e) => updateRow(idx, f.id, e.target.value)}
                placeholder={f.placeholder || f.label || ""}
                style={{ ...INPUT_STYLE, fontSize: 12, padding: "6px 10px" }}
              />
            </div>
          ))}
          <button onClick={() => removeRow(idx)} style={{
            background: "#FFF5F5", border: "1px solid #FEB2B2", borderRadius: "50%",
            width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", flexShrink: 0,
          }}>
            <svg width="8" height="8" viewBox="0 0 16 16" fill="none">
              <path d="M4 4L12 12M12 4L4 12" stroke="#E53E3E" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      ))}
      <button onClick={addRow} style={{
        display: "flex", alignItems: "center", gap: 4,
        padding: "5px 12px", fontSize: 11, fontWeight: 600,
        color: "#0072C6", backgroundColor: "#EBF5FB",
        border: "1px solid #B3D9F2", borderRadius: 5, cursor: "pointer",
      }}>
        <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="#0072C6" strokeWidth="2">
          <path d="M8 2v12M2 8h12" />
        </svg>
        {subField.addLabel || "Add"}
      </button>
    </div>
  );
}

// ─── Repeater Field — dynamic rows of sub-fields ───
function RepeaterField({ field, value, onChange, allValues }) {
  const rows = Array.isArray(value) ? value : [];

  const addRow = () => {
    const blank = {};
    (field.subFields || []).forEach((sf) => {
      blank[sf.id] = sf.defaultValue ?? "";
    });
    onChange(field.id, [...rows, blank]);
  };

  const removeRow = (idx) => {
    onChange(field.id, rows.filter((_, i) => i !== idx));
  };

  const updateRow = (idx, subFieldId, val) => {
    const updated = rows.map((row, i) =>
      i === idx ? { ...row, [subFieldId]: val } : row
    );
    onChange(field.id, updated);
  };

  return (
    <div style={{ width: "100%" }}>
      {rows.map((row, idx) => (
        <div
          key={idx}
          style={{
            display: "flex", gap: 12, alignItems: "flex-start",
            padding: "12px 16px", marginBottom: 8,
            backgroundColor: idx % 2 === 0 ? "#FAFBFC" : "#FFF",
            border: "1px solid #ECEFF1", borderRadius: 6,
          }}
        >
          {/* Row number badge */}
          <div style={{
            width: 24, height: 24, borderRadius: "50%", flexShrink: 0,
            backgroundColor: "#E3F2FD", color: "#0072C6", fontSize: 11, fontWeight: 700,
            display: "flex", alignItems: "center", justifyContent: "center", marginTop: 6,
          }}>
            {idx + 1}
          </div>

          {/* Sub-fields */}
          <div style={{
            flex: 1, display: "flex", gap: 12,
            ...(field.layout === "vertical"
              ? { flexDirection: "column" }
              : { flexWrap: "wrap" }),
          }}>
            {(field.subFields || []).map((sf) => {
              const subVal = row[sf.id] ?? sf.defaultValue ?? "";
              const isDropdown = sf.type === "dropdown";
              const fieldFlex = field.layout === "vertical" ? undefined : (sf.flex || 1);

              return (
                <div key={sf.id} style={{ flex: fieldFlex, minWidth: field.layout === "vertical" ? undefined : (sf.minWidth || 140) }}>
                  <label style={{ fontSize: 11, fontWeight: 500, color: "#78909C", display: "block", marginBottom: 4 }}>
                    {sf.label}
                    {sf.required && <span style={{ color: "#E53E3E", marginLeft: 2 }}>*</span>}
                  </label>
                  {sf.type === "checkboxgroup" ? (() => {
                    // Support dynamic options from _sourceField
                    let options = sf.options || [];
                    if (sf._sourceField && allValues[sf._sourceField]) {
                      const src = allValues[sf._sourceField];
                      if (Array.isArray(src)) {
                        options = src.map((item) => {
                          const val = sf._sourceKey ? item[sf._sourceKey] : (typeof item === "string" ? item : "");
                          return val ? { value: val, label: val } : null;
                        }).filter(Boolean);
                      }
                    }
                    return (
                    <div style={{ display: "flex", gap: 14, paddingTop: 4, flexWrap: "wrap" }}>
                      {options.length > 0 ? options.map((opt) => {
                        const checked = Array.isArray(subVal) ? subVal.includes(opt.value) : false;
                        return (
                          <label key={opt.value} style={{ display: "flex", alignItems: "center", gap: 5, cursor: "pointer", fontSize: 13, color: "#37474F" }}>
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => {
                                const current = Array.isArray(subVal) ? [...subVal] : [];
                                const updated = checked ? current.filter((v) => v !== opt.value) : [...current, opt.value];
                                updateRow(idx, sf.id, updated);
                              }}
                              style={{ width: 15, height: 15, accentColor: "#0072C6" }}
                            />
                            {opt.label}
                          </label>
                        );
                      }) : <span style={{ fontSize: 11, color: "#B0BEC5", fontStyle: "italic" }}>Add {sf._sourceField === "mcp_servers" ? "MCP servers" : "skill files"} first</span>}
                    </div>
                    );
                  })() : sf.type === "sub_repeater" ? (
                    <SubRepeater
                      subField={sf}
                      value={Array.isArray(subVal) ? subVal : []}
                      onChange={(newVal) => updateRow(idx, sf.id, newVal)}
                    />
                  ) : sf.type === "textarea" ? (
                    <textarea
                      value={subVal}
                      onChange={(e) => updateRow(idx, sf.id, e.target.value)}
                      placeholder={sf.placeholder || ""}
                      rows={sf.rows || 2}
                      style={{ ...INPUT_STYLE, fontSize: 13, padding: "8px 10px", resize: "vertical" }}
                    />
                  ) : isDropdown ? (
                    <select
                      value={subVal}
                      onChange={(e) => updateRow(idx, sf.id, e.target.value)}
                      style={{ ...INPUT_STYLE, fontSize: 13, padding: "8px 10px", appearance: "auto", cursor: "pointer" }}
                    >
                      <option value="">{sf.placeholder || "Select..."}</option>
                      {(sf.options || []).map((o) => (
                        <option key={o.value} value={o.value}>{o.label}</option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type={sf.type === "number" ? "number" : "text"}
                      value={subVal}
                      onChange={(e) => updateRow(idx, sf.id, sf.type === "number" ? (e.target.value === "" ? "" : Number(e.target.value)) : e.target.value)}
                      placeholder={sf.placeholder || ""}
                      style={{ ...INPUT_STYLE, fontSize: 13, padding: "8px 10px" }}
                    />
                  )}
                </div>
              );
            })}
          </div>

          {/* Remove button */}
          <button
            onClick={() => removeRow(idx)}
            title="Remove"
            style={{
              background: "#FFF5F5", border: "1px solid #FEB2B2", borderRadius: "50%",
              width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", flexShrink: 0, marginTop: 4,
            }}
          >
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
              <path d="M4 4L12 12M12 4L4 12" stroke="#E53E3E" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      ))}

      {/* Add button */}
      <button
        onClick={addRow}
        style={{
          display: "flex", alignItems: "center", gap: 6,
          padding: "8px 16px", fontSize: 13, fontWeight: 600,
          color: "#0072C6", backgroundColor: "#EBF5FB",
          border: "1px solid #B3D9F2", borderRadius: 6, cursor: "pointer",
          marginTop: rows.length > 0 ? 4 : 0,
        }}
      >
        <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="#0072C6" strokeWidth="2">
          <path d="M8 2v12M2 8h12" />
        </svg>
        {field.addLabel || "Add"}
      </button>
    </div>
  );
}

// ─── Chips Field — multi-select with removable tags ───
function ChipsField({ field, value, onChange, allValues }) {
  const selected = Array.isArray(value) ? value : [];
  const [isOpen, setIsOpen] = useState(false);

  // Build available options from sourceField or static options
  let availableOptions = [];
  if (field.sourceField && allValues[field.sourceField]) {
    const sourceData = allValues[field.sourceField];
    if (Array.isArray(sourceData)) {
      availableOptions = sourceData
        .map((item) => {
          const val = field.sourceKey ? item[field.sourceKey] : (typeof item === "string" ? item : "");
          return val ? { value: val, label: val } : null;
        })
        .filter(Boolean);
    }
  } else if (field.options) {
    availableOptions = field.options;
  }

  // Filter out already-selected
  const unselected = availableOptions.filter((o) => !selected.includes(o.value));

  const addChip = (val) => {
    if (!selected.includes(val)) {
      onChange(field.id, [...selected, val]);
    }
    setIsOpen(false);
  };

  const removeChip = (val) => {
    onChange(field.id, selected.filter((s) => s !== val));
  };

  return (
    <div style={{ width: "100%" }}>
      {/* Selected chips */}
      {selected.length > 0 && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 10 }}>
          {selected.map((chip) => (
            <div
              key={chip}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                padding: "5px 10px 5px 12px", borderRadius: 16,
                backgroundColor: "#EBF5FB", border: "1px solid #B3D9F2",
                fontSize: 13, color: "#003366", fontWeight: 500,
              }}
            >
              {chip}
              <button
                onClick={() => removeChip(chip)}
                style={{
                  background: "none", border: "none", cursor: "pointer", padding: 0,
                  display: "flex", alignItems: "center",
                }}
              >
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                  <circle cx="8" cy="8" r="7" fill="#B3D9F2" />
                  <path d="M5.5 5.5L10.5 10.5M10.5 5.5L5.5 10.5" stroke="#003366" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add dropdown */}
      {unselected.length > 0 ? (
        <div style={{ position: "relative", display: "inline-block" }}>
          <button
            onClick={() => setIsOpen(!isOpen)}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "7px 14px", fontSize: 13, fontWeight: 500,
              color: "#0072C6", backgroundColor: "#FFF",
              border: "1px solid #B3D9F2", borderRadius: 6, cursor: "pointer",
            }}
          >
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="#0072C6" strokeWidth="2">
              <path d="M8 2v12M2 8h12" />
            </svg>
            Add Tool
            <ChevronDown />
          </button>
          {isOpen && (
            <div style={{
              position: "absolute", top: "100%", left: 0, marginTop: 4, zIndex: 50,
              backgroundColor: "#FFF", border: "1px solid #E0E0E0", borderRadius: 8,
              boxShadow: "0 4px 12px rgba(0,0,0,0.1)", minWidth: 200, maxHeight: 200, overflowY: "auto",
            }}>
              {unselected.map((opt) => (
                <div
                  key={opt.value}
                  onClick={() => addChip(opt.value)}
                  style={{
                    padding: "9px 14px", fontSize: 13, color: "#37474F", cursor: "pointer",
                    borderBottom: "1px solid #F5F5F5",
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = "#EBF5FB"; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = "#FFF"; }}
                >
                  {opt.label}
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <span style={{ fontSize: 12, color: "#B0BEC5", fontStyle: "italic" }}>
          {availableOptions.length === 0 ? "Add MCP servers first to see tools here" : "All tools selected"}
        </span>
      )}
    </div>
  );
}

// ─── HITL Field — Human-in-the-Loop configuration ───
function HitlField({ field, value, onChange, allValues }) {
  const hitlState = (typeof value === "object" && value !== null) ? value : { enabled: false, tools: {} };
  const isEnabled = !!hitlState.enabled;
  const toolConfigs = hitlState.tools || {};

  const update = (newState) => onChange(field.id, { ...hitlState, ...newState });
  const updateTool = (toolName, config) => {
    update({ tools: { ...toolConfigs, [toolName]: config } });
  };
  const removeTool = (toolName) => {
    const updated = { ...toolConfigs };
    delete updated[toolName];
    update({ tools: updated });
  };

  // Build available tools: defaults + MCP server names
  const defaultTools = ["write_file", "edit_file"];
  let mcpTools = [];
  if (field.sourceField && allValues[field.sourceField]) {
    const src = allValues[field.sourceField];
    if (Array.isArray(src)) {
      mcpTools = src.map((s) => field.sourceKey ? s[field.sourceKey] : s).filter(Boolean);
    }
  }
  const allTools = [...new Set([...defaultTools, ...mcpTools])];
  const selectedTools = Object.keys(toolConfigs);
  const unselectedTools = allTools.filter((t) => !selectedTools.includes(t));

  const [dropdownOpen, setDropdownOpen] = useState(false);

  const addTool = (name) => {
    updateTool(name, true);
    setDropdownOpen(false);
  };

  const DECISIONS = [
    { value: "approve", label: "Approve" },
    { value: "edit", label: "Edit" },
    { value: "reject", label: "Reject" },
    { value: "respond", label: "Respond" },
  ];

  const getMode = (config) => {
    if (config === true) return "true";
    if (config === false) return "false";
    if (typeof config === "object" && config.allowed_decisions) return "allowed";
    return "true";
  };

  return (
    <div style={{ width: "100%" }}>
      {/* Enable/Disable toggle */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: isEnabled ? 16 : 0 }}>
        <div
          onClick={() => update({ enabled: !isEnabled })}
          style={{ width: 40, height: 22, borderRadius: 11, backgroundColor: isEnabled ? "#0072C6" : "#CFD8DC", position: "relative", cursor: "pointer", transition: "background 0.2s" }}
        >
          <div style={{ width: 18, height: 18, borderRadius: "50%", backgroundColor: "#FFF", position: "absolute", top: 2, left: isEnabled ? 20 : 2, transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
        </div>
        <span style={{ fontSize: 14, color: "#546E7A" }}>{isEnabled ? "Enabled" : "Disabled"}</span>
      </div>

      {isEnabled && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {/* Tool cards */}
          {selectedTools.map((toolName) => {
            const config = toolConfigs[toolName];
            const mode = getMode(config);
            const decisions = (typeof config === "object" && config.allowed_decisions) ? config.allowed_decisions : [];

            return (
              <div key={toolName} style={{
                border: "1px solid #E2E8F0", borderRadius: 8, backgroundColor: "#FAFBFC", overflow: "hidden",
              }}>
                {/* Tool header */}
                <div style={{
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "10px 16px", backgroundColor: "#F0F7FF", borderBottom: "1px solid #E2E8F0",
                }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: "#003366", fontFamily: "monospace" }}>{toolName}</span>
                  <button onClick={() => removeTool(toolName)} style={{
                    background: "#FFF5F5", border: "1px solid #FEB2B2", borderRadius: "50%",
                    width: 24, height: 24, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
                  }}>
                    <svg width="10" height="10" viewBox="0 0 16 16" fill="none">
                      <path d="M4 4L12 12M12 4L4 12" stroke="#E53E3E" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                  </button>
                </div>

                {/* Radio options */}
                <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 10 }}>
                  {/* False */}
                  <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, color: "#37474F" }}>
                    <input type="radio" name={`hitl_${toolName}`} checked={mode === "false"} onChange={() => updateTool(toolName, false)}
                      style={{ accentColor: "#0072C6", width: 16, height: 16 }} />
                    <span style={{ fontWeight: mode === "false" ? 600 : 400 }}>False</span>
                    <span style={{ fontSize: 11, color: "#90A4AE", marginLeft: 4 }}>— No intervention required</span>
                  </label>

                  {/* True */}
                  <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, color: "#37474F" }}>
                    <input type="radio" name={`hitl_${toolName}`} checked={mode === "true"} onChange={() => updateTool(toolName, true)}
                      style={{ accentColor: "#0072C6", width: 16, height: 16 }} />
                    <span style={{ fontWeight: mode === "true" ? 600 : 400 }}>True</span>
                    {/* Info tooltip */}
                    <div style={{ position: "relative", display: "inline-flex" }} title="All operations are enabled when this option is selected: Approve, Edit, Reject, and Respond.">
                      <svg width="14" height="14" viewBox="0 0 20 20" fill="none" style={{ cursor: "help" }}>
                        <circle cx="10" cy="10" r="9" stroke="#0072C6" strokeWidth="1.5" fill="none" />
                        <text x="10" y="14.5" textAnchor="middle" fill="#0072C6" fontSize="12" fontWeight="600" fontFamily="sans-serif">i</text>
                      </svg>
                    </div>
                  </label>

                  {/* Allowed Decisions */}
                  <div>
                    <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, color: "#37474F" }}>
                      <input type="radio" name={`hitl_${toolName}`} checked={mode === "allowed"}
                        onChange={() => updateTool(toolName, { allowed_decisions: ["approve"] })}
                        style={{ accentColor: "#0072C6", width: 16, height: 16 }} />
                      <span style={{ fontWeight: mode === "allowed" ? 600 : 400 }}>Allowed Decisions</span>
                    </label>

                    {mode === "allowed" && (
                      <div style={{ marginLeft: 28, marginTop: 8, display: "flex", gap: 16, flexWrap: "wrap" }}>
                        {DECISIONS.map((d) => {
                          const checked = decisions.includes(d.value);
                          return (
                            <label key={d.value} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 13, color: "#37474F" }}>
                              <input type="checkbox" checked={checked}
                                onChange={() => {
                                  const updated = checked
                                    ? decisions.filter((x) => x !== d.value)
                                    : [...decisions, d.value];
                                  updateTool(toolName, { allowed_decisions: updated.length > 0 ? updated : ["approve"] });
                                }}
                                style={{ width: 15, height: 15, accentColor: "#0072C6" }} />
                              {d.label}
                            </label>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Add tool dropdown */}
          <div style={{ position: "relative", display: "inline-block" }}>
            <button onClick={() => setDropdownOpen(!dropdownOpen)} style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "8px 16px", fontSize: 13, fontWeight: 600,
              color: "#0072C6", backgroundColor: "#EBF5FB",
              border: "1px solid #B3D9F2", borderRadius: 6, cursor: "pointer",
            }}>
              <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="#0072C6" strokeWidth="2">
                <path d="M8 2v12M2 8h12" />
              </svg>
              Add Tool
            </button>
            {dropdownOpen && (
              <div style={{
                position: "absolute", top: "100%", left: 0, marginTop: 4, zIndex: 50,
                backgroundColor: "#FFF", border: "1px solid #E0E0E0", borderRadius: 8,
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)", minWidth: 220, maxHeight: 240, overflowY: "auto",
              }}>
                {unselectedTools.length > 0 ? unselectedTools.map((t) => (
                  <div key={t} onClick={() => addTool(t)} style={{
                    padding: "10px 14px", fontSize: 13, color: "#37474F", cursor: "pointer",
                    borderBottom: "1px solid #F5F5F5", fontFamily: "monospace",
                  }}
                    onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = "#EBF5FB"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = "#FFF"; }}
                  >{t}</div>
                )) : (
                  <div style={{ padding: "10px 14px", fontSize: 12, color: "#B0BEC5", fontStyle: "italic" }}>
                    All available tools have been added
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Tools Grid — same rendering as LangGraph ToolsAndOrchestration ───
function ToolsGrid({ field, value, onChange, mcpToolsFromScopes, toolsLoading }) {
  const [showFullDesc, setShowFullDesc] = useState(null);

  const tools = (mcpToolsFromScopes || []).map((server, idx) => ({
    id: server.server_id || server.id || `mcp-${idx}`,
    name: server.name || server.server_name || "",
    description: server.description || "",
  }));

  const selectedNames = Array.isArray(value) ? value : [];
  const allSelected = tools.length > 0 && tools.every((t) => selectedNames.includes(t.name));

  const toggle = (name) => {
    const updated = selectedNames.includes(name)
      ? selectedNames.filter((n) => n !== name)
      : [...selectedNames, name];
    onChange(field.id, updated);
  };

  const toggleAll = () => {
    onChange(field.id, allSelected ? [] : tools.map((t) => t.name));
  };

  if (toolsLoading) {
    return (
      <div style={{ textAlign: "center", padding: "32px 16px" }}>
        <div style={{ width: 28, height: 28, border: "3px solid #0072C6", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 12px" }} />
        <p style={{ color: "#78909C", fontSize: 13 }}>Loading tools from access scopes...</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (tools.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: "24px 16px", color: "#B0BEC5", fontSize: 13 }}>
        No tools available. Agent access scopes may not be configured.
      </div>
    );
  }

  return (
    <div style={{ width: "100%" }}>
      {/* Select All */}
      <div style={{ marginBottom: 16 }}>
        <button onClick={toggleAll} style={{
          padding: "6px 18px", fontSize: 13, fontWeight: 600, borderRadius: 6,
          border: `1px solid ${allSelected ? "#0072C6" : "#0072C6"}`, cursor: "pointer",
          backgroundColor: allSelected ? "#0072C6" : "#FFF",
          color: allSelected ? "#FFF" : "#0072C6",
        }}>
          {allSelected ? "Deselect All" : "Select All"}
        </button>
      </div>

      {/* Tool cards — 4 per row, same as LangGraph */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
        {tools.map((tool) => {
          const selected = selectedNames.includes(tool.name);
          const maxChars = 80;
          const isLong = tool.description && tool.description.length > maxChars;
          const truncated = isLong ? tool.description.slice(0, maxChars) + "..." : (tool.description || "No description");

          return (
            <div
              key={tool.id}
              onClick={() => toggle(tool.name)}
              style={{
                backgroundColor: "#FFF", borderRadius: 12, padding: 16, cursor: "pointer",
                border: selected ? "2px solid #0072C6" : "1px solid #E0E0E0",
                boxShadow: selected ? "0 0 0 1px #0072C6" : "0 1px 3px rgba(0,0,0,0.04)",
                height: 150, display: "flex", flexDirection: "column",
                overflow: "hidden", position: "relative",
                transition: "border-color 0.15s, box-shadow 0.15s",
              }}
            >
              {/* Top row: icon + checkbox */}
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={selected ? "#0072C6" : "#90A4AE"} strokeWidth="1.5">
                  <rect x="2" y="3" width="20" height="14" rx="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" />
                </svg>
                {selected ? (
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="11" fill="#0072C6" />
                    <path d="M7 12.5L10.5 16L17 9" stroke="#FFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                ) : (
                  <div style={{ width: 22, height: 22, borderRadius: "50%", border: "2px solid #CFD8DC" }} />
                )}
              </div>

              {/* Name + description */}
              <div style={{ marginTop: 12, flex: 1, overflow: "hidden" }}>
                <p style={{ fontSize: 13, fontWeight: 600, color: selected ? "#1A1A1A" : "#546E7A", lineHeight: "18px", wordBreak: "break-word", margin: "0 0 4px 0" }}>{tool.name}</p>
                <p style={{ fontSize: 11, color: "#90A4AE", lineHeight: "16px", margin: 0 }}>
                  {truncated}
                </p>
              </div>

              {/* Info icon for long descriptions */}
              {isLong && (
                <button
                  onClick={(e) => { e.stopPropagation(); setShowFullDesc(tool); }}
                  style={{
                    position: "absolute", bottom: 8, right: 8,
                    background: "rgba(255,255,255,0.9)", border: "1px solid #E0E0E0",
                    borderRadius: "50%", width: 26, height: 26,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    cursor: "pointer", boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                  }}
                  title="View full description"
                >
                  <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                    <circle cx="10" cy="10" r="9" stroke="#0072C6" strokeWidth="1.5" fill="none" />
                    <text x="10" y="14.5" textAnchor="middle" fill="#0072C6" fontSize="12" fontWeight="600" fontFamily="sans-serif">i</text>
                  </svg>
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Full description modal */}
      {showFullDesc && (
        <div onClick={() => setShowFullDesc(null)} style={{
          position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: "rgba(0,0,0,0.4)", zIndex: 9999,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <div onClick={(e) => e.stopPropagation()} style={{
            backgroundColor: "#FFF", borderRadius: 12, padding: "24px 28px",
            maxWidth: 480, width: "90%", maxHeight: "60vh", overflowY: "auto",
            boxShadow: "0 12px 40px rgba(0,0,0,0.15)",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A", margin: 0 }}>{showFullDesc.name}</h3>
              <button onClick={() => setShowFullDesc(null)} style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 4L12 12M12 4L4 12" stroke="#90A4AE" strokeWidth="2" strokeLinecap="round" /></svg>
              </button>
            </div>
            <p style={{ fontSize: 14, color: "#546E7A", lineHeight: 1.6 }}>{showFullDesc.description}</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Standard Field ───
function DynamicField({ field, value, onChange, allValues, mcpToolsFromScopes, toolsLoading }) {
  if (field.condition) {
    if (allValues[field.condition.field] !== field.condition.value) return null;
  }

  const val = value ?? "";

  // Tools Grid
  if (field.type === "tools_grid") {
    return {
      field: { ...field, fullWidth: true },
      element: (
        <ToolsGrid field={field} value={val} onChange={onChange} mcpToolsFromScopes={mcpToolsFromScopes} toolsLoading={toolsLoading} />
      ),
    };
  }

  // Repeater and chips are always full-width and have their own layout
  if (field.type === "repeater") {
    return {
      field: { ...field, fullWidth: true },
      element: (
        <div className="flex items-start">
          {field.label && (
            <label className="text-sm flex-shrink-0 pr-3" style={{ color: "#37474F", fontWeight: 500, minWidth: 120, paddingTop: 8 }}>
              {field.label}
              {field.required && <span style={{ color: "#E53E3E", marginLeft: 2 }}>*</span>}
            </label>
          )}
          <RepeaterField field={field} value={val} onChange={onChange} allValues={allValues} />
        </div>
      ),
    };
  }

  if (field.type === "chips") {
    return {
      field: { ...field, fullWidth: true },
      element: (
        <div className="flex items-start">
          {field.label && (
            <label className="text-sm flex-shrink-0 pr-3" style={{ color: "#37474F", fontWeight: 500, minWidth: 120, paddingTop: 6 }}>
              {field.label}
              {field.required && <span style={{ color: "#E53E3E", marginLeft: 2 }}>*</span>}
            </label>
          )}
          <ChipsField field={field} value={val} onChange={onChange} allValues={allValues} />
        </div>
      ),
    };
  }

  if (field.type === "hitl") {
    return {
      field: { ...field, fullWidth: true },
      element: (
        <div className="flex items-start">
          {field.label && (
            <label className="text-sm flex-shrink-0 pr-3" style={{ color: "#37474F", fontWeight: 500, minWidth: 120, paddingTop: 8 }}>
              {field.label}
            </label>
          )}
          <HitlField field={field} value={val} onChange={onChange} allValues={allValues} />
        </div>
      ),
    };
  }

  const labelColor = field.disabled ? "#C0C8CC" : "#37474F";
  const labelWeight = field.disabled ? 400 : 500;

  const renderInput = () => {
    switch (field.type) {
      case "text":
        return <input type="text" value={val} onChange={(e) => onChange(field.id, e.target.value)} placeholder={field.placeholder || ""} disabled={field.disabled} className="flex-1" style={{ ...INPUT_STYLE, cursor: field.disabled ? "not-allowed" : undefined }} />;

      case "textarea":
      case "json":
        return (
          <textarea
            value={typeof val === "string" ? val : JSON.stringify(val, null, 2)}
            onChange={(e) => onChange(field.id, e.target.value)}
            placeholder={field.placeholder || ""} rows={field.rows || 4} disabled={field.disabled} className="flex-1"
            style={{ ...INPUT_STYLE, resize: "vertical", cursor: field.disabled ? "not-allowed" : undefined, ...(field.type === "json" && { fontFamily: "'Consolas', 'Monaco', monospace", fontSize: 12 }) }}
          />
        );

      case "number":
        return <input type="number" value={val} onChange={(e) => onChange(field.id, e.target.value === "" ? "" : Number(e.target.value))} placeholder={field.placeholder || ""} disabled={field.disabled} className="flex-1" style={INPUT_STYLE} />;

      case "toggle":
        return (
          <div onClick={() => !field.disabled && onChange(field.id, !val)} className="flex-1" style={{ display: "flex", alignItems: "center", gap: 10, cursor: field.disabled ? "not-allowed" : "pointer" }}>
            <div style={{ width: 40, height: 22, borderRadius: 11, backgroundColor: val ? "#0072C6" : "#CFD8DC", position: "relative", transition: "background-color 0.2s" }}>
              <div style={{ width: 18, height: 18, borderRadius: "50%", backgroundColor: "#FFF", position: "absolute", top: 2, left: val ? 20 : 2, transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
            </div>
            <span style={{ fontSize: 14, color: "#546E7A" }}>{val ? "Enabled" : "Disabled"}</span>
          </div>
        );

      case "checkbox":
        return <div className="flex-1" style={{ display: "flex", alignItems: "center", gap: 8 }}><input type="checkbox" checked={!!val} onChange={(e) => onChange(field.id, e.target.checked)} style={{ width: 16, height: 16, accentColor: "#0072C6" }} /><span style={{ fontSize: 14, color: "#546E7A" }}>{field.placeholder || "Enable"}</span></div>;

      case "dropdown":
        return (
          <div className="relative flex-1">
            <select value={val} onChange={(e) => onChange(field.id, e.target.value)} disabled={field.disabled} className="w-full" style={{ ...INPUT_STYLE, appearance: "none", paddingRight: 32, cursor: field.disabled ? "not-allowed" : "pointer" }}>
              <option value="">{field.placeholder || "Select..."}</option>
              {(field.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none"><ChevronDown /></div>
          </div>
        );

      case "radio":
        return (
          <div className="flex-1" style={{ display: "flex", gap: 20, flexWrap: "wrap", paddingTop: 2 }}>
            {(field.options || []).map((o) => (
              <label key={o.value} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 14, color: "#37474F" }}>
                <input type="radio" name={field.id} checked={String(val) === String(o.value)} onChange={() => onChange(field.id, o.value)} style={{ accentColor: "#0072C6", width: 16, height: 16 }} />
                {o.label}
              </label>
            ))}
          </div>
        );

      case "readonly":
        return <div className="flex-1" style={{ ...INPUT_STYLE, cursor: "not-allowed", color: "#A0AEB5" }}>{val || "—"}</div>;

      default:
        return <input type="text" value={val} onChange={(e) => onChange(field.id, e.target.value)} className="flex-1" style={INPUT_STYLE} />;
    }
  };

  const isMultiline = field.type === "textarea" || field.type === "json";

  return {
    field,
    element: (
      <div className={`flex ${isMultiline ? "items-start" : "items-center"}`}>
        {field.label && (
          <label className="text-sm flex-shrink-0 pr-3" style={{ color: labelColor, fontWeight: labelWeight, minWidth: 120, paddingTop: isMultiline ? 12 : 0 }}>
            {field.label}
            {field.required && <span style={{ color: "#E53E3E", marginLeft: 2 }}>*</span>}
          </label>
        )}
        {renderInput()}
      </div>
    ),
  };
}

// ─── Section Card ───
function SectionCard({ title, fields, values, onChange, mcpToolsFromScopes, toolsLoading }) {
  const visibleFields = fields
    .map((f) => DynamicField({ field: f, value: values[f.id], onChange, allValues: values, mcpToolsFromScopes, toolsLoading }))
    .filter((result) => result !== null);

  const rows = [];
  let i = 0;
  while (i < visibleFields.length) {
    const f = visibleFields[i];
    const isFullWidth = f.field.fullWidth || f.field.type === "textarea" || f.field.type === "json" || f.field.type === "repeater" || f.field.type === "chips" || f.field.type === "hitl" || f.field.type === "tools_grid";

    if (isFullWidth) {
      rows.push([f]);
      i++;
    } else if (i + 1 < visibleFields.length) {
      const next = visibleFields[i + 1];
      const nextFull = next.field.fullWidth || next.field.type === "textarea" || next.field.type === "json" || next.field.type === "repeater" || next.field.type === "chips" || next.field.type === "hitl" || next.field.type === "tools_grid";
      if (nextFull) { rows.push([f]); i++; }
      else { rows.push([f, next]); i += 2; }
    } else {
      rows.push([f]); i++;
    }
  }

  return (
    <div style={{ backgroundColor: "#FFF", border: "1px solid #E0E0E0", borderRadius: 8, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
      {title && (
        <div style={{ padding: "10px 20px", backgroundColor: "#EBF5FB", borderBottom: "1px solid #D6EAF8", borderRadius: "8px 8px 0 0", display: "flex", alignItems: "center", gap: 8 }}>
          <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="#0072C6" strokeWidth="1.5" fill="none" /><text x="10" y="14.5" textAnchor="middle" fill="#0072C6" fontSize="12" fontWeight="600" fontFamily="sans-serif">i</text></svg>
          <span style={{ fontSize: 14, fontWeight: 600, color: "#003366" }}>{title}</span>
        </div>
      )}
      <div className="px-5 pt-5 pb-4">
        {rows.map((row, idx) => (
          <div key={idx} className={`${idx > 0 ? "mt-5" : ""} ${row.length === 2 ? "flex gap-6" : ""}`}>
            {row.map((item) => (
              <div key={item.field.id} style={{ flex: row.length === 2 ? 1 : undefined }}>{item.element}</div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main Step Renderer ───
export default function DynamicStepRenderer({ step, values, onChange, mcpToolsFromScopes, toolsLoading }) {
  const enabledSections = (step.sections || []).filter((s) => s.enabled !== false);
  if (enabledSections.length === 0) return null;

  return (
    <div className="mt-5">
      <SectionHeader>{step.name}</SectionHeader>
      <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
        {enabledSections.map((section, idx) => (
          <SectionCard key={idx} title={section.title} fields={section.fields} values={values} onChange={onChange} mcpToolsFromScopes={mcpToolsFromScopes} toolsLoading={toolsLoading} />
        ))}
      </div>
    </div>
  );
}