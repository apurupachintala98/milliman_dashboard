// import { useState, useRef, useEffect } from "react";
// import { Navigate } from "react-router-dom";
// import Header from "../components/Header";
// import ServiceEndpoint from "../components/ServiceEndpoint";
// import { SendHorizonal } from "lucide-react";
// import { v4 as uuidv4 } from "uuid";

// const SSE_LOGS = [];

// const TOOL_RESULT = `{ "status": "success", "results": [
//   {"plan": "PPO Gold", "diff": 0.03},
//   {"plan": "HDHP Silver", "diff": 0} ] }`;

// const typeColors = {
//     EVENT: "text-blue-600",
//     SSE: "text-teal-600",
//     TOOL: "text-blue-600",
// };

// function BotIcon() {
//     return (
//         <div className="w-9 h-9 flex items-center justify-center flex-shrink-0"
//             style={{
//                 borderRadius: "16777200px",
//                 background: "rgba(0, 45, 114, 0.05)",
//             }}
//         >
//             <svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16" fill="none">
//                 <g clipPath="url(#clip0_179_1715)">
//                     <path d="M2.45455 10.8636C1.77273 10.8636 1.19319 10.6251 0.715911 10.1478C0.238637 9.6705 -1.86557e-07 9.09095 -1.86557e-07 8.40913C-1.86557e-07 7.72731 0.238637 7.14776 0.715911 6.67049C1.19319 6.19322 1.77273 5.95458 2.45455 5.95458V4.31821C2.45455 3.86821 2.61477 3.48298 2.93523 3.16252C3.25569 2.84207 3.64091 2.68184 4.09092 2.68184H6.54547C6.54547 2.00003 6.7841 1.42048 7.26137 0.943206C7.73865 0.465932 8.31819 0.227295 9.00002 0.227295C9.68183 0.227295 10.2614 0.465932 10.7387 0.943206C11.2159 1.42048 11.4546 2.00003 11.4546 2.68184H13.9091C14.3591 2.68184 14.7444 2.84207 15.0648 3.16252C15.3852 3.48298 15.5455 3.86821 15.5455 4.31821V5.95458C16.2273 5.95458 16.8069 6.19322 17.2842 6.67049C17.7614 7.14776 18 7.72731 18 8.40913C18 9.09095 17.7614 9.6705 17.2842 10.1478C16.8069 10.6251 16.2273 10.8636 15.5455 10.8636V14.1364C15.5455 14.5864 15.3852 14.9717 15.0648 15.2921C14.7444 15.6125 14.3591 15.7727 13.9091 15.7727H4.09092C3.64091 15.7727 3.25569 15.6125 2.93523 15.2921C2.61477 14.9717 2.45455 14.5864 2.45455 14.1364V10.8636ZM6.54547 9.22731C6.88638 9.22731 7.17615 9.10799 7.41478 8.86935C7.65342 8.63072 7.77274 8.34095 7.77274 8.00004C7.77274 7.65912 7.65342 7.36936 7.41478 7.13072C7.17615 6.89208 6.88638 6.77276 6.54547 6.77276C6.20455 6.77276 5.91479 6.89208 5.67615 7.13072C5.43751 7.36936 5.31819 7.65912 5.31819 8.00004C5.31819 8.34095 5.43751 8.63072 5.67615 8.86935C5.91479 9.10799 6.20455 9.22731 6.54547 9.22731ZM11.4546 9.22731C11.7955 9.22731 12.0852 9.10799 12.3239 8.86935C12.5625 8.63072 12.6819 8.34095 12.6819 8.00004C12.6819 7.65912 12.5625 7.36936 12.3239 7.13072C12.0852 6.89208 11.7955 6.77276 11.4546 6.77276C11.1136 6.77276 10.8239 6.89208 10.5852 7.13072C10.3466 7.36936 10.2273 7.65912 10.2273 8.00004C10.2273 8.34095 10.3466 8.63072 10.5852 8.86935C10.8239 9.10799 11.1136 9.22731 11.4546 9.22731ZM5.72728 12.5H12.2727V10.8636H5.72728V12.5ZM4.09092 14.1364H13.9091V4.31821H4.09092V14.1364Z" fill="#1A3673" />
//                 </g>
//                 <defs>
//                     <clipPath id="clip0_179_1715">
//                         <rect width="18" height="16" fill="white" />
//                     </clipPath>
//                 </defs>
//             </svg>
//         </div>
//     );
// }

// function UserIcon() {
//     return (
//         <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
//             style={{
//                 borderRadius: "16777200px",
//                 background: "rgba(0, 153, 204, 0.10)"
//             }}>
//             <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
//                 <g clipPath="url(#clip0_179_1734)">
//                     <path d="M6.50002 6.50002C5.60626 6.50002 4.84116 6.18179 4.2047 5.54533C3.56824 4.90886 3.25 4.14376 3.25 3.25C3.25 2.35626 3.56824 1.59115 4.2047 0.95469C4.84116 0.31823 5.60626 0 6.50002 0C7.39376 0 8.15888 0.31823 8.79533 0.95469C9.43179 1.59115 9.75002 2.35626 9.75002 3.25C9.75002 4.14376 9.43179 4.90886 8.79533 5.54533C8.15888 6.18179 7.39376 6.50002 6.50002 6.50002ZM0 13V10.725C0 10.2646 0.11849 9.84148 0.355469 9.45549C0.592449 9.06955 0.907294 8.77502 1.3 8.5719C2.13958 8.1521 2.99271 7.83725 3.85938 7.62737C4.72605 7.41747 5.60626 7.31252 6.50002 7.31252C7.39376 7.31252 8.27398 7.41747 9.14065 7.62737C10.0073 7.83725 10.8605 8.1521 11.7 8.5719C12.0928 8.77502 12.4076 9.06955 12.6446 9.45549C12.8815 9.84148 13 10.2646 13 10.725V13H0ZM1.62501 11.3751H11.3751V10.725C11.3751 10.576 11.3378 10.4406 11.2633 10.3187C11.1888 10.1969 11.0907 10.1021 10.9688 10.0344C10.2375 9.66878 9.49951 9.39456 8.75471 9.21174C8.00992 9.02893 7.25835 8.93752 6.50002 8.93752C5.74168 8.93752 4.99012 9.02893 4.24533 9.21174C3.50053 9.39456 2.7625 9.66878 2.03125 10.0344C1.90938 10.1021 1.8112 10.1969 1.73672 10.3187C1.66224 10.4406 1.62501 10.576 1.62501 10.725V11.3751ZM6.50002 4.87501C6.94689 4.87501 7.32944 4.7159 7.64768 4.39767C7.96591 4.07944 8.12502 3.69689 8.12502 3.25C8.12502 2.80313 7.96591 2.42058 7.64768 2.10235C7.32944 1.78412 6.94689 1.62501 6.50002 1.62501C6.05314 1.62501 5.67058 1.78412 5.35235 2.10235C5.03412 2.42058 4.87501 2.80313 4.87501 3.25C4.87501 3.69689 5.03412 4.07944 5.35235 4.39767C5.67058 4.7159 6.05314 4.87501 6.50002 4.87501Z" fill="#0099CC" />
//                 </g>
//                 <defs>
//                     <clipPath id="clip0_179_1734">
//                         <rect width="13" height="13" fill="white" />
//                     </clipPath>
//                 </defs>
//             </svg>
//         </div>
//     );
// }

// function StructuredResponse() {
//     return (
//         <div className="text-sm text-gray-700 leading-relaxed space-y-3">
//             <p>For the 2024 plan year, there are a few key updates to premiums depending on your selected tier.</p>
//             <ul className="space-y-2">
//                 <li className="flex items-start gap-2">
//                     <span className="mt-2 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
//                     <span><span className="font-medium text-gray-800">PPO Gold:</span> 3% increase in monthly employee contribution.</span>
//                 </li>
//                 <li className="flex items-start gap-2">
//                     <span className="mt-2 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
//                     <span><span className="font-medium text-gray-800">HDHP Silver:</span> No change to premiums, HSA match remains at $500.</span>
//                 </li>
//             </ul>
//             <p className="text-gray-500">Would you like to see the specific breakdown for your current plan?</p>
//         </div>
//     );
// }


// export default function ChatPage() {
//     const [messages, setMessages] = useState([]);
//     const [input, setInput] = useState("");
//     const bottomRef = useRef(null);
//     const [isLoading, setIsLoading] = useState(false);
//     const [loading, setLoading] = useState(false);
//     const [errorNotification, setErrorNotification] = useState("");
//     const [apiUrl, setApiUrl] = useState("");

//     // Read localStorage values as state so they are reactive
//     const [agentId, setAgentId] = useState("");
//     const [sesnId, setSesnId] = useState("");
//     const [userId, setUserId] = useState("");
//     const [appCode, setAppCode] = useState("");
//     const [agentName, setAgentName] = useState("");
//     const [agentType, setAgentType] = useState("");
//     const [sseLogs, setSseLogs] = useState([]);
//     const requestStartTime = useRef(null);
//     // Cortex session UUID — stays the same until refresh is clicked
//     const cortexSessionIdRef = useRef(uuidv4());
//     const [cortexSessionId, setCortexSessionId] = useState(cortexSessionIdRef.current);
//     // Deep Agent execution flow logs (per query)
//     const [executionLogs, setExecutionLogs] = useState([]);
//     const streamingRef = useRef(null);
//     const [metrics, setMetrics] = useState({
//         latency: "—",
//         cacheRead: "—",
//         cacheWrite: "—",
//         inputTokens: "—",
//         outputTokens: "—",
//         modelName: "—",
//     });

//     // Read localStorage on mount
//     useEffect(() => {
//         setAgentId(localStorage.getItem("agentId") || "");
//         setSesnId(localStorage.getItem("session_id") || localStorage.getItem("session_Id") || "");
//         setUserId(localStorage.getItem("user_id") || "");
//         setAppCode(localStorage.getItem("aplctn_cd") || "");
//         setAgentName(localStorage.getItem("agentName") || "");
//         setAgentType(localStorage.getItem("agentType") || "");
//     }, []);

//     useEffect(() => {
//         bottomRef.current?.scrollIntoView({ behavior: "smooth" });
//     }, [messages]);

  
//     useEffect(() => {
//         if (!agentName && agentType !== "Deep Agent") return;

//         const buildUrl = async () => {
//             try {
//                 const base = "https://agentbuilder-demo.edl.dev.awsdns.internal.das";

//                 let generatedUrl;
//                 if (agentType === "LangGraph") {
//                     const formatted = agentName.trim().replace(/\s+/g, "");
//                     generatedUrl = `${base}/${formatted}be-service/`;
//                 } else if (agentType === "Deep Agent") {
//                     try {
//                         const { API_CONFIG } = await import("../config/api-config");
//                         generatedUrl = API_CONFIG?.BASE_URL;
//                     } catch {
//                         generatedUrl = "https://agentbuilder-demo.edl.dev.awsdns.internal.da";
//                     }
//                 } else {
//                     const formatted = agentName.toLowerCase().trim().replace(/\s+/g, "");
//                     generatedUrl = `${base}/${formatted}-service/`;
//                 }

//                 setApiUrl(generatedUrl);
//             } catch (error) {
//                 console.error("Failed to build service URL:", error);
//             }
//         };
//         buildUrl();
//     }, [agentName, agentType]);


//     // ── Cortex SSE streaming handler ──
//     const handleCortexStream = async (endpoint, payload) => {
//         // Add a placeholder assistant message that we'll stream into
//         const assistantId = Date.now() + 1;
//         const placeholderMsg = {
//             id: assistantId,
//             role: "assistant",
//             text: "",
//             time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//             isStreaming: true,
//         };
//         setMessages(prev => [...prev, placeholderMsg]);

//         const res = await fetch(endpoint, {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify(payload),
//         });

//         if (!res.ok) throw new Error(`API Error ${res.status}`);

//         const reader = res.body.getReader();
//         const decoder = new TextDecoder();
//         let buffer = "";
//         let streamedText = "";
//         let finalText = "";

//         while (true) {
//             const { done, value } = await reader.read();
//             if (done) break;

//             buffer += decoder.decode(value, { stream: true });
//             const lines = buffer.split("\n");
//             buffer = lines.pop() || "";

//             let currentEventType = "";

//             for (const line of lines) {
//                 if (line.startsWith("event: ")) {
//                     currentEventType = line.slice(7).trim();
//                     continue;
//                 }

//                 if (line.startsWith("data: ")) {
//                     const dataStr = line.slice(6).trim();
//                     if (dataStr === "[DONE]") continue;

//                     try {
//                         const data = JSON.parse(dataStr);

//                         // Stream text deltas in real-time
//                         if (currentEventType === "response.text.delta" && data.text) {
//                             streamedText += data.text;
//                             setMessages(prev =>
//                                 prev.map(m => m.id === assistantId ? { ...m, text: streamedText } : m)
//                             );
//                         }

//                         // Final complete response — extract the text block and metrics
//                         if (currentEventType === "response" && data.content) {
//                             const textBlock = data.content.find(c => c.type === "text");
//                             if (textBlock?.text) {
//                                 finalText = textBlock.text;
//                             }

//                             // Extract metrics from response metadata
//                             const usage = data.metadata?.usage?.tokens_consumed?.[0];
//                             if (usage) {
//                                 const latencyMs = requestStartTime.current
//                                     ? Date.now() - requestStartTime.current
//                                     : 0;
//                                 setMetrics({
//                                     latency: latencyMs > 0 ? `${latencyMs}ms` : "—",
//                                     cacheRead: usage.input_tokens?.cache_read ?? "—",
//                                     cacheWrite: usage.input_tokens?.cache_write ?? "—",
//                                     inputTokens: usage.input_tokens?.total ?? "—",
//                                     outputTokens: usage.output_tokens?.total ?? "—",
//                                     modelName: usage.model_name || "—",
//                                 });
//                             }
//                         }

//                         // Update SSE debug logs
//                         if (currentEventType === "response.status" && data.message) {
//                             setSseLogs(prev => [...prev, {
//                                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
//                                 type: "EVENT",
//                                 content: data.message,
//                             }]);
//                         }

//                         if (currentEventType === "response.tool_use" && data.name) {
//                             setSseLogs(prev => [...prev, {
//                                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
//                                 type: "TOOL",
//                                 content: `call: ${data.name}`,
//                             }]);
//                         }

//                     } catch (e) {
//                         // Skip malformed JSON lines
//                     }
//                 }
//             }
//         }

//         // Once stream is done, set the final complete text and remove streaming flag
//         const displayText = finalText || streamedText || "No response received.";
//         setMessages(prev =>
//             prev.map(m => m.id === assistantId ? { ...m, text: displayText, isStreaming: false } : m)
//         );
//     };

//     // ── LangGraph JSON handler (unchanged) ──
//     const handleLangGraphRequest = async (endpoint, payload) => {
//         const res = await fetch(endpoint, {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify(payload),
//         });

//         if (!res.ok) throw new Error(`API Error ${res.status}`);

//         const data = await res.json();

//         const assistantText =
//             data?.response?.messages?.[0]?.content ||
//             data?.response ||
//             "No response received.";

//         const assistantMessage = {
//             id: Date.now() + 1,
//             role: "assistant",
//             text: assistantText,
//             time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//         };

//         setMessages(prev => [...prev, assistantMessage]);
//     };

//     // ─── Deep Agent handler ───
//     const handleDeepAgentRequest = async (endpoint, payload, userQuestion) => {
//         const res = await fetch(endpoint, {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify(payload),
//         });

//         if (!res.ok) throw new Error(`API Error ${res.status}`);
//         const data = await res.json();

//         // Check interrupted
//         if (data.interrupted) {
//             setMessages(prev => [...prev, {
//                 id: Date.now() + 1, role: "assistant",
//                 text: " The agent was interrupted. Please try again.",
//                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//             }]);
//             setIsLoading(false);
//             return;
//         }

//         // Calculate latency
//         const latencyMs = requestStartTime.current ? Date.now() - requestStartTime.current : 0;

//         // Build execution log for this query
//         const execLog = {
//             id: Date.now(),
//             question: userQuestion,
//             expanded: true,
//             messages: (data.messages || []).map((msg, idx) => ({
//                 id: idx,
//                 type: msg.type,
//                 name: msg.name || null,
//                 content: msg.content || "",
//                 toolCalls: msg.tool_calls || [],
//                 toolCallId: msg.tool_call_id || null,
//                 status: msg.status || null,
//             })),
//             latency: `${latencyMs}ms`,
//         };
//         setExecutionLogs(prev => [...prev, execLog]);

//         // Wait for execution panel to render, then stream the response
//         const responseText = data.response || "No response received.";
//         setTimeout(() => {
//             // Add placeholder streaming message
//             const streamMsgId = Date.now() + 1;
//             setMessages(prev => [...prev, {
//                 id: streamMsgId, role: "assistant", text: "", isStreaming: true,
//                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//             }]);

//             // Stream character by character
//             let charIdx = 0;
//             const streamSpeed = 12; // ms per character
//             if (streamingRef.current) clearInterval(streamingRef.current);
//             streamingRef.current = setInterval(() => {
//                 charIdx++;
//                 if (charIdx >= responseText.length) {
//                     clearInterval(streamingRef.current);
//                     streamingRef.current = null;
//                     setMessages(prev => prev.map(m =>
//                         m.id === streamMsgId ? { ...m, text: responseText, isStreaming: false } : m
//                     ));
//                     setIsLoading(false);
//                 } else {
//                     setMessages(prev => prev.map(m =>
//                         m.id === streamMsgId ? { ...m, text: responseText.slice(0, charIdx) } : m
//                     ));
//                 }
//             }, streamSpeed);
//         }, 800); // delay to let execution panel render first
//     };

//     const handleSubmit = async () => {
//         const content = input.trim();
//         if (!content) return;

//         const userMessage = {
//             id: Date.now(),
//             role: "user",
//             text: content,
//             time: new Date().toLocaleTimeString([], {
//                 hour: "2-digit",
//                 minute: "2-digit",
//             }),
//         };

//         setMessages(prev => [...prev, userMessage]);
//         setInput("");
//         requestStartTime.current = Date.now();
//         setIsLoading(true);

//         if (!apiUrl) {
//             console.error("API URL missing");
//             setIsLoading(false);
//             return;
//         }

//         try {
//             if (agentType === "LangGraph") {
//                 // LangGraph: JSON request/response
//                 const endpoint = `${apiUrl.replace(/\/$/, "")}/agent/chat`;
//                 const payload = {
//                     agent_id: agentId,
//                     application_id: appCode,
//                     user_id: userId,
//                     session_id: sesnId,
//                     body: {
//                         content_type: "text",
//                         messages: [{ role: "user", content: content }],
//                     },
//                 };
//                 await handleLangGraphRequest(endpoint, payload);
//             } else if (agentType === "Deep Agent") {
//                 // Deep Agent: JSON request with execution flow
//                 const agentUuid = localStorage.getItem("agentUuid") || agentId;
//                 const endpoint = `${apiUrl.replace(/\/$/, "")}/chat`;
//                 const payload = {
//                     content: content,
//                     user_id: userId,
//                     agent_id: agentUuid,
//                     thread_id: sesnId,
//                 };
//                 await handleDeepAgentRequest(endpoint, payload, content);
//             } else {
//                 // Cortex: SSE streaming
//                 const endpoint = `${apiUrl.replace(/\/$/, "")}/run_${appCode.toLowerCase()}_agent`;
//                 const payload = {
//                     application_name: appCode,
//                     agent_id: cortexSessionId,
//                     messages: [
//                         {
//                             role: "user",
//                             content: [{ type: "text", text: content }],
//                         },
//                     ],
//                 };
//                 await handleCortexStream(endpoint, payload);
//             }
//         } catch (error) {
//             console.error(error);

//             setMessages(prev => [
//                 ...prev,
//                 {
//                     id: Date.now() + 2,
//                     role: "assistant",
//                     text: "Sorry, something went wrong.",
//                     time: new Date().toLocaleTimeString([], {
//                         hour: "2-digit",
//                         minute: "2-digit",
//                     }),
//                 },
//             ]);
//         } finally {
//             setIsLoading(false);
//         }
//     };

//     // Redirect to login if not authenticated
//     if (!localStorage.getItem("user_id") || !localStorage.getItem("aplctn_cd")) {
//         return <Navigate to="/" replace />;
//     }

//     return (
//         <div
//             className="min-h-screen bg-gray-100 text-gray-900 flex flex-col"
//             style={{ fontFamily: "'Segoe UI', sans-serif" }}
//         >
//             <Header />
//             <div className="px-6 py-4">
//                 <ServiceEndpoint url={apiUrl} />
//             </div>

//             <div className='flex flex-col h-full flex-1'>
//                 <div className="flex flex-1 overflow-hidden relative">

//                     {/* Chat Area */}
//                     <div className="flex-1 flex flex-col min-w-0 px-4">
//                         {/* Agent tag */}
//                         <div className="bg-gray-100 border-b border-gray-200 px-6 py-2 flex items-center gap-2">
//                             <span className="text-sm text-gray-500">Testing:</span>
//                             <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow shadow-blue-200" />
//                             <span className="text-sm font-semibold text-gray-700">{agentName || "Agent"}</span>
//                             <div style={{ flex: 1 }} />
//                             <button
//                                 onClick={() => {
//                                     setMessages([]);
//                                     setSseLogs([]);
//                                     setInput("");
//                                     setIsLoading(false);
//                                     // Generate new session ID for fresh LangGraph conversation
//                                     const newSessionId = uuidv4();
//                                     setSesnId(newSessionId);
//                                     localStorage.setItem("session_id", newSessionId);
//                                     localStorage.setItem("session_Id", newSessionId);
//                                     // Reset Cortex session UUID
//                                     const newCortexId = uuidv4();
//                                     cortexSessionIdRef.current = newCortexId;
//                                     setCortexSessionId(newCortexId);
//                                     // Reset metrics
//                                     setMetrics({ latency: "—", cacheRead: "—", cacheWrite: "—", inputTokens: "—", outputTokens: "—", modelName: "—" });
//                                     // Reset Deep Agent execution logs
//                                     setExecutionLogs([]);
//                                     if (streamingRef.current) { clearInterval(streamingRef.current); streamingRef.current = null; }
//                                 }}
//                                 title="Refresh Chat"
//                                 style={{
//                                     background: "none", border: "none", cursor: "pointer",
//                                     padding: 4, borderRadius: 6, display: "flex", alignItems: "center",
//                                     justifyContent: "center", transition: "background 0.2s",
//                                 }}
//                                 onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(0,121,194,0.08)"; }}
//                                 onMouseLeave={(e) => { e.currentTarget.style.background = "none"; }}
//                             >
//                                 <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#546E7A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                                     <polyline points="23 4 23 10 17 10" />
//                                     <polyline points="1 20 1 14 7 14" />
//                                     <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
//                                 </svg>
//                             </button>
//                         </div>

//                         {/* Messages */}
//                         <div className="flex-1 overflow-y-auto px-8 py-6 space-y-5 bg-gray-100">
//                             {messages.map(msg => (
//                                 <div
//                                     key={msg.id}
//                                     className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
//                                 >
//                                     {msg.role === "assistant" ? <BotIcon /> : <UserIcon />}
//                                     <div className={`max-w-xl flex flex-col gap-1 ${msg.role === "user" ? "items-end" : "items-start"}`}>
//                                         <div
//                                             className={`rounded-2xl px-5 py-3.5 shadow-sm text-sm leading-relaxed ${msg.role === "user"
//                                                 ? "bg-blue-50 border border-blue-100 text-gray-700 rounded-tr-sm"
//                                                 : "bg-white border border-gray-200 text-gray-700 rounded-tl-sm"
//                                                 }`}
//                                         >
//                                             {msg.structured
//                                                 ? <StructuredResponse />
//                                                 : msg.isStreaming && !msg.text
//                                                 ? (
//                                                     <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 0" }}>
//                                                         <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#0072C6", animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0s" }} />
//                                                         <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#0072C6", animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.2s" }} />
//                                                         <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#0072C6", animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.4s" }} />
//                                                     </div>
//                                                 )
//                                                 : <p className="whitespace-pre-line">{msg.text}{msg.isStreaming && <span style={{ display: "inline-block", width: 6, height: 16, backgroundColor: "#0072C6", marginLeft: 2, animation: "blink 0.8s infinite", verticalAlign: "text-bottom" }} />}</p>
//                                             }
//                                         </div>
//                                         <span className="text-xs text-gray-400 px-1">{msg.time}</span>
//                                     </div>
//                                 </div>
//                             ))}

//                             {/* Loading indicator while waiting for response */}
//                             {isLoading && !messages.some(m => m.isStreaming) && (
//                                 <div className="flex gap-3 flex-row">
//                                     <BotIcon />
//                                     <div className="rounded-2xl px-5 py-3.5 shadow-sm bg-white border border-gray-200 rounded-tl-sm">
//                                         <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
//                                             <span style={{
//                                                 width: 8, height: 8, borderRadius: "50%", backgroundColor: "#90A4AE",
//                                                 animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0s",
//                                             }} />
//                                             <span style={{
//                                                 width: 8, height: 8, borderRadius: "50%", backgroundColor: "#90A4AE",
//                                                 animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.2s",
//                                             }} />
//                                             <span style={{
//                                                 width: 8, height: 8, borderRadius: "50%", backgroundColor: "#90A4AE",
//                                                 animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.4s",
//                                             }} />
//                                         </div>
//                                     </div>
//                                 </div>
//                             )}

//                             <div ref={bottomRef} />
//                         </div>

//                         {/* Input */}
//                         <div className="px-6 py-4 flex space-x-3 items-end">
//                             <div className="relative flex-1 bg-white rounded-2xl border border-gray-300 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-50 transition-all shadow-sm">
//                                 <textarea
//                                     value={input}
//                                     onChange={e => setInput(e.target.value)}
//                                     onKeyDown={e => {
//                                         if (e.key === "Enter" && !e.shiftKey) {
//                                             e.preventDefault();
//                                             handleSubmit();
//                                         }
//                                     }}
//                                     placeholder="Type your message to test the agent..."
//                                     rows={2}
//                                     className="w-full bg-transparent px-4 pt-3 pb-10 text-sm text-gray-700 placeholder-gray-400 resize-none outline-none"
//                                 />
//                                 <div className="absolute bottom-2.5 left-3 flex items-center gap-1 w-full pr-8">
//                                     <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
//                                         <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                                             <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
//                                         </svg>
//                                     </button>
//                                     <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
//                                         <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                                             <ellipse cx="12" cy="5" rx="9" ry="3" />
//                                             <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
//                                             <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
//                                         </svg>
//                                     </button>

//                                     <div className="flex-1"></div>
//                                     <span className="text-xs text-gray-300 select-none">Shift + Enter for new line</span>
//                                 </div>
//                             </div>

//                             <div className="flex items-center gap-2 pb-2">
//                                 <button
//                                     type="button"
//                                     onClick={handleSubmit}
//                                     className="w-10 h-10 rounded-[50%] bg-blue-500 hover:bg-blue-600 flex items-center justify-center transition-colors shadow"
//                                 >
//                                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
//                                         <path d="M0.0183334 15.2577L1.36977 9.40529C1.42312 9.15625 1.63651 8.96058 1.90324 8.925L9.46063 8.14231C9.67402 8.12452 9.67402 7.80433 9.46063 7.76875L1.90324 7.03942C1.63651 7.02163 1.42312 6.82596 1.36977 6.57692L0.0183334 0.74229C-0.106141 0.244212 0.427322 -0.164924 0.889657 0.066327L15.6666 7.46635C16.1111 7.6976 16.1111 8.33798 15.6666 8.56923L0.889657 15.9337C0.427322 16.1649 -0.106141 15.7558 0.0183334 15.2577Z" fill="white" />
//                                     </svg>
//                                 </button>
//                             </div>
//                         </div>
//                     </div>

//                     {/* Right Panel — Execution Flow (Deep Agent) or SSE Debug (Cortex/LangGraph) */}
//                     {agentType === "Deep Agent" ? (
//                     <div className="w-96 border border-gray-200 bg-white flex flex-col flex-shrink-0 mx-4 mt-4 mb-3" style={{ borderRadius: 8 }}>
//                         <div className="px-5 py-3.5 flex items-center justify-between" style={{ borderBottom: "1px solid #E0E0E0" }}>
//                             <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
//                                 <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0072C6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                                     <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
//                                 </svg>
//                                 <span className="text-sm font-semibold" style={{ color: "#003366" }}>Execution Flow</span>
//                             </div>
//                             <span style={{ fontSize: 11, color: "#90A4AE" }}>{executionLogs.length} {executionLogs.length === 1 ? "query" : "queries"}</span>
//                         </div>

//                         <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2" style={{ fontSize: 13 }}>
//                             {executionLogs.length === 0 && (
//                                 <div style={{ textAlign: "center", padding: "40px 16px", color: "#B0BEC5" }}>
//                                     <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#CFD8DC" strokeWidth="1.5" style={{ margin: "0 auto 12px" }}>
//                                         <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
//                                     </svg>
//                                     <p style={{ fontSize: 13 }}>Execution details will appear here when you ask a question.</p>
//                                 </div>
//                             )}

//                             {executionLogs.map((log) => (
//                                 <div key={log.id} style={{ border: "1px solid #E2E8F0", borderRadius: 8, overflow: "hidden" }}>
//                                     {/* Query header — click to expand/collapse */}
//                                     <div
//                                         onClick={() => setExecutionLogs(prev => prev.map(l => l.id === log.id ? { ...l, expanded: !l.expanded } : l))}
//                                         style={{
//                                             display: "flex", alignItems: "center", justifyContent: "space-between",
//                                             padding: "10px 14px", cursor: "pointer",
//                                             backgroundColor: log.expanded ? "#F0F7FF" : "#FAFBFC",
//                                             borderBottom: log.expanded ? "1px solid #D6EAF8" : "none",
//                                         }}
//                                     >
//                                         <div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, minWidth: 0 }}>
//                                             <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#0072C6" strokeWidth="2" style={{ flexShrink: 0, transform: log.expanded ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.2s" }}>
//                                                 <polyline points="9 18 15 12 9 6" />
//                                             </svg>
//                                             <span style={{ fontSize: 12, fontWeight: 600, color: "#003366", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
//                                                 {log.question}
//                                             </span>
//                                         </div>
//                                         <span style={{ fontSize: 10, color: "#90A4AE", flexShrink: 0, marginLeft: 8 }}>{log.latency}</span>
//                                     </div>

//                                     {/* Execution steps */}
//                                     {log.expanded && (
//                                         <div style={{ padding: "8px 12px" }}>
//                                             {log.messages.map((msg, idx) => {
//                                                 const typeColors = { human: "#2E8540", ai: "#0072C6", tool: "#E65100" };
//                                                 const typeBg = { human: "#F0FFF4", ai: "#EBF5FB", tool: "#FFF3E0" };
//                                                 const typeIcons = {
//                                                     human: "👤",
//                                                     ai: "🤖",
//                                                     tool: "🔧",
//                                                 };

//                                                 return (
//                                                     <div key={idx} style={{ marginBottom: idx < log.messages.length - 1 ? 8 : 0 }}>
//                                                         {/* Step connector line */}
//                                                         {idx > 0 && (
//                                                             <div style={{ width: 1, height: 8, backgroundColor: "#D6EAF8", marginLeft: 14, marginBottom: 4 }} />
//                                                         )}
//                                                         <div style={{
//                                                             padding: "8px 10px", borderRadius: 6,
//                                                             backgroundColor: typeBg[msg.type] || "#F5F5F5",
//                                                             border: `1px solid ${typeColors[msg.type] || "#E0E0E0"}20`,
//                                                         }}>
//                                                             {/* Type badge + name */}
//                                                             <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
//                                                                 <span style={{ fontSize: 12 }}>{typeIcons[msg.type] || "📋"}</span>
//                                                                 <span style={{
//                                                                     fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5,
//                                                                     color: typeColors[msg.type] || "#546E7A",
//                                                                 }}>{msg.type}</span>
//                                                                 {msg.name && <span style={{ fontSize: 10, color: "#90A4AE" }}>· {msg.name}</span>}
//                                                                 {msg.status && (
//                                                                     <span style={{
//                                                                         fontSize: 9, fontWeight: 600, padding: "1px 6px", borderRadius: 8,
//                                                                         backgroundColor: msg.status === "success" ? "#C6F6D5" : "#FED7D7",
//                                                                         color: msg.status === "success" ? "#22543D" : "#9B2C2C",
//                                                                     }}>{msg.status}</span>
//                                                                 )}
//                                                             </div>
//                                                             {/* Content */}
//                                                             <div style={{ fontSize: 11, color: "#37474F", lineHeight: 1.5, whiteSpace: "pre-wrap", wordBreak: "break-word", maxHeight: 120, overflow: "auto" }}>
//                                                                 {msg.content || "—"}
//                                                             </div>
//                                                             {/* Tool calls */}
//                                                             {msg.toolCalls && msg.toolCalls.length > 0 && (
//                                                                 <div style={{ marginTop: 6, padding: "6px 8px", backgroundColor: "rgba(0,0,0,0.03)", borderRadius: 4 }}>
//                                                                     <span style={{ fontSize: 10, fontWeight: 600, color: "#78909C" }}>Tool Calls:</span>
//                                                                     {msg.toolCalls.map((tc, ti) => (
//                                                                         <div key={ti} style={{ marginTop: 4, fontSize: 11, color: "#546E7A" }}>
//                                                                             <span style={{ fontWeight: 600, color: "#E65100", fontFamily: "monospace" }}>{tc.name}</span>
//                                                                             {tc.args && (
//                                                                                 <pre style={{ fontSize: 10, color: "#78909C", margin: "2px 0 0 0", whiteSpace: "pre-wrap", fontFamily: "monospace", maxHeight: 80, overflow: "auto" }}>
//                                                                                     {JSON.stringify(tc.args, null, 2)}
//                                                                                 </pre>
//                                                                             )}
//                                                                         </div>
//                                                                     ))}
//                                                                 </div>
//                                                             )}
//                                                         </div>
//                                                     </div>
//                                                 );
//                                             })}
//                                         </div>
//                                     )}
//                                 </div>
//                             ))}
//                         </div>
//                     </div>
//                     ) : (
//                     /* SSE Debug Panel for Cortex/LangGraph */
//                     <div className="w-96 border border-gray-200 bg-white flex flex-col flex-shrink-0 mx-4 mt-4 mb-3">
//                         <div className="px-5 py-3.5 flex items-center justify-between">
//                             <span className="text-sm font-semibold text-gray-700">SSE Debug Terminal</span>
//                             <div className="flex items-center gap-1 text-gray-400">
//                                 <button className="p-1 rounded hover:bg-gray-100 hover:text-gray-600 transition-colors">
//                                     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                                         <circle cx="12" cy="12" r="10" /><line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
//                                     </svg>
//                                 </button>
//                                 <button className="p-1 rounded hover:bg-gray-100 hover:text-gray-600 transition-colors">
//                                     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                                         <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
//                                         <polyline points="7 10 12 15 17 10" />
//                                         <line x1="12" y1="15" x2="12" y2="3" />
//                                     </svg>
//                                 </button>
//                             </div>
//                         </div>

//                         <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 font-mono text-xs">
//                             {sseLogs.length > 0 && sseLogs.map((log, i) => (
//                                 <div key={i}>
//                                     <div className="flex items-start gap-2 leading-relaxed">
//                                         <span className="text-gray-400 flex-shrink-0 tabular-nums">{log.time}</span>
//                                         <span className={`font-bold flex-shrink-0 ${typeColors[log.type]}`}>[{log.type}]</span>
//                                         <span className="text-gray-600 whitespace-pre-line">{log.content}</span>
//                                     </div>
//                                 </div>
//                             ))}

//                             {sseLogs.length === 0 && (
//                                 <div className='text-gray-400 text-sm'>Debug Terminal Coming Soon...</div>
//                             )}
//                         </div>

//                         {agentType === "Cortex" ? (
//                         <div className="p-2 grid grid-cols-3 gap-y-2 gap-x-2 bg-white">
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">LATENCY</div>
//                                 <div className="text-sm font-bold text-gray-800">{metrics.latency}</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">CACHE READ</div>
//                                 <div className="text-sm font-bold text-gray-800">{metrics.cacheRead}</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">CACHE WRITE</div>
//                                 <div className="text-sm font-bold text-gray-800">{metrics.cacheWrite}</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">INPUT TOKENS</div>
//                                 <div className="text-sm font-bold text-gray-800">{metrics.inputTokens}</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">OUTPUT TOKENS</div>
//                                 <div className="text-sm font-bold text-gray-800">{metrics.outputTokens}</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">MODEL</div>
//                                 <div className="text-sm font-bold text-gray-800">{metrics.modelName}</div>
//                             </div>
//                         </div>
//                         ) : (
//                         <div className="p-2 grid grid-cols-2 gap-y-2 gap-x-2 bg-white">
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">LATENCY</div>
//                                 <div className="text-base font-bold text-gray-800">240ms</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">TOKEN</div>
//                                 <div className="text-base font-bold text-gray-800">1.2k</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">MODEL</div>
//                                 <div className="text-base font-bold text-gray-800">GPT-4 Turbo</div>
//                             </div>
//                             <div className="bg-[#F8FAFC] p-3">
//                                 <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">MEMORY</div>
//                                 <div className="text-base font-bold text-green-600">Active</div>
//                             </div>
//                         </div>
//                         )}
//                     </div>
//                     )}
//                 </div>

//                 <div className="text-gray-400 text-[14px] w-full text-center">&copy; 2026 Elevance Health Agent Studio. All rights reserved.</div>
//             </div>
//             <style>{`
//                 @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
//                 @keyframes dotPulse { 0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; } 40% { transform: scale(1); opacity: 1; } }
//             `}</style>
//         </div>
//     );
// }

import { useState, useRef, useEffect } from "react";
import { Navigate } from "react-router-dom";
import Header from "../components/Header";
import ServiceEndpoint from "../components/ServiceEndpoint";
import { SendHorizonal } from "lucide-react";
import { v4 as uuidv4 } from "uuid";

const SSE_LOGS = [];

const TOOL_RESULT = `{ "status": "success", "results": [
  {"plan": "PPO Gold", "diff": 0.03},
  {"plan": "HDHP Silver", "diff": 0} ] }`;

const typeColors = {
    EVENT: "text-blue-600",
    SSE: "text-teal-600",
    TOOL: "text-blue-600",
};

function BotIcon() {
    return (
        <div className="w-9 h-9 flex items-center justify-center flex-shrink-0"
            style={{
                borderRadius: "16777200px",
                background: "rgba(0, 45, 114, 0.05)",
            }}
        >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16" fill="none">
                <g clipPath="url(#clip0_179_1715)">
                    <path d="M2.45455 10.8636C1.77273 10.8636 1.19319 10.6251 0.715911 10.1478C0.238637 9.6705 -1.86557e-07 9.09095 -1.86557e-07 8.40913C-1.86557e-07 7.72731 0.238637 7.14776 0.715911 6.67049C1.19319 6.19322 1.77273 5.95458 2.45455 5.95458V4.31821C2.45455 3.86821 2.61477 3.48298 2.93523 3.16252C3.25569 2.84207 3.64091 2.68184 4.09092 2.68184H6.54547C6.54547 2.00003 6.7841 1.42048 7.26137 0.943206C7.73865 0.465932 8.31819 0.227295 9.00002 0.227295C9.68183 0.227295 10.2614 0.465932 10.7387 0.943206C11.2159 1.42048 11.4546 2.00003 11.4546 2.68184H13.9091C14.3591 2.68184 14.7444 2.84207 15.0648 3.16252C15.3852 3.48298 15.5455 3.86821 15.5455 4.31821V5.95458C16.2273 5.95458 16.8069 6.19322 17.2842 6.67049C17.7614 7.14776 18 7.72731 18 8.40913C18 9.09095 17.7614 9.6705 17.2842 10.1478C16.8069 10.6251 16.2273 10.8636 15.5455 10.8636V14.1364C15.5455 14.5864 15.3852 14.9717 15.0648 15.2921C14.7444 15.6125 14.3591 15.7727 13.9091 15.7727H4.09092C3.64091 15.7727 3.25569 15.6125 2.93523 15.2921C2.61477 14.9717 2.45455 14.5864 2.45455 14.1364V10.8636ZM6.54547 9.22731C6.88638 9.22731 7.17615 9.10799 7.41478 8.86935C7.65342 8.63072 7.77274 8.34095 7.77274 8.00004C7.77274 7.65912 7.65342 7.36936 7.41478 7.13072C7.17615 6.89208 6.88638 6.77276 6.54547 6.77276C6.20455 6.77276 5.91479 6.89208 5.67615 7.13072C5.43751 7.36936 5.31819 7.65912 5.31819 8.00004C5.31819 8.34095 5.43751 8.63072 5.67615 8.86935C5.91479 9.10799 6.20455 9.22731 6.54547 9.22731ZM11.4546 9.22731C11.7955 9.22731 12.0852 9.10799 12.3239 8.86935C12.5625 8.63072 12.6819 8.34095 12.6819 8.00004C12.6819 7.65912 12.5625 7.36936 12.3239 7.13072C12.0852 6.89208 11.7955 6.77276 11.4546 6.77276C11.1136 6.77276 10.8239 6.89208 10.5852 7.13072C10.3466 7.36936 10.2273 7.65912 10.2273 8.00004C10.2273 8.34095 10.3466 8.63072 10.5852 8.86935C10.8239 9.10799 11.1136 9.22731 11.4546 9.22731ZM5.72728 12.5H12.2727V10.8636H5.72728V12.5ZM4.09092 14.1364H13.9091V4.31821H4.09092V14.1364Z" fill="#1A3673" />
                </g>
                <defs>
                    <clipPath id="clip0_179_1715">
                        <rect width="18" height="16" fill="white" />
                    </clipPath>
                </defs>
            </svg>
        </div>
    );
}

function UserIcon() {
    return (
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
                borderRadius: "16777200px",
                background: "rgba(0, 153, 204, 0.10)"
            }}>
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                <g clipPath="url(#clip0_179_1734)">
                    <path d="M6.50002 6.50002C5.60626 6.50002 4.84116 6.18179 4.2047 5.54533C3.56824 4.90886 3.25 4.14376 3.25 3.25C3.25 2.35626 3.56824 1.59115 4.2047 0.95469C4.84116 0.31823 5.60626 0 6.50002 0C7.39376 0 8.15888 0.31823 8.79533 0.95469C9.43179 1.59115 9.75002 2.35626 9.75002 3.25C9.75002 4.14376 9.43179 4.90886 8.79533 5.54533C8.15888 6.18179 7.39376 6.50002 6.50002 6.50002ZM0 13V10.725C0 10.2646 0.11849 9.84148 0.355469 9.45549C0.592449 9.06955 0.907294 8.77502 1.3 8.5719C2.13958 8.1521 2.99271 7.83725 3.85938 7.62737C4.72605 7.41747 5.60626 7.31252 6.50002 7.31252C7.39376 7.31252 8.27398 7.41747 9.14065 7.62737C10.0073 7.83725 10.8605 8.1521 11.7 8.5719C12.0928 8.77502 12.4076 9.06955 12.6446 9.45549C12.8815 9.84148 13 10.2646 13 10.725V13H0ZM1.62501 11.3751H11.3751V10.725C11.3751 10.576 11.3378 10.4406 11.2633 10.3187C11.1888 10.1969 11.0907 10.1021 10.9688 10.0344C10.2375 9.66878 9.49951 9.39456 8.75471 9.21174C8.00992 9.02893 7.25835 8.93752 6.50002 8.93752C5.74168 8.93752 4.99012 9.02893 4.24533 9.21174C3.50053 9.39456 2.7625 9.66878 2.03125 10.0344C1.90938 10.1021 1.8112 10.1969 1.73672 10.3187C1.66224 10.4406 1.62501 10.576 1.62501 10.725V11.3751ZM6.50002 4.87501C6.94689 4.87501 7.32944 4.7159 7.64768 4.39767C7.96591 4.07944 8.12502 3.69689 8.12502 3.25C8.12502 2.80313 7.96591 2.42058 7.64768 2.10235C7.32944 1.78412 6.94689 1.62501 6.50002 1.62501C6.05314 1.62501 5.67058 1.78412 5.35235 2.10235C5.03412 2.42058 4.87501 2.80313 4.87501 3.25C4.87501 3.69689 5.03412 4.07944 5.35235 4.39767C5.67058 4.7159 6.05314 4.87501 6.50002 4.87501Z" fill="#0099CC" />
                </g>
                <defs>
                    <clipPath id="clip0_179_1734">
                        <rect width="13" height="13" fill="white" />
                    </clipPath>
                </defs>
            </svg>
        </div>
    );
}

function StructuredResponse() {
    return (
        <div className="text-sm text-gray-700 leading-relaxed space-y-3">
            <p>For the 2024 plan year, there are a few key updates to premiums depending on your selected tier.</p>
            <ul className="space-y-2">
                <li className="flex items-start gap-2">
                    <span className="mt-2 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                    <span><span className="font-medium text-gray-800">PPO Gold:</span> 3% increase in monthly employee contribution.</span>
                </li>
                <li className="flex items-start gap-2">
                    <span className="mt-2 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                    <span><span className="font-medium text-gray-800">HDHP Silver:</span> No change to premiums, HSA match remains at $500.</span>
                </li>
            </ul>
            <p className="text-gray-500">Would you like to see the specific breakdown for your current plan?</p>
        </div>
    );
}


export default function ChatPage() {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");
    const bottomRef = useRef(null);
    const [isLoading, setIsLoading] = useState(false);
    const [loading, setLoading] = useState(false);
    const [errorNotification, setErrorNotification] = useState("");
    const [apiUrl, setApiUrl] = useState("");

    // Read localStorage values as state so they are reactive
    const [agentId, setAgentId] = useState("");
    const [sesnId, setSesnId] = useState("");
    const [userId, setUserId] = useState("");
    const [appCode, setAppCode] = useState("");
    const [agentName, setAgentName] = useState("");
    const [agentType, setAgentType] = useState("");
    const [sseLogs, setSseLogs] = useState([]);
    const requestStartTime = useRef(null);
    // Cortex session UUID — stays the same until refresh is clicked
    const cortexSessionIdRef = useRef(uuidv4());
    const [cortexSessionId, setCortexSessionId] = useState(cortexSessionIdRef.current);
    // Deep Agent execution flow logs (per query)
    const [executionLogs, setExecutionLogs] = useState([]);
    const streamingRef = useRef(null);
    const [metrics, setMetrics] = useState({
        latency: "—",
        cacheRead: "—",
        cacheWrite: "—",
        inputTokens: "—",
        outputTokens: "—",
        modelName: "—",
    });

    // Read localStorage on mount
    useEffect(() => {
        setAgentId(localStorage.getItem("agentId") || "");
        setSesnId(localStorage.getItem("session_id") || localStorage.getItem("session_Id") || "");
        setUserId(localStorage.getItem("user_id") || "");
        setAppCode(localStorage.getItem("aplctn_cd") || "");
        setAgentName(localStorage.getItem("agentName") || "");
        setAgentType(localStorage.getItem("agentType") || "");
    }, []);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    // Build service endpoint URL
    // Base is always https://agentbuilder-demo.edl.dev.awsdns.internal.das/
    // LangGraph: {agentName}be-service/  (name already lowercase)
    // Cortex:    {agentName}-service/
    useEffect(() => {
        if (!agentName) return;

        const buildUrl = async () => {
            try {
                const base = "https://agentbuilder-demo.edl.dev.awsdns.internal.das";

                let generatedUrl;
                if (agentType === "LangGraph") {
                    const formatted = agentName.trim().replace(/\s+/g, "");
                    generatedUrl = `${base}/${formatted}be-service/`;
                } else if (agentType === "Deep Agent") {
                    // Deep Agent: same pattern as LangGraph but with ldabe-service
                    const formatted = agentName.toLowerCase().trim().replace(/\s+/g, "");
                    generatedUrl = `${base}/${formatted}ldabe-service/`;
                } else {
                    const formatted = agentName.toLowerCase().trim().replace(/\s+/g, "");
                    generatedUrl = `${base}/${formatted}-service/`;
                }

                setApiUrl(generatedUrl);
            } catch (error) {
                console.error("Failed to build service URL:", error);
            }
        };
        buildUrl();
    }, [agentName, agentType]);


    // ── Cortex SSE streaming handler ──
    const handleCortexStream = async (endpoint, payload) => {
        // Add a placeholder assistant message that we'll stream into
        const assistantId = Date.now() + 1;
        const placeholderMsg = {
            id: assistantId,
            role: "assistant",
            text: "",
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            isStreaming: true,
        };
        setMessages(prev => [...prev, placeholderMsg]);

        const res = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        if (!res.ok) throw new Error(`API Error ${res.status}`);

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let streamedText = "";
        let finalText = "";

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            let currentEventType = "";

            for (const line of lines) {
                if (line.startsWith("event: ")) {
                    currentEventType = line.slice(7).trim();
                    continue;
                }

                if (line.startsWith("data: ")) {
                    const dataStr = line.slice(6).trim();
                    if (dataStr === "[DONE]") continue;

                    try {
                        const data = JSON.parse(dataStr);

                        // Stream text deltas in real-time
                        if (currentEventType === "response.text.delta" && data.text) {
                            streamedText += data.text;
                            setMessages(prev =>
                                prev.map(m => m.id === assistantId ? { ...m, text: streamedText } : m)
                            );
                        }

                        // Final complete response — extract the text block and metrics
                        if (currentEventType === "response" && data.content) {
                            const textBlock = data.content.find(c => c.type === "text");
                            if (textBlock?.text) {
                                finalText = textBlock.text;
                            }

                            // Extract metrics from response metadata
                            const usage = data.metadata?.usage?.tokens_consumed?.[0];
                            if (usage) {
                                const latencyMs = requestStartTime.current
                                    ? Date.now() - requestStartTime.current
                                    : 0;
                                setMetrics({
                                    latency: latencyMs > 0 ? `${latencyMs}ms` : "—",
                                    cacheRead: usage.input_tokens?.cache_read ?? "—",
                                    cacheWrite: usage.input_tokens?.cache_write ?? "—",
                                    inputTokens: usage.input_tokens?.total ?? "—",
                                    outputTokens: usage.output_tokens?.total ?? "—",
                                    modelName: usage.model_name || "—",
                                });
                            }
                        }

                        // Update SSE debug logs
                        if (currentEventType === "response.status" && data.message) {
                            setSseLogs(prev => [...prev, {
                                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
                                type: "EVENT",
                                content: data.message,
                            }]);
                        }

                        if (currentEventType === "response.tool_use" && data.name) {
                            setSseLogs(prev => [...prev, {
                                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
                                type: "TOOL",
                                content: `call: ${data.name}`,
                            }]);
                        }

                    } catch (e) {
                        // Skip malformed JSON lines
                    }
                }
            }
        }

        // Once stream is done, set the final complete text and remove streaming flag
        const displayText = finalText || streamedText || "No response received.";
        setMessages(prev =>
            prev.map(m => m.id === assistantId ? { ...m, text: displayText, isStreaming: false } : m)
        );
    };

    // ── LangGraph JSON handler (unchanged) ──
    const handleLangGraphRequest = async (endpoint, payload) => {
        const res = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        if (!res.ok) throw new Error(`API Error ${res.status}`);

        const data = await res.json();

        const assistantText =
            data?.response?.messages?.[0]?.content ||
            data?.response ||
            "No response received.";

        const assistantMessage = {
            id: Date.now() + 1,
            role: "assistant",
            text: assistantText,
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        };

        setMessages(prev => [...prev, assistantMessage]);
    };

    // ─── Deep Agent handler ───
    const handleDeepAgentRequest = async (endpoint, payload, userQuestion) => {
        const res = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        if (!res.ok) throw new Error(`API Error ${res.status}`);
        const data = await res.json();

        // Check interrupted
        if (data.interrupted) {
            setMessages(prev => [...prev, {
                id: Date.now() + 1, role: "assistant",
                text: "⚠️ The agent was interrupted. Please try again.",
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            }]);
            setIsLoading(false);
            return;
        }

        // Calculate latency
        const latencyMs = requestStartTime.current ? Date.now() - requestStartTime.current : 0;

        // Build execution log for this query
        const execLog = {
            id: Date.now(),
            question: userQuestion,
            expanded: true,
            messages: (data.messages || []).map((msg, idx) => ({
                id: idx,
                type: msg.type,
                name: msg.name || null,
                content: msg.content || "",
                toolCalls: msg.tool_calls || [],
                toolCallId: msg.tool_call_id || null,
                status: msg.status || null,
            })),
            latency: `${latencyMs}ms`,
        };
        setExecutionLogs(prev => [...prev, execLog]);

        // Wait for execution panel to render, then stream the response
        const responseText = data.response || "No response received.";
        setTimeout(() => {
            // Add placeholder streaming message
            const streamMsgId = Date.now() + 1;
            setMessages(prev => [...prev, {
                id: streamMsgId, role: "assistant", text: "", isStreaming: true,
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            }]);

            // Stream character by character
            let charIdx = 0;
            const streamSpeed = 12; // ms per character
            if (streamingRef.current) clearInterval(streamingRef.current);
            streamingRef.current = setInterval(() => {
                charIdx++;
                if (charIdx >= responseText.length) {
                    clearInterval(streamingRef.current);
                    streamingRef.current = null;
                    setMessages(prev => prev.map(m =>
                        m.id === streamMsgId ? { ...m, text: responseText, isStreaming: false } : m
                    ));
                    setIsLoading(false);
                } else {
                    setMessages(prev => prev.map(m =>
                        m.id === streamMsgId ? { ...m, text: responseText.slice(0, charIdx) } : m
                    ));
                }
            }, streamSpeed);
        }, 800); // delay to let execution panel render first
    };

    const handleSubmit = async () => {
        const content = input.trim();
        if (!content) return;

        const userMessage = {
            id: Date.now(),
            role: "user",
            text: content,
            time: new Date().toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
            }),
        };

        setMessages(prev => [...prev, userMessage]);
        setInput("");
        requestStartTime.current = Date.now();
        setIsLoading(true);

        if (!apiUrl) {
            console.error("API URL missing");
            setIsLoading(false);
            return;
        }

        try {
            if (agentType === "LangGraph") {
                // LangGraph: JSON request/response
                const endpoint = `${apiUrl.replace(/\/$/, "")}/agent/chat`;
                const payload = {
                    agent_id: agentId,
                    application_id: appCode,
                    user_id: userId,
                    session_id: sesnId,
                    body: {
                        content_type: "text",
                        messages: [{ role: "user", content: content }],
                    },
                };
                await handleLangGraphRequest(endpoint, payload);
            } else if (agentType === "Deep Agent") {
                // Deep Agent: JSON request with execution flow
                const agentUuid = localStorage.getItem("agentUuid") || agentId;
                const endpoint = `${apiUrl.replace(/\/$/, "")}/chat`;
                const payload = {
                    content: content,
                    user_id: userId,
                    agent_id: agentUuid,
                    thread_id: sesnId,
                };
                await handleDeepAgentRequest(endpoint, payload, content);
            } else {
                // Cortex: SSE streaming
                const endpoint = `${apiUrl.replace(/\/$/, "")}/run_${appCode.toLowerCase()}_agent`;
                const payload = {
                    application_name: appCode,
                    agent_id: cortexSessionId,
                    messages: [
                        {
                            role: "user",
                            content: [{ type: "text", text: content }],
                        },
                    ],
                };
                await handleCortexStream(endpoint, payload);
            }
        } catch (error) {
            console.error(error);

            setMessages(prev => [
                ...prev,
                {
                    id: Date.now() + 2,
                    role: "assistant",
                    text: "Sorry, something went wrong.",
                    time: new Date().toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                    }),
                },
            ]);
        } finally {
            setIsLoading(false);
        }
    };

    // Redirect to login if not authenticated
    if (!localStorage.getItem("user_id") || !localStorage.getItem("aplctn_cd")) {
        return <Navigate to="/" replace />;
    }

    return (
        <div
            className="min-h-screen bg-gray-100 text-gray-900 flex flex-col"
            style={{ fontFamily: "'Segoe UI', sans-serif" }}
        >
            <Header />
            <div className="px-6 py-4">
                <ServiceEndpoint url={apiUrl} />
            </div>

            <div className='flex flex-col h-full flex-1'>
                <div className="flex flex-1 overflow-hidden relative">

                    {/* Chat Area */}
                    <div className="flex-1 flex flex-col min-w-0 px-4">
                        {/* Agent tag */}
                        <div className="bg-gray-100 border-b border-gray-200 px-6 py-2 flex items-center gap-2">
                            <span className="text-sm text-gray-500">Testing:</span>
                            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow shadow-blue-200" />
                            <span className="text-sm font-semibold text-gray-700">{agentName || "Agent"}</span>
                            <div style={{ flex: 1 }} />
                            <button
                                onClick={() => {
                                    setMessages([]);
                                    setSseLogs([]);
                                    setInput("");
                                    setIsLoading(false);
                                    // Generate new session ID for fresh LangGraph conversation
                                    const newSessionId = uuidv4();
                                    setSesnId(newSessionId);
                                    localStorage.setItem("session_id", newSessionId);
                                    localStorage.setItem("session_Id", newSessionId);
                                    // Reset Cortex session UUID
                                    const newCortexId = uuidv4();
                                    cortexSessionIdRef.current = newCortexId;
                                    setCortexSessionId(newCortexId);
                                    // Reset metrics
                                    setMetrics({ latency: "—", cacheRead: "—", cacheWrite: "—", inputTokens: "—", outputTokens: "—", modelName: "—" });
                                    // Reset Deep Agent execution logs
                                    setExecutionLogs([]);
                                    if (streamingRef.current) { clearInterval(streamingRef.current); streamingRef.current = null; }
                                }}
                                title="Refresh Chat"
                                style={{
                                    background: "none", border: "none", cursor: "pointer",
                                    padding: 4, borderRadius: 6, display: "flex", alignItems: "center",
                                    justifyContent: "center", transition: "background 0.2s",
                                }}
                                onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(0,121,194,0.08)"; }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = "none"; }}
                            >
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#546E7A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <polyline points="23 4 23 10 17 10" />
                                    <polyline points="1 20 1 14 7 14" />
                                    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                                </svg>
                            </button>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto px-8 py-6 space-y-5 bg-gray-100">
                            {messages.map(msg => (
                                <div
                                    key={msg.id}
                                    className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                                >
                                    {msg.role === "assistant" ? <BotIcon /> : <UserIcon />}
                                    <div className={`max-w-xl flex flex-col gap-1 ${msg.role === "user" ? "items-end" : "items-start"}`}>
                                        <div
                                            className={`rounded-2xl px-5 py-3.5 shadow-sm text-sm leading-relaxed ${msg.role === "user"
                                                ? "bg-blue-50 border border-blue-100 text-gray-700 rounded-tr-sm"
                                                : "bg-white border border-gray-200 text-gray-700 rounded-tl-sm"
                                                }`}
                                        >
                                            {msg.structured
                                                ? <StructuredResponse />
                                                : msg.isStreaming && !msg.text
                                                ? (
                                                    <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 0" }}>
                                                        <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#0072C6", animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0s" }} />
                                                        <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#0072C6", animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.2s" }} />
                                                        <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#0072C6", animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.4s" }} />
                                                    </div>
                                                )
                                                : <p className="whitespace-pre-line">{msg.text}{msg.isStreaming && <span style={{ display: "inline-block", width: 6, height: 16, backgroundColor: "#0072C6", marginLeft: 2, animation: "blink 0.8s infinite", verticalAlign: "text-bottom" }} />}</p>
                                            }
                                        </div>
                                        <span className="text-xs text-gray-400 px-1">{msg.time}</span>
                                    </div>
                                </div>
                            ))}

                            {/* Loading indicator while waiting for response */}
                            {isLoading && !messages.some(m => m.isStreaming) && (
                                <div className="flex gap-3 flex-row">
                                    <BotIcon />
                                    <div className="rounded-2xl px-5 py-3.5 shadow-sm bg-white border border-gray-200 rounded-tl-sm">
                                        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                                            <span style={{
                                                width: 8, height: 8, borderRadius: "50%", backgroundColor: "#90A4AE",
                                                animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0s",
                                            }} />
                                            <span style={{
                                                width: 8, height: 8, borderRadius: "50%", backgroundColor: "#90A4AE",
                                                animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.2s",
                                            }} />
                                            <span style={{
                                                width: 8, height: 8, borderRadius: "50%", backgroundColor: "#90A4AE",
                                                animation: "dotPulse 1.4s infinite ease-in-out", animationDelay: "0.4s",
                                            }} />
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div ref={bottomRef} />
                        </div>

                        {/* Input */}
                        <div className="px-6 py-4 flex space-x-3 items-end">
                            <div className="relative flex-1 bg-white rounded-2xl border border-gray-300 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-50 transition-all shadow-sm">
                                <textarea
                                    value={input}
                                    onChange={e => setInput(e.target.value)}
                                    onKeyDown={e => {
                                        if (e.key === "Enter" && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSubmit();
                                        }
                                    }}
                                    placeholder="Type your message to test the agent..."
                                    rows={2}
                                    className="w-full bg-transparent px-4 pt-3 pb-10 text-sm text-gray-700 placeholder-gray-400 resize-none outline-none"
                                />
                                <div className="absolute bottom-2.5 left-3 flex items-center gap-1 w-full pr-8">
                                    <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
                                        </svg>
                                    </button>
                                    <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <ellipse cx="12" cy="5" rx="9" ry="3" />
                                            <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
                                            <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
                                        </svg>
                                    </button>

                                    <div className="flex-1"></div>
                                    <span className="text-xs text-gray-300 select-none">Shift + Enter for new line</span>
                                </div>
                            </div>

                            <div className="flex items-center gap-2 pb-2">
                                <button
                                    type="button"
                                    onClick={handleSubmit}
                                    className="w-10 h-10 rounded-[50%] bg-blue-500 hover:bg-blue-600 flex items-center justify-center transition-colors shadow"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M0.0183334 15.2577L1.36977 9.40529C1.42312 9.15625 1.63651 8.96058 1.90324 8.925L9.46063 8.14231C9.67402 8.12452 9.67402 7.80433 9.46063 7.76875L1.90324 7.03942C1.63651 7.02163 1.42312 6.82596 1.36977 6.57692L0.0183334 0.74229C-0.106141 0.244212 0.427322 -0.164924 0.889657 0.066327L15.6666 7.46635C16.1111 7.6976 16.1111 8.33798 15.6666 8.56923L0.889657 15.9337C0.427322 16.1649 -0.106141 15.7558 0.0183334 15.2577Z" fill="white" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Right Panel — Execution Flow (Deep Agent) or SSE Debug (Cortex/LangGraph) */}
                    {agentType === "Deep Agent" ? (
                    <div className="w-96 border border-gray-200 bg-white flex flex-col flex-shrink-0 mx-4 mt-4 mb-3" style={{ borderRadius: 8 }}>
                        <div className="px-5 py-3.5 flex items-center justify-between" style={{ borderBottom: "1px solid #E0E0E0" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0072C6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                                </svg>
                                <span className="text-sm font-semibold" style={{ color: "#003366" }}>Execution Flow</span>
                            </div>
                            <span style={{ fontSize: 11, color: "#90A4AE" }}>{executionLogs.length} {executionLogs.length === 1 ? "query" : "queries"}</span>
                        </div>

                        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2" style={{ fontSize: 13 }}>
                            {executionLogs.length === 0 && (
                                <div style={{ textAlign: "center", padding: "40px 16px", color: "#B0BEC5" }}>
                                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#CFD8DC" strokeWidth="1.5" style={{ margin: "0 auto 12px" }}>
                                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                                    </svg>
                                    <p style={{ fontSize: 13 }}>Execution details will appear here when you ask a question.</p>
                                </div>
                            )}

                            {executionLogs.map((log) => (
                                <div key={log.id} style={{ border: "1px solid #E2E8F0", borderRadius: 8, overflow: "hidden" }}>
                                    {/* Query header — click to expand/collapse */}
                                    <div
                                        onClick={() => setExecutionLogs(prev => prev.map(l => l.id === log.id ? { ...l, expanded: !l.expanded } : l))}
                                        style={{
                                            display: "flex", alignItems: "center", justifyContent: "space-between",
                                            padding: "10px 14px", cursor: "pointer",
                                            backgroundColor: log.expanded ? "#F0F7FF" : "#FAFBFC",
                                            borderBottom: log.expanded ? "1px solid #D6EAF8" : "none",
                                        }}
                                    >
                                        <div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, minWidth: 0 }}>
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#0072C6" strokeWidth="2" style={{ flexShrink: 0, transform: log.expanded ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.2s" }}>
                                                <polyline points="9 18 15 12 9 6" />
                                            </svg>
                                            <span style={{ fontSize: 12, fontWeight: 600, color: "#003366", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                                {log.question}
                                            </span>
                                        </div>
                                        <span style={{ fontSize: 10, color: "#90A4AE", flexShrink: 0, marginLeft: 8 }}>{log.latency}</span>
                                    </div>

                                    {/* Execution steps */}
                                    {log.expanded && (
                                        <div style={{ padding: "8px 12px" }}>
                                            {log.messages.map((msg, idx) => {
                                                const typeColors = { human: "#2E8540", ai: "#0072C6", tool: "#E65100" };
                                                const typeBg = { human: "#F0FFF4", ai: "#EBF5FB", tool: "#FFF3E0" };
                                                const typeIcons = {
                                                    human: "👤",
                                                    ai: "🤖",
                                                    tool: "🔧",
                                                };

                                                return (
                                                    <div key={idx} style={{ marginBottom: idx < log.messages.length - 1 ? 8 : 0 }}>
                                                        {/* Step connector line */}
                                                        {idx > 0 && (
                                                            <div style={{ width: 1, height: 8, backgroundColor: "#D6EAF8", marginLeft: 14, marginBottom: 4 }} />
                                                        )}
                                                        <div style={{
                                                            padding: "8px 10px", borderRadius: 6,
                                                            backgroundColor: typeBg[msg.type] || "#F5F5F5",
                                                            border: `1px solid ${typeColors[msg.type] || "#E0E0E0"}20`,
                                                        }}>
                                                            {/* Type badge + name */}
                                                            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                                                                <span style={{ fontSize: 12 }}>{typeIcons[msg.type] || "📋"}</span>
                                                                <span style={{
                                                                    fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5,
                                                                    color: typeColors[msg.type] || "#546E7A",
                                                                }}>{msg.type}</span>
                                                                {msg.name && <span style={{ fontSize: 10, color: "#90A4AE" }}>· {msg.name}</span>}
                                                                {msg.status && (
                                                                    <span style={{
                                                                        fontSize: 9, fontWeight: 600, padding: "1px 6px", borderRadius: 8,
                                                                        backgroundColor: msg.status === "success" ? "#C6F6D5" : "#FED7D7",
                                                                        color: msg.status === "success" ? "#22543D" : "#9B2C2C",
                                                                    }}>{msg.status}</span>
                                                                )}
                                                            </div>
                                                            {/* Content */}
                                                            <div style={{ fontSize: 11, color: "#37474F", lineHeight: 1.5, whiteSpace: "pre-wrap", wordBreak: "break-word", maxHeight: 120, overflow: "auto" }}>
                                                                {msg.content || "—"}
                                                            </div>
                                                            {/* Tool calls */}
                                                            {msg.toolCalls && msg.toolCalls.length > 0 && (
                                                                <div style={{ marginTop: 6, padding: "6px 8px", backgroundColor: "rgba(0,0,0,0.03)", borderRadius: 4 }}>
                                                                    <span style={{ fontSize: 10, fontWeight: 600, color: "#78909C" }}>Tool Calls:</span>
                                                                    {msg.toolCalls.map((tc, ti) => (
                                                                        <div key={ti} style={{ marginTop: 4, fontSize: 11, color: "#546E7A" }}>
                                                                            <span style={{ fontWeight: 600, color: "#E65100", fontFamily: "monospace" }}>{tc.name}</span>
                                                                            {tc.args && (
                                                                                <pre style={{ fontSize: 10, color: "#78909C", margin: "2px 0 0 0", whiteSpace: "pre-wrap", fontFamily: "monospace", maxHeight: 80, overflow: "auto" }}>
                                                                                    {JSON.stringify(tc.args, null, 2)}
                                                                                </pre>
                                                                            )}
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                    ) : (
                    /* SSE Debug Panel for Cortex/LangGraph */
                    <div className="w-96 border border-gray-200 bg-white flex flex-col flex-shrink-0 mx-4 mt-4 mb-3">
                        <div className="px-5 py-3.5 flex items-center justify-between">
                            <span className="text-sm font-semibold text-gray-700">SSE Debug Terminal</span>
                            <div className="flex items-center gap-1 text-gray-400">
                                <button className="p-1 rounded hover:bg-gray-100 hover:text-gray-600 transition-colors">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                        <circle cx="12" cy="12" r="10" /><line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
                                    </svg>
                                </button>
                                <button className="p-1 rounded hover:bg-gray-100 hover:text-gray-600 transition-colors">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                        <polyline points="7 10 12 15 17 10" />
                                        <line x1="12" y1="15" x2="12" y2="3" />
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 font-mono text-xs">
                            {sseLogs.length > 0 && sseLogs.map((log, i) => (
                                <div key={i}>
                                    <div className="flex items-start gap-2 leading-relaxed">
                                        <span className="text-gray-400 flex-shrink-0 tabular-nums">{log.time}</span>
                                        <span className={`font-bold flex-shrink-0 ${typeColors[log.type]}`}>[{log.type}]</span>
                                        <span className="text-gray-600 whitespace-pre-line">{log.content}</span>
                                    </div>
                                </div>
                            ))}

                            {sseLogs.length === 0 && (
                                <div className='text-gray-400 text-sm'>Debug Terminal Coming Soon...</div>
                            )}
                        </div>

                        {agentType === "Cortex" ? (
                        <div className="p-2 grid grid-cols-3 gap-y-2 gap-x-2 bg-white">
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">LATENCY</div>
                                <div className="text-sm font-bold text-gray-800">{metrics.latency}</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">CACHE READ</div>
                                <div className="text-sm font-bold text-gray-800">{metrics.cacheRead}</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">CACHE WRITE</div>
                                <div className="text-sm font-bold text-gray-800">{metrics.cacheWrite}</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">INPUT TOKENS</div>
                                <div className="text-sm font-bold text-gray-800">{metrics.inputTokens}</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">OUTPUT TOKENS</div>
                                <div className="text-sm font-bold text-gray-800">{metrics.outputTokens}</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">MODEL</div>
                                <div className="text-sm font-bold text-gray-800">{metrics.modelName}</div>
                            </div>
                        </div>
                        ) : (
                        <div className="p-2 grid grid-cols-2 gap-y-2 gap-x-2 bg-white">
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">LATENCY</div>
                                <div className="text-base font-bold text-gray-800">240ms</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">TOKEN</div>
                                <div className="text-base font-bold text-gray-800">1.2k</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">MODEL</div>
                                <div className="text-base font-bold text-gray-800">GPT-4 Turbo</div>
                            </div>
                            <div className="bg-[#F8FAFC] p-3">
                                <div className="text-xs text-gray-400 font-semibold tracking-widest uppercase mb-0.5">MEMORY</div>
                                <div className="text-base font-bold text-green-600">Active</div>
                            </div>
                        </div>
                        )}
                    </div>
                    )}
                </div>

                <div className="text-gray-400 text-[14px] w-full text-center">&copy; 2026 Elevance Health Agent Studio. All rights reserved.</div>
            </div>
            <style>{`
                @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
                @keyframes dotPulse { 0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; } 40% { transform: scale(1); opacity: 1; } }
            `}</style>
        </div>
    );
}