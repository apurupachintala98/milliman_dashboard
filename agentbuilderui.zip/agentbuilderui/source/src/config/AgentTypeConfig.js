/**
 * AgentTypeConfig.js
 *
 * Configuration-driven agent type definitions.
 * Cortex and LangGraph use their existing hardcoded components.
 * Any new agent type added here will be rendered dynamically.
 *
 * STEP PROPERTIES:
 *   - id:          unique step key
 *   - name:        display label in stepper
 *   - enabled:     boolean (default true) — set to false to hide the entire step from the UI
 *
 * SECTION PROPERTIES:
 *   - title:       section header text
 *   - enabled:     boolean (default true) — set to false to hide this section within a step
 *   - fields:      array of field definitions
 *
 * FIELD TYPES: text, textarea, number, checkbox, toggle, dropdown, radio, json, readonly
 *
 * Each field has:
 *   - id:          unique key (also used to read/write values)
 *   - label:       display label
 *   - type:        one of the supported field types
 *   - apiKey:      dot-path into the API response to auto-populate
 *   - placeholder: placeholder text
 *   - required:    boolean
 *   - options:     for dropdown/radio — array of { value, label }
 *   - defaultValue: fallback if API has no value
 *   - disabled:    boolean — renders as read-only
 *   - rows:        for textarea — number of rows
 *   - fullWidth:   boolean — span full width instead of half
 *   - condition:   { field, value } — only show if another field matches a value
 */

// ─── Helper: resolve a dot-path on an object ───
export function resolvePath(obj, path) {
  if (!obj || !path) return undefined;
  return path.split(".").reduce((acc, key) => acc?.[key], obj);
}

// ─── Helper: set a dot-path on an object (immutable) ───
export function setPath(obj, path, value) {
  const keys = path.split(".");
  const result = { ...obj };
  let current = result;
  for (let i = 0; i < keys.length - 1; i++) {
    current[keys[i]] = { ...(current[keys[i]] || {}) };
    current = current[keys[i]];
  }
  current[keys[keys.length - 1]] = value;
  return result;
}

// ─── Supported Models List ───
const SUPPORTED_MODELS = [
  "claude-sonnet-5", "claude-sonnet-4-6", "claude-opus-4-8", "claude-opus-4-7",
  "claude-opus-4-6", "claude-sonnet-4-5", "claude-haiku-4-5", "claude-opus-4-5",
  "gemini-3.1-pro", "mistral-large2", "mistral-large3",
  "openai-gpt-5.12", "openai-gpt-5.4-mini", "openai-gpt-5.4-nano",
  "openai-gpt-5", "openai-gpt-5-mini", "openai-gpt-5-nano", "openai-gpt-4.1",
  "llama3.1-8b", "llama3.1-70b", "llama3.3-70b", "mistral-7b",
];
const SUPPORTED_MODEL_OPTIONS = SUPPORTED_MODELS.map((m) => ({ value: m, label: m }));

// ─── Deep Agent Configuration — derived from API schema ───
// Field type mapping:
//   string           → text / textarea (multiline)
//   float / integer  → number
//   boolean          → toggle
//   string + enum    → dropdown
//   array of objects → repeater (individual sub-fields with add/remove rows)
//   array of strings → chips (when selecting from another field) or json
//   object           → json
const DEEP_AGENT_CONFIG = {
  label: "Deep Agent",
  description: "LangChain DeepAgent with middleware, sub-agents, and skills",
  steps: [

    // ── Step 1: Configure Agent (Register API called before navigation) ──
    {
      id: "step1", name: "Configure Agent", enabled: true,
      sections: [
        {
          title: "Agent Details", enabled: true,
          fields: [
            { id: "agent_name",        label: "Agent Name",        type: "text",     apiKey: "2_configure_agent.fields.agent_name",        required: true,  placeholder: "e.g. ResearchAssistant" },
            { id: "agent_description", label: "Agent Description", type: "textarea", apiKey: "2_configure_agent.fields.agent_description",  required: false, rows: 3, fullWidth: true, placeholder: "Describe what this agent does" },
          ],
        },
        {
          title: "LLM Configuration", enabled: true,
          fields: [
            { id: "llm_provider",    label: "Provider",      type: "dropdown", apiKey: "2_configure_agent.fields.llm.fields.provider",    required: true,  options: [{ value: "cortex", label: "Snowflake Cortex" }, { value: "openai", label: "OpenAI" }, { value: "anthropic", label: "Anthropic" }], defaultValue: "cortex" },
            { id: "llm_model",       label: "Model",         type: "text",     apiKey: "2_configure_agent.fields.llm.fields.model",       required: true,  placeholder: "e.g. claude-4-sonnet" },
            { id: "llm_api_key",     label: "API Key",       type: "text",     apiKey: "2_configure_agent.fields.llm.fields.api_key",     required: true,  placeholder: "Your API key" },
            { id: "llm_base_url",    label: "Base URL",      type: "text",     apiKey: "2_configure_agent.fields.llm.fields.base_url",    required: true,  placeholder: "https://api.example.com" },
            { id: "llm_temperature", label: "Temperature",   type: "number",   apiKey: "2_configure_agent.fields.llm.fields.temperature", defaultValue: 0.1, placeholder: "0.0 – 1.0" },
            { id: "llm_top_p",       label: "Top P",         type: "number",   apiKey: "2_configure_agent.fields.llm.fields.top_p",       defaultValue: 0.9, placeholder: "0.0 – 1.0" },
            { id: "llm_max_tokens",  label: "Max Tokens",    type: "number",   apiKey: "2_configure_agent.fields.llm.fields.max_tokens",  defaultValue: 4000, placeholder: "e.g. 4000" },
            { id: "llm_cert_path",   label: "Cert Path",     type: "text",     apiKey: "2_configure_agent.fields.llm.fields.cert_path",   defaultValue: "certs/cacert.pem", placeholder: "certs/cacert.pem" },
          ],
        },
        {
          title: "System Prompt", enabled: true,
          fields: [
            { id: "sp_system",         label: "System Message",   type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.system",         rows: 4, fullWidth: true, defaultValue: "You are a helpful AI assistant.", placeholder: "Base system message..." },
            { id: "sp_instructions",   label: "Instructions",     type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.instructions",   rows: 3, fullWidth: true, placeholder: "Specific instructions for the agent..." },
            { id: "sp_context",        label: "Context",          type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.context",        rows: 3, fullWidth: true, placeholder: "Additional context..." },
            { id: "sp_constraints",    label: "Constraints",      type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.constraints",    rows: 3, fullWidth: true, placeholder: "Boundaries and limitations..." },
            { id: "sp_output_format",  label: "Output Format",    type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.output_format",  rows: 3, fullWidth: true, placeholder: "Expected response structure..." },
            { id: "sp_tone",           label: "Tone",             type: "text",     apiKey: "2_configure_agent.fields.system_prompt.fields.tone",           placeholder: "e.g. Professional, analytical" },
            { id: "sp_error_handling", label: "Error Handling",   type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.error_handling", rows: 2, fullWidth: true, placeholder: "How the agent should handle errors..." },
            { id: "sp_tools_guidance", label: "Tools Guidance",   type: "textarea", apiKey: "2_configure_agent.fields.system_prompt.fields.tools_guidance", rows: 2, fullWidth: true, placeholder: "Instructions for how to use tools..." },
          ],
        },
        {
          title: "Examples", enabled: true,
          fields: [
            { id: "sp_examples", label: "Examples", type: "repeater", fullWidth: true, addLabel: "Add Example",
              apiKey: "2_configure_agent.fields.system_prompt.fields.examples",
              subFields: [
                { id: "user",      label: "User",      type: "text", required: true, placeholder: "User message...", flex: 1 },
                { id: "assistant", label: "Assistant",  type: "text", required: true, placeholder: "Assistant response...", flex: 1 },
              ],
            },
          ],
        },
      ],
    },

    // ── Step 3: Configure Tools ──
    {
      id: "step2", name: "Configure Tools", enabled: true,
      sections: [
        {
          title: "Tool Settings", enabled: true,
          fields: [
            { id: "tools_enabled", label: "Enable Tools", type: "toggle", apiKey: "3_configure_tools.fields.enabled", defaultValue: false },
          ],
        },
        {
          title: "MCP Servers", enabled: true,
          fields: [
            { id: "mcp_tools_selected", label: "Available Tools", type: "tools_grid", fullWidth: true, defaultValue: [],
              condition: { field: "tools_enabled", value: true } },
          ],
        },
        {
          title: "Main Agent", enabled: true,
          fields: [
            { id: "tools_main_agent_enabled", label: "Enable Main Agent", type: "toggle", apiKey: "3_configure_tools.fields.main_agent_enabled", defaultValue: true, condition: { field: "tools_enabled", value: true } },
            { id: "tools_main_agent_tools",   label: "Main Agent Tools",  type: "chips",  apiKey: "3_configure_tools.fields.main_agent_tools",
              sourceField: "mcp_tools_selected",
              condition: { field: "tools_main_agent_enabled", value: true } },
            { id: "tools_timeout", label: "Timeout (seconds)", type: "number", apiKey: "3_configure_tools.fields.timeout", defaultValue: 30, placeholder: "30",
              condition: { field: "tools_main_agent_enabled", value: true } },
          ],
        },
        {
          title: "Permissions", enabled: true,
          fields: [
            { id: "tools_permissions", label: "Permissions", type: "repeater", fullWidth: true, addLabel: "Add Permission Rule",
              apiKey: "3_configure_tools.fields.permissions",
              condition: { field: "tools_enabled", value: true },
              subFields: [
                { id: "operations", label: "Operations", type: "checkboxgroup", required: true, flex: 1, minWidth: 160,
                  defaultValue: [],
                  options: [{ value: "read", label: "Read" }, { value: "write", label: "Write" }] },
                { id: "paths",      label: "Paths",      type: "text", required: true, placeholder: "/workspace/**, /tmp/", flex: 2 },
                { id: "mode",       label: "Mode",       type: "checkboxgroup", required: true, flex: 1, minWidth: 160,
                  defaultValue: [],
                  options: [{ value: "allow", label: "Allow" }, { value: "deny", label: "Deny" }] },
              ],
            },
          ],
        },
        {
          title: "Human-in-the-Loop (HITL)", enabled: true,
          fields: [
            { id: "hitl_config", label: "Human-in-the-Loop", type: "hitl", fullWidth: true,
              defaultValue: { enabled: false, tools: {} },
              sourceField: "mcp_tools_selected",
              condition: { field: "tools_enabled", value: true } },
          ],
        },
      ],
    },

    // ── Step 3: Configure Memory ──
    {
      id: "step3", name: "Configure Memory", enabled: true,
      sections: [
        {
          title: "Memory Settings", enabled: true,
          fields: [
            { id: "memory_enabled", label: "Enable Memory", type: "toggle", apiKey: "4_configure_memory.fields.enabled", defaultValue: false },
          ],
        },
        {
          title: "Database Configuration", enabled: true,
          fields: [
            { id: "db_host",         label: "Host",              type: "text",     apiKey: "4_configure_memory.fields.database.fields.host",          required: true,  placeholder: "localhost",   condition: { field: "memory_enabled", value: true } },
            { id: "db_port",         label: "Port",              type: "number",   apiKey: "4_configure_memory.fields.database.fields.port",          defaultValue: 5432,                          condition: { field: "memory_enabled", value: true } },
            { id: "db_user",         label: "User",              type: "text",     apiKey: "4_configure_memory.fields.database.fields.user",          required: true,  placeholder: "postgres",    condition: { field: "memory_enabled", value: true } },
            { id: "db_password",     label: "Password",          type: "text",     apiKey: "4_configure_memory.fields.database.fields.password",      required: true,  placeholder: "••••••••",    condition: { field: "memory_enabled", value: true } },
            { id: "db_name",         label: "Database Name",     type: "text",     apiKey: "4_configure_memory.fields.database.fields.database",      required: true,  placeholder: "my_database", condition: { field: "memory_enabled", value: true } },
          ],
        },
        {
          title: "Seed Categories", enabled: true,
          fields: [
            { id: "seed_categories", label: "Seed Categories", type: "repeater", fullWidth: true, addLabel: "Add Category",
              layout: "vertical",
              condition: { field: "memory_enabled", value: true },
              subFields: [
                { id: "name",       label: "Category Name", type: "text", required: true, placeholder: "e.g. knowledge_base", flex: 1 },
                { id: "seed_files", label: "Seed Files",    type: "sub_repeater", flex: 3, minWidth: 300, addLabel: "Add File",
                  subFields: [
                    { id: "path",    label: "Path",    placeholder: "e.g. docs/knowledge_base.md", flex: 1 },
                    { id: "content", label: "Content", placeholder: "File content...", flex: 2 },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },

    // ── Step 4: Configure Middleware ──
    {
      id: "step4", name: "Configure Middleware", enabled: true,
      sections: [
        { title: "Middleware Toggle", enabled: true, fields: [
          { id: "mw_enabled", label: "Enable Middleware", type: "toggle", defaultValue: false },
        ]},
        { title: "Summarization", enabled: true, fields: [
          { id: "mw_summ_enabled",       label: "Enable Summarization", type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_summ_model",         label: "Model",            type: "dropdown", defaultValue: "claude-4-sonnet", options: SUPPORTED_MODEL_OPTIONS, condition: { field: "mw_summ_enabled", value: true } },
          { id: "mw_summ_trigger_type",  label: "Trigger Type",     type: "dropdown", defaultValue: "tokens",  options: [{ value: "tokens", label: "Tokens" }, { value: "messages", label: "Messages" }], condition: { field: "mw_summ_enabled", value: true } },
          { id: "mw_summ_trigger_value", label: "Trigger Value",    type: "number",   defaultValue: 4000, placeholder: "4000", condition: { field: "mw_summ_enabled", value: true } },
          { id: "mw_summ_keep_type",     label: "Keep Type",        type: "dropdown", defaultValue: "messages", options: [{ value: "tokens", label: "Tokens" }, { value: "messages", label: "Messages" }], condition: { field: "mw_summ_enabled", value: true } },
          { id: "mw_summ_keep_value",    label: "Keep Value",       type: "number",   defaultValue: 20, placeholder: "20", condition: { field: "mw_summ_enabled", value: true } },
        ]},
        { title: "Call Limits", enabled: true, fields: [
          { id: "mw_call_limits_enabled", label: "Enable Call Limits", type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_model_call_thread", label: "Model Thread Limit",  type: "number",   defaultValue: 100, condition: { field: "mw_call_limits_enabled", value: true } },
          { id: "mw_model_call_run",    label: "Model Run Limit",     type: "number",   defaultValue: 50,  condition: { field: "mw_call_limits_enabled", value: true } },
          { id: "mw_model_call_exit",   label: "Model Exit Behavior", type: "dropdown", defaultValue: "end", options: [{ value: "end", label: "End" }, { value: "error", label: "Error" }], condition: { field: "mw_call_limits_enabled", value: true } },
          { id: "mw_tool_call_thread",  label: "Tool Thread Limit",   type: "number",   defaultValue: 50,  condition: { field: "mw_call_limits_enabled", value: true } },
          { id: "mw_tool_call_run",     label: "Tool Run Limit",      type: "number",   defaultValue: 25,  condition: { field: "mw_call_limits_enabled", value: true } },
          { id: "mw_tool_call_name",    label: "Limit Specific Tool", type: "text",     placeholder: "blank = all tools", condition: { field: "mw_call_limits_enabled", value: true } },
          { id: "mw_tool_call_exit",    label: "Tool Exit Behavior",  type: "dropdown", defaultValue: "continue", options: [{ value: "continue", label: "Continue" }, { value: "end", label: "End" }, { value: "error", label: "Error" }], condition: { field: "mw_call_limits_enabled", value: true } },
        ]},
        { title: "Model Fallback", enabled: true, fields: [
          { id: "mw_fallback_enabled", label: "Enable Model Fallback", type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_fallback_models", label: "Fallback Models", type: "chips", fullWidth: true, defaultValue: [],
            options: SUPPORTED_MODEL_OPTIONS,
            condition: { field: "mw_fallback_enabled", value: true } },
        ]},
        { title: "PII Detection", enabled: true, fields: [
          { id: "mw_pii_enabled",       label: "Enable PII Detection", type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_pii_detectors",    label: "Detectors",        type: "chips", fullWidth: true, defaultValue: ["email"],
            options: [{ value: "email", label: "Email" }, { value: "credit_card", label: "Credit Card" }, { value: "ip", label: "IP" }, { value: "mac_address", label: "MAC Address" }, { value: "url", label: "URL" }],
            condition: { field: "mw_pii_enabled", value: true } },
          { id: "mw_pii_strategy",     label: "Strategy",         type: "chips", fullWidth: true, defaultValue: ["redact"],
            options: [{ value: "redact", label: "Redact" }, { value: "mask", label: "Mask" }, { value: "hash", label: "Hash" }, { value: "block", label: "Block" }],
            condition: { field: "mw_pii_enabled", value: true } },
          { id: "mw_pii_input",        label: "Apply to Input",   type: "toggle", defaultValue: true,  condition: { field: "mw_pii_enabled", value: true } },
          { id: "mw_pii_output",       label: "Apply to Output",  type: "toggle", defaultValue: false, condition: { field: "mw_pii_enabled", value: true } },
          { id: "mw_pii_tool_results", label: "Apply to Tools",   type: "toggle", defaultValue: false, condition: { field: "mw_pii_enabled", value: true } },
        ]},
        { title: "Retry Settings", enabled: true, fields: [
          { id: "mw_retry_enabled",      label: "Enable Retry",         type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_tool_retry_max",     label: "Tool Max Retries",   type: "number", defaultValue: 3,    condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_tool_retry_backoff", label: "Tool Backoff",       type: "number", defaultValue: 2.0,  condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_tool_retry_delay",   label: "Tool Initial Delay", type: "number", defaultValue: 1.0,  condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_tool_retry_max_d",   label: "Tool Max Delay",     type: "number", defaultValue: 60.0, condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_tool_retry_jitter",  label: "Tool Jitter",        type: "toggle", defaultValue: true, condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_tool_retry_fail",    label: "Tool On Failure",    type: "dropdown", defaultValue: "continue", options: [{ value: "continue", label: "Continue" }, { value: "error", label: "Error" }], condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_model_retry_max",    label: "Model Max Retries",  type: "number", defaultValue: 3,    condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_model_retry_jitter", label: "Model Jitter",       type: "toggle", defaultValue: true, condition: { field: "mw_retry_enabled", value: true } },
          { id: "mw_model_retry_fail",   label: "Model On Failure",   type: "dropdown", defaultValue: "continue", options: [{ value: "continue", label: "Continue" }, { value: "error", label: "Error" }], condition: { field: "mw_retry_enabled", value: true } },
        ]},
        { title: "LLM Tool Selector", enabled: true, fields: [
          { id: "mw_selector_enabled", label: "Enable LLM Tool Selector", type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_selector_model",  label: "Selector Model",   type: "dropdown", defaultValue: "claude-sonnet-4-6", options: SUPPORTED_MODEL_OPTIONS, condition: { field: "mw_selector_enabled", value: true } },
          { id: "mw_selector_max",    label: "Max Tools",        type: "number",   defaultValue: 5, condition: { field: "mw_selector_enabled", value: true } },
          { id: "mw_selector_always", label: "Always Include",   type: "checkboxgroup", fullWidth: true, defaultValue: ["read_file", "write_file"],
            options: [{ value: "read_file", label: "Read File" }, { value: "write_file", label: "Write File" }],
            condition: { field: "mw_selector_enabled", value: true } },
          { id: "mw_selector_prompt", label: "Selector Prompt",  type: "textarea", rows: 3, fullWidth: true, condition: { field: "mw_selector_enabled", value: true } },
        ]},
        { title: "File Search", enabled: true, fields: [
          { id: "mw_fs_enabled",  label: "Enable File Search",    type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
          { id: "mw_fs_root",     label: "Root Path",          type: "text",   defaultValue: ".", condition: { field: "mw_fs_enabled", value: true } },
          { id: "mw_fs_ripgrep",  label: "Use Ripgrep",        type: "toggle", defaultValue: true, condition: { field: "mw_fs_enabled", value: true } },
          { id: "mw_fs_max_size", label: "Max File Size (MB)",  type: "number", defaultValue: 10, condition: { field: "mw_fs_enabled", value: true } },
        ]},
        { title: "Snowflake Sanitizer", enabled: true, fields: [
          { id: "mw_snowflake_enabled", label: "Enable Snowflake Sanitizer", type: "toggle", defaultValue: false, condition: { field: "mw_enabled", value: true } },
        ]},
      ],
    },

    // ── Step 5: Configure Backend ──
    {
      id: "step5", name: "Configure Backend", enabled: true,
      sections: [{
        title: "Backend Configuration", enabled: true,
        fields: [
          { id: "backend_type",    label: "Type",    type: "readonly", defaultValue: "composite" },
          { id: "backend_default", label: "Default", type: "dropdown", defaultValue: "state", options: [{ value: "state", label: "State" }, { value: "store", label: "Store" }] },
        ],
      },
      {
        title: "Routes", enabled: true,
        fields: [
          { id: "backend_routes", label: "Routes", type: "repeater", fullWidth: true, addLabel: "Add Route",
            defaultValue: [{ path: "/memories/", backend: "store" }, { path: "/skills/", backend: "store" }],
            subFields: [
              { id: "path",    label: "Path",    type: "text",     required: true, placeholder: "/memories/", flex: 2 },
              { id: "backend", label: "Backend", type: "dropdown", required: true, flex: 1,
                options: [{ value: "store", label: "Store" }], defaultValue: "store" },
            ],
          },
        ],
      }],
    },

    // ── Step 6: Configure Skills ──
    {
      id: "step6", name: "Configure Skills", enabled: true,
      sections: [{
        title: "Skills Configuration", enabled: true,
        fields: [
          { id: "skills_enabled", label: "Enable Skills", type: "toggle", defaultValue: false },
          { id: "skill_files", label: "Skill Files", type: "repeater", fullWidth: true, addLabel: "Add Skill File",
            condition: { field: "skills_enabled", value: true },
            subFields: [
              { id: "path",    label: "Path",    type: "text", required: true, placeholder: "e.g. /skills/web_research/skill.py", flex: 1 },
              { id: "content", label: "Content", type: "textarea", placeholder: "Skill file content...", rows: 3, flex: 2, minWidth: 300 },
            ],
          },
        ],
      }],
    },

    // ── Step 7: Configure Sub-Agents ──
    {
      id: "step7", name: "Sub-Agents", enabled: true,
      sections: [{
        title: "Sub-Agent Configuration", enabled: true,
        fields: [
          { id: "subagents_enabled", label: "Enable Sub-Agents", type: "toggle", defaultValue: false },
          { id: "subagents_list", label: "Sub-Agents", type: "repeater", fullWidth: true, addLabel: "Add Sub-Agent",
            layout: "vertical",
            condition: { field: "subagents_enabled", value: true },
            subFields: [
              { id: "name",          label: "Name",          type: "text",     required: true, placeholder: "e.g. researcher", flex: 1 },
              { id: "description",   label: "Description",   type: "text",     required: true, placeholder: "What this subagent does", flex: 1 },
              { id: "system_prompt", label: "System Prompt",  type: "textarea", required: true, placeholder: "Instructions for the subagent...", rows: 2, flex: 2, minWidth: 280 },
              { id: "model",         label: "Model",          type: "dropdown", flex: 1, options: SUPPORTED_MODEL_OPTIONS, placeholder: "Select model" },
              { id: "tools",         label: "Tools",          type: "checkboxgroup", flex: 2, minWidth: 200, defaultValue: [],
                _sourceField: "mcp_tools_selected" },
              { id: "skills",        label: "Skills",         type: "checkboxgroup", flex: 2, minWidth: 200, defaultValue: [],
                _sourceField: "skill_files", _sourceKey: "path" },
            ],
          },
        ],
      }],
    },

    // ── Step 8: Configure API Settings ──
    {
      id: "step8", name: "API Settings", enabled: true,
      sections: [
        { title: "API Info", enabled: true, fields: [
          { id: "api_title",   label: "API Title",   type: "readonly" },
          { id: "api_version", label: "API Version", type: "text", defaultValue: "1.0.0" },
        ]},
        { title: "Server", enabled: true, fields: [
          { id: "api_host",      label: "Host",        type: "readonly",  defaultValue: "127.0.0.1" },
          { id: "api_port",      label: "Port",        type: "readonly",  defaultValue: "8000" },
          { id: "api_reload",    label: "Auto Reload", type: "readonly",  defaultValue: "false" },
          { id: "api_log_level", label: "Log Level",   type: "readonly",  defaultValue: "info" },
        ]},
        { title: "Defaults", enabled: true, fields: [
          { id: "api_user_id",         label: "Default User ID",  type: "readonly" },
          { id: "api_history_limit",   label: "History Limit",    type: "number", defaultValue: 100 },
          { id: "api_files_limit",     label: "Files Limit",      type: "number", defaultValue: 100 },
          { id: "api_recursion_limit", label: "Recursion Limit",  type: "number", defaultValue: 1000 },
        ]},
      ],
    },

  ],
};
// ─── Registry of all dynamic agent type configs ───
// Add new agent types here. Cortex and LangGraph are NOT listed
// because they use their own hardcoded components.
const DYNAMIC_AGENT_CONFIGS = {
  "Deep Agent": DEEP_AGENT_CONFIG,
};

/**
 * Get the config for a dynamic agent type.
 * Returns null if the type uses hardcoded components (Cortex/LangGraph).
 */
export function getDynamicAgentConfig(agentType) {
  return DYNAMIC_AGENT_CONFIGS[agentType] || null;
}

/**
 * Get only the enabled steps from a config.
 * Checks both config defaults AND localStorage overrides from Preferences.
 * Steps/sections with enabled === false are hidden from the UI.
 */
export function getEnabledSteps(config) {
  if (!config?.steps) return [];

  // Read overrides from Preferences (localStorage)
  let overrides = null;
  try {
    const raw = localStorage.getItem("agent_studio_preferences");
    if (raw) {
      const prefs = JSON.parse(raw);
      overrides = prefs[config.label]; // e.g. prefs["Deep Agent"]
    }
  } catch { /* ignore parse errors */ }

  return config.steps
    .filter((step) => {
      // Check localStorage override first, then config default
      if (overrides?.steps) {
        const override = overrides.steps.find((s) => s.id === step.id);
        if (override && override.enabled === false) return false;
      }
      return step.enabled !== false;
    })
    .map((step) => {
      const stepOverride = overrides?.steps?.find((s) => s.id === step.id);
      return {
        ...step,
        sections: (step.sections || []).filter((section) => {
          // Check localStorage override for section
          if (stepOverride?.sections) {
            const secOverride = stepOverride.sections.find((ss) => ss.title === section.title);
            if (secOverride && secOverride.enabled === false) return false;
          }
          return section.enabled !== false;
        }),
      };
    })
    .filter((step) => step.sections.length > 0);
}

/**
 * Get all registered dynamic agent type names.
 */
export function getDynamicAgentTypes() {
  return Object.keys(DYNAMIC_AGENT_CONFIGS);
}

/**
 * Check if an agent type should use the dynamic builder.
 */
export function isDynamicAgentType(agentType) {
  return agentType in DYNAMIC_AGENT_CONFIGS;
}

/**
 * Populate field default values from an API response record.
 * Returns a flat { fieldId: value } map.
 */
export function populateFromApiResponse(config, apiRecord) {
  const values = {};
  if (!config || !apiRecord) return values;

  for (const step of config.steps) {
    for (const section of step.sections) {
      for (const field of section.fields) {
        if (field.apiKey) {
          const apiValue = resolvePath(apiRecord, field.apiKey);
          if (apiValue !== undefined && apiValue !== null) {
            values[field.id] = apiValue;
          } else if (field.defaultValue !== undefined) {
            values[field.id] = field.defaultValue;
          }
        } else if (field.defaultValue !== undefined) {
          values[field.id] = field.defaultValue;
        }
      }
    }
  }

  return values;
}

export default DYNAMIC_AGENT_CONFIGS;