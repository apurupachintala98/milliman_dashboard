import { useState, useEffect, useRef } from "react";
import { useParams, Navigate, useNavigate } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import {
  PageLayout,
  BackToDashboard,
  FooterButtons,
} from "../components/SharedComponents";
import DynamicStepRenderer from "../components/DynamicStepRenderer";
import CustomFieldsSection from "../components/CustomFieldsRenderer";
import Deployment from "../components/Deployment";
import {
  getDynamicAgentConfig,
  getEnabledSteps,
} from "../config/AgentTypeConfig";

// ─── Stepper that adapts to any number of steps ───
function CheckCircle() {
  return (
    <div className="flex items-center justify-center rounded-full" style={{ width: 32, height: 32, backgroundColor: "#0072C6", flexShrink: 0 }}>
      <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
        <path d="M5 10L9 14L15 6" stroke="#FFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

function DynamicStepper({ activeStep, steps }) {
  const count = steps.length;
  // Adapt line width to fit within container — max 120, min 40
  const lineWidth = count <= 5 ? 120 : count <= 7 ? 80 : count <= 10 ? 56 : 40;
  const labelWidth = count <= 5 ? 120 : count <= 7 ? 90 : 76;

  const getCircle = (num) => {
    if (num < activeStep) return <CheckCircle />;
    if (num === activeStep) {
      return (
        <div className="flex items-center justify-center rounded-full font-semibold" style={{ width: 32, height: 32, backgroundColor: "#0072C6", color: "#FFF", fontSize: 14, flexShrink: 0 }}>
          {num}
        </div>
      );
    }
    return (
      <div className="flex items-center justify-center rounded-full font-semibold" style={{ width: 32, height: 32, backgroundColor: "transparent", border: "2px solid #B0BEC5", color: "#78909C", fontSize: 14, flexShrink: 0 }}>
        {num}
      </div>
    );
  };

  return (
    <div className="flex justify-center pt-6 pb-4">
      <div style={{ paddingBottom: 40 }}>
        <div className="flex items-center">
          {steps.map((label, i) => {
            const num = i + 1;
            return (
              <div key={num} className="flex items-center" style={{ position: "relative" }}>
                {getCircle(num)}
                {/* Label centered under circle */}
                <div style={{ position: "absolute", top: 40, left: 16, transform: "translateX(-50%)", width: labelWidth, textAlign: "center" }}>
                  <span style={{
                    fontSize: count <= 5 ? 13 : 11,
                    color: num <= activeStep ? "#0072C6" : "#78909C",
                    fontWeight: num <= activeStep ? 600 : 400,
                    lineHeight: 1.3,
                    display: "inline-block",
                  }}>
                    {label}
                  </span>
                </div>
                {/* Connector line */}
                {i < steps.length - 1 && (
                  <div style={{ width: lineWidth, height: 2, backgroundColor: num < activeStep ? "#0072C6" : "#B0BEC5" }} />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ───
export default function DynamicAgentBuilder() {
  if (!localStorage.getItem("user_id") || !localStorage.getItem("aplctn_cd")) {
    return <Navigate to="/" replace />;
  }

  const { agentId, agentType: routeAgentType } = useParams();
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(1);
  const [values, setValues] = useState({});
  const [isCreating, setIsCreating] = useState(false);
  const [isLoadingDefaults, setIsLoadingDefaults] = useState(true);
  const [createStatus, setCreateStatus] = useState("idle");
  const [saveStatus, setSaveStatus] = useState("idle");
  const [saveError, setSaveError] = useState("");
  const [showDeployment, setShowDeployment] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [agentUuid, setAgentUuid] = useState(
    agentId || localStorage.getItem("agentUuid") || ""
  );

  // Load MCP tools from scopes — only when tools step is active
  const [mcpToolsFromScopes, setMcpToolsFromScopes] = useState([]);
  const [toolsLoading, setToolsLoading] = useState(false);
  const toolsFetchedRef = useRef(false);

  // Common payload fields — same pattern as Cortex/LangGraph
  const sessionId = useState(() => {
    const existing = localStorage.getItem("session_Id") || localStorage.getItem("session_id");
    return existing || (() => { const id = uuidv4(); localStorage.setItem("session_Id", id); return id; })();
  })[0];
  const userId = localStorage.getItem("user_id") || "";
  const appCode = localStorage.getItem("aplctn_cd") || "";

  const agentType = decodeURIComponent(routeAgentType || "") || localStorage.getItem("agentType") || "";
  const config = getDynamicAgentConfig(agentType);

  const enabledSteps = config ? getEnabledSteps(config) : [];
  const stepLabels = enabledSteps.map((s) => s.name);

  // ─── Map API default_inputs response to flat form values ───
  // This is the SINGLE SOURCE OF TRUTH for all default values
  const mapDefaultsToValues = (data) => {
    const v = {};
    if (!data) return v;

    // Configure Agent — API returns agent_config with llm_config and system_prompt
    const ca = data.configure_agent || data.agent_config || {};
    v.agent_name = (ca.agent_name ?? "").replace(/\s+/g, "");
    v.agent_description = ca.agent_description ?? "";
    const llm = ca.llm || ca.llm_config || {};
    v.llm_provider = llm.provider ?? "";
    v.llm_model = llm.model ?? "";
    v.llm_api_key = llm.api_key ?? "";
    v.llm_base_url = llm.base_url ?? "";
    v.llm_temperature = llm.temperature ?? "";
    v.llm_top_p = llm.top_p ?? "";
    v.llm_max_tokens = llm.max_tokens ?? "";
    v.llm_cert_path = llm.cert_path ?? "";
    const sp = ca.system_prompt || {};
    v.sp_system = sp.system ?? "";
    v.sp_instructions = sp.instructions ?? "";
    v.sp_context = sp.context ?? "";
    v.sp_constraints = sp.constraints ?? "";
    v.sp_output_format = sp.output_format ?? "";
    v.sp_tone = sp.tone ?? "";
    v.sp_error_handling = sp.error_handling ?? "";
    v.sp_tools_guidance = sp.tools_guidance ?? "";
    v.sp_examples = Array.isArray(sp.examples) ? sp.examples : [];

    // Configure Tools — API may return tools_config
    const ct = data.configure_tools || data.tools_config || {};
    v.tools_enabled = !!ct.enabled;
    v.tools_main_agent_enabled = ct.main_agent_enabled !== undefined ? !!ct.main_agent_enabled : true;
    v.tools_main_agent_tools = Array.isArray(ct.main_agent_tools) ? ct.main_agent_tools : [];
    v.mcp_servers = Array.isArray(ct.mcp_tools) ? ct.mcp_tools : [];
    v.tools_timeout = ct.timeout ?? 30;
    v.tools_permissions = Array.isArray(ct.permissions) ? ct.permissions : [];
    v.hitl_config = { enabled: false, tools: ct.interrupt_on || {} };

    // Configure Memory — API may return memory_config
    const cm = data.configure_memory || data.memory_config || {};
    v.memory_enabled = !!cm.enabled;
    const db = cm.database || {};
    v.db_host = db.host ?? "";
    v.db_port = db.port ?? 5432;
    v.db_user = db.user ?? "";
    v.db_password = db.password ?? "";
    v.db_name = db.database ?? "";
    v.seed_categories = Array.isArray(cm.seed_categories) ? cm.seed_categories : [];

    // Configure Middleware — API may return middleware_config
    const mw = data.configure_middleware || data.middleware_config || {};
    v.mw_enabled = !!mw.enabled;
    const summ = mw.summarization || {};
    v.mw_summ_enabled = !!(summ.enabled || summ.model || (Array.isArray(summ.trigger) && summ.trigger.length));
    v.mw_summ_model = summ.model ?? "";
    if (Array.isArray(summ.trigger) && summ.trigger.length >= 2) { v.mw_summ_trigger_type = summ.trigger[0]; v.mw_summ_trigger_value = summ.trigger[1]; }
    else { v.mw_summ_trigger_type = "tokens"; v.mw_summ_trigger_value = 4000; }
    if (Array.isArray(summ.keep) && summ.keep.length >= 2) { v.mw_summ_keep_type = summ.keep[0]; v.mw_summ_keep_value = summ.keep[1]; }
    else { v.mw_summ_keep_type = "messages"; v.mw_summ_keep_value = 20; }
    const mcl = mw.model_call_limit || {};
    const tcl = mw.tool_call_limit || {};
    v.mw_call_limits_enabled = !!(mcl.thread_limit || tcl.thread_limit);
    v.mw_model_call_thread = mcl.thread_limit ?? 100;
    v.mw_model_call_run = mcl.run_limit ?? 50;
    v.mw_model_call_exit = mcl.exit_behavior ?? "end";
    v.mw_tool_call_thread = tcl.thread_limit ?? 50;
    v.mw_tool_call_run = tcl.run_limit ?? 25;
    v.mw_tool_call_name = tcl.tool_name ?? "";
    v.mw_tool_call_exit = tcl.exit_behavior ?? "continue";
    const mf = mw.model_fallback || {};
    v.mw_fallback_enabled = Array.isArray(mf.fallback_models) && mf.fallback_models.length > 0;
    v.mw_fallback_models = Array.isArray(mf.fallback_models) ? mf.fallback_models : [];
    const pii = mw.pii_detection || {};
    v.mw_pii_enabled = !!(pii.enabled || (Array.isArray(pii.detectors) && pii.detectors.length > 0));
    v.mw_pii_detectors = Array.isArray(pii.detectors) ? pii.detectors : [];
    v.mw_pii_strategy = pii.strategy ? [pii.strategy] : [];
    v.mw_pii_input = !!pii.apply_to_input;
    v.mw_pii_output = !!pii.apply_to_output;
    v.mw_pii_tool_results = !!pii.apply_to_tool_results;
    const tr = mw.tool_retry || {};
    const mr = mw.model_retry || {};
    v.mw_retry_enabled = !!(tr.max_retries || mr.max_retries);
    v.mw_tool_retry_max = tr.max_retries ?? 3;
    v.mw_tool_retry_backoff = tr.backoff_factor ?? 2.0;
    v.mw_tool_retry_delay = tr.initial_delay ?? 1.0;
    v.mw_tool_retry_max_d = tr.max_delay ?? 60.0;
    v.mw_tool_retry_jitter = tr.jitter !== false;
    v.mw_tool_retry_fail = tr.on_failure ?? "continue";
    v.mw_model_retry_max = mr.max_retries ?? 3;
    v.mw_model_retry_jitter = mr.jitter !== false;
    v.mw_model_retry_fail = mr.on_failure ?? "continue";
    const sel = mw.llm_tool_selector || {};
    v.mw_selector_enabled = !!(sel.enabled || sel.model);
    v.mw_selector_model = sel.model ?? "";
    v.mw_selector_max = sel.max_tools ?? 5;
    v.mw_selector_always = Array.isArray(sel.always_include) ? sel.always_include : [];
    v.mw_selector_prompt = sel.system_prompt ?? "";
    const fs = mw.file_search || {};
    v.mw_fs_enabled = !!(fs.enabled || fs.root_path || fs.use_ripgrep);
    v.mw_fs_root = fs.root_path ?? ".";
    v.mw_fs_ripgrep = fs.use_ripgrep !== false;
    v.mw_fs_max_size = fs.max_file_size_mb ?? 10;
    const sf = mw.snowflake_sanitizer || {};
    v.mw_snowflake_enabled = !!(sf.enabled || Object.keys(sf).length > 0);

    // Configure Backend — API may return backend_config
    const cb = data.configure_backend || data.backend_config || {};
    v.backend_type = cb.type ?? "composite";
    v.backend_default = cb.default ?? "state";
    if (cb.routes && typeof cb.routes === "object") {
      v.backend_routes = Object.entries(cb.routes).map(([path, backend]) => ({ path, backend }));
    } else {
      v.backend_routes = [];
    }

    // Configure Skills — API may return skills_config
    const cs = data.configure_skills || data.skills_config || {};
    v.skills_enabled = !!cs.enabled;
    v.skill_files = Array.isArray(cs.skill_files) ? cs.skill_files : [];

    // Configure Sub-Agents — API may return subagents_config
    const csa = data.configure_subagents || data.subagents_config || {};
    v.subagents_enabled = !!csa.enabled;
    v.subagents_list = Array.isArray(csa.agents) ? csa.agents : [];

    // Configure API Settings — API may return api_config
    const api = data.configure_api_settings || data.api_config || {};
    v.api_title = api.title ?? "";
    v.api_version = api.version ?? "";
    const srv = api.server || {};
    v.api_host = srv.host ?? "";
    v.api_port = srv.port ?? "";
    v.api_reload = !!srv.reload;
    v.api_log_level = srv.log_level ?? "";
    const def = api.defaults || {};
    v.api_user_id = def.user_id ?? "";
    v.api_history_limit = def.history_limit ?? "";
    v.api_files_limit = def.files_limit ?? "";
    v.api_recursion_limit = def.recursion_limit ?? "";

    return v;
  };

  // ─── Load default inputs from API on mount — single source of truth ───
  useEffect(() => {
    if (!config) return;

    (async () => {
      setIsLoadingDefaults(true);
      try {
        const { ldaApi } = await import("../services/lda-api");
        const defaultData = await ldaApi.getDefaultInputs();
        console.log("[Default Inputs] Raw API response:", JSON.stringify(defaultData, null, 2));
        const apiValues = mapDefaultsToValues(defaultData);
        console.log("[Default Inputs] Mapped values:", apiValues);
        console.log("[Default Inputs] Total fields:", Object.keys(apiValues).length);

        // Override with user-specific values
        const storedName = (localStorage.getItem("agentName") || "").replace(/\s+/g, "");
        if (storedName) { apiValues.agent_name = storedName; apiValues.api_title = storedName; }
        apiValues.api_user_id = localStorage.getItem("user_id") || apiValues.api_user_id || "default_user";

        setValues(apiValues);
      } catch (err) {
        console.error("[Default Inputs] Failed to load:", err);
        setValues({
          agent_name: localStorage.getItem("agentName") || "",
          api_title: localStorage.getItem("agentName") || "",
          api_user_id: localStorage.getItem("user_id") || "default_user",
        });
      } finally {
        setIsLoadingDefaults(false);
      }
    })();
  }, [config]);

  const handleChange = (fieldId, value) => {
    // Strip spaces from agent name in real-time
    if (fieldId === "agent_name") {
      value = (value || "").replace(/\s+/g, "");
    }
    setValues((prev) => ({ ...prev, [fieldId]: value }));
  };

  const totalSteps = enabledSteps.length || 1;
  const currentStepConfig = enabledSteps[activeStep - 1];
  const isLastStep = activeStep === totalSteps;

  // Fetch tools from scopes when tools step becomes active
  useEffect(() => {
    if (currentStepConfig?.id !== "step2" || toolsFetchedRef.current) return;
    toolsFetchedRef.current = true;

    (async () => {
      setToolsLoading(true);
      try {
        const stored = localStorage.getItem("agentDetails");
        if (!stored) { setToolsLoading(false); return; }
        const record = JSON.parse(stored);
        const scopeStr = record.agnt_access_scope;
        if (!scopeStr || scopeStr === "null") { setToolsLoading(false); return; }

        const parsed = JSON.parse(scopeStr);
        const scopesArray = parsed?.scopes || [];
        if (scopesArray.length === 0) { setToolsLoading(false); return; }

        const { langgraphApi } = await import("../services/langgraph-api");
        const scopesPayload = [scopesArray.join(",")];
        const toolsRes = await langgraphApi.getMcpServersByScopes(scopesPayload);
        const mcpServers = toolsRes?.mcp_servers || toolsRes?.data?.mcp_servers || toolsRes || [];
        setMcpToolsFromScopes(Array.isArray(mcpServers) ? mcpServers : []);
        console.log(`[Deep Agent] Fetched ${mcpServers.length} tools from scopes`);
      } catch (err) {
        console.warn("[Deep Agent] Failed to fetch tools:", err);
      } finally {
        setToolsLoading(false);
      }
    })();
  }, [currentStepConfig?.id]);

  // ─── Parse comma-separated string into array ───
  const toArray = (val) => {
    if (Array.isArray(val)) return val;
    if (typeof val === "string" && val.trim()) return val.split(",").map((s) => s.trim()).filter(Boolean);
    return [];
  };

  // ─── Parse JSON string safely ───
  const parseJson = (val, fallback = {}) => {
    if (typeof val === "object" && val !== null) return val;
    try { return JSON.parse(val); } catch { return fallback; }
  };

  // ─── Common fields for all payloads ───
  const commonFields = {
    sesn_id: sessionId,
    user_id: userId,
    aplctn_cd: appCode,
  };

  // ─── Sanitize agent name — replace spaces with underscores ───
  const sanitizeName = (name) => (name || "").replace(/\s+/g, "");

  // ─── Build payload for each step based on its config id ───
  const buildPayload = (stepId) => {
    const v = values;

    switch (stepId) {
      case "step1": // Configure Agent
        return {
          ...commonFields,
          agent_name: sanitizeName(v.agent_name),
          agent_description: v.agent_description || "",
          llm: {
            provider: v.llm_provider || "cortex",
            model: v.llm_model || "",
            api_key: v.llm_api_key || "",
            base_url: v.llm_base_url || "",
            temperature: Number(v.llm_temperature) || 0.1,
            top_p: Number(v.llm_top_p) || 0.9,
            max_tokens: Number(v.llm_max_tokens) || 4000,
            cert_path: v.llm_cert_path || "certs/cacert.pem",
          },
          system_prompt: {
            system: v.sp_system || "You are a helpful AI assistant.",
            instructions: v.sp_instructions || "",
            context: v.sp_context || "",
            constraints: v.sp_constraints || "",
            output_format: v.sp_output_format || "",
            tone: v.sp_tone || "",
            error_handling: v.sp_error_handling || "",
            tools_guidance: v.sp_tools_guidance || "",
            examples: Array.isArray(v.sp_examples) ? v.sp_examples : [],
          },
        };

      case "step2": // Configure Tools
        return {
          ...commonFields,
          enabled: !!v.tools_enabled,
          main_agent_enabled: !!v.tools_main_agent_enabled,
          main_agent_tools: Array.isArray(v.tools_main_agent_tools) ? v.tools_main_agent_tools : [],
          mcp_tools: (() => {
            // Build mcp_tools from selected tools grid + mcpToolsFromScopes state
            const selectedNames = Array.isArray(v.mcp_tools_selected) ? v.mcp_tools_selected : [];
            if (selectedNames.length === 0) return [];
            return mcpToolsFromScopes
              .filter((t) => selectedNames.includes(t.name || t.server_name))
              .map((t) => ({
                name: t.name || t.server_name || "",
                url: t.url || (t.config?.url) || "",
                description: t.description || "",
                transport: t.transport || (t.config?.transport) || "streamable_http",
              }));
          })(),
          timeout: Number(v.tools_timeout) || 30,
          permissions: Array.isArray(v.tools_permissions) ? v.tools_permissions.map((p) => ({
            operations: Array.isArray(p.operations) ? p.operations : toArray(p.operations),
            paths: Array.isArray(p.paths) ? p.paths : toArray(p.paths),
            mode: Array.isArray(p.mode) ? p.mode[0] || "allow" : (p.mode || "allow"),
          })) : [],
          interrupt_on: (() => {
            const hitl = v.hitl_config;
            if (!hitl?.enabled || !hitl?.tools) return {};
            const result = {};
            Object.entries(hitl.tools).forEach(([toolName, config]) => {
              // Only allow boolean or { allowed_decisions: [...] }
              if (config === true || config === false) {
                result[toolName] = config;
              } else if (typeof config === "object" && Array.isArray(config.allowed_decisions)) {
                result[toolName] = { allowed_decisions: config.allowed_decisions };
              }
              // Skip any string values like "approve" (legacy)
            });
            return result;
          })(),
        };

      case "step3": // Configure Memory
        return {
          ...commonFields,
          enabled: !!v.memory_enabled,
          database: {
            host: v.db_host || "",
            port: Number(v.db_port) || 5432,
            user: v.db_user || "",
            password: v.db_password || "",
            database: v.db_name || "",
          },
          seed_categories: Array.isArray(v.seed_categories) ? v.seed_categories.map((cat) => ({
            name: cat.name || "",
            seed_files: Array.isArray(cat.seed_files) ? cat.seed_files.map((f) => ({
              path: f.path || "",
              content: f.content || "",
            })) : [],
          })) : [],
        };

      case "step4": // Configure Middleware
        return {
          ...commonFields,
          enabled: !!v.mw_enabled,
          summarization: v.mw_summ_enabled ? {
            model: v.mw_summ_model || "claude-4-sonnet",
            trigger: [v.mw_summ_trigger_type || "tokens", Number(v.mw_summ_trigger_value) || 4000],
            keep: [v.mw_summ_keep_type || "messages", Number(v.mw_summ_keep_value) || 20],
          } : {},
          model_call_limit: v.mw_call_limits_enabled ? {
            thread_limit: Number(v.mw_model_call_thread) || 100,
            run_limit: Number(v.mw_model_call_run) || 50,
            exit_behavior: v.mw_model_call_exit || "end",
          } : {},
          tool_call_limit: v.mw_call_limits_enabled ? {
            thread_limit: Number(v.mw_tool_call_thread) || 50,
            run_limit: Number(v.mw_tool_call_run) || 25,
            tool_name: v.mw_tool_call_name || null,
            exit_behavior: v.mw_tool_call_exit || "continue",
          } : {},
          model_fallback: v.mw_fallback_enabled ? {
            fallback_models: Array.isArray(v.mw_fallback_models) ? v.mw_fallback_models : [],
          } : {},
          pii_detection: v.mw_pii_enabled ? {
            detectors: Array.isArray(v.mw_pii_detectors) ? v.mw_pii_detectors : ["email"],
            strategy: Array.isArray(v.mw_pii_strategy) ? v.mw_pii_strategy[0] || "redact" : (v.mw_pii_strategy || "redact"),
            apply_to_input: !!v.mw_pii_input,
            apply_to_output: !!v.mw_pii_output,
            apply_to_tool_results: !!v.mw_pii_tool_results,
          } : {},
          llm_tool_selector: v.mw_selector_enabled ? {
            model: v.mw_selector_model || "claude-sonnet-4-6",
            max_tools: Number(v.mw_selector_max) || 5,
            always_include: Array.isArray(v.mw_selector_always) ? v.mw_selector_always : [],
            system_prompt: v.mw_selector_prompt || "",
          } : {},
          tool_retry: v.mw_retry_enabled ? {
            max_retries: Number(v.mw_tool_retry_max) || 3,
            backoff_factor: Number(v.mw_tool_retry_backoff) || 2.0,
            initial_delay: Number(v.mw_tool_retry_delay) || 1.0,
            max_delay: Number(v.mw_tool_retry_max_d) || 60.0,
            jitter: v.mw_tool_retry_jitter !== false,
            on_failure: v.mw_tool_retry_fail || "continue",
          } : {},
          model_retry: v.mw_retry_enabled ? {
            max_retries: Number(v.mw_model_retry_max) || 3,
            jitter: v.mw_model_retry_jitter !== false,
            on_failure: v.mw_model_retry_fail || "continue",
          } : {},
          context_editing: {},
          shell_tool: {},
          file_search: v.mw_fs_enabled ? {
            root_path: v.mw_fs_root || ".",
            use_ripgrep: v.mw_fs_ripgrep !== false,
            max_file_size_mb: Number(v.mw_fs_max_size) || 10,
          } : {},
          llm_tool_emulator: {},
          snowflake_sanitizer: v.mw_snowflake_enabled ? { enabled: true } : {},
        };

      case "step5": // Configure Backend
        return {
          ...commonFields,
          type: "composite",
          default: v.backend_default || "state",
          routes: (() => {
            if (Array.isArray(v.backend_routes)) {
              const routeObj = {};
              v.backend_routes.forEach((r) => {
                if (r.path) routeObj[r.path] = r.backend || "store";
              });
              return routeObj;
            }
            return { "/memories/": "store", "/skills/": "store" };
          })(),
        };

      case "step6": // Configure Skills
        return {
          ...commonFields,
          enabled: !!v.skills_enabled,
          skill_files: Array.isArray(v.skill_files) ? v.skill_files.map((f) => ({
            path: f.path || "",
            content: f.content || "",
          })) : [],
        };

      case "step7": // Configure Sub-Agents
        return {
          ...commonFields,
          enabled: !!v.subagents_enabled,
          agents: Array.isArray(v.subagents_list) ? v.subagents_list.map((sa) => ({
            name: sa.name || "",
            description: sa.description || "",
            system_prompt: sa.system_prompt || "",
            tools: toArray(sa.tools),
            model: sa.model || "",
            skills: toArray(sa.skills),
            middleware: [],
            response_format: "",
            permissions: [],
          })) : [],
        };

      case "step8": // Configure API Settings
        return {
          ...commonFields,
          title: sanitizeName(v.agent_name) || v.api_title || "LDA Template API",
          version: v.api_version || "1.0.0",
          server: {
            host: v.api_host || "127.0.0.1",
            port: Number(v.api_port) || 8000,
            reload: !!v.api_reload,
            log_level: v.api_log_level || "info",
          },
          defaults: {
            user_id: v.api_user_id || "default_user",
            history_limit: Number(v.api_history_limit) || 100,
            files_limit: Number(v.api_files_limit) || 100,
            recursion_limit: Number(v.api_recursion_limit) || 1000,
          },
          cors: {
            enabled: true,
            origins: ["*"],
          },
        };

      default:
        return {};
    }
  };

  // ─── Map step config id to ldaApi method name ───
  const STEP_API_MAP = {
    step1: "configure",
    step2: "configureTools",
    step3: "configureMemory",
    step4: "configureMiddleware",
    step5: "configureBackend",
    step6: "configureSkills",
    step7: "configureSubagents",
    step8: "configureApi",
  };

  // ─── Save & Continue — just navigate to next step (no API call) ───
  const handleNext = () => {
    if (isLastStep) {
      handleCreateAll();
    } else {
      setActiveStep((prev) => Math.min(prev + 1, totalSteps));
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => Math.max(prev - 1, 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // ─── Create & Deploy Agent — calls ALL step APIs, then create, then deploy ───
  const handleCreateAll = async () => {
    setIsCreating(true);
    setCreateStatus("creating");
    setSaveError("");

    try {
      const { ldaApi } = await import("../services/lda-api");

      // 1. Call each step API in order
      const stepOrder = ["step1", "step2", "step3", "step4", "step5", "step6", "step7", "step8"];
      for (const stepId of stepOrder) {
        const apiMethod = STEP_API_MAP[stepId];
        if (apiMethod && agentUuid) {
          const payload = buildPayload(stepId);
          console.log(`[${stepId}] Calling ${apiMethod}...`);
          await ldaApi[apiMethod](agentUuid, payload);
          console.log(`[${stepId}] ✓ Saved`);
        }
      }

      // 2. Create the agent
      console.log(`[Create] Calling createAgent for ${agentUuid}...`);
      await ldaApi.createAgent(agentUuid);
      console.log(`[Create] ✓ Agent created`);

      // 3. Deploy the agent
      console.log(`[Deploy] Calling deployAgent for ${agentUuid}...`);
      await ldaApi.deployAgent(agentUuid);
      console.log(`[Deploy] ✓ Agent deployed`);

      setCreateStatus("success");
      setTimeout(() => {
        setShowDeployment(true);
        window.scrollTo({ top: 0, behavior: "smooth" });
      }, 1500);
    } catch (error) {
      console.error("Create/Deploy failed:", error);
      const errMsg = error?.message || "Unknown error occurred";
      setSaveError(errMsg);
      setCreateStatus("error");
      setTimeout(() => setCreateStatus("idle"), 6000);
    } finally {
      setIsCreating(false);
    }
  };



  // ─── No config ───
  if (!config) {
    return (
      <PageLayout>
        <BackToDashboard />
        <div style={{ padding: 40, textAlign: "center", color: "#78909C" }}>
          <h2>Unknown Agent Type: "{agentType}"</h2>
          <p>No configuration found. Add an entry in AgentTypeConfig.js</p>
        </div>
      </PageLayout>
    );
  }

  // ─── Loading defaults ───
  if (isLoadingDefaults) {
    return (
      <PageLayout>
        <BackToDashboard />
        <div style={{ padding: "80px 24px", textAlign: "center" }}>
          <div style={{ width: 36, height: 36, border: "3px solid #0072C6", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px" }} />
          <p style={{ color: "#78909C", fontSize: 14 }}>Loading default configuration...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </PageLayout>
    );
  }

  const getFooterButtons = () => {
    const buttons = [];
    if (activeStep > 1) buttons.push({ label: "Back", variant: "outline", onClick: handleBack });
    buttons.push({ label: "Discard", variant: "outline", onClick: () => navigate("/dashboard") });

    if (isLastStep) {
      const label = createStatus === "creating" ? "Creating Agent..."
        : createStatus === "success" ? "Agent Created!"
        : createStatus === "error" ? "Retry"
        : "Save & Create Agent";
      buttons.push({
        label,
        variant: createStatus === "creating" || createStatus === "success" ? "disabled-primary" : "primary",
        onClick: createStatus === "creating" || createStatus === "success" ? undefined : handleNext,
      });
    } else {
      buttons.push({ label: "Save & Continue", variant: "primary", onClick: handleNext });
    }
    return buttons;
  };

  // ─── Deployment / Download View — uses same Deployment component as Cortex/LangGraph ───
  if (showDeployment) {
    const agName = sanitizeName(values.agent_name) || "Agent";
    // Build agentDetails object matching what Deployment component expects
    const deployAgentDetails = {
      agnt_id: agentUuid,
      agnt_nm: agName,
      agnt_type: "Deep Agent",
    };

    return (
      <PageLayout>
        <BackToDashboard />
        <Deployment
          agentDetails={deployAgentDetails}
          onFinish={() => navigate("/dashboard")}
        />
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <BackToDashboard />

      {/* Stepper — same visual as Cortex/LangGraph */}
      <DynamicStepper activeStep={activeStep} steps={stepLabels} />

      {/* Step content */}
      {currentStepConfig && (
        <DynamicStepRenderer
          step={currentStepConfig}
          values={values}
          onChange={handleChange}
          mcpToolsFromScopes={mcpToolsFromScopes}
          toolsLoading={toolsLoading}
        />
      )}

      {/* Preferences custom fields */}
      <CustomFieldsSection
        agentType={agentType}
        stepId={currentStepConfig?.id || "step1"}
        values={values}
        onChange={handleChange}
      />

      {/* Footer */}
      <FooterButtons loading={isCreating} buttons={getFooterButtons()} />

      {/* Save Error Toast */}
      {saveStatus === "error" && saveError && (
        <div style={{
          position: "fixed", top: 24, right: 24, zIndex: 9999,
          minWidth: 360, maxWidth: 520, padding: "16px 20px",
          borderRadius: 12, backgroundColor: "#FFF",
          border: "1px solid #FEB2B2",
          boxShadow: "0 6px 20px rgba(0,0,0,0.1)",
          display: "flex", alignItems: "flex-start", gap: 12,
        }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#FFF5F5", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" fill="#E53E3E" /><path d="M7 7L13 13M13 7L7 13" stroke="white" strokeWidth="2" strokeLinecap="round" /></svg>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A", marginBottom: 4 }}>Save Failed</div>
            <div style={{ fontSize: 12, color: "#78909C", lineHeight: 1.4, wordBreak: "break-word" }}>{saveError}</div>
          </div>
          <button onClick={() => { setSaveError(""); setSaveStatus("idle"); }} style={{
            background: "none", border: "none", cursor: "pointer", padding: 4, flexShrink: 0, marginLeft: "auto",
          }}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 4L12 12M12 4L4 12" stroke="#90A4AE" strokeWidth="2" strokeLinecap="round" /></svg>
          </button>
        </div>
      )}

      {/* Create Toast */}
      {createStatus !== "idle" && (
        <div style={{
          position: "fixed", top: 24, right: 24, zIndex: 9999,
          minWidth: 340, maxWidth: 420, padding: "16px 20px",
          borderRadius: 12, backgroundColor: "#FFF",
          border: `1px solid ${createStatus === "error" ? "#FEB2B2" : createStatus === "success" ? "#9AE6B4" : "#D0E4F5"}`,
          boxShadow: "0 6px 20px rgba(0,0,0,0.1)",
          display: "flex", alignItems: "center", gap: 12,
        }}>
          {createStatus === "creating" && (
            <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#EBF5FB", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ width: 16, height: 16, border: "2.5px solid #0072C6", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            </div>
          )}
          {createStatus === "success" && (
            <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#F0FFF4", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" fill="#2E8540" /><path d="M6 10.5L8.5 13L14 7.5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
          )}
          {createStatus === "error" && (
            <div style={{ width: 32, height: 32, borderRadius: "50%", backgroundColor: "#FFF5F5", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" fill="#E53E3E" /><path d="M7 7L13 13M13 7L7 13" stroke="white" strokeWidth="2" strokeLinecap="round" /></svg>
            </div>
          )}
          <span style={{ fontSize: 14, fontWeight: 500, color: "#1A1A1A" }}>
            {createStatus === "creating" && "Agent creation in progress..."}
            {createStatus === "success" && "Agent created successfully!"}
            {createStatus === "error" && "Agent creation failed. Please try again."}
          </span>
        </div>
      )}

      {createStatus === "creating" && (
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      )}
    </PageLayout>
  );
}