/**
 * lda-api.ts — Deep Agent (LDA) API Service
 *
 * All endpoints for the LangChain Deep Agent builder flow.
 * Each step in the builder calls its corresponding API.
 */
import { API_CONFIG } from "../config/api-config";

const BASE = "https://agentbuilder-be.edl.dev.awsdns.internal.das";

async function post(url, body = {}) {
  const res = await fetch(`${BASE}${url}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    let errDetail = "";
    try {
      const errJson = await res.json();
      errDetail = errJson.detail
        ? (Array.isArray(errJson.detail)
          ? errJson.detail.map((d) => `${d.loc?.join(".")} — ${d.msg}`).join("; ")
          : String(errJson.detail))
        : JSON.stringify(errJson);
    } catch {
      errDetail = await res.text().catch(() => "No details");
    }
    throw new Error(`${res.status} ${res.statusText}: ${errDetail}`);
  }
  return res.json();
}

async function get(url) {
  const res = await fetch(`${BASE}${url}`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`API Error ${res.status}: ${errText}`);
  }
  return res.json();
}

export const ldaApi = {

  // Get default inputs for all steps
  getDefaultInputs() {
    return get("/api/lda_agents/default_inputs");
  },

  // Step 1: Register — generates agent UUID
  register() {
    return post("/api/lda_agents/register");
  },

  // Step 2: Configure Agent
  configure(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/configure`, payload);
  },

  // Step 3: Configure Tools
  configureTools(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/tools`, payload);
  },

  // Step 4: Configure Memory
  configureMemory(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/memory`, payload);
  },

  // Step 5: Configure Middleware
  configureMiddleware(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/middleware`, payload);
  },

  // Step 6: Configure Backend
  configureBackend(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/backend`, payload);
  },

  // Step 7: Configure Skills
  configureSkills(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/skills`, payload);
  },

  // Step 8: Configure Sub-Agents
  configureSubagents(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/subagents`, payload);
  },

  // Step 9: Configure API Settings
  configureApi(agentUuid, payload) {
    return post(`/api/lda_agents/${agentUuid}/api`, payload);
  },

  // Final: Create Agent
  createAgent(agentUuid) {
    return get(`/api/lda_agents/${agentUuid}/create`);
  },

  // Deploy Agent
  deployAgent(agentUuid) {
    return get(`/api/lda_agents/${agentUuid}/deploy`);
  },

  // Status check
  getStatus(agentId) {
    return get(`/api/lda_agents/${agentId}/status`);
  },

  // Download
  async download(agentId) {
    const res = await fetch(`${BASE}/api/lda_agents/${agentId}/download`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });
    if (!res.ok) {
      let errDetail = "";
      try { const e = await res.json(); errDetail = e.detail || JSON.stringify(e); } catch { errDetail = await res.text().catch(() => ""); }
      throw new Error(`${res.status}: ${errDetail}`);
    }
    const contentType = res.headers.get("content-type") || "";
    if (contentType.includes("application/zip") || contentType.includes("octet-stream")) {
      return res.blob();
    }
    return res.json();
  },
};